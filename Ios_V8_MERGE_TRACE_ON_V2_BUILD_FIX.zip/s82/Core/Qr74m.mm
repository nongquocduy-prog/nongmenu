#import "Qr74m.h"
#import "OngnongOxorany.h"
#import "OngnongHookManager.h"
#import "zx8f1a_gate.h"
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
#include <atomic>
#include <stdint.h>
#include <dlfcn.h>

namespace Ongnong {

static NSMutableArray<NSString *> *gMergeEvents = nil;
static NSString *gLastMergeMessage = nil;
static CFTimeInterval gLastMergeMessageAt = 0;
static void mergeEvent(NSString *message) {
    @synchronized([NSProcessInfo processInfo]) {
        if (!gMergeEvents) gMergeEvents = [NSMutableArray array];
        CFTimeInterval now = CACurrentMediaTime();
        if ([gLastMergeMessage isEqualToString:message] && now - gLastMergeMessageAt < 1.5) return;
        gLastMergeMessage = message;
        gLastMergeMessageAt = now;
        NSString *line = [NSString stringWithFormat:@"%.3f %@", now, message ?: @""];
        [gMergeEvents addObject:line];
        if (gMergeEvents.count > 180) [gMergeEvents removeObjectsInRange:NSMakeRange(0, gMergeEvents.count - 180)];
    }
}

struct V2I { int32_t x; int32_t y; };
using ResolveIcallFn = void *(*)(const char *);
using ClassGetTypeFn = void *(*)(void *);
using TypeGetObjectFn = void *(*)(void *);
using FindObjects2Fn = monoArray<void *> *(*)(void *, bool);
using FindObjects1Fn = monoArray<void *> *(*)(void *);
using GetSuggestionFn = void *(*)(void *);
using GetCellFn = void *(*)(void *);
using GetPosFn = uint64_t (*)(void *);
using GetBoolFn = bool (*)(void *);
using ItemClickFn = void (*)(void *, void *);
using GetIntFn = int (*)(void *);
using HandleDropFn = void (*)(void *, void *);
using TryProducerFn = bool (*)(void *);
using ProducerClickFn = void (*)(void *, void *);
using GetBoolFn2 = bool (*)(void *);
using PerformMergeFn = void (*)(void *, void *, void *, void *, void *);
using GetSelectedBetFn = int (*)(void *);
using SetSelectedBetFn = void (*)(void *, int);
using GetBetOptionsFn = monoArray<int32_t> *(*)(void *);
using GetObjectFn = void *(*)(void *);
using VoidThisFn = void (*)(void *);
using BetButtonPressedFn = void (*)(void *);
using IsBoardFullFn = bool (*)(void *, bool, Il2CppString *);
using ObjectGetClassFn = void *(*)(void *);
using ClassGetMethodFromNameFn = MethodInfo *(*)(void *, const char *, int);
using RuntimeInvokeFn = void *(*)(MethodInfo *, void *, void **, void **);
using ObjectUnboxFn = void *(*)(void *);
using ArrayNewFn = void *(*)(void *, uintptr_t);
using StringNewFn = Il2CppString *(*)(const char *);
using ClassAssignableFn = bool (*)(void *, void *);

static bool gOrdersEventSignature = false;
static bool gMergeOrdersSignature = false;
static bool gCurrentOrdersBoard = false;
static GetObjectFn fnBoardEventId = nullptr;
static std::atomic_bool gEnabled(false);
static std::atomic_bool gRuntimeReady(false);
static std::atomic_bool gPrepareStarted(false);
NSString *AutoMergeOrderDebugCopy(void) {
    @synchronized([NSProcessInfo processInfo]) {
        NSString *head = [NSString stringWithFormat:@"ONGNONG MERGE DEBUG\nEnabled=%d Ready=%d Orders=%d\n", (int)gEnabled.load(), (int)gRuntimeReady.load(), (int)gCurrentOrdersBoard];
        NSString *body = [gMergeEvents componentsJoinedByString:@"\n"];
        return [head stringByAppendingString:body ?: @""];
    }
}

static std::atomic_bool gStepScheduled(false);
static void *gBoardType = nullptr;
static void *gOrdersViewType = nullptr;
static void *gMergePopupType = nullptr;
static size_t offPopupOrdersView = SIZE_MAX;
static size_t offOrdersViewBoard = SIZE_MAX;
static size_t offOrdersViewHandler = SIZE_MAX;
static size_t offOrdersViewReady = SIZE_MAX;
static ObjectGetClassFn fnObjectGetClass = nullptr;
static ClassGetMethodFromNameFn fnClassGetMethodFromName = nullptr;
static RuntimeInvokeFn fnRuntimeInvoke = nullptr;
static ObjectUnboxFn fnObjectUnbox = nullptr;
static ArrayNewFn fnArrayNew = nullptr;
static StringNewFn fnStringNew = nullptr;
static ClassAssignableFn fnClassAssignable = nullptr;
static void *gProducerClass = nullptr;
static size_t offItemChain = SIZE_MAX;
static size_t offItemIndex = SIZE_MAX;
static size_t offItemDraggable = SIZE_MAX;
static size_t offItemOrderStatus = SIZE_MAX;
static MethodInfo *miClaimOrder = nullptr;
static size_t offHintEnergyManager = SIZE_MAX;
static int (*fnCalculateEnergyCost)(void *, int) = nullptr;
static bool (*fnHasEnoughEnergy)(void *, int) = nullptr;
static CFTimeInterval gOrderClaimWaitUntil = 0;
static NSString *gLastClaimedOrderId = nil;
static CFTimeInterval gLastClaimAttemptAt = 0;
static bool gClaimConfirmationPending = false;
static void *gProducerItemType = nullptr;
static void *gBetViewType = nullptr;
static void *gBetDataModel = nullptr;
static void *gProducerItem = nullptr;
static void *gBoardController = nullptr;
static CFTimeInterval gNextScanAt = 0;
static CFTimeInterval gNextActionAt = 0;
static int gNoHintCount = 0;
static bool gProducerFillMode = false;
static int gProducerFillLastItems = -1;
static int gProducerFillStall = 0;
static int gProducerFillClicks = 0;
static bool gRewardRefreshPending = false;
static std::atomic_int gRewardSweepGeneration(0);
static int gTerminalNoProgressCycles = 0;
static bool gHadActiveBoard = false;
static int gLastMergeSrcX = INT32_MIN;
static int gLastMergeSrcY = INT32_MIN;
static int gLastMergeDstX = INT32_MIN;
static int gLastMergeDstY = INT32_MIN;
static void *gLastMergeSrcItem = nullptr;
static void *gLastMergeDstItem = nullptr;
static int gStaleHintCount = 0;
static bool gStaleHintDetected = false;


static CFTimeInterval gOrdersProducerRecoveryAt = 0;
static CFTimeInterval gOrdersLastProgressAt = 0;
static int gOrdersProducerMisses = 0;
static int gEventCompatRetries = 0;
static CFTimeInterval gEventCompatBoardGraceUntil = 0;


static bool gBoardFullMergeRecovery = false;
static int gBoardFullMergeScans = 0;


static void *gCollectibleIgnoreItem = nullptr;
static CFTimeInterval gCollectibleIgnoreUntil = 0;
static std::atomic_int gCollectibleTapGeneration(0);
static CFTimeInterval gCollectibleTapInFlightUntil = 0;

enum PendingActionKind { PENDING_NONE = 0, PENDING_MERGE = 1, PENDING_PRODUCER = 2 };
static PendingActionKind gPendingAction = PENDING_NONE;
static CFTimeInterval gPendingDeadline = 0;
static V2I gPendingSrc = {INT32_MIN, INT32_MIN};
static V2I gPendingDst = {INT32_MIN, INT32_MIN};
static void *gPendingSrcItem = nullptr;
static void *gPendingDstItem = nullptr;
static int gPendingItemsBefore = -1;


static FindObjects2Fn gFindObjects2 = nullptr;
static FindObjects1Fn gFindObjects1 = nullptr;
static ClassGetTypeFn gClassGetType = nullptr;
static TypeGetObjectFn gTypeGetObject = nullptr;

static GetSuggestionFn fnGetHintSuggestion = nullptr;
static GetCellFn fnGetSourceCell = nullptr;
static GetCellFn fnGetTargetCell = nullptr;
static GetPosFn fnGetCellBoardPosition = nullptr;
static GetBoolFn fnGetIsObstacleHint = nullptr;
static GetBoolFn fnGetIsCollectibleAccumulationHint = nullptr;
static ItemClickFn fnBaseItemClicked = nullptr;
static GetIntFn fnGetRows = nullptr;
static GetIntFn fnGetColumns = nullptr;
static HandleDropFn fnHandleDrop = nullptr;
static TryProducerFn fnTryProducer = nullptr;
static TryProducerFn fnTryClickSpawner = nullptr;
static ProducerClickFn fnProducerItemClicked = nullptr;
static GetBoolFn2 fnProducerBehaviorIsEnabled = nullptr;
static PerformMergeFn fnPerformMerge = nullptr;
static GetSelectedBetFn fnGetSelectedBet = nullptr;
static SetSelectedBetFn fnSetSelectedBet = nullptr;
static GetBetOptionsFn fnGetBetOptions = nullptr;
static GetObjectFn fnBoardGetBetDataModel = nullptr;
static VoidThisFn fnBoardDataUpdated = nullptr;
static BetButtonPressedFn fnBetButtonPressed = nullptr;
static IsBoardFullFn fnIsBoardFull = nullptr;

static size_t offTiles = SIZE_MAX;
static size_t offCurrentItem = SIZE_MAX;
static size_t offBoardPosition = SIZE_MAX;
static size_t offIsInitialized = SIZE_MAX;
static size_t offOperationsHandler = SIZE_MAX;
static size_t offOpsHintController = SIZE_MAX;
static size_t offHintControllerHandler = SIZE_MAX;
static size_t offProducerInitialized = SIZE_MAX;
static size_t offProducerBehavior = SIZE_MAX;
static size_t offItemType = SIZE_MAX;

static inline bool ptrOK(const void *p) {
    uintptr_t v = (uintptr_t)p;
    return v > 0x10000ULL && v < 0x0000008000000000ULL;
}

static inline void *methodPtr(MethodInfo *m) { return m ? m->methodPointer : nullptr; }
static inline V2I unpackV2(uint64_t raw) {
    return {(int32_t)(raw & 0xffffffffu), (int32_t)(raw >> 32)};
}

static MethodInfo *findMethod(const char *ns, const char *cl, const char *name, int argc) {
    const char *img = nullptr;
    void *klass = Il2CppFindClassAnyImage(ns, cl, &img);
    if (!klass || !img) return nullptr;
    return Il2CppFindMethodInfoRaw(img, ns, cl, name, argc, true);
}

static size_t findField(const char *ns, const char *cl, const char *name) {
    const char *img = nullptr;
    void *klass = Il2CppFindClassAnyImage(ns, cl, &img);
    if (!klass || !img) return SIZE_MAX;
    return Il2CppGetFieldOffset(img, ns, cl, name);
}

static int countBoardItems(void *board);

static bool prepareRuntime(void) {
    const char *boardImage = nullptr;
    void *boardClass = Il2CppFindClassAnyImage(
        OX_C("MoonActive.Minigame.Merge.UI.Board"),
        OX_C("MergeMinigameBoardUIController"), &boardImage);
    if (!boardClass || !boardImage) return false;

    void *ordersViewClass = Il2CppFindClassAnyImage(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigameOrdersView"), nullptr);
    void *popupClass = Il2CppFindClassAnyImage(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigamePopup"), nullptr);
    offPopupOrdersView = findField(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigamePopup"), OX_C("m_OrdersView"));
    offOrdersViewBoard = findField(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigameOrdersView"), OX_C("m_BoardUIController"));
    offOrdersViewHandler = findField(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigameOrdersView"), OX_C("m_Handler"));
    offOrdersViewReady = findField(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigameOrdersView"), OX_C("m_ReadyOrderIds"));
    miClaimOrder = findMethod(OX_C("MoonActive.Minigame.Merge.Common.MergeOrders"), OX_C("MergeMinigameOrdersHandler"), OX_C("ClaimOrder"), 1);
    fnObjectGetClass = (ObjectGetClassFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_object_get_class"));
    fnClassGetMethodFromName = (ClassGetMethodFromNameFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_method_from_name"));
    fnRuntimeInvoke = (RuntimeInvokeFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_runtime_invoke"));
    fnObjectUnbox = (ObjectUnboxFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_object_unbox"));
    fnArrayNew = (ArrayNewFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_array_new"));
    fnStringNew = (StringNewFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_string_new"));
    fnClassAssignable = (ClassAssignableFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_is_assignable_from"));
    offItemChain = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameItem"), OX_C("m_ChainId"));
    offItemIndex = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameItem"), OX_C("m_IndexInChain"));
    offItemDraggable = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameItem"), OX_C("m_IsDraggable"));
    offItemOrderStatus = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameItem"), OX_C("m_OrderVisualStatus"));
    gOrdersEventSignature = Il2CppFindClassAnyImage(OX_C("MoonActive.SpecialEvents.OrdersGame"), OX_C("OrdersGameSpecialEvent"), nullptr) != nullptr;
    gMergeOrdersSignature = Il2CppFindClassAnyImage(OX_C("MoonActive.Minigame.Merge.Common.MergeOrders"), OX_C("MergeMinigameOrdersHandler"), nullptr) != nullptr;
    gClassGetType = (ClassGetTypeFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_type"));
    gTypeGetObject = (TypeGetObjectFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_type_get_object"));
    ResolveIcallFn resolve = (ResolveIcallFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_resolve_icall"));
    if (resolve) {
        gFindObjects2 = (FindObjects2Fn)resolve(OX_C("UnityEngine.Object::FindObjectsOfType(System.Type,System.Boolean)"));
        gFindObjects1 = (FindObjects1Fn)resolve(OX_C("UnityEngine.Object::FindObjectsOfType(System.Type)"));
    }
    if (gClassGetType && gTypeGetObject) {
        void *t = gClassGetType(boardClass);
        if (t) gBoardType = gTypeGetObject(t);
        if (popupClass) {
            void *pt = gClassGetType(popupClass);
            if (pt) gMergePopupType = gTypeGetObject(pt);
        }
        if (ordersViewClass) {
            void *ot = gClassGetType(ordersViewClass);
            if (ot) gOrdersViewType = gTypeGetObject(ot);
        }

        const char *producerImage = nullptr;
        void *producerClass = Il2CppFindClassAnyImage(
            OX_C("MoonActive.Minigame.Merge.UI.Items"),
            OX_C("MergeMinigameProducerItem"), &producerImage);
        if (producerClass) {
            gProducerClass = producerClass;
            void *pt = gClassGetType(producerClass);
            if (pt) gProducerItemType = gTypeGetObject(pt);
        }

        const char *betViewImage = nullptr;
        void *betViewClass = Il2CppFindClassAnyImage(
            OX_C("MoonActive.Minigame.Merge.UI.Bet"),
            OX_C("MergeMinigameBetView"), &betViewImage);
        if (betViewClass) {
            void *bt = gClassGetType(betViewClass);
            if (bt) gBetViewType = gTypeGetObject(bt);
        }
    }

    fnGetHintSuggestion = (GetSuggestionFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Hint"), OX_C("MergeMinigameHintHandler"), OX_C("GetHintSuggestion"), 0));
    fnGetSourceCell = (GetCellFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Hint"), OX_C("MergeMinigameHintSuggestion"), OX_C("get_SourceCell"), 0));
    fnGetTargetCell = (GetCellFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Hint"), OX_C("MergeMinigameHintSuggestion"), OX_C("get_TargetCell"), 0));
    fnGetIsObstacleHint = (GetBoolFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Hint"), OX_C("MergeMinigameHintSuggestion"), OX_C("get_IsObstacleHint"), 0));
    fnGetIsCollectibleAccumulationHint = (GetBoolFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Hint"), OX_C("MergeMinigameHintSuggestion"), OX_C("get_IsCollectibleAccumulationHint"), 0));
    fnBaseItemClicked = (ItemClickFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameItem"), OX_C("ItemClickedInternal"), 1));
    fnGetCellBoardPosition = (GetPosFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Common.Data"), OX_C("MergeMinigameBoardCellData"), OX_C("get_BoardPosition"), 0));
    fnBoardEventId = (GetObjectFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("get_EventId"), 0));
    fnGetRows = (GetIntFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("get_Rows"), 0));
    fnGetColumns = (GetIntFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("get_Columns"), 0));
    fnHandleDrop = (HandleDropFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardTileView"), OX_C("HandleDrop"), 1));
    fnTryProducer = (TryProducerFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardTileView"), OX_C("TryTriggerProducerTap"), 0));
    fnTryClickSpawner = (TryProducerFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardTileView"), OX_C("TryTriggerClickSpawnerTap"), 0));
    fnProducerItemClicked = (ProducerClickFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameProducerItem"), OX_C("ItemClickedInternal"), 1));
    fnProducerBehaviorIsEnabled = (GetBoolFn2)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Items.Behaviors"), OX_C("MergeMinigameProducerBehavior"), OX_C("get_IsEnabled"), 0));
    fnPerformMerge = (PerformMergeFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameBoardOperationsHandler"), OX_C("PerformMerge"), 4));
    fnIsBoardFull = (IsBoardFullFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameBoardOperationsHandler"), OX_C("IsBoardFull"), 2));
    fnGetSelectedBet = (GetSelectedBetFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Common.Data"), OX_C("MergeMinigameBetDataModel"), OX_C("get_SelectedBet"), 0));
    fnSetSelectedBet = (SetSelectedBetFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Common.Data"), OX_C("MergeMinigameBetDataModel"), OX_C("set_SelectedBet"), 1));
    fnGetBetOptions = (GetBetOptionsFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Common.Data"), OX_C("MergeMinigameBetDataModel"), OX_C("get_BetOptions"), 0));
    fnBoardGetBetDataModel = (GetObjectFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("get_BetDataModel"), 0));
    fnBoardDataUpdated = (VoidThisFn)methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("OnBoardDataUpdated"), 0));
    fnBetButtonPressed = (BetButtonPressedFn)methodPtr(findMethod(OX_C("KitHelpers.ProbabilityEngineKit"), OX_C("BetView"), OX_C("BetButtonPressed"), 0));

    offTiles = findField(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("m_Tiles"));
    offCurrentItem = findField(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardTileView"), OX_C("m_CurrentItem"));
    offBoardPosition = findField(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardTileView"), OX_C("m_BoardPosition"));
    offIsInitialized = findField(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("m_IsInitialized"));
    offOperationsHandler = findField(OX_C("MoonActive.Minigame.Merge.UI.Board"), OX_C("MergeMinigameBoardUIController"), OX_C("m_OperationsHandler"));
    offOpsHintController = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameBoardOperationsHandler"), OX_C("m_HintController"));
    offHintControllerHandler = findField(OX_C("MoonActive.Minigame.Merge.Hint"), OX_C("MergeMinigameHintController"), OX_C("m_HintHandler"));
    offHintEnergyManager = findField(OX_C("MoonActive.Minigame.Merge.Hint"), OX_C("MergeMinigameHintController"), OX_C("m_EnergyManager"));
    fnCalculateEnergyCost = (int (*)(void *, int))methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigameGenericCurrencyEnergyManager"), OX_C("CalculateEnergyCost"), 1));
    fnHasEnoughEnergy = (bool (*)(void *, int))methodPtr(findMethod(OX_C("MoonActive.Minigame.Merge.Common"), OX_C("MergeMinigameGenericCurrencyEnergyManager"), OX_C("HasEnoughEnergy"), 1));
    offProducerInitialized = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameProducerItem"), OX_C("m_IsProducerInitialized"));
    offProducerBehavior = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameProducerItem"), OX_C("m_ProducerBehavior"));
    offItemType = findField(OX_C("MoonActive.Minigame.Merge.UI.Items"), OX_C("MergeMinigameItem"), OX_C("m_ItemType"));

    bool ok = ptrOK(gBoardType) && (gFindObjects2 || gFindObjects1) &&
              fnGetHintSuggestion && fnGetSourceCell && fnGetTargetCell && fnGetCellBoardPosition &&
              (fnPerformMerge || fnHandleDrop) && offTiles != SIZE_MAX &&
              offCurrentItem != SIZE_MAX && offBoardPosition != SIZE_MAX &&
              offOperationsHandler != SIZE_MAX && offOpsHintController != SIZE_MAX &&
              offHintControllerHandler != SIZE_MAX;
    gRuntimeReady.store(ok);
    return ok;
}

static void prepareRetry(int attempt) {
    if (!gEnabled.load() || gRuntimeReady.load()) { gPrepareStarted.store(false); return; }
    if (prepareRuntime()) { gPrepareStarted.store(false); return; }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue(), ^{ prepareRetry(attempt + 1); });
}

static bool claimReadyOrder(void *board) {
    if (!gCurrentOrdersBoard || !ptrOK(board)) return false;
    CFTimeInterval now = CACurrentMediaTime();
    if (now < gOrderClaimWaitUntil) return true;
    if (offPopupOrdersView == SIZE_MAX || offOrdersViewBoard == SIZE_MAX || offOrdersViewHandler == SIZE_MAX || offOrdersViewReady == SIZE_MAX ||
        !ptrOK(gMergePopupType) || !miClaimOrder || !fnObjectGetClass || !fnClassGetMethodFromName ||
        !fnRuntimeInvoke || !fnObjectUnbox || !fnArrayNew || !fnStringNew) return false;
    monoArray<void *> *popups = gFindObjects2 ? gFindObjects2(gMergePopupType, false) : (gFindObjects1 ? gFindObjects1(gMergePopupType) : nullptr);
    if (!ptrOK(popups) || popups->getCapacity() < 0 || popups->getCapacity() > 32) return false;
    for (int i = 0; i < popups->getCapacity(); i++) {
        void *popup = popups->m_Items[i];
        if (!ptrOK(popup)) continue;
        void *view = *reinterpret_cast<void **>((uint8_t *)popup + offPopupOrdersView);
        if (!ptrOK(view)) continue;
        void *linkedBoard = *reinterpret_cast<void **>((uint8_t *)view + offOrdersViewBoard);
        if (linkedBoard != board) continue;
        void *handler = *reinterpret_cast<void **>((uint8_t *)view + offOrdersViewHandler);
        void *ready = *reinterpret_cast<void **>((uint8_t *)view + offOrdersViewReady);
        if (!ptrOK(handler) || !ptrOK(ready)) return false;
        void *klass = fnObjectGetClass(ready);
        if (!ptrOK(klass)) return false;
        MethodInfo *countMethod = fnClassGetMethodFromName(klass, OX_C("get_Count"), 0);
        MethodInfo *copyMethod = fnClassGetMethodFromName(klass, OX_C("CopyTo"), 1);
        if (!countMethod || !copyMethod) return false;
        void *exception = nullptr;
        void *boxedCount = fnRuntimeInvoke(countMethod, ready, nullptr, &exception);
        if (ptrOK(exception) || !ptrOK(boxedCount)) { return false; }
        void *value = fnObjectUnbox(boxedCount);
        if (!ptrOK(value)) return false;
        int count = *reinterpret_cast<int *>(value);
        if (count == 0 && gClaimConfirmationPending) {
            gClaimConfirmationPending = false;
            gLastClaimedOrderId = nil;
            return false;
        }
        if (count <= 0 || count > 24) return false;
        Il2CppString *empty = fnStringNew("");
        if (!ptrOK(empty)) return false;
        void *stringClass = fnObjectGetClass(empty);
        if (!ptrOK(stringClass)) return false;
        auto *ids = reinterpret_cast<monoArray<Il2CppString *> *>(fnArrayNew(stringClass, (uintptr_t)count));
        if (!ptrOK(ids)) return false;
        void *args[1] = {ids};
        exception = nullptr;
        fnRuntimeInvoke(copyMethod, ready, args, &exception);
        if (ptrOK(exception)) { return false; }
        if (gClaimConfirmationPending && gLastClaimedOrderId.length) {
            bool stillReady = false;
            for (int k = 0; k < count; ++k) {
                Il2CppString *candidate = ids->m_Items[k];
                if (!ptrOK(candidate) || candidate->length <= 0 || candidate->length > 160) continue;
                NSString *candidateId = [[NSString alloc] initWithCharacters:(const unichar *)&candidate->start_char length:candidate->length];
                if ([candidateId isEqualToString:gLastClaimedOrderId]) { stillReady = true; break; }
            }
            if (!stillReady) {
                gClaimConfirmationPending = false;
                gLastClaimedOrderId = nil;
            } else if (now - gLastClaimAttemptAt < 3.0) {
                gOrderClaimWaitUntil = now + 0.35;
                return true;
            } else {
                gClaimConfirmationPending = false;
                gOrderClaimWaitUntil = now + 1.0;
                return true;
            }
        }
        for (int j = 0; j < count; j++) {
            Il2CppString *orderId = ids->m_Items[j];
            if (!ptrOK(orderId) || orderId->length <= 0 || orderId->length > 160) continue;
            NSString *key = [[NSString alloc] initWithBytes:&orderId->start_char length:(NSUInteger)orderId->length * sizeof(uint16_t) encoding:NSUTF16LittleEndianStringEncoding];
            if (!key.length) continue;
            if ([key isEqualToString:gLastClaimedOrderId] && now - gLastClaimAttemptAt < 4.0) continue;
            exception = nullptr;
            void *claimArgs[1] = {orderId};
            fnRuntimeInvoke(miClaimOrder, handler, claimArgs, &exception);
            gLastClaimedOrderId = [key copy];
            gLastClaimAttemptAt = now;
            gClaimConfirmationPending = !ptrOK(exception);
            if (ptrOK(exception)) {
                gOrderClaimWaitUntil = now + 1.0;
                return true;
            }
            gOrderClaimWaitUntil = now + 0.50;
            return true;
        }
    }
    return false;
}

static void *findOrdersBoard(void) {
    if (!ptrOK(gMergePopupType) || offPopupOrdersView == SIZE_MAX || offOrdersViewBoard == SIZE_MAX) return nullptr;
    monoArray<void *> *arr = gFindObjects2 ? gFindObjects2(gMergePopupType, false) : (gFindObjects1 ? gFindObjects1(gMergePopupType) : nullptr);
    if (!ptrOK(arr)) return nullptr;
    int count = arr->getCapacity();
    if (count < 0 || count > 32) return nullptr;
    for (int i = 0; i < count; ++i) {
        void *popup = arr->m_Items[i];
        if (!ptrOK(popup)) continue;
        void *view = *reinterpret_cast<void **>((uint8_t *)popup + offPopupOrdersView);
        if (!ptrOK(view)) continue;
        void *board = *reinterpret_cast<void **>((uint8_t *)view + offOrdersViewBoard);
        if (!ptrOK(board)) continue;
        if (offIsInitialized != SIZE_MAX && !*reinterpret_cast<bool *>((uint8_t *)board + offIsInitialized)) continue;
        if (offOperationsHandler != SIZE_MAX && !ptrOK(*reinterpret_cast<void **>((uint8_t *)board + offOperationsHandler))) continue;
        gCurrentOrdersBoard = true;
        gProducerFillMode = true;
        return board;
    }
    return nullptr;
}

static void *findBoardController(void) {
    CFTimeInterval now = CACurrentMediaTime();
    if (ptrOK(gBoardController)) return gBoardController;
    if (now < gNextScanAt || !ptrOK(gBoardType)) return nullptr;
    gNextScanAt = now + 0.8;
    monoArray<void *> *arr = gFindObjects2 ? gFindObjects2(gBoardType, false) : (gFindObjects1 ? gFindObjects1(gBoardType) : nullptr);
    if (!ptrOK(arr) && gFindObjects2) arr = gFindObjects2(gBoardType, true);
    if (!ptrOK(arr)) {
        void *linked = findOrdersBoard();
        if (linked) { gBoardController = linked; gHadActiveBoard = true; }
        return linked;
    }
    int count = arr->getCapacity();
    if (count < 0) count = 0; if (count > 32) count = 32;
    for (int i=0;i<count;i++) {
        void *obj = arr->m_Items[i];
        if (!ptrOK(obj)) continue;
        if (offIsInitialized != SIZE_MAX && !*reinterpret_cast<bool *>((uint8_t*)obj + offIsInitialized)) continue;
        NSString *eventName = @"unknown";
        if (fnBoardEventId) {
            Il2CppString *eventId = (Il2CppString *)fnBoardEventId(obj);
            if (ptrOK(eventId) && eventId->length >= 0 && eventId->length < 256) {
                eventName = [[NSString alloc] initWithCharacters:(const unichar *)&eventId->start_char length:eventId->length];
            }
        }
        gCurrentOrdersBoard = [eventName hasPrefix:@"MergeOrders_"];
        if (gCurrentOrdersBoard) { gProducerFillMode = true; gOrdersLastProgressAt = now; }
        gBoardController = obj;
        gHadActiveBoard = true;
        return obj;
    }
    if (gFindObjects2) {
        monoArray<void *> *all = gFindObjects2(gBoardType, true);
        if (ptrOK(all)) {
            int n = all->getCapacity();
            if (n >= 0 && n <= 32) for (int i = 0; i < n; ++i) {
                void *candidate = all->m_Items[i];
                if (!ptrOK(candidate)) continue;
                if (offIsInitialized != SIZE_MAX && !*reinterpret_cast<bool *>((uint8_t *)candidate + offIsInitialized)) continue;
                gBoardController = candidate;
                gHadActiveBoard = true;
                return candidate;
            }
        }
    }
    void *linked = findOrdersBoard();
    if (linked) { gBoardController = linked; gHadActiveBoard = true; }
    return linked;
}

static void *getHintHandler(void *board) {
    if (!ptrOK(board) || offOperationsHandler == SIZE_MAX) return nullptr;
    void *ops = *reinterpret_cast<void **>((uint8_t*)board + offOperationsHandler);
    if (!ptrOK(ops)) return nullptr;
    void *hintController = *reinterpret_cast<void **>((uint8_t*)ops + offOpsHintController);
    if (!ptrOK(hintController)) return nullptr;
    void *handler = *reinterpret_cast<void **>((uint8_t*)hintController + offHintControllerHandler);
    return ptrOK(handler) ? handler : nullptr;
}

static int countBoardItems(void *board);
static int countBoardSlots(void *board);
static bool boardLooksFull(void *board);

static void *tileAt(void *board, V2I wanted) {
    if (!ptrOK(board) || offTiles == SIZE_MAX) return nullptr;
    auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t*)board + offTiles);
    if (!ptrOK(tiles)) return nullptr;
    int cap = tiles->getCapacity(); if (cap < 0 || cap > 512) return nullptr;
    for (int i=0;i<cap;i++) {
        void *tile = tiles->m_Items[i]; if (!ptrOK(tile)) continue;
        V2I p = *reinterpret_cast<V2I *>((uint8_t*)tile + offBoardPosition);
        if (p.x == wanted.x && p.y == wanted.y) return tile;
    }
    if (fnGetRows && fnGetColumns) {
        int rows=fnGetRows(board), cols=fnGetColumns(board);
        int idx=wanted.y*cols+wanted.x;
        if (rows>0 && cols>0 && idx>=0 && idx<cap && ptrOK(tiles->m_Items[idx])) return tiles->m_Items[idx];
    }
    return nullptr;
}

static int currentBetSafe(void *board);
static bool ordersMergePair(void *board) {
    static CFTimeInterval lastReadyScanLog = 0;
    if (!gCurrentOrdersBoard || !fnPerformMerge || offTiles == SIZE_MAX ||
        offItemChain == SIZE_MAX || offItemIndex == SIZE_MAX ||
        offItemDraggable == SIZE_MAX || offCurrentItem == SIZE_MAX ||
        offBoardPosition == SIZE_MAX || offOperationsHandler == SIZE_MAX) return false;
    auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t *)board + offTiles);
    if (!ptrOK(tiles)) return false;
    int cap = tiles->getCapacity();
    if (cap < 1 || cap > 512) return false;
    void *ops = *reinterpret_cast<void **>((uint8_t *)board + offOperationsHandler);
    if (!ptrOK(ops)) return false;
    int matchedPairs = 0;
    int scannedItems = 0;
    int nonPositiveChains = 0;
    for (int i = 0; i < cap; ++i) {
            void *a = tiles->m_Items[i];
            if (!ptrOK(a)) continue;
            void *itemA = *reinterpret_cast<void **>((uint8_t *)a + offCurrentItem);
            if (!ptrOK(itemA)) continue;
            bool movableA = *reinterpret_cast<bool *>((uint8_t *)itemA + offItemDraggable);
            if (!movableA) continue;
            int chain = *reinterpret_cast<int32_t *>((uint8_t *)itemA + offItemChain);
            int level = *reinterpret_cast<int32_t *>((uint8_t *)itemA + offItemIndex);
            scannedItems++;
            if (chain <= 0) nonPositiveChains++;
            if (level < 0) continue;

            for (int j = i + 1; j < cap; ++j) {
                void *b = tiles->m_Items[j];
                if (!ptrOK(b)) continue;
                void *itemB = *reinterpret_cast<void **>((uint8_t *)b + offCurrentItem);
                if (!ptrOK(itemB)) continue;
                bool movableB = *reinterpret_cast<bool *>((uint8_t *)itemB + offItemDraggable);
                if (!movableB) continue;
                if (*reinterpret_cast<int32_t *>((uint8_t *)itemB + offItemChain) != chain ||
                    *reinterpret_cast<int32_t *>((uint8_t *)itemB + offItemIndex) != level) continue;
                matchedPairs++;
                V2I sp = *reinterpret_cast<V2I *>((uint8_t *)a + offBoardPosition);
                V2I dp = *reinterpret_cast<V2I *>((uint8_t *)b + offBoardPosition);
                if (sp.x == gLastMergeSrcX && sp.y == gLastMergeSrcY &&
                    dp.x == gLastMergeDstX && dp.y == gLastMergeDstY &&
                    itemA == gLastMergeSrcItem && itemB == gLastMergeDstItem && gStaleHintCount >= 2) continue;
                gLastMergeSrcX = sp.x; gLastMergeSrcY = sp.y;
                gLastMergeDstX = dp.x; gLastMergeDstY = dp.y;
                gLastMergeSrcItem = itemA; gLastMergeDstItem = itemB;
                gPendingAction = PENDING_MERGE;
                gPendingDeadline = CACurrentMediaTime() + 0.45;
                gPendingSrc = sp; gPendingDst = dp;
                gPendingSrcItem = itemA; gPendingDstItem = itemB;
                gPendingItemsBefore = countBoardItems(board);
                mergeEvent([NSString stringWithFormat:@"ORDER_PAIR chain=%d level=%d src=%d,%d dst=%d,%d bet=%d", chain, level, sp.x, sp.y, dp.x, dp.y, currentBetSafe(board)]);
                fnPerformMerge(ops, a, b, itemA, nullptr);
                return true;
            }
        }
    if (gCurrentOrdersBoard && CACurrentMediaTime() - lastReadyScanLog > 4.0) {
        lastReadyScanLog = CACurrentMediaTime();
    }
    return false;
}

static bool mergeOnce(void *board) {
    void *handler = getHintHandler(board);
    if (!ptrOK(handler)) { mergeEvent(@"HINT_HANDLER_MISSING"); return false; }
    void *suggestion = fnGetHintSuggestion(handler);
    if (!ptrOK(suggestion)) { mergeEvent(@"NO_SUGGESTION"); return false; }
    if (fnGetIsObstacleHint && fnGetIsObstacleHint(suggestion)) { mergeEvent(@"OBSTACLE_HINT"); return false; }

    
    if (fnGetIsCollectibleAccumulationHint && fnGetIsCollectibleAccumulationHint(suggestion)) {
        void *collectCell = fnGetSourceCell ? fnGetSourceCell(suggestion) : nullptr;
        if (!ptrOK(collectCell)) return false;
        V2I cp = unpackV2(fnGetCellBoardPosition(collectCell));
        void *collectTile = tileAt(board, cp);
        void *collectItem = ptrOK(collectTile) ? *reinterpret_cast<void **>((uint8_t*)collectTile + offCurrentItem) : nullptr;
        if (!ptrOK(collectItem)) return false;

        CFTimeInterval now = CACurrentMediaTime();
        if (collectItem == gCollectibleIgnoreItem && now < gCollectibleIgnoreUntil) {
            
            
            return false;
        }

        if (fnBaseItemClicked) {
            int generation = gCollectibleTapGeneration.fetch_add(1) + 1;
            gCollectibleIgnoreItem = collectItem;
            gCollectibleIgnoreUntil = now + 1.25;
            gCollectibleTapInFlightUntil = now + 0.38;
            @try { fnBaseItemClicked(collectItem, nullptr); }
            @catch (__unused NSException *e) { return false; }

            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.13 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (!gEnabled.load() || gCollectibleTapGeneration.load() != generation) return;
                void *b = gBoardController;
                if (!ptrOK(b)) return;
                void *t = tileAt(b, cp);
                void *itemNow = ptrOK(t) ? *reinterpret_cast<void **>((uint8_t*)t + offCurrentItem) : nullptr;
                if (itemNow != collectItem || !ptrOK(itemNow)) return;
                @try { fnBaseItemClicked(itemNow, nullptr); }
                @catch (__unused NSException *e) {}
            });
            gPendingAction = PENDING_NONE;
            gProducerFillMode = false;
            gTerminalNoProgressCycles = 0;
            gEventCompatRetries = 0;
            gStaleHintCount = 0;
            gStaleHintDetected = false;
            gNextActionAt = now + 0.42;
            return true;
        }
        return false;
    }

    
    if (gCollectibleIgnoreItem && CACurrentMediaTime() >= gCollectibleIgnoreUntil) {
        gCollectibleIgnoreItem = nullptr;
        gCollectibleIgnoreUntil = 0;
    }

    void *srcCell = fnGetSourceCell(suggestion), *dstCell = fnGetTargetCell(suggestion);
    if (!ptrOK(srcCell) || !ptrOK(dstCell)) { return false; }
    V2I sp=unpackV2(fnGetCellBoardPosition(srcCell)), dp=unpackV2(fnGetCellBoardPosition(dstCell));
    void *srcTile=tileAt(board, sp), *dstTile=tileAt(board, dp);
    if (!ptrOK(srcTile) || !ptrOK(dstTile)) { return false; }
    void *item=*reinterpret_cast<void **>((uint8_t*)srcTile + offCurrentItem);
    void *dstItem=*reinterpret_cast<void **>((uint8_t*)dstTile + offCurrentItem);
    if (!ptrOK(item)) { return false; }

    bool samePair = (sp.x == gLastMergeSrcX && sp.y == gLastMergeSrcY &&
                     dp.x == gLastMergeDstX && dp.y == gLastMergeDstY);
    bool unchanged = samePair && item == gLastMergeSrcItem && dstItem == gLastMergeDstItem;
    if (unchanged) {
        gStaleHintCount++;
        if (gStaleHintCount >= 2) {
            gStaleHintDetected = true;
            return false;
        }
    } else {
        gStaleHintCount = 0;
    }

    gLastMergeSrcX = sp.x; gLastMergeSrcY = sp.y;
    gLastMergeDstX = dp.x; gLastMergeDstY = dp.y;
    gLastMergeSrcItem = item; gLastMergeDstItem = dstItem;

    void *ops=*reinterpret_cast<void **>((uint8_t*)board + offOperationsHandler);
    if (fnPerformMerge && ptrOK(ops)) {
        gPendingAction = PENDING_MERGE;
        gPendingDeadline = CACurrentMediaTime() + 0.35;
        gPendingSrc = sp; gPendingDst = dp;
        gPendingSrcItem = item; gPendingDstItem = dstItem;
        gPendingItemsBefore = countBoardItems(board);
        fnPerformMerge(ops, srcTile, dstTile, item, nullptr);
        return true;
    }
    if (fnHandleDrop) {
        gPendingAction = PENDING_MERGE;
        gPendingDeadline = CACurrentMediaTime() + 0.35;
        gPendingSrc = sp; gPendingDst = dp;
        gPendingSrcItem = item; gPendingDstItem = dstItem;
        gPendingItemsBefore = countBoardItems(board);
        fnHandleDrop(dstTile, item);
        return true;
    }
    return false;
}

static void *findProducerItem(void) {
    if (ptrOK(gProducerItem)) return gProducerItem;
    if (!ptrOK(gProducerItemType) || (!gFindObjects2 && !gFindObjects1)) return nullptr;
    monoArray<void *> *arr = gFindObjects2 ? gFindObjects2(gProducerItemType, false) : gFindObjects1(gProducerItemType);
    if (!ptrOK(arr)) return nullptr;
    int count = arr->getCapacity();
    if (count < 0) count = 0; if (count > 32) count = 32;
    for (int i=0;i<count;i++) {
        void *obj = arr->m_Items[i];
        if (!ptrOK(obj)) continue;
        if (offProducerInitialized != SIZE_MAX) {
            bool initialized = *reinterpret_cast<bool *>((uint8_t*)obj + offProducerInitialized);
            if (!initialized) continue;
        }
        if (offProducerBehavior != SIZE_MAX && fnProducerBehaviorIsEnabled) {
            void *behavior = *reinterpret_cast<void **>((uint8_t*)obj + offProducerBehavior);
            if (!ptrOK(behavior)) continue;
            bool enabled = fnProducerBehaviorIsEnabled(behavior);
            if (!enabled) continue;
        }
        gProducerItem = obj;
        return obj;
    }
    return nullptr;
}


static void *findActiveObject(void *typeObj, int maxCount) {
    if (!ptrOK(typeObj) || (!gFindObjects2 && !gFindObjects1)) return nullptr;
    monoArray<void *> *arr = gFindObjects2 ? gFindObjects2(typeObj, false) : gFindObjects1(typeObj);
    if (!ptrOK(arr)) return nullptr;
    int count = arr->getCapacity();
    if (count < 0) return nullptr;
    if (count > maxCount) count = maxCount;
    for (int i = 0; i < count; i++) {
        void *obj = arr->m_Items[i];
        if (ptrOK(obj)) return obj;
    }
    return nullptr;
}

static void *getBetDataModel(void *board) {
    if (!ptrOK(board) || !fnBoardGetBetDataModel) return nullptr;
    void *model = fnBoardGetBetDataModel(board);
    if (ptrOK(model)) {
        gBetDataModel = model;
        return model;
    }
    gBetDataModel = nullptr;
    return nullptr;
}

static NSString *AutoMergeStateChangedNotification(void) {
    return OX_NS("om_auto_merge_state_changed");
}

static void postAutoMergeStateChanged(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:AutoMergeStateChangedNotification() object:nil];
    });
}

static void scheduleRewardCollectSweepStep(int generation, int attempt) {
    if (attempt >= 50) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.40 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (gRewardSweepGeneration.load() != generation) return;
        @try { AutoMergeTryCollectPendingReward(); }
        @catch (__unused NSException *e) {}
        scheduleRewardCollectSweepStep(generation, attempt + 1);
    });
}

static void scheduleRewardCollectSweep(void) {
    int generation = gRewardSweepGeneration.fetch_add(1) + 1;
    scheduleRewardCollectSweepStep(generation, 0);
}

static void scheduleRewardRefreshPulse(void) {
    if (gRewardRefreshPending) return;
    gRewardRefreshPending = true;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.65 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationWillEnterForegroundNotification object:UIApplication.sharedApplication];
        [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationDidBecomeActiveNotification object:UIApplication.sharedApplication];
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.80 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationDidBecomeActiveNotification object:UIApplication.sharedApplication];
        gRewardRefreshPending = false;
    });
}

static int countBoardItems(void *board) {
    if (!ptrOK(board) || offTiles == SIZE_MAX || offCurrentItem == SIZE_MAX) return -1;
    auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t*)board + offTiles);
    if (!ptrOK(tiles)) return -1;
    int cap = tiles->getCapacity();
    if (cap < 0 || cap > 512) return -1;
    int count = 0;
    for (int i = 0; i < cap; i++) {
        void *tile = tiles->m_Items[i];
        if (!ptrOK(tile)) continue;
        void *item = *reinterpret_cast<void **>((uint8_t*)tile + offCurrentItem);
        if (ptrOK(item)) count++;
    }
    return count;
}

static int countBoardSlots(void *board) {
    if (!ptrOK(board) || offTiles == SIZE_MAX) return -1;
    auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t*)board + offTiles);
    if (!ptrOK(tiles)) return -1;
    int cap = tiles->getCapacity();
    if (cap < 0 || cap > 512) return -1;
    int slots = 0;
    for (int i = 0; i < cap; i++) {
        if (ptrOK(tiles->m_Items[i])) slots++;
    }
    return slots;
}

static bool boardLooksFull(void *board) {
    if (!ptrOK(board)) return false;

    
    if (fnIsBoardFull && offOperationsHandler != SIZE_MAX) {
        void *ops = *reinterpret_cast<void **>((uint8_t*)board + offOperationsHandler);
        if (ptrOK(ops)) {
            @try { return fnIsBoardFull(ops, false, nullptr); }
            @catch (__unused NSException *e) {}
        }
    }

    
    int items = countBoardItems(board);
    int slots = countBoardSlots(board);
    return items >= 0 && slots > 0 && items >= slots;
}

static int currentBetSafe(void *board) {
    if (!ptrOK(board) || !fnGetSelectedBet) return 1;
    void *model = getBetDataModel(board);
    if (!ptrOK(model)) return 1;
    int value = fnGetSelectedBet(model);
    return (value == 2 || value == 4) ? value : 1;
}

static int ordersEnergyState(void *board) {
    if (!gCurrentOrdersBoard || offHintEnergyManager == SIZE_MAX || !fnHasEnoughEnergy ||
        !fnCalculateEnergyCost || offOperationsHandler == SIZE_MAX || offOpsHintController == SIZE_MAX) return -1;
    void *ops = *reinterpret_cast<void **>((uint8_t *)board + offOperationsHandler);
    if (!ptrOK(ops)) return -1;
    void *hint = *reinterpret_cast<void **>((uint8_t *)ops + offOpsHintController);
    if (!ptrOK(hint)) return -1;
    void *manager = *reinterpret_cast<void **>((uint8_t *)hint + offHintEnergyManager);
    if (!ptrOK(manager)) return -1;
    int cost = fnCalculateEnergyCost(manager, 1);
    if (cost <= 0 || cost > 10000) return -1;
    return fnHasEnoughEnergy(manager, cost) ? 1 : 0;
}

static bool producerOnce(void *board) {
    if (!ptrOK(board)) return false;
    if (gCurrentOrdersBoard && ordersEnergyState(board) == 0) return false;

    
    if (boardLooksFull(board)) {
        gBoardFullMergeRecovery = true;
        gBoardFullMergeScans = 0;
        return false;
    }

    if (gCurrentOrdersBoard && fnProducerItemClicked && fnObjectGetClass &&
        fnClassAssignable && ptrOK(gProducerClass) && offTiles != SIZE_MAX && offCurrentItem != SIZE_MAX) {
        auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t *)board + offTiles);
        if (ptrOK(tiles)) {
            int cap = tiles->getCapacity();
            if (cap >= 0 && cap <= 512) for (int i = 0; i < cap; ++i) {
                void *tile = tiles->m_Items[i];
                if (!ptrOK(tile)) continue;
                void *item = *reinterpret_cast<void **>((uint8_t *)tile + offCurrentItem);
                if (!ptrOK(item)) continue;
                void *klass = fnObjectGetClass(item);
                if (!ptrOK(klass) || !fnClassAssignable(gProducerClass, klass)) continue;
                bool initialized = offProducerInitialized == SIZE_MAX ||
                    *reinterpret_cast<bool *>((uint8_t *)item + offProducerInitialized);
                void *behavior = offProducerBehavior == SIZE_MAX ? nullptr :
                    *reinterpret_cast<void **>((uint8_t *)item + offProducerBehavior);
                int enabled = ptrOK(behavior) && fnProducerBehaviorIsEnabled ?
                    (fnProducerBehaviorIsEnabled(behavior) ? 1 : 0) : -1;
                gPendingAction = PENDING_PRODUCER;
                gPendingDeadline = CACurrentMediaTime() + 0.70;
                gPendingItemsBefore = countBoardItems(board);
                { fnProducerItemClicked(item, nullptr); }
                return true;
            }
        }
    }

    if (gCurrentOrdersBoard && fnTryProducer && offTiles != SIZE_MAX) {
        auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t *)board + offTiles);
        if (ptrOK(tiles)) {
            int cap = tiles->getCapacity();
            if (cap >= 0 && cap <= 512) {
                for (int pass = 0; pass < 2; ++pass) for (int i = 0; i < cap; ++i) {
                    void *tile = tiles->m_Items[i];
                    if (!ptrOK(tile)) continue;
                    void *item = offCurrentItem != SIZE_MAX ? *reinterpret_cast<void **>((uint8_t *)tile + offCurrentItem) : nullptr;
                    bool producer = false;
                    if (ptrOK(item) && fnObjectGetClass && fnClassAssignable && ptrOK(gProducerClass)) {
                        void *klass = fnObjectGetClass(item);
                        producer = ptrOK(klass) && fnClassAssignable(gProducerClass, klass);
                    }
                    if (pass == 0 && !producer) continue;
                    if (pass == 1 && producer) continue;
                    gPendingAction = PENDING_PRODUCER;
                    gPendingDeadline = CACurrentMediaTime() + 0.55;
                    gPendingItemsBefore = countBoardItems(board);
                    if (fnTryProducer(tile)) {
                        return true;
                    }
                    gPendingAction = PENDING_NONE;
                }
            }
        }
    }

    if (gCurrentOrdersBoard && fnTryClickSpawner && offTiles != SIZE_MAX) {
        auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t *)board + offTiles);
        if (ptrOK(tiles)) {
            int cap = tiles->getCapacity();
            if (cap >= 0 && cap <= 512) for (int i = 0; i < cap; ++i) {
                void *tile = tiles->m_Items[i];
                if (!ptrOK(tile)) continue;
                gPendingAction = PENDING_PRODUCER;
                gPendingDeadline = CACurrentMediaTime() + 0.70;
                gPendingItemsBefore = countBoardItems(board);
                if (fnTryClickSpawner(tile)) {
                    return true;
                }
                gPendingAction = PENDING_NONE;
            }
        }
    }

    if (gCurrentOrdersBoard && fnBaseItemClicked && offItemType != SIZE_MAX &&
        offCurrentItem != SIZE_MAX && offTiles != SIZE_MAX) {
        auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t *)board + offTiles);
        if (ptrOK(tiles)) {
            int cap = tiles->getCapacity();
            if (cap >= 0 && cap <= 512) {
                for (int i = 0; i < cap; ++i) {
                    void *tile = tiles->m_Items[i];
                    if (!ptrOK(tile)) continue;
                    void *item = *reinterpret_cast<void **>((uint8_t *)tile + offCurrentItem);
                    if (!ptrOK(item)) continue;
                    int type = *reinterpret_cast<int32_t *>((uint8_t *)item + offItemType);
                    if (type != 1 && type != 2) continue;
                    gPendingAction = PENDING_PRODUCER;
                    gPendingDeadline = CACurrentMediaTime() + 0.70;
                    gPendingItemsBefore = countBoardItems(board);
                    void *klass = fnObjectGetClass ? fnObjectGetClass(item) : nullptr;
                    bool specialized = ptrOK(klass) && ptrOK(gProducerClass) && fnClassAssignable && fnClassAssignable(gProducerClass, klass);
                    if (specialized && fnProducerItemClicked) { fnProducerItemClicked(item, nullptr); }
                    else { fnBaseItemClicked(item, nullptr); }
                    return true;
                }
            }
        }
    }

    if (gCurrentOrdersBoard && fnProducerItemClicked && fnObjectGetClass &&
        fnClassAssignable && ptrOK(gProducerClass) && offTiles != SIZE_MAX) {
        auto *tiles = *reinterpret_cast<monoArray<void *> **>((uint8_t *)board + offTiles);
        if (ptrOK(tiles)) {
            int cap = tiles->getCapacity();
            if (cap >= 0 && cap <= 512) for (int i = 0; i < cap; ++i) {
                void *tile = tiles->m_Items[i];
                if (!ptrOK(tile)) continue;
                void *item = *reinterpret_cast<void **>((uint8_t *)tile + offCurrentItem);
                if (!ptrOK(item)) continue;
                void *klass = fnObjectGetClass(item);
                if (!ptrOK(klass) || !fnClassAssignable(gProducerClass, klass)) continue;
                gPendingAction = PENDING_PRODUCER;
                gPendingDeadline = CACurrentMediaTime() + 0.70;
                gPendingItemsBefore = countBoardItems(board);
                { fnProducerItemClicked(item, nullptr); }
                return true;
            }
        }
    }
    if (fnProducerItemClicked && ptrOK(gProducerItemType)) {
        void *producer = findProducerItem();
        if (ptrOK(producer)) {
            gPendingAction = PENDING_PRODUCER;
            gPendingDeadline = CACurrentMediaTime() + 0.35;
            gPendingItemsBefore = countBoardItems(board);
            { fnProducerItemClicked(producer, nullptr); }
            return true;
        }
    }

    if (fnTryProducer) {
        auto *tiles=*reinterpret_cast<monoArray<void *> **>((uint8_t*)board + offTiles);
        if (ptrOK(tiles)) {
            int cap=tiles->getCapacity(); if (cap>=0 && cap<=512) {
                for (int i=0;i<cap;i++) {
                    void *tile=tiles->m_Items[i]; if (!ptrOK(tile)) continue;
                    gPendingAction = PENDING_PRODUCER;
                    gPendingDeadline = CACurrentMediaTime() + 0.35;
                    gPendingItemsBefore = countBoardItems(board);
                    if (fnTryProducer(tile)) return true;
                    gPendingAction = PENDING_NONE;
                }
            }
        }
    }
    if (gCurrentOrdersBoard && !boardLooksFull(board) && ordersEnergyState(board) != 0) {
        CFTimeInterval now = CACurrentMediaTime();
        gOrdersProducerMisses++;
        if (gOrdersProducerMisses >= 2 && now - gOrdersProducerRecoveryAt >= 2.0) {
            gOrdersProducerRecoveryAt = now;
            gOrdersProducerMisses = 0;
            gProducerItem = nullptr;
            if (fnBoardDataUpdated) fnBoardDataUpdated(board);
        }
    }
    return false;
}

void AutoMergeModuleSetEnabled(bool enabled);
static void disableAutoMerge(bool runRewardSweep);

static void runStep(void) {
    void *board = findBoardController();
    if (!ptrOK(board)) {
        static CFTimeInterval lastMissing = 0;
        if (CACurrentMediaTime() - lastMissing > 5.0) { lastMissing = CACurrentMediaTime(); mergeEvent(@"BOARD_UNAVAILABLE"); }
        if (gHadActiveBoard) {
            CFTimeInterval now = CACurrentMediaTime();
            
            
            if (gEventCompatBoardGraceUntil <= 0)
                gEventCompatBoardGraceUntil = now + 1.50;
            if (now < gEventCompatBoardGraceUntil) {
                gBoardController = nullptr;
                gProducerItem = nullptr;
                gNextActionAt = now + 0.12;
                return;
            }
            disableAutoMerge(false);
        }
        return;
    }
    gEventCompatBoardGraceUntil = 0;

    
    if (CACurrentMediaTime() < gCollectibleTapInFlightUntil) {
        gNextActionAt = gCollectibleTapInFlightUntil + 0.02;
        return;
    }

    if (gPendingAction != PENDING_NONE) {
        CFTimeInterval now = CACurrentMediaTime();
        int itemsNow = countBoardItems(board);
        if (gPendingAction == PENDING_MERGE) {
            void *srcTile = tileAt(board, gPendingSrc);
            void *dstTile = tileAt(board, gPendingDst);
            void *srcNow = ptrOK(srcTile) ? *reinterpret_cast<void **>((uint8_t*)srcTile + offCurrentItem) : nullptr;
            void *dstNow = ptrOK(dstTile) ? *reinterpret_cast<void **>((uint8_t*)dstTile + offCurrentItem) : nullptr;
            bool changed = srcNow != gPendingSrcItem || dstNow != gPendingDstItem ||
                           (gPendingItemsBefore >= 0 && itemsNow != gPendingItemsBefore);
            if (changed) {
                if (gCurrentOrdersBoard) gOrdersLastProgressAt = now;
                gPendingAction = PENDING_NONE;
                gStaleHintCount = 0; gStaleHintDetected = false;
                gNoHintCount = 0; gTerminalNoProgressCycles = 0;
                gEventCompatRetries = 0;
                gNextActionAt = now + 0.080;
                return;
            }
            if (now < gPendingDeadline) { gNextActionAt = now + 0.05; return; }
            gPendingAction = PENDING_NONE;
            gStaleHintDetected = true;
            gProducerFillMode = true;
            gProducerFillLastItems = -1; gProducerFillClicks = 0;
            gNextActionAt = now + 0.03;
            return;
        }
        if (gPendingAction == PENDING_PRODUCER) {
            if (gPendingItemsBefore >= 0 && itemsNow > gPendingItemsBefore) {
                gProducerFillClicks++;
                if (gCurrentOrdersBoard) gOrdersLastProgressAt = now;
                gPendingAction = PENDING_NONE;
                gProducerFillLastItems = itemsNow;
                gTerminalNoProgressCycles = 0;
                gEventCompatRetries = 0;
                if (currentBetSafe(board) <= 1 && gProducerFillClicks >= 2) {
                    gProducerFillMode = false; gProducerFillClicks = 0; gProducerFillLastItems = -1;
                    gNextActionAt = now + 0.055;
                } else {
                    gNextActionAt = now + 0.040;
                }
                return;
            }
            if (now < gPendingDeadline) { gNextActionAt = now + 0.05; return; }
            gPendingAction = PENDING_NONE;
            
            
            if (boardLooksFull(board)) {
                gBoardFullMergeRecovery = true;
                gBoardFullMergeScans = 0;
                gTerminalNoProgressCycles = 0;
                gEventCompatRetries = 0;
                gProducerFillMode = false;
                gProducerFillLastItems = -1;
                gProducerFillStall = 0;
                gProducerFillClicks = 0;
                gNoHintCount = 0;
                gStaleHintCount = 0;
                gStaleHintDetected = false;
                gLastMergeSrcX=INT32_MIN; gLastMergeSrcY=INT32_MIN;
                gLastMergeDstX=INT32_MIN; gLastMergeDstY=INT32_MIN;
                gLastMergeSrcItem=nullptr; gLastMergeDstItem=nullptr;
                if (fnBoardDataUpdated) fnBoardDataUpdated(board);
                gNextActionAt = now + 0.10;
                return;
            }
            gTerminalNoProgressCycles = 1;
            gProducerFillMode = false;
            gProducerFillLastItems = -1;
            gProducerFillStall = 0;
            gProducerFillClicks = 0;
            gNoHintCount = 0;
            gNextActionAt = now + 0.025;
            return;
        }
    }

    if (gCurrentOrdersBoard && claimReadyOrder(board)) {
        gOrdersLastProgressAt = CACurrentMediaTime();
        gNextActionAt = CACurrentMediaTime() + 0.15;
        return;
    }


    if (gCurrentOrdersBoard && ordersMergePair(board)) {
        mergeEvent(@"ORDER_MERGE_REQUESTED");
        gNoHintCount = 0;
        gTerminalNoProgressCycles = 0;
        gEventCompatRetries = 0;
        gNextActionAt = CACurrentMediaTime() + 0.10;
        return;
    }

    

    if (boardLooksFull(board)) {
        gBoardFullMergeRecovery = true;
        gProducerFillMode = false;
        gProducerFillLastItems = -1;
        gProducerFillStall = 0;
        gProducerFillClicks = 0;
        gTerminalNoProgressCycles = 0;
        gEventCompatRetries = 0;
    } else if (gBoardFullMergeRecovery) {
        
        gBoardFullMergeRecovery = false;
        gBoardFullMergeScans = 0;
    }

    if (gProducerFillMode) {
        int itemsNow = countBoardItems(board);
        int currentBet = currentBetSafe(board);
        if (currentBet <= 1 && gProducerFillClicks >= 2) {
            gProducerFillMode = false;
            gProducerFillLastItems = -1;
            gProducerFillStall = 0;
            gProducerFillClicks = 0;
            gNoHintCount = 0;
            gNextActionAt = CACurrentMediaTime() + 0.055;
            return;
        }
        gProducerFillLastItems = itemsNow;
            if (producerOnce(board)) {
            gNextActionAt = CACurrentMediaTime() + 0.05;
            return;
        }
        gTerminalNoProgressCycles = 1;
        gProducerFillMode = false;
        gProducerFillLastItems = -1;
        gProducerFillStall = 0;
        gProducerFillClicks = 0;
        gNoHintCount = 0;
        gNextActionAt = CACurrentMediaTime() + 0.025;
        return;
    }

    if (gBoardFullMergeRecovery) {
        
        
        gStaleHintCount = 0;
        gStaleHintDetected = false;
        gLastMergeSrcX=INT32_MIN; gLastMergeSrcY=INT32_MIN;
        gLastMergeDstX=INT32_MIN; gLastMergeDstY=INT32_MIN;
        gLastMergeSrcItem=nullptr; gLastMergeDstItem=nullptr;
    }

    if (mergeOnce(board)) {
        mergeEvent(@"HINT_ACTION_REQUESTED");
        gNoHintCount = 0;
        gTerminalNoProgressCycles = 0;
        gEventCompatRetries = 0;
        gBoardFullMergeScans = 0;
        gNextActionAt = CACurrentMediaTime() + 0.080;
        return;
    }

    if (gCurrentOrdersBoard && ordersEnergyState(board) == 0) {
        disableAutoMerge(false);
        return;
    }

    if (gCurrentOrdersBoard && boardLooksFull(board)) {
        disableAutoMerge(false);
        return;
    }

    if (gBoardFullMergeRecovery && boardLooksFull(board)) {
        
        
        gBoardFullMergeScans++;
        gTerminalNoProgressCycles = 0;
        gEventCompatRetries = 0;
        gProducerFillMode = false;
        if ((gBoardFullMergeScans % 4) == 0 && fnBoardDataUpdated) fnBoardDataUpdated(board);
        gNextActionAt = CACurrentMediaTime() + 0.12;
        return;
    }

    if (gTerminalNoProgressCycles > 0) {
        
        
        if (gEventCompatRetries < 6) {
            gEventCompatRetries++;
            gTerminalNoProgressCycles = 0;
            gStaleHintDetected = false;
            gProducerFillMode = true;
            gProducerFillLastItems = -1;
            gProducerFillStall = 0;
            gProducerFillClicks = 0;
            gNoHintCount = 0;
            gProducerItem = nullptr;
            gNextActionAt = CACurrentMediaTime() + 0.18;
            return;
        }
        if (gCurrentOrdersBoard) {
            disableAutoMerge(false);
            return;
        }
        gEventCompatRetries = 0;
        disableAutoMerge(false);
        return;
    }

    if (gStaleHintDetected) gStaleHintDetected = false;
    gProducerFillMode = true;
    gProducerFillLastItems = -1;
    gProducerFillStall = 0;
    gProducerFillClicks = 0;
    gNoHintCount = 0;
    gNextActionAt = CACurrentMediaTime() + 0.03;
}

void AutoMergeModuleInstall(void) {}

static void disableAutoMerge(bool runRewardSweep) {
    void *boardBeforeDisable = gBoardController;
    bool wasEnabled = gEnabled.exchange(false);
    gProducerItem=nullptr; gBetDataModel=nullptr; gNoHintCount=0; gOrderClaimWaitUntil=0; gLastClaimedOrderId=nil; gLastClaimAttemptAt=0; gClaimConfirmationPending=false;
    gProducerFillMode=false; gProducerFillLastItems=-1; gProducerFillStall=0; gProducerFillClicks=0;
    gTerminalNoProgressCycles=0; gEventCompatRetries=0; gEventCompatBoardGraceUntil=0;
    gBoardFullMergeRecovery=false; gBoardFullMergeScans=0;
    gCollectibleIgnoreItem=nullptr; gCollectibleIgnoreUntil=0; gCollectibleTapInFlightUntil=0; gCollectibleTapGeneration.fetch_add(1);
    gLastMergeSrcX=INT32_MIN; gLastMergeSrcY=INT32_MIN; gLastMergeDstX=INT32_MIN; gLastMergeDstY=INT32_MIN;
    gLastMergeSrcItem=nullptr; gLastMergeDstItem=nullptr; gStaleHintCount=0; gStaleHintDetected=false;
    gPendingAction=PENDING_NONE; gPendingDeadline=0; gPendingItemsBefore=-1;
    gPendingSrc={INT32_MIN,INT32_MIN}; gPendingDst={INT32_MIN,INT32_MIN};
    gPendingSrcItem=nullptr; gPendingDstItem=nullptr;
    gNextActionAt=CACurrentMediaTime()+0.5; gNextScanAt=0;
    if (wasEnabled) postAutoMergeStateChanged();
    gStepScheduled.store(false);
    if (runRewardSweep && ptrOK(boardBeforeDisable) && fnBoardDataUpdated) {
        @try {
            fnBoardDataUpdated(boardBeforeDisable);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.40 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (ptrOK(boardBeforeDisable)) {
                    @try { fnBoardDataUpdated(boardBeforeDisable); }
                    @catch (...) {}
                }
            });
        }
        @catch (__unused NSException *e) {}
    }
    if (runRewardSweep) {
        scheduleRewardRefreshPulse();
        scheduleRewardCollectSweep();
    }
    gBoardController=nullptr;
    gHadActiveBoard=false;
}

void AutoMergeModuleSetEnabled(bool enabled) {
    if (!enabled) {
        mergeEvent(@"USER_OFF");
        disableAutoMerge(false);
        return;
    }
    if (!Zx8fAutoMergeAllowed()) {
        disableAutoMerge(false);
        return;
    }
    mergeEvent(@"USER_ON");
    gEnabled.store(true);
    gOrdersProducerRecoveryAt = 0;
    gOrdersLastProgressAt = CACurrentMediaTime();
    gOrdersProducerMisses = 0;
    gProducerItem=nullptr; gBetDataModel=nullptr; gNoHintCount=0; gOrderClaimWaitUntil=0; gLastClaimedOrderId=nil; gLastClaimAttemptAt=0; gClaimConfirmationPending=false;
    gProducerFillMode=false; gProducerFillLastItems=-1; gProducerFillStall=0; gProducerFillClicks=0;
    gTerminalNoProgressCycles=0; gEventCompatRetries=0; gEventCompatBoardGraceUntil=0;
    gBoardFullMergeRecovery=false; gBoardFullMergeScans=0;
    gCollectibleIgnoreItem=nullptr; gCollectibleIgnoreUntil=0; gCollectibleTapInFlightUntil=0; gCollectibleTapGeneration.fetch_add(1);
    gLastMergeSrcX=INT32_MIN; gLastMergeSrcY=INT32_MIN; gLastMergeDstX=INT32_MIN; gLastMergeDstY=INT32_MIN;
    gLastMergeSrcItem=nullptr; gLastMergeDstItem=nullptr; gStaleHintCount=0; gStaleHintDetected=false;
    gHadActiveBoard=false;
    gNextActionAt=CACurrentMediaTime()+0.5; gNextScanAt=0;
    postAutoMergeStateChanged();
    gBoardController=nullptr;
    if (!gRuntimeReady.load() && !gPrepareStarted.exchange(true)) {
        dispatch_async(dispatch_get_main_queue(), ^{ prepareRetry(0); });
    }
}

void AutoMergeModuleToggle(void) { AutoMergeModuleSetEnabled(!AutoMergeModuleIsEnabled()); }
bool AutoMergeModuleIsEnabled(void) { return gEnabled.load() && Zx8fAutoMergeAllowed(); }

void AutoMergeModuleTick(void) {
    if (!Zx8fAutoMergeAllowed()) {
        if (gEnabled.load()) disableAutoMerge(false);
        return;
    }
    if (!gEnabled.load() || !gRuntimeReady.load()) return;
    if (CACurrentMediaTime() < gNextActionAt) return;
    bool expected=false;
    if (!gStepScheduled.compare_exchange_strong(expected,true)) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        @try { runStep(); }
        @catch (NSException *e) { disableAutoMerge(false); }
        gStepScheduled.store(false);
    });
}

__attribute__((constructor)) static void AutoMergeBootstrap(void) {
    gEnabled.store(false);
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:OX_NS("om_auto_merge")];
    [[NSUserDefaults standardUserDefaults] synchronize];
    AutoMergeModuleInstall();
}

}
