#import "Qr65c.h"
#import "Qr65a.h"
#import "Qr65b.h"
#import "Qr65d.h"
#import "Qr66e.h"
#import "Qr66f.h"
#import "Qr67c.h"
#import "Qr67b.h"
#import "Qr70a.h"
#import "zx8f1a_gate.h"
#import "zx8f1a_pro.h"
#import "OngnongState.h"
#import "OngnongOxorany.h"
#import <Foundation/Foundation.h>

static NSString *q65c0(NSString *a) {
    NSString *s = ([a isKindOfClass:[NSString class]] && a.length) ? a : zxv_p05();
    return [zxv_p35() stringByAppendingString:s];
}

static NSString *q65c1(NSString *a) {
    NSString *s = ([a isKindOfClass:[NSString class]] && a.length) ? a : zxv_p05();
    return [zxv_p36() stringByAppendingString:s];
}

static NSMutableDictionary *q65c2(NSString *a) {
    NSUserDefaults *u = [NSUserDefaults standardUserDefaults];
    id s = [u objectForKey:q65c0(a)];
    if (![s isKindOfClass:[NSDictionary class]]) s = [u objectForKey:q65c1(a)];
    return [s isKindOfClass:[NSDictionary class]] ? [(NSDictionary *)s mutableCopy] : [NSMutableDictionary dictionary];
}

static void q65c3(NSString *a, NSMutableDictionary *s) {
    if (![s isKindOfClass:[NSMutableDictionary class]]) return;
    NSUserDefaults *u = [NSUserDefaults standardUserDefaults];
    [u setObject:s forKey:q65c0(a)];
}

static NSMutableDictionary *q65c4(NSMutableDictionary *s) {
    id v = s[zxv_p37()];
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *c = [(NSDictionary *)v mutableCopy];
        s[zxv_p37()] = c;
        return c;
    }
    NSMutableDictionary *b = [NSMutableDictionary dictionary];
    s[zxv_p37()] = b;
    return b;
}

static NSDictionary *q65c5(NSMutableDictionary *b, NSString *i) {
    if (![b isKindOfClass:[NSDictionary class]] || ![i isKindOfClass:[NSString class]] || i.length == 0) return nil;
    id v = b[i];
    return [v isKindOfClass:[NSDictionary class]] ? (NSDictionary *)v : nil;
}

static NSString *q65cb(void) { static NSString *s = nil; if (!s) s = OX_NS("q0"); return s; }
static NSString *q65cc(void) { static NSString *s = nil; if (!s) s = OX_NS("q1"); return s; }
static NSString *q65cd(void) { static NSString *s = nil; if (!s) s = OX_NS("q2"); return s; }

static Q65B0 *q65ce(NSArray<Q65B0 *> *z, NSString *i) {
    if (![i isKindOfClass:[NSString class]] || i.length == 0) return nil;
    for (Q65B0 *x in z) if ([x isKindOfClass:[Q65B0 class]] && [x.x0 isEqualToString:i]) return x;
    return nil;
}

static NSDictionary *q65cf(NSMutableDictionary *s, NSString *i) {
    if (![s isKindOfClass:[NSDictionary class]] || ![i isKindOfClass:[NSString class]] || i.length == 0) return nil;
    NSString *lk = [s[q65cb()] isKindOfClass:[NSString class]] ? s[q65cb()] : @"";
    if (![lk isEqualToString:i]) return nil;
    NSInteger a = q65b6(s[q65cc()], -1);
    NSInteger b = q65b6(s[q65cd()], -1);
    if (a < 0 || b <= 0) return nil;
    return @{zxv_p24():@(a), zxv_p31():@(b)};
}

static NSInteger q65cg(Q65B0 *x, NSDictionary *old) {
    NSInteger a = q65b6(old[zxv_p24()], -1);
    if (a < 0 || ![x isKindOfClass:[Q65B0 class]]) return 0;
    return x.x1 > a ? x.x1 - a : 0;
}

static BOOL q65ca(NSString *a, NSString *b) {
    static NSMutableSet *z = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ z = [NSMutableSet set]; });
    NSString *k = [[q65c0(a) stringByAppendingString:OX_NS(".")] stringByAppendingString:(b ?: [NSString string])];
    if ([z containsObject:k]) return NO;
    if (z.count > 256) [z removeAllObjects];
    [z addObject:k];
    return YES;
}

static void q65c6(NSMutableDictionary *b, Q65B0 *x) {
    if (![b isKindOfClass:[NSMutableDictionary class]] || ![x isKindOfClass:[Q65B0 class]] || x.x0.length == 0) return;
    b[x.x0] = @{zxv_p24(): @(x.x1), zxv_p31(): @(x.x2)};
}

static Q65B0 *q65c7(NSArray<Q65B0 *> *z, NSMutableDictionary *b, NSInteger *o) {
    if (![z isKindOfClass:[NSArray class]]) return nil;
    Q65B0 *p = nil;
    NSInteger h = 0;
    for (Q65B0 *x in z) {
        if (![x isKindOfClass:[Q65B0 class]]) continue;
        NSDictionary *old = q65c5(b, x.x0);
        NSInteger prev = q65b6(old[zxv_p24()], -1);
        NSInteger d = (prev >= 0) ? (x.x1 - prev) : 0;
        if (d > 0 && (!p || d > h || (d == h && x.x1 > p.x1))) {
            p = x;
            h = d;
        }
    }
    if (o) *o = h;
    return p;
}

static NSData *q65ch(NSString *s) {
    if (![s isKindOfClass:[NSString class]] || s.length == 0) return nil;
    return [s dataUsingEncoding:NSUTF8StringEncoding];
}

static BOOL q65ci(NSData *d, NSString *s) {
    NSData *n = q65ch(s);
    if (!d || d.length == 0 || !n || n.length == 0 || n.length > d.length) return NO;
    return [d rangeOfData:n options:0 range:NSMakeRange(0, d.length)].location != NSNotFound;
}

static BOOL q65cj(NSData *d) {
    if (!d || d.length == 0) return NO;
    if (!q65ci(d, zxv_p34()) && !q65ci(d, q67k11())) return NO;
    if (q65ci(d, zxv_p07()) || q65ci(d, zxv_p08()) || q65ci(d, zxv_p09())) return YES;
    if (q65ci(d, q67k42()) || q65ci(d, q67k43()) || q65ci(d, q67k44())) return YES;
    return NO;
}

static NSRange q65ck(NSData *d, NSString *s, NSUInteger st) {
    NSData *n = q65ch(s);
    if (!d || !n || n.length == 0 || st >= d.length || n.length > d.length) return NSMakeRange(NSNotFound, 0);
    return [d rangeOfData:n options:0 range:NSMakeRange(st, d.length - st)];
}

static NSUInteger q65cl(NSData *d, NSArray<NSString *> *ks, NSUInteger *pos, NSString **key) {
    NSUInteger cnt = 0;
    NSUInteger fp = NSNotFound;
    NSString *fk = nil;
    for (NSString *k in ks) {
        NSUInteger st = 0;
        while (st < d.length) {
            NSRange r = q65ck(d, k, st);
            if (r.location == NSNotFound) break;
            cnt++;
            if (fp == NSNotFound || r.location < fp) { fp = r.location; fk = k; }
            if (cnt > 1) break;
            st = r.location + MAX((NSUInteger)1, r.length);
        }
        if (cnt > 1) break;
    }
    if (pos) *pos = fp;
    if (key) *key = fk;
    return cnt;
}

static BOOL q65cm(NSData *d, NSUInteger p) {
    const unsigned char *b = (const unsigned char *)d.bytes;
    NSUInteger n = d.length;
    BOOL str = NO, esc = NO;
    NSInteger dep = 0;
    for (NSUInteger i = 0; i < n && i < p; i++) {
        unsigned char c = b[i];
        if (str) {
            if (esc) esc = NO;
            else if (c == '\\') esc = YES;
            else if (c == '"') str = NO;
            continue;
        }
        if (c == '"') { str = YES; continue; }
        if (c == '{' || c == '[') dep++;
        else if ((c == '}' || c == ']') && dep > 0) dep--;
    }
    return dep > 0 && dep <= 2;
}

static NSUInteger q65cn(const unsigned char *b, NSUInteger n, NSUInteger p) {
    while (p < n && (b[p] == ' ' || b[p] == '\n' || b[p] == '\r' || b[p] == '\t')) p++;
    return p;
}

static NSData *q65co(NSData *d) {
    if (!q65cj(d)) return nil;
    NSUInteger p = NSNotFound;
    NSString *k = nil;
    NSArray *ks = @[zxv_p34(), q67k11()];
    if (q65cl(d, ks, &p, &k) != 1 || p == NSNotFound || !q65cm(d, p)) return nil;
    const unsigned char *b = (const unsigned char *)d.bytes;
    NSUInteger n = d.length;
    NSUInteger i = p + q65ch(k).length;
    i = q65cn(b, n, i);
    if (i < n && b[i] == '"') i++;
    i = q65cn(b, n, i);
    if (i >= n || b[i] != ':') return nil;
    i++;
    i = q65cn(b, n, i);
    if (i >= n || b[i] != '{') return nil;
    NSUInteger start = i;
    BOOL str = NO, esc = NO;
    NSInteger dep = 0;
    NSUInteger end = NSNotFound;
    for (; i < n; i++) {
        unsigned char c = b[i];
        if (str) {
            if (esc) esc = NO;
            else if (c == '\\') esc = YES;
            else if (c == '"') str = NO;
            continue;
        }
        if (c == '"') { str = YES; continue; }
        if (c == '{') dep++;
        else if (c == '}') {
            dep--;
            if (dep == 0) { end = i; break; }
        }
    }
    if (end == NSNotFound || end <= start) return nil;
    NSUInteger len = end - start + 1;
    if (len > 1024 * 1024) return nil;
    NSMutableData *out = [NSMutableData dataWithCapacity:len + 32];
    [out appendData:[OX_NS("{\"accumulationBarsById\":") dataUsingEncoding:NSUTF8StringEncoding]];
    [out appendBytes:b + start length:len];
    [out appendData:[OX_NS("}") dataUsingEncoding:NSUTF8StringEncoding]];
    return out;
}

static BOOL q65cp(id j) {
    NSMutableArray<Q67A0 *> *m = [NSMutableArray array];
    NSMutableArray<Q67A0 *> *s = [NSMutableArray array];
    q67b9(j, m, s, q67k37(), 0);
    if (m.count || s.count) return YES;
    return q65b9(j).count > 0;
}

static NSString *q65hit(void) { static NSString *s = nil; if (!s) s = @"p_last_hit_snap"; return s; }
static NSString *q65pending(void) { return @"p_roll_pending"; }
static NSString *q65pendingSnap(void) { return @"p_roll_pending_snap"; }
static void q65clearPending(NSMutableDictionary *st) {
    [st removeObjectForKey:q65pending()];
    [st removeObjectForKey:q65pendingSnap()];
}


static void q65cu(NSString *u, uint64_t snap, BOOL potionRelevant, BOOL potionHit, NSInteger potionCountAtParse,
                  BOOL tokenRelevant, BOOL tokenHit, NSInteger tokenCountAtParse) {
    if (snap == 0 || !tokenRelevant || tokenHit) return;
    NSArray<NSNumber *> *delays = @[@0.22, @0.70, @1.40];
    [delays enumerateObjectsUsingBlock:^(NSNumber *delayNumber, NSUInteger retryIndex, BOOL *stop) {
        NSTimeInterval delay = delayNumber.doubleValue;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)),
                       dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            if (Ongnong::Zx8fTokenAllowed() && !q67d1(u, snap)) {
                q67d0(u, snap, tokenCountAtParse);
            }
        });
    }];
}

static void q65cr(id j, NSString *u, uint64_t snap) {
    if (!j) return;
    NSInteger potionCountAtParse = Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z2f0c1a9d77];
    NSInteger tokenCountAtParse = Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z87f6d0c11d];
    NSInteger tokenFlags = Ongnong::Zx8fTokenAllowed() ? q67c9(j, u, snap) : 0;
    BOOL tokenRelevant = (tokenFlags & 1) != 0;
    BOOL tokenHit = (tokenFlags & 2) != 0;
    BOOL potionRelevant = NO;
    BOOL potionHit = NO;

    if (Ongnong::Zx8fPotionAllowed()) {
        NSArray<Q65B0 *> *a = q65b9(j);
        potionRelevant = a.count > 0;
        if (a.count > 0) {
            NSString *acc = q65a1(u);
            NSMutableDictionary *st = q65c2(acc);
            NSMutableDictionary *b = q65c4(st);
            NSInteger delta = 0;
            BOOL had = b.count > 0;
            NSString *lk = [st[q65cb()] isKindOfClass:[NSString class]] ? st[q65cb()] : @"";
            Q65B0 *pick = q65ce(a, lk);
            NSDictionary *old = pick ? (q65c5(b, pick.x0) ?: q65cf(st, pick.x0)) : nil;
            if (pick && old) delta = q65cg(pick, old);
            if (!pick || delta <= 0) pick = q65c7(a, b, &delta);
            BOOL first = pick ? q65ca(acc, pick.x0) : NO;
            NSDictionary *pending = [st[q65pending()] isKindOfClass:[NSDictionary class]] ? st[q65pending()] : nil;
            uint64_t pendingSnap = (uint64_t)q65b6(st[q65pendingSnap()], 0);
            BOOL confirmedRoll = NO;
            Q65B0 *rollPick = nil;
            uint64_t liveSpin = Ongnong::Z9c4a7f611b();
            BOOL hasGap = Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z5d92a7e4c1] > 0;
            if (pending.count && pendingSnap > 0) {
                NSString *pendingId = [pending[@"id"] isKindOfClass:[NSString class]] ? pending[@"id"] : @"";
                Q65B0 *candidate = q65ce(a, pendingId);
                BOOL advanced = snap > pendingSnap || liveSpin > pendingSnap;
                BOOL unused = (uint64_t)q65b6(st[q65hit()], 0) != pendingSnap;
                NSInteger candidateValue = candidate ? candidate.x1 : -1;
                NSInteger floorValue = q65b6(pending[@"value"], -1);
                if (candidate && advanced && unused && hasGap && candidateValue > floorValue && candidate.x2 > q65b6(pending[@"max"], candidate.x2) && !pick) {
                    confirmedRoll = YES;
                    rollPick = candidate;
                    Ongnong::ZPotionTrace([NSString stringWithFormat:@"POTION_ROLL_CONFIRM snap=%llu from=%llu kind=%@ floor=%ld current=%ld live=%llu", (unsigned long long)snap, (unsigned long long)pendingSnap, pendingId, (long)floorValue, (long)candidateValue, (unsigned long long)liveSpin]);
                } else {
                    Ongnong::ZPotionTrace([NSString stringWithFormat:@"POTION_ROLL_CHECK snap=%llu from=%llu present=%d advanced=%d unused=%d gap=%d value=%ld floor=%ld positive=%d", (unsigned long long)snap, (unsigned long long)pendingSnap, candidate != nil, advanced, unused, hasGap, (long)candidateValue, (long)floorValue, pick != nil]);
                }
                q65clearPending(st);
            }
            NSMutableDictionary *newPending = [NSMutableDictionary dictionary];
            Q65B0 *instantRoll = nil;
            for (Q65B0 *x in a) {
                NSDictionary *prior = q65c5(b, x.x0);
                BOOL stored = prior != nil;
                NSInteger pv = stored ? q65b6(prior[zxv_p24()], -1) : -1;
                NSInteger pt = stored ? q65b6(prior[zxv_p31()], -1) : -1;
                NSInteger diff = pv >= 0 ? x.x1 - pv : 0;
                NSString *status = !stored ? @"BASELINE" : (diff > 0 ? @"INCREASE" : (diff < 0 ? @"DECREASE" : @"UNCHANGED"));
                Ongnong::ZPotionTrace([NSString stringWithFormat:@"POTION_VALUE snap=%llu kind=%@ old=%ld new=%ld delta=%ld oldMax=%ld newMax=%ld status=%@ selected=%d", (unsigned long long)snap, x.x0 ?: @"", (long)pv, (long)x.x1, (long)diff, (long)pt, (long)x.x2, status, (int)(x == pick)]);
                if (stored && diff < 0 && snap > 0 && hasGap && (uint64_t)q65b6(st[q65hit()], 0) != snap && !pick && !confirmedRoll && x.x1 >= 0) {
                    if (pt > 0 && x.x2 > pt && !instantRoll) {
                        instantRoll = x;
                        Ongnong::ZPotionTrace([NSString stringWithFormat:@"POTION_ROLL_INSTANT snap=%llu kind=%@ previous=%ld current=%ld previousMax=%ld max=%ld before=%ld", (unsigned long long)snap, x.x0, (long)pv, (long)x.x1, (long)pt, (long)x.x2, (long)potionCountAtParse]);
                    } else {
                        newPending[@"id"] = x.x0;
                        newPending[@"value"] = @(x.x1);
                        newPending[@"max"] = @(x.x2);
                        Ongnong::ZPotionTrace([NSString stringWithFormat:@"POTION_ROLL_PENDING snap=%llu kind=%@ previous=%ld current=%ld previousMax=%ld max=%ld", (unsigned long long)snap, x.x0, (long)pv, (long)x.x1, (long)pt, (long)x.x2]);
                    }
                }
            }
            if (pick && delta > 0) {
                q65clearPending(st);
            } else if (instantRoll) {
                pick = instantRoll;
                delta = 1;
                first = NO;
                q65clearPending(st);
            } else if (confirmedRoll) {
                pick = rollPick;
                delta = 1;
                first = NO;
                q65clearPending(st);
            } else if (newPending.count) {
                st[q65pending()] = newPending;
                st[q65pendingSnap()] = @(snap);
            }
            if (!pick || delta <= 0) Ongnong::ZPotionTrace([NSString stringWithFormat:@"POTION_NO_HIT snap=%llu reason=%@ entries=%lu", (unsigned long long)snap, (!pick ? @"NO_POSITIVE_DELTA" : @"NONPOSITIVE_DELTA"), (unsigned long)a.count]);
            for (Q65B0 *x in a) {
                q65ca(acc, x.x0);
                q65c6(b, x);
            }
            if (pick) {
                st[q65cb()] = pick.x0 ?: @"";
                st[q65cc()] = @(pick.x1);
                st[q65cd()] = @(pick.x2);
            }
            Ongnong::ZPotionTrace([NSString stringWithFormat:@"PARSE_CHECK snap=%llu count=%lu delta=%ld pick=%d prevHit=%llu before=%ld", (unsigned long long)snap, (unsigned long)a.count, (long)delta, (int)(pick != nil), (unsigned long long)q65b6(st[q65hit()], 0), (long)potionCountAtParse]);
            if (pick && delta > 0 && snap > 0 && (uint64_t)q65b6(st[q65hit()], 0) != snap) {
                st[q65hit()] = @(snap);
                potionHit = YES;
                Ongnong::ZPotionTrace([NSString stringWithFormat:@"PARSE_HIT snap=%llu delta=%lld first=%d", (unsigned long long)snap, (long long)delta, (int)first]);
                (void)0;
                q65d4(acc, pick, snap);
            }
            q65c3(acc, st);
        }
    }

    q65cu(u, snap, potionRelevant, potionHit, potionCountAtParse,
          tokenRelevant, tokenHit, tokenCountAtParse);
}

static void q65c8(NSData *d, NSString *u, uint64_t snap) {
    NSError *e = nil;
    id j = [NSJSONSerialization JSONObjectWithData:d options:0 error:&e];
    if (e || !j) return;
    q65cr(j, u, snap);
}

static BOOL q65cq(NSData *d, NSString *u, uint64_t snap) {
    NSData *sd = q65co(d);
    if (!sd || sd.length == 0) return NO;
    NSError *e = nil;
    id j = [NSJSONSerialization JSONObjectWithData:sd options:0 error:&e];
    if (e || !j || !q65cp(j)) return NO;
    q65cr(j, u, snap);
    return YES;
}

void q65c9(NSData *d, NSString *u, uint64_t snap) {
    if (!Ongnong::Zx8fPotionOrTokenAllowed() && !Ongnong::Zx8fLightningAllowed()) return;
    if (!d || d.length == 0 || !q65a0(u)) return;
    if (d.length > 12 * 1024 * 1024) return;
    @autoreleasepool {
        BOOL normal = q65cj(d);
        BOOL lightning = q70a0(d);
        if (!normal && !lightning) return;
        if (normal) {
            if (!q65cq(d, u, snap)) q65c8(d, u, snap);
        }
        if (lightning) q70a1(d, u, snap);
    }
}
