#include "OngnongHookManager.h"
#include "GameResolver.h"
#include "CompatibilityTrace.h"
#include <Foundation/Foundation.h>
namespace Ongnong {
void InstallHooks() {
    @autoreleasepool {
        NSLog(@"ONGNONG HOOK STAGE4: compatibility trace; hooks disabled");
        StartCompatibilityTrace();
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            struct Probe { const char *assembly; const char *ns; const char *type; const char *method; int argc; };
            const Probe probes[]={
                {"UnityEngine.CoreModule.dll","UnityEngine","Transform","get_position",0},
                {"UnityEngine.CoreModule.dll","UnityEngine","Transform","set_position",1},
                {"UnityEngine.CoreModule.dll","UnityEngine","GameObject","get_activeSelf",0},
                {"UnityEngine.CoreModule.dll","UnityEngine","Component","get_transform",0},
                {"UnityEngine.CoreModule.dll","UnityEngine","Time","get_timeScale",0},
                {"UnityEngine.CoreModule.dll","UnityEngine","Time","set_timeScale",1},
                {"UnityEngine.CoreModule.dll","UnityEngine","Application","get_unityVersion",0}
            };
            for(int attempt=0;attempt<12;attempt++) {
                const auto &first=probes[0];
                auto result=ResolveGameMethod(first.assembly,first.ns,first.type,first.method,first.argc);
                if(result.reason=="runtime_unavailable" || result.reason=="domain_unavailable" || result.reason=="assemblies_unavailable" || result.reason=="il2cpp_exports_unavailable") {
                    [NSThread sleepForTimeInterval:1.0];
                    continue;
                }
                for(size_t i=1;i<sizeof(probes)/sizeof(probes[0]);i++) {
                    const auto &probe=probes[i];
                    ResolveGameMethod(probe.assembly,probe.ns,probe.type,probe.method,probe.argc);
                }
                break;
            }
            NSLog(@"%s", CompatibilityReport().c_str());
        });
    }
}
void Z2c1f8801fd() {}
bool AutoBuildModuleIsEnabled() { return false; }
bool AutoBuildModuleIsPending() { return false; }
void AutoBuildModuleSetEnabled(bool enabled) {}
void AutoBuildModuleToggle() {}
bool AutoPigModuleIsEnabled() { return false; }
void AutoPigModuleSetEnabled(bool enabled) {}
void AutoPigModuleToggle() {}
bool AutoHammerModuleIsEnabled() { return false; }
void AutoHammerModuleSetEnabled(bool enabled) {}
void AutoHammerModuleToggle() {}
bool RaidHammerModuleIsEnabled() { return false; }
void RaidHammerModuleSetEnabled(bool enabled) {}
void RaidHammerModuleToggle() {}
void BetCycleRaidAutoSync() {}
bool MagicCardsModuleIsEnabled() { return false; }
void MagicCardsModuleSetEnabled(bool enabled) {}
void MagicCardsModuleToggle() {}
void HBMagicChestToggleAutoFromButton() {}
bool HBMagicChestIsAutoEnabled() { return false; }
bool StopSpinForAutoTarget() { return false; }
bool SetSlotBetStateForCycle(int state) { return false; }
int GetSlotBetStateForCycle() { return 0; }
bool SlotIsSpinningForCycle() { return false; }
bool PauseAutoSpinForCycle() { return false; }
bool StartAutoSpinForCycle() { return false; }
bool AutoMergeTryCollectPendingReward() { return false; }
}
