#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <dlfcn.h>
#import <mach-o/dyld.h>

@interface ONLiveEventBar : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) UITextView *view;
@property(nonatomic,strong) UIButton *toggle;
@property(nonatomic,strong) NSMutableArray<NSString *> *lines;
@property(nonatomic,assign) BOOL expanded;
+ (instancetype)shared;
- (void)append:(NSString *)line;
- (void)show;
@end

@implementation ONLiveEventBar
+ (instancetype)shared { static ONLiveEventBar *o; static dispatch_once_t once; dispatch_once(&once, ^{ o=[ONLiveEventBar new]; o.lines=[NSMutableArray array]; }); return o; }
- (void)append:(NSString *)line {
 if (!line) return;
 dispatch_async(dispatch_get_main_queue(), ^{
  NSString *s=[NSString stringWithFormat:@"%@ %@", [[NSDate date] descriptionWithLocale:nil], line];
  [self.lines addObject:s];
  if (self.lines.count>160) [self.lines removeObjectAtIndex:0];
  if (self.expanded) { self.view.text=[self.lines componentsJoinedByString:@"\n"]; [self.view scrollRangeToVisible:NSMakeRange(self.view.text.length,0)]; }
  NSString *p=[NSTemporaryDirectory() stringByAppendingPathComponent:@"ONGNONG_LiveEvents.txt"];
  NSFileHandle *f=[NSFileHandle fileHandleForWritingAtPath:p];
  if (!f) { [[NSData data] writeToFile:p atomically:YES]; f=[NSFileHandle fileHandleForWritingAtPath:p]; }
  @try { [f seekToEndOfFile]; [f writeData:[[s stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]]; [f closeFile]; } @catch(NSException *e) {}
 });
}
- (void)togglePanel {
 self.expanded=!self.expanded;
 self.view.hidden=!self.expanded;
 self.window.frame=self.expanded?CGRectMake(8,105,UIScreen.mainScreen.bounds.size.width-16,285):CGRectMake(8,105,210,42);
 [self.toggle setTitle:self.expanded?@"LIVE EVENTS  −  SHARE":@"LIVE EVENTS  +" forState:UIControlStateNormal];
 if (self.expanded) self.view.text=[self.lines componentsJoinedByString:@"\n"];
}
- (void)shareLog {
 NSString *p=[NSTemporaryDirectory() stringByAppendingPathComponent:@"ONGNONG_LiveEvents.txt"];
 UIViewController *root=UIApplication.sharedApplication.keyWindow.rootViewController;
 if (!root) return;
 UIActivityViewController *a=[[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:p]] applicationActivities:nil];
 if (a.popoverPresentationController) a.popoverPresentationController.sourceView=self.toggle;
 [root presentViewController:a animated:YES completion:nil];
}
- (void)tap:(UITapGestureRecognizer *)g { if (g.numberOfTapsRequired==2) [self shareLog]; }
- (void)show {
 if (self.window) return;
 UIWindow *w=[[UIWindow alloc] initWithFrame:CGRectMake(8,105,210,42)];
 w.windowLevel=UIWindowLevelAlert+50; w.backgroundColor=[UIColor colorWithWhite:0.05 alpha:0.88]; w.layer.cornerRadius=10; w.clipsToBounds=YES;
 UIViewController *vc=[UIViewController new]; vc.view.backgroundColor=UIColor.clearColor; w.rootViewController=vc;
 UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem]; b.frame=CGRectMake(0,0,210,42); b.autoresizingMask=UIViewAutoresizingFlexibleWidth; [b setTitle:@"LIVE EVENTS  +" forState:UIControlStateNormal]; [b setTitleColor:UIColor.greenColor forState:UIControlStateNormal]; b.titleLabel.font=[UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightBold]; [b addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside]; [vc.view addSubview:b]; self.toggle=b;
 UITapGestureRecognizer *dbl=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(shareLog)]; dbl.numberOfTapsRequired=2; [b addGestureRecognizer:dbl];
 UITextView *t=[[UITextView alloc] initWithFrame:CGRectMake(5,43,200,236)]; t.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; t.editable=NO; t.backgroundColor=UIColor.clearColor; t.textColor=UIColor.greenColor; t.font=[UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightRegular]; t.hidden=YES; [vc.view addSubview:t]; self.view=t;
 self.window=w; w.hidden=NO;
 [self append:@"MONITOR_STARTED UIKit + IL2CPP metadata and heap read-only monitor"];
}
@end

@interface UIApplication (ONLiveEvents)
- (void)onlive_sendEvent:(UIEvent *)event;
@end
@implementation UIApplication (ONLiveEvents)
- (void)onlive_sendEvent:(UIEvent *)event {
 if (event.type==UIEventTypeTouches) {
  NSSet<UITouch *> *touches=event.allTouches;
  for (UITouch *t in touches) {
   if (t.phase==UITouchPhaseBegan || t.phase==UITouchPhaseEnded) {
    CGPoint p=[t locationInView:nil];
    [[ONLiveEventBar shared] append:[NSString stringWithFormat:@"TOUCH %@ x=%.0f y=%.0f", t.phase==UITouchPhaseBegan?@"DOWN":@"UP",p.x,p.y]];
   }
  }
 }
 [self onlive_sendEvent:event];
}
@end



namespace {
typedef void* (*ONDomainGet)(void);
typedef void** (*ONDomainAssemblies)(void*,size_t*);
typedef void* (*ONAssemblyImage)(void*);
typedef size_t (*ONImageClassCount)(void*);
typedef void* (*ONImageClass)(void*,size_t);
typedef const char* (*ONClassText)(void*);
typedef size_t (*ONHeapBytes)(void);
struct ONApi {ONDomainGet domain;ONDomainAssemblies assemblies;ONAssemblyImage image;ONImageClassCount classCount;ONImageClass classAt;ONClassText className;ONClassText classNamespace;ONHeapBytes heapUsed;ONHeapBytes heapSize;};
static ONApi onApi={};
static bool onInitialized=false;
static void* onFind(const char* name) {
 void* p=dlsym(RTLD_DEFAULT,name);
 if(p)return p;
 uint32_t n=_dyld_image_count();
 for(uint32_t i=0;i<n;i++){
  const char* nm=_dyld_get_image_name(i);
  if(nm&&strstr(nm,"UnityFramework")){
   void* h=dlopen(nm,RTLD_NOW|RTLD_NOLOAD);
   if(h){p=dlsym(h,name);if(p)return p;}
  }
 }
 return nullptr;
}
static bool onReady(){
 if(onInitialized)return true;
 onApi.domain=(ONDomainGet)onFind("il2cpp_domain_get");
 onApi.assemblies=(ONDomainAssemblies)onFind("il2cpp_domain_get_assemblies");
 onApi.image=(ONAssemblyImage)onFind("il2cpp_assembly_get_image");
 onApi.classCount=(ONImageClassCount)onFind("il2cpp_image_get_class_count");
 onApi.classAt=(ONImageClass)onFind("il2cpp_image_get_class");
 onApi.className=(ONClassText)onFind("il2cpp_class_get_name");
 onApi.classNamespace=(ONClassText)onFind("il2cpp_class_get_namespace");
 onApi.heapUsed=(ONHeapBytes)onFind("il2cpp_gc_get_used_size");
 onApi.heapSize=(ONHeapBytes)onFind("il2cpp_gc_get_heap_size");
 onInitialized=onApi.domain&&onApi.assemblies&&onApi.image&&onApi.classCount&&onApi.classAt&&onApi.className&&onApi.classNamespace;
 return onInitialized;
}
static NSMutableSet<NSString*>* onSeen;
static NSUInteger onCycle=0;
static size_t onPreviousUsed=0;
static size_t onPreviousHeap=0;
static bool onHeapKnown=false;
static size_t onAssemblyCursor=0;
static size_t onClassCursor=0;
static void onSnapshot(){
 if(!onReady()){
  if(onCycle++%10==0)[[ONLiveEventBar shared] append:@"IL2CPP_WAIT metadata exports unavailable"];
  return;
 }
 if(!onSeen){onSeen=[NSMutableSet set];[[ONLiveEventBar shared] append:@"IL2CPP_READY metadata + managed heap monitoring (read only)"];}
 if(onApi.heapUsed&&onApi.heapSize){
  size_t used=onApi.heapUsed();size_t heap=onApi.heapSize();
  if(!onHeapKnown||used!=onPreviousUsed||heap!=onPreviousHeap){
   long long delta=onHeapKnown?(long long)used-(long long)onPreviousUsed:0;
   [[ONLiveEventBar shared] append:[NSString stringWithFormat:@"IL2CPP_HEAP used=%llu heap=%llu delta=%lld",(unsigned long long)used,(unsigned long long)heap,delta]];
   onPreviousUsed=used;onPreviousHeap=heap;onHeapKnown=true;
  }
 }
 void* domain=onApi.domain();if(!domain)return;
 size_t assemblyCount=0;void** assemblies=onApi.assemblies(domain,&assemblyCount);
 if(!assemblies||assemblyCount>4096)return;
 size_t budget=120;
 while(budget&&onAssemblyCursor<assemblyCount){
  void* image=onApi.image(assemblies[onAssemblyCursor]);
  if(!image){onAssemblyCursor++;onClassCursor=0;continue;}
  size_t count=onApi.classCount(image);
  if(count>1000000){onAssemblyCursor++;onClassCursor=0;continue;}
  if(onClassCursor>=count){onAssemblyCursor++;onClassCursor=0;continue;}
  void* klass=onApi.classAt(image,onClassCursor++);budget--;
  if(!klass)continue;
  const char* n=onApi.className(klass);const char* ns=onApi.classNamespace(klass);
  if(!n||strlen(n)>256||!ns||strlen(ns)>256)continue;
  NSString* name=[NSString stringWithFormat:@"%s.%s",ns,n];
  if(![onSeen containsObject:name]){
   [onSeen addObject:name];
   if(onSeen.count<=300)[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"IL2CPP_CLASS %@",name]];
  }
 }
 if(onAssemblyCursor>=assemblyCount){
  if(onCycle%10==0)[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"IL2CPP_METADATA classes=%lu assemblies=%lu",(unsigned long)onSeen.count,(unsigned long)assemblyCount]];
  onAssemblyCursor=0;onClassCursor=0;
 }
 onCycle++;
}
}
@interface ONRuntimeScanner:NSObject
@property(nonatomic,strong) NSTimer* timer;
@end
@implementation ONRuntimeScanner
- (void)tick:(NSTimer*)timer { @try {onSnapshot();} @catch(NSException* e) {[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"IL2CPP_ERROR %@",e.name]];} }
@end
static ONRuntimeScanner* onScanner;

__attribute__((constructor)) static void ONLiveBoot(void) {
 dispatch_async(dispatch_get_main_queue(), ^{
  Method a=class_getInstanceMethod([UIApplication class],@selector(sendEvent:));
  Method b=class_getInstanceMethod([UIApplication class],@selector(onlive_sendEvent:));
  if (a && b) method_exchangeImplementations(a,b);
  [[ONLiveEventBar shared] show];
  onScanner=[ONRuntimeScanner new];
  onScanner.timer=[NSTimer scheduledTimerWithTimeInterval:1.5 target:onScanner selector:@selector(tick:) userInfo:nil repeats:YES];
 });
}
