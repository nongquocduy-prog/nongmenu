#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"

static NSMutableArray<NSString *> *twLines;
static NSRecursiveLock *twLock;
static void twLog(NSString *line) {
    [twLock lock];
    if (!twLines) twLines = [NSMutableArray array];
    [twLines addObject:[NSString stringWithFormat:@"%@ | %@", [NSDate date], line ?: @""]];
    while (twLines.count > 350) [twLines removeObjectAtIndex:0];
    [twLock unlock];
}
static NSString *twCopy(void) {
    [twLock lock];
    NSString *s = [[twLines copy] componentsJoinedByString:@"\n"];
    [twLock unlock];
    return [@"ONGNONG TOKEN WHEEL TRACE v75\n" stringByAppendingString:s ?: @""];
}
@interface ONTokenTraceButton : UIButton
@end
@implementation ONTokenTraceButton
- (void)twHold:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    [UIPasteboard generalPasteboard].string = twCopy();
    twLog(@"TRACE_COPIED");
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Token Wheel Trace" message:@"Đã sao chép trace. Dán vào ChatGPT để gửi." preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    UIViewController *vc = self.window.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)twShow:(id)sender {
    NSString *logText = twCopy();
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"TOKEN WHEEL TRACE" message:logText.length ? logText : @"Chưa có dữ liệu" preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"Sao chép" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [UIPasteboard generalPasteboard].string = logText;
        twLog(@"TRACE_COPIED_FROM_POPUP");
    }]];
    [a addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *vc = self.window.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)twDrag:(UIPanGestureRecognizer *)g {
    CGPoint p = [g translationInView:self.superview];
    self.center = CGPointMake(self.center.x+p.x,self.center.y+p.y);
    [g setTranslation:CGPointZero inView:self.superview];
}
@end
static void twUI(void) {
    UIWindow *w = nil;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if (![s isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *x in ((UIWindowScene *)s).windows) if (x.isKeyWindow) { w=x; break; }
        if (w) break;
    }
    if (!w) w = UIApplication.sharedApplication.keyWindow;
    if (!w || [w viewWithTag:8172026]) return;
    ONTokenTraceButton *b = [ONTokenTraceButton buttonWithType:UIButtonTypeSystem];
    b.tag=8172026; b.frame=CGRectMake(12,170,116,36);
    b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.78];
    b.layer.cornerRadius=9;
    [b setTitle:@"TOKEN TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [b addTarget:b action:@selector(twShow:) forControlEvents:UIControlEventTouchUpInside];
    [b addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:b action:@selector(twHold:)]];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:b action:@selector(twDrag:)]];
    [w addSubview:b];
}
static void *(*origSpin)(void *,int,void *,const void *);
static void *twSpin(void *self,int bag,void *event,const void *method) {
    twLog([NSString stringWithFormat:@"SPIN_REQUEST bag=%d event=%p",bag,event]);
    return origSpin(self,bag,event,method);
}
static void *(*origSuccess)(int,void *,const void *);
static void *twSuccess(int type,void *balance,const void *method) {
    twLog([NSString stringWithFormat:@"NETWORK_SUCCESS requestType=%d balance=%p",type,balance]);
    return origSuccess(type,balance,method);
}
static void *(*origCollect)(int,void *,const void *);
static void *twCollect(int type,void *response,const void *method) {
    twLog([NSString stringWithFormat:@"COLLECT_SUCCESS requestType=%d response=%p",type,response]);
    return origCollect(type,response,method);
}
static void twInstall(void) {
    const char *img=nullptr;
    void *c=Il2CppFindClassAnyImage("TokenWheel", "TokenWheelNetworkManagerV2", &img);
    if (c && img) {
        MethodInfo *m=Il2CppFindMethodInfoRaw(img,"TokenWheel","TokenWheelNetworkManagerV2","SendSpinRequest",2,true);
        if (m && m->methodPointer && DobbyHook((void *)m->methodPointer,(void *)twSpin,(void **)&origSpin)==0) twLog(@"HOOK_SPIN_OK");
        else twLog(@"HOOK_SPIN_FAILED");
    } else twLog(@"CLASS_NETWORK_MANAGER_NOT_FOUND");
    img=nullptr;
    c=Il2CppFindClassAnyImage("TokenWheel", "TokenWheelNetworkRequestFinishedSignal", &img);
    if (c && img) {
        MethodInfo *m=Il2CppFindMethodInfoRaw(img,"TokenWheel","TokenWheelNetworkRequestFinishedSignal","CreateFromSuccessfulRequest",2,true);
        if (m && m->methodPointer && DobbyHook((void *)m->methodPointer,(void *)twSuccess,(void **)&origSuccess)==0) twLog(@"HOOK_RESULT_OK");
        else twLog(@"HOOK_RESULT_FAILED");
    } else twLog(@"CLASS_RESULT_NOT_FOUND");
}
__attribute__((constructor)) static void twStart(void) {
    twLock=[NSRecursiveLock new];
    twLines=[NSMutableArray array];
    twLog(@"START v75 token wheel read-only trace; tap to view, long-press to copy");
    dispatch_async(dispatch_get_main_queue(), ^{ twUI(); });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 7*NSEC_PER_SEC),dispatch_get_main_queue(), ^{ twUI(); twInstall(); });
}
