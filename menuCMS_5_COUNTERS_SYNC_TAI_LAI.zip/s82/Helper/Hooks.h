//Name: Hooks.h
#import "Helper.hpp"
#include <fstream>
#define FMT_HEADER_ONLY
#include "fmt/core.h"
#include <chrono>
#include <unordered_map>
#include <vector>
#include <sys/mman.h>
#include <sys/socket.h>
#include <netdb.h>
#include <errno.h>
#include <unistd.h>
#include <dlfcn.h>
#import <Foundation/Foundation.h>
#import <CFNetwork/CFNetwork.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#import "PatchNonJB/PatchNonJB.h"
#import "JRMemory.framework/Headers/MemScan.h"
#import "Il2cpp.h"

struct SlotSymbol3_Struct {
    void* isa; void* unk;
    int symbol1; int symbol2; int symbol3;
};

struct WinResult_Struct {
    void* isa; void* unk;
    int state1; 
    int state2; 
    long long amount;
};

struct SlotResult_Struct {
    void* isa; void* unk;
    SlotSymbol3_Struct* slotSymbols;
    WinResult_Struct* win;
};

struct MemoryFileInfo {
    uint32_t index;
    const struct mach_header *header;
    const char *name;
    long long address;
};

MemoryFileInfo getBaseInfo() {
    MemoryFileInfo _info;
    std::string applicationsPath = "/private/var/containers/Bundle/Application";
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *name = _dyld_get_image_name(i);
        if (!name) continue;
        std::string fullpath(name);
        if (strncmp(fullpath.c_str(), applicationsPath.c_str(), applicationsPath.size()) == 0) {
            _info.index = i;
            _info.header = _dyld_get_image_header(i);
            _info.name = _dyld_get_image_name(i);
            _info.address = _dyld_get_image_vmaddr_slide(i);
            break;
        }
    }
    return _info;
}

MemoryFileInfo getMemoryFileInfo(const std::string& fileName) {
    MemoryFileInfo _info;
    const uint32_t imageCount = _dyld_image_count();
    for (uint32_t i = 0; i < imageCount; i++) {
        const char *name = _dyld_get_image_name(i);
        if (!name) continue;
        std::string fullpath(name);
        if (fullpath.length() < fileName.length() || fullpath.compare(fullpath.length() - fileName.length(), fileName.length(), fileName) != 0) continue;
        _info.index = i;
        _info.header = _dyld_get_image_header(i);
        _info.name = _dyld_get_image_name(i);
        _info.address = _dyld_get_image_vmaddr_slide(i);
        break;
    }
    return _info;
}

uintptr_t getAbsoluteAddress(const char *fileName, uintptr_t address) {
    MemoryFileInfo info;
    if (fileName) info = getMemoryFileInfo(fileName);
    else info = getBaseInfo();
    if (info.address == 0) return 0;
    return info.address + address;
}

struct Vars_t {
    bool Enable = false;
    bool history = false;
    bool disconnect = false;
    bool SkipAttackRaid = false;
    
    int countAttack = 0;
    int countRaid = 0;
    int countSymbol = 0;
    int countSpin = 0;
    int countPoin = 0; // THÊM COUNT POIN
    
    int target = 0;
    bool resetOnTarget = false; 
    int lastSymbol1 = -1;
    int lastSymbol2 = -1;
    int lastSymbol3 = -1;

    std::vector<int> historyAttack;
    std::vector<int> historyRaid;
    std::vector<int> historySymbol;
    std::vector<int> historySpin;
    std::vector<int> historyPoin; // THÊM LỊCH SỬ POIN

    float speed = 1.0f;
    bool speedEnabled = false;
} Vars;

bool StreamerMode = false;

static void RegisterStopNotification() {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[NSNotificationCenter defaultCenter]
         addObserverForName:@"StopNowPlease"
         object:nil
         queue:[NSOperationQueue mainQueue]
         usingBlock:^(NSNotification *note) {
        }];
    });
}

void (*oActivateWinSequence)(void* ins, SlotResult_Struct* slotResult);

void ActivateWinSequence(void* ins, SlotResult_Struct* slotResult)
{
    if (Vars.SkipAttackRaid) 
    {
        if (slotResult != nullptr && slotResult->win != nullptr)
        {
            int winState = slotResult->win->state1;
            if (winState == 2 || winState == 4) 
            {
                slotResult->win->state1 = 1; 
            }
        }
    }
    return oActivateWinSequence(ins, slotResult);
}

void (*oOnSpinResultReceived)(void* ins, void* response);
void OnSpinResultReceived(void* ins, void* response)
{
    if(Vars.disconnect)
    {  
       if (response != NULL)
       {
           *(void**)((uint64_t)response + 0x8) = nullptr;
           *(void**)((uint64_t)response + 0x10) = nullptr;
       }
    }
    oOnSpinResultReceived(ins, response);
}

void (*oSetSlotBar)(void* ins, void* originalSymbols, void* replacedSymbols);

void SetSlotBar(void* ins, void* originalSymbols, void* replacedSymbols)
{
    if(true) 
    { 
        Vars.countAttack++;
        Vars.countRaid++;
        Vars.countSymbol++;
        Vars.countSpin++;
        Vars.countPoin++; 
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateAutoSpinCount" object:nil];
        });
        
        if(originalSymbols != NULL){
            int realS1 = *(int*)((uint64_t)originalSymbols + 0x10);
            int realS2 = *(int*)((uint64_t)originalSymbols + 0x14);
            int realS3 = *(int*)((uint64_t)originalSymbols + 0x18);
            
            Vars.lastSymbol1 = realS1;
            Vars.lastSymbol2 = realS2;
            Vars.lastSymbol3 = realS3;
            
            if(realS1 == realS2 && realS2 == realS3)
            {
                int hitSymbol = realS1;
                int hitCount = 0;
                
                if (hitSymbol == 3) {
                    hitCount = Vars.countAttack;
                    if(Vars.history && hitCount > 0){
                        Vars.historyAttack.insert(Vars.historyAttack.begin(), hitCount);
                        if(Vars.historyAttack.size() > 70) Vars.historyAttack.pop_back();
                    }
                    Vars.countAttack = 0;
                } else if (hitSymbol == 4) {
                    hitCount = Vars.countRaid;
                    if(Vars.history && hitCount > 0){
                        Vars.historyRaid.insert(Vars.historyRaid.begin(), hitCount);
                        if(Vars.historyRaid.size() > 70) Vars.historyRaid.pop_back();
                    }
                    Vars.countRaid = 0;
                } else if (hitSymbol == 30) {
                    hitCount = Vars.countSymbol;
                    if(Vars.history && hitCount > 0){
                        Vars.historySymbol.insert(Vars.historySymbol.begin(), hitCount);
                        if(Vars.historySymbol.size() > 70) Vars.historySymbol.pop_back();
                    }
                    Vars.countSymbol = 0;
                } else if (hitSymbol == 6) {
                    hitCount = Vars.countSpin;
                    if(Vars.history && hitCount > 0){
                        Vars.historySpin.insert(Vars.historySpin.begin(), hitCount);
                        if(Vars.historySpin.size() > 70) Vars.historySpin.pop_back();
                    }
                    Vars.countSpin = 0;
                } else if (hitSymbol == 54) { // XỬ LÝ KHI TRÚNG POIN
                    hitCount = Vars.countPoin;
                    if(Vars.history && hitCount > 0){
                        Vars.historyPoin.insert(Vars.historyPoin.begin(), hitCount);
                        if(Vars.historyPoin.size() > 70) Vars.historyPoin.pop_back();
                    }
                    Vars.countPoin = 0;
                }
                
                if(Vars.resetOnTarget && Vars.target != 0) 
                {
                    if(hitSymbol == Vars.target)
                    {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [[NSNotificationCenter defaultCenter] postNotificationName:@"StopNowPlease" object:nil];
 
                            [[NSNotificationCenter defaultCenter] postNotificationName:@"ResetAutoTargetCount" object:nil];
                        });
                    }
                }
            }
        }
    }
    return oSetSlotBar(ins, originalSymbols, replacedSymbols);
}

void (*oSetTimeScale)(float scale, void* method);

static void HookNSURLSession()
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class targetClass = objc_getClass("NSURLSession");
        if(!targetClass) return;
        
        SEL originalSelector = @selector(dataTaskWithRequest:completionHandler:);
        Method originalMethod = class_getInstanceMethod(targetClass, originalSelector);
        
        if(originalMethod) {
            IMP originalImplementation = method_getImplementation(originalMethod);
            typedef NSURLSessionDataTask* (*OriginalIMP)(id, SEL, NSURLRequest*, void(^)(NSData*, NSURLResponse*, NSError*));
            
            IMP newImplementation = imp_implementationWithBlock(^NSURLSessionDataTask *(id self, NSURLRequest *request, void (^completionHandler)(NSData *data, NSURLResponse *response, NSError *error)) {
                
                void (^wrappedCompletion)(NSData*, NSURLResponse*, NSError*) = ^(NSData *data, NSURLResponse *response, NSError *error) {
                    if(Vars.disconnect) {
                        NSError *fakeError = [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorNotConnectedToInternet userInfo:nil];
                        if(completionHandler) completionHandler(nil, nil, fakeError);
                    } else {
                        if(completionHandler) completionHandler(data, response, error);
                    }
                };
                
                NSURLSessionDataTask *task = ((OriginalIMP)originalImplementation)(self, originalSelector, request, wrappedCompletion);
                if(Vars.disconnect) [task cancel];
                return task;
            });
            method_setImplementation(originalMethod, newImplementation);
        }
        
        SEL originalSelector2 = @selector(dataTaskWithRequest:);
        Method originalMethod2 = class_getInstanceMethod(targetClass, originalSelector2);
        if(originalMethod2)
        {
            IMP originalImplementation2 = method_getImplementation(originalMethod2);
            typedef NSURLSessionDataTask* (*OriginalIMP2)(id, SEL, NSURLRequest*);
            
            IMP newImplementation2 = imp_implementationWithBlock(^NSURLSessionDataTask *(id self, NSURLRequest *request) {
                NSURLSessionDataTask *task = ((OriginalIMP2)originalImplementation2)(self, originalSelector2, request);
                if(Vars.disconnect) [task cancel];
                return task;
            });
            method_setImplementation(originalMethod2, newImplementation2);
        }
    });
}

void CheatHandle()
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Attach();
        HookNSURLSession();
        RegisterStopNotification();

        oSetTimeScale = (void (*)(float, void*))get_offset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Time"), oxorany("set_timeScale"), 1);
        void* NetworkOffset = get_offset(oxorany("Assembly-CSharp.dll"), oxorany(""), oxorany("SlotMachineManager"), oxorany("OnSpinResultReceived"), 1);
        void* SymbolOffset = get_offset(oxorany("Assembly-CSharp.dll"), oxorany(""), oxorany("SlotMachineManager"), oxorany("SetSlotBarResults"), 2);
        void* SkipAnimOffset = get_offset(oxorany("Assembly-CSharp.dll"), oxorany(""), oxorany("SlotMachineManager"), oxorany("activateWinSequence"), 1);

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            const char* frameworkPath = "Frameworks/UnityFramework.framework/UnityFramework";
            InitOffsetForPatchHook(frameworkPath, (uintptr_t)NetworkOffset, nullptr);
            InitOffsetForPatchHook(frameworkPath, (uintptr_t)SymbolOffset, nullptr);
            InitOffsetForPatchHook(frameworkPath, (uintptr_t)SkipAnimOffset, nullptr);

            oOnSpinResultReceived = (void (*)(void*, void*))HookOffset(frameworkPath, (uintptr_t)NetworkOffset, (void*)OnSpinResultReceived);
            oSetSlotBar = (void (*)(void*, void*, void*))HookOffset(frameworkPath, (uintptr_t)SymbolOffset, (void*)SetSlotBar);
            if(SkipAnimOffset != 0) {
                 oActivateWinSequence = (void (*)(void*, SlotResult_Struct*))HookOffset(frameworkPath, (uintptr_t)SkipAnimOffset, (void*)ActivateWinSequence);
            }
        });
    });
}
