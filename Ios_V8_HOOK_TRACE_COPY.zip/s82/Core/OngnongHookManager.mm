#import "Qr74m.h"
#import "OngnongSecureStrings.h"
#import "OngnongOxorany.h"
#import "OngnongHookManager.h"
#import "R7f5.h"
#import "Qr68a.h"
#import "Qr68b.h"
#import "Qr68c.h"
#import "OngnongState.h"
#import "Qr73c.h"
#import "zx8f1a_strings.h"
#import "zx8f1a_gate.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#include <dispatch/dispatch.h>
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <stdint.h>
#include <string.h>

#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/PatchNonJB.h"
#import "../Autoclick/PTFakeMetaTouch.h"

namespace Ongnong {

struct SlotSymbol3 {
    void *isa;
    void *unk;
    int symbol1;
    int symbol2;
    int symbol3;
};

struct WinResult {
    void *isa;
    void *unk;
    int state1;
    int state2;
    long long amount;
};

struct SlotResult {
    void *isa;
    void *unk;
    SlotSymbol3 *slotSymbols;
    WinResult *win;
};

static const char *UnityFrameworkPath = q6a(121);

static void (*origOnSpinResultReceived)(void *ins, void *response) = nullptr;
static void (*origSetSlotBarResults)(void *ins, void *originalSymbols, void *replacedSymbols) = nullptr;
static void (*origActivateWinSequence)(void *ins, SlotResult *slotResult) = nullptr;
static void (*origUpdate)(void *ins) = nullptr;
static void (*unitySetTimeScale)(float scale, void *method) = nullptr;
static NSTimeInterval zCoreInstallAt = 0;
static unsigned long long zTraceUpdateCalls = 0;
static unsigned long long zTraceInstallAttempts = 0;
static NSTimeInterval zTraceLastUpdate = 0;

static void *(*getMainManagerInstance)() = nullptr;
static int (*getCurrentGameState)(void *ins) = nullptr;
static bool (*getReadyToLevelUp)(void *ins) = nullptr;
static void (*moveToNextVillage)(void *ins) = nullptr;
static void (*attemptToBuildStructure)(void *ins, int structureIndex, bool quickFix, void *callback, void *zSrv, void *buildFailedAction, bool quickBuild) = nullptr;
static void (*mainManagerSwipeUp)(void *ins) = nullptr;
static void (*mainManagerSwipeDown)(void *ins) = nullptr;
static void (*villageCompleteGoNext)(void *ins) = nullptr;
static void (*mapPopupCloseClick)(void *ins) = nullptr;
static void (*genericSaleCloseBool)(void *ins, bool cancel) = nullptr;
static void (*genericSaleBackPressed)(void *ins) = nullptr;
static void (*openChestViewClick)(void *ins) = nullptr;
static void (*openChestViewSkip)(void *ins) = nullptr;
static void (*openChestCtrlClick)(void *ins) = nullptr;
static void (*openChestCtrlSkip)(void *ins) = nullptr;
static void (*villageMasterRewardCollect)(void *ins) = nullptr;
static void (*villageMasterRewardClose)(void *ins) = nullptr;

static int autoRaidDigPoint = 0;
static void *lastOpenCardsChestPopup = nullptr;
static bool autoCardChestRunning = false;
static void *hbLastRaidChestAutoObj = nullptr;
static NSTimeInterval hbLastRaidChestAutoAt = 0;
static NSTimeInterval hbLastRaidChestNoisyScheduleAt = 0;
static NSTimeInterval hbLastRaidChestSeenAt = 0;
static NSTimeInterval hbRaidChestReadyAt = 0;
static NSTimeInterval hbRaidChestClickGuardUntil = 0;
static int hbRaidChestStepSession = 0;

static void *lastAttackTargetControl = nullptr;
static bool autoAttackClicked = false;
static bool autoSummaryCloseRunning = false;

static void (*attackTargetOnAttackClicked)(void *ins) = nullptr;
static void (*origAttackTargetOnAttackClicked)(void *ins) = nullptr;
static void (*origAttackTargetEnable)(void *ins) = nullptr;
static void (*origAttackTargetShowTarget)(void *ins, float delay) = nullptr;
static void (*origAttackTargetShow)(void *ins) = nullptr;
static void (*origAttackSummaryOnAwake)(void *ins) = nullptr;
static void (*origAttackSummaryCloseButtonClicked)(void *ins) = nullptr;
static void (*origStartAttackProcess)(void *ins, int attackVersion, void *attackTarget, void *randomTarget) = nullptr;
static void (*origEndAttackSequence)(void *ins) = nullptr;

static void (*hbRaidServiceStealFromDigPoint)(void *ins, int digPointID, void *method) = nullptr;
static void (*hbLegacyStealFromDigPoint)(int digPointID) = nullptr;
static void (*hbLegacyEndStealSequence4)(bool shouldReloadVillage, uint16_t isPerfectSteal, uint16_t isFoxActive, long long coinsStolen) = nullptr;
static void (*hbLegacyEndStealSequence3)(bool shouldReloadVillage, uint16_t isPerfectSteal, uint16_t isFoxActive) = nullptr;
static void (*hbLegacyEndOfRaidSequence)(void) = nullptr;
static void (*origRaidServiceSwitchToSteal)(void *ins, void *raidInfo, void *analyticsParams, void *method) = nullptr;
static void (*origRaidServiceFinishedSuccessfulDig)(void *ins, void *method) = nullptr;
static void (*origRaidMainResetForNewRaid)(void *ins, void *method) = nullptr;
static void (*origRaidMainDigComplete)(void *ins, void *method) = nullptr;
static void *hbRaidServiceInstance = nullptr;
static void *hbSlotMachineManagerInstance = nullptr;
static void (*origShowSummaryWindow)(void *result, float upperBarDelay, float summaryDelay) = nullptr;



static void (*openCardsChestNextStateClicked)(void *ins) = nullptr;
static void (*openCardsChestCloseButtonClicked)(void *ins) = nullptr;
static void (*raidOpenCardsChestNextStateClicked)(void *ins) = nullptr;
static void (*raidOpenCardsChestCloseButtonClicked)(void *ins) = nullptr;

typedef void (*AttackSummaryCloseFn)(void *self);
typedef void (*AttackAnimAbortFn)(void *self);
static AttackSummaryCloseFn directAttackSummaryClose = nullptr;
static AttackAnimAbortFn directAttackAnimationAbort = nullptr;

typedef void *(*Il2CppResolveIcallFn)(const char *);
typedef void *(*Il2CppClassGetTypeFn)(void *);
typedef void *(*Il2CppTypeGetObjectFn)(void *);
typedef monoArray<void *> *(*FindObjectsOfType2Fn)(void *typeObj, bool includeInactive);
typedef monoArray<void *> *(*FindObjectsOfType1Fn)(void *typeObj);

static Il2CppResolveIcallFn resolveIcall = nullptr;
static Il2CppClassGetTypeFn classGetType = nullptr;
static Il2CppTypeGetObjectFn typeGetObject = nullptr;
static FindObjectsOfType2Fn findObjects2 = nullptr;
static FindObjectsOfType1Fn findObjects1 = nullptr;
static void *attackSummaryPopupType = nullptr;
static void *attackMainAnimationType = nullptr;
static void *hbBaseRaidAttackSummaryType = nullptr;


static void *hbRaidSummaryPopupType = nullptr;
static void *hbRaidSummaryScreenType = nullptr;
static MethodInfo *hbRaidSummaryPopupClickMethod = nullptr;
static MethodInfo *hbRaidSummaryScreenClickMethod = nullptr;
static NSTimeInterval hbPigSummaryNextResolveAt = 0;
static void *hbGenericRewardPopupType = nullptr;
static void *hbAttackTargetControlType = nullptr;
static void *hbOpenCardsChestPopupType = nullptr;
static void *hbRaidOpenCardsChestPopupType = nullptr;
static void *hbRewardFoundPopupType = nullptr;
static void *hbRewardReceivedPopupType = nullptr;
static void *hbRaidMainViewType = nullptr;
static void *hbMultipleChestsPopupType = nullptr;
static void *hbCardsStoreChestInfoPopupType = nullptr;
static void *hbCardsCollectionCompletePopupType = nullptr;
static void *hbOpenChestPopupViewType = nullptr;
static void *hbOpenChestPopupControllerType = nullptr;
static void *hbCardsCollectionPopupType = nullptr;
static void *hbCardsScreenViewType = nullptr;
static void *hbGuiHudControlType = nullptr;
static void *hbGuiHudOnCardButtonClickMethod = nullptr;
static bool attackCloseReady = false;


typedef bool (*HBAutoBuildSlotIsSpinningFn)(void *self);
typedef void (*HBAutoBuildSlotStringFn)(void *self, Il2CppString *key);
typedef void (*H9c4SetAutoSpinFn)(void *self, bool startSpinning);
typedef bool (*H9c4GetAutoSpinFn)(void *self);
typedef int (*H9c4GetBetFn)(void *self);
typedef void (*H9c4SetBetFn)(void *self, int state);
static void *hbAutoBuildSlotType = nullptr;
static HBAutoBuildSlotIsSpinningFn hbSlotIsSpinning = nullptr;
static HBAutoBuildSlotStringFn hbSlotDeactivateAutoSpin = nullptr;
static HBAutoBuildSlotStringFn hbSlotLock = nullptr;
static HBAutoBuildSlotStringFn hbSlotUnlock = nullptr;
static H9c4SetAutoSpinFn h9c4SetAutoSpin = nullptr;
static H9c4GetAutoSpinFn h9c4GetAutoSpin = nullptr;
static H9c4GetBetFn h9c4GetBet = nullptr;
static H9c4SetBetFn h9c4SetBet = nullptr;
static void (*origSlotMachineSpinComplete)(void *ins) = nullptr;
static uint64_t h9c4SpinSerial = 0;
static BOOL hbAutoBuildPending = NO;
static BOOL hbAutoBuildSessionGranted = NO;
static BOOL hbAutoBuildPendingLocked = NO;
static NSTimeInterval hbAutoBuildPendingAt = 0;
static NSTimeInterval hbAutoBuildPendingLastCheckAt = 0;
static NSTimeInterval hbAutoBuildSafeAfterAt = 0;
static NSTimeInterval hbAutoBuildStateStableSince = 0;
static NSTimeInterval hbAutoBuildLastSpinProbeAt = 0;
static BOOL hbAutoBuildLastSpinProbeValue = NO;
static int hbAutoBuildLastStableState = -999;

static void (*hbBaseSummaryOnClick)(void *ins) = nullptr;
static void (*hbGenericRewardCollect)(void *ins) = nullptr;
static void (*hbGenericRewardClose)(void *ins) = nullptr;
static void (*hbRewardFoundClaim)(void *ins) = nullptr;
static void (*hbRewardFoundClose)(void *ins) = nullptr;
static void (*hbRewardReceivedClose)(void *ins) = nullptr;
static void *hbRaidMainPlayDigChestMethod = nullptr;
static void *hbRaidAnimCollectChestMethod = nullptr;
static void *hbRaidUtilsCollectChestMethod = nullptr;
static void *hbOpenCardsShowPopupMethod = nullptr;
static void *hbMultipleChestsShowPopupMethod = nullptr;
static void *hbMultipleChestsClickPurchaseMethod = nullptr;
static void *hbCardsStoreInfoClickPurchaseMethod = nullptr;
static void *hbLegacyProcessChestSuccessMethod = nullptr;
static void *hbNetworkPurchaseChestMethod = nullptr;
static void *hbNetworkPurchaseChestMultipleMethod = nullptr;
static void *hbMultipleChestsNumberUpdatedMethod = nullptr;
static void *hbMultipleChestsCloseMethod = nullptr;
static void *hbCardsStoreInfoShowPopupMethod = nullptr;
static void *hbCardsStoreInfoCloseMethod = nullptr;
static void *hbLegacyProcessChestPurchaseMethod = nullptr;
static void *hbLegacyProcessGenericChestPurchaseMethod = nullptr;
static void *hbLegacyPurchaseChestMethod = nullptr;
static void *hbOpenCardsOpenChestSequenceMethod = nullptr;
static void *hbOpenCardsPlayChestAnimationMethod = nullptr;
static void *hbOpenCardsPlaySpecificChestAnimationMethod = nullptr;
static void *hbCardsCollectionShowPopupMethod = nullptr;
static void *hbCardsCollectionOnAwakeMethod = nullptr;
static void *hbCardsCollectionCloseButtonMethod = nullptr;
static void *hbCardsHandleChestMethod = nullptr;
static void *hbCardsHandleSetCompleteMethod = nullptr;
static void *hbCardsProcessSetCompleteDataMethod = nullptr;
static void *hbOpenChestPopupViewOnAwakeMethod = nullptr;
static void *hbOpenChestPopupViewOnClickMethod = nullptr;
static void *hbOpenChestPopupViewOnSkipClickMethod = nullptr;
static void *hbOpenChestPopupControllerShowMethod = nullptr;
static void *hbOpenChestPopupControllerCloseMethod = nullptr;
static void *hbOpenChestPopupControllerOnClickMethod = nullptr;
static void *hbOpenChestPopupControllerOnSkipClickMethod = nullptr;
static void *hbStoreItemComponentType = nullptr;
static void *hbStoreItemComponentInitMethod = nullptr;
static void *hbStoreItemComponentItemClickMethod = nullptr;
static void *hbStoreItemComponentGetCurrentDataMethod = nullptr;
static void *hbCardsCollectionPopupShowPopupMethod = nullptr;
static void *hbCardsCollectionPopupOnOpenStoreClickedMethod = nullptr;
static void *hbCardsScreenViewOnOpenStoreClickedMethod = nullptr;

static BOOL hbMagicChestFlowActive = NO;
static NSTimeInterval hbMagicChestLastEventAt = 0;
static int hbMagicChestEventSession = 0;
static int hbMagicScanActiveChains = 0;
static NSTimeInterval hbMagicScanLastRequestAt = 0;
static void *hbLastMagicChestPopupObj = nullptr;

static BOOL hbMagicAutoEnabled = NO;

static BOOL hbMagicRuntimeEnabled = NO;
static UIButton *hbMagicAutoButton = nil;
static BOOL hbMagicAutoLoopScheduled = NO;
static int hbMagicAutoTickNo = 0;
static NSTimeInterval hbMagicAutoLastTapAt = 0;
static NSTimeInterval hbMagicAutoLastActionAt = 0;
static int hbMagicAutoIdleTapCount = 0;
static BOOL hbMagicSafeScanInstalled = NO;
static NSTimeInterval hbMagicSafeScanLastAt = 0;
static int hbMagicSafeScanTick = 0;
static BOOL hbMagicSafeScanObservedOffsets = NO;
static BOOL hbMagicDirectHooksInstalled = NO;
static void *hbMagicLastMultiObj = nullptr;
static int hbMagicLastMultiChests = -999;
static BOOL hbMagicLastMultiVisible = NO;
static NSTimeInterval hbMagicLastMultiSeenAt = 0;
static BOOL hbMagicLastOpenVisible = NO;
static void *hbMagicLastOpenObj = nullptr;
static int hbMagicLastOpenState = -999;
static NSTimeInterval hbMagicLastOpenSeenAt = 0;
static BOOL hbMagicLastRewardOpenVisible = NO;
static void *hbMagicLastRewardOpenObj = nullptr;
static NSTimeInterval hbMagicLastRewardOpenSeenAt = 0;


static void (*origLegacyProcessChestPurchase)(void *ins, void *data, void *onComplete, void *onBeforeNotEnoughCoins) = nullptr;
static void (*origLegacyProcessGenericChestPurchase)(void *ins, void *data, void *onComplete, void *onNotEnoughCoins) = nullptr;
static void (*origLegacyPurchaseChest)(void *ins, void *sku, int chestType, void *requestId, bool isRetry, void *onComplete) = nullptr;
static void (*origLegacyProcessChestPurchaseSuccess)(void *ins, void *chestType, void *requestId, void *balanceData, void *onComplete) = nullptr;

static void *hbMagicLastStoreItemObj = nullptr;
static long long hbMagicLastStoreItemPrice = 0;
static NSTimeInterval hbMagicLastStoreItemAt = 0;
static int hbMagicStoreScanSerial = 0;
static NSTimeInterval hbMagicAutoPayClickedAt = 0;
static NSTimeInterval hbMagicAutoSkipAllowedAt = 0;
static NSTimeInterval hbMagicAutoPayReadyAt = 0;
static NSTimeInterval hbMagicAutoRewardSeenAt = 0;
static NSTimeInterval hbMagicAutoLastWaitSeenAt = 0;


enum { HB_MAGIC_STAGE_IDLE = 0, HB_MAGIC_STAGE_WAIT_QTY = 1, HB_MAGIC_STAGE_READY_PAY = 2, HB_MAGIC_STAGE_WAIT_REWARD = 3, HB_MAGIC_STAGE_WAIT_CLOSED = 4, HB_MAGIC_STAGE_OPEN_CARDS = 5, HB_MAGIC_STAGE_OPEN_STORE = 6 };
static int hbMagicAutoStage = HB_MAGIC_STAGE_IDLE;
static NSTimeInterval hbMagicAutoStageAt = 0;
static NSTimeInterval hbMagicAutoCooldownUntil = 0;
static NSTimeInterval hbMagicAutoLastStageSeenAt = 0;
static NSTimeInterval hbMagicAutoLastNavActionAt = 0;
static int hbMagicAutoNavTryCount = 0;


static void HBMagicChestSafeScanBootstrap(void);
static void HBMagicChestSafeScanTick(int state);

static NSTimeInterval hbLastFallbackScan = 0;
static NSTimeInterval hbLastOkHintSeenAt = 0;
static int hbLastOkHintState = -999;
static NSTimeInterval hbLastPigDigAt = 0;
static NSTimeInterval hbPigPauseUntil = 0;
static int hbPigDigInCycle = 0;
static void *hbLastSummaryClicked = nullptr;
static NSTimeInterval hbLastSummaryClickAt = 0;

static void *hbLastPigSummaryClicked = nullptr;
static NSTimeInterval hbLastPigSummaryClickAt = 0;
static void *hbLastRewardClicked = nullptr;
static NSTimeInterval hbLastRewardClickAt = 0;
static void *hbLastAttackClickedObj = nullptr;
static NSTimeInterval hbLastAttackClickAt = 0;
static BOOL hbAndroidPigScheduled = NO;
static void *hbPigRaidMainViewInstance = nullptr;
static int hbPigDigRequested = 0;
static int hbPigDigFinished = 0;
static BOOL hbPigDigInFlight = NO;
static BOOL hbPigViewReadyForNextDig = NO;
static NSTimeInterval hbPigLastDigRequestAt = 0;
static const double hbPigMinDigInterval = 0.55;
static int hbPigLastResultCount = -1;
static int hbPigResultRetryCount = 0;
static int hbPigServiceRetryCount = 0;
static int hbPigScheduleRetryCount = 0;
static BOOL hbPigScheduleRetryArmed = NO;

static int HBPigReadResultCount(void *view) {
    if (!view) return -1;
    static size_t digResultOffset = SIZE_MAX;
    static BOOL digResultOffsetResolved = NO;
    if (!digResultOffsetResolved) {
        digResultOffsetResolved = YES;
        const char *imageName = nullptr;
        void *klass = Il2CppFindClassAnyImage(OX_C("MoonActive.Raid.UI"), OX_C("RaidMainView"), &imageName);
        if (klass && imageName) {
            size_t resolved = Il2CppGetFieldOffset(imageName, OX_C("MoonActive.Raid.UI"), OX_C("RaidMainView"), OX_C("m_DigResultById"));
            if (resolved > 0 && resolved < 0x1000) digResultOffset = resolved;
        }
        if (digResultOffset == SIZE_MAX) digResultOffset = 0x40;
    }
    void *dict = nullptr;
    @try { dict = *(void **)((uintptr_t)view + digResultOffset); } @catch (NSException *e) { return -1; }
    if (!dict) return 0;
    int count = -1;
    @try { count = *(int *)((uintptr_t)dict + 0x20); } @catch (NSException *e) { return -1; }
    if (count < 0 || count > 64) return -1;
    return count;
}

static void HBPigRefreshServiceFromSlot(void) {
    void *slot = hbSlotMachineManagerInstance;
    if (!slot) return;
    static size_t raidServiceOffset = SIZE_MAX;
    static BOOL raidServiceOffsetResolved = NO;
    if (!raidServiceOffsetResolved) {
        raidServiceOffsetResolved = YES;
        const char *imageName = nullptr;
        void *klass = Il2CppFindClassAnyImage(OX_C(""), OX_C("SlotMachineManager"), &imageName);
        if (klass && imageName) {
            size_t resolved = Il2CppGetFieldOffset(imageName, OX_C(""), OX_C("SlotMachineManager"), OX_C("m_RaidService"));
            if (resolved > 0 && resolved < 0x1000) raidServiceOffset = resolved;
        }
        if (raidServiceOffset == SIZE_MAX) raidServiceOffset = 0x1F0;
    }
    void *svc = nullptr;
    @try { svc = *(void **)((uintptr_t)slot + raidServiceOffset); } @catch (NSException *e) { svc = nullptr; }
    if (svc && svc != hbRaidServiceInstance) {
        hbRaidServiceInstance = svc;
    }
}
static BOOL hbAndroidPigRunning = NO;
static int hbAndroidPigSession = 0;
static NSTimeInterval hbAndroidPigLastScheduleAt = 0;
static NSTimeInterval hbAndroidPigLastEndAt = 0;
static NSTimeInterval hbAndroidLastStateSeenAt = 0;
static NSTimeInterval hbChestLastScanAt = 0;
static BOOL hbChestScanRunning = NO;
static int hbChestScanSession = 0;
static int hbHammerSession = 0;
static NSTimeInterval hbHammerLastTargetScanAt = 0;
static NSTimeInterval hbHammerTargetSeenAt = 0;
static NSTimeInterval hbHammerTargetClickedAt = 0;
static NSTimeInterval hbHammerLastSummaryScanAt = 0;
static void *hbHammerTargetObj = nullptr;
static void *hbHammerLastClosedSummaryObj = nullptr;
static NSTimeInterval hbHammerLastClosedSummaryAt = 0;
static int hbHammerRetryCount = 0;
static BOOL hbHammerHookInstalled = NO;
static BOOL hbPigModuleEnabled = NO;
static BOOL hbHammerModuleEnabled = NO;

static BOOL HBPigModuleEnabled(void) { return hbPigModuleEnabled; }
static BOOL HBAutoHammerEnabled(void) { return hbHammerModuleEnabled; }
static BOOL HBRaidAutomationEnabled(void) { return hbPigModuleEnabled || hbHammerModuleEnabled; }

static void OngnongJobDrop(int owner);

static void HBHammerModuleResetState(void) {
    hbHammerSession++;
    hbHammerLastTargetScanAt = 0;
    hbHammerTargetSeenAt = 0;
    hbHammerTargetClickedAt = 0;
    hbHammerLastSummaryScanAt = 0;
    hbHammerTargetObj = nullptr;
    hbHammerLastClosedSummaryObj = nullptr;
    hbHammerLastClosedSummaryAt = 0;
    hbHammerRetryCount = 0;
    autoAttackClicked = false;
    autoSummaryCloseRunning = false;
    lastAttackTargetControl = nullptr;
}

static int GetCurrentGameStateSafely() {
    if (!getMainManagerInstance || !getCurrentGameState) return -1;
    void *mainMgr = getMainManagerInstance();
    if (!mainMgr) return -1;
    return getCurrentGameState(mainMgr);
}

enum { ONGNONG_JOB_NONE = 0, ONGNONG_JOB_RAID = 1, ONGNONG_JOB_BUILD = 2, ONGNONG_JOB_MAGIC = 3 };
static int ongnongJobOwner = ONGNONG_JOB_NONE;
static NSTimeInterval ongnongJobOwnerUntil = 0;

static BOOL OngnongJobTake(int owner, double seconds) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (ongnongJobOwnerUntil > 0 && now > ongnongJobOwnerUntil) {
        ongnongJobOwner = ONGNONG_JOB_NONE;
        ongnongJobOwnerUntil = 0;
    }
    if (ongnongJobOwner != ONGNONG_JOB_NONE && ongnongJobOwner != owner) return NO;
    ongnongJobOwner = owner;
    NSTimeInterval until = now + seconds;
    if (until > ongnongJobOwnerUntil) ongnongJobOwnerUntil = until;
    return YES;
}

static void OngnongJobDrop(int owner) {
    if (ongnongJobOwner == owner) {
        ongnongJobOwner = ONGNONG_JOB_NONE;
        ongnongJobOwnerUntil = 0;
    }
}

static BOOL OngnongJobCanRun(int owner) {
    return OngnongJobTake(owner, 0.10);
}

static BOOL HBRaidGameState(int state) {
    return (state == 1 || state == 2);
}

static void q4b2a1();
static const char *OngnongOpenCardsClassName(void);
static void Zx8fResolveRaidDirectFast();
static void HBAndroidPigSchedule(const char *reason, double startDelay);
static void MagicCardsModuleResetState(void);
static BOOL HBAutoBuildBeginOrPend(void);
static void HBAutoBuildCancelPending(void);
static BOOL HBAutoBuildPendingActive(void);
static void HBAutoBuildTryFinishPending(void);
static void HBAutoBuildResetSceneStability(void);

static void AutoBuildModuleResetState(void) {
    hbAutoBuildSessionGranted = NO;
    HBAutoBuildCancelPending();
    hbAutoBuildSafeAfterAt = 0;
    hbAutoBuildStateStableSince = 0;
    hbAutoBuildLastStableState = -999;
    hbAutoBuildLastSpinProbeAt = 0;
    hbAutoBuildLastSpinProbeValue = NO;
    OngnongJobDrop(ONGNONG_JOB_BUILD);
}

static void RaidHammerModuleResetState(void) {
    OngnongJobDrop(ONGNONG_JOB_RAID);
    autoCardChestRunning = false;
    lastOpenCardsChestPopup = nullptr;
    hbLastRaidChestAutoObj = nullptr;
    hbLastRaidChestAutoAt = 0;
    hbRaidChestStepSession++;
    hbRaidChestReadyAt = 0;
    hbRaidChestClickGuardUntil = 0;
    autoAttackClicked = false;
    autoSummaryCloseRunning = false;
    lastAttackTargetControl = nullptr;
    hbAndroidPigScheduled = NO;
    hbAndroidPigRunning = NO;
    hbAndroidPigLastScheduleAt = 0;
    hbAndroidPigLastEndAt = 0;
    hbLastPigSummaryClicked = nullptr;
    hbLastPigSummaryClickAt = 0;
    hbPigSummaryNextResolveAt = 0;
    hbChestScanRunning = NO;
    hbChestScanSession++;
    HBHammerModuleResetState();
}

bool AutoBuildModuleIsEnabled(void) { return q6ga(0xA1B2C301u) && hbAutoBuildSessionGranted && zce119e8048.z7377de64e5; }
bool AutoBuildModuleIsPending(void) { return q6ga(0xA1B2C301u) && hbAutoBuildSessionGranted && HBAutoBuildPendingActive(); }
void AutoBuildModuleSetEnabled(bool enabled) {
    
    if (!q6ga(0xA1B2C302u)) return;
    if (enabled && hbAutoBuildSessionGranted && zce119e8048.z7377de64e5) {  return; }
    if (!enabled && !zce119e8048.z7377de64e5 && !hbAutoBuildPending && !hbAutoBuildSessionGranted) {  return; }
    if (enabled) {
        if (!Ongnong::Zx8fAutoBuildAllowed()) {  return; }
        if (HBRaidAutomationEnabled() || hbMagicAutoEnabled) return;
        hbAutoBuildSessionGranted = YES;
        
        BOOL canStartNow = HBAutoBuildBeginOrPend();
        if (!canStartNow) return;
    } else {
        HBAutoBuildCancelPending();
        hbAutoBuildSessionGranted = NO;
        
    }
    zce119e8048.z7377de64e5 = enabled;
    
    if (enabled) {
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        hbAutoBuildSafeAfterAt = now + 0.95;
        HBAutoBuildResetSceneStability();
        q4b2a1();
    }
    else AutoBuildModuleResetState();
}
void AutoBuildModuleToggle(void) {
    if (!q6gb(0xA1B2C303u)) return;
    bool active = AutoBuildModuleIsEnabled() || AutoBuildModuleIsPending();
    if (!active && !Ongnong::Zx8fAutoBuildAllowed()) return;
    AutoBuildModuleSetEnabled(!active);
}

bool AutoPigModuleIsEnabled(void) { return q6gb(0xB2C3D401u) && HBPigModuleEnabled(); }
void AutoPigModuleSetEnabled(bool enabled) {
    if (!q6gb(0xB2C3D402u)) return;
    if (enabled && (zce119e8048.z7377de64e5 || HBAutoBuildPendingActive() || hbMagicAutoEnabled)) return;
    hbPigModuleEnabled = enabled ? YES : NO;
    if (enabled) {
        hbAndroidPigScheduled = NO;
        hbAndroidPigRunning = NO;
        hbAndroidPigSession++;
        hbPigDigRequested = 0;
        hbPigDigFinished = 0;
        hbPigDigInFlight = NO;
        hbPigViewReadyForNextDig = NO;
        hbPigLastDigRequestAt = 0;
        hbPigLastResultCount = -1;
        hbPigResultRetryCount = 0;
        hbPigServiceRetryCount = 0;
        hbPigScheduleRetryCount = 0;
        hbPigScheduleRetryArmed = NO;
        hbPigRaidMainViewInstance = nullptr;
        autoRaidDigPoint = 0;
        OngnongJobDrop(ONGNONG_JOB_RAID);
        Zx8fResolveRaidDirectFast();
        HBAndroidPigSchedule(q6a(1), 0.65);
    }
    else {
        hbAndroidPigScheduled = NO;
        hbAndroidPigRunning = NO;
        hbAndroidPigSession++;
        hbAndroidPigLastScheduleAt = 0;
        hbAndroidPigLastEndAt = 0;
        hbPigDigInCycle = 0;
        autoRaidDigPoint = 0;
        hbLastPigSummaryClicked = nullptr;
        hbLastPigSummaryClickAt = 0;
        hbPigSummaryNextResolveAt = 0;
        hbChestScanRunning = NO;
        hbChestScanSession++;
    }
    zce119e8048.zfd92661903 = HBRaidAutomationEnabled();
}
void AutoPigModuleToggle(void) { AutoPigModuleSetEnabled(!AutoPigModuleIsEnabled()); }

bool AutoHammerModuleIsEnabled(void) { return q6gb(0xB2C3D401u) && HBAutoHammerEnabled(); }
void AutoHammerModuleSetEnabled(bool enabled) {
    if (!q6gb(0xB2C3D402u)) return;
    if (enabled && (zce119e8048.z7377de64e5 || HBAutoBuildPendingActive() || hbMagicAutoEnabled)) return;
    hbHammerModuleEnabled = enabled ? YES : NO;
    if (enabled) Zx8fResolveRaidDirectFast();
    else HBHammerModuleResetState();
    zce119e8048.zfd92661903 = HBRaidAutomationEnabled();
}
void AutoHammerModuleToggle(void) { AutoHammerModuleSetEnabled(!AutoHammerModuleIsEnabled()); }

bool RaidHammerModuleIsEnabled(void) { return Ongnong::Zx8fRaidHammerAllowed() && (AutoPigModuleIsEnabled() || AutoHammerModuleIsEnabled()); }
void RaidHammerModuleSetEnabled(bool enabled) {
    if (!q6gb(0xB2C3D402u)) return;
    if (enabled && !Ongnong::Zx8fRaidHammerAllowed()) return;
    if (enabled && (zce119e8048.z7377de64e5 || HBAutoBuildPendingActive() || hbMagicAutoEnabled)) return;
    AutoPigModuleSetEnabled(enabled);
    AutoHammerModuleSetEnabled(enabled);
    if (!enabled) RaidHammerModuleResetState();
    zce119e8048.zfd92661903 = HBRaidAutomationEnabled();
}
static bool q72RaidOwned = false;
void BetCycleRaidAutoSync(void) {
    bool wanted = R3n8() && [[NSUserDefaults standardUserDefaults] boolForKey:@"ongnong_q72_auto_raid"];
    if (wanted) {
        if (!RaidHammerModuleIsEnabled() && Ongnong::Zx8fRaidHammerAllowed()) {
            RaidHammerModuleSetEnabled(true);
            if (RaidHammerModuleIsEnabled()) q72RaidOwned = true;
        }
    } else if (q72RaidOwned) {
        RaidHammerModuleSetEnabled(false);
        q72RaidOwned = false;
    }
}
void RaidHammerModuleToggle(void) { if (Ongnong::Zx8fRaidHammerAllowed() && q6gc(0xB2C3D403u)) RaidHammerModuleSetEnabled(!RaidHammerModuleIsEnabled()); }


static void InitAttackCloseHelpers() {
    if (attackCloseReady) return;
    attackCloseReady = true;

    resolveIcall = (Il2CppResolveIcallFn)dlsym(RTLD_DEFAULT, q6a(122));
    classGetType = (Il2CppClassGetTypeFn)dlsym(RTLD_DEFAULT, q6a(123));
    typeGetObject = (Il2CppTypeGetObjectFn)dlsym(RTLD_DEFAULT, q6a(124));

    if (resolveIcall) {
        findObjects2 = (FindObjectsOfType2Fn)resolveIcall(q6a(23));
        findObjects1 = (FindObjectsOfType1Fn)resolveIcall(q6a(24));
    }

    void *summaryClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(53));
    if (summaryClass && classGetType && typeGetObject) {
        void *type = classGetType(summaryClass);
        if (type) attackSummaryPopupType = typeGetObject(type);
    }

    void *animClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(54));
    if (animClass && classGetType && typeGetObject) {
        void *type = classGetType(animClass);
        if (type) attackMainAnimationType = typeGetObject(type);
    }

    void *baseSummaryClass = Il2CppGetClassType(q6a(0), q6a(56), q6a(57));
    if (baseSummaryClass && classGetType && typeGetObject) {
        void *type = classGetType(baseSummaryClass);
        if (type) hbBaseRaidAttackSummaryType = typeGetObject(type);
    }

    
    void *raidSummaryPopupClass = Il2CppGetClassType(
        q6a(0), OX_C("MoonActive.Raid.UI"), OX_C("RaidSummaryScreenPopup"));
    if (raidSummaryPopupClass && classGetType && typeGetObject) {
        void *type = classGetType(raidSummaryPopupClass);
        if (type) hbRaidSummaryPopupType = typeGetObject(type);
    }

    void *raidSummaryScreenClass = Il2CppGetClassType(
        q6a(0), OX_C("MoonActive.Raid.UI.UpperHUD"), OX_C("RaidSummaryScreen"));
    if (raidSummaryScreenClass && classGetType && typeGetObject) {
        void *type = classGetType(raidSummaryScreenClass);
        if (type) hbRaidSummaryScreenType = typeGetObject(type);
    }

    void *genericRewardClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(58));
    if (genericRewardClass && classGetType && typeGetObject) {
        void *type = classGetType(genericRewardClass);
        if (type) hbGenericRewardPopupType = typeGetObject(type);
    }

    void *attackTargetClass = Il2CppGetClassType(q6a(0), q6a(1), OX_C("GUI_attackTergetControl"));
    if (attackTargetClass && classGetType && typeGetObject) {
        void *type = classGetType(attackTargetClass);
        if (type) hbAttackTargetControlType = typeGetObject(type);
    }

    void *openCardsClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(59));
    if (openCardsClass && classGetType && typeGetObject) {
        void *type = classGetType(openCardsClass);
        if (type) hbOpenCardsChestPopupType = typeGetObject(type);
    }

    void *raidOpenCardsClass = Il2CppGetClassType(q6a(0), q6a(1), OngnongOpenCardsClassName());
    if (raidOpenCardsClass && classGetType && typeGetObject) {
        void *type = classGetType(raidOpenCardsClass);
        if (type) hbRaidOpenCardsChestPopupType = typeGetObject(type);
    }

    void *rewardFoundClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(60));
    if (rewardFoundClass && classGetType && typeGetObject) {
        void *type = classGetType(rewardFoundClass);
        if (type) hbRewardFoundPopupType = typeGetObject(type);
    }

    void *rewardReceivedClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(61));
    if (rewardReceivedClass && classGetType && typeGetObject) {
        void *type = classGetType(rewardReceivedClass);
        if (type) hbRewardReceivedPopupType = typeGetObject(type);
    }

    void *raidMainClass = Il2CppGetClassType(q6a(0), q6a(62), q6a(63));
    if (raidMainClass && classGetType && typeGetObject) {
        void *type = classGetType(raidMainClass);
        if (type) hbRaidMainViewType = typeGetObject(type);
    }

    void *multiChestClass = Il2CppGetClassType(q6a(0), q6a(64), q6a(65));
    if (multiChestClass && classGetType && typeGetObject) {
        void *type = classGetType(multiChestClass);
        if (type) hbMultipleChestsPopupType = typeGetObject(type);
    }

    void *cardsInfoClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(66));
    if (cardsInfoClass && classGetType && typeGetObject) {
        void *type = classGetType(cardsInfoClass);
        if (type) hbCardsStoreChestInfoPopupType = typeGetObject(type);
    }

    void *storeItemClass = Il2CppGetClassType(q6a(0), q6a(67), q6a(68));
    if (storeItemClass && classGetType && typeGetObject) {
        void *type = classGetType(storeItemClass);
        if (type) hbStoreItemComponentType = typeGetObject(type);
    }

    void *setCompleteClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(69));
    if (setCompleteClass && classGetType && typeGetObject) {
        void *type = classGetType(setCompleteClass);
        if (type) hbCardsCollectionCompletePopupType = typeGetObject(type);
    }

    void *openChestViewClass = Il2CppGetClassType(q6a(0), q6a(70), q6a(71));
    if (openChestViewClass && classGetType && typeGetObject) {
        void *type = classGetType(openChestViewClass);
        if (type) hbOpenChestPopupViewType = typeGetObject(type);
    }
    void *openChestCtrlClass = Il2CppGetClassType(q6a(0), q6a(70), q6a(72));
    if (openChestCtrlClass && classGetType && typeGetObject) {
        void *type = classGetType(openChestCtrlClass);
        if (type) hbOpenChestPopupControllerType = typeGetObject(type);
    }

    void *cardsCollectionPopupClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(73));
    if (cardsCollectionPopupClass && classGetType && typeGetObject) {
        void *type = classGetType(cardsCollectionPopupClass);
        if (type) hbCardsCollectionPopupType = typeGetObject(type);
    }

    void *cardsScreenViewClass = Il2CppGetClassType(q6a(0), q6a(74), q6a(75));
    if (!cardsScreenViewClass) cardsScreenViewClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(75));
    if (cardsScreenViewClass && classGetType && typeGetObject) {
        void *type = classGetType(cardsScreenViewClass);
        if (type) hbCardsScreenViewType = typeGetObject(type);
    }

    void *guiHudClass = Il2CppGetClassType(q6a(0), q6a(1), q6a(76));
    if (guiHudClass && classGetType && typeGetObject) {
        void *type = classGetType(guiHudClass);
        if (type) hbGuiHudControlType = typeGetObject(type);
    }
}

static monoArray<void *> *FindObjectsForType(void *typeObj) {
    if (!typeObj) return nullptr;
    InitAttackCloseHelpers();
    monoArray<void *> *arr = nullptr;
    if (findObjects2) arr = findObjects2(typeObj, false);
    if (!arr && findObjects1) arr = findObjects1(typeObj);
    return arr;
}

static monoArray<void *> *HBFindObjectsForTypeEx(void *typeObj, bool includeInactive) {
    if (!typeObj) return nullptr;
    InitAttackCloseHelpers();
    monoArray<void *> *arr = nullptr;
    if (findObjects2) arr = findObjects2(typeObj, includeInactive);
    if (!arr && !includeInactive && findObjects1) arr = findObjects1(typeObj);
    return arr;
}


static BOOL HBAutoBuildPendingActive(void) {
    return hbAutoBuildPending ? YES : NO;
}

static void HBAutoBuildResolveSlotMachine(void) {
    if (hbSlotIsSpinning && hbSlotDeactivateAutoSpin && hbSlotLock && hbSlotUnlock && hbAutoBuildSlotType) return;
    InitAttackCloseHelpers();
    if (!hbAutoBuildSlotType && classGetType && typeGetObject) {
        void *klass = Il2CppGetClassType(q6a(0), q6a(1), q6a(25));
        if (klass) {
            void *type = classGetType(klass);
            if (type) hbAutoBuildSlotType = typeGetObject(type);
        }
    }
    void *isSpin = get_offset(q6a(0), q6a(1), q6a(25), q6a(126), 0);
    void *deact = get_offset(q6a(0), q6a(1), q6a(25), q6a(127), 1);
    void *lock = get_offset(q6a(0), q6a(1), q6a(25), q6a(128), 1);
    void *unlock = get_offset(q6a(0), q6a(1), q6a(25), q6a(129), 1);
    if (isSpin) hbSlotIsSpinning = (HBAutoBuildSlotIsSpinningFn)isSpin;
    if (deact) hbSlotDeactivateAutoSpin = (HBAutoBuildSlotStringFn)deact;
    if (lock) hbSlotLock = (HBAutoBuildSlotStringFn)lock;
    if (unlock) hbSlotUnlock = (HBAutoBuildSlotStringFn)unlock;
}

static void H9c4ResolveMethods(void) {
    if (h9c4SetAutoSpin && h9c4GetAutoSpin && h9c4GetBet && h9c4SetBet) return;
    HBAutoBuildResolveSlotMachine();
    void *setAutoSpin = get_offset(q6a(0), q6a(1), q6a(25), OX_C("SetAutoSpin"), 1);
    void *getAutoSpin = get_offset(q6a(0), q6a(1), q6a(25), OX_C("get_IsAutoSpinEnabled"), 0);
    void *getBet = get_offset(q6a(0), q6a(1), q6a(25), OX_C("get_BetState"), 0);
    void *setBet = get_offset(q6a(0), q6a(1), q6a(25), OX_C("SetBetState"), 1);
    if (setAutoSpin) h9c4SetAutoSpin = (H9c4SetAutoSpinFn)setAutoSpin;
    if (getAutoSpin) h9c4GetAutoSpin = (H9c4GetAutoSpinFn)getAutoSpin;
    if (getBet) h9c4GetBet = (H9c4GetBetFn)getBet;
    if (setBet) h9c4SetBet = (H9c4SetBetFn)setBet;
}

static void *HBAutoBuildFindSlotMachine(void) {
    HBAutoBuildResolveSlotMachine();
    if (!hbAutoBuildSlotType) return nullptr;
    monoArray<void *> *arr = HBFindObjectsForTypeEx(hbAutoBuildSlotType, false);
    int cap = arr ? arr->getCapacity() : 0;
    if (cap > 6) cap = 6;
    for (int i = 0; i < cap; i++) {
        void *obj = arr->m_Items[i];
        if (obj) return obj;
    }
    return nullptr;
}

static Il2CppString *HBAutoBuildString(uint32_t idx) {
    const char *s = q6a(idx);
    if (!s) s = "";
    return Il2CppString::Create(s);
}

static BOOL HBAutoBuildIsSpinningNow(void) {
    void *slot = HBAutoBuildFindSlotMachine();
    if (!slot || !hbSlotIsSpinning) return NO;
    BOOL spinning = NO;
    @try { spinning = hbSlotIsSpinning(slot) ? YES : NO; } @catch (NSException *e) { spinning = NO; }
    return spinning;
}

static BOOL HBAutoBuildIsSpinningCached(NSTimeInterval now) {
    if (hbAutoBuildLastSpinProbeAt > 0 && now - hbAutoBuildLastSpinProbeAt < 0.25) return hbAutoBuildLastSpinProbeValue;
    hbAutoBuildLastSpinProbeAt = now;
    hbAutoBuildLastSpinProbeValue = HBAutoBuildIsSpinningNow();
    return hbAutoBuildLastSpinProbeValue;
}

static BOOL HBAutoBuildStateIsActionable(int state) {
    return (state == 0 || state == 3 || state == 5) ? YES : NO;
}

static void HBAutoBuildResetSceneStability(void) {
    hbAutoBuildStateStableSince = 0;
    hbAutoBuildLastStableState = -999;
}

static BOOL HBAutoBuildSceneIsStableForAction(int state, void *mainMgr, NSTimeInterval now) {
    if (!mainMgr) { HBAutoBuildResetSceneStability(); return NO; }
    if (HBRaidAutomationEnabled() || hbMagicAutoEnabled || hbMagicRuntimeEnabled) { HBAutoBuildResetSceneStability(); return NO; }
    if (!HBAutoBuildStateIsActionable(state)) { HBAutoBuildResetSceneStability(); return NO; }
    if (hbAutoBuildSafeAfterAt > 0 && now < hbAutoBuildSafeAfterAt) return NO;
    if (HBAutoBuildIsSpinningCached(now)) {
        hbAutoBuildSafeAfterAt = now + 1.05;
        HBAutoBuildResetSceneStability();
        return NO;
    }
    if (hbAutoBuildLastStableState != state) {
        hbAutoBuildLastStableState = state;
        hbAutoBuildStateStableSince = now;
        return NO;
    }
    if (hbAutoBuildStateStableSince <= 0) {
        hbAutoBuildStateStableSince = now;
        return NO;
    }
    double needStable = (state == 5) ? 0.90 : 0.75;
    return (now - hbAutoBuildStateStableSince >= needStable) ? YES : NO;
}

static void HBAutoBuildUnlockPendingSlot(void) {
    if (!hbAutoBuildPendingLocked) return;
    void *slot = HBAutoBuildFindSlotMachine();
    if (slot && hbSlotUnlock) {
        @try { hbSlotUnlock(slot, HBAutoBuildString(131)); } @catch (NSException *e) {}
    }
    hbAutoBuildPendingLocked = NO;
}

static void HBAutoBuildCancelPending(void) {
    if (hbAutoBuildPending || hbAutoBuildPendingLocked) HBAutoBuildUnlockPendingSlot();
    hbAutoBuildPending = NO;
    hbAutoBuildPendingAt = 0;
    hbAutoBuildPendingLastCheckAt = 0;
    HBAutoBuildResetSceneStability();
}

static BOOL HBAutoBuildBeginOrPend(void) {
    HBAutoBuildResolveSlotMachine();
    
    if (HBRaidAutomationEnabled()) return NO;
    void *slot = HBAutoBuildFindSlotMachine();
    BOOL spinning = NO;
    if (slot && hbSlotIsSpinning) {
        @try { spinning = hbSlotIsSpinning(slot) ? YES : NO; } @catch (NSException *e) { spinning = NO; }
    }
    if (!spinning) {
        HBAutoBuildCancelPending();
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        hbAutoBuildSafeAfterAt = now + 0.95;
        HBAutoBuildResetSceneStability();
        return YES;
    }
    
    hbAutoBuildPending = YES;
    hbAutoBuildPendingAt = [NSDate timeIntervalSinceReferenceDate];
    hbAutoBuildPendingLastCheckAt = 0;
    zce119e8048.z7377de64e5 = false;
    if (slot && hbSlotDeactivateAutoSpin) {
        @try { hbSlotDeactivateAutoSpin(slot, HBAutoBuildString(130)); } @catch (NSException *e) {}
    }
    if (slot && hbSlotLock) {
        @try { hbSlotLock(slot, HBAutoBuildString(131)); hbAutoBuildPendingLocked = YES; } @catch (NSException *e) {}
    }
    return NO;
}

static void HBAutoBuildTryFinishPending(void) {
    if (!hbAutoBuildPending) return;
    if (HBRaidAutomationEnabled()) { HBAutoBuildCancelPending(); return; }
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (hbAutoBuildPendingLastCheckAt > 0 && now - hbAutoBuildPendingLastCheckAt < 0.18) return;
    hbAutoBuildPendingLastCheckAt = now;
    if (HBAutoBuildIsSpinningNow()) {
        hbAutoBuildSafeAfterAt = now + 1.05;
        HBAutoBuildResetSceneStability();
        return;
    }
    int state = GetCurrentGameStateSafely();
    if (state == 1 || state == 2) {
        hbAutoBuildSafeAfterAt = now + 1.05;
        HBAutoBuildResetSceneStability();
        return;
    }
    if (state < 0) {
        if (hbAutoBuildPendingAt > 0 && now - hbAutoBuildPendingAt < 7.0) return;
    }
    if (!HBAutoBuildStateIsActionable(state)) {
        hbAutoBuildSafeAfterAt = now + 0.70;
        HBAutoBuildResetSceneStability();
        if (hbAutoBuildPendingAt > 0 && now - hbAutoBuildPendingAt < 7.0) return;
    }
    if (hbAutoBuildSafeAfterAt <= 0) hbAutoBuildSafeAfterAt = now + 1.05;
    void *mainMgr = getMainManagerInstance ? getMainManagerInstance() : nullptr;
    if (!HBAutoBuildSceneIsStableForAction(state, mainMgr, now)) return;
    HBAutoBuildUnlockPendingSlot();
    
    hbAutoBuildPending = NO;
    hbAutoBuildPendingAt = 0;
    hbAutoBuildPendingLastCheckAt = 0;
    MagicCardsModuleResetState();
    zce119e8048.z7377de64e5 = true;
    
    hbAutoBuildSafeAfterAt = now + 0.35;
    HBAutoBuildResetSceneStability();
    q4b2a1();
}

static void HookedSlotMachineSpinComplete(void *ins) {
    if (origSlotMachineSpinComplete) origSlotMachineSpinComplete(ins);
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_slot_spin_complete") object:nil];
    });
    if (hbAutoBuildPending) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            HBAutoBuildTryFinishPending();
        });
    }
}

bool StopSpinForAutoTarget(void) {
    __block BOOL did = NO;
    HBAutoBuildResolveSlotMachine();
    void *slot = HBAutoBuildFindSlotMachine();
    if (!slot) return false;
    if (hbSlotDeactivateAutoSpin) {
        @try { hbSlotDeactivateAutoSpin(slot, HBAutoBuildString(130)); did = YES; } @catch (NSException *e) {}
    }
    if (hbSlotLock) {
        @try { hbSlotLock(slot, HBAutoBuildString(131)); did = YES; } @catch (NSException *e) {}
    }
    if (did && hbSlotUnlock) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            void *slot2 = HBAutoBuildFindSlotMachine();
            if (slot2 && hbSlotUnlock) {
                @try { hbSlotUnlock(slot2, HBAutoBuildString(131)); } @catch (NSException *e) {}
            }
        });
    }
    return did ? true : false;
}


bool SetSlotBetStateForCycle(int state) {
    if (state <= 0) return false;
    H9c4ResolveMethods();
    void *slot = HBAutoBuildFindSlotMachine();
    if (!slot || !h9c4SetBet) return false;
    @try {
        h9c4SetBet(slot, state);
        return true;
    } @catch (NSException *e) {
        return false;
    }
}

int GetSlotBetStateForCycle(void) {
    H9c4ResolveMethods();
    void *slot = HBAutoBuildFindSlotMachine();
    if (!slot || !h9c4GetBet) return -1;
    @try { return h9c4GetBet(slot); }
    @catch (NSException *e) { return -1; }
}

bool SlotIsSpinningForCycle(void) {
    return HBAutoBuildIsSpinningNow() ? true : false;
}

bool PauseAutoSpinForCycle(void) {
    H9c4ResolveMethods();
    void *slot = HBAutoBuildFindSlotMachine();
    if (!slot || !hbSlotDeactivateAutoSpin) return false;
    @try {
        hbSlotDeactivateAutoSpin(slot, HBAutoBuildString(130));
        return true;
    } @catch (NSException *e) {
        return false;
    }
}

bool StartAutoSpinForCycle(void) {
    H9c4ResolveMethods();
    void *slot = HBAutoBuildFindSlotMachine();
    if (!slot || !h9c4SetAutoSpin || !h9c4GetAutoSpin) return false;
    @try {
        h9c4SetAutoSpin(slot, true);
        return h9c4GetAutoSpin(slot) ? true : false;
    } @catch (NSException *e) {
        return false;
    }
}


static void *q5c0 = nullptr;
static void *q5c0Ctrl = nullptr;
static void *q5c2 = nullptr;
static void *q5c3 = nullptr;
static void *q5c4 = nullptr;
static void *q5c5 = nullptr;
static void *q5c6 = nullptr;

static void *q4b0f1(const char *namesp, const char *klass, void **cache) {
    if (*cache) return *cache;
    InitAttackCloseHelpers();
    if (!classGetType || !typeGetObject) return nullptr;
    void *c = Il2CppGetClassType(q6a(0), namesp ? namesp : q6a(1), klass);
    if (!c) return nullptr;
    void *t = classGetType(c);
    if (!t) return nullptr;
    *cache = typeGetObject(t);
    return *cache;
}

static void *q4b0f2(const char *klass, void **cache) {
    return q4b0f1(q6a(1), klass, cache);
}

static void *q4b0f3(void *typeObj) {
    if (!typeObj) return nullptr;
    monoArray<void *> *arr = FindObjectsForType(typeObj);
    if (!arr) return nullptr;
    int cap = arr->getCapacity();
    if (cap > 20) cap = 20;
    for (int i = 0; i < cap; i++) {
        void *o = arr->m_Items[i];
        if (o) return o;
    }
    return nullptr;
}

static void *q4b0f4(void) {
    void *o = q4b0f3(q4b0f2(q6a(16), &q5c0));
    if (o) return o;
    return q4b0f3(q4b0f1(q6a(18), q6a(16), &q5c0));
}

static void *q4b0f5(void) {
    return q4b0f3(q4b0f1(q6a(18), q6a(20), &q5c0Ctrl));
}

static BOOL q4b0f6(void **outObj, BOOL *outController) {
    if (outObj) *outObj = nullptr;
    if (outController) *outController = NO;
    void *view = q4b0f4();
    if (view) {
        if (outObj) *outObj = view;
        return YES;
    }
    void *ctrl = q4b0f5();
    if (ctrl) {
        if (outObj) *outObj = ctrl;
        if (outController) *outController = YES;
        return YES;
    }
    return NO;
}

static void *q4b0f7(void) {
    void *o = nullptr;
    q4b0f6(&o, nullptr);
    return o;
}
static void *q4b0f8(void) { return q4b0f3(q4b0f2(q6a(13), &q5c2)); }
static void *q4b0f9(void) {
    void *o = q4b0f3(q4b0f2(q6a(10), &q5c3));
    if (o) return o;
    return q4b0f3(q4b0f1(q6a(12), q6a(10), &q5c4));
}
static void *q4b1a0(void) { return q4b0f3(q4b0f2(q6a(8), &q5c5)); }
static void *q4b1a1(void) { return q4b0f3(q4b0f2(q6a(21), &q5c6)); }

static NSTimeInterval q5d0 = 0;
static NSTimeInterval q5d1 = 0;
static NSTimeInterval q5d2 = 0;
static NSTimeInterval q5d3 = 0;
static NSTimeInterval q5d4 = 0;
static NSTimeInterval q5d5 = 0;
static NSTimeInterval q5d6 = 0;
static NSTimeInterval q5d7 = 0;
static NSTimeInterval q5d8 = 0;
static NSTimeInterval q5d9 = 0;
static NSTimeInterval q5e0 = 0;
static NSTimeInterval q5e1 = 0;
static NSTimeInterval q5e2 = 0;
static int q5e5 = 0;
static int q5e4 = 0;
static void *q5e3 = nullptr;
static int q5e6 = 0;

static void q4b1a2(NSTimeInterval t) {
    if (t > q5d7) q5d7 = t;
}


static BOOL q4b1a3(NSTimeInterval now) {
    
    
    if (now - q5d6 < q6t(1)) return NO;
    void *vm = q4b1a1();
    if (!vm) return NO;
    q5d6 = now;
    q5d7 = now + q6t(2);
    if (villageMasterRewardCollect) {
        @try { villageMasterRewardCollect(vm); } @catch (NSException *e) {}
        
        return YES;
    }
    if (villageMasterRewardClose) {
        @try { villageMasterRewardClose(vm); } @catch (NSException *e) {}
        
        return YES;
    }
    return NO;
}

static BOOL q4b1a4(NSTimeInterval now) {
    if (now - q5d5 < q6t(3)) return NO;
    void *x = q4b0f8();
    if (!x) return NO;
    if (genericSaleCloseBool) {
        q5d5 = now;
        q5d7 = now + q6t(4);
        @try { genericSaleCloseBool(x, true); } @catch (NSException *e) {}
        
        return YES;
    }
    if (genericSaleBackPressed) {
        q5d5 = now;
        q5d7 = now + q6t(4);
        @try { genericSaleBackPressed(x); } @catch (NSException *e) {}
        
        return YES;
    }
    return NO;
}

static BOOL q4b1a5(NSTimeInterval now) {
    void *chest = nullptr;
    BOOL fromController = NO;
    if (!q4b0f6(&chest, &fromController) || !chest) {
        if (q5e3 && q5e4 > 0) {
            
            q5d7 = now + q6t(5);
            
        }
        q5e4 = 0;
        q5e3 = nullptr;
        q5e2 = 0;
        if (q5e1 > 0 && now > q5e1 + q6t(6)) q5e1 = 0;
        return NO;
    }

    
    if (q5e1 > 0 && now < q5e1) {
        q4b1a2(q5e1 + q6t(7));
        if (now - q5e0 > q6t(7)) {
            q5e0 = now;
            
        }
        return YES;
    }

    void (*skipFn)(void *) = fromController ? openChestCtrlSkip : openChestViewSkip;
    void (*clickFn)(void *) = fromController ? openChestCtrlClick : openChestViewClick;
    const char *q1 = fromController ? q6a(20) : q6a(16); (void)q1;

    if (chest != q5e3) {
        q5e3 = chest;
        q5e4 = 0;
        q5e2 = now + q6t(8);
        q4b1a2(now + q6t(9));
        
        return YES;
    }

    if (now < q5e2) {
        q4b1a2(q5e2 + q6t(7));
        return YES;
    }

    q5d4 = now;
    q4b1a2(now + q6t(11));

    if (q5e4 == 0) {
        q5e4 = 1;
        q5e2 = now + q6t(8);
        if (skipFn) {
            @try { skipFn(chest); } @catch (NSException *e) {}
            
            return YES;
        }
    }

    if (q5e4 == 1) {
        q5e4 = 2;
        q5e2 = now + q6t(10);
        if (skipFn) {
            @try { skipFn(chest); } @catch (NSException *e) {}
            
            return YES;
        }
    }

    if (q5e4 == 2) {
        q5e4 = 3;
        q5e2 = now + q6t(10);
        if (clickFn) {
            @try { clickFn(chest); } @catch (NSException *e) {}
            
            return YES;
        }
    }

    if (q5e4 == 3) {
        q5e4 = 4;
        q5e2 = now + q6t(12);
        if (clickFn) {
            @try { clickFn(chest); } @catch (NSException *e) {}
            
            return YES;
        }
    }

    q5e4++;
    q5e2 = now + q6t(13);
    if (clickFn) {
        @try { clickFn(chest); } @catch (NSException *e) {}
        
        return YES;
    }
    if (skipFn) {
        @try { skipFn(chest); } @catch (NSException *e) {}
        
        return YES;
    }
    return YES;
}

static BOOL q4b1a6(NSTimeInterval now) {
    if (!mapPopupCloseClick || q5d8 <= 0 || now < q5d8) return NO;
    if (now - q5d3 < q6t(14)) return NO;
    void *map = q4b0f9();
    if (!map) return NO;
    q5d3 = now;
    q5d8 = 0;
    q5d7 = now + q6t(15);
    @try { mapPopupCloseClick(map); } @catch (NSException *e) {}
    
    return YES;
}

static BOOL q4b1a7(NSTimeInterval now, void *mainMgr) {
    if (!getReadyToLevelUp || !getReadyToLevelUp(mainMgr)) return NO;
    if (now - q5d2 < q6t(16)) {
        return YES;
    }
    void *vc = q4b1a0();
    if (vc && villageCompleteGoNext) {
        q5d2 = now;
        q5d8 = now + q6t(17);
        q5d7 = now + q6t(18);
        @try { villageCompleteGoNext(vc); } @catch (NSException *e) {}
        
        return YES;
    }
    if (moveToNextVillage) {
        q5d2 = now;
        q5d8 = now + q6t(17);
        q5d7 = now + q6t(18);
        @try { moveToNextVillage(mainMgr); } @catch (NSException *e) {}
        
        return YES;
    }
    return NO;
}

static void q4b1a8(NSTimeInterval now, void *mainMgr, int state) {
    if (!attemptToBuildStructure) return;
    if (now - q5d0 < q6t(19)) return;
    q5d0 = now;
    int idx = q6slot(&q5e5);
    @try { attemptToBuildStructure(mainMgr, idx, true, nullptr, nullptr, nullptr, true); } @catch (NSException *e) {  }
}

static void q4b1a9(NSTimeInterval now, void *mainMgr, int state) {
    if (!mainManagerSwipeDown && !mainManagerSwipeUp) return;
    if (now - q5d1 < q6t(20)) return;
    if (now - q5d0 < q6t(21)) return;
    q5d1 = now;
    q5d7 = now + q6t(22);
    if (mainManagerSwipeDown) {
        @try { mainManagerSwipeDown(mainMgr); } @catch (NSException *e) {}
    } else {
        @try { mainManagerSwipeUp(mainMgr); } @catch (NSException *e) {}
    }
}

static void q4b2a0(int state, void *mainMgr) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (!mainMgr || state < 0) {  return; }
    if (!HBAutoBuildSceneIsStableForAction(state, mainMgr, now)) { return; }
    if (!OngnongJobTake(ONGNONG_JOB_BUILD, 0.30)) { return; }
    if (zCoreInstallAt > 0 && now - zCoreInstallAt < q6t(0)) {
        return;
    }

    
    if (q4b1a3(now)) {  return; }
    if (q4b1a4(now)) {  return; }
    if (q4b1a5(now)) { return; }

    if (getReadyToLevelUp && getReadyToLevelUp(mainMgr)) {
        if (q5e1 <= 0 || now > q5e1 + q6t(6)) {
            q5e1 = now + q6t(2);
            q4b1a2(now + q6t(9));
            
        }
        if (now - q5e0 > q6t(2)) {
            q5e0 = now;
            
        }
        return;
    }

    if (q4b0f9() || q4b1a0()) {
        if (now - q5e0 > q6t(23)) {
            q5e0 = now;
            
        }
        return;
    }

    if (now < q5d7) { return; }

    if (state == 0 || state == 3) {
        q4b1a8(now, mainMgr, state);
        return;
    }

    if (state == 5) {
        
        q4b1a9(now, mainMgr, state);
        return;
    }
}

static void AutoClickOpenCardsChest(void *ins);

static void HBResolveRaidOpenCardsTypeIfNeeded(void) {
    if (hbRaidOpenCardsChestPopupType || !classGetType || !typeGetObject) return;
    void *klass = Il2CppGetClassType(q6a(0), q6a(1), OngnongOpenCardsClassName());
    if (!klass) return;
    void *type = classGetType(klass);
    if (type) hbRaidOpenCardsChestPopupType = typeGetObject(type);
}

static void *HBFindFirstObjectEx(void *typeObj, bool includeInactive, int maxCount) {
    if (!typeObj) return nullptr;
    monoArray<void *> *arr = HBFindObjectsForTypeEx(typeObj, includeInactive);
    if (!arr) return nullptr;
    int cap = arr->getCapacity();
    if (cap > maxCount) cap = maxCount;
    for (int i = 0; i < cap; i++) {
        void *obj = arr->m_Items[i];
        if (obj) return obj;
    }
    return nullptr;
}

static BOOL HBIsRaidChestReason(const char *reason) {
    (void)reason;
    return YES;
}

static BOOL HBTryAutoRaidChestPopup(const char *reason, int state) {
    if (!HBPigModuleEnabled()) return NO;
    if (!HBIsRaidChestReason(reason)) return NO;
    if (state != 1 && state != 2 && state != 5) return NO;
    HBResolveRaidOpenCardsTypeIfNeeded();
    if (!hbRaidOpenCardsChestPopupType || !raidOpenCardsChestNextStateClicked || !raidOpenCardsChestCloseButtonClicked) return NO;
    if (autoCardChestRunning) return YES;

    void *obj = HBFindFirstObjectEx(hbRaidOpenCardsChestPopupType, false, 8);
    if (!obj) return NO;

    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (obj == hbLastRaidChestAutoObj && now - hbLastRaidChestAutoAt < 0.75) return YES;
    hbLastRaidChestAutoObj = obj;
    hbLastRaidChestAutoAt = now;
    lastOpenCardsChestPopup = obj;
    ((void)0);
    AutoClickOpenCardsChest(obj);
    return YES;
}

static int HBCountObjects(const char *tag, void *typeObj, bool includeInactive, int maxDump) {
    InitAttackCloseHelpers();
    monoArray<void *> *arr = HBFindObjectsForTypeEx(typeObj, includeInactive);
    int cap = arr ? arr->getCapacity() : 0;
    ((void)0);
    if (arr) {
        int dump = cap;
        if (dump > maxDump) dump = maxDump;
        for (int i = 0; i < dump; i++) {
            void *obj = arr->m_Items[i];
            if (obj) ((void)0);
        }
    }
    return cap;
}

static void HBChestScanOnce(const char *reason, int step) {
    if (!HBPigModuleEnabled()) return;
    int state = GetCurrentGameStateSafely();
    ((void)0);

    NSTimeInterval seenNow = [NSDate timeIntervalSinceReferenceDate];
    if (seenNow - hbLastRaidChestSeenAt > 2.0) {
        hbLastRaidChestSeenAt = seenNow;
        ((void)0);
        ((void)0);
    }

    HBResolveRaidOpenCardsTypeIfNeeded();
    int openCount = 0;
    if (hbRaidOpenCardsChestPopupType) {
        openCount += HBCountObjects(q6a(77), hbRaidOpenCardsChestPopupType, false, 2);
    }
    if (openCount > 0) {
        ((void)0);
        HBTryAutoRaidChestPopup(reason, state);
    }

    if (hbRewardFoundPopupType) {
        int c1 = HBCountObjects(q6a(60), hbRewardFoundPopupType, false, 4);
        int c2 = HBCountObjects(q6a(60), hbRewardFoundPopupType, true, 4);
        if ((c1 + c2) > 0) ((void)0);
    }

    if (hbRewardReceivedPopupType) {
        int c1 = HBCountObjects(q6a(61), hbRewardReceivedPopupType, false, 4);
        int c2 = HBCountObjects(q6a(61), hbRewardReceivedPopupType, true, 4);
        if ((c1 + c2) > 0) ((void)0);
    }

    if (hbGenericRewardPopupType) {
        int c1 = HBCountObjects(q6a(58), hbGenericRewardPopupType, false, 4);
        int c2 = HBCountObjects(q6a(58), hbGenericRewardPopupType, true, 4);
        if ((c1 + c2) > 0) ((void)0);
    }

    if (hbRaidMainViewType) HBCountObjects(q6a(63), hbRaidMainViewType, false, 3);

    if (hbMultipleChestsPopupType) {
        int c1 = HBCountObjects(q6a(65), hbMultipleChestsPopupType, false, 3);
        int c2 = HBCountObjects(q6a(65), hbMultipleChestsPopupType, true, 3);
        if ((c1 + c2) > 0) ((void)0);
    }

    if (hbCardsStoreChestInfoPopupType) {
        int c1 = HBCountObjects(q6a(66), hbCardsStoreChestInfoPopupType, false, 3);
        int c2 = HBCountObjects(q6a(66), hbCardsStoreChestInfoPopupType, true, 3);
        if ((c1 + c2) > 0) ((void)0);
    }

    ((void)0);
}

static void HBHammerModuleTick(int state);
static BOOL HBHammerModuleOwnsState(int state);
static void ScheduleAutoAttackCloseSummary(void);

static void HBMagicChestScanSchedule(const char *reason, double delay, int repeat);
static void HBMagicChestScanStep(const char *reason, double interval, int step, int repeat);
static void HBMagicChestEnsureAutoButton(void);
static void HBMagicChestUpdateAutoButton(void);
static void HBMagicChestAutoSchedule(double delay);
static void HBMagicChestAutoTick(void);
static void HBMagicChestAutoStepOnce(int tickNo);
static void HBMagicChestAutoTap(CGFloat xr, CGFloat yr, const char *reason);
static BOOL HBMagicChestAutoFindAndRun(void);
static void HBResolveMagicChestOffsetsSafe(const char *reason);
static void *HBMagicFindCardsCollectionPopup(void);
static void *HBMagicFindCardsScreenView(void);
static BOOL HBMagicAutoNavigateToStore(void);

static void HBChestScanScheduleStep(const char *reason, int session, int step, int repeat) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.18 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!HBPigModuleEnabled() || session != hbChestScanSession) { hbChestScanRunning = NO; return; }
        @autoreleasepool {
            HBChestScanOnce(reason, step);
        }
        hbChestLastScanAt = [NSDate timeIntervalSinceReferenceDate];
        if (step + 1 < repeat) {
            HBChestScanScheduleStep(reason, session, step + 1, repeat);
        } else {
            hbChestScanRunning = NO;
        }
    });
}

static void HBChestScanSchedule(const char *reason, double delay, int repeat) {
    if (!HBPigModuleEnabled() || repeat <= 0) return;
    int curStateForChest = GetCurrentGameStateSafely();
    (void)curStateForChest;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (hbChestScanRunning && now - hbChestLastScanAt < 0.22) return;
    if (!hbChestScanRunning && now - hbChestLastScanAt < 0.12) return;
    hbChestScanRunning = YES;
    hbChestLastScanAt = now;
    int session = ++hbChestScanSession;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!HBPigModuleEnabled() || session != hbChestScanSession) { hbChestScanRunning = NO; return; }
        @autoreleasepool {
            HBChestScanOnce(reason, 0);
        }
        hbChestLastScanAt = [NSDate timeIntervalSinceReferenceDate];
        if (repeat > 1) {
            HBChestScanScheduleStep(reason, session, 1, repeat);
        } else {
            hbChestScanRunning = NO;
        }
    });
}

static void *HBFindFirstObject(void *typeObj, int maxCount);
static void HBObserveOkHintByState(int state, NSTimeInterval now, const char *reason);

static BOOL HBHammerModuleOwnsState(int state) {
    if (!HBAutoHammerEnabled()) return NO;
    if (state == 2) return NO;
    return state == 1 || hbHammerTargetObj != nullptr || hbHammerTargetClickedAt > 0;
}

static void *HBHammerFindTargetLight(void) {
    void *current = HBFindFirstObject(hbAttackTargetControlType, 4);
    if (current) return current;
    return lastAttackTargetControl;
}

static void HBHammerBindTarget(void *target);

static BOOL HBHammerTryClickTargetLight(int state, NSTimeInterval now) {
    if (!HBAutoHammerEnabled() || !attackTargetOnAttackClicked) return NO;
    void *target = HBHammerFindTargetLight();
    if (!target) return NO;
    if (target != hbHammerTargetObj) {
        HBHammerBindTarget(target);
        return YES;
    }
    if (hbHammerTargetSeenAt <= 0 || now - hbHammerTargetSeenAt < 2.00) return YES;
    if (hbHammerTargetClickedAt > 0 && now - hbHammerTargetClickedAt < 1.80) return YES;
    if (hbHammerRetryCount >= 6) {
        hbHammerTargetObj = nullptr;
        hbHammerTargetSeenAt = 0;
        hbHammerTargetClickedAt = 0;
        hbHammerRetryCount = 0;
        lastAttackTargetControl = nullptr;
        autoAttackClicked = false;
        return YES;
    }
    hbHammerTargetClickedAt = now;
    hbHammerRetryCount++;
    hbLastAttackClickedObj = target;
    hbLastAttackClickAt = now;
    lastAttackTargetControl = target;
    autoAttackClicked = true;
    @try {
        attackTargetOnAttackClicked(target);
    } @catch (NSException *e) {
    }
    ScheduleAutoAttackCloseSummary();
    return YES;
}

static BOOL HBHammerTryCloseSummaryLight(NSTimeInterval now) {
    if (!HBAutoHammerEnabled()) return NO;
    if (now - hbHammerLastSummaryScanAt < 0.75) return NO;
    hbHammerLastSummaryScanAt = now;

    InitAttackCloseHelpers();
    void *popup = nullptr;
    if (hbBaseSummaryOnClick && hbBaseRaidAttackSummaryType) {
        popup = HBFindFirstObject(hbBaseRaidAttackSummaryType, 4);
        if (popup && !(popup == hbHammerLastClosedSummaryObj && now - hbHammerLastClosedSummaryAt < 1.15)) {
            hbHammerLastClosedSummaryObj = popup;
            hbHammerLastClosedSummaryAt = now;
            if (OngnongJobTake(ONGNONG_JOB_RAID, 0.35)) {
                @try { hbBaseSummaryOnClick(popup); } @catch (NSException *e) { ((void)0); }
            }
            autoAttackClicked = false;
            lastAttackTargetControl = nullptr;
            hbHammerTargetObj = nullptr;
                                    OngnongJobDrop(ONGNONG_JOB_RAID);
            return YES;
        }
    }

    if (directAttackSummaryClose && attackSummaryPopupType) {
        popup = HBFindFirstObject(attackSummaryPopupType, 4);
        if (popup && !(popup == hbHammerLastClosedSummaryObj && now - hbHammerLastClosedSummaryAt < 1.15)) {
            hbHammerLastClosedSummaryObj = popup;
            hbHammerLastClosedSummaryAt = now;
            if (OngnongJobTake(ONGNONG_JOB_RAID, 0.35)) {
                @try { directAttackSummaryClose(popup); } @catch (NSException *e) { ((void)0); }
            }
            autoAttackClicked = false;
            lastAttackTargetControl = nullptr;
            hbHammerTargetObj = nullptr;
                                    OngnongJobDrop(ONGNONG_JOB_RAID);
            return YES;
        }
    }
    return NO;
}

static void HBHammerModuleTick(int state) {
    if (!HBAutoHammerEnabled()) { HBHammerModuleResetState(); return; }
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    @autoreleasepool {
        if (state == 1 || hbHammerTargetObj) HBHammerTryClickTargetLight(state, now);
        if (hbHammerTargetClickedAt > 0 || autoSummaryCloseRunning) HBHammerTryCloseSummaryLight(now);
    }
}

static bool AutoAttackCloseSummaryByGameFunc() {
    InitAttackCloseHelpers();
    bool did = false;

    if (directAttackAnimationAbort && attackMainAnimationType) {
        for (int pass = 0; pass < 2 && !did; pass++) {
            bool includeInactive = (pass == 1);
            monoArray<void *> *arr = HBFindObjectsForTypeEx(attackMainAnimationType, includeInactive);
            int cap = arr ? arr->getCapacity() : 0;
            if (cap > 8) cap = 8;
            ((void)0);
            if (arr) {
                for (int i = 0; i < cap; i++) {
                    void *anim = arr->m_Items[i];
                    if (anim) {
                        ((void)0);
                        @try { directAttackAnimationAbort(anim); } @catch (NSException *e) { ((void)0); }
                        did = true;
                        break;
                    }
                }
            }
        }
    }

    if (directAttackSummaryClose && attackSummaryPopupType) {
        for (int pass = 0; pass < 2; pass++) {
            bool includeInactive = (pass == 1);
            monoArray<void *> *arr = HBFindObjectsForTypeEx(attackSummaryPopupType, includeInactive);
            int cap = arr ? arr->getCapacity() : 0;
            if (cap > 12) cap = 12;
            ((void)0);
            if (arr) {
                for (int i = 0; i < cap; i++) {
                    void *popup = arr->m_Items[i];
                    if (popup) {
                        ((void)0);
                        @try { directAttackSummaryClose(popup); } @catch (NSException *e) { ((void)0); }
                        autoAttackClicked = false;
                        lastAttackTargetControl = nullptr;
                        did = true;
                        break;
                    }
                }
            }
            if (did) break;
        }
    }

    return did;
}

static void ProcessAutoAttackCloseStep(int step) {
    if (!HBAutoHammerEnabled() || !autoSummaryCloseRunning) return;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    int closeState = GetCurrentGameStateSafely();
    if (closeState != 2 && HBHammerModuleOwnsState(closeState)) {
        BOOL closedLight = HBHammerTryCloseSummaryLight(now);
        if (closedLight || step > 8) { autoSummaryCloseRunning = false; return; }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.55 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            ProcessAutoAttackCloseStep(step + 1);
        });
        return;
    }

    bool closed = AutoAttackCloseSummaryByGameFunc();
    if (closed || step > 18) {
        ((void)0);
        autoSummaryCloseRunning = false;
        return;
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        ProcessAutoAttackCloseStep(step + 1);
    });
}

static void ScheduleAutoAttackCloseSummary() {
    if (!HBAutoHammerEnabled()) return;
    if (autoSummaryCloseRunning) {
        ((void)0);
        return;
    }
    ((void)0);
    autoSummaryCloseRunning = true;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        ProcessAutoAttackCloseStep(0);
    });
}

static void *HBFindFirstObject(void *typeObj, int maxCount) {
    if (!typeObj) return nullptr;
    monoArray<void *> *arr = FindObjectsForType(typeObj);
    if (!arr) return nullptr;
    int cap = arr->getCapacity();
    if (cap > maxCount) cap = maxCount;
    for (int i = 0; i < cap; i++) {
        void *obj = arr->m_Items[i];
        if (obj) return obj;
    }
    return nullptr;
}

static void HBObserveOkHintByState(int state, NSTimeInterval now, const char *reason) {
    if (!HBRaidAutomationEnabled()) return;
    if (state != 1 && state != 2 && state != 3 && state != 4 && state != 5) return;
    if (state == hbLastOkHintState && now - hbLastOkHintSeenAt < 1.25) return;
    hbLastOkHintState = state;
    hbLastOkHintSeenAt = now;
    ((void)0);
}


static MethodInfo *HBFindPigSummaryClickSemantic(
    const char *namespaze,
    const char *clazz) {

    typedef void *(*ClassGetMethodsFn)(void *, void **);
    typedef const char *(*MethodGetNameFn)(void *);
    typedef uint32_t (*MethodGetParamCountFn)(void *);
    typedef void *(*ClassGetParentFn)(void *);

    static ClassGetMethodsFn classGetMethods =
        (ClassGetMethodsFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_methods"));
    static MethodGetNameFn methodGetName =
        (MethodGetNameFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_get_name"));
    static MethodGetParamCountFn methodGetParamCount =
        (MethodGetParamCountFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_get_param_count"));
    static ClassGetParentFn classGetParent =
        (ClassGetParentFn)dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_parent"));

    if (!classGetMethods || !methodGetName || !methodGetParamCount) {
        return nullptr;
    }

    void *klass = Il2CppGetClassType(q6a(0), namespaze, clazz);
    if (!klass) return nullptr;

    MethodInfo *best = nullptr;
    int bestScore = 0;

    for (void *current = klass, *next = nullptr;
         current;
         current = next) {
        next = classGetParent ? classGetParent(current) : nullptr;

        void *iter = nullptr;
        while (void *raw = classGetMethods(current, &iter)) {
            const char *name = methodGetName(raw);
            if (!name || methodGetParamCount(raw) != 0) continue;
            if (strchr(name, '<') || strstr(name, OX_C("Internal"))) continue;

            int score = 0;
            const BOOL hasClick =
                strstr(name, OX_C("Click")) ||
                strstr(name, OX_C("Pressed")) ||
                strstr(name, OX_C("Press"));
            if (strstr(name, OX_C("Summary")) && hasClick) score = 100;
            else if (strstr(name, OX_C("Continue")) && hasClick) score = 95;
            else if (strstr(name, OX_C("Confirm")) && hasClick) score = 90;
            else if ((strstr(name, OX_C("Ok")) || strstr(name, OX_C("OK"))) && hasClick) score = 85;

            MethodInfo *candidate = reinterpret_cast<MethodInfo *>(raw);
            if (score > bestScore && candidate && candidate->methodPointer) {
                best = candidate;
                bestScore = score;
            }
        }

        
        if (current != klass) break;
    }

    return bestScore >= 85 ? best : nullptr;
}


static void HBResolvePigSummaryMethodsIfNeeded(void) {
    if (hbRaidSummaryScreenClickMethod && hbRaidSummaryPopupClickMethod) return;

    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now < hbPigSummaryNextResolveAt) return;
    hbPigSummaryNextResolveAt = now + 1.0;

    Attach();

    if (!hbRaidSummaryScreenClickMethod) {
        static const char *names[] = {
            "OnSummaryScreenClicked",
            "OnSummaryClicked",
            "OnContinueClicked",
            "ContinueButtonClicked",
            "OnOkClicked",
            "OkButtonClicked"
        };
        for (const char *name : names) {
            MethodInfo *m = Il2CppFindMethodInfo(
                q6a(0),
                OX_C("MoonActive.Raid.UI.UpperHUD"),
                OX_C("RaidSummaryScreen"),
                name,
                0,
                true);
            if (m && m->methodPointer) {
                hbRaidSummaryScreenClickMethod = m;
                break;
            }
        }
        if (!hbRaidSummaryScreenClickMethod) {
            hbRaidSummaryScreenClickMethod =
                HBFindPigSummaryClickSemantic(
                    OX_C("MoonActive.Raid.UI.UpperHUD"),
                    OX_C("RaidSummaryScreen"));
        }
    }

    if (!hbRaidSummaryPopupClickMethod) {
        static const char *names[] = {
            "OnSummaryScreenClicked",
            "OnSummaryClicked",
            "OnContinueClicked",
            "ContinueButtonClicked",
            "OnOkClicked",
            "OkButtonClicked"
        };
        for (const char *name : names) {
            MethodInfo *m = Il2CppFindMethodInfo(
                q6a(0),
                OX_C("MoonActive.Raid.UI"),
                OX_C("RaidSummaryScreenPopup"),
                name,
                0,
                true);
            if (m && m->methodPointer) {
                hbRaidSummaryPopupClickMethod = m;
                break;
            }
        }
        if (!hbRaidSummaryPopupClickMethod) {
            hbRaidSummaryPopupClickMethod =
                HBFindPigSummaryClickSemantic(
                    OX_C("MoonActive.Raid.UI"),
                    OX_C("RaidSummaryScreenPopup"));
        }
    }
}

static void HBResolvePigSummaryTypesIfNeeded(void) {
    InitAttackCloseHelpers();

    
    if (!classGetType) {
        classGetType =
            (Il2CppClassGetTypeFn)dlsym(RTLD_DEFAULT, q6a(123));
    }
    if (!typeGetObject) {
        typeGetObject =
            (Il2CppTypeGetObjectFn)dlsym(RTLD_DEFAULT, q6a(124));
    }
    if (!classGetType || !typeGetObject) return;

    if (!hbRaidSummaryScreenType) {
        void *klass = Il2CppGetClassType(
            q6a(0), OX_C("MoonActive.Raid.UI.UpperHUD"), OX_C("RaidSummaryScreen"));
        if (klass) {
            void *type = classGetType(klass);
            if (type) hbRaidSummaryScreenType = typeGetObject(type);
        }
    }

    if (!hbRaidSummaryPopupType) {
        void *klass = Il2CppGetClassType(
            q6a(0), OX_C("MoonActive.Raid.UI"), OX_C("RaidSummaryScreenPopup"));
        if (klass) {
            void *type = classGetType(klass);
            if (type) hbRaidSummaryPopupType = typeGetObject(type);
        }
    }
}

static BOOL HBTryClickPigSummaryAnyState(NSTimeInterval now) {
    if (!HBPigModuleEnabled()) return NO;

    HBResolvePigSummaryTypesIfNeeded();
    HBResolvePigSummaryMethodsIfNeeded();

    
    if (hbRaidSummaryScreenType && hbRaidSummaryScreenClickMethod) {
        void *screen = HBFindFirstObject(hbRaidSummaryScreenType, 8);
        if (screen) {
            if (screen == hbLastPigSummaryClicked &&
                now - hbLastPigSummaryClickAt < 1.35) {
                return YES;
            }
            hbLastPigSummaryClicked = screen;
            hbLastPigSummaryClickAt = now;
            void *exception = nullptr;
            @try {
                Il2CppRuntimeInvoke(
                    hbRaidSummaryScreenClickMethod,
                    screen,
                    nullptr,
                    &exception);
            } @catch (NSException *e) { exception = reinterpret_cast<void *>(1); }
            if (exception) {
                hbLastPigSummaryClicked = nullptr;
                return NO;
            }
            hbPigPauseUntil = now + 1.5;
            return YES;
        }
    }

    
    if (hbRaidSummaryPopupType && hbRaidSummaryPopupClickMethod) {
        void *popup = HBFindFirstObject(hbRaidSummaryPopupType, 8);
        if (popup) {
            if (popup == hbLastPigSummaryClicked &&
                now - hbLastPigSummaryClickAt < 1.35) {
                return YES;
            }
            hbLastPigSummaryClicked = popup;
            hbLastPigSummaryClickAt = now;
            void *exception = nullptr;
            @try {
                Il2CppRuntimeInvoke(
                    hbRaidSummaryPopupClickMethod,
                    popup,
                    nullptr,
                    &exception);
            } @catch (NSException *e) { exception = reinterpret_cast<void *>(1); }
            if (exception) {
                hbLastPigSummaryClicked = nullptr;
                return NO;
            }
            hbPigPauseUntil = now + 1.5;
            return YES;
        }
    }

    hbLastPigSummaryClicked = nullptr;
    return NO;
}

static BOOL HBTryClickSummaryPopup(int state, NSTimeInterval now) {
    if (!HBRaidAutomationEnabled() || !hbBaseSummaryOnClick) return NO;
    if (state != 1 && state != 2) return NO;
    InitAttackCloseHelpers();
    void *popup = HBFindFirstObject(hbBaseRaidAttackSummaryType, 8);
    if (!popup) return NO;
    if (popup == hbLastSummaryClicked && now - hbLastSummaryClickAt < 1.2) return YES;
    hbLastSummaryClicked = popup;
    hbLastSummaryClickAt = now;
    ((void)0);
    @try { hbBaseSummaryOnClick(popup); } @catch (NSException *e) { ((void)0); }
    return YES;
}

static BOOL HBTryCollectGenericReward(int state, NSTimeInterval now) {
    if (!HBRaidAutomationEnabled()) return NO;
    if (state != 1 && state != 2) return NO;
    if (!hbGenericRewardCollect && !hbGenericRewardClose) return NO;
    InitAttackCloseHelpers();
    void *popup = HBFindFirstObject(hbGenericRewardPopupType, 8);
    if (!popup) return NO;
    if (popup == hbLastRewardClicked && now - hbLastRewardClickAt < 1.0) return YES;
    hbLastRewardClicked = popup;
    hbLastRewardClickAt = now;
    ((void)0);
    if (hbGenericRewardCollect) { @try { hbGenericRewardCollect(popup); } @catch (NSException *e) { ((void)0); } }
    else if (hbGenericRewardClose) { @try { hbGenericRewardClose(popup); } @catch (NSException *e) { ((void)0); } }
    return YES;
}

bool AutoMergeTryCollectPendingReward() {
    InitAttackCloseHelpers();
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];

    if (hbRewardFoundPopupType && hbRewardFoundClaim) {
        void *popup = HBFindFirstObject(hbRewardFoundPopupType, 8);
        if (popup && !(popup == hbLastRewardClicked && now - hbLastRewardClickAt < 0.45)) {
            hbLastRewardClicked = popup;
            hbLastRewardClickAt = now;
            @try { hbRewardFoundClaim(popup); } @catch (NSException *e) {}
            return true;
        }
    }

    if (hbGenericRewardPopupType && (hbGenericRewardCollect || hbGenericRewardClose)) {
        void *popup = HBFindFirstObject(hbGenericRewardPopupType, 8);
        if (popup && !(popup == hbLastRewardClicked && now - hbLastRewardClickAt < 0.45)) {
            hbLastRewardClicked = popup;
            hbLastRewardClickAt = now;
            @try {
                if (hbGenericRewardCollect) hbGenericRewardCollect(popup);
                else hbGenericRewardClose(popup);
            } @catch (NSException *e) {}
            return true;
        }
    }

    if (hbRewardReceivedPopupType && hbRewardReceivedClose) {
        void *popup = HBFindFirstObject(hbRewardReceivedPopupType, 8);
        if (popup && !(popup == hbLastRewardClicked && now - hbLastRewardClickAt < 0.45)) {
            hbLastRewardClicked = popup;
            hbLastRewardClickAt = now;
            @try { hbRewardReceivedClose(popup); } @catch (NSException *e) {}
            return true;
        }
    }
    return false;
}

static BOOL HBTryFallbackAttackTarget(int state, NSTimeInterval now) {
    return HBHammerTryClickTargetLight(state, now);
}

static void HBAndroidPigFinish(int session, const char *reason) {
    if (session != hbAndroidPigSession) return;
    (void)reason;
    hbAndroidPigScheduled = NO;
    hbAndroidPigRunning = NO;
    hbAndroidPigLastEndAt = [NSDate timeIntervalSinceReferenceDate];
    hbPigDigRequested = 0;
    hbPigDigFinished = 0;
    hbPigDigInFlight = NO;
    hbPigViewReadyForNextDig = NO;
    hbPigLastDigRequestAt = 0;
    hbPigLastResultCount = -1;
    hbPigResultRetryCount = 0;
    hbPigServiceRetryCount = 0;
    hbPigScheduleRetryCount = 0;
    hbPigScheduleRetryArmed = NO;
    hbPigRaidMainViewInstance = nullptr;
    hbRaidServiceInstance = nullptr;
    autoRaidDigPoint = 0;
    OngnongJobDrop(ONGNONG_JOB_RAID);
}

static void HBPigRequestNext(int session, double delay);

static void HBPigPollDigResult(int session, int baseline, NSTimeInterval startedAt) {
    if (!HBPigModuleEnabled() || session != hbAndroidPigSession || !hbAndroidPigRunning) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!HBPigModuleEnabled() || session != hbAndroidPigSession || !hbAndroidPigRunning) return;
        int nowCount = HBPigReadResultCount(hbPigRaidMainViewInstance);
        if (nowCount >= 0 && baseline >= 0 && nowCount > baseline) {
            hbPigLastResultCount = nowCount;
            hbPigResultRetryCount = 0;
            hbPigServiceRetryCount = 0;
            if (hbPigDigFinished < hbPigDigRequested) hbPigDigFinished = hbPigDigRequested;
            hbPigDigInFlight = NO;
            hbPigViewReadyForNextDig = YES;
            if (hbPigDigFinished >= 3) {
                HBChestScanSchedule(q6a(1), 0.10, 8);
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (session != hbAndroidPigSession || !hbAndroidPigRunning) return;
                    HBAndroidPigFinish(session, q6a(1));
                });
                return;
            }
            HBPigRequestNext(session, 0.50);
            return;
        }
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        if (now - startedAt >= 6.5) {
            hbPigResultRetryCount++;
            hbPigDigInFlight = NO;
            hbPigViewReadyForNextDig = YES;
            if (hbPigDigRequested > hbPigDigFinished) hbPigDigRequested = hbPigDigFinished;
            void *freshView = HBFindFirstObject(hbRaidMainViewType, 6);
            if (freshView && freshView != hbPigRaidMainViewInstance) {
                hbPigRaidMainViewInstance = freshView;
                hbPigLastResultCount = HBPigReadResultCount(freshView);
            }
            HBPigRefreshServiceFromSlot();
            if (hbPigResultRetryCount <= 4) {
                HBPigRequestNext(session, 0.55);
            } else {
                hbAndroidPigScheduled = NO;
                hbAndroidPigRunning = NO;
                hbPigDigRequested = 0;
                hbPigDigFinished = 0;
                hbPigResultRetryCount = 0;
                hbPigServiceRetryCount = 0;
                OngnongJobDrop(ONGNONG_JOB_RAID);
            }
            return;
        }
        HBPigPollDigResult(session, baseline, startedAt);
    });
}

static void HBPigRequestNext(int session, double delay) {
    if (!HBPigModuleEnabled() || session != hbAndroidPigSession) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!HBPigModuleEnabled() || session != hbAndroidPigSession || !hbAndroidPigRunning) return;
        if (!hbPigViewReadyForNextDig || hbPigDigInFlight) {
            return;
        }
        if (hbPigDigRequested >= 3 || hbPigDigFinished >= 3) return;
        if (hbPigDigRequested != hbPigDigFinished) {
            hbPigDigRequested = hbPigDigFinished;
        }
        HBPigRefreshServiceFromSlot();
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        if (hbPigLastDigRequestAt > 0) {
            double elapsed = now - hbPigLastDigRequestAt;
            if (elapsed < hbPigMinDigInterval) {
                HBPigRequestNext(session, hbPigMinDigInterval - elapsed);
                return;
            }
        }
        if (!hbRaidServiceInstance || !hbRaidServiceStealFromDigPoint) {
            hbPigServiceRetryCount++;
            if (hbPigServiceRetryCount <= 20) {
                HBPigRequestNext(session, 0.35);
            } else {
                hbAndroidPigScheduled = NO;
                hbAndroidPigRunning = NO;
                hbPigServiceRetryCount = 0;
                OngnongJobDrop(ONGNONG_JOB_RAID);
            }
            return;
        }
        hbPigServiceRetryCount = 0;
        int baseline = HBPigReadResultCount(hbPigRaidMainViewInstance);
        int point = hbPigDigRequested;
        hbPigDigRequested++;
        hbPigDigInFlight = YES;
        hbPigViewReadyForNextDig = NO;
        hbPigLastDigRequestAt = now;
        hbPigLastResultCount = baseline;
        autoRaidDigPoint = point;
        @try {
            hbRaidServiceStealFromDigPoint(hbRaidServiceInstance, point, nullptr);
            HBPigPollDigResult(session, baseline, now);
        } @catch (NSException *e) {
            hbPigDigRequested--;
            hbPigDigInFlight = NO;
            hbPigViewReadyForNextDig = YES;
        }
    });
}

static void HBPigStartForView(void *view, double delay) {
    HBPigRefreshServiceFromSlot();
    if (!HBPigModuleEnabled() || !view || !hbRaidServiceInstance || !hbRaidServiceStealFromDigPoint) return;
    hbAndroidPigSession++;
    int session = hbAndroidPigSession;
    hbPigRaidMainViewInstance = view;
    hbPigDigRequested = 0;
    hbPigDigFinished = 0;
    hbPigDigInFlight = NO;
    hbPigViewReadyForNextDig = YES;
    hbPigLastDigRequestAt = 0;
    hbPigLastResultCount = HBPigReadResultCount(view);
    hbPigResultRetryCount = 0;
    hbPigServiceRetryCount = 0;
    hbPigScheduleRetryCount = 0;
    hbPigScheduleRetryArmed = NO;
    if (!OngnongJobTake(ONGNONG_JOB_RAID, 10.0)) return;
    hbAndroidPigScheduled = YES;
    hbAndroidPigRunning = YES;
    hbAndroidPigLastScheduleAt = [NSDate timeIntervalSinceReferenceDate];
    HBPigRequestNext(session, delay);
}

static void HookedRaidServiceSwitchToSteal(void *ins, void *raidInfo, void *analyticsParams, void *method) {
    if (ins) hbRaidServiceInstance = ins;
    void *inner = nullptr;
    if (ins) inner = *(void **)((uintptr_t)ins + 0x10);
    if (origRaidServiceSwitchToSteal) origRaidServiceSwitchToSteal(ins, raidInfo, analyticsParams, method);
}

static void HookedRaidServiceFinishedSuccessfulDig(void *ins, void *method) {
    if (origRaidServiceFinishedSuccessfulDig) origRaidServiceFinishedSuccessfulDig(ins, method);
    if (!HBPigModuleEnabled() || !hbAndroidPigRunning || ins != hbRaidServiceInstance) return;
    if (hbPigDigFinished < hbPigDigRequested) hbPigDigFinished++;
    hbPigDigInFlight = NO;
    HBChestScanSchedule(q6a(1), 0.10, 3);
    if (hbPigDigFinished >= 3) {
        int session = hbAndroidPigSession;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (session != hbAndroidPigSession) return;
            HBChestScanSchedule(q6a(1), 0.05, 5);
            HBAndroidPigFinish(session, q6a(1));
        });
        return;
    }
    HBPigRequestNext(hbAndroidPigSession, 0.50);
}

static void HookedRaidMainResetForNewRaid(void *ins, void *method) {
    if (origRaidMainResetForNewRaid) origRaidMainResetForNewRaid(ins, method);
    if (HBPigModuleEnabled() && hbRaidServiceInstance && hbRaidServiceStealFromDigPoint) HBPigStartForView(ins, 1.00);
}

static void HookedRaidMainDigComplete(void *ins, void *method) {
    if (origRaidMainDigComplete) origRaidMainDigComplete(ins, method);
    if (!HBPigModuleEnabled() || !hbAndroidPigRunning) return;
    if (ins != hbPigRaidMainViewInstance) {
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        BOOL recent = hbPigLastDigRequestAt > 0 && now - hbPigLastDigRequestAt <= 5.0;
        if (!recent || hbPigDigInFlight || hbPigDigRequested != hbPigDigFinished || hbPigDigRequested <= 0 || hbPigDigRequested >= 3) {
            return;
        }
        hbPigRaidMainViewInstance = ins;
    }
    hbPigViewReadyForNextDig = YES;
    HBPigRequestNext(hbAndroidPigSession, 0.05);
}

static void HBAndroidPigSchedule(const char *reason, double startDelay);

static void HBPigScheduleRetry(double startDelay) {
    if (hbPigScheduleRetryArmed || hbAndroidPigScheduled || hbAndroidPigRunning || !HBPigModuleEnabled()) return;
    if (hbPigScheduleRetryCount >= 30) {
        hbPigScheduleRetryCount = 0;
        return;
    }
    hbPigScheduleRetryArmed = YES;
    int retry = ++hbPigScheduleRetryCount;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        hbPigScheduleRetryArmed = NO;
        if (!HBPigModuleEnabled() || hbAndroidPigScheduled || hbAndroidPigRunning) return;
        HBAndroidPigSchedule(q6a(1), startDelay);
    });
}

static void HBAndroidPigSchedule(const char *reason, double startDelay) {
    if (!HBPigModuleEnabled()) return;
    (void)reason;
    if (hbAndroidPigScheduled || hbAndroidPigRunning) return;
    InitAttackCloseHelpers();
    HBPigRefreshServiceFromSlot();
    if (!hbRaidServiceInstance || !hbRaidServiceStealFromDigPoint) {
        HBPigScheduleRetry(startDelay);
        return;
    }
    void *view = HBFindFirstObject(hbRaidMainViewType, 6);
    if (!view) {
        HBPigScheduleRetry(startDelay);
        return;
    }
    hbPigScheduleRetryCount = 0;
    hbPigScheduleRetryArmed = NO;
    double delay = startDelay < 0.55 ? 0.55 : startDelay;
    HBPigStartForView(view, delay);
}


static void HBProcessAutoFallbacks(int state) {
    if (!HBRaidAutomationEnabled()) return;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (state == 2 && HBPigModuleEnabled()) {
        BOOL pigOk = HBTryClickSummaryPopup(state, now);
        BOOL pigReward = HBTryCollectGenericReward(state, now);
        if (pigOk || pigReward) OngnongJobDrop(ONGNONG_JOB_RAID);
    }
    if (now - hbLastFallbackScan < 0.45) return;
    hbLastFallbackScan = now;
    HBObserveOkHintByState(state, now, OX_C("fallback_tick"));
    if (state == 1 && HBAutoHammerEnabled()) {
        HBTryFallbackAttackTarget(state, now);
    }
    if (state == 2 && HBPigModuleEnabled()) {
        HBTryClickSummaryPopup(state, now);
        HBTryCollectGenericReward(state, now);
        HBChestScanSchedule(q6a(1), 0.02, 2);
        HBAndroidPigSchedule(q6a(1), 0.25);
    }
}

static void HBHammerVerifyTarget(int session, void *target) {
    if (!HBAutoHammerEnabled() || session != hbHammerSession || !target) return;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (HBHammerTryCloseSummaryLight(now)) return;
    void *current = HBHammerFindTargetLight();
    if (!current) {
        hbHammerTargetObj = nullptr;
        hbHammerTargetSeenAt = 0;
        hbHammerRetryCount = 0;
        return;
    }
    if (current != target) {
        HBHammerBindTarget(current);
        return;
    }
    HBHammerTryClickTargetLight(1, now);
    if (hbHammerRetryCount >= 6) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.80 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        HBHammerVerifyTarget(session, target);
    });
}

static void HBHammerBindTarget(void *target) {
    if (!HBAutoHammerEnabled() || !target) return;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (target == hbHammerTargetObj && hbHammerTargetSeenAt > 0 && now - hbHammerTargetSeenAt < 0.80) return;
    hbHammerSession++;
    int session = hbHammerSession;
    hbHammerTargetObj = target;
    hbHammerTargetSeenAt = now;
    hbHammerTargetClickedAt = 0;
    hbHammerRetryCount = 0;
    lastAttackTargetControl = target;
    autoAttackClicked = false;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.00 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!HBAutoHammerEnabled() || session != hbHammerSession || hbHammerTargetObj != target) return;
        HBHammerTryClickTargetLight(1, [NSDate timeIntervalSinceReferenceDate]);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.80 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            HBHammerVerifyTarget(session, target);
        });
    });
}

static void HookedAttackTargetEnable(void *ins) {
    if (origAttackTargetEnable) origAttackTargetEnable(ins);
    if (HBAutoHammerEnabled()) HBHammerBindTarget(ins);
}

static void HookedAttackTargetShowTarget(void *ins, float delay) {
    if (origAttackTargetShowTarget) origAttackTargetShowTarget(ins, delay);
    if (HBAutoHammerEnabled()) HBHammerBindTarget(ins);
}

static void HookedAttackTargetShow(void *ins) {
    if (origAttackTargetShow) origAttackTargetShow(ins);
    if (HBAutoHammerEnabled()) HBHammerBindTarget(ins);
}

static void HookedAttackTargetOnAttackClicked(void *ins) {
    lastAttackTargetControl = ins;
    if (origAttackTargetOnAttackClicked) origAttackTargetOnAttackClicked(ins);
}

static void HookedAttackSummaryOnAwake(void *ins) {
    if (origAttackSummaryOnAwake) origAttackSummaryOnAwake(ins);
    if (HBAutoHammerEnabled()) {
        hbHammerSession++;
        hbHammerTargetObj = nullptr;
        hbHammerTargetSeenAt = 0;
        hbHammerRetryCount = 0;
        ScheduleAutoAttackCloseSummary();
    }
}

static void HookedAttackSummaryCloseButtonClicked(void *ins) {
    if (origAttackSummaryCloseButtonClicked) origAttackSummaryCloseButtonClicked(ins);
    hbHammerSession++;
    hbHammerTargetObj = nullptr;
    hbHammerTargetSeenAt = 0;
    hbHammerTargetClickedAt = 0;
    hbHammerRetryCount = 0;
    autoAttackClicked = false;
    lastAttackTargetControl = nullptr;
}


static int GetOpenCardsChestState(void *ins);

static const char *HBStringUtf8(void *s) {
    if (!s) return OX_C("null");
    const char *out = OX_C("?");
    @try {
        out = ((Il2CppString *)s)->CString();
        if (!out) out = OX_C("null");
    } @catch (NSException *ex) {
        out = OX_C("err");
    }
    return out;
}

static int HBReadMagicChestsToBuy(void *ins) {
    if (!ins) return -1;
    int value = -1;
    @try {
        value = *(int *)((uint8_t *)ins + 0xF8); 
    } @catch (NSException *ex) {
        value = -2;
    }
    return value;
}

static void *HBMagicReadPtr(void *base, uintptr_t off) {
    if (!base) return nullptr;
    void *v = nullptr;
    @try { v = *(void **)((uint8_t *)base + off); } @catch (NSException *ex) { v = nullptr; }
    return v;
}

static BOOL HBMagicReadBool(void *base, uintptr_t off) {
    if (!base) return NO;
    BOOL v = NO;
    @try { v = (*(uint8_t *)((uint8_t *)base + off)) ? YES : NO; } @catch (NSException *ex) { v = NO; }
    return v;
}

static long long HBMagicReadLong(void *base, uintptr_t off) {
    if (!base) return 0;
    long long v = 0;
    @try { v = *(long long *)((uint8_t *)base + off); } @catch (NSException *ex) { v = 0; }
    return v;
}

static float HBMagicReadFloat(void *base, uintptr_t off) {
    if (!base) return 0.0f;
    float v = 0.0f;
    @try { v = *(float *)((uint8_t *)base + off); } @catch (NSException *ex) { v = 0.0f; }
    return v;
}

static void *HBMagicStoreItemData(void *item) { return HBMagicReadPtr(item, 0x128); }
static const char *HBMagicStoreItemChestType(void *item) { return HBStringUtf8(HBMagicReadPtr(HBMagicStoreItemData(item), 0x78)); }
static const char *HBMagicStoreItemStoreType(void *item) { return HBStringUtf8(HBMagicReadPtr(HBMagicStoreItemData(item), 0x18)); }
static const char *HBMagicStoreItemPriceText(void *item) { return HBStringUtf8(HBMagicReadPtr(HBMagicStoreItemData(item), 0x40)); }
static BOOL HBMagicStoreItemMultipleAllowed(void *item) { return HBMagicReadBool(HBMagicStoreItemData(item), 0x68); }
static long long HBMagicStoreItemLongPrice(void *item) { return HBMagicReadLong(HBMagicStoreItemData(item), 0x70); }
static float HBMagicStoreItemFloatPrice(void *item) { return HBMagicReadFloat(HBMagicStoreItemData(item), 0x6C); }

static BOOL HBMagicStrContainsCI(const char *s, const char *needle) {
    if (!s || !needle) return NO;
    if (!strcmp(s, OX_C("null")) ||
        !strcmp(s, OX_C("?"))) {
        return NO;
    }
    NSString *a = [NSString stringWithUTF8String:s];
    NSString *b = [NSString stringWithUTF8String:needle];
    if (!a || !b) return NO;
    return ([a rangeOfString:b options:NSCaseInsensitiveSearch].location != NSNotFound) ? YES : NO;
}

static BOOL HBMagicStoreItemLooksMagical(void *item) {
    
    const char *chest = HBMagicStoreItemChestType(item);
    const char *stype = HBMagicStoreItemStoreType(item);
    if (HBMagicStrContainsCI(chest, q6a(108)) || HBMagicStrContainsCI(chest, q6a(109)) || HBMagicStrContainsCI(chest, q6a(110))) return YES;
    if (HBMagicStrContainsCI(stype, q6a(108)) || HBMagicStrContainsCI(stype, q6a(109)) || HBMagicStrContainsCI(stype, q6a(110))) return YES;
    return NO;
}

static BOOL HBMagicStoreItemLooksChest(void *item) {
    const char *chest = HBMagicStoreItemChestType(item);
    const char *stype = HBMagicStoreItemStoreType(item);
    if (HBMagicStoreItemMultipleAllowed(item)) return YES;
    if (HBMagicStrContainsCI(chest, q6a(111)) || HBMagicStrContainsCI(stype, q6a(111))) return YES;
    return NO;
}

static void HBMagicObserveStoreItem(const char *tag, void *item, int idx) {
    void *data = HBMagicStoreItemData(item);
    ((void)0);
}

static void HBMagicRememberStoreItemIfGood(const char *tag, void *item) {
    if (!item) return;
    if (!HBMagicStoreItemLooksMagical(item)) return;
    long long price = HBMagicStoreItemLongPrice(item); 
    hbMagicLastStoreItemObj = item;
    hbMagicLastStoreItemPrice = price;
    hbMagicLastStoreItemAt = [NSDate timeIntervalSinceReferenceDate];
    ((void)0);
}

static void HBMagicChestMark(const char *reason, void *obj);

static BOOL HBMagicChestLikelyActive(void) {
    if (!hbMagicChestFlowActive) return NO;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now - hbMagicChestLastEventAt > 70.0) {
        hbMagicChestFlowActive = NO;
        return NO;
    }
    return YES;
}

static const char *HBMagicStageName(int st) {
    switch (st) {
        case HB_MAGIC_STAGE_IDLE:
            return OX_C("IDLE");
        case HB_MAGIC_STAGE_WAIT_QTY:
            return OX_C("WAIT_QTY_POPUP");
        case HB_MAGIC_STAGE_READY_PAY:
            return OX_C("READY_PAY");
        case HB_MAGIC_STAGE_WAIT_REWARD:
            return OX_C("WAIT_REWARD");
        case HB_MAGIC_STAGE_WAIT_CLOSED:
            return OX_C("WAIT_ALL_CLOSED");
        case HB_MAGIC_STAGE_OPEN_CARDS:
            return OX_C("OPEN_CARDS_CENTER");
        case HB_MAGIC_STAGE_OPEN_STORE:
            return OX_C("OPEN_STORE_TAB");
        default:
            return OX_C("UNKNOWN");
    }
}

static void HBMagicAutoSetStage(int st, const char *reason) {
    if (hbMagicAutoStage == st && ([NSDate timeIntervalSinceReferenceDate] - hbMagicAutoLastStageSeenAt) < 0.45) return;
    hbMagicAutoStage = st;
    hbMagicAutoStageAt = [NSDate timeIntervalSinceReferenceDate];
    hbMagicAutoLastStageSeenAt = hbMagicAutoStageAt;
    ((void)0);
}

static int HBMagicCountActive(void *typeObj) {
    if (!typeObj) return 0;
    monoArray<void *> *arr = HBFindObjectsForTypeEx(typeObj, false);
    return arr ? arr->getCapacity() : 0;
}

static BOOL HBMagicAnyBlockingPopupVisible(void) {
    if (HBMagicCountActive(hbMultipleChestsPopupType) > 0) return YES;
    if (HBMagicCountActive(hbOpenChestPopupViewType) > 0) return YES;
    if (HBMagicCountActive(hbOpenChestPopupControllerType) > 0) return YES;
    if (HBMagicCountActive(hbOpenCardsChestPopupType) > 0) return YES;
    if (HBMagicCountActive(hbCardsCollectionCompletePopupType) > 0) return YES;
    return NO;
}


static void *HBMagicFindCardsCollectionPopup(void) {
    if (!hbCardsCollectionPopupType) return nullptr;
    monoArray<void *> *arr = HBFindObjectsForTypeEx(hbCardsCollectionPopupType, false);
    int cap = arr ? arr->getCapacity() : 0;
    for (int i = 0; i < cap; i++) {
        void *obj = arr->m_Items[i];
        if (obj) return obj;
    }
    arr = HBFindObjectsForTypeEx(hbCardsCollectionPopupType, true);
    cap = arr ? arr->getCapacity() : 0;
    for (int i = 0; i < cap; i++) {
        void *obj = arr->m_Items[i];
        if (obj) return obj;
    }
    return nullptr;
}

static void *HBMagicFindCardsScreenView(void) {
    if (!hbCardsScreenViewType) return nullptr;
    monoArray<void *> *arr = HBFindObjectsForTypeEx(hbCardsScreenViewType, false);
    int cap = arr ? arr->getCapacity() : 0;
    if (cap > 0 && arr && arr->m_Items[0]) return arr->m_Items[0];
    arr = HBFindObjectsForTypeEx(hbCardsScreenViewType, true);
    cap = arr ? arr->getCapacity() : 0;
    if (cap > 0 && arr && arr->m_Items[0]) return arr->m_Items[0];
    return nullptr;
}

static void *HBMagicFindGuiHudControl(void) {
    if (!hbGuiHudControlType) return nullptr;
    monoArray<void *> *arr = HBFindObjectsForTypeEx(hbGuiHudControlType, false);
    int cap = arr ? arr->getCapacity() : 0;
    for (int i = 0; arr && i < cap; i++) {
        void *obj = arr->m_Items[i];
        if (obj) return obj;
    }
    arr = HBFindObjectsForTypeEx(hbGuiHudControlType, true);
    cap = arr ? arr->getCapacity() : 0;
    for (int i = 0; arr && i < cap; i++) {
        void *obj = arr->m_Items[i];
        if (obj) return obj;
    }
    return nullptr;
}

static BOOL HBMagicAutoCallHudCardButton(void) {
    if (!hbGuiHudOnCardButtonClickMethod) return NO;
    void *hud = HBMagicFindGuiHudControl();
    if (!hud) return NO;
    @try {
        ((void)0);
        ((void (*)(void *))hbGuiHudOnCardButtonClickMethod)(hud);
        hbMagicAutoLastNavActionAt = [NSDate timeIntervalSinceReferenceDate];
        return YES;
    } @catch (NSException *e) {
        ((void)0);
        return NO;
    }
}

static BOOL HBMagicAutoCallCardsCollectionShowPopup(void) {
    if (!hbCardsCollectionPopupShowPopupMethod) return NO;
    @try {
        ((void)0);
        ((void (*)(void *, bool))hbCardsCollectionPopupShowPopupMethod)(nullptr, true);
        hbMagicAutoLastNavActionAt = [NSDate timeIntervalSinceReferenceDate];
        return YES;
    } @catch (NSException *e) {
        ((void)0);
        return NO;
    }
}

static BOOL HBMagicAutoCallCardsCollectionOpenStore(void *cardsPopup) {
    if (!cardsPopup || !hbCardsCollectionPopupOnOpenStoreClickedMethod) return NO;
    @try {
        ((void)0);
        ((void (*)(void *))hbCardsCollectionPopupOnOpenStoreClickedMethod)(cardsPopup);
        hbMagicAutoLastNavActionAt = [NSDate timeIntervalSinceReferenceDate];
        return YES;
    } @catch (NSException *e) {
        ((void)0);
        return NO;
    }
}

static BOOL HBMagicAutoCallOpenStoreTab(void *cardsView) {
    if (!cardsView || !hbCardsScreenViewOnOpenStoreClickedMethod) return NO;
    @try {
        ((void)0);
        ((void (*)(void *))hbCardsScreenViewOnOpenStoreClickedMethod)(cardsView);
        hbMagicAutoLastNavActionAt = [NSDate timeIntervalSinceReferenceDate];
        return YES;
    } @catch (NSException *e) {
        ((void)0);
        return NO;
    }
}

static BOOL HBMagicAutoNavigateToStore(void) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now - hbMagicAutoLastNavActionAt < 0.18) return YES;

    
    void *cardsPopup = HBMagicFindCardsCollectionPopup();
    if (cardsPopup) {
        hbMagicAutoNavTryCount++;
        ((void)0);
        if (HBMagicAutoCallCardsCollectionOpenStore(cardsPopup)) {
            HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_STORE, OX_C("cards_collection_popup_open_store_plus_chest"));
            HBMagicChestScanSchedule(OX_C("nav_after_cards_collection_open_store_find_magic_item"), 0.20, 16);
            return YES;
        }
    }

    void *cardsView = HBMagicFindCardsScreenView();
    if (cardsView) {
        hbMagicAutoNavTryCount++;
        ((void)0);
        if (HBMagicAutoCallOpenStoreTab(cardsView)) {
            HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_STORE, OX_C("cards_screen_opened_wait_store_items"));
            HBMagicChestScanSchedule(OX_C("nav_after_open_store_find_magic_item"), 0.20, 16);
            return YES;
        }
    }

    hbMagicAutoNavTryCount++;
    ((void)0);
    if (HBMagicAutoCallHudCardButton()) {
        HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_CARDS, OX_C("hud_card_button_clicked_wait_plus_chest_keep_old_flow"));
        HBMagicChestScanSchedule(OX_C("nav_after_hud_card_button_find_cards_screen_or_popup"), 0.08, 18);
        return YES;
    }
    if (HBMagicAutoCallCardsCollectionShowPopup()) {
        HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_CARDS, OX_C("cards_collection_popup_opened_wait_plus_chest"));
        HBMagicChestScanSchedule(OX_C("nav_after_open_cards_find_popup_plus_or_store"), 0.25, 18);
        return YES;
    }
    ((void)0);
    return NO;
}


static UIWindow *HBMagicMainWindow(void) {
    UIWindow *w = UIApplication.sharedApplication.keyWindow;
    if (!w) {
        for (UIWindow *x in UIApplication.sharedApplication.windows) {
            if (!w || x.isKeyWindow) { w = x; if (x.isKeyWindow) break; }
        }
    }
    return w;
}

bool HBMagicChestIsAutoEnabled(void) {
    return hbMagicAutoEnabled ? true : false;
}

static void HBMagicChestUpdateAutoButton(void) { }

static void HBMagicChestSetAutoEnabled(BOOL enabled) {
    hbMagicAutoEnabled = enabled;
    hbMagicRuntimeEnabled = enabled;
    hbMagicAutoTickNo = 0;
    hbMagicAutoIdleTapCount = 0;
    hbMagicAutoSkipAllowedAt = 0;
    hbMagicAutoPayReadyAt = 0;
    hbMagicAutoRewardSeenAt = 0;
    hbMagicAutoCooldownUntil = 0;
    hbMagicAutoNavTryCount = 0;
    hbMagicAutoLastActionAt = [NSDate timeIntervalSinceReferenceDate];
    hbMagicAutoLastNavActionAt = 0;
    HBMagicChestUpdateAutoButton();
    ((void)0);
    if (enabled) {
        OngnongJobTake(ONGNONG_JOB_MAGIC, 0.80);
        HBMagicChestSafeScanBootstrap();
        HBResolveMagicChestOffsetsSafe(OX_C("m_on"));
        if (HBMagicAutoCallHudCardButton()) {
            HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_CARDS, OX_C("m_start_hud"));
            HBMagicChestScanSchedule(OX_C("m_after_hud"), 0.08, 12);
        } else if (HBMagicAutoCallCardsCollectionShowPopup()) {
            HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_CARDS, OX_C("m_start_fallback"));
            HBMagicChestScanSchedule(OX_C("m_after_center"), 0.20, 8);
        } else {
            HBMagicAutoSetStage(HB_MAGIC_STAGE_IDLE, OX_C("m_start_retry"));
            HBMagicChestScanSchedule(OX_C("m_find"), 0.02, 5);
        }
        HBMagicChestAutoSchedule(0.03);
    } else {
        MagicCardsModuleResetState();
        HBMagicAutoSetStage(HB_MAGIC_STAGE_IDLE, OX_C(""));
    }
}

static void MagicCardsModuleResetState(void) {
    hbMagicChestFlowActive = NO;
    hbMagicAutoLoopScheduled = NO;
    hbMagicAutoEnabled = NO;
    hbMagicRuntimeEnabled = NO;
    hbMagicAutoSkipAllowedAt = 0;
    hbMagicAutoPayReadyAt = 0;
    hbMagicAutoRewardSeenAt = 0;
    hbMagicAutoCooldownUntil = 0;
    hbMagicAutoNavTryCount = 0;
    hbMagicAutoIdleTapCount = 0;
    hbMagicAutoStage = HB_MAGIC_STAGE_IDLE;
    hbMagicAutoStageAt = 0;
    hbMagicAutoLastNavActionAt = 0;
    hbMagicLastStoreItemObj = nullptr;
    hbLastMagicChestPopupObj = nullptr;
    hbMagicScanActiveChains = 0;
    hbMagicScanLastRequestAt = 0;
    OngnongJobDrop(ONGNONG_JOB_MAGIC);
}

bool MagicCardsModuleIsEnabled(void) { return Ongnong::Zx8fMagicCardsAllowed() && q6gc(0xC3D4E501u) && HBMagicChestIsAutoEnabled(); }
void MagicCardsModuleSetEnabled(bool enabled) {
    if (!Ongnong::Zx8fMagicCardsAllowed()) { MagicCardsModuleResetState(); return; }
    if (!q6gc(0xC3D4E502u)) return;
    if (enabled) {
        if (zce119e8048.z7377de64e5 || HBAutoBuildPendingActive() || HBRaidAutomationEnabled()) return;
    }
    HBMagicChestSetAutoEnabled(enabled ? YES : NO);
}
void MagicCardsModuleToggle(void) { if (Ongnong::Zx8fMagicCardsAllowed() && q6ga(0xC3D4E503u)) MagicCardsModuleSetEnabled(!MagicCardsModuleIsEnabled()); }

void HBMagicChestToggleAutoFromButton(void) {
    MagicCardsModuleToggle();
}

static void HBMagicChestEnsureAutoButton(void) { }

static void HBMagicChestAutoTap(CGFloat xr, CGFloat yr, const char *reason) {
    dispatch_async(dispatch_get_main_queue(), ^{
        CGSize s = UIScreen.mainScreen.bounds.size;
        CGPoint p = CGPointMake(s.width * xr, s.height * yr);
        NSInteger pid = [X7q4M c4d8];
        ((void)0);
        [X7q4M x7q0:pid n2v5:p k9m1:UITouchPhaseBegan];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.040 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [X7q4M x7q0:pid n2v5:p k9m1:UITouchPhaseEnded];
        });
    });
}

static void HBMagicChestAutoSchedule(double delay) {
    if (!hbMagicAutoEnabled) return;
    if (hbMagicAutoLoopScheduled) return;
    hbMagicAutoLoopScheduled = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        hbMagicAutoLoopScheduled = NO;
        HBMagicChestAutoTick();
    });
}

static void HBMagicChestAutoTick(void) {
    if (!hbMagicAutoEnabled) return;
    @autoreleasepool {
        HBMagicChestAutoStepOnce(++hbMagicAutoTickNo);
    }
    if (hbMagicAutoEnabled) HBMagicChestAutoSchedule(0.15);
}

static void HBMagicInvokeNoParam(void *fnPtr, void *obj, const char *tag) {
    if (!fnPtr || !obj) return;
    @try {
        ((void (*)(void *))fnPtr)(obj);
        ((void)0);
    } @catch (NSException *e) {
        ((void)0);
    }
}

static void *HBMagicFindStoreItemCandidate(BOOL requireExactMagic) {
    if (!hbStoreItemComponentType) return nullptr;
    int serial = ++hbMagicStoreScanSerial;
    void *bestExact = nullptr;
    void *bestChest = nullptr;
    long long bestChestPrice = -1;
    for (int pass = 0; pass < 2; pass++) {
        BOOL inactive = pass == 1;
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbStoreItemComponentType, inactive);
        int cap = arr ? arr->getCapacity() : 0;
        ((void)0);
        int dump = cap > 30 ? 30 : cap;
        for (int i = 0; arr && i < dump; i++) {
            void *obj = arr->m_Items[i];
            if (!obj) continue;
            void *data = HBMagicStoreItemData(obj);
            if (!data) continue;
            BOOL looksChest = HBMagicStoreItemLooksChest(obj);
            BOOL exactMagic = HBMagicStoreItemLooksMagical(obj);
            if (looksChest || exactMagic) {
                HBMagicObserveStoreItem(
                    inactive
                        ? OX_C("scan_inactive")
                        : OX_C("scan_active"),
                    obj,
                    i);
            }
            if (exactMagic && !bestExact) bestExact = obj;
            if (looksChest) {
                long long price = HBMagicStoreItemLongPrice(obj);
                if (!bestChest || price > bestChestPrice) { bestChest = obj; bestChestPrice = price; }
            }
        }
    }
    if (bestExact) {
        HBMagicRememberStoreItemIfGood(
            OX_C("scan_best_exact_magic"),
            bestExact);
        ((void)0);
        return bestExact;
    }
    if (bestChest) {
        ((void)0);
    }
    return nullptr;
}

static BOOL HBMagicAutoShouldWaitBeforeSkip(const char *source) {
    if (hbMagicAutoSkipAllowedAt <= 0) return NO;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now >= hbMagicAutoSkipAllowedAt) return NO;
    if (now - hbMagicAutoLastWaitSeenAt > 0.28) {
        hbMagicAutoLastWaitSeenAt = now;
        ((void)0);
    }
    return YES;
}

static void HBMagicAutoMarkPaymentClicked(const char *source, void *obj) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    hbMagicAutoPayClickedAt = now;
    hbMagicAutoSkipAllowedAt = now + 1.05;
    hbMagicAutoRewardSeenAt = 0;
    hbMagicAutoLastWaitSeenAt = 0;
    ((void)0);
}

static BOOL HBMagicAutoShouldWaitRewardAfterVisible(const char *source, void *obj) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (hbMagicAutoRewardSeenAt <= 0) {
        hbMagicAutoRewardSeenAt = now;
        ((void)0);
        return YES;
    }
    if (now - hbMagicAutoRewardSeenAt < 0.18) {
        if (now - hbMagicAutoLastWaitSeenAt > 0.18) {
            hbMagicAutoLastWaitSeenAt = now;
            ((void)0);
        }
        return YES;
    }
    return NO;
}

static BOOL HBMagicChestAutoFindAndRun(void) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (!hbMagicAutoEnabled) return NO;
    if (!OngnongJobTake(ONGNONG_JOB_MAGIC, 0.45)) return YES;

    if (hbMagicAutoCooldownUntil > now) {
        if (now - hbMagicAutoLastStageSeenAt > 0.45) {
            hbMagicAutoLastStageSeenAt = now;
            ((void)0);
        }
        return YES;
    }

    
    if (hbMagicAutoSkipAllowedAt > 0 && now < hbMagicAutoSkipAllowedAt) {
        HBMagicAutoShouldWaitBeforeSkip(
            OX_C("global_after_payment_state_machine"));
        return YES;
    }

    
    if (hbCardsCollectionCompletePopupType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbCardsCollectionCompletePopupType, false);
        int cap = arr ? arr->getCapacity() : 0;
        for (int i = 0; arr && i < cap && i < 3; i++) {
            void *obj = arr->m_Items[i];
            if (obj && hbCardsCollectionCloseButtonMethod) {
                ((void)0);
                ((void)0);
                HBMagicInvokeNoParam(
                    hbCardsCollectionCloseButtonMethod,
                    obj,
                    OX_C("set_complete_collect"));
                HBMagicChestScanSchedule(OX_C("auto_after_set_complete_collect"), 0.02, 2);
                hbMagicAutoLastActionAt = now;
                hbMagicAutoIdleTapCount = 0;
                hbMagicAutoCooldownUntil = now + 0.14;
                HBMagicAutoSetStage(HB_MAGIC_STAGE_WAIT_CLOSED, OX_C("collect_set_complete_clicked"));
                return YES;
            }
        }
    }

    
    if (hbOpenChestPopupViewType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbOpenChestPopupViewType, false);
        int cap = arr ? arr->getCapacity() : 0;
        for (int i = 0; arr && i < cap && i < 3; i++) {
            void *obj = arr->m_Items[i];
            if (obj && hbOpenChestPopupViewOnSkipClickMethod) {
                if (HBMagicAutoShouldWaitBeforeSkip(q6a(71))) return YES;
                if (HBMagicAutoShouldWaitRewardAfterVisible(q6a(71), obj)) return YES;
                ((void)0);
                ((void)0);
                HBMagicInvokeNoParam(
                    hbOpenChestPopupViewOnSkipClickMethod,
                    obj,
                    OX_C("reward_skip_view"));
                HBMagicChestScanSchedule(OX_C("auto_after_reward_skip_view"), 0.03, 2);
                hbMagicAutoSkipAllowedAt = 0;
                hbMagicAutoRewardSeenAt = 0;
                hbMagicAutoLastActionAt = now;
                hbMagicAutoIdleTapCount = 0;
                hbMagicAutoCooldownUntil = now + 0.04;
                HBMagicAutoSetStage(HB_MAGIC_STAGE_WAIT_CLOSED, OX_C("reward_skip_clicked_view"));
                return YES;
            }
        }
    }
    if (hbOpenChestPopupControllerType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbOpenChestPopupControllerType, false);
        int cap = arr ? arr->getCapacity() : 0;
        for (int i = 0; arr && i < cap && i < 3; i++) {
            void *obj = arr->m_Items[i];
            if (obj && hbOpenChestPopupControllerOnSkipClickMethod) {
                if (HBMagicAutoShouldWaitBeforeSkip(q6a(72))) return YES;
                if (HBMagicAutoShouldWaitRewardAfterVisible(q6a(72), obj)) return YES;
                ((void)0);
                ((void)0);
                HBMagicInvokeNoParam(
                    hbOpenChestPopupControllerOnSkipClickMethod,
                    obj,
                    OX_C("reward_skip_controller"));
                HBMagicChestScanSchedule(OX_C("auto_after_reward_skip_controller"), 0.03, 2);
                hbMagicAutoSkipAllowedAt = 0;
                hbMagicAutoRewardSeenAt = 0;
                hbMagicAutoLastActionAt = now;
                hbMagicAutoIdleTapCount = 0;
                hbMagicAutoCooldownUntil = now + 0.04;
                HBMagicAutoSetStage(HB_MAGIC_STAGE_WAIT_CLOSED, OX_C("reward_skip_clicked_controller"));
                return YES;
            }
        }
    }


    if (hbMultipleChestsPopupType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbMultipleChestsPopupType, false);
        int cap = arr ? arr->getCapacity() : 0;
        for (int i = 0; arr && i < cap && i < 3; i++) {
            void *obj = arr->m_Items[i];
            if (!obj) continue;
            int chests = HBReadMagicChestsToBuy(obj);
            if (chests != 10 && hbMultipleChestsNumberUpdatedMethod) {
                ((void)0);
                ((void)0);
                @try { ((void (*)(void *, bool, int))hbMultipleChestsNumberUpdatedMethod)(obj, true, 10); }
                @catch (NSException *e) { ((void)0); }
                HBMagicChestScanSchedule(OX_C("auto_after_select_qty10"), 0.05, 6);
                hbMagicAutoPayReadyAt = now + 0.35;
                hbMagicAutoLastActionAt = now;
                hbMagicAutoIdleTapCount = 0;
                HBMagicAutoSetStage(HB_MAGIC_STAGE_READY_PAY, OX_C("qty10_selected_wait_0_35_pay"));
                return YES;
            }
            if (chests == 10 && hbMultipleChestsClickPurchaseMethod) {
                if (hbMagicAutoStage == HB_MAGIC_STAGE_READY_PAY) {
                    if (hbMagicAutoPayReadyAt <= 0) hbMagicAutoPayReadyAt = now + 0.35;
                    if (now < hbMagicAutoPayReadyAt) {
                        if (now - hbMagicAutoLastStageSeenAt > 0.18) {
                            hbMagicAutoLastStageSeenAt = now;
                            ((void)0);
                        }
                        return YES;
                    }
                }
                ((void)0);
                ((void)0);
                HBMagicInvokeNoParam(
                    hbMultipleChestsClickPurchaseMethod,
                    obj,
                    OX_C("multiple_chests_pay"));
                HBMagicAutoMarkPaymentClicked(OX_C("auto_step3_pay_state_machine"), obj);
                HBMagicChestScanSchedule(OX_C("auto_after_payment_find_reward_skip"), 0.05, 45);
                HBMagicChestMark(OX_C("auto_pay_clicked_state_machine"), obj);
                hbMagicAutoLastActionAt = now;
                hbMagicAutoIdleTapCount = 0;
                HBMagicAutoSetStage(HB_MAGIC_STAGE_WAIT_REWARD, OX_C("payment_done_wait_reward_popup"));
                return YES;
            }
        }
    }

    
    if (hbMagicAutoStage == HB_MAGIC_STAGE_WAIT_QTY) {
        if (now - hbMagicAutoStageAt < 1.40) {
            if (now - hbMagicAutoLastStageSeenAt > 0.50) {
                hbMagicAutoLastStageSeenAt = now;
                ((void)0);
            }
            return YES;
        }
        HBMagicAutoSetStage(HB_MAGIC_STAGE_IDLE, OX_C("wait_qty_timeout_retry_find_magic"));
    }

    
    if (hbMagicAutoStage == HB_MAGIC_STAGE_WAIT_REWARD) {
        if (now - hbMagicAutoStageAt < 9.0) {
            if (now - hbMagicAutoLastStageSeenAt > 0.55) {
                hbMagicAutoLastStageSeenAt = now;
                ((void)0);
            }
            return YES;
        }
        ((void)0);
        hbMagicAutoSkipAllowedAt = 0;
        hbMagicAutoCooldownUntil = now + 0.14;
        HBMagicAutoSetStage(HB_MAGIC_STAGE_WAIT_CLOSED, OX_C("wait_reward_timeout_reset"));
        return YES;
    }

    if (hbMagicAutoStage == HB_MAGIC_STAGE_WAIT_CLOSED) {
        if (HBMagicAnyBlockingPopupVisible()) {
            if (now - hbMagicAutoLastStageSeenAt > 0.55) {
                hbMagicAutoLastStageSeenAt = now;
                ((void)0);
            }
            return YES;
        }
        if (now - hbMagicAutoStageAt < 0.03) return YES;
        HBMagicAutoSetStage(HB_MAGIC_STAGE_IDLE, OX_C("all_closed_next_loop"));
        return YES;
    }

    
    if (hbMagicAutoStage == HB_MAGIC_STAGE_OPEN_CARDS || hbMagicAutoStage == HB_MAGIC_STAGE_OPEN_STORE) {
        if (hbMagicAutoStage == HB_MAGIC_STAGE_OPEN_CARDS && hbMagicAutoLastNavActionAt > 0 && now - hbMagicAutoLastNavActionAt < 0.30) {
            if (now - hbMagicAutoLastStageSeenAt > 0.25) {
                hbMagicAutoLastStageSeenAt = now;
                ((void)0);
            }
            return YES;
        }
        if (hbMagicAutoStage == HB_MAGIC_STAGE_OPEN_STORE && hbMagicAutoLastNavActionAt > 0 && now - hbMagicAutoLastNavActionAt < 0.18) {
            if (now - hbMagicAutoLastStageSeenAt > 0.25) {
                hbMagicAutoLastStageSeenAt = now;
                ((void)0);
            }
            return YES;
        }
        void *readyItem = (hbStoreItemComponentType && hbStoreItemComponentItemClickMethod) ? HBMagicFindStoreItemCandidate(YES) : nullptr;
        if (readyItem) {
            ((void)0);
            HBMagicAutoSetStage(HB_MAGIC_STAGE_IDLE, OX_C("store_ready_find_magic_chest"));
            return YES;
        }
        if (hbMagicAutoStage == HB_MAGIC_STAGE_OPEN_CARDS) {
            void *popup = HBMagicFindCardsCollectionPopup();
            if (popup) {
                HBMagicAutoCallCardsCollectionOpenStore(popup);
                HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_STORE, OX_C("cards_collection_popup_found_open_store_plus_chest"));
                return YES;
            }
            void *view = HBMagicFindCardsScreenView();
            if (view) {
                HBMagicAutoCallOpenStoreTab(view);
                HBMagicAutoSetStage(HB_MAGIC_STAGE_OPEN_STORE, OX_C("cards_screen_found_open_store"));
                return YES;
            }
        }
        if (hbMagicAutoStage == HB_MAGIC_STAGE_OPEN_STORE) {
            if (now - hbMagicAutoLastNavActionAt > 0.18) {
                void *popup = HBMagicFindCardsCollectionPopup();
                if (popup && HBMagicAutoCallCardsCollectionOpenStore(popup)) return YES;
                void *view = HBMagicFindCardsScreenView();
                if (view && HBMagicAutoCallOpenStoreTab(view)) return YES;
            }
        }
        if (now - hbMagicAutoStageAt < 7.0) {
            if (now - hbMagicAutoLastStageSeenAt > 0.75) {
                hbMagicAutoLastStageSeenAt = now;
                ((void)0);
            }
            return YES;
        }
        ((void)0);
        HBMagicAutoSetStage(HB_MAGIC_STAGE_IDLE, OX_C("nav_timeout_retry"));
        return YES;
    }

    
    if (hbMagicAutoStage != HB_MAGIC_STAGE_IDLE) return YES;
    if (HBMagicAnyBlockingPopupVisible()) return YES;

    if (hbStoreItemComponentType && hbStoreItemComponentItemClickMethod) {
        void *storeItem = HBMagicFindStoreItemCandidate(YES);
        if (storeItem) {
            BOOL exactMagic = HBMagicStoreItemLooksMagical(storeItem);
            ((void)0);
            ((void)0);
            HBMagicInvokeNoParam(
                hbStoreItemComponentItemClickMethod,
                storeItem,
                OX_C("store_item_component_item_click"));
            HBMagicChestScanSchedule(OX_C("auto_after_store_item_method_find_qty_popup"), 0.05, 10);
            hbMagicAutoLastActionAt = now;
            hbMagicAutoIdleTapCount = 0;
            HBMagicAutoSetStage(HB_MAGIC_STAGE_WAIT_QTY, OX_C("store_item_clicked_wait_qty_popup"));
            return YES;
        }
    }

    
    if (HBMagicAutoNavigateToStore()) return YES;

    return NO;
}

static void HBMagicChestAutoStepOnce(int tickNo) {
    if (!hbMagicAutoEnabled) return;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    static NSTimeInterval hbMagicLastAutoResolveAt = 0;
    if (now - hbMagicLastAutoResolveAt > 2.0) {
        HBResolveMagicChestOffsetsSafe(
            OX_C("magic_refresh"));
        hbMagicLastAutoResolveAt = now;
    }
    BOOL did = HBMagicChestAutoFindAndRun();
    if (did) return;
    
    if (now - hbMagicAutoLastTapAt > 0.80) {
        hbMagicAutoLastTapAt = now;
        hbMagicAutoIdleTapCount++;
        ((void)0);
        HBMagicChestScanSchedule(OX_C("auto_no_tap_wait_find_exact_magic_store_item"), 0.02, 5);
    }
}

static void HBMagicChestScanOnce(const char *reason, int step) {
    InitAttackCloseHelpers();
    int state = GetCurrentGameStateSafely();
    ((void)0);
    ((void)0);

    if (hbMultipleChestsPopupType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbMultipleChestsPopupType, false);
        int cap = arr ? arr->getCapacity() : 0;
        BOOL multiVisibleNow = cap > 0;
        void *firstMultiObj = nullptr;
        int firstMultiChests = -1;
        ((void)0);
        int dump = cap > 4 ? 4 : cap;
        for (int i = 0; arr && i < dump; i++) {
            void *obj = arr->m_Items[i];
            if (obj) {
                int chests = HBReadMagicChestsToBuy(obj);
                if (!firstMultiObj) { firstMultiObj = obj; firstMultiChests = chests; }
                ((void)0);
                ((void)0);
                if (chests == 10 && (hbMagicLastMultiObj != obj || hbMagicLastMultiChests != 10)) {
                    ((void)0);
                    ((void)0);
                    HBMagicChestMark(OX_C("scan_detect_qty10"), obj);
                }
            }
        }
        if (multiVisibleNow && firstMultiObj) {
            hbMagicLastMultiVisible = YES;
            hbMagicLastMultiObj = firstMultiObj;
            hbMagicLastMultiChests = firstMultiChests;
            hbMagicLastMultiSeenAt = [NSDate timeIntervalSinceReferenceDate];
        } else if (hbMagicLastMultiVisible) {
            if (hbMagicLastMultiChests == 10) {
                ((void)0);
                ((void)0);
                HBMagicAutoMarkPaymentClicked(OX_C("scan_popup_disappeared_after_qty10"), hbMagicLastMultiObj);
                HBMagicChestMark(OX_C("scan_popup_disappeared_after_qty10_buy_confirmed"), hbMagicLastMultiObj);
                ((void)0);
                HBMagicChestScanSchedule(OX_C("instant_after_money_click_wait_open_skip"), 0.01, 45);
            } else {
                ((void)0);
            }
            hbMagicLastMultiVisible = NO;
        }
        arr = HBFindObjectsForTypeEx(hbMultipleChestsPopupType, true);
        cap = arr ? arr->getCapacity() : 0;
        ((void)0);
    }

    if (hbCardsStoreChestInfoPopupType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbCardsStoreChestInfoPopupType, false);
        int cap = arr ? arr->getCapacity() : 0;
        ((void)0);
        int dump = cap > 4 ? 4 : cap;
        for (int i = 0; arr && i < dump; i++) {
            void *obj = arr->m_Items[i];
            if (obj) {
                ((void)0);
                ((void)0);
            }
        }
    }

    if (hbCardsCollectionCompletePopupType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbCardsCollectionCompletePopupType, false);
        int cap = arr ? arr->getCapacity() : 0;
        ((void)0);
        int limit = cap < 3 ? cap : 3;
        for (int i = 0; arr && i < limit; i++) {
            void *obj = arr->m_Items[i];
            if (obj) {
                ((void)0);
                ((void)0);
            }
        }
    }

    if (hbOpenCardsChestPopupType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbOpenCardsChestPopupType, false);
        int cap = arr ? arr->getCapacity() : 0;
        ((void)0);
        BOOL openVisibleNow = cap > 0;
        void *firstOpenObj = nullptr;
        int firstOpenState = -999;
        int dump = cap > 4 ? 4 : cap;
        for (int i = 0; arr && i < dump; i++) {
            void *obj = arr->m_Items[i];
            if (obj) {
                int st = GetOpenCardsChestState(obj);
                if (!firstOpenObj) { firstOpenObj = obj; firstOpenState = st; }
                ((void)0);
                if (!hbMagicLastOpenVisible || hbMagicLastOpenObj != obj || hbMagicLastOpenState != st) {
                    ((void)0);
                    ((void)0);
                }
            }
        }
        if (openVisibleNow && firstOpenObj) {
            hbMagicLastOpenVisible = YES;
            hbMagicLastOpenObj = firstOpenObj;
            hbMagicLastOpenState = firstOpenState;
            hbMagicLastOpenSeenAt = [NSDate timeIntervalSinceReferenceDate];
        } else if (hbMagicLastOpenVisible) {
            ((void)0);
            hbMagicLastOpenVisible = NO;
        }
        arr = HBFindObjectsForTypeEx(hbOpenCardsChestPopupType, true);
        cap = arr ? arr->getCapacity() : 0;
        if (cap > 0 && !openVisibleNow) {
            int dump2 = cap > 3 ? 3 : cap;
            for (int j = 0; arr && j < dump2; j++) {
                void *obj = arr->m_Items[j];
                if (obj) ((void)0);
            }
        }
    }

    if (hbOpenChestPopupViewType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbOpenChestPopupViewType, false);
        int cap = arr ? arr->getCapacity() : 0;
        BOOL rewardVisibleNow = cap > 0;
        void *firstRewardObj = nullptr;
        int dump = cap > 3 ? 3 : cap;
        for (int i = 0; arr && i < dump; i++) {
            void *obj = arr->m_Items[i];
            if (obj) {
                if (!firstRewardObj) firstRewardObj = obj;
                if (!hbMagicLastRewardOpenVisible || hbMagicLastRewardOpenObj != obj) {
                    ((void)0);
                    ((void)0);
                    ((void)0);
                    HBMagicChestMark(OX_C("scan_reward_popup_open_chest_view"), obj);
                }
            }
        }
        if (rewardVisibleNow && firstRewardObj) {
            hbMagicLastRewardOpenVisible = YES;
            hbMagicLastRewardOpenObj = firstRewardObj;
            hbMagicLastRewardOpenSeenAt = [NSDate timeIntervalSinceReferenceDate];
        } else if (hbMagicLastRewardOpenVisible) {
            ((void)0);
            hbMagicLastRewardOpenVisible = NO;
        }
    }

    if (hbOpenChestPopupControllerType) {
        monoArray<void *> *arr = HBFindObjectsForTypeEx(hbOpenChestPopupControllerType, false);
        int cap = arr ? arr->getCapacity() : 0;
        int dump = cap > 3 ? 3 : cap;
        for (int i = 0; arr && i < dump; i++) {
            void *obj = arr->m_Items[i];
            if (obj && HBMagicChestLikelyActive()) {
                ((void)0);
            }
        }
    }

    ((void)0);
}

static void HBMagicChestScanStep(const char *reason, double interval, int step, int repeat) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(interval * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!hbMagicRuntimeEnabled && !hbMagicAutoEnabled && !HBMagicChestLikelyActive()) {
            if (hbMagicScanActiveChains > 0) hbMagicScanActiveChains--;
            return;
        }
        @autoreleasepool {
            HBMagicChestScanOnce(reason, step);
        }
        if (step + 1 < repeat) {
            HBMagicChestScanStep(reason, interval, step + 1, repeat);
        } else {
            if (hbMagicScanActiveChains > 0) hbMagicScanActiveChains--;
        }
    });
}

static void HBMagicChestScanSchedule(const char *reason, double delay, int repeat) {
    const char *safeReason =
        reason ? reason : OX_C("?");
    if (repeat <= 0) return;
    if (!hbMagicRuntimeEnabled && !hbMagicAutoEnabled && !HBMagicChestLikelyActive()) {
        ((void)0);
        return;
    }
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (hbMagicScanActiveChains >= 4) return;
    if (repeat <= 5 && now - hbMagicScanLastRequestAt < 0.10) return;
    hbMagicScanLastRequestAt = now;
    ++hbMagicChestEventSession;
    double interval = 0.14;
    if (strstr(safeReason, OX_C("instant_after_money")) || strstr(safeReason, OX_C("wait_open_skip"))) interval = 0.055;
    else if (strstr(safeReason, OX_C("long_after_money"))) interval = 0.10;
    else if (strstr(safeReason, OX_C("fast_after_money")) || strstr(safeReason, OX_C("popup_disappeared"))) interval = 0.07;
    else if (strstr(safeReason, OX_C("scan_detect_qty10"))) interval = 0.08;
    else if (strstr(safeReason, OX_C("auto_after_"))) interval = 0.08;
    hbMagicScanActiveChains++;
    ((void)0);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!hbMagicRuntimeEnabled && !hbMagicAutoEnabled && !HBMagicChestLikelyActive()) {
            if (hbMagicScanActiveChains > 0) hbMagicScanActiveChains--;
            return;
        }
        @autoreleasepool {
            HBMagicChestScanOnce(safeReason, 0);
        }
        if (repeat > 1) {
            HBMagicChestScanStep(safeReason, interval, 1, repeat);
        } else {
            if (hbMagicScanActiveChains > 0) hbMagicScanActiveChains--;
        }
    });
}

static void HBResolveMagicChestOffsetsSafe(const char *reason) {
    InitAttackCloseHelpers();
    ((void)0);

    void *multipleChestsShowOffset = get_offset(q6a(0), q6a(64), q6a(65), q6a(80), 5);
    void *multipleChestsClickOffset = get_offset(q6a(0), q6a(64), q6a(65), q6a(81), 0);
    void *multipleChestsNumberUpdatedOffset = get_offset(q6a(0), q6a(64), q6a(65), q6a(82), 2);
    void *multipleChestsCloseOffset = get_offset(q6a(0), q6a(64), q6a(65), q6a(83), 0);
    void *cardsStoreInfoShowOffset = get_offset(q6a(0), q6a(1), q6a(66), q6a(80), 5);
    void *cardsStoreInfoClickOffset = get_offset(q6a(0), q6a(1), q6a(66), q6a(81), 0);
    void *cardsStoreInfoCloseOffset = get_offset(q6a(0), q6a(1), q6a(66), q6a(83), 0);
    void *storeItemInitOffset = get_offset(q6a(0), q6a(67), q6a(68), q6a(84), 1);
    void *storeItemItemClickOffset = get_offset(q6a(0), q6a(67), q6a(68), q6a(85), 0);
    void *storeItemCurrentDataOffset = get_offset(q6a(0), q6a(67), q6a(68), q6a(86), 0);
    void *legacyProcessChestPurchaseOffset = get_offset(q6a(0), q6a(1), q6a(87), q6a(88), 3);
    void *legacyProcessGenericChestPurchaseOffset = get_offset(q6a(0), q6a(1), q6a(87), q6a(89), 3);
    void *legacyPurchaseChestOffset = get_offset(q6a(0), q6a(1), q6a(87), q6a(90), 5);
    void *legacyProcessChestSuccessOffset = get_offset(q6a(0), q6a(1), q6a(87), q6a(91), 4);
    void *networkPurchaseChestOffset = get_offset(q6a(0), q6a(1), q6a(92), q6a(90), 2);
    void *networkPurchaseChestMultipleOffset = get_offset(q6a(0), q6a(1), q6a(92), q6a(93), 3);
    void *openCardsShowPopupOffset = get_offset(q6a(0), q6a(1), q6a(59), q6a(80), 5);
    void *openCardsNextOffset = get_offset(q6a(0), q6a(1), q6a(59), q6a(94), 0);
    void *openCardsCloseOffset = get_offset(q6a(0), q6a(1), q6a(59), q6a(83), 0);
    void *openCardsOpenChestSequenceOffset = get_offset(q6a(0), q6a(1), q6a(59), q6a(95), 2);
    void *openCardsPlayChestAnimationOffset = get_offset(q6a(0), q6a(1), q6a(59), q6a(96), 2);
    void *openCardsPlaySpecificAnimationOffset = get_offset(q6a(0), q6a(1), q6a(59), q6a(97), 6);
    void *cardsCollectionShowPopupOffset = get_offset(q6a(0), q6a(1), q6a(69), q6a(80), 5);
    void *cardsCollectionOnAwakeOffset = get_offset(q6a(0), q6a(1), q6a(69), q6a(98), 0);
    void *cardsCollectionCloseOffset = get_offset(q6a(0), q6a(1), q6a(69), q6a(83), 0);
    void *cardsHandleChestOffset = get_offset(q6a(0), q6a(1), q6a(125), q6a(99), 11);
    void *cardsHandleSetCompleteOffset = get_offset(q6a(0), q6a(1), q6a(125), q6a(100), 10);
    void *cardsProcessSetCompleteDataOffset = get_offset(q6a(0), q6a(1), q6a(125), q6a(101), 1);
    void *openChestViewOnAwakeOffset = get_offset(q6a(0), q6a(70), q6a(71), q6a(98), 0);
    void *openChestViewOnClickOffset = get_offset(q6a(0), q6a(70), q6a(71), q6a(102), 0);
    void *openChestViewOnSkipClickOffset = get_offset(q6a(0), q6a(70), q6a(71), q6a(103), 0);
    void *openChestControllerShowOffset = get_offset(q6a(0), q6a(70), q6a(72), q6a(104), 1);
    void *openChestControllerCloseOffset = get_offset(q6a(0), q6a(70), q6a(72), q6a(105), 2);
    void *openChestControllerOnClickOffset = get_offset(q6a(0), q6a(70), q6a(72), q6a(102), 0);
    void *openChestControllerOnSkipClickOffset = get_offset(q6a(0), q6a(70), q6a(72), q6a(103), 0);
    void *cardsCollectionPopupShowOffset = get_offset(q6a(0), q6a(1), q6a(73), q6a(80), 2);
    void *cardsCollectionPopupOpenStoreOffset = get_offset(q6a(0), q6a(1), q6a(73), q6a(106), 0);
    void *cardsScreenViewOpenStoreOffset = get_offset(q6a(0), q6a(74), q6a(75), q6a(106), 0);
    if (!cardsScreenViewOpenStoreOffset) cardsScreenViewOpenStoreOffset = get_offset(q6a(0), q6a(1), q6a(75), q6a(106), 0);
    void *guiHudOnCardButtonOffset = get_offset(q6a(0), q6a(1), q6a(76), q6a(107), 0);

    if (multipleChestsShowOffset) hbMultipleChestsShowPopupMethod = multipleChestsShowOffset;
    if (multipleChestsClickOffset) hbMultipleChestsClickPurchaseMethod = multipleChestsClickOffset;
    if (multipleChestsNumberUpdatedOffset) hbMultipleChestsNumberUpdatedMethod = multipleChestsNumberUpdatedOffset;
    if (multipleChestsCloseOffset) hbMultipleChestsCloseMethod = multipleChestsCloseOffset;
    if (cardsStoreInfoShowOffset) hbCardsStoreInfoShowPopupMethod = cardsStoreInfoShowOffset;
    if (cardsStoreInfoClickOffset) hbCardsStoreInfoClickPurchaseMethod = cardsStoreInfoClickOffset;
    if (cardsStoreInfoCloseOffset) hbCardsStoreInfoCloseMethod = cardsStoreInfoCloseOffset;
    if (storeItemInitOffset) hbStoreItemComponentInitMethod = storeItemInitOffset;
    if (storeItemItemClickOffset) hbStoreItemComponentItemClickMethod = storeItemItemClickOffset;
    if (storeItemCurrentDataOffset) hbStoreItemComponentGetCurrentDataMethod = storeItemCurrentDataOffset;
    if (cardsCollectionPopupShowOffset) hbCardsCollectionPopupShowPopupMethod = cardsCollectionPopupShowOffset;
    if (cardsCollectionPopupOpenStoreOffset) hbCardsCollectionPopupOnOpenStoreClickedMethod = cardsCollectionPopupOpenStoreOffset;
    if (cardsScreenViewOpenStoreOffset) hbCardsScreenViewOnOpenStoreClickedMethod = cardsScreenViewOpenStoreOffset;
    if (guiHudOnCardButtonOffset) hbGuiHudOnCardButtonClickMethod = guiHudOnCardButtonOffset;
    if (legacyProcessChestPurchaseOffset) hbLegacyProcessChestPurchaseMethod = legacyProcessChestPurchaseOffset;
    if (legacyProcessGenericChestPurchaseOffset) hbLegacyProcessGenericChestPurchaseMethod = legacyProcessGenericChestPurchaseOffset;
    if (legacyPurchaseChestOffset) hbLegacyPurchaseChestMethod = legacyPurchaseChestOffset;
    if (legacyProcessChestSuccessOffset) hbLegacyProcessChestSuccessMethod = legacyProcessChestSuccessOffset;
    if (networkPurchaseChestOffset) hbNetworkPurchaseChestMethod = networkPurchaseChestOffset;
    if (networkPurchaseChestMultipleOffset) hbNetworkPurchaseChestMultipleMethod = networkPurchaseChestMultipleOffset;
    if (openCardsShowPopupOffset) hbOpenCardsShowPopupMethod = openCardsShowPopupOffset;
    if (openCardsNextOffset && !openCardsChestNextStateClicked) openCardsChestNextStateClicked = (void (*)(void *))openCardsNextOffset;
    if (openCardsCloseOffset && !openCardsChestCloseButtonClicked) openCardsChestCloseButtonClicked = (void (*)(void *))openCardsCloseOffset;
    if (openCardsOpenChestSequenceOffset) hbOpenCardsOpenChestSequenceMethod = openCardsOpenChestSequenceOffset;
    if (openCardsPlayChestAnimationOffset) hbOpenCardsPlayChestAnimationMethod = openCardsPlayChestAnimationOffset;
    if (openCardsPlaySpecificAnimationOffset) hbOpenCardsPlaySpecificChestAnimationMethod = openCardsPlaySpecificAnimationOffset;
    if (cardsCollectionShowPopupOffset) hbCardsCollectionShowPopupMethod = cardsCollectionShowPopupOffset;
    if (cardsCollectionOnAwakeOffset) hbCardsCollectionOnAwakeMethod = cardsCollectionOnAwakeOffset;
    if (cardsCollectionCloseOffset) hbCardsCollectionCloseButtonMethod = cardsCollectionCloseOffset;
    if (cardsHandleChestOffset) hbCardsHandleChestMethod = cardsHandleChestOffset;
    if (cardsHandleSetCompleteOffset) hbCardsHandleSetCompleteMethod = cardsHandleSetCompleteOffset;
    if (cardsProcessSetCompleteDataOffset) hbCardsProcessSetCompleteDataMethod = cardsProcessSetCompleteDataOffset;
    if (openChestViewOnAwakeOffset) hbOpenChestPopupViewOnAwakeMethod = openChestViewOnAwakeOffset;
    if (openChestViewOnClickOffset) hbOpenChestPopupViewOnClickMethod = openChestViewOnClickOffset;
    if (openChestViewOnSkipClickOffset) hbOpenChestPopupViewOnSkipClickMethod = openChestViewOnSkipClickOffset;
    if (openChestControllerShowOffset) hbOpenChestPopupControllerShowMethod = openChestControllerShowOffset;
    if (openChestControllerCloseOffset) hbOpenChestPopupControllerCloseMethod = openChestControllerCloseOffset;
    if (openChestControllerOnClickOffset) hbOpenChestPopupControllerOnClickMethod = openChestControllerOnClickOffset;
    if (openChestControllerOnSkipClickOffset) hbOpenChestPopupControllerOnSkipClickMethod = openChestControllerOnSkipClickOffset;

    if (!hbMagicSafeScanObservedOffsets) {
        hbMagicSafeScanObservedOffsets = YES;
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
    }

    ((void)0);
    ((void)0);
}


static void HBMagicChestSafeScanBootstrap(void) {
    if (!hbMagicRuntimeEnabled && !hbMagicAutoEnabled) {
        ((void)0);
        return;
    }
    if (hbMagicSafeScanInstalled) return;
    hbMagicSafeScanInstalled = YES;
    ((void)0);
    HBResolveMagicChestOffsetsSafe(OX_C("m_on"));
    
    
    ((void)0);
    HBMagicChestScanSchedule(OX_C("m_init"), 0.20, 3);
}

static void HBMagicChestSafeScanTick(int state) {
    if (!hbMagicRuntimeEnabled && !hbMagicAutoEnabled && !HBMagicChestLikelyActive()) return;
    if (!hbMagicSafeScanInstalled) return;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now - hbMagicSafeScanLastAt < 1.10) return;
    hbMagicSafeScanLastAt = now;
    int step = ++hbMagicSafeScanTick;
    if (step <= 2 || (step % 4) == 0) {
        HBResolveMagicChestOffsetsSafe(OX_C("m_refresh"));
    }
    @autoreleasepool {
        HBMagicChestScanOnce(OX_C("m_scan"), step);
    }
}

static void HBMagicChestMark(const char *reason, void *obj) {
    hbMagicChestFlowActive = YES;
    hbMagicChestLastEventAt = [NSDate timeIntervalSinceReferenceDate];
    if (obj) hbLastMagicChestPopupObj = obj;
    ((void)0);
    HBMagicChestScanSchedule(
        reason ? reason : OX_C("m_evt"),
        0.08,
        3);
}

static void HookedStartAttackProcess(void *ins, int attackVersion, void *attackTarget, void *randomTarget) {
    ((void)0);
    autoAttackClicked = false;
    if (origStartAttackProcess) origStartAttackProcess(ins, attackVersion, attackTarget, randomTarget);
}

static void HookedEndAttackSequence(void *ins) {
    ((void)0);
    lastAttackTargetControl = nullptr;
    autoAttackClicked = false;
    if (origEndAttackSequence) origEndAttackSequence(ins);
    if (HBAutoHammerEnabled()) ScheduleAutoAttackCloseSummary();
}

static void HookedShowSummaryWindow(void *result, float upperBarDelay, float summaryDelay) {
    ((void)0);
    ((void)0);
    hbPigPauseUntil = [NSDate timeIntervalSinceReferenceDate] + 4.0;
    if (origShowSummaryWindow) origShowSummaryWindow(result, upperBarDelay, summaryDelay);
    if (q6gb(0xB2C3D411u) && HBRaidAutomationEnabled()) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.9 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            int st = GetCurrentGameStateSafely();
            if (HBAutoHammerEnabled() && st != 2 && HBHammerModuleOwnsState(st)) HBHammerModuleTick(st);
            if (HBPigModuleEnabled()) HBProcessAutoFallbacks(2);
        });
    }
}

static BOOL HBRaidChestObjectIsVisible(void *ins) {
    if (!ins || !hbRaidOpenCardsChestPopupType) return NO;
    monoArray<void *> *arr = HBFindObjectsForTypeEx(hbRaidOpenCardsChestPopupType, false);
    if (!arr) return NO;
    int cap = arr->getCapacity();
    if (cap > 10) cap = 10;
    for (int i = 0; i < cap; i++) {
        if (arr->m_Items[i] == ins) return YES;
    }
    return NO;
}

static int GetOpenCardsChestState(void *ins) {
    if (!ins) return -1;
    int v = -1;
    @try { v = *(volatile int *)((uint8_t *)ins + 0x300); } @catch (NSException *e) { v = -1; }
    if (v < 0 || v > 20) return -1;
    return v;
}

static BOOL HBRaidChestSafeNext(void *ins) {
    if (!ins || !raidOpenCardsChestNextStateClicked || !HBRaidChestObjectIsVisible(ins)) return NO;
    BOOL ok = YES;
    try {
        @try { raidOpenCardsChestNextStateClicked(ins); } @catch (NSException *e) { ok = NO; }
    } catch (...) {
        ok = NO;
    }
    return ok;
}

static BOOL HBRaidChestSafeClose(void *ins) {
    if (!ins || !raidOpenCardsChestCloseButtonClicked || !HBRaidChestObjectIsVisible(ins)) return NO;
    BOOL ok = YES;
    try {
        @try { raidOpenCardsChestCloseButtonClicked(ins); } @catch (NSException *e) { ok = NO; }
    } catch (...) {
        ok = NO;
    }
    return ok;
}

static void HBRaidChestResetAuto(void) {
    autoCardChestRunning = false;
    lastOpenCardsChestPopup = nullptr;
    hbRaidChestReadyAt = 0;
    hbRaidChestClickGuardUntil = 0;
}

static void ProcessCardChestStep(void *ins, int step) {
    if (!HBPigModuleEnabled() || lastOpenCardsChestPopup != ins) {
        HBRaidChestResetAuto();
        return;
    }
    if (!HBRaidChestObjectIsVisible(ins)) {
        HBRaidChestResetAuto();
        return;
    }

    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    int session = hbRaidChestStepSession;

    if (hbRaidChestReadyAt > 0 && now < hbRaidChestReadyAt) {
        double wait = hbRaidChestReadyAt - now;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(wait * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!HBPigModuleEnabled() || session != hbRaidChestStepSession) return;
            ProcessCardChestStep(ins, step);
        });
        return;
    }

    int state = GetOpenCardsChestState(ins);
    if (state >= 6) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!HBPigModuleEnabled() || session != hbRaidChestStepSession) return;
            if (lastOpenCardsChestPopup == ins) HBRaidChestSafeClose(ins);
            HBRaidChestResetAuto();
        });
        return;
    }

    if (step >= 6) {
        HBRaidChestResetAuto();
        return;
    }

    if (now < hbRaidChestClickGuardUntil) {
        double wait = hbRaidChestClickGuardUntil - now;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(wait * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!HBPigModuleEnabled() || session != hbRaidChestStepSession) return;
            ProcessCardChestStep(ins, step);
        });
        return;
    }

    hbRaidChestClickGuardUntil = now + 0.35;
    if (!HBRaidChestSafeNext(ins)) {
        HBRaidChestResetAuto();
        return;
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!HBPigModuleEnabled() || session != hbRaidChestStepSession) return;
        ProcessCardChestStep(ins, step + 1);
    });
}

static void AutoClickOpenCardsChest(void *ins) {
    if (!ins || !HBPigModuleEnabled() || !raidOpenCardsChestNextStateClicked || !raidOpenCardsChestCloseButtonClicked) { ((void)0); return; }
    if (!HBRaidChestObjectIsVisible(ins)) return;
    if (!OngnongJobTake(ONGNONG_JOB_RAID, 2.80)) return;
    hbRaidChestStepSession++;
    lastOpenCardsChestPopup = ins;
    ((void)0);
    autoCardChestRunning = true;
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    hbRaidChestReadyAt = now + 0.35;
    hbRaidChestClickGuardUntil = now + 0.35;
    int session = hbRaidChestStepSession;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!HBPigModuleEnabled() || session != hbRaidChestStepSession) return;
        ProcessCardChestStep(ins, 0);
    });
}

static void HookedActivateWinSequence(void *ins, SlotResult *slotResult) {
    Ongnong::BetCycleRaidAutoSync();
    if (ins) hbSlotMachineManagerInstance = ins;
    if ((zce119e8048.z54007f39a0 || (R3n8() && [[NSUserDefaults standardUserDefaults] boolForKey:@"ongnong_q72_x1_skip"] && GetSlotBetStateForCycle() == 1)) && slotResult && slotResult->win) {
        int state = slotResult->win->state1;
        if (state == 2 || state == 4) slotResult->win->state1 = 1;
    }
    if (origActivateWinSequence) origActivateWinSequence(ins, slotResult);
}

static void q4b2a1();
static void q4b2a0(int state, void *mainMgr);
static void HBMagicChestSafeScanBootstrap();
static void HBMagicChestSafeScanTick(int state);

static void HookedOnSpinResultReceived(void *ins, void *response) {
    if (ins) hbSlotMachineManagerInstance = ins;
    if (zce119e8048.z7180b46195 && response) {
        @try {
            *(void **)((uint64_t)response + 0x8) = nullptr;
            *(void **)((uint64_t)response + 0x10) = nullptr;
        } @catch (NSException *z8f16a3c3a0) {
        }
    }
    if (origOnSpinResultReceived) origOnSpinResultReceived(ins, response);
}

static void HookedSetSlotBarResults(void *ins, void *originalSymbols, void *replacedSymbols) {
    if (ins) hbSlotMachineManagerInstance = ins;
    int hbS1 = -1, hbS2 = -2, hbS3 = -3;
    if (originalSymbols) {
        hbS1 = *(int *)((uint64_t)originalSymbols + 0x10);
        hbS2 = *(int *)((uint64_t)originalSymbols + 0x14);
        hbS3 = *(int *)((uint64_t)originalSymbols + 0x18);
        if (hbS1 == hbS2 && hbS2 == hbS3) {
            if (hbS1 == 4 && HBPigModuleEnabled()) {
                HBAndroidPigSchedule(OX_C("symbol_pig"), 1.0);
            } else if (hbS1 == 3 && HBAutoHammerEnabled()) {
                hbHammerTargetObj = nullptr;
                hbHammerTargetSeenAt = 0;
                hbHammerTargetClickedAt = 0;
            }
        }
    }
    if (zce119e8048.z26f020afac && Ongnong::Zx8fCounterAllowed()) {
        Z33f3ef693d();
        if (originalSymbols) {
            if (hbS1 == hbS2 && hbS2 == hbS3) Z74902605ad(hbS1);
        }
        Z6cb2075a89();
    }
    if (originalSymbols) R3nf(hbS1, hbS2, hbS3, ++h9c4SpinSerial);
    if (origSetSlotBarResults) origSetSlotBarResults(ins, originalSymbols, replacedSymbols);
}

static void HookedUpdate(void *ins) {
    zTraceUpdateCalls++;
    zTraceLastUpdate = [NSDate timeIntervalSinceReferenceDate];
    if (ins) hbSlotMachineManagerInstance = ins;
    BOOL zLateEnough = (zCoreInstallAt <= 0 || [NSDate timeIntervalSinceReferenceDate] - zCoreInstallAt > 6.0);
    int state = GetCurrentGameStateSafely();

    if (zLateEnough) {
        
        
        if (q6ga(0xC3D4E511u) && (hbMagicAutoEnabled || hbMagicRuntimeEnabled)) {
            HBMagicChestSafeScanBootstrap();
            HBMagicChestAutoSchedule(0.05);
            HBMagicChestSafeScanTick(state);
        }
    }

    if (hbAutoBuildPending) {
        HBAutoBuildTryFinishPending();
    }

    if (q6ga(0xA1B2C311u) && hbAutoBuildSessionGranted && zce119e8048.z7377de64e5 && !hbAutoBuildPending) {
        if (!attemptToBuildStructure || !getReadyToLevelUp ||
            (!mainManagerSwipeDown && !mainManagerSwipeUp)) {
            static NSTimeInterval hbLastBuildResolveRetry = 0;
            NSTimeInterval resolveNow = [NSDate timeIntervalSinceReferenceDate];
            if (resolveNow - hbLastBuildResolveRetry >= 3.0) {
                hbLastBuildResolveRetry = resolveNow;
                q4b2a1();
            }
        }
        void *mainMgr = getMainManagerInstance ? getMainManagerInstance() : nullptr;
        if (HBAutoBuildStateIsActionable(state)) q4b2a0(state, mainMgr);
        else HBAutoBuildResetSceneStability();
    }

    BOOL hbPigSummaryVisible = NO;
    if (q6gb(0xB2C3D411u) && HBRaidAutomationEnabled()) {
        Zx8fResolveRaidDirectFast();
        NSTimeInterval raidNow = [NSDate timeIntervalSinceReferenceDate];
        if (HBPigModuleEnabled()) {
            hbPigSummaryVisible = HBTryClickPigSummaryAnyState(raidNow);
            if (hbPigSummaryVisible) OngnongJobDrop(ONGNONG_JOB_RAID);
        }
        if (HBAutoHammerEnabled() && HBHammerModuleOwnsState(state)) HBHammerModuleTick(state);
        HBProcessAutoFallbacks(state);
    }

    if (!hbPigSummaryVisible && q6gc(0xB2C3D412u) && HBPigModuleEnabled() && state == 2) {
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        if (now >= hbPigPauseUntil) {
            HBChestScanSchedule(q6a(1), 0.02, 2);
            HBAndroidPigSchedule(q6a(1), 0.25);
        }
    } else if (q6gc(0xB2C3D413u) && HBPigModuleEnabled() && state != 2) {
        hbPigDigInCycle = 0;
    }

    Ongnong::ExpeditionAutoTick();
    Ongnong::AutoMergeModuleTick();

    if (origUpdate) origUpdate(ins);
    static int zf8c2a1d76 = 0;
    zf8c2a1d76++;
    if (zf8c2a1d76 >= 24) {
        zf8c2a1d76 = 0;
        Z2c1f8801fd();
    }
}

void Z2c1f8801fd() {
    if (!unitySetTimeScale) return;
    if (getMainManagerInstance && !getMainManagerInstance()) return;
    float value = zce119e8048.z904d9bb65a ? ((float)qsec_num(1, 0x44B)) : (zce119e8048.zacc65d5e7b ? zce119e8048.z68593f2227 : 1.0f);
    if (!Ongnong::Zx8fSpeedAllowed()) value = 1.0f;
    if (value < 0.0f) value = 0.0f;
    if (value > ((float)qsec_num(201, 0x3A5))) value = ((float)qsec_num(201, 0x3A5));
    unitySetTimeScale(value, nullptr);
}

static BOOL Zx8fIsGateRequest(NSURLRequest *request) {
    NSURL *url = request.URL;
    if (!url) return NO;
    NSString *u = url.absoluteString ?: @"";
    NSString *api = kApiUrl();
    return (api.length > 0 && [u hasPrefix:api]);
}

static void HookNSURLSession() {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class sessionClass =
            objc_getClass(OX_C("NSURLSession"));
        if (!sessionClass) return;

        SEL selector = @selector(dataTaskWithRequest:completionHandler:);
        Method method = class_getInstanceMethod(sessionClass, selector);
        if (method) {
            IMP originalImp = method_getImplementation(method);
            typedef NSURLSessionDataTask *(*OriginalImp)(id, SEL, NSURLRequest *, void (^)(NSData *, NSURLResponse *, NSError *));
            IMP replacement = imp_implementationWithBlock(^NSURLSessionDataTask *(id self, NSURLRequest *request, void (^completion)(NSData *, NSURLResponse *, NSError *)) {
                void (^wrapped)(NSData *, NSURLResponse *, NSError *) = ^(NSData *data, NSURLResponse *response, NSError *error) {
                    if (zce119e8048.z7180b46195 && !Zx8fIsGateRequest(request)) {
                        NSError *fakeError = [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorNotConnectedToInternet userInfo:nil];
                        if (completion) completion(nil, nil, fakeError);
                    } else {
                        if (completion) completion(data, response, error);
                    }
                };
                NSURLSessionDataTask *task = ((OriginalImp)originalImp)(self, selector, request, wrapped);
                if (zce119e8048.z7180b46195 && !Zx8fIsGateRequest(request)) [task cancel];
                return task;
            });
            method_setImplementation(method, replacement);
        }

        SEL z9c61e0e12a = @selector(dataTaskWithRequest:);
        Method zbd98b24222 = class_getInstanceMethod(sessionClass, z9c61e0e12a);
        if (zbd98b24222) {
            IMP z9e4e9495df = method_getImplementation(zbd98b24222);
            typedef NSURLSessionDataTask *(*Z0e72e27b47)(id, SEL, NSURLRequest *);
            IMP z0de8ac60fc = imp_implementationWithBlock(^NSURLSessionDataTask *(id self, NSURLRequest *request) {
                NSURLSessionDataTask *z895f0d2be2 = ((Z0e72e27b47)z9e4e9495df)(self, z9c61e0e12a, request);
                if (zce119e8048.z7180b46195 && !Zx8fIsGateRequest(request)) [z895f0d2be2 cancel];
                return z895f0d2be2;
            });
            method_setImplementation(zbd98b24222, z0de8ac60fc);
        }
    });
}

static const char *OngnongOpenCardsClassName(void) { return q6a(77); }

static void Zx8fResolveRaidDirectFast() {
    static BOOL done = NO;
    static BOOL busy = NO;
    if (done || busy) return;
    busy = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            Attach();
            InitAttackCloseHelpers();
            HBResolvePigSummaryMethodsIfNeeded();
            void *raidServiceDigOffset = get_offset(q6a(0), OX_C("MoonActive.Raid"), OX_C("RaidServiceProxy"), OX_C("StealFromDigPoint"), 1);
            void *raidServiceSwitchOffset = get_offset(q6a(0), OX_C("MoonActive.Raid"), OX_C("RaidServiceProxy"), OX_C("SwitchToSteal"), 2);
            void *raidServiceFinishedDigOffset = get_offset(q6a(0), OX_C("MoonActive.Raid"), OX_C("RaidServiceProxy"), OX_C("FinishedSuccessfulDig"), 0);
            void *legacyStealFromDigPointOffset = get_offset(q6a(0), q6a(1), q6a(38), q6a(39), 1);
            void *legacyEndStealSequence4Offset = get_offset(q6a(0), q6a(1), q6a(38), q6a(41), 4);
            void *legacyEndStealSequence3Offset = legacyEndStealSequence4Offset ? nullptr : get_offset(q6a(0), q6a(1), q6a(38), q6a(41), 3);
            void *legacyEndOfRaidSequenceOffset = get_offset(q6a(0), q6a(1), q6a(78), q6a(79), 0);
            void *raidMainResetOffset = get_offset(q6a(0), OX_C("MoonActive.Raid.UI"), OX_C("RaidMainView"), OX_C("ResetForNewRaid"), 0);
            void *raidMainDigCompleteOffset = get_offset(q6a(0), OX_C("MoonActive.Raid.UI"), OX_C("RaidMainView"), OX_C("DigComplete"), 0);
            void *attackTargetOnClickOffset = get_offset(q6a(0), q6a(1), OX_C("GUI_attackTergetControl"), OX_C("OnAttackBtnClicked"), 0);
            void *attackTargetEnableOffset = get_offset(q6a(0), q6a(1), OX_C("GUI_attackTergetControl"), OX_C("Enable"), 0);
            void *attackTargetShowTargetOffset = get_offset(q6a(0), q6a(1), OX_C("GUI_attackTergetControl"), OX_C("ShowTarget"), 1);
            void *attackTargetShowOffset = get_offset(q6a(0), q6a(1), OX_C("GUI_attackTergetControl"), OX_C("Show"), 0);
            void *attackSummaryCloseOffset = get_offset(q6a(0), q6a(1), q6a(53), q6a(14), 0);
            void *attackAnimAbortOffset = get_offset(q6a(0), q6a(1), q6a(54), q6a(55), 0);
            void *openCardsNextOffset = get_offset(q6a(0), q6a(1), OngnongOpenCardsClassName(), q6a(37), 0);
            void *openCardsCloseOffset = get_offset(q6a(0), q6a(1), OngnongOpenCardsClassName(), q6a(14), 0);
            void *baseSummaryClickOffset = get_offset(q6a(0), q6a(56), q6a(57), q6a(112), 0);
            void *genericRewardCollectOffset = get_offset(q6a(0), q6a(1), q6a(58), q6a(113), 0);
            void *genericRewardCloseOffset = get_offset(q6a(0), q6a(1), q6a(58), q6a(83), 0);
            void *rewardFoundClaimOffset = get_offset(q6a(0), q6a(1), q6a(60), q6a(114), 0);
            void *rewardFoundCloseOffset = get_offset(q6a(0), q6a(1), q6a(60), q6a(83), 0);
            void *rewardReceivedCloseOffset = get_offset(q6a(0), q6a(1), q6a(61), q6a(83), 0);
            void *raidAnimCollectChestOffset = get_offset(q6a(0), q6a(115), q6a(116), q6a(117), 2);
            void *raidUtilsCollectChestOffset = get_offset(q6a(0), q6a(118), q6a(119), q6a(117), 2);
            void *raidMainPlayDigChestOffset = get_offset(q6a(0), q6a(62), q6a(63), q6a(120), 2);
            if (raidServiceDigOffset) hbRaidServiceStealFromDigPoint = (void (*)(void *, int, void *))raidServiceDigOffset;
            if (legacyStealFromDigPointOffset) hbLegacyStealFromDigPoint = (void (*)(int))legacyStealFromDigPointOffset;
            if (legacyEndStealSequence4Offset) hbLegacyEndStealSequence4 = (void (*)(bool, uint16_t, uint16_t, long long))legacyEndStealSequence4Offset;
            if (legacyEndStealSequence3Offset) hbLegacyEndStealSequence3 = (void (*)(bool, uint16_t, uint16_t))legacyEndStealSequence3Offset;
            if (legacyEndOfRaidSequenceOffset) hbLegacyEndOfRaidSequence = (void (*)(void))legacyEndOfRaidSequenceOffset;
            if (!origAttackTargetOnAttackClicked && attackTargetOnClickOffset) {
                origAttackTargetOnAttackClicked = (void (*)(void *))HookOffset(UnityFrameworkPath, (uintptr_t)attackTargetOnClickOffset, (void *)HookedAttackTargetOnAttackClicked);
                attackTargetOnAttackClicked = origAttackTargetOnAttackClicked ? origAttackTargetOnAttackClicked : (void (*)(void *))attackTargetOnClickOffset;
            }
            if (!hbHammerHookInstalled && attackTargetOnClickOffset) {
                if (attackTargetEnableOffset) origAttackTargetEnable = (void (*)(void *))HookOffset(UnityFrameworkPath, (uintptr_t)attackTargetEnableOffset, (void *)HookedAttackTargetEnable);
                if (attackTargetShowTargetOffset) origAttackTargetShowTarget = (void (*)(void *, float))HookOffset(UnityFrameworkPath, (uintptr_t)attackTargetShowTargetOffset, (void *)HookedAttackTargetShowTarget);
                if (attackTargetShowOffset) origAttackTargetShow = (void (*)(void *))HookOffset(UnityFrameworkPath, (uintptr_t)attackTargetShowOffset, (void *)HookedAttackTargetShow);
                hbHammerHookInstalled = (origAttackTargetEnable || origAttackTargetShowTarget || origAttackTargetShow) ? YES : NO;
            }
            if (attackSummaryCloseOffset) directAttackSummaryClose = (AttackSummaryCloseFn)attackSummaryCloseOffset;
            if (attackAnimAbortOffset) directAttackAnimationAbort = (AttackAnimAbortFn)attackAnimAbortOffset;
            if (openCardsNextOffset) { raidOpenCardsChestNextStateClicked = (void (*)(void *))openCardsNextOffset; openCardsChestNextStateClicked = (void (*)(void *))openCardsNextOffset; }
            if (openCardsCloseOffset) { raidOpenCardsChestCloseButtonClicked = (void (*)(void *))openCardsCloseOffset; openCardsChestCloseButtonClicked = (void (*)(void *))openCardsCloseOffset; }
            if (baseSummaryClickOffset) hbBaseSummaryOnClick = (void (*)(void *))baseSummaryClickOffset;
            if (genericRewardCollectOffset) hbGenericRewardCollect = (void (*)(void *))genericRewardCollectOffset;
            if (genericRewardCloseOffset) hbGenericRewardClose = (void (*)(void *))genericRewardCloseOffset;
            if (rewardFoundClaimOffset) hbRewardFoundClaim = (void (*)(void *))rewardFoundClaimOffset;
            if (rewardFoundCloseOffset) hbRewardFoundClose = (void (*)(void *))rewardFoundCloseOffset;
            if (rewardReceivedCloseOffset) hbRewardReceivedClose = (void (*)(void *))rewardReceivedCloseOffset;
            hbRaidMainPlayDigChestMethod = raidMainPlayDigChestOffset;
            hbRaidAnimCollectChestMethod = raidAnimCollectChestOffset;
            hbRaidUtilsCollectChestMethod = raidUtilsCollectChestOffset;
            done = ((hbRaidServiceStealFromDigPoint || hbLegacyStealFromDigPoint) && attackTargetOnAttackClicked && raidOpenCardsChestNextStateClicked && raidOpenCardsChestCloseButtonClicked) ? YES : NO;
            busy = NO;
        }
    });
}

static void q4b2a1() {
    static BOOL done = NO;
    static BOOL busy = NO;
    if (done || busy) return;
    busy = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(q6t(24) * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @autoreleasepool {
            Attach();
            void *getReadyToLevelUpOffset = get_offset(q6a(0), q6a(1), q6a(2), q6a(3), 0);
            void *moveToNextVillageOffset = get_offset(q6a(0), q6a(1), q6a(2), q6a(4), 0);
            void *attemptToBuildStructureOffset = get_offset(q6a(0), q6a(1), q6a(2), q6a(5), 6);
            void *swipeUpOffset = get_offset(q6a(0), q6a(1), q6a(2), q6a(6), 0);
            void *swipeDownOffset = get_offset(q6a(0), q6a(1), q6a(2), q6a(7), 0);
            void *villageGoOffset = get_offset(q6a(0), q6a(1), q6a(8), q6a(9), 0);
            void *mapCloseOffset = get_offset(q6a(0), q6a(1), q6a(10), q6a(11), 0);
            if (!mapCloseOffset) mapCloseOffset = get_offset(q6a(0), q6a(12), q6a(10), q6a(11), 0);
            void *genericSaleCloseOffset = get_offset(q6a(0), q6a(1), q6a(13), q6a(14), 1);
            void *genericSaleBackOffset = get_offset(q6a(0), q6a(1), q6a(13), q6a(15), 0);
            void *openChestClickOffset = get_offset(q6a(0), q6a(1), q6a(16), q6a(17), 0);
            if (!openChestClickOffset) openChestClickOffset = get_offset(q6a(0), q6a(18), q6a(16), q6a(17), 0);
            void *openChestSkipOffset = get_offset(q6a(0), q6a(1), q6a(16), q6a(19), 0);
            if (!openChestSkipOffset) openChestSkipOffset = get_offset(q6a(0), q6a(18), q6a(16), q6a(19), 0);
            void *openChestCtrlClickOffset = get_offset(q6a(0), q6a(18), q6a(20), q6a(17), 0);
            void *openChestCtrlSkipOffset = get_offset(q6a(0), q6a(18), q6a(20), q6a(19), 0);
            void *villageMasterCollectOffset = get_offset(q6a(0), q6a(1), q6a(21), q6a(22), 0);
            void *villageMasterCloseOffset = get_offset(q6a(0), q6a(1), q6a(21), q6a(14), 0);
            if (getReadyToLevelUpOffset) getReadyToLevelUp = (bool (*)(void *))getReadyToLevelUpOffset;
            if (moveToNextVillageOffset) moveToNextVillage = (void (*)(void *))moveToNextVillageOffset;
            if (attemptToBuildStructureOffset) attemptToBuildStructure = (void (*)(void *, int, bool, void *, void *, void *, bool))attemptToBuildStructureOffset;
            if (swipeUpOffset) mainManagerSwipeUp = (void (*)(void *))swipeUpOffset;
            if (swipeDownOffset) mainManagerSwipeDown = (void (*)(void *))swipeDownOffset;
            if (villageGoOffset) villageCompleteGoNext = (void (*)(void *))villageGoOffset;
            if (mapCloseOffset) mapPopupCloseClick = (void (*)(void *))mapCloseOffset;
            if (genericSaleCloseOffset) genericSaleCloseBool = (void (*)(void *, bool))genericSaleCloseOffset;
            if (genericSaleBackOffset) genericSaleBackPressed = (void (*)(void *))genericSaleBackOffset;
            if (openChestClickOffset) openChestViewClick = (void (*)(void *))openChestClickOffset;
            if (openChestSkipOffset) openChestViewSkip = (void (*)(void *))openChestSkipOffset;
            if (openChestCtrlClickOffset) openChestCtrlClick = (void (*)(void *))openChestCtrlClickOffset;
            if (openChestCtrlSkipOffset) openChestCtrlSkip = (void (*)(void *))openChestCtrlSkipOffset;
            if (villageMasterCollectOffset) villageMasterRewardCollect = (void (*)(void *))villageMasterCollectOffset;
            if (villageMasterCloseOffset) villageMasterRewardClose = (void (*)(void *))villageMasterCloseOffset;
            
            
            done = (getReadyToLevelUp && attemptToBuildStructure &&
                    (mainManagerSwipeDown || mainManagerSwipeUp)) ? YES : NO;
            busy = NO;
        }
    });
}

void InstallHooks() {
    zTraceInstallAttempts++;
    static BOOL bootstrapped = NO;
    if (!bootstrapped) {
        bootstrapped = YES;
        Attach();
        HookNSURLSession();
    }
    {
        @autoreleasepool {
            ((void)0);
            ((void)0);
            ((void)0);
            if (zCoreInstallAt <= 0) zCoreInstallAt = [NSDate timeIntervalSinceReferenceDate];

            void *networkOffset = get_offset(q6a(0), q6a(1), q6a(25), q6a(26), 1);
            void *symbolOffset = get_offset(q6a(0), q6a(1), q6a(25), q6a(27), 2);
            void *skipOffset = get_offset(q6a(0), q6a(1), q6a(25), q6a(28), 1);
            void *updateOffset = get_offset(q6a(0), q6a(1), q6a(25), q6a(29), 0);
            void *slotSpinCompleteOffset = get_offset(q6a(0), q6a(1), q6a(25), q6a(132), 0);
            void *getMainManagerInstanceOffset = get_offset(q6a(0), q6a(1), q6a(2), q6a(30), 0);
            void *getCurrentGameStateOffset = get_offset(q6a(0), q6a(1), q6a(2), q6a(31), 0);
            if (!unitySetTimeScale) unitySetTimeScale = (void (*)(float, void *))get_offset(q6a(32), q6a(33), q6a(34), q6a(35), 1);
            if (getMainManagerInstanceOffset) getMainManagerInstance = (void *(*)())getMainManagerInstanceOffset;
            if (getCurrentGameStateOffset) getCurrentGameState = (int (*)(void *))getCurrentGameStateOffset;

            if (networkOffset) InitOffsetForPatchHook(UnityFrameworkPath, (uintptr_t)networkOffset, nullptr);
            if (symbolOffset) InitOffsetForPatchHook(UnityFrameworkPath, (uintptr_t)symbolOffset, nullptr);
            if (skipOffset) InitOffsetForPatchHook(UnityFrameworkPath, (uintptr_t)skipOffset, nullptr);
            if (updateOffset) InitOffsetForPatchHook(UnityFrameworkPath, (uintptr_t)updateOffset, nullptr);
            if (slotSpinCompleteOffset) InitOffsetForPatchHook(UnityFrameworkPath, (uintptr_t)slotSpinCompleteOffset, nullptr);

            if (networkOffset && !origOnSpinResultReceived) origOnSpinResultReceived = (void (*)(void *, void *))HookOffset(UnityFrameworkPath, (uintptr_t)networkOffset, (void *)HookedOnSpinResultReceived);
            if (symbolOffset && !origSetSlotBarResults) origSetSlotBarResults = (void (*)(void *, void *, void *))HookOffset(UnityFrameworkPath, (uintptr_t)symbolOffset, (void *)HookedSetSlotBarResults);
            if (skipOffset && !origActivateWinSequence) origActivateWinSequence = (void (*)(void *, SlotResult *))HookOffset(UnityFrameworkPath, (uintptr_t)skipOffset, (void *)HookedActivateWinSequence);
            if (updateOffset && !origUpdate) origUpdate = (void (*)(void *))HookOffset(UnityFrameworkPath, (uintptr_t)updateOffset, (void *)HookedUpdate);
            if (slotSpinCompleteOffset && !origSlotMachineSpinComplete) origSlotMachineSpinComplete = (void (*)(void *))HookOffset(UnityFrameworkPath, (uintptr_t)slotSpinCompleteOffset, (void *)HookedSlotMachineSpinComplete);

            if (origUpdate) InstallExpeditionAutoHooks();
        }
    }
}

NSString *HookTraceSnapshot() {
    return [NSString stringWithFormat:@"installAttempts=%llu updateCalls=%llu lastUpdateAge=%.1f\nnetwork=%d symbol=%d skip=%d update=%d spinComplete=%d timeScale=%d\nmainManager=%d gameState=%d coreReady=%d",
        zTraceInstallAttempts, zTraceUpdateCalls,
        zTraceLastUpdate > 0 ? [NSDate timeIntervalSinceReferenceDate] - zTraceLastUpdate : -1.0,
        origOnSpinResultReceived != nullptr, origSetSlotBarResults != nullptr,
        origActivateWinSequence != nullptr, origUpdate != nullptr,
        origSlotMachineSpinComplete != nullptr, unitySetTimeScale != nullptr,
        getMainManagerInstance != nullptr, getCurrentGameState != nullptr,
        AreCoreHooksReady()];
}

bool AreCoreHooksReady() {
    return origUpdate != nullptr && unitySetTimeScale != nullptr;
}

}
