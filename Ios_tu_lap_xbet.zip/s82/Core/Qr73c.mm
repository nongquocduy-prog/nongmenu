#import "Qr73c.h"
#import "Qr73d.h"
#import "OngnongState.h"
#import "OngnongHookManager.h"
#import "zx8f1a_gate.h"
#import "OngnongOxorany.h"
#import "../UI/OngnongUIVault.h"
#import <UIKit/UIKit.h>

namespace Ongnong {

static NSMutableArray<NSDictionary *> *g_q72Rows = nil;
static NSInteger g_q72Target = Z94881eb8d3;
static NSInteger g_q72MaxTotal = 130;
static NSInteger g_q72Total = 0;
static NSInteger g_q72RowIndex = 0;
static NSInteger g_q72RowCount = 0;
static BOOL g_q72Running = NO;
static BOOL g_q72AutoRepeat = NO;
static BOOL g_q72Collapsed = NO;
typedef NS_ENUM(NSInteger, R3naCode) {
    R3naReady = 0,
    R3naSpinning,
    R3naAutoStartFailed,
    R3naWaitSpinStopFailed,
    R3naBetChanged,
    R3naBetUnsupported,
    R3naChangingBet,
    R3naSaved,
    R3naOff,
    R3naStarting,
    R3naResetDone,
    R3naTargetReached,
    R3naCheckingTarget,
    R3naStopped
};
static R3naCode g_q72StatusCode = R3naReady;
static NSInteger g_q72StatusA = 0;
static NSInteger g_q72StatusB = 0;
static uint64_t g_q72LastSpin = 0;
static uint64_t g_q72PendingTargetSpin = 0;
static int g_q72PendingTargetIndex = -1;
static NSUInteger g_q72BetGeneration = 0;
static NSUInteger g_q72StopGeneration = 0;
static BOOL g_q72Loaded = NO;

static void W8c1(R3naCode code, NSInteger a, NSInteger b);
static NSString *W8c2(void);

NSString *R3n1(void) { return K4p7b(); }

static void W8c3(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:K4p7b() object:nil];
    });
}

static void W8c4(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:g_q72Rows ?: @[] forKey:K4p7a(OX_NS("rows"))];
    [ud setInteger:g_q72Target forKey:K4p7a(OX_NS("target"))];
    [ud setInteger:g_q72MaxTotal forKey:K4p7a(OX_NS("max"))];
    [ud setInteger:g_q72Total forKey:K4p7a(OX_NS("total"))];
    [ud setInteger:g_q72RowIndex forKey:K4p7a(OX_NS("row"))];
    [ud setInteger:g_q72RowCount forKey:K4p7a(OX_NS("row_count"))];
    [ud setBool:g_q72Running forKey:K4p7a(OX_NS("running"))];
    [ud setBool:g_q72Collapsed forKey:K4p7a(OX_NS("collapsed"))];
    [ud setInteger:g_q72StatusCode forKey:K4p7a(OX_NS("status_code"))];
    [ud setInteger:g_q72StatusA forKey:K4p7a(OX_NS("status_a"))];
    [ud setInteger:g_q72StatusB forKey:K4p7a(OX_NS("status_b"))];
    [ud synchronize];
}

static void W8c5(void) {
    if (g_q72Loaded) return;
    g_q72Loaded = YES;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSArray *saved = [ud arrayForKey:K4p7a(OX_NS("rows"))];
    NSMutableArray *valid = [NSMutableArray array];
    for (id obj in saved) {
        NSDictionary *r = K4p7d(obj);
        if (r) [valid addObject:r];
        if (valid.count >= 20) break;
    }
    if (valid.count == 0) [valid addObjectsFromArray:K4p7c()];
    g_q72Rows = valid;
    if ([ud objectForKey:K4p7a(OX_NS("target"))]) g_q72Target = [ud integerForKey:K4p7a(OX_NS("target"))];
    if (g_q72Target == -100) g_q72Target = Z94881eb8d3;
    if ([ud objectForKey:K4p7a(OX_NS("max"))]) g_q72MaxTotal = [ud integerForKey:K4p7a(OX_NS("max"))];
    g_q72Total = MAX((NSInteger)0, [ud integerForKey:K4p7a(OX_NS("total"))]);
    g_q72RowIndex = MAX((NSInteger)0, [ud integerForKey:K4p7a(OX_NS("row"))]);
    g_q72RowCount = MAX((NSInteger)0, [ud integerForKey:K4p7a(OX_NS("row_count"))]);
    g_q72Running = NO;
    g_q72AutoRepeat = [ud boolForKey:K4p7a(OX_NS("auto_repeat"))];
    g_q72Collapsed = [ud boolForKey:K4p7a(OX_NS("collapsed"))];
    g_q72StatusCode = R3naOff;
    g_q72StatusA = 0;
    g_q72StatusB = 0;
    [ud setBool:NO forKey:K4p7a(OX_NS("running"))];
    [ud setInteger:R3naOff forKey:K4p7a(OX_NS("status_code"))];
    [ud setInteger:0 forKey:K4p7a(OX_NS("status_a"))];
    [ud setInteger:0 forKey:K4p7a(OX_NS("status_b"))];
    [ud synchronize];
    if (g_q72RowIndex >= (NSInteger)g_q72Rows.count) g_q72RowIndex = MAX((NSInteger)0, (NSInteger)g_q72Rows.count - 1);
}

static BOOL R3n3Allowed(NSInteger target) {
    if (target == Z700020a485 || target == Z124338f2d8 || target == Z94881eb8d3 || target == Z646dcbe562) return YES;
    if (!Ongnong::Zx8fIsVIP()) return NO;
    if (target == Z2f0c1a9d77) return Ongnong::Zx8fPotionAllowed();
    if (target == Z87f6d0c11d) return Ongnong::Zx8fTokenAllowed();
    if (target == Z5d92a7e4c1) return Ongnong::Zx8fLightningAllowed();
    return NO;
}

static NSInteger W8c7(void) {
    W8c5();
    if (g_q72Rows.count == 0) return 0;
    NSInteger idx = MIN(MAX((NSInteger)0, g_q72RowIndex), (NSInteger)g_q72Rows.count - 1);
    return [g_q72Rows[idx][OX_NS("bet")] integerValue];
}

static void W8c8(void) {
    StopSpinForAutoTarget();
}

static void W8c9(NSUInteger generation, NSInteger left) {
    if (generation != g_q72BetGeneration || !g_q72Running) return;
    if (StartAutoSpinForCycle()) {
        NSInteger bet = W8c7();
        W8c1(R3naSpinning, bet, 0);
        W8c4();
        W8c3();
        return;
    }
    if (left > 0) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            W8c9(generation, left - 1);
        });
        return;
    }
    g_q72Running = NO;
    ++g_q72StopGeneration;
    W8c1(R3naAutoStartFailed, 0, 0);
    W8c4();
    W8c3();
}

static void W8ca(NSInteger bet, NSUInteger generation, NSInteger left) {
    if (generation != g_q72BetGeneration || !g_q72Running) return;

    if (SlotIsSpinningForCycle()) {
        if (left > 0) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                W8ca(bet, generation, left - 1);
            });
            return;
        }
        g_q72Running = NO;
        ++g_q72StopGeneration;
        W8c1(R3naWaitSpinStopFailed, 0, 0);
        W8c4();
        W8c3();
        PauseAutoSpinForCycle();
        return;
    }

    BOOL called = SetSlotBetStateForCycle((int)bet);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (generation != g_q72BetGeneration || !g_q72Running) return;
        int current = GetSlotBetStateForCycle();
        if (called && current == (int)bet) {
            W8c1(R3naBetChanged, bet, 0);
            W8c4();
            W8c3();
            W8c9(generation, 5);
            return;
        }
        if (left > 0) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.22 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                W8ca(bet, generation, left - 1);
            });
            return;
        }
        g_q72Running = NO;
        ++g_q72StopGeneration;
        W8c1(R3naBetUnsupported, bet, 0);
        W8c4();
        W8c3();
        PauseAutoSpinForCycle();
    });
}

static void W8cb(NSInteger bet, NSString *reason) {
    (void)reason;
    if (bet <= 0) return;
    NSUInteger generation = ++g_q72BetGeneration;
    PauseAutoSpinForCycle();
    W8c1(R3naChangingBet, bet, 0);
    W8c4();
    W8c3();
    dispatch_async(dispatch_get_main_queue(), ^{
        W8ca(bet, generation, 40);
    });
}

static void W8c1(R3naCode code, NSInteger a, NSInteger b) {
    g_q72StatusCode = code;
    g_q72StatusA = a;
    g_q72StatusB = b;
}

static NSString *W8c2(void) {
    switch (g_q72StatusCode) {
        case R3naSpinning:
            return [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxSpinningFormat), (long)g_q72StatusA];
        case R3naAutoStartFailed:
            return OngnongUIVaultText(OngnongUIVaultQxAutoStartFailed);
        case R3naWaitSpinStopFailed:
            return OngnongUIVaultText(OngnongUIVaultQxWaitSpinStopFailed);
        case R3naBetChanged:
            return [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxBetChangedFormat), (long)g_q72StatusA];
        case R3naBetUnsupported:
            return [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxBetUnsupportedFormat), (long)g_q72StatusA];
        case R3naChangingBet:
            return [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxChangingBetFormat), (long)g_q72StatusA];
        case R3naSaved:
            return OngnongUIVaultText(OngnongUIVaultQxSaved);
        case R3naOff:
            return OngnongUIVaultText(OngnongUIVaultQxOff);
        case R3naStarting:
            return OngnongUIVaultText(OngnongUIVaultQxStarting);
        case R3naResetDone:
            return OngnongUIVaultText(OngnongUIVaultQxResetDone);
        case R3naTargetReached:
            return OngnongUIVaultText(OngnongUIVaultQxTargetReached);
        case R3naCheckingTarget:
            return OngnongUIVaultText(OngnongUIVaultQxCheckingTarget);
        case R3naStopped:
            return [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxStoppedFormat), (long)g_q72StatusA, (long)g_q72StatusB];
        case R3naReady:
        default:
            return OngnongUIVaultText(OngnongUIVaultQxReady);
    }
}

NSArray<NSDictionary *> *R3n2(void) { W8c5(); return [g_q72Rows copy]; }
NSInteger R3n3(void) { W8c5(); return g_q72Target; }
NSInteger R3n4(void) { W8c5(); return g_q72MaxTotal; }
NSInteger R3n5(void) { W8c5(); return g_q72Total; }
NSInteger R3n6(void) { W8c5(); return g_q72RowIndex; }
NSInteger R3n7(void) { W8c5(); return g_q72RowCount; }
BOOL R3n8(void) { W8c5(); return g_q72Running; }
BOOL R3nRepeat(void) { W8c5(); return g_q72AutoRepeat; }
void R3nSetRepeat(BOOL enabled) { W8c5(); g_q72AutoRepeat=enabled; [[NSUserDefaults standardUserDefaults] setBool:enabled forKey:K4p7a(OX_NS("auto_repeat"))]; [[NSUserDefaults standardUserDefaults] synchronize]; }
BOOL R3n9(void) { W8c5(); return g_q72Collapsed; }
NSString *R3na(void) { W8c5(); return W8c2(); }

BOOL R3nb(NSArray<NSDictionary *> *rows, NSInteger target, NSInteger maxTotal, NSString **errorText) {
    W8c5();
    if (g_q72Running) {
        if (errorText) *errorText = OngnongUIVaultText(OngnongUIVaultQxErrTurnOffBeforeEdit);
        return NO;
    }
    NSMutableArray *valid = [NSMutableArray array];
    for (id obj in rows) {
        NSDictionary *r = K4p7d(obj);
        if (!r) {
            if (errorText) *errorText = OngnongUIVaultText(OngnongUIVaultQxErrBetSpinsPositive);
            return NO;
        }
        [valid addObject:r];
        if (valid.count >= 20) break;
    }
    if (valid.count == 0) {
        if (errorText) *errorText = OngnongUIVaultText(OngnongUIVaultQxErrNeedRow);
        return NO;
    }
    if (!R3n3Allowed(target)) {
        if (errorText) *errorText = OngnongUIVaultText(OngnongUIVaultQxErrTargetNotAllowed);
        return NO;
    }
    NSInteger minimum = K4p7e(valid);
    if (maxTotal < minimum) {
        if (errorText) *errorText = [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxErrAutoStopMinimumFormat), (long)minimum];
        return NO;
    }
    if (maxTotal > 10000000) maxTotal = 10000000;
    g_q72Rows = valid;
    g_q72Target = target;
    g_q72MaxTotal = maxTotal;
    g_q72Total = 0;
    g_q72RowIndex = 0;
    g_q72RowCount = 0;
    g_q72LastSpin = 0;
    ++g_q72StopGeneration;
    g_q72PendingTargetSpin = 0;
    g_q72PendingTargetIndex = -1;
    W8c1(R3naSaved, 0, 0);
    W8c4();
    W8c3();
    return YES;
}

BOOL R3nc(BOOL running, NSString **errorText) {
    W8c5();
    if (!running) {
        g_q72Running = NO;
        ++g_q72BetGeneration;
        ++g_q72StopGeneration;
        PauseAutoSpinForCycle();
        W8c1(R3naOff, 0, 0);
        W8c4();
        W8c3();
        return YES;
    }
    NSInteger minimum = K4p7e(g_q72Rows);
    if (!Ongnong::Zx8fBetCycleAllowed() || g_q72Rows.count == 0 || g_q72MaxTotal < minimum || !R3n3Allowed(g_q72Target)) {
        if (errorText) *errorText = OngnongUIVaultText(OngnongUIVaultQxErrSaveBeforeStart);
        return NO;
    }
    if (g_q72RowIndex >= (NSInteger)g_q72Rows.count) g_q72RowIndex = 0;
    g_q72Running = YES;
    W8c1(R3naStarting, 0, 0);
    W8c4();
    W8c3();
    W8cb(W8c7(), OX_NS("start"));
    return YES;
}

void R3nd(BOOL collapsed) {
    W8c5();
    g_q72Collapsed = collapsed;
    W8c4();
    W8c3();
}

void R3ne(void) {
    W8c5();
    g_q72Total = 0;
    g_q72RowIndex = 0;
    g_q72RowCount = 0;
    g_q72LastSpin = 0;
    ++g_q72StopGeneration;
    g_q72PendingTargetSpin = 0;
    g_q72PendingTargetIndex = -1;
    W8c1(R3naResetDone, 0, 0);
    W8c4();
    W8c3();
    if (g_q72Running) W8cb(W8c7(), OX_NS("reset"));
}

static BOOL W8cc(int s1, int s2, int s3) {
    if (!(s1 == s2 && s2 == s3)) return NO;
    int idx = Z1562633390(s1);
    return idx >= 0 && idx == g_q72Target;
}

static void R3n3Reached(void) {
    ++g_q72StopGeneration;
    g_q72Total = 0;
    g_q72RowIndex = 0;
    g_q72RowCount = 0;
    g_q72PendingTargetSpin = 0;
    g_q72PendingTargetIndex = -1;
    W8c1(R3naTargetReached, 0, 0);
    W8c4();
    W8c3();
    W8cb(W8c7(), OX_NS("target"));
}

void R3nf(int symbol1, int symbol2, int symbol3, uint64_t spinSequence) {
    W8c5();
    if (!Ongnong::Zx8fBetCycleAllowed() || !R3n3Allowed(g_q72Target)) {
        R3ni(Ongnong::Zx8fBetCycleAllowed());
        return;
    }
    if (!g_q72Running) return;
    if (spinSequence == 0) spinSequence = Z9c4a7f611b();
    if (spinSequence != 0 && spinSequence == g_q72LastSpin) return;
    g_q72LastSpin = spinSequence;

    g_q72Total++;
    g_q72RowCount++;

    BOOL targetHit = W8cc(symbol1, symbol2, symbol3);
    if (!targetHit && g_q72PendingTargetSpin != 0 && g_q72PendingTargetIndex == g_q72Target) {
        if (g_q72PendingTargetSpin == UINT64_MAX || g_q72PendingTargetSpin == spinSequence) targetHit = YES;
    }
    if (g_q72PendingTargetSpin != 0) {
        g_q72PendingTargetSpin = 0;
        g_q72PendingTargetIndex = -1;
    }

    if (targetHit) {
        R3n3Reached();
        return;
    }

    if (g_q72MaxTotal > 0 && g_q72Total >= g_q72MaxTotal) {
        NSUInteger stopGeneration = ++g_q72StopGeneration;
        uint64_t stopSpinSequence = g_q72LastSpin;
        PauseAutoSpinForCycle();
        W8c1(R3naCheckingTarget, 0, 0);
        W8c4();
        W8c3();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!g_q72Running || stopGeneration != g_q72StopGeneration || stopSpinSequence != g_q72LastSpin) return;
            if (g_q72MaxTotal <= 0 || g_q72Total < g_q72MaxTotal) return;
            if (g_q72AutoRepeat) {
                g_q72Total=0;
                g_q72RowIndex=0;
                g_q72RowCount=0;
                g_q72PendingTargetSpin=0;
                g_q72PendingTargetIndex=-1;
                W8c4();
                W8c3();
                W8cb(W8c7(), OX_NS("repeat"));
                return;
            }
            g_q72Running = NO;
            ++g_q72BetGeneration;
            W8c1(R3naStopped, g_q72Total, g_q72MaxTotal);
            W8c4();
            W8c3();
            W8c8();
        });
        return;
    }

    if (g_q72Rows.count > 0 && g_q72RowIndex < (NSInteger)g_q72Rows.count - 1) {
        NSInteger quota = [g_q72Rows[g_q72RowIndex][OX_NS("spins")] integerValue];
        if (g_q72RowCount >= quota) {
            g_q72RowIndex++;
            g_q72RowCount = 0;
            W8c4();
            W8c3();
            W8cb(W8c7(), OX_NS("next"));
            return;
        }
    }

    W8c1(R3naSpinning, W8c7(), 0);
    W8c4();
    W8c3();
}

void R3ng(int targetIndex, uint64_t requestSnapshot) {
    W8c5();
    if (!Ongnong::Zx8fBetCycleAllowed() || !R3n3Allowed(g_q72Target)) {
        R3ni(Ongnong::Zx8fBetCycleAllowed());
        return;
    }
    if (!g_q72Running || targetIndex != g_q72Target) return;
    uint64_t counterNow = Z9c4a7f611b();
    BOOL currentSpinAlreadyCounted = (requestSnapshot > 0 && counterNow > requestSnapshot);
    if (!currentSpinAlreadyCounted && requestSnapshot == 0 && g_q72LastSpin > 0 && !SlotIsSpinningForCycle()) currentSpinAlreadyCounted = YES;
    if (currentSpinAlreadyCounted) {
        R3n3Reached();
        return;
    }
    g_q72PendingTargetSpin = UINT64_MAX;
    g_q72PendingTargetIndex = targetIndex;
    W8c4();
    W8c3();
}

void R3nh(void) {
    W8c5();
    R3ni(Ongnong::Zx8fBetCycleAllowed());
    if (g_q72Running) W8cb(W8c7(), OX_NS("refresh"));
}

void R3ni(BOOL moduleAllowed) {
    W8c5();
    BOOL changed = NO;
    BOOL mustStop = !moduleAllowed || !R3n3Allowed(g_q72Target);
    if (moduleAllowed && !R3n3Allowed(g_q72Target)) {
        g_q72Target = Z94881eb8d3;
        g_q72PendingTargetSpin = 0;
        g_q72PendingTargetIndex = -1;
        changed = YES;
    }
    if (mustStop && g_q72Running) {
        g_q72Running = NO;
        ++g_q72BetGeneration;
        ++g_q72StopGeneration;
        W8c1(R3naOff, 0, 0);
        PauseAutoSpinForCycle();
        changed = YES;
    }
    if (changed) {
        W8c4();
        W8c3();
    }
}

}
