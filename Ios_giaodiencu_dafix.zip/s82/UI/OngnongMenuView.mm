#import "../Core/OngnongSecureStrings.h"
#import "../Core/OngnongOxorany.h"
#import "OngnongUIVault.h"
#import "OngnongMenuView.h"
#import "X4f0a1.h"
#import "../Core/OngnongState.h"
#import "../Core/OngnongHookManager.h"
#import "../Core/OngnongExtras.h"
#import "../Core/R7f5.h"
#import "../Core/R7f4.h"
#import "../Core/zx8f1a_gate.h"
#import "../Core/Qr73c.h"
#import "../Core/Qr74m.h"
#import "../Autoclick/PTFakeMetaTouch.h"
#import <QuartzCore/QuartzCore.h>
#import <CoreImage/CoreImage.h>
#import <math.h>

@interface ZVipPayController : UIViewController
@property (nonatomic, copy) NSString *orderCode;
@property (nonatomic, copy) NSString *statusToken;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, assign) BOOL stopped;
@end

@implementation ZVipPayController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0.07 alpha:0.98];
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    self.stopped = YES;
}
@end

@interface Z5e8402e1b3 : NSObject
+ (void)m4q8v1;
+ (void)d7x2p6:(BOOL)visible;
+ (BOOL)c3n9k5;
@end

using namespace Ongnong;

static const NSInteger ZHistoryVisibleRows = 22;

static CGFloat z067adc83c5(void) {
    CGSize size = UIScreen.mainScreen.bounds.size;
    CGFloat shortSide = MIN(size.width, size.height);
    if (shortSide <= 390.0) return 0.58;
    if (shortSide <= 430.0) return 0.62;
    return 0.70;
}

static CGFloat zb1d8336499(CGFloat base, CGFloat minSize) {
    return MAX(minSize, base * z067adc83c5());
}

static UIColor *RGB(CGFloat r, CGFloat g, CGFloat b) {
    return [UIColor colorWithRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:1.0];
}

static BOOL Zde31f8c6b2(NSInteger idx) {
    if (idx == Z2f0c1a9d77) return Ongnong::Zx8fPotionAllowed();
    if (idx == Z87f6d0c11d) return Ongnong::Zx8fTokenAllowed();
    if (idx == Z5d92a7e4c1) return Ongnong::Zx8fLightningAllowed();
    return YES;
}

static void Z0418c1e0ae(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (@available(iOS 10.0, *)) {
            UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
            [gen prepare];
            [gen impactOccurred];
        }
    });
}

static NSString *Z6ddd40608f(void) {
    return Ongnong::Zx8fUILabel(OX_NS("main_title"), OX_NS("ÔNG NÔNG"));
}

static NSString *ZAltLanguageText(void) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("zh")]) return OX_NS("中文");
    if ([code isEqualToString:OX_NS("th")]) return OX_NS("ไทย");
    if ([code isEqualToString:OX_NS("it")]) return OX_NS("Italiano");
    if ([code isEqualToString:OX_NS("en")]) return OX_NS("English");
    return OX_NS("Việt Nam");
}

static NSString *ZAltLanguageHeaderText(void) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("zh")]) return OX_NS("语言");
    if ([code isEqualToString:OX_NS("th")]) return OX_NS("ภาษา");
    if ([code isEqualToString:OX_NS("it")]) return OX_NS("LINGUA");
    if ([code isEqualToString:OX_NS("en")]) return OX_NS("LANGUAGE");
    return OX_NS("NGÔN NGỮ");
}

static NSString *ZuiServerPick5(NSString *key, NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("vi")]) return Ongnong::Zx8fMenuLabelVI(key, vi);
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return Ongnong::Zx8fMenuLabelVI(key, vi);
}

static NSString *ZuiPick5(NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return vi ?: OX_NS("");
}

static NSString *ZVipBuyNowText(void) {
    return ZuiServerPick5(OX_NS("buy_vip"), OX_NS("MUA VIP"), OX_NS("购买 VIP"), OX_NS("ซื้อ VIP"), OX_NS("ACQUISTA VIP"), OX_NS("BUY VIP"));
}
static NSString *ZVipVietnamCustomerText(void) {
    return ZuiPick5(OX_NS("🇻🇳 KHÁCH HÀNG VIỆT NAM"), OX_NS("🇻🇳 越南客户"), OX_NS("🇻🇳 ลูกค้าเวียดนาม"), OX_NS("🇻🇳 CLIENTI VIETNAMITI"), OX_NS("🇻🇳 VIETNAM CUSTOMERS"));
}
static NSString *ZVipInternationalCustomerText(void) {
    return ZuiPick5(OX_NS("🌍 KHÁCH HÀNG QUỐC TẾ"), OX_NS("🌍 国际客户"), OX_NS("🌍 ลูกค้าต่างประเทศ"), OX_NS("🌍 CLIENTI INTERNAZIONALI"), OX_NS("🌍 INTERNATIONAL CUSTOMERS"));
}
static NSString *ZVipChoosePlanText(void) {
    return ZuiPick5(OX_NS("CHỌN GÓI VIP"), OX_NS("选择 VIP 套餐"), OX_NS("เลือกแพ็กเกจ VIP"), OX_NS("SCEGLI PACCHETTO VIP"), OX_NS("SELECT VIP PLAN"));
}
static NSString *ZVipCopyText(void) {
    return ZuiPick5(OX_NS("SAO CHÉP"), OX_NS("复制"), OX_NS("คัดลอก"), OX_NS("COPIA"), OX_NS("COPY"));
}
static NSString *ZVipCloseText(void) {
    return ZuiPick5(OX_NS("ĐÓNG"), OX_NS("关闭"), OX_NS("ปิด"), OX_NS("CHIUDI"), OX_NS("CLOSE"));
}
static NSString *ZVipWaitingText(void) {
    return ZuiPick5(OX_NS("Đang chờ thanh toán..."), OX_NS("等待付款..."), OX_NS("กำลังรอการชำระเงิน..."), OX_NS("In attesa del pagamento..."), OX_NS("Waiting for payment..."));
}
static NSString *ZVipActivatedText(void) {
    return ZuiPick5(OX_NS("✓ THANH TOÁN THÀNH CÔNG — VIP ĐÃ ĐƯỢC KÍCH HOẠT"), OX_NS("✓ 支付成功 — VIP 已激活"), OX_NS("✓ ชำระเงินสำเร็จ — เปิด VIP แล้ว"), OX_NS("✓ PAGAMENTO RIUSCITO — VIP ATTIVATO"), OX_NS("✓ PAYMENT SUCCESSFUL — VIP ACTIVATED"));
}
static NSString *ZVipPaidText(void) {
    return ZuiPick5(OX_NS("Đã nhận thanh toán, đang kích hoạt VIP..."), OX_NS("已收到付款，正在激活 VIP..."), OX_NS("รับชำระเงินแล้ว กำลังเปิด VIP..."), OX_NS("Pagamento ricevuto, attivazione VIP..."), OX_NS("Payment received, activating VIP..."));
}
static NSString *ZVipMoney(NSInteger amount) {
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    f.numberStyle = NSNumberFormatterDecimalStyle;
    f.groupingSeparator = OX_NS(".");
    f.usesGroupingSeparator = YES;
    return [NSString stringWithFormat:OX_NS("%@đ"), [f stringFromNumber:@(amount)] ?: @(amount).stringValue];
}

static NSDictionary *ZVipJSON(NSData *data) {
    if (!data.length) return nil;
    id obj = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    return [obj isKindOfClass:[NSDictionary class]] ? obj : nil;
}

static UIImage *ZVipQRImage(NSString *payload, CGFloat side) {
    if (payload.length == 0) return nil;
    NSData *data = [payload dataUsingEncoding:NSUTF8StringEncoding];
    CIFilter *filter = [CIFilter filterWithName:OX_NS("CIQRCodeGenerator")];
    [filter setValue:data forKey:OX_NS("inputMessage")];
    [filter setValue:OX_NS("M") forKey:OX_NS("inputCorrectionLevel")];
    CIImage *out = filter.outputImage;
    if (!out) return nil;
    CGRect extent = CGRectIntegral(out.extent);
    CGFloat scale = MIN(side / CGRectGetWidth(extent), side / CGRectGetHeight(extent));
    CIImage *scaled = [out imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
    CIContext *ctx = [CIContext contextWithOptions:nil];
    CGImageRef cg = [ctx createCGImage:scaled fromRect:scaled.extent];
    if (!cg) return nil;
    UIImage *img = [UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp];
    CGImageRelease(cg);
    return img;
}


static UIImage *Z9a3e7f9348(void) {
    static UIImage *wifiImage = nil;
    if (wifiImage) return wifiImage;

    CGSize size = CGSizeMake(64.0, 64.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(ctx, UIColor.whiteColor.CGColor);
    CGContextSetFillColorWithColor(ctx, UIColor.whiteColor.CGColor);
    CGContextSetLineWidth(ctx, 6.5);
    CGContextSetLineCap(ctx, kCGLineCapRound);

    CGPoint c = CGPointMake(32.0, 47.0);
    CGFloat start = 1.17 * M_PI;
    CGFloat end = 1.83 * M_PI;
    CGContextAddArc(ctx, c.x, c.y, 28.0, start, end, 0);
    CGContextStrokePath(ctx);
    CGContextAddArc(ctx, c.x, c.y, 19.0, start, end, 0);
    CGContextStrokePath(ctx);
    CGContextAddArc(ctx, c.x, c.y, 10.0, start, end, 0);
    CGContextStrokePath(ctx);
    CGContextFillEllipseInRect(ctx, CGRectMake(27.0, 45.0, 10.0, 10.0));

    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    wifiImage = [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    return wifiImage;
}

static const CGFloat Ze25ebfed17 = 190.0;
static const CGFloat Zed1192a6d1 = 100.0;

static NSString *ZThemeNotify(void) { return OX_NS("ongnong_theme_changed"); }
static NSString *ZThemeKeyR(void) { return OX_NS("om_theme_r"); }
static NSString *ZThemeKeyG(void) { return OX_NS("om_theme_g"); }
static NSString *ZThemeKeyB(void) { return OX_NS("om_theme_b"); }
static NSString *ZThemeKeyA(void) { return OX_NS("om_theme_a"); }
static NSString *ZThemeVisibleKey(void) { return OX_NS("om_color_visible"); }
static NSString *ZThemePosXKey(void) { return OX_NS("om_color_x"); }
static NSString *ZThemePosYKey(void) { return OX_NS("om_color_y"); }
static NSString *Z0f21de981b(void) { return OX_NS("om_qx_slot"); }

static CGFloat g_themeR = 34.0 / 255.0;
static CGFloat g_themeG = 54.0 / 255.0;
static CGFloat g_themeB = 88.0 / 255.0;
static CGFloat g_themeA = 0.86;
static BOOL g_themeLoaded = NO;

static CGFloat ZClamp01(CGFloat v) { return MAX(0.0, MIN(1.0, v)); }
static void ZThemeDefaults(void) {
    g_themeR = 34.0 / 255.0;
    g_themeG = 54.0 / 255.0;
    g_themeB = 88.0 / 255.0;
    g_themeA = 0.86;
}
static void ZThemeLoad(void) {
    if (g_themeLoaded) return;
    g_themeLoaded = YES;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if ([ud objectForKey:ZThemeKeyR()]) g_themeR = ZClamp01([ud floatForKey:ZThemeKeyR()]);
    if ([ud objectForKey:ZThemeKeyG()]) g_themeG = ZClamp01([ud floatForKey:ZThemeKeyG()]);
    if ([ud objectForKey:ZThemeKeyB()]) g_themeB = ZClamp01([ud floatForKey:ZThemeKeyB()]);
    if ([ud objectForKey:ZThemeKeyA()]) g_themeA = ZClamp01([ud floatForKey:ZThemeKeyA()]);
    if (g_themeA < 0.30) g_themeA = 0.30;
}
static void ZThemeSave(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setFloat:g_themeR forKey:ZThemeKeyR()];
    [ud setFloat:g_themeG forKey:ZThemeKeyG()];
    [ud setFloat:g_themeB forKey:ZThemeKeyB()];
    [ud setFloat:g_themeA forKey:ZThemeKeyA()];
    [ud synchronize];
}
static UIColor *ZThemePanelColor(void) { ZThemeLoad(); return [UIColor colorWithRed:g_themeR green:g_themeG blue:g_themeB alpha:g_themeA]; }
static UIColor *ZThemePanelDarker(void) { ZThemeLoad(); return [UIColor colorWithRed:g_themeR * 0.72 green:g_themeG * 0.72 blue:g_themeB * 0.72 alpha:MIN(0.94, g_themeA + 0.08)]; }
static UIColor *ZThemeButtonOff(void) { ZThemeLoad(); return [UIColor colorWithRed:g_themeR * 0.82 green:g_themeG * 0.82 blue:g_themeB * 0.82 alpha:MIN(0.90, g_themeA + 0.02)]; }
static UIColor *ZThemeBorder(void) { return RGB(82, 211, 255); }
static UIColor *ZThemeActiveGreen(void) { return RGB(30, 165, 255); }
static UIColor *ZThemeOnGreen(void) { return RGB(30, 185, 95); }
static UIColor *ZThemeOffRed(void) { return RGB(210, 42, 48); }
static UIColor *ZThemeOrange(void) { return RGB(245, 152, 44); }
static UIColor *ZThemeWhite(void) { return [UIColor whiteColor]; }
static UIColor *ZThemeHisWhite(void) { return [UIColor colorWithWhite:0.96 alpha:1.0]; }
static UIColor *ZThemeGapYellow(void) { return RGB(255, 238, 83); }

static void ApplyNeon(UIView *view, UIColor *color, CGFloat radius, CGFloat width) {
    view.layer.cornerRadius = radius;
    view.layer.borderWidth = width;
    view.layer.borderColor = color.CGColor;
    view.layer.shadowOpacity = 0.0;
    view.layer.shadowRadius = 0.0;
    view.layer.shadowOffset = CGSizeZero;
    view.layer.shadowColor = [UIColor clearColor].CGColor;
}

static UILabel *Label(NSString *text, CGFloat size, UIFontWeight weight, UIColor *color, NSTextAlignment alignment) {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.text = text;
    label.textColor = color;
    label.font = [UIFont systemFontOfSize:size weight:weight];
    label.textAlignment = alignment;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.55;
    label.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    return label;
}

static CGFloat Z7cb9c1a47a(CGFloat width, NSUInteger len, CGFloat maxSize, CGFloat minSize, CGFloat k) {
    CGFloat w = MAX(1.0, width);
    CGFloat n = MAX(1.0, (CGFloat)MAX((NSUInteger)1, len));
    CGFloat f = w / MAX(1.0, n * k);
    return MAX(minSize, MIN(maxSize, f));
}

static void Z611a3d09ce(UIButton *button, CGFloat maxSize, CGFloat minSize) {
    if (!button) return;
    NSString *text = [button titleForState:UIControlStateNormal] ?: [NSString string];
    CGFloat innerW = MAX(1.0, button.bounds.size.width - 2.0);
    CGFloat f = Z7cb9c1a47a(innerW, text.length, maxSize, minSize, 0.72);
    button.titleLabel.font = [UIFont systemFontOfSize:f weight:UIFontWeightBlack];
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    button.titleLabel.minimumScaleFactor = 0.18;
    button.titleLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    button.titleLabel.lineBreakMode = NSLineBreakByClipping;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
}

static void Z3218ec4b5a(UILabel *label, NSString *text, CGFloat maxSize, CGFloat minSize, UIFontWeight weight) {
    if (!label) return;
    NSString *v = text ?: [NSString string];
    label.text = v;
    CGFloat innerW = MAX(1.0, label.bounds.size.width - 1.0);
    CGFloat f = Z7cb9c1a47a(innerW, v.length, maxSize, minSize, 0.60);
    label.font = [UIFont monospacedDigitSystemFontOfSize:f weight:weight];
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.30;
    label.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    label.lineBreakMode = NSLineBreakByClipping;
}

static UIImage *ZCounterTrashIconImage(void) {
    CGSize size = CGSizeMake(32.0, 32.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    UIColor *c = [UIColor whiteColor];
    [c setStroke];
    [c setFill];
    UIBezierPath *lid = [UIBezierPath bezierPath];
    lid.lineWidth = 2.8;
    lid.lineCapStyle = kCGLineCapRound;
    [lid moveToPoint:CGPointMake(8.0, 10.0)];
    [lid addLineToPoint:CGPointMake(24.0, 10.0)];
    [lid moveToPoint:CGPointMake(13.0, 7.0)];
    [lid addLineToPoint:CGPointMake(19.0, 7.0)];
    [lid stroke];

    UIBezierPath *body = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(10.0, 12.0, 12.0, 14.0) cornerRadius:2.4];
    body.lineWidth = 2.6;
    [body stroke];

    UIBezierPath *lines = [UIBezierPath bezierPath];
    lines.lineWidth = 1.8;
    lines.lineCapStyle = kCGLineCapRound;
    [lines moveToPoint:CGPointMake(14.0, 15.0)];
    [lines addLineToPoint:CGPointMake(14.0, 23.0)];
    [lines moveToPoint:CGPointMake(18.0, 15.0)];
    [lines addLineToPoint:CGPointMake(18.0, 23.0)];
    [lines stroke];

    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

static UIImage *ZCounterEyeIconImage(BOOL slash) {
    CGSize size = CGSizeMake(32.0, 32.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);

    UIColor *eyeStroke = RGB(90, 235, 255);
    UIColor *pupilFill = RGB(255, 220, 55);
    UIColor *pupilRing = RGB(255, 255, 255);
    UIColor *slashColor = RGB(255, 80, 80);

    UIBezierPath *eye = [UIBezierPath bezierPath];
    eye.lineWidth = 2.8;
    eye.lineCapStyle = kCGLineCapRound;
    eye.lineJoinStyle = kCGLineJoinRound;
    [eye moveToPoint:CGPointMake(4.0, 16.0)];
    [eye addCurveToPoint:CGPointMake(16.0, 8.0) controlPoint1:CGPointMake(7.5, 10.5) controlPoint2:CGPointMake(11.5, 8.0)];
    [eye addCurveToPoint:CGPointMake(28.0, 16.0) controlPoint1:CGPointMake(20.5, 8.0) controlPoint2:CGPointMake(24.5, 10.5)];
    [eye addCurveToPoint:CGPointMake(16.0, 24.0) controlPoint1:CGPointMake(24.5, 21.5) controlPoint2:CGPointMake(20.5, 24.0)];
    [eye addCurveToPoint:CGPointMake(4.0, 16.0) controlPoint1:CGPointMake(11.5, 24.0) controlPoint2:CGPointMake(7.5, 21.5)];
    [eyeStroke setStroke];
    [eye stroke];

    UIBezierPath *ring = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10.4, 10.4, 11.2, 11.2)];
    ring.lineWidth = 1.6;
    [pupilRing setStroke];
    [ring stroke];

    UIBezierPath *pupil = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(12.3, 12.3, 7.4, 7.4)];
    [pupilFill setFill];
    [pupil fill];

    if (slash) {
        UIBezierPath *line = [UIBezierPath bezierPath];
        line.lineWidth = 3.2;
        line.lineCapStyle = kCGLineCapRound;
        [line moveToPoint:CGPointMake(7.0, 25.0)];
        [line addLineToPoint:CGPointMake(25.0, 7.0)];
        [slashColor setStroke];
        [line stroke];
    }

    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return [img imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

static void ZPlainIconButton(UIButton *button, UIImage *image) {
    if (!button) return;
    [button setTitle:[NSString string] forState:UIControlStateNormal];
    [button setImage:image forState:UIControlStateNormal];
    button.tintColor = ZThemeWhite();
    button.backgroundColor = [UIColor clearColor];
    button.imageView.contentMode = UIViewContentModeScaleAspectFit;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    button.contentEdgeInsets = UIEdgeInsetsMake(1.0, 1.0, 1.0, 1.0);
    button.layer.cornerRadius = 0.0;
    button.layer.borderWidth = 0.0;
    button.layer.borderColor = [UIColor clearColor].CGColor;
    button.layer.shadowOpacity = 0.0;
    button.layer.shadowRadius = 0.0;
    button.layer.shadowOffset = CGSizeZero;
    button.layer.shadowColor = [UIColor clearColor].CGColor;
}

static NSString *ZuiLanguageButtonText(void) { return OngnongUIVaultText(OngnongUIVaultLangButton); }
static NSString *ZuiHistoryText(void) { return OngnongUIVaultText(OngnongUIVaultHistory); }
static NSString *ZuiAutoBuildText(void) { return OngnongUIVaultText(OngnongUIVaultAutoBuild); }
static NSString *ZuiAutoPigHammerText(void) { return OngnongUIVaultText(OngnongUIVaultPigHammer); }
static NSString *ZuiToolsText(void) { return OngnongUIVaultText(OngnongUIVaultTools); }
static NSString *ZuiAutoClickText(void) { return OngnongUIVaultText(OngnongUIVaultAutoClick); }
static NSString *ZuiUpdateText(void) { return OngnongUIVaultText(OngnongUIVaultUpdate); }
static NSString *ZuiBuyVipText(void) { return OngnongUIVaultText(Ongnong::Zx8fIsVIP() ? OngnongUIVaultActiveRestoreVip : OngnongUIVaultBuyVip); }
static NSString *ZuiAutoTargetText(void) { return OngnongUIVaultText(OngnongUIVaultAutoTarget); }
static NSString *ZuiBetCycleText(void) { return OngnongUIVaultText(OngnongUIVaultQxMenu); }
static NSString *ZuiSetText(void) { return OngnongUIVaultText(OngnongUIVaultSet); }
static NSString *ZuiSaveText(void) { return OngnongUIVaultText(OngnongUIVaultSave); }
static NSString *ZuiCancelText(void) { return OngnongUIVaultText(OngnongUIVaultCancel); }
static NSString *ZuiAutoTargetPrompt(void) { return OngnongUIVaultText(OngnongUIVaultTargetPrompt); }
static NSString *ZuiSkipText(void) { return OngnongUIVaultText(OngnongUIVaultSkip); }
static NSString *ZuiSpeedTitle(void) { return OngnongUIVaultText(OngnongUIVaultSpeedTitle); }
static NSString *ZuiSpeedMessage(void) { return OngnongUIVaultText(OngnongUIVaultSpeedMessage); }
static NSString *ZuiLanguageTitle(void) { return OngnongUIVaultText(OngnongUIVaultLanguageTitle); }
static NSString *ZuiMenuColorText(void) { return OngnongUIVaultText(OngnongUIVaultMenuColor); }
static NSString *ZuiMagicCardsText(void) { return OngnongUIVaultText(OngnongUIVaultMagicCards); }
static NSString *ZuiMagicCardsQuickText(void) { return OngnongUIVaultText(OngnongUIVaultMagicCardsQuick); }
static NSString *ZuiAutoMergeText(void) {
    return OngnongUIVaultText(OngnongUIVaultAutoMerge);
}
static NSString *ZuiFriendInviteText(void) { return OngnongUIVaultText(OngnongUIVaultFriendInvite); }
static NSString *ZuiPotionStateText(BOOL on) { return OngnongUIVaultText(on ? OngnongUIVaultPotionOn : OngnongUIVaultPotionOff); }
static NSString *ZuiFriendClearText(void) { return OngnongUIVaultText(OngnongUIVaultFriendClear); }
static NSString *ZuiInterfaceText(void) { return ZuiServerPick5(OX_NS("interface"), OX_NS("GIAO DIỆN"), OX_NS("界面"), OX_NS("หน้าตา"), OX_NS("INTERFACCIA"), OX_NS("INTERFACE")); }
static NSString *ZuiMagicCardsStateText(BOOL on) { return [NSString stringWithFormat:OX_NS("%@ %@"), ZuiMagicCardsText(), on ? OX_NS("ON") : OX_NS("OFF")]; }
static NSString *ZuiAutoBuildStateText(BOOL on) { return [NSString stringWithFormat:OX_NS("%@ %@"), ZuiAutoBuildText(), on ? OX_NS("ON") : OX_NS("OFF")]; }
static NSString *ZuiAutoPigHammerStateText(BOOL on) { return [NSString stringWithFormat:OX_NS("%@ %@"), ZuiAutoPigHammerText(), on ? OX_NS("ON") : OX_NS("OFF")]; }
static NSString *Zr7f421(void) { return Ongnong::R7f402(); }
static NSString *Zr7f422(BOOL on) { return Ongnong::R7f403(on); }

static NSString *Z3dc983e2b1(NSString *name) {
    if ([name isEqualToString:qsec_s_0021()]) return qsec_s_0022();
    if ([name isEqualToString:qsec_s_0023()]) return qsec_s_0024();
    if ([name isEqualToString:qsec_s_0025()]) return qsec_s_0026();
    if ([name isEqualToString:qsec_s_0027()]) return qsec_s_0028();
    return nil;
}

static UIImage *Z0da1985399(NSString *name) {
    static NSMutableDictionary *z92a7d4c1 = nil;
    static dispatch_once_t z6cbe0d29;
    dispatch_once(&z6cbe0d29, ^{
        z92a7d4c1 = [NSMutableDictionary dictionary];
    });
    UIImage *cached = name ? [z92a7d4c1 objectForKey:name] : nil;
    if (cached) return cached;
    NSString *b64 = Z3dc983e2b1(name);
    if (!b64) return nil;
    NSData *data = [[NSData alloc] initWithBase64EncodedString:b64 options:0];
    if (!data) return nil;
    UIImage *img = [UIImage imageWithData:data];
    if (img && name) [z92a7d4c1 setObject:img forKey:name];
    return img;
}

static UIImage *Z67b9f0c2a1(void) {
    static UIImage *img = nil;
    if (img) return img;
    NSString *b64 =
        @"iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAMwElEQVR42rWYa5BlVXXHf2vvc85937797p4Hw9DMjEMPIGSI"
        @"+EC7AZVUfORLdyqiJj4pH3mUiSWVVHKnfVQRQU1VPlhgFKRSJt6ORkkkTnAcQDSENwUzDMK8H9093T093X2f55y9Vz6MpkoM"
        @"zEDwVO2vZ/1q/9f677WW8Kp9IdWvxJU1+QfK0OaEubY+9dHSKbQFOAB0AktNvYjouf5V/j9IqioA90/f/Id9xWffn/XHNwfJ"
        @"apm4g2tro90KZjs68FQ9uuhHhy686Z73vcXMgFKtVs3U1JT/jQLu3l0Nxsan3L3TX/rwG1/75G1hex80FRpNaLYh6YDrgPMk"
        @"rQxHVvtOnwwu/6dnX3P7Zz8wLrOqKudyk+aVAo7N71XBqpx6/G1h9wWe7G91XDurrlNSl3Rr0q5o3K74uFN0YlI3UjpYeX3h"
        @"+x973bNXP3T39N2XiYhqtXrW+PaVwNVqE3bb5LS75ztfvW7dwreqpfaC5fI/CykMi1k5LCaJxXhEMCIaGEdgUpNRVU0Gi8d6"
        @"VpeOvmn4/c//w9gnx93Ub+IG+/ecFFUVv/rkZZu3SIbGfm+e/SKyvBfXt5Vk+GIY3ojtGyTo6SHT1UU2VxQJyyFByRfd/NDe"
        @"A+QE9Jd5/GJf8EoA50cHVET0/q997QfPzD35+a3bQ0O7gT+6k2RuiaUloRkXsbkcJhR23jPHb2+vMNiN1o+tmAPxhuaXbiae"
        @"vvHssV42YLVaNRMTO/y/7/rZhp/kX/tF7vo5rZm7ZfS6TWRKDXRuhXhxjubcHK0mtBPoacPMowvMOG8KeavZ8v71j371pouA"
        @"R9mxQwB9FSUeMyKih11lavPm/Nuf6Lnaz+zeIw/fej9PP7hIW0PKPXlKPSHFSkC+aDlvwFDIQLYQal/Riea6lsOtHzwOwI4d"
        @"+qrm4N7RMVVVOZ6a3o05XGF4RI6FRTbpKZYeOsCPvnOS+x707J8znG4LiYe2FzoSQDvxT0VXEF9z0yfeMT44W6vV7Nms5hXk"
        @"4B4rss2985+ftZvnsF+7fpO7f+gu7vtelfOjnzC02ubwETjYgVgMHsEjVMKYufJWnn7Xd7kk4ErgW9PTZ49mzj331IAwPbkt"
        @"1t21otV07cFldKmZypXXjLPls/dz5D272HfZx1gc3EYS5UljT7PuaDdSZmWIOzf+lfStXUevrP4uwPT0pHtViqRWUzs5KU6r"
        @"VfPNd37khq/G9s+zJTtS1ERnGtasnI5ZaEGy9WrMlqvR5ZjW7HGaC3OkzToSZAgHNvDJgX7tXet57rH0MVVlcnraTk++NORZ"
        @"AWuqdlLE3fKDvZtr6/q+sWVN/xsXW3BJPtFiWSXXZ1iaDzlZT3hqdpkjy006XlHJYXIjRHkhL46wXue/Vxc1Ywd43fLCv4mI"
        @"fvTWR8z/dhKvBLBWq52B2/XcG7au6/veGzZV+q2QnqinJp4Vs//HCQ9nlhl5S4lCdxZdTIl9yPxyk1MrDZqtFnGrQ9xJ8C4k"
        @"e/mF5m3a1Fxx4ENfv/+xuz/05svnq1U1U1PiXzZgVdVMirgv3fPMxZuG+/7jzZsr5TwuPfj9NFjcKQyfMBSOhzx2wvFQ714y"
        @"Y1laWypIySKRYIsBgc1ACJGPsF3dVEZKJl5J/YaLR68y9ZmdN92zf7z1AKsv1TgEL9ZG7QBu3vlEYbi7Mn3ZSKWsaeIO3JwG"
        @"/Cxg23pLqwinB6EnGmR2oYc9d8xwKjlGbrBN95AhLCuNwOO8hyCiPxNzaeApX5kxR5eSZPvG4cvS5Oid752Sd+8dVftiUstL"
        @"FcXXHzh40xUXn/+ZvqJPW1/sBKVDIf03GrStpLtg9VHh9IJy7Kjn8NGYRjumnXSoJ01a2iaWlNQo3ggilqHiAOs+USTzkZDF"
        @"0ybZ2G3Cg8///AMfG99yxy9jnvUGq1U1k5PibvnhU+u7y11/HOXwyz9u2cozEf1/a/BDIBjMWqUsysK3YWa/I3YOa4R8Jks2"
        @"k0G9IiIokKonFYfvQOOWGFNWMhMZO1dHu7srn6/ufvpfJsdo/F9S/7oPjt1rALJh7o8G13Tn09XUP/65RArvMjAExIJPweZh"
        @"dUZ57gkPxpAJAqxaxAviz7yuzntSl6LqERUwnqYmtG73JIcTs5R4H3UNrB3S8HpEdMe999qzGvWOsTEHSBhE786V0Jn7OtJ8"
        @"LAtHBV0AjcAGkNTgmW8IHQCjiBisGAwGwWB/ecQgCuIUEwt9hQLLp1d58tszSGRYbKGZTOa9ANx7r39JiavVqhER//nvPDIc"
        @"RNmtziPHdnozdH6GbAfcLrAjytIxx0N/10GKEYXQkjQCYq901CE+xXjFo2ceOVUiK4ShQFY5njvBzpnHyd63lrXvWW/ahUB6"
        @"THjpp27d3Td1w/jCC2X+FcDR0VEBCMJgpFgq5jurTusHrFx0oRAr+INK8Lzlttvm+Wm0wvbbLqD5mVkKc46yzZLrBIQSEhlB"
        @"8ThxtE2HU67BiXiJ/c0Zjp1axHqDm2+ydKQtuQuLWpZcqauUHQEWJqenf8W8X1AkE2dKW4Iek8nSrnvvYmuzm4VGVsHBnn2O"
        @"XScTfF/IrjvqNA4vk55aIsp7shlFmwlhoBhNcT4ldjGdNCFOYywQ2ggMJKmnvpBgLsQHUd7aQPrOEEwwfTYf9N5Jx0PiIS0K"
        @"Sa/SqoCLhV3HExYKBYK0SXLXIpLJYLK95C7PE13Txfzn9iGSID7BaIBoQBAoYaDgY5wmGBVsmCFOlMSBBhYxQXjORp0Pw9PN"
        @"VkyxEEraL9RLUOqF2ZPKYx1DcyiHiUK8pmiSYkoJ8Zyg320i/b0Yn2JcDD5GXAdNU4xz2Cgi9I5AFcnl8aEhTRFvY+JOXAeY"
        @"finAPXvOtN7dhfjIfL2R5Ms9YXvE61wG6eqG5xfhUK+h1WNQLN5F0HFIx2MTj22n0Bdh4xQbd7BJBxN3yJYdYQh+sUkgSlYt"
        @"vrcIXSGiGN9a8XG7eQLgogle3AenplBQeZ9fOiouPtBwSvYSdJ+FlTIcKsHpDULnAqG5wdLYYGmcH9I4P6KxIUPj/Dyt4Tyt"
        @"wQKt/jJxb4Uk6KJw/QUU/mIrRF0Yk8eUykQbivjuyBcDpRj64yeOHD0AsOMF88kLJBat7tZAxsfTOx8+eteSk09n1ovf1xLT"
        @"nSone6G+HtRC6sCpQCKYWDEtsC0laFps0xI0A1wzJIoi5p8VguNtgnyBMM0Qd0f0jBYhZ/15JRG7kv7km1MfaNdqakV+9bn7"
        @"9RwcwwMMZNJv1FdXPrXfFczAiNcfNq34gqezBpwFVVB3xhAkEaQDNAXbUsKGJVg1uFWLK1j8YkJ4yJEtFQgjJbPRYi/N0xsZ"
        @"6aYtiyv128+55Z8S8RO1mr3uko37wuWZrxcja05779YMKceygg6BDggMgAwCA+D7wQ2CroV0jdBeK7TXGdprDe2hgPa6DJ31"
        @"OZI1WWRTDhkrUOyz7rIB7MKJQw9+/HdGd1WrVXNOzQJAbWLC76iqybcfuLF/NX/dAVl/3qnZtlt/XmT3B0LSASO/aIYSyGcV"
        @"TaC9KEisaBPiOviCQB5Ytti2IQwswRbou8joaJdVtzyvq8v1PwV0dHTUnPPQJCLKDrj+HVctFZOVie1mvhUvRfbggy3d0Ejo"
        @"6lbMoMH3gHYDXb843UCPQI8gfeD7hbhfYBiyrzHkrwpYf6noBlzaG2qwvDD7lzdOXvHQRK1mJ19kNpFzGZZu/88nr5kL+mp3"
        @"z5Yrj8/Gkhs0Uh7J0BgOWS1Y2ghpqpACHYGWQgNsQ6ikMJyBnqxil5q+fDrVt24p23Dp+b+/4erNf1Kt7g6mpsbTV7wfrNae"
        @"jqYmt8Wf/dcn/vrCSy+d+vJ9K+mTM0loQkPUExD2B5g+i+YFHyipEYyDqA25hifXSXGnYhrHm25LJW/fsdXSowuf++CbRv5m"
        @"olaz05MTHl58eD/rVDfKqKuqms739/5XlHbkC+O54Cs/TdNdp8SuDuWE4QCcEqx4TMsjbWDF055rs7zSJG20qET4a0eL9g1r"
        @"Vg+U2yuf/uA1F3/3DNykf6m9zDntB6enp3SMHfKFjw/sf83Vv98Y6i2OT1xRCbcUEBu33UqY+HrB4bvB9QmubHCxIEspeZfq"
        @"lZsK8Sfe2h8WVp77xzE59K53vv1NT9Rqaqcmt7lzmcnPfQWsKojoF+7ed0lfT9dnCoXsu7srlUKscLgJh1sJJxqexbrSqUPG"
        @"C6XI8NoNIaXTR5vLs8dHp/7g9YdufeSR8Ibt25PfyBL9F7I4gOpdT5+XBLlrC5F5SzkbjJYiO+xVivW2D5djjb36lSSOj/WV"
        @"oocHTOe266/atMerGhHxLyfmy16iV1XN3mlk+gWmeu1N93StC1y5O0smZ5PWBaFb+ciHf29VX6DAy433P3P9PKhp79phAAAA"
        @"AElFTkSuQmCC";
    NSData *data = [[NSData alloc] initWithBase64EncodedString:b64 options:0];
    if (!data) return nil;
    img = [UIImage imageWithData:data];
    return img;
}

static UIImage *Zc83f0d7b42(void) {
    static UIImage *img = nil;
    if (img) return img;

    CGSize size = CGSizeMake(48.0, 48.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextClearRect(ctx, CGRectMake(0.0, 0.0, size.width, size.height));

    CGPoint c = CGPointMake(24.0, 24.0);

    UIColor *glowOuter = [RGB(95, 240, 255) colorWithAlphaComponent:0.42];
    [glowOuter setStroke];
    UIBezierPath *glowRing = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(4.0, 4.0, 40.0, 40.0)];
    glowRing.lineWidth = 4.0;
    [glowRing stroke];

    UIColor *glowInner = [RGB(170, 255, 255) colorWithAlphaComponent:0.24];
    [glowInner setFill];
    UIBezierPath *halo = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(7.0, 7.0, 34.0, 34.0)];
    [halo fill];

    UIBezierPath *outer = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(8.0, 8.0, 32.0, 32.0)];
    [RGB(255, 221, 58) setFill];
    [outer fill];

    UIBezierPath *rimShade = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10.1, 10.1, 27.8, 27.8)];
    [RGB(255, 147, 33) setFill];
    [rimShade fill];

    UIBezierPath *rim = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(11.6, 11.6, 24.8, 24.8)];
    [RGB(119, 43, 197) setFill];
    [rim fill];

    UIBezierPath *body = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(13.5, 13.5, 21.0, 21.0)];
    [RGB(196, 61, 255) setFill];
    [body fill];

    UIBezierPath *highlight = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(16.0, 14.0, 8.6, 6.4)];
    [[UIColor colorWithWhite:1.0 alpha:0.44] setFill];
    [highlight fill];

    UIBezierPath *bolt = [UIBezierPath bezierPath];
    [bolt moveToPoint:CGPointMake(26.2, 11.0)];
    [bolt addLineToPoint:CGPointMake(16.3, 24.3)];
    [bolt addLineToPoint:CGPointMake(22.0, 24.3)];
    [bolt addLineToPoint:CGPointMake(18.7, 37.0)];
    [bolt addLineToPoint:CGPointMake(31.8, 20.8)];
    [bolt addLineToPoint:CGPointMake(25.1, 20.8)];
    [bolt closePath];
    [RGB(255, 246, 73) setFill];
    [bolt fill];
    [RGB(255, 116, 23) setStroke];
    bolt.lineWidth = 1.35;
    [bolt stroke];

    CGContextSetLineCap(ctx, kCGLineCapRound);
    CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithWhite:1.0 alpha:0.70].CGColor);
    CGContextSetLineWidth(ctx, 1.7);
    CGContextAddArc(ctx, c.x, c.y, 14.5, 1.05 * M_PI, 1.40 * M_PI, 0);
    CGContextStrokePath(ctx);

    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

static UIImage *Z71a4c9e2d6(void) {
    static UIImage *img = nil;
    static CGFloat lastR = -1.0;
    static CGFloat lastG = -1.0;
    static CGFloat lastB = -1.0;
    static CGFloat lastA = -1.0;
    ZThemeLoad();
    if (img && fabs(lastR - g_themeR) < 0.0001 && fabs(lastG - g_themeG) < 0.0001 && fabs(lastB - g_themeB) < 0.0001 && fabs(lastA - g_themeA) < 0.0001) return img;
    lastR = g_themeR;
    lastG = g_themeG;
    lastB = g_themeB;
    lastA = g_themeA;

    CGSize size = CGSizeMake(48.0, 48.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextClearRect(ctx, CGRectMake(0.0, 0.0, size.width, size.height));

    UIColor *themeGlow = [ZThemeBorder() colorWithAlphaComponent:0.28];
    UIColor *themeAura = [ZThemeButtonOff() colorWithAlphaComponent:0.22];
    UIColor *outline = RGB(122, 66, 14);
    UIColor *sideShade = RGB(219, 146, 18);
    UIColor *mainFill = RGB(255, 238, 78);
    UIColor *mainFill2 = RGB(255, 224, 53);
    UIColor *shadow = [UIColor colorWithWhite:0.0 alpha:0.14];

    UIBezierPath *shadowPath = [UIBezierPath bezierPath];
    [shadowPath moveToPoint:CGPointMake(17.0, 8.5)];
    [shadowPath addQuadCurveToPoint:CGPointMake(25.3, 10.8) controlPoint:CGPointMake(22.0, 7.8)];
    [shadowPath addLineToPoint:CGPointMake(33.9, 14.5)];
    [shadowPath addLineToPoint:CGPointMake(34.2, 23.0)];
    [shadowPath addQuadCurveToPoint:CGPointMake(31.5, 26.6) controlPoint:CGPointMake(34.2, 25.4)];
    [shadowPath addLineToPoint:CGPointMake(39.0, 31.6)];
    [shadowPath addQuadCurveToPoint:CGPointMake(39.2, 35.3) controlPoint:CGPointMake(40.4, 33.6)];
    [shadowPath addLineToPoint:CGPointMake(22.8, 46.4)];
    [shadowPath addQuadCurveToPoint:CGPointMake(18.3, 45.2) controlPoint:CGPointMake(20.1, 47.6)];
    [shadowPath addLineToPoint:CGPointMake(12.4, 40.2)];
    [shadowPath addQuadCurveToPoint:CGPointMake(11.7, 35.9) controlPoint:CGPointMake(10.9, 38.6)];
    [shadowPath addLineToPoint:CGPointMake(17.5, 28.1)];
    [shadowPath addLineToPoint:CGPointMake(14.1, 24.8)];
    [shadowPath addQuadCurveToPoint:CGPointMake(13.2, 20.2) controlPoint:CGPointMake(12.7, 23.0)];
    [shadowPath addLineToPoint:CGPointMake(13.0, 11.8)];
    [shadowPath closePath];
    CGContextSaveGState(ctx);
    CGContextTranslateCTM(ctx, 1.0, 1.2);
    [shadow setFill];
    [shadowPath fill];
    CGContextRestoreGState(ctx);

    UIBezierPath *aura = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(7.0, 5.0, 33.0, 38.0) cornerRadius:12.0];
    [themeAura setFill];
    [aura fill];

    UIBezierPath *glow = [UIBezierPath bezierPath];
    [glow moveToPoint:CGPointMake(15.8, 7.4)];
    [glow addLineToPoint:CGPointMake(24.9, 10.1)];
    [glow addLineToPoint:CGPointMake(33.0, 13.8)];
    [glow addLineToPoint:CGPointMake(32.5, 22.2)];
    [glow addLineToPoint:CGPointMake(29.6, 25.4)];
    [glow addLineToPoint:CGPointMake(36.5, 30.4)];
    [glow addLineToPoint:CGPointMake(21.7, 43.7)];
    [glow addLineToPoint:CGPointMake(14.0, 38.7)];
    [glow addLineToPoint:CGPointMake(19.6, 28.2)];
    [glow addLineToPoint:CGPointMake(15.3, 24.3)];
    [glow addLineToPoint:CGPointMake(15.0, 12.8)];
    [glow closePath];
    [themeGlow setStroke];
    glow.lineWidth = 5.0;
    glow.lineJoinStyle = kCGLineJoinRound;
    [glow stroke];

    UIBezierPath *body = [UIBezierPath bezierPath];
    [body moveToPoint:CGPointMake(14.8, 6.8)];
    [body addQuadCurveToPoint:CGPointMake(25.2, 9.5) controlPoint:CGPointMake(21.1, 6.1)];
    [body addLineToPoint:CGPointMake(33.5, 13.4)];
    [body addQuadCurveToPoint:CGPointMake(34.0, 22.3) controlPoint:CGPointMake(34.4, 16.0)];
    [body addQuadCurveToPoint:CGPointMake(30.8, 25.8) controlPoint:CGPointMake(34.0, 24.9)];
    [body addLineToPoint:CGPointMake(39.0, 31.6)];
    [body addQuadCurveToPoint:CGPointMake(38.8, 35.4) controlPoint:CGPointMake(40.4, 33.7)];
    [body addLineToPoint:CGPointMake(22.3, 46.2)];
    [body addQuadCurveToPoint:CGPointMake(18.0, 45.1) controlPoint:CGPointMake(19.6, 47.0)];
    [body addLineToPoint:CGPointMake(12.0, 40.0)];
    [body addQuadCurveToPoint:CGPointMake(11.3, 35.8) controlPoint:CGPointMake(10.5, 38.4)];
    [body addLineToPoint:CGPointMake(17.8, 28.0)];
    [body addLineToPoint:CGPointMake(14.0, 24.4)];
    [body addQuadCurveToPoint:CGPointMake(13.2, 20.0) controlPoint:CGPointMake(12.4, 22.7)];
    [body addLineToPoint:CGPointMake(13.0, 11.5)];
    [body addQuadCurveToPoint:CGPointMake(14.8, 6.8) controlPoint:CGPointMake(13.0, 8.8)];
    [body closePath];
    [mainFill setFill];
    [body fill];
    [outline setStroke];
    body.lineWidth = 1.8;
    body.lineJoinStyle = kCGLineJoinRound;
    [body stroke];

    UIBezierPath *side = [UIBezierPath bezierPath];
    [side moveToPoint:CGPointMake(24.9, 10.0)];
    [side addLineToPoint:CGPointMake(33.3, 13.6)];
    [side addQuadCurveToPoint:CGPointMake(33.8, 22.0) controlPoint:CGPointMake(34.1, 15.9)];
    [side addQuadCurveToPoint:CGPointMake(30.9, 25.3) controlPoint:CGPointMake(33.8, 24.5)];
    [side addLineToPoint:CGPointMake(38.7, 31.3)];
    [side addQuadCurveToPoint:CGPointMake(38.3, 34.9) controlPoint:CGPointMake(39.9, 33.6)];
    [side addLineToPoint:CGPointMake(22.1, 46.0)];
    [side addLineToPoint:CGPointMake(20.0, 38.5)];
    [side addLineToPoint:CGPointMake(25.0, 29.1)];
    [side addLineToPoint:CGPointMake(22.5, 24.9)];
    [side addLineToPoint:CGPointMake(24.4, 19.0)];
    [side closePath];
    [sideShade setFill];
    [side fill];

    UIBezierPath *inner = [UIBezierPath bezierPath];
    [inner moveToPoint:CGPointMake(17.8, 10.0)];
    [inner addQuadCurveToPoint:CGPointMake(24.3, 10.8) controlPoint:CGPointMake(21.2, 9.0)];
    [inner addLineToPoint:CGPointMake(28.7, 12.7)];
    [inner addQuadCurveToPoint:CGPointMake(29.0, 18.6) controlPoint:CGPointMake(29.4, 14.3)];
    [inner addQuadCurveToPoint:CGPointMake(27.1, 20.9) controlPoint:CGPointMake(29.0, 20.1)];
    [inner addLineToPoint:CGPointMake(31.2, 24.4)];
    [inner addLineToPoint:CGPointMake(20.7, 37.5)];
    [inner addLineToPoint:CGPointMake(19.2, 31.5)];
    [inner addLineToPoint:CGPointMake(22.4, 26.8)];
    [inner addLineToPoint:CGPointMake(19.0, 23.6)];
    [inner addQuadCurveToPoint:CGPointMake(17.5, 20.3) controlPoint:CGPointMake(17.9, 22.6)];
    [inner addLineToPoint:CGPointMake(17.4, 12.6)];
    [inner closePath];
    [mainFill2 setFill];
    [inner fill];

    UIBezierPath *shine = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(17.0, 8.8, 12.5, 3.8) cornerRadius:2.0];
    [[UIColor colorWithWhite:1.0 alpha:0.42] setFill];
    [shine fill];

    UIBezierPath *shine2 = [UIBezierPath bezierPath];
    [shine2 moveToPoint:CGPointMake(24.6, 21.9)];
    [shine2 addQuadCurveToPoint:CGPointMake(28.9, 24.2) controlPoint:CGPointMake(27.2, 22.2)];
    shine2.lineWidth = 2.0;
    shine2.lineCapStyle = kCGLineCapRound;
    [[UIColor colorWithWhite:1.0 alpha:0.30] setStroke];
    [shine2 stroke];

    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

UIImage *OngnongCounterIconImage(NSInteger index) {
    if (index == Z700020a485) return Z0da1985399(qsec_s_0021());
    if (index == Z124338f2d8) return Z0da1985399(qsec_s_0023());
    if (index == Z94881eb8d3) return Z0da1985399(qsec_s_0025());
    if (index == Z646dcbe562) return Z0da1985399(qsec_s_0027());
    if (index == Z2f0c1a9d77) return Z67b9f0c2a1();
    if (index == Z87f6d0c11d) return Zc83f0d7b42();
    if (index == Z5d92a7e4c1) return Z71a4c9e2d6();
    return nil;
}


@interface Z68534fe442 : UIWindow
@end

@implementation Z68534fe442
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    if (hit == self || hit == self.rootViewController.view) return nil;
    return hit;
}
@end

@interface Zcb66126fa3 : UIButton
@property (nonatomic, strong) UIColor *r8m1v5;
@property (nonatomic, strong) UILabel *q3p7d2;
@property (nonatomic, strong) UILabel *x9c4n6;
@property (nonatomic, assign) BOOL h5m2k8;
@property (nonatomic, strong) UIColor *v1q7p3;
- (instancetype)initWithV5m8p2:(NSString *)title icon:(NSString *)icon color:(UIColor *)color;
@end

@implementation Zcb66126fa3
- (instancetype)initWithV5m8p2:(NSString *)title icon:(NSString *)icon color:(UIColor *)color {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.r8m1v5 = color;
    self.backgroundColor = ZThemeButtonOff();
    ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
    self.clipsToBounds = YES;

    _q3p7d2 = Label(icon, zb1d8336499(28.0, 15.0), UIFontWeightHeavy, color, NSTextAlignmentCenter);
    _q3p7d2.layer.shadowColor = color.CGColor;
    _q3p7d2.layer.shadowOpacity = 0.0;
    _q3p7d2.layer.shadowRadius = 0.0;
    _q3p7d2.layer.shadowOffset = CGSizeZero;
    [self addSubview:_q3p7d2];

    _x9c4n6 = Label(title, zb1d8336499(18.0, 11.5), UIFontWeightHeavy, [UIColor whiteColor], NSTextAlignmentCenter);
    _x9c4n6.numberOfLines = 1;
    _x9c4n6.lineBreakMode = NSLineBreakByClipping;
    _x9c4n6.minimumScaleFactor = 0.42;
    _x9c4n6.layer.shadowColor = [UIColor blackColor].CGColor;
    _x9c4n6.layer.shadowOpacity = 0.0;
    _x9c4n6.layer.shadowRadius = 0.0;
    _x9c4n6.layer.shadowOffset = CGSizeMake(0, 1);
    [self addSubview:_x9c4n6];
    [self addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    return self;
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat s = z067adc83c5();
    CGFloat h = self.bounds.size.height;
    CGFloat pad = 10.0 * s;
    BOOL hasIcon = (_q3p7d2.text.length > 0);
    if (hasIcon) {
        CGFloat iconW = 44.0 * s;
        CGFloat textX = pad + iconW + 8.0 * s;
        _q3p7d2.hidden = NO;
        _q3p7d2.frame = CGRectMake(pad, 0, iconW, h);
        _x9c4n6.textAlignment = NSTextAlignmentLeft;
        _x9c4n6.frame = CGRectMake(textX, 0, self.bounds.size.width - textX - 8.0 * s, h);
    } else {
        _q3p7d2.hidden = YES;
        _q3p7d2.frame = CGRectZero;
        _x9c4n6.textAlignment = NSTextAlignmentCenter;
        _x9c4n6.frame = CGRectMake(8.0 * s, 0, self.bounds.size.width - 16.0 * s, h);
    }
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    self.transform = highlighted ? CGAffineTransformMakeScale(0.97, 0.97) : CGAffineTransformIdentity;
    UIColor *activeColor = ZThemeActiveGreen();
    UIColor *normalBackground = self.v1q7p3 ? self.v1q7p3 : (self.h5m2k8 ? activeColor : ZThemeButtonOff());
    UIColor *highlightBackground = self.v1q7p3 ? [self.v1q7p3 colorWithAlphaComponent:0.96] : (self.h5m2k8 ? [activeColor colorWithAlphaComponent:0.86] : [ZThemeBorder() colorWithAlphaComponent:0.18]);
    self.backgroundColor = highlighted ? highlightBackground : normalBackground;
}
@end

@interface Zf721fd429b : UIButton
@property (nonatomic, strong) UIColor *r8m1v5;
- (instancetype)initWithV5m8p2:(NSString *)title color:(UIColor *)color;
@end

@implementation Zf721fd429b
- (instancetype)initWithV5m8p2:(NSString *)title color:(UIColor *)color {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.r8m1v5 = color;
    [self setTitle:title forState:UIControlStateNormal];
    [self setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    self.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(24.0, 15.0) weight:UIFontWeightHeavy];
    self.titleLabel.adjustsFontSizeToFitWidth = YES;
    self.titleLabel.minimumScaleFactor = 0.18;
    self.titleLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    self.titleLabel.lineBreakMode = NSLineBreakByClipping;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.contentEdgeInsets = UIEdgeInsetsMake(0.0, 1.0, 0.0, 1.0);
    self.backgroundColor = ZThemeButtonOff();
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    ApplyNeon(self, ZThemeBorder(), 10.0, 1.2);
    [self addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    return self;
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)layoutSubviews {
    [super layoutSubviews];
    Z611a3d09ce(self, zb1d8336499(22.0, 13.0), 6.0);
}
@end

@interface Z73b2f81c4a : UIControl
@property (nonatomic, strong) UIImageView *c6d9x4;
@property (nonatomic, strong) UILabel *t2m8r5;
@end

@implementation Z73b2f81c4a
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = ZThemeButtonOff();
    ApplyNeon(self, ZThemeBorder(), 10.0, 1.2);
    _c6d9x4 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _c6d9x4.contentMode = UIViewContentModeScaleAspectFit;
    _c6d9x4.userInteractionEnabled = NO;
    [self addSubview:_c6d9x4];
    _t2m8r5 = Label(qsec_s_0029(), 16.0, UIFontWeightBlack, RGB(80, 255, 120), NSTextAlignmentCenter);
    _t2m8r5.backgroundColor = [UIColor clearColor];
    _t2m8r5.layer.cornerRadius = 8.0;
    _t2m8r5.clipsToBounds = YES;
    _t2m8r5.adjustsFontSizeToFitWidth = YES;
    _t2m8r5.minimumScaleFactor = 0.25;
    _t2m8r5.numberOfLines = 1;
    _t2m8r5.lineBreakMode = NSLineBreakByClipping;
    _t2m8r5.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    _t2m8r5.allowsDefaultTighteningForTruncation = YES;
    _t2m8r5.userInteractionEnabled = NO;
    [self addSubview:_t2m8r5];
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    CGFloat countH = MIN(18.0, MAX(15.0, h * 0.34));
    CGFloat iconH = MAX(18.0, h - countH - 7.0);
    _c6d9x4.frame = CGRectMake(5.0, 2.0, MAX(0.0, w - 10.0), iconH);
    _t2m8r5.frame = CGRectMake(2.0, h - countH - 2.0, MAX(0.0, w - 4.0), countH);
    _t2m8r5.layer.cornerRadius = countH * 0.44;
    _t2m8r5.font = [UIFont monospacedDigitSystemFontOfSize:MIN(16.0, countH - 2.0) weight:UIFontWeightBlack];
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    self.transform = highlighted
        ? CGAffineTransformMakeScale(0.97, 0.97)
        : CGAffineTransformIdentity;
}
@end

@interface Z8x4c2v7 : UIView
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UISlider *rSlider;
@property (nonatomic, strong) UISlider *gSlider;
@property (nonatomic, strong) UISlider *bSlider;
@property (nonatomic, strong) UISlider *aSlider;
@property (nonatomic, strong) UIView *preview;
@property (nonatomic, strong) UIButton *resetButton;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, assign) CGPoint x3q8c6;
- (void)f5q1m9;
@end

@implementation Z8x4c2v7
- (UISlider *)u8m2q5:(CGFloat)y label:(NSString *)label value:(CGFloat)value {
    UILabel *l = Label(label, 12.0, UIFontWeightHeavy, ZThemeWhite(), NSTextAlignmentLeft);
    l.frame = CGRectMake(12.0, y, 28.0, 24.0);
    [self addSubview:l];
    UISlider *sl = [[UISlider alloc] initWithFrame:CGRectMake(42.0, y, 154.0, 24.0)];
    sl.minimumValue = 0.0;
    sl.maximumValue = 1.0;
    sl.value = value;
    sl.minimumTrackTintColor = ZThemeBorder();
    sl.maximumTrackTintColor = [UIColor colorWithWhite:1.0 alpha:0.20];
    sl.thumbTintColor = ZThemeWhite();
    [sl addTarget:self action:@selector(c4p9v1:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:sl];
    return sl;
}
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    ZThemeLoad();
    self.backgroundColor = ZThemePanelDarker();
    ApplyNeon(self, ZThemeBorder(), 15.0, 1.2);
    self.clipsToBounds = YES;

    _titleLabel = Label(ZuiMenuColorText(), 15.0, UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentCenter);
    [self addSubview:_titleLabel];

    _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_closeButton setTitle:OX_NS("✕") forState:UIControlStateNormal];
    [_closeButton setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightHeavy];
    _closeButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_closeButton, ZThemeBorder(), 7.0, 1.0);
    [_closeButton addTarget:self action:@selector(h2n8k4) forControlEvents:UIControlEventTouchUpInside];
    [_closeButton addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_closeButton];

    _rSlider = [self u8m2q5:38.0 label:OX_NS("R") value:g_themeR];
    _gSlider = [self u8m2q5:66.0 label:OX_NS("G") value:g_themeG];
    _bSlider = [self u8m2q5:94.0 label:OX_NS("B") value:g_themeB];
    _aSlider = [self u8m2q5:122.0 label:OX_NS("A") value:g_themeA];

    _preview = [[UIView alloc] initWithFrame:CGRectZero];
    _preview.backgroundColor = ZThemePanelColor();
    ApplyNeon(_preview, ZThemeBorder(), 9.0, 1.0);
    [self addSubview:_preview];

    _resetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_resetButton setTitle:OX_NS("Reset") forState:UIControlStateNormal];
    [_resetButton setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _resetButton.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightHeavy];
    _resetButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_resetButton, ZThemeBorder(), 9.0, 1.0);
    [_resetButton addTarget:self action:@selector(r7d3x6) forControlEvents:UIControlEventTouchUpInside];
    [_resetButton addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_resetButton];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    [self addGestureRecognizer:pan];
    return self;
}
- (void)z51bfdd51e4:(UIButton *)sender { Z0418c1e0ae(); }
- (void)layoutSubviews {
    [super layoutSubviews];
    _titleLabel.frame = CGRectMake(12.0, 7.0, self.bounds.size.width - 52.0, 24.0);
    _closeButton.frame = CGRectMake(self.bounds.size.width - 34.0, 7.0, 24.0, 24.0);
    _preview.frame = CGRectMake(12.0, self.bounds.size.height - 40.0, 62.0, 28.0);
    _resetButton.frame = CGRectMake(84.0, self.bounds.size.height - 40.0, self.bounds.size.width - 96.0, 28.0);
}
- (void)c4p9v1:(UISlider *)sender {
    g_themeR = ZClamp01(_rSlider.value);
    g_themeG = ZClamp01(_gSlider.value);
    g_themeB = ZClamp01(_bSlider.value);
    g_themeA = MAX(0.30, ZClamp01(_aSlider.value));
    ZThemeSave();
    [self f5q1m9];
    [[NSNotificationCenter defaultCenter] postNotificationName:ZThemeNotify() object:self];
}
- (void)r7d3x6 {
    ZThemeDefaults();
    _rSlider.value = g_themeR;
    _gSlider.value = g_themeG;
    _bSlider.value = g_themeB;
    _aSlider.value = g_themeA;
    ZThemeSave();
    [self f5q1m9];
    [[NSNotificationCenter defaultCenter] postNotificationName:ZThemeNotify() object:self];
    Z0418c1e0ae();
}
- (void)h2n8k4 {
    self.hidden = YES;
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:ZThemeVisibleKey()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:ZThemeNotify() object:self];
    Z0418c1e0ae();
}
- (void)f5q1m9 {
    self.backgroundColor = ZThemePanelDarker();
    ApplyNeon(self, ZThemeBorder(), 15.0, 1.2);
    _preview.backgroundColor = ZThemePanelColor();
    ApplyNeon(_preview, ZThemeBorder(), 9.0, 1.0);
    _resetButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_resetButton, ZThemeBorder(), 9.0, 1.0);
    _closeButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_closeButton, ZThemeBorder(), 7.0, 1.0);
    _titleLabel.text = ZuiMenuColorText();
    _titleLabel.textColor = ZThemeWhite();
    for (UISlider *sl in @[_rSlider, _gSlider, _bSlider, _aSlider]) {
        sl.minimumTrackTintColor = ZThemeBorder();
        sl.maximumTrackTintColor = [UIColor colorWithWhite:1.0 alpha:0.20];
        sl.thumbTintColor = ZThemeWhite();
    }
}
- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *sv = self.superview;
    if (!sv) return;
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint t = [pan translationInView:sv];
        CGPoint c = CGPointMake(_x3q8c6.x + t.x, _x3q8c6.y + t.y);
        CGFloat hw = self.bounds.size.width * 0.5;
        CGFloat hh = self.bounds.size.height * 0.5;
        c.x = MAX(hw, MIN(sv.bounds.size.width - hw, c.x));
        c.y = MAX(hh + 20.0, MIN(sv.bounds.size.height - hh, c.y));
        self.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.x forKey:ZThemePosXKey()];
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.y forKey:ZThemePosYKey()];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
    }
}
@end

@interface Z6dcb301a04 : UIView
@property (nonatomic, strong) UIImageView *c6d9x4;
@property (nonatomic, strong) UILabel *n7q1v6;
@property (nonatomic, strong) UILabel *value;
@property (nonatomic, assign) NSInteger p4x9c3;
- (instancetype)initWithC7q3x9:(NSString *)imageName fallback:(NSString *)fallback color:(UIColor *)color index:(NSInteger)index;
@end

@implementation Z6dcb301a04
- (instancetype)initWithC7q3x9:(NSString *)imageName fallback:(NSString *)fallback color:(UIColor *)color index:(NSInteger)index {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.p4x9c3 = index;
    self.backgroundColor = [UIColor clearColor];
    ApplyNeon(self, ZThemeBorder(), 10.0, 0.9);
    self.layer.shadowOpacity = 0.0;

    _c6d9x4 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _c6d9x4.contentMode = UIViewContentModeScaleAspectFit;
    _c6d9x4.image = (index == Z2f0c1a9d77) ? Z67b9f0c2a1() : ((index == Z87f6d0c11d) ? Zc83f0d7b42() : ((index == Z5d92a7e4c1) ? Z71a4c9e2d6() : Z0da1985399(imageName)));
    _c6d9x4.layer.shadowColor = color.CGColor;
    _c6d9x4.layer.shadowOpacity = 0.0;
    _c6d9x4.layer.shadowRadius = 0.0;
    _c6d9x4.layer.shadowOffset = CGSizeZero;
    [self addSubview:_c6d9x4];

    _n7q1v6 = Label(fallback, 18.0, UIFontWeightHeavy, [UIColor whiteColor], NSTextAlignmentCenter);
    _n7q1v6.hidden = (_c6d9x4.image != nil);
    [self addSubview:_n7q1v6];

    _value = Label([NSString string], 1.0, UIFontWeightRegular, [UIColor clearColor], NSTextAlignmentCenter);
    _value.hidden = YES;
    [self addSubview:_value];
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat h = self.bounds.size.height;
    CGFloat w = self.bounds.size.width;
    CGFloat iconH = MIN(h - 4.0, 26.0);
    CGFloat iconW = MIN(w - 6.0, 28.0);
    if (self.p4x9c3 == Z87f6d0c11d) {
        iconH = MIN(h - 1.0, 29.0);
        iconW = MIN(w - 2.0, 32.0);
    } else if (self.p4x9c3 == Z5d92a7e4c1) {
        iconH = MIN(h - 1.0, 30.0);
        iconW = MIN(w - 1.0, 31.0);
    }
    CGFloat iconX = (w - iconW) / 2.0;
    CGFloat iconY = (h - iconH) / 2.0;

    _c6d9x4.frame = CGRectMake(iconX, iconY, iconW, iconH);
    _n7q1v6.frame = CGRectMake(0, iconY, w, iconH);
    _n7q1v6.font = [UIFont systemFontOfSize:18.0 weight:UIFontWeightHeavy];

    _value.hidden = YES;
    _value.frame = CGRectZero;
}
@end

@interface Zc1dba0f365 : UIView
@property (nonatomic, strong) UILabel *y8m2d7;
@property (nonatomic, strong) UIView *k5q1n9;
@property (nonatomic, strong) NSArray<UILabel *> *a3v6p8;
@property (nonatomic, assign) NSInteger p4x9c3;
- (instancetype)initWithD2n6k4:(UIColor *)color index:(NSInteger)index;
@end

@implementation Zc1dba0f365
- (instancetype)initWithD2n6k4:(UIColor *)color index:(NSInteger)index {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.p4x9c3 = index;
    self.clipsToBounds = YES;

    _y8m2d7 = Label(qsec_s_0029(), 13.2, UIFontWeightBlack, ZThemeGapYellow(), NSTextAlignmentCenter);
    _y8m2d7.font = [UIFont monospacedDigitSystemFontOfSize:13.2 weight:UIFontWeightBlack];
    _y8m2d7.adjustsFontSizeToFitWidth = YES;
    _y8m2d7.minimumScaleFactor = 0.30;
    _y8m2d7.clipsToBounds = YES;
    [self addSubview:_y8m2d7];

    _k5q1n9 = [[UIView alloc] initWithFrame:CGRectZero];
    _k5q1n9.backgroundColor = [UIColor clearColor];
    _k5q1n9.clipsToBounds = YES;
    _k5q1n9.userInteractionEnabled = NO;
    [self addSubview:_k5q1n9];

    NSMutableArray<UILabel *> *rows = [NSMutableArray array];
    for (NSInteger i = 0; i < ZHistoryVisibleRows; i++) {
        UILabel *row = Label([NSString string], 11.0, UIFontWeightHeavy, ZThemeHisWhite(), NSTextAlignmentCenter);
        row.font = [UIFont monospacedDigitSystemFontOfSize:11.0 weight:UIFontWeightHeavy];
        row.adjustsFontSizeToFitWidth = YES;
        row.minimumScaleFactor = 0.30;
        row.clipsToBounds = YES;
        row.layer.shadowColor = [UIColor clearColor].CGColor;
        row.layer.shadowOpacity = 0.0;
        row.layer.shadowRadius = 0.0;
        row.layer.shadowOffset = CGSizeZero;
        row.hidden = YES;
        [_k5q1n9 addSubview:row];
        [rows addObject:row];
    }
    _a3v6p8 = rows;

    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat gapH = MIN(25.0, MAX(21.0, self.bounds.size.width * 0.23));
    CGFloat rowH = 15.5;
    _y8m2d7.frame = CGRectMake(2.0, 0.0, MAX(0.0, self.bounds.size.width - 4.0), gapH);
    Z3218ec4b5a(_y8m2d7, _y8m2d7.text, 14.0, 8.0, UIFontWeightBlack);
    CGFloat historyY = gapH + 1.0;
    CGFloat historyH = MAX(0.0, self.bounds.size.height - historyY);
    _k5q1n9.frame = CGRectMake(0.0, historyY, self.bounds.size.width, historyH);
    CGFloat y = 0.0;
    for (UILabel *row in _a3v6p8) {
        row.frame = CGRectMake(0.0, y, self.bounds.size.width, rowH);
        Z3218ec4b5a(row, row.text, 11.0, 6.0, UIFontWeightHeavy);
        y += rowH;
    }
}
@end

@interface Za540ef69c7 : UIView
@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UIButton *r6q2p8;
@property (nonatomic, strong) UIButton *k3v9d4;
@property (nonatomic, strong) NSArray<Zcb66126fa3 *> *a7m1c5;
@property (nonatomic, strong) UIButton *x8p4n2;
@property (nonatomic, assign) CGPoint x3q8c6;
- (void)e4p7n1:(NSString *)code;
@end

@interface Z4c5163ab2a : UIView
@property (nonatomic, assign) CGPoint x3q8c6;
@property (nonatomic, strong) Zf721fd429b *d5q9v3;
@property (nonatomic, strong) Zf721fd429b *t2m7k6;
@property (nonatomic, strong) Zf721fd429b *c8x1p4;
@property (nonatomic, strong) Z73b2f81c4a *r3n9d5;
@property (nonatomic, strong) Zf721fd429b *v6q2m8;
@property (nonatomic, strong) Zf721fd429b *k4p7c1;
@property (nonatomic, strong) UIButton *q4n8p2;
@property (nonatomic, assign) BOOL q6m2v8;
@property (nonatomic, assign) BOOL a1v8m3;
@property (nonatomic, strong) UIView *u2p7k4;
@property (nonatomic, strong) UIButton *m6q1d8;
@property (nonatomic, strong) UIButton *h3c9v5;
@property (nonatomic, strong) UIButton *g8n2x6;
@property (nonatomic, strong) UIView *z7h4p1;
@property (nonatomic, strong) UIImageView *x2c8m5;
@property (nonatomic, strong) UILabel *p9v3k7;
@property (nonatomic, strong) UIButton *r4n6d2;
- (void)setQ6m2v8:(BOOL)collapsed;
- (void)setA1v8m3:(BOOL)enabled;
@end

@interface Z1c94f803b6 : UIView <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIButton *k3v9d4;
@property (nonatomic, strong) UIButton *eyeButton;
@property (nonatomic, assign) NSInteger r2c7m4;
@property (nonatomic, strong) NSArray<Z6dcb301a04 *> *t6m1v8;
@property (nonatomic, strong) UIView *d9q3x5;
@property (nonatomic, strong) NSArray<Zc1dba0f365 *> *p7k4n2;
@property (nonatomic, assign) CGPoint x3q8c6;
@property (nonatomic, assign) CGRect h9m2d5;
@property (nonatomic, assign) NSInteger v4p7k1;
@property (nonatomic, assign) BOOL c8n3q6;
@property (nonatomic, strong) UILabel *y1m5x9;
- (void)n4q9c1;
@end

@interface Zd4f227a905 : UIView <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *h8m3x6;
@property (nonatomic, strong) UISwitch *d2q9v5;
@property (nonatomic, strong) UIView *p7n1c4;
@property (nonatomic, strong) NSArray<UIButton *> *y5m8k2;
@property (nonatomic, strong) UIView *r9q3d6;
@property (nonatomic, strong) UIImageView *x1v7p4;
@property (nonatomic, strong) UILabel *c6m2n8;
@property (nonatomic, assign) NSInteger t4q9k5;
@property (nonatomic, assign) NSInteger a8p3v1;
@property (nonatomic, assign) NSInteger d7m2x6;
@property (nonatomic, assign) BOOL h5q1c9;
@property (nonatomic, assign) BOOL v3n8p4;
@property (nonatomic, assign) BOOL k9m2d7;
@property (nonatomic, assign) BOOL q6r1m8;
@property (nonatomic, assign) BOOL z7c4p1;
@property (nonatomic, assign) NSInteger z2m6q8;
@property (nonatomic, assign) NSInteger z8n4c2;
@property (nonatomic, assign) NSInteger p6f3a9;
@property (nonatomic, assign) CGPoint x3q8c6;
- (void)k9m2c8:(BOOL)animated;
- (void)r8p3d7;
- (void)a9m3c6;
- (NSInteger)zAutoStopMasterCount;
- (void)zAutoStopSyncFromMaster;
- (NSInteger)zAutoStopCycleProgress;
- (void)zAutoStopSetBaseToCurrent;
@end

@implementation Zd4f227a905

- (NSArray<NSNumber *> *)t8m2d5 {
    return Ongnong::Z76e4c1b909();
}

- (int)q4p9x1:(NSInteger)slot {
    return Ongnong::Z76d01f2a88(slot);
}

- (NSInteger)zAutoStopMasterCount {
    int idx = [self q4p9x1:self.t4q9k5];
    if (idx < 0 || idx >= Za94c0d401a) return 0;
    return zce119e8048.zc9f4191bf8[idx];
}

- (void)zAutoStopSyncFromMaster {
    self.a8p3v1 = [self zAutoStopMasterCount];
}

- (NSInteger)zAutoStopCycleProgress {
    NSInteger current = [self zAutoStopMasterCount];
    if (current < self.p6f3a9) {
        self.z2m6q8 = current;
        self.z8n4c2 = 0;
    }
    self.p6f3a9 = current;
    return self.z8n4c2 + MAX((NSInteger)0, current - self.z2m6q8);
}

- (void)zAutoStopSetBaseToCurrent {
    [self zAutoStopSyncFromMaster];
    self.z2m6q8 = self.a8p3v1;
    self.p6f3a9 = self.a8p3v1;
    self.z8n4c2 = 0;
    [[NSUserDefaults standardUserDefaults] setInteger:self.z2m6q8 forKey:OX_NS("ot_base")];
}

- (UIImage *)v7n3k6:(int)idx {
    if (idx == Z2f0c1a9d77) return Z67b9f0c2a1();
    if (idx == Z87f6d0c11d) return Zc83f0d7b42();
    if (idx == Z5d92a7e4c1) return Z71a4c9e2d6();
    if (idx == Z700020a485) return Z0da1985399(qsec_s_0021());
    if (idx == Z124338f2d8) return Z0da1985399(qsec_s_0023());
    if (idx == Z94881eb8d3) return Z0da1985399(qsec_s_0025());
    if (idx == Z646dcbe562) return Z0da1985399(qsec_s_0027());
    return nil;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, 166.0, 88.0)];
    if (!self) return nil;
    self.backgroundColor = ZThemePanelColor();
    ApplyNeon(self, ZThemeBorder(), 15.0, 1.1);
    self.clipsToBounds = NO;
    self.userInteractionEnabled = YES;

    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    _t4q9k5 = [ud integerForKey:OX_NS("ot_slot")];
    _d7m2x6 = [ud integerForKey:OX_NS("ot_target")];
    _a8p3v1 = 0;
    _h5q1c9 = [ud boolForKey:OX_NS("ot_running")];
    _z2m6q8 = [ud objectForKey:OX_NS("ot_base")] ? [ud integerForKey:OX_NS("ot_base")] : 0;
    if (_t4q9k5 < 0 || _t4q9k5 >= (NSInteger)[self t8m2d5].count) _t4q9k5 = 0;
    [self zAutoStopSyncFromMaster];
    if (!_h5q1c9 || _z2m6q8 > _a8p3v1) _z2m6q8 = _a8p3v1;
    _p6f3a9 = _a8p3v1;
    _z8n4c2 = 0;

    _titleLabel = Label(ZuiAutoTargetText(), 12.0, UIFontWeightHeavy, ZThemeWhite(), NSTextAlignmentCenter);
    [self addSubview:_titleLabel];

    _h8m3x6 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_h8m3x6 setTitle:(_d7m2x6 > 0 ? [NSString stringWithFormat:@"%ld", (long)_d7m2x6] : ZuiSetText()) forState:UIControlStateNormal];
    [_h8m3x6 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _h8m3x6.titleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightHeavy];
    _h8m3x6.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_h8m3x6, ZThemeBorder(), 8.0, 1.0);
    [_h8m3x6 addTarget:self action:@selector(y2v9m5) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_h8m3x6];

    _d2q9v5 = [[UISwitch alloc] initWithFrame:CGRectZero];
    _d2q9v5.transform = CGAffineTransformMakeScale(0.72, 0.72);
    _d2q9v5.onTintColor = ZThemeOnGreen();
    [_d2q9v5 setOn:_h5q1c9 animated:NO];
    [_d2q9v5 addTarget:self action:@selector(u6c1x4:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_d2q9v5];

    _p7n1c4 = [[UIView alloc] initWithFrame:CGRectZero];
    _p7n1c4.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_p7n1c4, ZThemeBorder(), 10.0, 0.8);
    [self addSubview:_p7n1c4];

    NSMutableArray *a7m1c5 = [NSMutableArray array];
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    for (NSInteger i = 0; i < (NSInteger)idxs.count; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        UIImage *img = [self v7n3k6:idxs[i].intValue];
        if (img) [b setImage:img forState:UIControlStateNormal];
        b.imageView.contentMode = UIViewContentModeScaleAspectFit;
        b.layer.cornerRadius = 10.0;
        [b addTarget:self action:@selector(b4q6n1:) forControlEvents:UIControlEventTouchUpInside];
        [_p7n1c4 addSubview:b];
        [a7m1c5 addObject:b];
    }
    _y5m8k2 = a7m1c5;

    _r9q3d6 = [[UIView alloc] initWithFrame:CGRectZero];
    _r9q3d6.backgroundColor = ZThemePanelDarker();
    ApplyNeon(_r9q3d6, ZThemeBorder(), 15.0, 1.1);
    _r9q3d6.layer.masksToBounds = NO;
    _r9q3d6.hidden = YES;
    [self addSubview:_r9q3d6];

    _x1v7p4 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _x1v7p4.contentMode = UIViewContentModeScaleAspectFit;
    [_r9q3d6 addSubview:_x1v7p4];

    _c6m2n8 = Label(@"0/0", 12.0, UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentCenter);
    _c6m2n8.font = [UIFont fontWithName:@"Menlo-Bold" size:13.0] ?: [UIFont boldSystemFontOfSize:13.0];
    _c6m2n8.adjustsFontSizeToFitWidth = YES;
    _c6m2n8.minimumScaleFactor = 0.62;
    [_r9q3d6 addSubview:_c6m2n8];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(d3x7v5)];
    [_r9q3d6 addGestureRecognizer:tap];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    pan.delegate = self;
    [self addGestureRecognizer:pan];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(m7d4k9:) name:Z1e3f87b2aa object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(p3n8q2:) name:Z9a421e103d object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(z4fb91b7407:) name:Z02a7e13d91 object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(z4fb91b7407:) name:Z6a3e9c1d74 object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(c7v2m9:) name:OX_NS("ongnong_slot_spin_complete") object:nil];

    _v3n8p4 = !_h5q1c9;
    _k9m2d7 = NO;
    _q6r1m8 = NO;
    _z7c4p1 = NO;
    [self r8p3d7];
    [self a9m3c6];
    [self k9m2c8:NO];
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)z1a3b62f4d9 {
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    if ((NSInteger)_y5m8k2.count == (NSInteger)idxs.count) return;

    for (UIButton *old in _y5m8k2) [old removeFromSuperview];

    NSMutableArray<UIButton *> *a7m1c5 = [NSMutableArray arrayWithCapacity:idxs.count];
    for (NSInteger i = 0; i < (NSInteger)idxs.count; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        UIImage *img = [self v7n3k6:idxs[i].intValue];
        if (img) [b setImage:img forState:UIControlStateNormal];
        b.imageView.contentMode = UIViewContentModeScaleAspectFit;
        b.layer.cornerRadius = 10.0;
        [b addTarget:self action:@selector(b4q6n1:) forControlEvents:UIControlEventTouchUpInside];
        [_p7n1c4 addSubview:b];
        [a7m1c5 addObject:b];
    }
    _y5m8k2 = a7m1c5;

    if (_t4q9k5 < 0 || _t4q9k5 >= (NSInteger)idxs.count) {
        _t4q9k5 = 0;
        [[NSUserDefaults standardUserDefaults] setInteger:_t4q9k5 forKey:OX_NS("ot_slot")];
    }

    [self r8p3d7];
    [self setNeedsLayout];
}

- (CGSize)c2m8r4 { return CGSizeMake(166.0, 88.0); }
- (CGSize)h6q1p9 { return CGSizeMake(110.0, 30.0); }

- (void)layoutSubviews {
    [super layoutSubviews];
    [self z1a3b62f4d9];
    if (self.h5q1c9 && !self.v3n8p4) {
        _r9q3d6.frame = self.bounds;
        _r9q3d6.layer.cornerRadius = self.bounds.size.height * 0.5;
        _r9q3d6.layer.borderWidth = 1.2;
        int compactIdx = [self q4p9x1:self.t4q9k5];
        _x1v7p4.frame = (compactIdx == Z87f6d0c11d || compactIdx == Z5d92a7e4c1) ? CGRectMake(5.0, 2.5, 25.0, 25.0) : CGRectMake(7.0, 4.0, 22.0, 22.0);
        _c6m2n8.frame = CGRectMake(31.0, 0.0, self.bounds.size.width - 35.0, self.bounds.size.height);
        return;
    }
    _titleLabel.text = ZuiAutoTargetText();
    _titleLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightHeavy];
    _titleLabel.frame = CGRectMake(6.0, 5.0, 76.0, 20.0);
    _h8m3x6.frame = CGRectMake(84.0, 6.0, 34.0, 20.0);
    _d2q9v5.frame = CGRectMake(119.0, 1.0, 42.0, 30.0);
    _p7n1c4.frame = CGRectMake(6.0, 31.0, self.bounds.size.width - 12.0, 51.0);
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    CGFloat count = MAX((CGFloat)1.0, (CGFloat)_y5m8k2.count);
    CGFloat w = _p7n1c4.bounds.size.width / count;
    for (NSInteger i = 0; i < (NSInteger)_y5m8k2.count; i++) {
        UIButton *b = _y5m8k2[i];
        b.frame = CGRectMake(i * w + 1.0, 4.0, w - 2.0, 43.0);
        int idx = (i < (NSInteger)idxs.count) ? idxs[i].intValue : -1;
        b.imageEdgeInsets = (idx == Z87f6d0c11d || idx == Z5d92a7e4c1) ? UIEdgeInsetsMake(-1.0, -1.0, -1.0, -1.0) : UIEdgeInsetsMake(0.5, 0.5, 0.5, 0.5);
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([touch.view isKindOfClass:[UIControl class]]) return NO;
    return YES;
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *sv = self.superview;
    if (!sv) return;
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint t = [pan translationInView:sv];
        CGPoint c = CGPointMake(_x3q8c6.x + t.x, _x3q8c6.y + t.y);
        CGFloat hw = self.bounds.size.width / 2.0;
        CGFloat hh = self.bounds.size.height / 2.0;
        c.x = MAX(hw, MIN(sv.bounds.size.width - hw, c.x));
        c.y = MAX(hh, MIN(sv.bounds.size.height - hh, c.y));
        self.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.x forKey:OX_NS("ot_x")];
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.y forKey:OX_NS("ot_y")];
        }
    }
}

- (void)d3x7v5 {
    self.v3n8p4 = YES;
    [self k9m2c8:YES];
    Z0418c1e0ae();
}

- (void)k9m2c8:(BOOL)animated {
    CGSize size = (self.h5q1c9 && !self.v3n8p4) ? [self h6q1p9] : [self c2m8r4];
    CGRect f = self.frame;
    f.size = size;
    UIView *sv = self.superview;
    if (sv) {
        if (CGRectGetMaxX(f) > sv.bounds.size.width - 4.0) f.origin.x = sv.bounds.size.width - f.size.width - 4.0;
        if (CGRectGetMaxY(f) > sv.bounds.size.height - 4.0) f.origin.y = sv.bounds.size.height - f.size.height - 4.0;
        if (f.origin.x < 4.0) f.origin.x = 4.0;
        if (f.origin.y < 24.0) f.origin.y = 24.0;
    }
    void (^changes)(void) = ^{
        self.frame = f;
        BOOL compact = (self.h5q1c9 && !self.v3n8p4);
        self.titleLabel.hidden = compact;
        self.h8m3x6.hidden = compact;
        self.d2q9v5.hidden = compact;
        self.p7n1c4.hidden = compact;
        self.r9q3d6.hidden = !compact;
        self.backgroundColor = compact ? [UIColor clearColor] : ZThemePanelColor();
        self.layer.borderWidth = compact ? 0.0 : 1.4;
        self.layer.shadowOpacity = 0.0;
        self.layer.cornerRadius = compact ? (f.size.height * 0.5) : 16.0;
        self.r9q3d6.layer.cornerRadius = compact ? (f.size.height * 0.5) : 17.0;
        [self setNeedsLayout];
        [self layoutIfNeeded];
    };
    if (animated) [UIView animateWithDuration:0.18 animations:changes]; else changes();
}

- (void)b4q6n1:(UIButton *)sender {
    if (self.h5q1c9) return;
    self.t4q9k5 = sender.tag;
    [[NSUserDefaults standardUserDefaults] setInteger:self.t4q9k5 forKey:OX_NS("ot_slot")];
    [self zAutoStopSetBaseToCurrent];
    self.z7c4p1 = NO;
    [self r8p3d7];
    [self a9m3c6];
    Z0418c1e0ae();
}

- (void)r8p3d7 {
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    if ((NSInteger)_y5m8k2.count != (NSInteger)idxs.count) {
        [self z1a3b62f4d9];
        return;
    }
    if (self.t4q9k5 < 0 || self.t4q9k5 >= (NSInteger)idxs.count) self.t4q9k5 = 0;
    for (NSInteger i = 0; i < (NSInteger)_y5m8k2.count; i++) {
        UIButton *b = _y5m8k2[i];
        if (i < (NSInteger)idxs.count) {
            UIImage *img = [self v7n3k6:idxs[i].intValue];
            if (b.imageView.image != img) [b setImage:img forState:UIControlStateNormal];
        }
        BOOL selected = (i == self.t4q9k5);
        b.backgroundColor = selected ? ZThemeOrange() : [UIColor colorWithWhite:0.0 alpha:0.0];
        b.layer.borderWidth = selected ? 1.1 : 0.0;
        b.layer.borderColor = ZThemeBorder().CGColor;
        b.layer.shadowColor = [UIColor clearColor].CGColor;
        b.layer.shadowOpacity = 0.0;
        b.layer.shadowRadius = 0.0;
        b.layer.shadowOffset = CGSizeZero;
    }
}

- (void)y2v9m5 {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:ZuiAutoTargetText() message:ZuiAutoTargetPrompt() preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.text = self.d7m2x6 > 0 ? [NSString stringWithFormat:@"%ld", (long)self.d7m2x6] : @"";
    }];
    [alert addAction:[UIAlertAction actionWithTitle:ZuiSaveText() style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        NSInteger v = [alert.textFields.firstObject.text integerValue];
        if (v < 0) v = 0;
        if (v > 9999) v = 9999;
        self.d7m2x6 = v;
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        [self.h8m3x6 setTitle:(v > 0 ? [NSString stringWithFormat:@"%ld", (long)v] : ZuiSetText()) forState:UIControlStateNormal];
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setInteger:self.d7m2x6 forKey:OX_NS("ot_target")];
        [ud setInteger:self.a8p3v1 forKey:OX_NS("ot_current")];
    [ud setInteger:self.z2m6q8 forKey:OX_NS("ot_base")];
        [ud synchronize];
        if (v <= 0 && self.h5q1c9) {
            [self.d2q9v5 setOn:NO animated:YES];
            [self u6c1x4:self.d2q9v5];
        }
        [self a9m3c6];
        Z0418c1e0ae();
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *root = UIApplication.sharedApplication.keyWindow.rootViewController;
    if (root.presentedViewController) root = root.presentedViewController;
    [root presentViewController:alert animated:YES completion:nil];
    Z0418c1e0ae();
}

- (void)u6c1x4:(UISwitch *)sender {
    if (sender.isOn && self.d7m2x6 <= 0) {
        [sender setOn:NO animated:YES];
        [self y2v9m5];
        return;
    }
    self.h5q1c9 = sender.isOn;
    if (self.h5q1c9) {
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        self.k9m2d7 = NO;
        self.q6r1m8 = NO;
        self.v3n8p4 = NO;
    } else {
        self.k9m2d7 = NO;
        self.q6r1m8 = NO;
        self.v3n8p4 = YES;
    }
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setBool:self.h5q1c9 forKey:OX_NS("ot_running")];
    [ud setInteger:self.a8p3v1 forKey:OX_NS("ot_current")];
    [ud setInteger:self.z2m6q8 forKey:OX_NS("ot_base")];
    [ud synchronize];
    [self a9m3c6];
    [self k9m2c8:YES];
    Z0418c1e0ae();
}

- (void)p3n8q2:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || !Ongnong::Z76f880a1d(self.t4q9k5)) return;
    self.k9m2d7 = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.h5q1c9) return;
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        [self a9m3c6];
    });
}

- (void)z4fb91b7407:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || !(Ongnong::Z76d7aa0492(self.t4q9k5) || Ongnong::Z76b8e20f53(self.t4q9k5))) return;
    self.k9m2d7 = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.h5q1c9) return;
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        [self a9m3c6];
    });
}

- (void)m7d4k9:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || self.d7m2x6 <= 0) return;
    self.k9m2d7 = NO;
    [self zAutoStopSyncFromMaster];
    [[NSUserDefaults standardUserDefaults] setInteger:self.a8p3v1 forKey:OX_NS("ot_current")];
    NSInteger progress = [self zAutoStopCycleProgress];
    [self a9m3c6];
    if (!self.z7c4p1 && progress >= self.d7m2x6) {
        self.z7c4p1 = YES;
        if (Ongnong::SlotIsSpinningForCycle()) {
            Ongnong::PauseAutoSpinForCycle();
        }
        [self x5q2v8];
    }
}

- (void)c7v2m9:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || !self.q6r1m8) return;
    self.q6r1m8 = NO;
    [self x5q2v8];
}

- (void)x5q2v8 {
    if (!self.h5q1c9) return;
    self.h5q1c9 = NO;
    self.k9m2d7 = NO;
    self.q6r1m8 = NO;
    self.v3n8p4 = YES;
    [self.d2q9v5 setOn:NO animated:YES];
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setBool:NO forKey:OX_NS("ot_running")];
    [ud synchronize];
    BOOL stoppedByGameMethod = Ongnong::StopSpinForAutoTarget();
    if (!stoppedByGameMethod) {
        CGSize screen = UIScreen.mainScreen.bounds.size;
        CGPoint p = CGPointMake(screen.width * 0.5, screen.height * 0.85);
        NSInteger pid = [X7q4M c4d8];
        [X7q4M x7q0:pid n2v5:p k9m1:UITouchPhaseBegan];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.055 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [X7q4M x7q0:pid n2v5:p k9m1:UITouchPhaseEnded];
        });
    }
    [self a9m3c6];
    [self k9m2c8:YES];
    Z0418c1e0ae();
}

- (void)a9m3c6 {
    [self zAutoStopSyncFromMaster];
    [self z1a3b62f4d9];
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    if (self.t4q9k5 < 0 || self.t4q9k5 >= (NSInteger)idxs.count) self.t4q9k5 = 0;
    int idx = [self q4p9x1:self.t4q9k5];
    UIImage *img = [self v7n3k6:idx];
    self.x1v7p4.image = img;
    NSInteger progress = self.h5q1c9 ? [self zAutoStopCycleProgress] : 0;
    NSString *text = [NSString stringWithFormat:OX_NS("%ld/%ld"), (long)progress, (long)MAX((NSInteger)0, self.d7m2x6)];
    self.c6m2n8.text = text;
}
@end

@interface Z9abcb7bb90 : UIViewController
@property (nonatomic, strong) Za540ef69c7 *v2p6k1;
@property (nonatomic, strong) Z4c5163ab2a *a9q2x4;
@property (nonatomic, strong) Z1c94f803b6 *n7c3m8;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSTimer *d8r4q7;
@property (nonatomic, assign) BOOL collapsed;
@property (nonatomic, assign) CGRect x5m9c2;
@property (nonatomic, strong) UIButton *b3n7v1;
@property (nonatomic, strong) Zd4f227a905 *d2q8n4;
@property (nonatomic, strong) Z8x4c2v7 *w7p3v6;
@property (nonatomic, strong) X4f0a1 *q72p9m4;
@property (nonatomic, assign) NSInteger z4b51d86a09;
@property (nonatomic, assign) NSUInteger p6d1v7;
@property (nonatomic, assign) BOOL k4m8r2;
@property (nonatomic, assign) BOOL h1x9c5;
@property (nonatomic, strong) UIButton *u1x7p4;
@property (nonatomic, assign) BOOL r8m2d5;
@property (nonatomic, assign) CGPoint r6q2p8;
@property (nonatomic, strong) UIButton *b6p2x9;
@property (nonatomic, assign) BOOL v7m4q1;
@property (nonatomic, assign) CGPoint n5c8r2;
@property (nonatomic, strong) UIButton *e3k9d6;
@property (nonatomic, assign) BOOL x4p7m2;
@property (nonatomic, assign) CGPoint h8q1v5;
@property (nonatomic, strong) UIButton *q8z1u4;
@property (nonatomic, assign) BOOL m3k9a2;
@property (nonatomic, assign) CGPoint c7w2e6;
@property (nonatomic, assign) BOOL zForestDragging;
@property (nonatomic, strong) UIButton *k2m8v4;
@property (nonatomic, assign) BOOL p7x3n6;
@property (nonatomic, assign) CGPoint a4q9d1;
@property (nonatomic, assign) BOOL n3q9c6;
@property (nonatomic, assign) BOOL b7v1k8;
@property (nonatomic, assign) BOOL t4p6x2;
@property (nonatomic, assign) float c9m5r3;
@property (nonatomic, assign) BOOL f7q2n8;
@property (nonatomic, assign) CGRect p4m9c1;
@property (nonatomic, strong) UIView *c5a8u2;
@property (nonatomic, strong) NSArray<UIButton *> *s4k7e1;
@property (nonatomic, strong) UIButton *w6j2r9;
@property (nonatomic, assign) BOOL a6t3y8;
@property (nonatomic, assign) BOOL d7u4i1;
@property (nonatomic, assign) CGPoint f2o9p5;
@property (nonatomic, assign) BOOL zAltGridDragging;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, UIButton *> *zAltFloatButtons;
- (void)p8c4n2;
- (void)zApplyInterface;
- (void)zToggleInterface;
- (void)zAltOpenMenu;
- (void)zAltCloseMenu;
- (void)zAltGridTap:(UIButton *)sender;
- (void)zAltGridPan:(UIPanGestureRecognizer *)pan;
- (NSArray<NSString *> *)zAltMenuTitles;
- (void)zRefreshAltMenuTitles;
- (void)zAltTargetCycle;
- (void)zAltShowShortcut:(NSInteger)tag;
- (void)zAltShortcutTap:(UIButton *)sender;
- (void)zAltShortcutClose:(UIButton *)sender;
- (void)zAltShortcutPan:(UIPanGestureRecognizer *)pan;
- (void)zMagicPopupClose;
- (void)zForestPopupClose;
- (void)zMergePopupClose;
- (void)orderDiagHold:(UILongPressGestureRecognizer *)gesture;
- (CGRect)collapseHandleFrameForMenuFrame:(CGRect)menuFrame collapsed:(BOOL)isCollapsed;
- (void)z3q7d9;
- (void)d2x8q4;
- (void)h9r3v7;
- (void)m1b6k5;
- (void)h2p7m9;
- (void)e7k3p9;
- (UIImage *)z0b9c95dabc:(int)idx;
- (NSInteger)z3f0b8e15a2:(NSInteger)slot;
- (void)z7ee09a13c4;
- (void)q1c8v4;
- (void)q9d3m6;
- (void)t6r2n9;
- (void)j3v7q5;
- (void)a7q3d8;
- (void)s2k6v4;
- (void)z6m4a8;
- (void)r9b4t1;
- (void)h6d2q8;
- (void)p3v7m5:(UIPanGestureRecognizer *)pan;
- (UIButton *)c4m8q2:(CGRect)frame title:(NSString *)title action:(SEL)action closeAction:(SEL)closeAction panAction:(SEL)panAction;
- (void)b2v7n4;
- (void)z3n8v5;
- (void)k1d6p4:(UIPanGestureRecognizer *)pan;
- (void)t5x9c2;
- (void)g7q3m8;
- (void)v5c2q8;
- (void)w1p5c9;
- (void)a9r2k6:(UIPanGestureRecognizer *)pan;
- (void)q4d8x3;
- (void)y6m1p7;
- (void)j6t3a8;
- (void)y4d8p2;
- (void)u7m1c9;
- (void)h5p1k8;
- (void)v7b2c9;
- (void)w3m7d2;
- (void)z8a5c1;
- (void)q2n9v6;
- (void)n1c8f5:(UIPanGestureRecognizer *)pan;
- (void)b6x4j9:(NSNotification *)note;
- (void)u4m8p2;
- (void)c3n7x5;
- (void)r9k2d6;
- (void)y5v1q8:(UIPanGestureRecognizer *)pan;
- (CGRect)zClampFrame:(CGRect)frame minW:(CGFloat)minW minH:(CGFloat)minH maxW:(CGFloat)maxW maxH:(CGFloat)maxH;
- (void)zSaveQuickPanelFrame;
- (void)zSaveCounterPanelFrame;
- (void)g5x9q4:(NSNotification *)note;
- (void)ongFriendModule;
- (void)ongFriendClearLink:(UIButton *)sender;
- (void)ongPotionModule;
- (void)zBuyVipPayOS;
- (void)zShowBuyVipRegionPicker;
- (void)zOpenInternationalCheckout;
- (void)zVipLoadPlans;
- (void)zStyleBuyVipAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle;
- (void)zApplyBuyVipStyleInAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle;
- (void)zCollectLabelsFromView:(UIView *)view into:(NSMutableArray<UILabel *> *)labels;
@end

@implementation Za540ef69c7
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = ZThemePanelColor();
    ApplyNeon(self, ZThemeBorder(), 24.0, 1.2);
    self.clipsToBounds = YES;

    _title = Label(Z6ddd40608f(), zb1d8336499(37.0, 22.0), UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentCenter);
    _title.layer.shadowColor = RGB(255, 120, 20).CGColor;
    _title.layer.shadowOpacity = 0.0;
    _title.layer.shadowRadius = 0.0;
    _title.layer.shadowOffset = CGSizeZero;
    [self addSubview:_title];

    _r6q2p8 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_r6q2p8 setTitle:ZuiLanguageButtonText() forState:UIControlStateNormal];
    [_r6q2p8 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _r6q2p8.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(19.0, 12.0) weight:UIFontWeightHeavy];
    _r6q2p8.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_r6q2p8, ZThemeBorder(), 12.0, 1.0);
    [_r6q2p8 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_r6q2p8];

    _k3v9d4 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_k3v9d4 setTitle:ZVipBuyNowText() forState:UIControlStateNormal];
    [_k3v9d4 setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    _k3v9d4.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(20.0, 13.0) weight:UIFontWeightBlack];
    _k3v9d4.backgroundColor = RGB(18, 105, 45);
    _k3v9d4.layer.cornerRadius = 8.0;
    _k3v9d4.layer.borderWidth = 1.0;
    _k3v9d4.layer.borderColor = RGB(40, 155, 72).CGColor;
    [self addSubview:_k3v9d4];

    Zcb66126fa3 *b1 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoClickText() icon:[NSString string] color:RGB(45, 255, 70)];
    Zcb66126fa3 *b2 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiHistoryText() icon:[NSString string] color:RGB(234, 76, 255)];
    Zcb66126fa3 *b3 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoBuildText() icon:[NSString string] color:RGB(50, 190, 255)];
    Zcb66126fa3 *b4 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoPigHammerText() icon:[NSString string] color:RGB(255, 120, 30)];
    Zcb66126fa3 *b9 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiMagicCardsQuickText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b5 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiUpdateText() icon:[NSString string] color:RGB(255, 65, 65)];
    b5.v1q7p3 = [RGB(205, 28, 28) colorWithAlphaComponent:0.90];
    b5.backgroundColor = b5.v1q7p3;
    b5.x9c4n6.textColor = [UIColor whiteColor];
    Zcb66126fa3 *b10 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiBuyVipText() icon:[NSString string] color:RGB(255, 212, 55)];
    b10.v1q7p3 = [RGB(203, 148, 20) colorWithAlphaComponent:0.93];
    b10.backgroundColor = b10.v1q7p3;
    b10.x9c4n6.textColor = [UIColor whiteColor];
    Zcb66126fa3 *b6 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiToolsText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b7 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoTargetText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b8 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiMenuColorText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b11 = [[Zcb66126fa3 alloc] initWithV5m8p2:Zr7f421() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b12 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiBetCycleText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b13 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoMergeText() icon:[NSString string] color:RGB(120, 235, 170)];
    Zcb66126fa3 *b14 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiFriendInviteText() icon:[NSString string] color:RGB(90, 210, 255)];
    NSString *potionMenuTitle = ZuiPotionStateText(Ongnong::AutoPotionIsEnabled());
    Zcb66126fa3 *b15 = [[Zcb66126fa3 alloc] initWithV5m8p2:potionMenuTitle icon:[NSString string] color:RGB(185, 105, 255)];
    Zcb66126fa3 *b16 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiInterfaceText() icon:[NSString string] color:ZThemeBorder()];
    _a7m1c5 = @[b5, b10, b2, b3, b4, b9, b1, b6, b7, b8, b11, b12, b13, b14, b15, b16];
    for (UIButton *button in _a7m1c5) [self addSubview:button];

    _x8p4n2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_x8p4n2 setTitle:qsec_s_0038() forState:UIControlStateNormal];
    [_x8p4n2 setTitleColor:RGB(160, 250, 255) forState:UIControlStateNormal];
    _x8p4n2.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(24.0, 15.0) weight:UIFontWeightHeavy];
    _x8p4n2.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_x8p4n2, ZThemeBorder(), 8.0, 1.0);
    _x8p4n2.hidden = YES;
    [self addSubview:_x8p4n2];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    [self addGestureRecognizer:pan];
    return self;
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)e4p7n1:(NSString *)code {
    _title.text = Z6ddd40608f();
    if (code.length == 0) code = qsec_s_0039();
    BOOL known = [code isEqualToString:qsec_s_0039()] || [code isEqualToString:qsec_s_0040()] || [code isEqualToString:qsec_s_0048()] || [code isEqualToString:qsec_s_0056()] || [code isEqualToString:OngnongUIVaultLangCodeEN()];
    if (!known) code = qsec_s_0039();

    [_r6q2p8 setTitle:ZuiLanguageButtonText() forState:UIControlStateNormal];
    [_k3v9d4 setTitle:ZVipBuyNowText() forState:UIControlStateNormal];
    NSString *potionMenuTitle = ZuiPotionStateText(Ongnong::AutoPotionIsEnabled());
    NSArray<NSString *> *titles = @[ZuiUpdateText(), ZuiBuyVipText(), ZuiHistoryText(), ZuiAutoBuildText(), ZuiAutoPigHammerText(), ZuiMagicCardsQuickText(), ZuiAutoClickText(), ZuiToolsText(), ZuiAutoTargetText(), ZuiMenuColorText(), Zr7f421(), ZuiBetCycleText(), ZuiAutoMergeText(), ZuiFriendInviteText(), potionMenuTitle, ZuiInterfaceText()];

    NSUInteger count = MIN(_a7m1c5.count, titles.count);
    for (NSUInteger i = 0; i < count; i++) {
        Zcb66126fa3 *button = _a7m1c5[i];
        button.x9c4n6.text = titles[i];
        [button setNeedsLayout];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat s = z067adc83c5();
    CGFloat w = self.bounds.size.width;
    _title.font = [UIFont systemFontOfSize:zb1d8336499(30.0, 18.0) weight:UIFontWeightBlack];
    _title.frame = CGRectMake(6 * s, 10 * s, w - 12 * s, 48 * s);

    CGFloat side = 6 * s;
    CGFloat rowY = 58 * s;
    CGFloat rowH = 40 * s;
    _r6q2p8.frame = CGRectMake(side, rowY, w - side * 2.0, rowH);
    BOOL freeMode = [ZuiBuyVipText() isEqualToString:OX_NS("FREE")];
    _k3v9d4.hidden = !freeMode;
    CGFloat y = 104 * s;
    if (freeMode) {
        _k3v9d4.frame = CGRectMake(side, y, w - side * 2.0, 40 * s);
        y += 46 * s;
    } else {
        _k3v9d4.frame = CGRectZero;
    }

    NSMutableArray<UIView *> *visibleButtons = [NSMutableArray array];
    for (UIView *button in _a7m1c5) { if (!button.hidden) [visibleButtons addObject:button]; }
    CGFloat gap = (visibleButtons.count > 9 ? 4.0 * s : 6.0 * s);
    CGFloat bh = 50 * s;
    if (visibleButtons.count > 0) {
        CGFloat bottom = self.bounds.size.height - 8.0 * s;
        CGFloat available = MAX(1.0, bottom - y);
        CGFloat fitH = (available - gap * MAX((NSInteger)0, (NSInteger)visibleButtons.count - 1)) / MAX((NSInteger)1, (NSInteger)visibleButtons.count);
        bh = MIN(bh, MAX(24.0 * s, fitH));
    }
    NSUInteger visibleIndex = 0;
    for (UIView *button in _a7m1c5) {
        if (button.hidden) { button.frame = CGRectZero; continue; }
        CGFloat bottom = self.bounds.size.height - 8.0 * s;
        CGFloat remaining = visibleButtons.count - visibleIndex;
        CGFloat maxH = MAX(1.0, (bottom - y - gap * MAX((NSInteger)0, (NSInteger)remaining - 1)) / MAX((CGFloat)1.0, (CGFloat)remaining));
        CGFloat rowHeight = MIN(bh, maxH);
        button.frame = CGRectMake(side, y, w - side * 2.0, rowHeight);
        y += rowHeight + gap;
        visibleIndex++;
    }

    _x8p4n2.frame = CGRectMake(w - 30 * s, self.bounds.size.height * 0.40, 30 * s, 70 * s);
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *superview = self.superview;
    if (!superview) return;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged) {
        CGFloat halfW = self.bounds.size.width / 2.0;
        CGFloat halfH = self.bounds.size.height / 2.0;
        CGFloat fixedX = (6.0 * z067adc83c5()) + halfW;
        CGPoint c = CGPointMake(fixedX, _x3q8c6.y + translation.y);
        c.y = MAX(halfH, MIN(superview.bounds.size.height - halfH, c.y));
        self.center = c;
        [[NSNotificationCenter defaultCenter] postNotificationName:qsec_s_0062() object:self];
    }
}


@end

@implementation Z4c5163ab2a
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = ZThemePanelColor();
    ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
    _d5q9v3 = [[Zf721fd429b alloc] initWithV5m8p2:[NSString string] color:RGB(35, 255, 90)];
    _t2m7k6 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0063() color:RGB(52, 225, 255)];
    _c8x1p4 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0064() color:RGB(255, 69, 230)];
    _r3n9d5 = [[Z73b2f81c4a alloc] initWithFrame:CGRectZero];
    _v6q2m8 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0081() color:RGB(208, 76, 255)];
    _k4p7c1 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0066() color:RGB(55, 255, 72)];
    for (UIView *v in @[_d5q9v3, _t2m7k6, _c8x1p4, _r3n9d5, _v6q2m8, _k4p7c1]) [self addSubview:v];
    _q4n8p2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_q4n8p2 setTitle:OX_NS("›") forState:UIControlStateNormal];
    [_q4n8p2 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _q4n8p2.titleLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightBlack];
    _q4n8p2.titleLabel.adjustsFontSizeToFitWidth = YES;
    _q4n8p2.contentEdgeInsets = UIEdgeInsetsZero;
    _q4n8p2.backgroundColor = UIColor.clearColor;
    _q4n8p2.layer.borderWidth = 0.0;
    _q4n8p2.layer.shadowOpacity = 0.0;
    [self addSubview:_q4n8p2];
    self.clipsToBounds = NO;
    _u2p7k4 = [[UIView alloc] initWithFrame:CGRectZero];
    _u2p7k4.backgroundColor = ZThemePanelColor();
    ApplyNeon(_u2p7k4, ZThemeBorder(), 12.0, 1.0);
    _u2p7k4.hidden = YES;
    [self insertSubview:_u2p7k4 atIndex:0];
    _m6q1d8 = [[Zf721fd429b alloc] initWithV5m8p2:OX_NS("MENU") color:ZThemeBorder()];
    _h3c9v5 = [[Zf721fd429b alloc] initWithV5m8p2:OX_NS("LỊCH SỬ") color:ZThemeBorder()];
    _g8n2x6 = [[Zf721fd429b alloc] initWithV5m8p2:OX_NS("ĐỔI UI") color:ZThemeBorder()];
    for (UIButton *b in @[_m6q1d8, _h3c9v5, _g8n2x6]) { b.hidden = YES; [self addSubview:b]; }
    _z7h4p1 = [[UIView alloc] initWithFrame:CGRectZero];
    _z7h4p1.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_z7h4p1, ZThemeBorder(), 10.0, 0.9);
    _z7h4p1.hidden = YES;
    [self addSubview:_z7h4p1];
    _x2c8m5 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _x2c8m5.contentMode = UIViewContentModeScaleAspectFit;
    [_z7h4p1 addSubview:_x2c8m5];
    _p9v3k7 = Label([NSString string], 12.0, UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentLeft);
    _p9v3k7.adjustsFontSizeToFitWidth = YES;
    _p9v3k7.minimumScaleFactor = 0.55;
    [_z7h4p1 addSubview:_p9v3k7];
    _r4n6d2 = [UIButton buttonWithType:UIButtonTypeCustom];
    ZPlainIconButton(_r4n6d2, ZCounterTrashIconImage());
    [_z7h4p1 addSubview:_r4n6d2];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    [self addGestureRecognizer:pan];
    return self;
}
- (void)setQ6m2v8:(BOOL)collapsed {
    _q6m2v8 = collapsed;
    [self setNeedsLayout];
    [self layoutIfNeeded];
}
- (void)setA1v8m3:(BOOL)enabled {
    _a1v8m3 = enabled;
    [self setNeedsLayout];
    [self layoutIfNeeded];
}
- (void)layoutSubviews {
    [super layoutSubviews];
    NSArray *allViews = @[_d5q9v3, _t2m7k6, _c8x1p4, _r3n9d5, _v6q2m8, _k4p7c1];
    NSArray *altOnlyViews = @[_u2p7k4, _m6q1d8, _h3c9v5, _g8n2x6, _z7h4p1];
    if (!_a1v8m3 || _q6m2v8) {
        for (UIView *v in altOnlyViews) v.hidden = YES;
    }
    if (_a1v8m3 && !_q6m2v8) {
        for (UIView *v in allViews) v.hidden = NO;
        _q4n8p2.hidden = NO;
        _u2p7k4.hidden = NO;
        _m6q1d8.hidden = NO;
        _h3c9v5.hidden = NO;
        _g8n2x6.hidden = YES;
        _z7h4p1.hidden = NO;
        self.backgroundColor = ZThemePanelColor();
        ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
        self.layer.cornerRadius = 14.0;
        CGFloat w = self.bounds.size.width;
        CGFloat gap = 3.0;
        CGFloat margin = 4.0;
        CGFloat topY = 4.0;
        CGFloat topH = 40.0;
        CGFloat arrowW = 24.0;
        CGFloat inner = w - margin * 2.0 - gap * 4.0 - arrowW;
        CGFloat wifiW = inner * 0.205;
        CGFloat skipW = inner * 0.205;
        CGFloat targetW = inner * 0.295;
        CGFloat playW = inner - wifiW - skipW - targetW;
        CGFloat x = margin;
        _d5q9v3.frame = CGRectMake(x, topY, wifiW, topH); x += wifiW + gap;
        _k4p7c1.frame = CGRectMake(x, topY, skipW, topH); x += skipW + gap;
        _r3n9d5.frame = CGRectMake(x, topY, targetW, topH); x += targetW + gap;
        _v6q2m8.frame = CGRectMake(x, topY, playW, topH);
        _q4n8p2.frame = CGRectMake(w - margin - arrowW, topY, arrowW, topH);
        _q4n8p2.layer.cornerRadius = 8.0;
        _r3n9d5.layer.cornerRadius = 10.0;
        _r3n9d5.backgroundColor = ZThemeButtonOff();
        ApplyNeon(_r3n9d5, ZThemeBorder(), 10.0, 1.0);
        CGFloat row2Y = 47.0;
        CGFloat row2H = 31.0;
        _u2p7k4.frame = CGRectMake(0.0, row2Y - 2.0, w, row2H + 4.0);
        _u2p7k4.backgroundColor = UIColor.clearColor;
        _u2p7k4.layer.cornerRadius = 0.0;
        _u2p7k4.layer.borderWidth = 0.0;
        _u2p7k4.layer.shadowOpacity = 0.0;
        CGFloat fixedW = (w - margin * 2.0 - gap * 3.0) / 4.0;
        CGFloat bx = margin;
        _m6q1d8.frame = CGRectMake(bx, row2Y, fixedW, row2H); bx += fixedW + gap;
        _t2m7k6.frame = CGRectMake(bx, row2Y, fixedW, row2H); bx += fixedW + gap;
        _c8x1p4.frame = CGRectMake(bx, row2Y, fixedW, row2H); bx += fixedW + gap;
        _h3c9v5.frame = CGRectMake(bx, row2Y, fixedW, row2H);
        _g8n2x6.frame = CGRectZero;
        for (UIButton *b in @[_m6q1d8, _t2m7k6, _c8x1p4, _h3c9v5]) Z611a3d09ce(b, 10.5, 5.5);
        CGFloat row3Y = 81.0;
        CGFloat row3H = MAX(28.0, self.bounds.size.height - row3Y - 4.0);
        _z7h4p1.frame = CGRectMake(margin, row3Y, w - margin * 2.0, row3H);
        _z7h4p1.layer.cornerRadius = 9.0;
        CGFloat iconW = MIN(28.0, row3H - 4.0);
        _x2c8m5.frame = CGRectMake(5.0, (row3H - iconW) * 0.5, iconW, iconW);
        CGFloat trashW = 31.0;
        _r4n6d2.frame = CGRectMake(_z7h4p1.bounds.size.width - trashW - 3.0, 2.0, trashW, row3H - 4.0);
        _p9v3k7.frame = CGRectMake(8.0 + iconW, 1.0, _z7h4p1.bounds.size.width - iconW - trashW - 15.0, row3H - 2.0);
        return;
    }
    if (!_a1v8m3) {
        self.backgroundColor = ZThemePanelColor();
        ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
    }
    if (_q6m2v8) {
        for (UIView *v in allViews) v.hidden = (v != _r3n9d5);
        _q4n8p2.hidden = YES;
        CGFloat side = MAX(1.0, MIN(self.bounds.size.width, self.bounds.size.height) - 5.0);
        _r3n9d5.frame = CGRectMake((self.bounds.size.width-side)/2.0, (self.bounds.size.height-side)/2.0, side, side);
        _r3n9d5.layer.cornerRadius = side / 2.0;
        _r3n9d5.backgroundColor = UIColor.clearColor;
        _r3n9d5.layer.borderWidth = 0.0;
        _r3n9d5.layer.shadowOpacity = 0.0;
        self.layer.cornerRadius = MIN(self.bounds.size.width, self.bounds.size.height) / 2.0;
        return;
    }
    NSArray *views = @[_d5q9v3, _t2m7k6, _c8x1p4, _v6q2m8, _k4p7c1];
    for (UIView *v in allViews) v.hidden = (v == _r3n9d5);
    _q4n8p2.hidden = NO;
    self.layer.cornerRadius = 14.0;
    CGFloat s = z067adc83c5();
    CGFloat gap = 4 * s;
    CGFloat y = 5 * s;
    CGFloat h = self.bounds.size.height - 10 * s;
    CGFloat x = 5 * s;
    CGFloat arrowW = MAX(19.0, 28.0 * s);
    CGFloat arrowGap = 3.0;
    CGFloat usable = self.bounds.size.width - 10 * s - arrowW - arrowGap - gap * 4;
    CGFloat btnW = usable / 5.0;
    for (UIView *v in views) {
        v.frame = CGRectMake(x, y, btnW, h);
        if ([v isKindOfClass:[UIButton class]]) Z611a3d09ce((UIButton *)v, zb1d8336499(22.0, 13.0), 6.0);
        x += btnW + gap;
    }
    _q4n8p2.frame = CGRectMake(self.bounds.size.width - 5.0 * s - arrowW, y, arrowW, h);
    _q4n8p2.layer.cornerRadius = 0.0;
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *superview = self.superview;
    if (!superview) return;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged) {
        CGPoint c = CGPointMake(_x3q8c6.x + translation.x, _x3q8c6.y + translation.y);
        CGFloat s = z067adc83c5();
        CGFloat halfW = self.bounds.size.width / 2.0;
        CGFloat halfH = self.bounds.size.height / 2.0;
        CGFloat visibleX = MAX(26.0 * s, 18.0);
        c.x = MAX(visibleX - halfW, MIN(superview.bounds.size.width - visibleX + halfW, c.x));
        c.y = MAX(halfH, MIN(superview.bounds.size.height - halfH, c.y));
        self.center = c;
    } else if (!_q6m2v8 && (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled || pan.state == UIGestureRecognizerStateFailed)) {
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setFloat:self.frame.origin.x forKey:OX_NS("tool_x")];
        [ud setFloat:self.frame.origin.y forKey:OX_NS("tool_y")];
        [ud setFloat:self.frame.size.width forKey:OX_NS("tool_w")];
        [ud setFloat:self.frame.size.height forKey:OX_NS("tool_h")];
        [ud synchronize];
    }
}
@end

@implementation Z1c94f803b6

- (NSInteger)u4m9q2 {
    NSInteger mask = 0;
    if (Ongnong::Zx8fTokenAllowed()) mask |= 1;
    if (Ongnong::Zx8fPotionAllowed()) mask |= 2;
    if (Ongnong::Zx8fLightningAllowed()) mask |= 4;
    return mask;
}

- (NSArray<NSNumber *> *)e5r1k7:(NSInteger)allowedMask {
    static NSArray<NSNumber *> *order = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        order = @[@0, @1, @2, @4, @3, @5, @6, @7];
    });
    NSMutableArray<NSNumber *> *cycle = [NSMutableArray arrayWithObject:@0];
    for (NSNumber *n in order) {
        NSInteger candidate = n.integerValue;
        if (candidate == 0) continue;
        if ((candidate & ~allowedMask) != 0) continue;
        if ((candidate & allowedMask) == 0) continue;
        [cycle addObject:n];
    }
    return cycle;
}

- (BOOL)w8c2m5 {
    return [self u4m9q2] != 0;
}

- (NSInteger)m8v2p6:(NSInteger)storedMask allowed:(NSInteger)allowedMask {
    if (storedMask < 0) storedMask = 0;
    if ((storedMask & ~allowedMask) != 0) storedMask &= allowedMask;
    NSArray<NSNumber *> *cycle = [self e5r1k7:allowedMask];
    for (NSNumber *n in cycle) if (n.integerValue == storedMask) return storedMask;
    return 0;
}

- (BOOL)t3p8x4:(NSInteger)idx {
    if (!Zde31f8c6b2(idx)) return NO;
    NSInteger allowedMask = [self u4m9q2];
    NSInteger hideMask = [self m8v2p6:_r2c7m4 allowed:allowedMask];
    if (idx == Z87f6d0c11d && (hideMask & 1)) return NO;
    if (idx == Z2f0c1a9d77 && (hideMask & 2)) return NO;
    if (idx == Z5d92a7e4c1 && (hideMask & 4)) return NO;
    return YES;
}

- (void)q6v1d9 {
    NSInteger allowedMask = [self u4m9q2];
    BOOL canUseEye = (allowedMask != 0);
    _r2c7m4 = [self m8v2p6:_r2c7m4 allowed:allowedMask];
    if (!canUseEye) _r2c7m4 = 0;
    _eyeButton.hidden = !canUseEye;
    ZPlainIconButton(_eyeButton, ZCounterEyeIconImage(_r2c7m4 != 0));
    _eyeButton.alpha = canUseEye ? 1.0 : 0.0;
}

- (void)f7m2k6:(UIButton *)sender {
    NSInteger allowedMask = [self u4m9q2];
    if (allowedMask == 0) return;
    Z0418c1e0ae();
    NSArray<NSNumber *> *cycle = [self e5r1k7:allowedMask];
    NSInteger current = [self m8v2p6:_r2c7m4 allowed:allowedMask];
    NSUInteger idx = [cycle indexOfObject:@(current)];
    if (idx == NSNotFound) idx = 0;
    NSUInteger next = (idx + 1) % MAX((NSUInteger)1, cycle.count);
    _r2c7m4 = cycle[next].integerValue;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setInteger:_r2c7m4 forKey:OX_NS("hist_vip_hide_mode")];
    [ud synchronize];
    [self q6v1d9];
    [self setNeedsLayout];
    [self n4q9c1];
}

- (NSArray<Z6dcb301a04 *> *)zefc0e4e6bd {
    NSMutableArray<Z6dcb301a04 *> *visible = [NSMutableArray arrayWithCapacity:self.t6m1v8.count];
    for (Z6dcb301a04 *card in self.t6m1v8) {
        BOOL show = [self t3p8x4:card.p4x9c3];
        card.hidden = !show;
        if (show) [visible addObject:card];
    }
    return visible;
}

- (NSArray<Zc1dba0f365 *> *)z7d5c8a0f42 {
    NSMutableArray<Zc1dba0f365 *> *visible = [NSMutableArray arrayWithCapacity:self.p7k4n2.count];
    for (Zc1dba0f365 *column in self.p7k4n2) {
        BOOL show = [self t3p8x4:column.p4x9c3];
        column.hidden = !show;
        if (show) [visible addObject:column];
    }
    return visible;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = ZThemePanelDarker();
    ApplyNeon(self, ZThemeBorder(), 18.0, 1.2);
    self.layer.shadowOpacity = 0.0;
    self.clipsToBounds = NO;
    _r2c7m4 = [[NSUserDefaults standardUserDefaults] integerForKey:OX_NS("hist_vip_hide_mode")];
    if (_r2c7m4 < 0 || _r2c7m4 > 7) _r2c7m4 = 0;

    _title = Label(
        Ongnong::Zx8fUILabel(OX_NS("counter_title"), OX_NS("ONGNONG.io.vn")),
        13.0,
        UIFontWeightBlack,
        ZThemeWhite(),
        NSTextAlignmentCenter);
    _title.numberOfLines = 1;
    _title.adjustsFontSizeToFitWidth = YES;
    _title.minimumScaleFactor = 0.34;
    _title.lineBreakMode = NSLineBreakByClipping;
    if (@available(iOS 9.0, *)) _title.allowsDefaultTighteningForTruncation = YES;
    _title.layer.shadowColor = RGB(255, 120, 20).CGColor;
    _title.layer.shadowOpacity = 0.0;
    _title.layer.shadowRadius = 0.0;
    _title.layer.shadowOffset = CGSizeZero;
    _title.userInteractionEnabled = YES;
    [self addSubview:_title];

    _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_closeButton setTitle:qsec_s_0068() forState:UIControlStateNormal];
    [_closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightHeavy];
    _closeButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_closeButton, ZThemeBorder(), 6.0, 0.75);
    _closeButton.layer.shadowOpacity = 0.30;
    [_closeButton addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_closeButton];

    _k3v9d4 = [UIButton buttonWithType:UIButtonTypeCustom];
    ZPlainIconButton(_k3v9d4, ZCounterTrashIconImage());
    [_k3v9d4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_k3v9d4];

    _eyeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    ZPlainIconButton(_eyeButton, ZCounterEyeIconImage(NO));
    [_eyeButton addTarget:self action:@selector(f7m2k6:) forControlEvents:UIControlEventTouchUpInside];
    _eyeButton.hidden = YES;
    [self addSubview:_eyeButton];

    Z6dcb301a04 *c0 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0021() fallback:qsec_s_0069() color:Z07aec8e446(Z700020a485) index:Z700020a485];
    Z6dcb301a04 *c1 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0023() fallback:qsec_s_0070() color:Z07aec8e446(Z124338f2d8) index:Z124338f2d8];
    Z6dcb301a04 *c2 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0025() fallback:qsec_s_0071() color:Z07aec8e446(Z94881eb8d3) index:Z94881eb8d3];
    Z6dcb301a04 *c3 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0027() fallback:qsec_s_0072() color:Z07aec8e446(Z646dcbe562) index:Z646dcbe562];
    Z6dcb301a04 *c4 = [[Z6dcb301a04 alloc] initWithC7q3x9:[NSString string] fallback:[NSString string] color:Z07aec8e446(Z2f0c1a9d77) index:Z2f0c1a9d77];
    Z6dcb301a04 *c5 = [[Z6dcb301a04 alloc] initWithC7q3x9:[NSString string] fallback:Ongnong::Z57eb159d41(Z87f6d0c11d) color:Z07aec8e446(Z87f6d0c11d) index:Z87f6d0c11d];
    Z6dcb301a04 *c6 = [[Z6dcb301a04 alloc] initWithC7q3x9:[NSString string] fallback:Ongnong::Z57eb159d41(Z5d92a7e4c1) color:Z07aec8e446(Z5d92a7e4c1) index:Z5d92a7e4c1];
    _t6m1v8 = @[c0, c1, c2, c3, c4, c5, c6];
    for (UIView *v in _t6m1v8) {
        v.userInteractionEnabled = NO;
        [self addSubview:v];
    }

    _d9q3x5 = [[UIView alloc] initWithFrame:CGRectZero];
    _d9q3x5.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.10];
    _d9q3x5.clipsToBounds = YES;
    _d9q3x5.userInteractionEnabled = YES;
    _d9q3x5.layer.cornerRadius = 7.0;
    _d9q3x5.layer.borderWidth = 0.0;
    _d9q3x5.layer.shadowOpacity = 0.0;
    [self addSubview:_d9q3x5];

    Zc1dba0f365 *h0 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z700020a485) index:Z700020a485];
    Zc1dba0f365 *h1 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z124338f2d8) index:Z124338f2d8];
    Zc1dba0f365 *h2 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z94881eb8d3) index:Z94881eb8d3];
    Zc1dba0f365 *h3 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z646dcbe562) index:Z646dcbe562];
    Zc1dba0f365 *h4 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z2f0c1a9d77) index:Z2f0c1a9d77];
    Zc1dba0f365 *h5 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z87f6d0c11d) index:Z87f6d0c11d];
    Zc1dba0f365 *h6 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z5d92a7e4c1) index:Z5d92a7e4c1];
    _p7k4n2 = @[h0, h1, h2, h3, h4, h5, h6];
    for (UIView *v in _p7k4n2) {
        v.clipsToBounds = YES;
        [_d9q3x5 addSubview:v];
    }

    _y1m5x9 = Label(OX_NS("↘"), 18.0, UIFontWeightHeavy, RGB(120, 220, 255), NSTextAlignmentCenter);
    _y1m5x9.userInteractionEnabled = YES;
    _y1m5x9.alpha = 0.75;
    [self addSubview:_y1m5x9];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    pan.cancelsTouchesInView = NO;
    pan.delaysTouchesBegan = NO;
    pan.delaysTouchesEnded = NO;
    pan.delegate = self;
    [self addGestureRecognizer:pan];

    [self n4q9c1];
    return self;
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;

    CGFloat margin = 5.0;
    CGFloat gap = 4.0;
    CGFloat titleY = 3.0;
    CGFloat titleH = 17.0;
    CGFloat iconTop = 23.0;
    CGFloat iconH = 28.0;
    CGFloat historyY = iconTop + iconH + 1.0;
    CGFloat bottomPad = 5.0;

    self.layer.cornerRadius = 18.0;

    ZPlainIconButton(_k3v9d4, ZCounterTrashIconImage());
    _k3v9d4.frame = CGRectMake(5.0, 2.0, 22.0, 22.0);

    _closeButton.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightHeavy];
    _closeButton.frame = CGRectMake(w - 21.0, 4.0, 15.0, 15.0);
    _closeButton.layer.cornerRadius = 6.0;

    [self q6v1d9];
    CGFloat eyeSize = 24.0;
    CGFloat closeLeft = CGRectGetMinX(_closeButton.frame);
    CGFloat titleLeft = CGRectGetMaxX(_k3v9d4.frame) + 2.0;
    CGFloat controlGap = 2.0;
    BOOL showEye = !_eyeButton.hidden && [self w8c2m5];

    CGFloat eyeX = closeLeft - eyeSize - controlGap;
    _eyeButton.frame = CGRectMake(eyeX, 0.5, eyeSize, eyeSize);

    CGFloat titleRight = showEye ? (eyeX - controlGap) : (closeLeft - controlGap);
    CGFloat titleW = MAX(28.0, titleRight - titleLeft);
    CGFloat responsiveFont = MIN(15.0, MAX(12.0, w * 0.047));
    _title.font = [UIFont systemFontOfSize:responsiveFont weight:UIFontWeightBlack];
    _title.adjustsFontSizeToFitWidth = YES;
    _title.minimumScaleFactor = 0.58;
    _title.numberOfLines = 1;
    _title.lineBreakMode = NSLineBreakByClipping;
    _title.textAlignment = NSTextAlignmentCenter;
    _title.frame = CGRectMake(titleLeft, titleY, titleW, titleH);


    NSArray<Z6dcb301a04 *> *visibleCards = [self zefc0e4e6bd];
    NSUInteger cardCount = MAX((NSUInteger)1, visibleCards.count);
    CGFloat cardW = (w - margin * 2.0 - gap * (cardCount - 1)) / (CGFloat)cardCount;
    for (NSUInteger i = 0; i < visibleCards.count; i++) {
        Z6dcb301a04 *card = visibleCards[i];
        card.layer.cornerRadius = 7.0;
        card.frame = CGRectMake(margin + (cardW + gap) * i, iconTop, cardW, iconH);
    }

    CGFloat boxH = MAX(34.0, h - historyY - bottomPad);
    _d9q3x5.frame = CGRectMake(margin, historyY, w - margin * 2.0, boxH);
    _d9q3x5.layer.cornerRadius = 7.0;

    NSArray<Zc1dba0f365 *> *visibleColumns = [self z7d5c8a0f42];
    NSUInteger columnCount = MAX((NSUInteger)1, visibleColumns.count);
    CGFloat colW = _d9q3x5.bounds.size.width / (CGFloat)columnCount;
    for (NSUInteger i = 0; i < visibleColumns.count; i++) {
        Zc1dba0f365 *column = visibleColumns[i];
        column.frame = CGRectMake(colW * i, 0.0, colW, _d9q3x5.bounds.size.height);
        if (i > 0) {
            UIView *line = [_d9q3x5 viewWithTag:8000 + i];
            if (!line) {
                line = [[UIView alloc] initWithFrame:CGRectZero];
                line.tag = 8000 + i;
                line.backgroundColor = ZThemeBorder();
                line.alpha = 0.24;
                [_d9q3x5 addSubview:line];
            }
            line.hidden = NO;
            line.frame = CGRectMake(colW * i, 0.0, 1.0, _d9q3x5.bounds.size.height);
            [_d9q3x5 bringSubviewToFront:line];
        }
    }
    for (NSUInteger i = visibleColumns.count; i < _p7k4n2.count; i++) {
        UIView *line = [_d9q3x5 viewWithTag:8000 + i];
        if (line) line.hidden = YES;
    }

    CGFloat gapLineY = MIN(25.0, MAX(21.0, colW * 0.23));
    UIView *gapLine = [_d9q3x5 viewWithTag:8900];
    if (!gapLine) {
        gapLine = [[UIView alloc] initWithFrame:CGRectZero];
        gapLine.tag = 8900;
        gapLine.backgroundColor = ZThemeBorder();
        gapLine.alpha = 0.36;
        [_d9q3x5 addSubview:gapLine];
    }
    gapLine.frame = CGRectMake(0.0, gapLineY, _d9q3x5.bounds.size.width, 1.0);
    [_d9q3x5 bringSubviewToFront:gapLine];

    CGFloat rowStartY = gapLineY + 2.0;
    CGFloat rowH = 15.5;
    NSInteger maxLines = MIN(ZHistoryVisibleRows, (NSInteger)((_d9q3x5.bounds.size.height - rowStartY) / rowH));
    for (NSInteger r = 1; r <= maxLines; r++) {
        UIView *rowLine = [_d9q3x5 viewWithTag:9000 + r];
        if (!rowLine) {
            rowLine = [[UIView alloc] initWithFrame:CGRectZero];
            rowLine.tag = 9000 + r;
            rowLine.backgroundColor = ZThemeBorder();
            rowLine.alpha = 0.10;
            [_d9q3x5 addSubview:rowLine];
        }
        rowLine.hidden = NO;
        rowLine.frame = CGRectMake(0.0, rowStartY + rowH * r, _d9q3x5.bounds.size.width, 1.0);
        [_d9q3x5 bringSubviewToFront:rowLine];
    }
    for (NSInteger r = maxLines + 1; r <= ZHistoryVisibleRows; r++) {
        UIView *oldLine = [_d9q3x5 viewWithTag:9000 + r];
        if (oldLine) oldLine.hidden = YES;
    }

    _y1m5x9.frame = CGRectMake(w - 24.0, h - 24.0, 24.0, 24.0);
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *superview = self.superview;
    if (!superview) return;

    if (pan.state == UIGestureRecognizerStateBegan) {
        _h9m2d5 = self.frame;
        _x3q8c6 = [pan locationInView:self];
        BOOL inResizeCorner = (_x3q8c6.x >= self.bounds.size.width - 32.0 && _x3q8c6.y >= self.bounds.size.height - 32.0);
        _v4p7k1 = inResizeCorner ? 2 : 1;
        _c8n3q6 = YES;
    }

    if (pan.state == UIGestureRecognizerStateChanged) {
        if (_v4p7k1 == 2) {
            CGPoint p = [pan locationInView:superview];
            CGRect f = _h9m2d5;
            CGFloat minW = Ze25ebfed17;
            CGFloat minH = Zed1192a6d1;
            CGFloat maxW = MIN(superview.bounds.size.width - f.origin.x - 8.0, 340.0);
            CGFloat maxH = MIN(superview.bounds.size.height - f.origin.y - 34.0, 430.0);
            f.size.width = MAX(minW, MIN(maxW, p.x - f.origin.x));
            f.size.height = MAX(minH, MIN(maxH, p.y - f.origin.y));
            self.frame = f;
            [self setNeedsLayout];
        } else if (_v4p7k1 == 1) {
            CGPoint p = [pan locationInView:superview];
            CGRect f = self.frame;
            f.origin.x = p.x - _x3q8c6.x;
            f.origin.y = p.y - _x3q8c6.y;

            CGFloat visible = 24.0;
            f.origin.x = MAX(visible - f.size.width, MIN(superview.bounds.size.width - visible, f.origin.x));
            f.origin.y = MAX(visible - f.size.height, MIN(superview.bounds.size.height - visible, f.origin.y));
            self.frame = f;
        }
    }

    if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled || pan.state == UIGestureRecognizerStateFailed) {
        _v4p7k1 = 0;
        _c8n3q6 = NO;
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setFloat:self.frame.origin.x forKey:OX_NS("hist_x")];
        [ud setFloat:self.frame.origin.y forKey:OX_NS("hist_y")];
        [ud setFloat:self.frame.size.width forKey:OX_NS("hist_w")];
        [ud setFloat:self.frame.size.height forKey:OX_NS("hist_h")];
        [ud synchronize];
        [self setNeedsLayout];
        [self n4q9c1];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    UIView *touched = touch.view;
    if (touched == _closeButton || [touched isDescendantOfView:_closeButton]) return NO;
    if (touched == _k3v9d4 || [touched isDescendantOfView:_k3v9d4]) return NO;
    if (touched == _eyeButton || [touched isDescendantOfView:_eyeButton]) return NO;

    CGPoint p = [touch locationInView:self];
    BOOL inResizeCorner = (p.x >= self.bounds.size.width - 34.0 && p.y >= self.bounds.size.height - 34.0);
    if (inResizeCorner || touched == _y1m5x9 || [touched isDescendantOfView:_y1m5x9]) return YES;

    if (touched == _d9q3x5 || [touched isDescendantOfView:_d9q3x5]) return YES;
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return NO;
}

- (void)n4q9c1 {
    _title.text = Ongnong::Zx8fUILabel(OX_NS("counter_title"), OX_NS("ONGNONG.io.vn"));
    [self setNeedsLayout];
    [self q6v1d9];
    for (Z6dcb301a04 *card in _t6m1v8) {
        card.value.hidden = YES;
        card.hidden = ![self t3p8x4:card.p4x9c3];
    }

    for (Zc1dba0f365 *column in [self z7d5c8a0f42]) {
        int idx = (int)column.p4x9c3;
        NSArray<NSNumber *> *items = Zd282eb67ef(idx);

        NSString *gapText = [NSString stringWithFormat:qsec_s_0074(), zce119e8048.zc9f4191bf8[idx]];
        Z3218ec4b5a(column.y8m2d7, gapText, 11.0, 5.2, UIFontWeightBlack);

        NSInteger maxCount = MIN((NSInteger)items.count, (NSInteger)column.a3v6p8.count);

        for (NSInteger i = 0; i < (NSInteger)column.a3v6p8.count; i++) {
            UILabel *row = column.a3v6p8[i];
            if (i < maxCount) {
                Z3218ec4b5a(row, items[i].stringValue, 11.0, 6.0, UIFontWeightHeavy);
                row.hidden = NO;
            } else {
                Z3218ec4b5a(row, [NSString string], 11.0, 6.0, UIFontWeightHeavy);
                row.hidden = YES;
            }
        }
    }
}
@end

@implementation Z9abcb7bb90

- (CGRect)zClampFrame:(CGRect)frame minW:(CGFloat)minW minH:(CGFloat)minH maxW:(CGFloat)maxW maxH:(CGFloat)maxH {
    CGRect bounds = self.view.bounds.size.width > 0 ? self.view.bounds : UIScreen.mainScreen.bounds;
    frame.size.width = MAX(minW, MIN(maxW, frame.size.width));
    frame.size.height = MAX(minH, MIN(maxH, frame.size.height));
    CGFloat visible = 26.0;
    frame.origin.x = MAX(visible - frame.size.width, MIN(bounds.size.width - visible, frame.origin.x));
    frame.origin.y = MAX(42.0, MIN(bounds.size.height - visible, frame.origin.y));
    return frame;
}

- (void)zSaveQuickPanelFrame {
    if (!_a9q2x4 || _f7q2n8) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if (_a6t3y8) {
        [ud setFloat:_a9q2x4.frame.origin.x forKey:OX_NS("alt_ui_x")];
        [ud setFloat:_a9q2x4.frame.origin.y forKey:OX_NS("alt_ui_y")];
        [ud synchronize];
        return;
    }
    [ud setFloat:_a9q2x4.frame.origin.x forKey:OX_NS("tool_x")];
    [ud setFloat:_a9q2x4.frame.origin.y forKey:OX_NS("tool_y")];
    [ud setFloat:_a9q2x4.frame.size.width forKey:OX_NS("tool_w")];
    [ud setFloat:_a9q2x4.frame.size.height forKey:OX_NS("tool_h")];
    [ud synchronize];
}

- (void)q1c8v4 {
    if (!_a9q2x4) return;
    if (!_f7q2n8) {
        [_a9q2x4 layoutIfNeeded];
        _p4m9c1 = _a9q2x4.frame;
        [self zSaveQuickPanelFrame];
        CGPoint middlePoint = CGPointMake((CGRectGetMaxX(_a9q2x4.c8x1p4.frame) + CGRectGetMinX(_a9q2x4.v6q2m8.frame))/2.0, CGRectGetMidY(_a9q2x4.bounds));
        CGPoint middleCenter = [_a9q2x4 convertPoint:middlePoint toView:self.view];
        CGFloat side = _a9q2x4.a1v8m3 ? 66.0 : MAX(60.0, _a9q2x4.bounds.size.height * 1.45);
        middleCenter.x = MAX(side/2.0, MIN(self.view.bounds.size.width-side/2.0, middleCenter.x));
        middleCenter.y = MAX(42.0+side/2.0, MIN(self.view.bounds.size.height-side/2.0, middleCenter.y));
        _f7q2n8 = YES;
        _a9q2x4.q6m2v8 = YES;
        _a9q2x4.bounds = CGRectMake(0, 0, side, side);
        _a9q2x4.center = middleCenter;
        [_a9q2x4 setNeedsLayout];
        [_a9q2x4 layoutIfNeeded];
        if (_a6t3y8) {
            _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = YES;
            _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = YES;
        }
    } else {
        CGPoint popupCenter = _a9q2x4.center;
        CGRect restored = CGRectIsEmpty(_p4m9c1) ? (_a6t3y8 ? CGRectMake(0, 0, 230.0, 114.0) : CGRectMake(0, 0, 360.0*z067adc83c5(), 66.0*z067adc83c5())) : _p4m9c1;
        _f7q2n8 = NO;
        _a9q2x4.q6m2v8 = NO;
        CGRect sizingFrame = _a9q2x4.frame;
        sizingFrame.size = restored.size;
        _a9q2x4.frame = sizingFrame;
        [_a9q2x4 setNeedsLayout];
        [_a9q2x4 layoutIfNeeded];
        CGPoint middlePoint = CGPointMake((CGRectGetMaxX(_a9q2x4.c8x1p4.frame) + CGRectGetMinX(_a9q2x4.v6q2m8.frame))/2.0, CGRectGetMidY(_a9q2x4.bounds));
        restored.origin.x = popupCenter.x - middlePoint.x;
        restored.origin.y = popupCenter.y - middlePoint.y;
        if (_a6t3y8) {
            restored.origin.x = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - restored.size.width - 4.0), restored.origin.x));
            restored.origin.y = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - restored.size.height - 4.0), restored.origin.y));
        } else {
            restored = [self zClampFrame:restored minW:restored.size.width minH:restored.size.height maxW:restored.size.width maxH:restored.size.height];
        }
        _a9q2x4.frame = restored;
        _p4m9c1 = restored;
        [self zSaveQuickPanelFrame];
        if (_a6t3y8) {
            _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = NO;
            _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = NO;
        }
    }
    [self.view bringSubviewToFront:_a9q2x4];
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)q9d3m6 {
    BOOL allowed = Ongnong::Zx8fBetCycleAllowed();
    BOOL isVIP = Ongnong::Zx8fIsVIP();
    Ongnong::R3ni(allowed);
    Zcb66126fa3 *button = _v2p6k1.a7m1c5.count > 11 ? _v2p6k1.a7m1c5[11] : nil;
    BOOL shouldHide = !allowed && isVIP;
    BOOL layoutChanged = button && button.hidden != shouldHide;
    if (button) {
        button.hidden = shouldHide;
        button.enabled = allowed || !isVIP;
        button.alpha = allowed ? 1.0 : (isVIP ? 0.0 : 0.36);
    }
    if (!allowed && _q72p9m4) _q72p9m4.hidden = YES;
    if (layoutChanged) [_v2p6k1 setNeedsLayout];
}

- (void)zSaveCounterPanelFrame {
    if (!_n7c3m8) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setFloat:_n7c3m8.frame.origin.x forKey:OX_NS("hist_x")];
    [ud setFloat:_n7c3m8.frame.origin.y forKey:OX_NS("hist_y")];
    [ud setFloat:_n7c3m8.frame.size.width forKey:OX_NS("hist_w")];
    [ud setFloat:_n7c3m8.frame.size.height forKey:OX_NS("hist_h")];
    [ud synchronize];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    _zAltFloatButtons = [NSMutableDictionary dictionary];
    if (!Ongnong::AutoBuildModuleIsEnabled() && !Ongnong::AutoBuildModuleIsPending()) Ongnong::AutoBuildModuleSetEnabled(false);
    Ongnong::RaidHammerModuleSetEnabled(false);
    Ongnong::MagicCardsModuleSetEnabled(false);
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:OX_NS("ot_running")];
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:ZThemeVisibleKey()];
    CGFloat s = z067adc83c5();
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat menuW = 214 * s;
    CGFloat menuH = 560 * s;
    if (menuH > screen.size.height - 88 * s) menuH = screen.size.height - 88 * s;
    CGFloat menuX = 6.0 * s;
    CGFloat menuY = MAX(36.0 * s, floor((screen.size.height - menuH) * 0.5));
    _v2p6k1 = [[Za540ef69c7 alloc] initWithFrame:CGRectMake(menuX, menuY, menuW, menuH)];
    _x5m9c2 = _v2p6k1.frame;
    [self.view addSubview:_v2p6k1];

    _b3n7v1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_b3n7v1 setTitle:qsec_s_0038() forState:UIControlStateNormal];
    [_b3n7v1 setTitleColor:RGB(160, 250, 255) forState:UIControlStateNormal];
    _b3n7v1.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(24.0, 15.0) weight:UIFontWeightHeavy];
    _b3n7v1.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_b3n7v1, ZThemeBorder(), 9.0, 1.0);
    [_b3n7v1 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:_b3n7v1];
    [self z3q7d9];

    CGFloat quickW = MIN(screen.size.width - 28.0 * s, 360.0 * s);
    CGFloat quickH = 66 * s;
    _a9q2x4 = [[Z4c5163ab2a alloc] initWithFrame:CGRectMake(0, 0, quickW, quickH)];
    [self.view addSubview:_a9q2x4];
    NSUserDefaults *toolUd = [NSUserDefaults standardUserDefaults];
    if ([toolUd objectForKey:OX_NS("tool_x")]) {
        CGFloat tx = [toolUd floatForKey:OX_NS("tool_x")];
        CGFloat ty = [toolUd floatForKey:OX_NS("tool_y")];
        _a9q2x4.frame = [self zClampFrame:CGRectMake(tx, ty, quickW, quickH) minW:quickW minH:quickH maxW:quickW maxH:quickH];
    } else {
        [self p8c4n2];
    }
    _p4m9c1 = _a9q2x4.frame;
    NSInteger savedSlot = [[NSUserDefaults standardUserDefaults] integerForKey:Z0f21de981b()];
    _z4b51d86a09 = [self z3f0b8e15a2:savedSlot];
    _h1x9c5 = NO;
    _a9q2x4.hidden = NO;
    [self.view bringSubviewToFront:_a9q2x4];

    CGFloat atX = MAX(8.0, MIN(screen.size.width - 166.0 - 8.0, CGRectGetMaxX(_v2p6k1.frame) + 10.0));
    CGFloat atY = MAX(42.0, MIN(screen.size.height - 88.0 - 8.0, CGRectGetMinY(_v2p6k1.frame) + 30.0));
    NSUserDefaults *atUd = [NSUserDefaults standardUserDefaults];
    if ([atUd objectForKey:OX_NS("ot_x")]) atX = [atUd floatForKey:OX_NS("ot_x")];
    if ([atUd objectForKey:OX_NS("ot_y")]) atY = [atUd floatForKey:OX_NS("ot_y")];
    _d2q8n4 = [[Zd4f227a905 alloc] initWithFrame:CGRectMake(atX, atY, 166.0, 88.0)];
    _d2q8n4.hidden = YES;
    [self.view addSubview:_d2q8n4];

    NSUserDefaults *bcUd = [NSUserDefaults standardUserDefaults];
    CGFloat bcX = [bcUd objectForKey:OX_NS("ongnong_bet_cycle_ui_x")] ? [bcUd floatForKey:OX_NS("ongnong_bet_cycle_ui_x")] : MAX(8.0, screen.size.width - 290.0);
    CGFloat bcY = [bcUd objectForKey:OX_NS("ongnong_bet_cycle_ui_y")] ? [bcUd floatForKey:OX_NS("ongnong_bet_cycle_ui_y")] : 42.0;
    _q72p9m4 = [[X4f0a1 alloc] initWithFrame:CGRectMake(bcX, bcY, 330.0, 286.0)];
    _q72p9m4.hidden = YES;
    [self.view addSubview:_q72p9m4];

    CGFloat colorW = 208.0;
    CGFloat colorH = 190.0;
    CGFloat colorX = MAX(8.0, MIN(screen.size.width - colorW - 8.0, CGRectGetMaxX(_v2p6k1.frame) + 10.0));
    CGFloat colorY = MAX(42.0, MIN(screen.size.height - colorH - 8.0, CGRectGetMinY(_v2p6k1.frame) + 160.0));
    NSUserDefaults *colorUd = [NSUserDefaults standardUserDefaults];
    if ([colorUd objectForKey:ZThemePosXKey()]) colorX = [colorUd floatForKey:ZThemePosXKey()];
    if ([colorUd objectForKey:ZThemePosYKey()]) colorY = [colorUd floatForKey:ZThemePosYKey()];
    _w7p3v6 = [[Z8x4c2v7 alloc] initWithFrame:CGRectMake(colorX, colorY, colorW, colorH)];
    _w7p3v6.hidden = ![colorUd boolForKey:ZThemeVisibleKey()];
    [self.view addSubview:_w7p3v6];
    [self r9b4t1];
    [self z8a5c1];

    NSArray<NSString *> *menuKeys = @[OX_NS("update"),OX_NS("buy_vip"),OX_NS("history"),OX_NS("auto_build"),OX_NS("pig_hammer"),OX_NS("magic_cards"),OX_NS("auto_click"),OX_NS("tools"),OX_NS("auto_stop"),OX_NS("menu_color"),OX_NS("auto_expedition"),OX_NS("bet_cycle"),OX_NS("auto_merge"),OX_NS("friend_invite"),OX_NS("potion"),OX_NS("interface")];
    for (NSUInteger i = 0; i < MIN(menuKeys.count, _v2p6k1.a7m1c5.count); i++) {
        UILongPressGestureRecognizer *hold = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(zRenameMenuHold:)];
        hold.minimumPressDuration = 3.0;
        hold.cancelsTouchesInView = YES;
        hold.name = menuKeys[i];
        [_v2p6k1.a7m1c5[i] addGestureRecognizer:hold];
    }
    [_v2p6k1.a7m1c5[0] addTarget:self action:@selector(k7p2m6) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 1) [_v2p6k1.a7m1c5[1] addTarget:self action:@selector(d4u8s0) forControlEvents:UIControlEventTouchUpInside];
    [_v2p6k1.k3v9d4 addTarget:self action:@selector(zShowBuyVipRegionPicker) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 2) [_v2p6k1.a7m1c5[2] addTarget:self action:@selector(l4m8k3) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 3) [_v2p6k1.a7m1c5[3] addTarget:self action:@selector(m8c2r6) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 4) [_v2p6k1.a7m1c5[4] addTarget:self action:@selector(f5n9x1) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 5) [_v2p6k1.a7m1c5[5] addTarget:self action:@selector(a7q3d8) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 6) [_v2p6k1.a7m1c5[6] addTarget:self action:@selector(e9m1p7) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 7) [_v2p6k1.a7m1c5[7] addTarget:self action:@selector(b4x8c3) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 8) [_v2p6k1.a7m1c5[8] addTarget:self action:@selector(t6r2n9) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 9) [_v2p6k1.a7m1c5[9] addTarget:self action:@selector(j3v7q5) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 10) [_v2p6k1.a7m1c5[10] addTarget:self action:@selector(h5p1k8) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 11) [_v2p6k1.a7m1c5[11] addTarget:self action:@selector(v7b2c9) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 12) [_v2p6k1.a7m1c5[12] addTarget:self action:@selector(z6m4a8) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 13) [_v2p6k1.a7m1c5[13] addTarget:self action:@selector(ongFriendModule) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 14) [_v2p6k1.a7m1c5[14] addTarget:self action:@selector(ongPotionModule) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 15) [_v2p6k1.a7m1c5[15] addTarget:self action:@selector(zToggleInterface) forControlEvents:UIControlEventTouchUpInside];
    [_v2p6k1.k3v9d4 addTarget:self action:@selector(x1c7p5) forControlEvents:UIControlEventTouchUpInside];
    [_v2p6k1.r6q2p8 addTarget:self action:@selector(c8x3n6) forControlEvents:UIControlEventTouchUpInside];
    [_b3n7v1 addTarget:self action:@selector(q6d9b2) forControlEvents:UIControlEventTouchUpInside];

    NSString *savedLanguage = [[NSUserDefaults standardUserDefaults] stringForKey:qsec_s_0075()];
    [_v2p6k1 e4p7n1:(savedLanguage.length ? savedLanguage : OngnongUIVaultResolvedLanguageCode())];

    [_a9q2x4.d5q9v3 addTarget:self action:@selector(d8k4m1) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.t2m7k6 addTarget:self action:@selector(y2p6a9) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.c8x1p4 addTarget:self action:@selector(u7c3x8) forControlEvents:UIControlEventTouchUpInside];
    UILongPressGestureRecognizer *speed9LongPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(r2c6m8:)];
    speed9LongPress.minimumPressDuration = 0.45;
    [_a9q2x4.t2m7k6 addGestureRecognizer:speed9LongPress];
    UILongPressGestureRecognizer *speed108LongPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(t7p3v1:)];
    speed108LongPress.minimumPressDuration = 0.45;
    [_a9q2x4.c8x1p4 addGestureRecognizer:speed108LongPress];
    _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = YES;
    _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = YES;
    UITapGestureRecognizer *quickTargetTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(z7ee09a13c4)];
    [_a9q2x4.r3n9d5.c6d9x4 addGestureRecognizer:quickTargetTap];
    UITapGestureRecognizer *quickNumberTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(q1c8v4)];
    [_a9q2x4.r3n9d5.t2m8r5 addGestureRecognizer:quickNumberTap];
    [_a9q2x4.v6q2m8 addTarget:self action:@selector(n5q1r4) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.k4p7c1 addTarget:self action:@selector(g9v2d6) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.q4n8p2 addTarget:self action:@selector(q1c8v4) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.m6q1d8 addTarget:self action:@selector(zAltOpenMenu) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.h3c9v5 addTarget:self action:@selector(l4m8k3) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.g8n2x6 addTarget:self action:@selector(zToggleInterface) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.r4n6d2 addTarget:self action:@selector(x1c7p5) forControlEvents:UIControlEventTouchUpInside];
    _a9q2x4.x2c8m5.userInteractionEnabled = YES;
    _a9q2x4.p9v3k7.userInteractionEnabled = YES;
    UITapGestureRecognizer *altTargetIconTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(zAltTargetCycle)];
    [_a9q2x4.x2c8m5 addGestureRecognizer:altTargetIconTap];
    UITapGestureRecognizer *altTargetHistoryTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(zAltTargetCycle)];
    [_a9q2x4.p9v3k7 addGestureRecognizer:altTargetHistoryTap];

    _c5a8u2 = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 252.0, 174.0)];
    _c5a8u2.backgroundColor = ZThemePanelColor();
    ApplyNeon(_c5a8u2, ZThemeBorder(), 16.0, 1.2);
    _c5a8u2.layer.cornerRadius = 16.0;
    _c5a8u2.hidden = YES;
    NSArray<NSString *> *altTitles = [self zAltMenuTitles];
    NSMutableArray<UIButton *> *altButtons = [NSMutableArray array];
    CGFloat ag = 4.0;
    CGFloat am = 6.0;
    CGFloat arrowRail = 30.0;
    CGFloat contentW = _c5a8u2.bounds.size.width - arrowRail - am * 2.0;
    CGFloat aw = (contentW - ag * 3.0) / 4.0;
    CGFloat ah = 35.0;
    for (NSInteger i = 0; i < (NSInteger)altTitles.count; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        b.exclusiveTouch = YES;
        NSInteger row = i / 4;
        NSInteger col = i % 4;
        b.frame = CGRectMake(am + col * (aw + ag), 6.0 + row * (ah + ag), aw, ah);
        [b setTitle:altTitles[i] forState:UIControlStateNormal];
        [b setAttributedTitle:nil forState:UIControlStateNormal];
        [self zApplyAltButtonStyle:b index:i];
        ApplyNeon(b, ZThemeBorder(), 8.0, 0.9);
        [b addTarget:self action:@selector(zAltGridTap:) forControlEvents:UIControlEventTouchUpInside];
        [_c5a8u2 addSubview:b];
        [altButtons addObject:b];
    }
    _s4k7e1 = altButtons;
    _w6j2r9 = [UIButton buttonWithType:UIButtonTypeCustom];
    _w6j2r9.frame = CGRectMake(_c5a8u2.bounds.size.width - 27.0, 6.0, 23.0, _c5a8u2.bounds.size.height - 12.0);
    [_w6j2r9 setTitle:OX_NS("‹") forState:UIControlStateNormal];
    [_w6j2r9 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _w6j2r9.titleLabel.font = [UIFont systemFontOfSize:21.0 weight:UIFontWeightBlack];
    _w6j2r9.backgroundColor = ZThemeActiveGreen();
    ApplyNeon(_w6j2r9, ZThemeBorder(), 12.0, 1.0);
    [_w6j2r9 addTarget:self action:@selector(zAltCloseMenu) forControlEvents:UIControlEventTouchUpInside];
    [_c5a8u2 addSubview:_w6j2r9];
    UIPanGestureRecognizer *altGridPan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(zAltGridPan:)];
    altGridPan.minimumNumberOfTouches = 1;
    altGridPan.maximumNumberOfTouches = 1;
    altGridPan.cancelsTouchesInView = YES;
    [_c5a8u2 addGestureRecognizer:altGridPan];
    [self.view addSubview:_c5a8u2];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(c2m6r4) name:Z973e694cc8 object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(a5v1x8:) name:qsec_s_0062() object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(g5x9q4:) name:ZThemeNotify() object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(b6x4j9:) name:Ongnong::R7f404() object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(n8q4m2:) name:OX_NS("om_auto_merge_state_changed") object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(zServerMenuLabelsChanged:) name:OX_NS("ongnong_menu_labels_changed") object:nil];

    Z9abcb7bb90 *controllerForHistory = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(7.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!controllerForHistory || !controllerForHistory.view.window) return;
        if (!Ongnong::Zx8fCounterAllowed()) return;
        [controllerForHistory h2p7m9];
        controllerForHistory.n7c3m8.hidden = NO;
        [controllerForHistory.n7c3m8 n4q9c1];
        [controllerForHistory.view bringSubviewToFront:controllerForHistory.n7c3m8];
        [controllerForHistory q7m2d8];
    });

    _a6t3y8 = [[NSUserDefaults standardUserDefaults] boolForKey:OX_NS("om_layout_alt")];
    _d7u4i1 = NO;
    [self zApplyInterface];
    [self g5x9q4:nil];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.2 target:self selector:@selector(tick) userInfo:nil repeats:YES];
    _timer.tolerance = 0.35;
    [self q7m2d8];
    [self d2x8q4];
}



- (BOOL)zAltFeatureAllowedForTag:(NSInteger)tag {
    switch (tag) {
        case 0: return YES;
        case 1: return YES;
        case 2: return Ongnong::Zx8fCounterAllowed();
        case 3: return Ongnong::Zx8fAutoBuildAllowed();
        case 4: return Ongnong::Zx8fRaidHammerAllowed();
        case 5: return Ongnong::Zx8fMagicCardsAllowed();
        case 6: return Ongnong::Zx8fAutoClickAllowed();
        case 7: return Ongnong::Zx8fAutoStopAllowed();
        case 8: return Ongnong::Zx8fMenuColorAllowed();
        case 9: return Ongnong::R7f401();
        case 10: return Ongnong::Zx8fBetCycleAllowed();
        case 11: return Ongnong::Zx8fAutoMergeAllowed();
        case 12: return Ongnong::Zx8fFriendInviteAllowed();
        case 13: return Ongnong::Zx8fPotionAllowed();
        case 14: return YES;
        case 15: return YES;
        default: return YES;
    }
}

- (BOOL)zAltVipLockedForTag:(NSInteger)tag {
    if (Ongnong::Zx8fIsVIP()) return NO;
    return ![self zAltFeatureAllowedForTag:tag];
}

- (void)zShowAltVipRequiredOnButton:(UIButton *)button {
    if (!button) return;
    NSString *message = ZuiPick5(OX_NS("CẦN NÂNG CẤP VIP"), OX_NS("需要升级 VIP"), OX_NS("ต้องอัปเกรด VIP"), OX_NS("PASSA A VIP"), OX_NS("VIP UPGRADE REQUIRED"));
    NSInteger marker = 92831;
    UILabel *existing = [button viewWithTag:marker];
    [existing removeFromSuperview];
    UILabel *label = [[UILabel alloc] initWithFrame:button.bounds];
    label.tag = marker;
    label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    label.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.96];
    label.text = message;
    label.textColor = RGB(238, 22, 22);
    label.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightBlack];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 2;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.68;
    label.layer.cornerRadius = 8.0;
    label.layer.masksToBounds = YES;
    label.layer.borderWidth = 1.1;
    label.layer.borderColor = RGB(255, 65, 65).CGColor;
    label.userInteractionEnabled = NO;
    [button addSubview:label];
    [button bringSubviewToFront:label];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (label.superview == button) [label removeFromSuperview];
    });

    NSInteger flyMarker = 92832;
    UIView *oldFly = [self.view viewWithTag:flyMarker];
    [oldFly removeFromSuperview];
    CGRect buttonRect = [button convertRect:button.bounds toView:self.view];
    CGFloat flyW = MIN(230.0, MAX(170.0, self.view.bounds.size.width - 24.0));
    CGFloat flyH = 38.0;
    CGFloat flyX = MIN(MAX(12.0, CGRectGetMidX(buttonRect) - flyW * 0.5), MAX(12.0, self.view.bounds.size.width - flyW - 12.0));
    CGFloat flyY = MAX(50.0, CGRectGetMinY(buttonRect) - 8.0);
    UILabel *fly = [[UILabel alloc] initWithFrame:CGRectMake(flyX, flyY, flyW, flyH)];
    fly.tag = flyMarker;
    fly.text = message;
    fly.textColor = RGB(210, 0, 0);
    fly.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightBlack];
    fly.textAlignment = NSTextAlignmentCenter;
    fly.adjustsFontSizeToFitWidth = YES;
    fly.minimumScaleFactor = 0.72;
    fly.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.92];
    fly.layer.cornerRadius = 10.0;
    fly.layer.masksToBounds = NO;
    fly.layer.borderWidth = 1.2;
    fly.layer.borderColor = RGB(235, 35, 35).CGColor;
    fly.layer.shadowColor = [UIColor blackColor].CGColor;
    fly.layer.shadowOpacity = 0.55;
    fly.layer.shadowRadius = 6.0;
    fly.layer.shadowOffset = CGSizeMake(0.0, 2.0);
    fly.userInteractionEnabled = NO;
    fly.alpha = 0.0;
    fly.transform = CGAffineTransformMakeScale(0.88, 0.88);
    [self.view addSubview:fly];
    [self.view bringSubviewToFront:fly];
    [UIView animateWithDuration:0.18 animations:^{
        fly.alpha = 1.0;
        fly.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:2.82 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            fly.frame = CGRectOffset(fly.frame, 0.0, -64.0);
            fly.alpha = 0.0;
            fly.transform = CGAffineTransformMakeScale(1.08, 1.08);
        } completion:^(BOOL finished2) {
            [fly removeFromSuperview];
        }];
    }];
}

- (void)zShowMainVipRequiredAtIndex:(NSInteger)index {
    if (Ongnong::Zx8fIsVIP()) return;
    if (index < 0 || index >= (NSInteger)_v2p6k1.a7m1c5.count) return;
    UIButton *button = _v2p6k1.a7m1c5[index];
    [self zShowAltVipRequiredOnButton:button];
}

- (void)zApplyAltLanguageButtonTitle:(UIButton *)button {
    if (!button) return;
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = NSTextAlignmentCenter;
    style.lineSpacing = 0.0;
    NSDictionary *smallAttrs = @{
        NSFontAttributeName:[UIFont systemFontOfSize:7.5 weight:UIFontWeightHeavy],
        NSForegroundColorAttributeName:[UIColor colorWithWhite:0.90 alpha:0.95],
        NSParagraphStyleAttributeName:style
    };
    NSDictionary *bigAttrs = @{
        NSFontAttributeName:[UIFont systemFontOfSize:10.0 weight:UIFontWeightBlack],
        NSForegroundColorAttributeName:ZThemeWhite(),
        NSParagraphStyleAttributeName:style
    };
    NSMutableAttributedString *value = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:OX_NS("%@\n"), ZAltLanguageHeaderText()] attributes:smallAttrs];
    [value appendAttributedString:[[NSAttributedString alloc] initWithString:ZAltLanguageText() attributes:bigAttrs]];
    [button setAttributedTitle:value forState:UIControlStateNormal];
    button.titleLabel.numberOfLines = 2;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.titleLabel.adjustsFontSizeToFitWidth = NO;
}

- (void)zApplyAltButtonStyle:(UIButton *)button index:(NSInteger)index {
    if (!button) return;
    [button setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:10.0 weight:UIFontWeightBlack];
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    button.titleLabel.minimumScaleFactor = 0.55;
    button.titleLabel.numberOfLines = 1;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.backgroundColor = ZThemeButtonOff();
    if (index == 0) {
        button.backgroundColor = [RGB(205, 28, 28) colorWithAlphaComponent:0.90];
    } else if (index == 1) {
        button.backgroundColor = [RGB(203, 148, 20) colorWithAlphaComponent:0.93];
    } else if (index == 14) {
        [self zApplyAltLanguageButtonTitle:button];
    }
    BOOL vipLocked = [self zAltVipLockedForTag:index];
    button.alpha = vipLocked ? 0.36 : 1.0;
    button.enabled = YES;
}

- (NSArray<NSString *> *)zAltMenuTitles {
    return @[
        ZuiPick5(OX_NS("CẬP NHẬT"), OX_NS("更新"), OX_NS("อัปเดต"), OX_NS("AGGIORNA"), OX_NS("UPDATE")),
        Ongnong::Zx8fIsVIP() ? OX_NS("VIP") : OngnongUIVaultText(OngnongUIVaultFreeBuyVipAction),
        ZuiPick5(OX_NS("LỊCH SỬ"), OX_NS("历史"), OX_NS("ประวัติ"), OX_NS("STORIA"), OX_NS("HISTORY")),
        ZuiPick5(OX_NS("XÂY"), OX_NS("建造"), OX_NS("สร้าง"), OX_NS("COSTRUISCI"), OX_NS("BUILD")),
        ZuiPick5(OX_NS("HEO/BÚA"), OX_NS("猪/锤"), OX_NS("หมู/ค้อน"), OX_NS("MAIALE/MART."), OX_NS("PIG/HAMMER")),
        ZuiPick5(OX_NS("THẺ"), OX_NS("卡牌"), OX_NS("การ์ด"), OX_NS("CARTE"), OX_NS("CARDS")),
        ZuiPick5(OX_NS("TỰ NHẤP"), OX_NS("自动点击"), OX_NS("คลิกอัตโนมัติ"), OX_NS("AUTO CLICK"), OX_NS("AUTO CLICK")),
        ZuiPick5(OX_NS("MỤC TIÊU"), OX_NS("目标"), OX_NS("เป้าหมาย"), OX_NS("OBIETTIVO"), OX_NS("TARGET")),
        ZuiPick5(OX_NS("MÀU"), OX_NS("颜色"), OX_NS("สี"), OX_NS("COLORE"), OX_NS("COLOR")),
        ZuiPick5(OX_NS("RỪNG"), OX_NS("森林"), OX_NS("ป่า"), OX_NS("FORESTA"), OX_NS("FOREST")),
        OX_NS("XBET"),
        ZuiPick5(OX_NS("GHÉP"), OX_NS("合并"), OX_NS("รวม"), OX_NS("UNISCI"), OX_NS("MERGE")),
        ZuiPick5(OX_NS("BẠN BÈ"), OX_NS("好友"), OX_NS("เพื่อน"), OX_NS("AMICI"), OX_NS("FRIENDS")),
        ZuiPick5(OX_NS("THUỐC"), OX_NS("药水"), OX_NS("ยา"), OX_NS("POZIONE"), OX_NS("POTION")),
        ZAltLanguageText(),
        ZuiPick5(OX_NS("ĐỔI UI"), OX_NS("切换UI"), OX_NS("เปลี่ยน UI"), OX_NS("CAMBIA UI"), OX_NS("SWITCH UI"))
    ];
}

- (void)zRefreshAltMenuTitles {
    NSArray<NSString *> *titles = [self zAltMenuTitles];
    NSUInteger count = MIN(_s4k7e1.count, titles.count);
    for (NSUInteger i = 0; i < count; i++) {
        UIButton *button = _s4k7e1[i];
        [button setAttributedTitle:nil forState:UIControlStateNormal];
        [button setTitle:titles[i] forState:UIControlStateNormal];
        [self zApplyAltButtonStyle:button index:i];
    }
    if (_a9q2x4) {
        [_a9q2x4.m6q1d8 setTitle:ZuiPick5(OX_NS("MENU"), OX_NS("菜单"), OX_NS("เมนู"), OX_NS("MENU"), OX_NS("MENU")) forState:UIControlStateNormal];
        [_a9q2x4.h3c9v5 setTitle:ZuiServerPick5(OX_NS("history"), OX_NS("LỊCH SỬ"), OX_NS("历史"), OX_NS("ประวัติ"), OX_NS("STORIA"), OX_NS("HISTORY")) forState:UIControlStateNormal];
    }
}

- (void)zApplyInterface {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if (_f7q2n8) {
        _f7q2n8 = NO;
        _a9q2x4.q6m2v8 = NO;
    }
    if (_a6t3y8) {
        _v2p6k1.hidden = YES;
        _b3n7v1.hidden = YES;
        _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = NO;
        _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = NO;
        [_a9q2x4 setA1v8m3:YES];
        CGFloat qw = 230.0;
        CGFloat qh = 114.0;
        CGFloat maxX = MAX(4.0, self.view.bounds.size.width - qw - 4.0);
        CGFloat maxY = MAX(44.0, self.view.bounds.size.height - qh - 4.0);
        CGFloat x = [ud objectForKey:OX_NS("alt_ui_x")] ? [ud floatForKey:OX_NS("alt_ui_x")] : MAX(4.0, (self.view.bounds.size.width - qw) * 0.5);
        CGFloat y = [ud objectForKey:OX_NS("alt_ui_y")] ? [ud floatForKey:OX_NS("alt_ui_y")] : MAX(48.0, self.view.bounds.size.height * 0.34);
        x = MAX(4.0, MIN(maxX, x));
        y = MAX(44.0, MIN(maxY, y));
        _a9q2x4.frame = CGRectMake(x, y, qw, qh);
        _p4m9c1 = _a9q2x4.frame;
        _a9q2x4.hidden = _d7u4i1;
        _c5a8u2.hidden = !_d7u4i1;
        if (_d7u4i1) {
            CGRect gf = _c5a8u2.frame;
            CGFloat gx = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - gf.size.width - 4.0), gf.origin.x));
            CGFloat gy = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - gf.size.height - 4.0), gf.origin.y));
            gf.origin = CGPointMake(gx, gy);
            _c5a8u2.frame = gf;
            [self.view bringSubviewToFront:_c5a8u2];
        } else {
            [self.view bringSubviewToFront:_a9q2x4];
        }
    } else {
        _d7u4i1 = NO;
        _c5a8u2.hidden = YES;
        _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = YES;
        _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = YES;
        [_a9q2x4 setA1v8m3:NO];
        CGFloat s = z067adc83c5();
        CGFloat qw = MIN(self.view.bounds.size.width - 28.0 * s, 360.0 * s);
        CGFloat qh = 66.0 * s;
        if ([ud objectForKey:OX_NS("tool_x")]) {
            _a9q2x4.frame = [self zClampFrame:CGRectMake([ud floatForKey:OX_NS("tool_x")], [ud floatForKey:OX_NS("tool_y")], qw, qh) minW:qw minH:qh maxW:qw maxH:qh];
        } else {
            _a9q2x4.frame = CGRectMake((self.view.bounds.size.width - qw) * 0.5, MAX(42.0, self.view.bounds.size.height - qh - 28.0), qw, qh);
        }
        _p4m9c1 = _a9q2x4.frame;
        _a9q2x4.hidden = NO;
        _v2p6k1.hidden = NO;
        _b3n7v1.hidden = NO;
        [self.view bringSubviewToFront:_a9q2x4];
    }
    [_a9q2x4 setNeedsLayout];
    [_a9q2x4 layoutIfNeeded];
}

- (void)zToggleInterface {
    if (_a6t3y8 && !_d7u4i1 && !_f7q2n8) {
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setFloat:_a9q2x4.frame.origin.x forKey:OX_NS("alt_ui_x")];
        [ud setFloat:_a9q2x4.frame.origin.y forKey:OX_NS("alt_ui_y")];
    }
    _d7u4i1 = NO;
    _c5a8u2.hidden = YES;
    if (_f7q2n8) {
        _f7q2n8 = NO;
        _a9q2x4.q6m2v8 = NO;
    }
    _a6t3y8 = !_a6t3y8;
    [[NSUserDefaults standardUserDefaults] setBool:_a6t3y8 forKey:OX_NS("om_layout_alt")];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self zApplyInterface];
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)zAltOpenMenu {
    if (!_a6t3y8 || !_c5a8u2) return;
    if (_f7q2n8) [self q1c8v4];
    _d7u4i1 = YES;
    [self zRefreshAltMenuTitles];
    CGRect f = _c5a8u2.frame;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if ([ud objectForKey:OX_NS("alt_menu_x")] && [ud objectForKey:OX_NS("alt_menu_y")]) {
        f.origin.x = [ud floatForKey:OX_NS("alt_menu_x")];
        f.origin.y = [ud floatForKey:OX_NS("alt_menu_y")];
    } else {
        f.origin.x = _a9q2x4.frame.origin.x;
        f.origin.y = _a9q2x4.frame.origin.y;
    }
    f.origin.x = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - f.size.width - 4.0), f.origin.x));
    f.origin.y = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - f.size.height - 4.0), f.origin.y));
    _c5a8u2.frame = f;
    _a9q2x4.hidden = YES;
    _c5a8u2.hidden = NO;
    [self.view bringSubviewToFront:_c5a8u2];
    Z0418c1e0ae();
}

- (void)zAltCloseMenu {
    if (!_a6t3y8) return;
    _d7u4i1 = NO;
    CGRect q = _a9q2x4.frame;
    q.origin = _c5a8u2.frame.origin;
    q.origin.x = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - q.size.width - 4.0), q.origin.x));
    q.origin.y = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - q.size.height - 4.0), q.origin.y));
    _a9q2x4.frame = q;
    _p4m9c1 = q;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setFloat:q.origin.x forKey:OX_NS("alt_ui_x")];
    [ud setFloat:q.origin.y forKey:OX_NS("alt_ui_y")];
    [ud synchronize];
    _c5a8u2.hidden = YES;
    _a9q2x4.hidden = NO;
    [self.view bringSubviewToFront:_a9q2x4];
    [self e7k3p9];
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)zAltShowShortcut:(NSInteger)tag {
    if (tag < 0 || tag >= 15) return;
    if (tag == 3 || tag == 4 || tag == 5 || tag == 9 || tag == 11) return;
    NSNumber *key = @(tag);
    UIButton *popup = self.zAltFloatButtons[key];
    NSArray<NSString *> *titles = [self zAltMenuTitles];
    NSString *title = (tag < (NSInteger)titles.count) ? titles[tag] : OX_NS("MENU");
    if (!popup) {
        CGFloat w = 132.0, h = 38.0;
        CGFloat x = MAX(8.0, self.view.bounds.size.width - w - 14.0);
        CGFloat y = 50.0 + (CGFloat)((tag % 6) * 46);
        y = MIN(MAX(42.0, y), self.view.bounds.size.height - h - 8.0);
        popup = [UIButton buttonWithType:UIButtonTypeCustom];
        popup.frame = CGRectMake(x, y, w, h);
        popup.tag = 6000 + tag;
        popup.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightHeavy];
        popup.titleLabel.adjustsFontSizeToFitWidth = YES;
        popup.titleLabel.minimumScaleFactor = 0.55;
        popup.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
        popup.layer.cornerRadius = 12.0;
        popup.layer.masksToBounds = NO;
        [popup setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
        [popup addTarget:self action:@selector(zAltShortcutTap:) forControlEvents:UIControlEventTouchUpInside];
        [popup addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(zAltShortcutPan:)];
        [popup addGestureRecognizer:pan];
        UIButton *close = [UIButton buttonWithType:UIButtonTypeCustom];
        close.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
        close.tag = 7000 + tag;
        [close setTitle:OX_NS("×") forState:UIControlStateNormal];
        [close setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
        close.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
        close.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
        close.layer.cornerRadius = 9.0;
        close.layer.borderWidth = 0.7;
        close.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
        [close addTarget:self action:@selector(zAltShortcutClose:) forControlEvents:UIControlEventTouchUpInside];
        [popup addSubview:close];
        self.zAltFloatButtons[key] = popup;
        [self.view addSubview:popup];
    }
    [popup setTitle:title forState:UIControlStateNormal];
    UIColor *color = ZThemeOnGreen();
    popup.backgroundColor = [color colorWithAlphaComponent:0.90];
    popup.layer.borderWidth = 1.1;
    popup.layer.borderColor = color.CGColor;
    popup.layer.shadowColor = color.CGColor;
    popup.layer.shadowOpacity = 0.45;
    popup.layer.shadowRadius = 8.0;
    popup.layer.shadowOffset = CGSizeZero;
    popup.hidden = NO;
    [self.view bringSubviewToFront:popup];
}

- (void)zAltShortcutTap:(UIButton *)sender {
    NSInteger tag = sender.tag - 6000;
    switch (tag) {
        case 0: [self k7p2m6]; break;
        case 1: [self d4u8s0]; break;
        case 2: [self l4m8k3]; break;
        case 6: [self e9m1p7]; break;
        case 7: [self t6r2n9]; break;
        case 8: [self j3v7q5]; break;
        case 10: [self v7b2c9]; break;
        case 12: [self ongFriendModule]; break;
        case 13: [self ongPotionModule]; break;
        case 14: [self c8x3n6]; break;
        default: break;
    }
}

- (void)zAltShortcutClose:(UIButton *)sender {
    NSInteger tag = sender.tag - 7000;
    UIButton *popup = self.zAltFloatButtons[@(tag)];
    if (popup) popup.hidden = YES;
}

- (void)zAltShortcutPan:(UIPanGestureRecognizer *)pan {
    UIView *popup = pan.view;
    UIView *sv = popup.superview;
    if (!popup || !sv) return;
    static CGPoint startCenter;
    if (pan.state == UIGestureRecognizerStateBegan) startCenter = popup.center;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint t = [pan translationInView:sv];
        CGPoint c = CGPointMake(startCenter.x + t.x, startCenter.y + t.y);
        CGFloat hw = popup.bounds.size.width * 0.5;
        CGFloat hh = popup.bounds.size.height * 0.5;
        c.x = MAX(hw + 8.0, MIN(sv.bounds.size.width - hw - 8.0, c.x));
        c.y = MAX(hh + 42.0, MIN(sv.bounds.size.height - hh - 8.0, c.y));
        popup.center = c;
    }
}

- (void)zMagicPopupClose {
    Ongnong::MagicCardsModuleSetEnabled(false);
    _r8m2d5 = NO;
    if (_u1x7p4) _u1x7p4.hidden = YES;
    [self h6d2q8];
    [self q7m2d8];
}

- (void)zForestPopupClose {
    Ongnong::ExpeditionAutoSetEnabled(false);
    _m3k9a2 = NO;
    if (_q8z1u4) _q8z1u4.hidden = YES;
    [self q2n9v6];
    [self q7m2d8];
}

- (void)zMergePopupClose {
    Ongnong::AutoMergeModuleSetEnabled(false);
    self.p7x3n6 = NO;
    if (self.k2m8v4) self.k2m8v4.hidden = YES;
    [self c3n7x5];
    [self q7m2d8];
}

- (void)zAltGridTap:(UIButton *)sender {
    if (_zAltGridDragging) return;
    NSInteger tag = sender.tag;
    if ([self zAltVipLockedForTag:tag]) {
        [self zShowAltVipRequiredOnButton:sender];
        Z0418c1e0ae();
        return;
    }
    if (tag == 15) {
        [self zToggleInterface];
        return;
    }
    [self zAltCloseMenu];
    switch (tag) {
        case 0: [self k7p2m6]; break;
        case 1: [self d4u8s0]; break;
        case 2: [self l4m8k3]; break;
        case 3: [self m8c2r6]; break;
        case 4: [self f5n9x1]; break;
        case 5: [self a7q3d8]; break;
        case 6: [self e9m1p7]; break;
        case 7: [self t6r2n9]; break;
        case 8: [self j3v7q5]; break;
        case 9: [self h5p1k8]; break;
        case 10: [self v7b2c9]; break;
        case 11: [self z6m4a8]; break;
        case 12: [self ongFriendModule]; break;
        case 13: [self ongPotionModule]; break;
        case 14: [self c8x3n6]; break;
        default: break;
    }
}

- (void)zAltGridPan:(UIPanGestureRecognizer *)pan {
    if (!_c5a8u2 || !_c5a8u2.superview) return;
    UIView *sv = _c5a8u2.superview;
    if (pan.state == UIGestureRecognizerStateBegan) {
        _f2o9p5 = _c5a8u2.center;
        _zAltGridDragging = NO;
    }
    CGPoint t = [pan translationInView:sv];
    if (!_zAltGridDragging && hypot(t.x, t.y) >= 7.0) _zAltGridDragging = YES;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        CGPoint c = CGPointMake(_f2o9p5.x + t.x, _f2o9p5.y + t.y);
        CGFloat hw = _c5a8u2.bounds.size.width * 0.5;
        CGFloat hh = _c5a8u2.bounds.size.height * 0.5;
        c.x = MAX(hw + 2.0, MIN(sv.bounds.size.width - hw - 2.0, c.x));
        c.y = MAX(42.0 + hh, MIN(sv.bounds.size.height - hh - 2.0, c.y));
        _c5a8u2.center = c;
        if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_c5a8u2.frame.origin.x forKey:OX_NS("alt_menu_x")];
            [ud setFloat:_c5a8u2.frame.origin.y forKey:OX_NS("alt_menu_y")];
            [ud synchronize];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.16 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.zAltGridDragging = NO;
            });
        }
    }
}

- (void)h2p7m9 {
    if (_n7c3m8) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat panelW = Ze25ebfed17;
    CGFloat panelH = Zed1192a6d1;
    CGFloat panelX = MAX(8.0, MIN(screen.size.width - panelW - 8.0, 50.0));
    CGFloat panelY = MAX(48.0, MIN(screen.size.height - panelH - 8.0, 100.0));
    NSUserDefaults *histUd = [NSUserDefaults standardUserDefaults];
    if ([histUd objectForKey:OX_NS("hist_x")]) {
        panelX = [histUd floatForKey:OX_NS("hist_x")];
        panelY = [histUd floatForKey:OX_NS("hist_y")];
        if ([histUd objectForKey:OX_NS("hist_w")]) panelW = [histUd floatForKey:OX_NS("hist_w")];
        if ([histUd objectForKey:OX_NS("hist_h")]) panelH = [histUd floatForKey:OX_NS("hist_h")];
    }
    CGRect panelFrame = [self zClampFrame:CGRectMake(panelX, panelY, panelW, panelH) minW:Ze25ebfed17 minH:Zed1192a6d1 maxW:340.0 maxH:430.0];
    _n7c3m8 = [[Z1c94f803b6 alloc] initWithFrame:panelFrame];
    _n7c3m8.hidden = YES;
    [_n7c3m8.closeButton addTarget:self action:@selector(l4m8k3) forControlEvents:UIControlEventTouchUpInside];
    [_n7c3m8.k3v9d4 addTarget:self action:@selector(x1c7p5) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_n7c3m8];
    [self g5x9q4:nil];
}

- (UIImage *)z0b9c95dabc:(int)idx {
    if (idx == Z2f0c1a9d77) return Z67b9f0c2a1();
    if (idx == Z87f6d0c11d) return Zc83f0d7b42();
    if (idx == Z5d92a7e4c1) return Z71a4c9e2d6();
    if (idx == Z700020a485) return Z0da1985399(qsec_s_0021());
    if (idx == Z124338f2d8) return Z0da1985399(qsec_s_0023());
    if (idx == Z94881eb8d3) return Z0da1985399(qsec_s_0025());
    if (idx == Z646dcbe562) return Z0da1985399(qsec_s_0027());
    return nil;
}

- (NSInteger)z3f0b8e15a2:(NSInteger)slot {
    NSArray<NSNumber *> *targets = Ongnong::Z76e4c1b909();
    if (targets.count <= 0) return 0;
    if (slot < 0 || slot >= (NSInteger)targets.count) return 0;
    return slot;
}

- (void)e7k3p9 {
    if (!_a9q2x4.r3n9d5) return;
    _z4b51d86a09 = [self z3f0b8e15a2:_z4b51d86a09];
    int idx = Ongnong::Z76d01f2a88(_z4b51d86a09);
    int countValue = (idx >= 0 && idx < Za94c0d401a) ? zce119e8048.zc9f4191bf8[idx] : 0;
    NSString *v = [NSString stringWithFormat:qsec_s_0074(), countValue];
    if (![_a9q2x4.r3n9d5.t2m8r5.text isEqualToString:v]) {
        _a9q2x4.r3n9d5.t2m8r5.text = v;
    }
    UIImage *img = [self z0b9c95dabc:idx];
    if (_a9q2x4.r3n9d5.c6d9x4.image != img) {
        _a9q2x4.r3n9d5.c6d9x4.image = img;
    }
    _a9q2x4.r3n9d5.t2m8r5.textColor = Z07aec8e446(idx);
    if (_a9q2x4.a1v8m3) {
        _a9q2x4.x2c8m5.image = img;
        NSArray<NSNumber *> *items = Zd282eb67ef(idx);
        NSMutableArray<NSString *> *parts = [NSMutableArray array];
        NSInteger limit = MIN((NSInteger)4, (NSInteger)items.count);
        for (NSInteger i = 0; i < limit; i++) [parts addObject:items[i].stringValue];
        _a9q2x4.p9v3k7.text = parts.count ? [parts componentsJoinedByString:OX_NS(", ")] : OX_NS("-");
        _a9q2x4.p9v3k7.textColor = ZThemeWhite();
    }
}

- (void)z7ee09a13c4 {
    if (_a6t3y8 && !_f7q2n8) return;
    NSArray<NSNumber *> *targets = Ongnong::Z76e4c1b909();
    if (targets.count <= 0) return;
    _z4b51d86a09 = (_z4b51d86a09 + 1) % targets.count;
    [[NSUserDefaults standardUserDefaults] setInteger:_z4b51d86a09 forKey:Z0f21de981b()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    Z0418c1e0ae();
    [self e7k3p9];
    [self d2x8q4];
}

- (void)zAltTargetCycle {
    if (!_a6t3y8 || _d7u4i1) return;
    NSArray<NSNumber *> *targets = Ongnong::Z76e4c1b909();
    if (targets.count <= 0) return;
    _z4b51d86a09 = (_z4b51d86a09 + 1) % targets.count;
    [[NSUserDefaults standardUserDefaults] setInteger:_z4b51d86a09 forKey:Z0f21de981b()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    Z0418c1e0ae();
    [self e7k3p9];
    [self q7m2d8];
}

- (void)h9r3v7 {
    if (_d8r4q7) {
        [_d8r4q7 invalidate];
        _d8r4q7 = nil;
    }
}

- (void)d2x8q4 {
    [self h9r3v7];
    if (_collapsed || !_v2p6k1 || _v2p6k1.hidden) return;
    _d8r4q7 = [NSTimer scheduledTimerWithTimeInterval:12.0
                                                          target:self
                                                        selector:@selector(m1b6k5)
                                                        userInfo:nil
                                                         repeats:NO];
}

- (void)m1b6k5 {
    _d8r4q7 = nil;
    if (_collapsed || !_v2p6k1 || !_b3n7v1) return;

    _x5m9c2 = _v2p6k1.frame;
    CGRect z7fa19172fd = _v2p6k1.frame;
    z7fa19172fd.origin.x = -z7fa19172fd.size.width;
    CGRect handleTarget = [self collapseHandleFrameForMenuFrame:z7fa19172fd collapsed:YES];

    _collapsed = YES;
    [_b3n7v1 setTitle:qsec_s_0081() forState:UIControlStateNormal];
    _v2p6k1.transform = CGAffineTransformIdentity;
    _v2p6k1.frame = z7fa19172fd;
    _b3n7v1.frame = handleTarget;
}

- (void)p8c4n2 {
    CGFloat s = z067adc83c5();
    CGRect screen = self.view.bounds;
    CGFloat quickW = 360 * s;
    CGFloat quickH = 66 * s;
    CGFloat rightX = CGRectGetMaxX(_v2p6k1.frame) + 14 * s;
    CGFloat rightSpace = screen.size.width - rightX - 8 * s;
    if (rightSpace >= quickW) {
        _a9q2x4.frame = CGRectMake(rightX, _v2p6k1.frame.origin.y + 210 * s, quickW, quickH);
    } else {
        quickW = MIN(screen.size.width - 28 * s, 360 * s);
        CGFloat x = 14 * s;
        CGFloat y = CGRectGetMaxY(_v2p6k1.frame) + 10 * s;
        if (y + quickH > screen.size.height - 18 * s) {
            y = screen.size.height - quickH - 18 * s;
        }
        _a9q2x4.frame = CGRectMake(x, y, quickW, quickH);
    }
}

- (CGRect)collapseHandleFrameForMenuFrame:(CGRect)menuFrame collapsed:(BOOL)isCollapsed {
    CGFloat s = z067adc83c5();
    CGFloat handleW = 30.0 * s;
    CGFloat handleH = 68.0 * s;
    CGFloat x = isCollapsed ? 0.0 : CGRectGetMaxX(menuFrame) - 1.0;
    CGFloat y = menuFrame.origin.y + menuFrame.size.height * 0.40;
    CGFloat maxY = self.view.bounds.size.height - handleH - 4.0;
    y = MAX(4.0, MIN(maxY, y));
    return CGRectMake(x, y, handleW, handleH);
}

- (void)z3q7d9 {
    _b3n7v1.frame = [self collapseHandleFrameForMenuFrame:_v2p6k1.frame collapsed:_collapsed];
}

- (void)a5v1x8:(NSNotification *)note {
    if (!_collapsed) {
        CGRect fixed = _v2p6k1.frame;
        fixed.origin.x = 6.0 * z067adc83c5();
        _x5m9c2 = fixed;
        [self z3q7d9];
        [self d2x8q4];
    }
}

- (void)zRenameMenuHold:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan || !Ongnong::Zx8fAllowed()) return;
    NSString *key = gesture.name;
    if (key.length == 0) return;
    UIButton *button = (UIButton *)gesture.view;
    NSString *oldName = Ongnong::Zx8fMenuLabelVI(key, [button titleForState:UIControlStateNormal] ?: OX_NS(""));
    UIAlertController *dialog = [UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("ĐỔI TÊN NÚT"), OX_NS("重命名按钮"), OX_NS("เปลี่ยนชื่อปุ่ม"), OX_NS("RINOMINA PULSANTE"), OX_NS("RENAME BUTTON")) message:ZuiPick5(OX_NS("Nhập tên mới cho nút này"), OX_NS("输入此按钮的新名称"), OX_NS("ป้อนชื่อใหม่สำหรับปุ่มนี้"), OX_NS("Inserisci un nuovo nome per questo pulsante"), OX_NS("Enter a new name for this button")) preferredStyle:UIAlertControllerStyleAlert];
    [dialog addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.text = oldName;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [dialog addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [dialog addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("MẶC ĐỊNH"), OX_NS("恢复默认"), OX_NS("ค่าเริ่มต้น"), OX_NS("PREDEFINITO"), OX_NS("DEFAULT")) style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        Ongnong::Zx8fSetMenuName(key, OX_NS(""), YES);
    }]];
    [dialog addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("LƯU"), OX_NS("保存"), OX_NS("บันทึก"), OX_NS("SALVA"), OX_NS("SAVE")) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = [dialog.textFields.firstObject.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (name.length == 0 || [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > 48 || [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding] == 0) return;
        Ongnong::Zx8fSetMenuName(key, name, NO);
    }]];
    [self presentViewController:dialog animated:YES completion:nil];
}

- (void)zServerMenuLabelsChanged:(NSNotification *)note {
    (void)note;
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    [_v2p6k1 e4p7n1:code];
    [self zRefreshAltMenuTitles];
    [self q7m2d8];
    if (_n7c3m8) [_n7c3m8 n4q9c1];
}

- (void)c2m6r4 {
    if (_a9q2x4 && !_a9q2x4.hidden) [self e7k3p9];
    if (!_n7c3m8 || _n7c3m8.hidden || _n7c3m8.c8n3q6) return;
    if (_k4m8r2) return;
    _k4m8r2 = YES;
    Z9abcb7bb90 *controller = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.035 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        controller.k4m8r2 = NO;
        if (controller.n7c3m8 && !controller.n7c3m8.hidden && !controller.n7c3m8.c8n3q6) [controller.n7c3m8 n4q9c1];
    });
}

- (void)tick {
    [self q9d3m6];
    if (_a6t3y8) {
        _v2p6k1.hidden = YES;
        _b3n7v1.hidden = YES;
    }
    if (_a9q2x4 && !_a9q2x4.hidden) [self e7k3p9];
    _p6d1v7++;
    if (!_collapsed && (_p6d1v7 % 3 == 0)) [self q7m2d8];
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (NSInteger)n4d8k2:(NSInteger)value {
    if (value < 1) return 1;
    if (value > 201) return 201;
    return value;
}

- (NSInteger)c7m1p6:(NSString *)key defaultValue:(NSInteger)defaultValue {
    NSInteger saved = [[NSUserDefaults standardUserDefaults] integerForKey:key];
    if (saved <= 0) saved = defaultValue;
    return [self n4d8k2:saved];
}

- (NSInteger)v3q9a5 {
    return [self c7m1p6:qsec_s_0082() defaultValue:9];
}

- (NSInteger)x8r2n7 {
    return [self c7m1p6:qsec_s_0083() defaultValue:108];
}

- (void)b6k4d1:(NSInteger)value forKey:(NSString *)key {
    value = [self n4d8k2:value];
    [[NSUserDefaults standardUserDefaults] setInteger:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)y4n8d2:(NSString *)key defaultValue:(NSInteger)defaultValue selectedButton:(UIButton *)button {
    NSInteger current = [self c7m1p6:key defaultValue:defaultValue];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:ZuiSpeedTitle()
                                                                   message:ZuiSpeedMessage()
                                                            preferredStyle:UIAlertControllerStyleAlert];

    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.text = [NSString stringWithFormat:qsec_s_0086(), (long)current];
        textField.placeholder = qsec_s_0087();
    }];

    Z9abcb7bb90 *controller = self;
    [alert addAction:[UIAlertAction actionWithTitle:ZuiSaveText()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSString *valueText = alert.textFields.firstObject.text ?: [NSString string];
        NSInteger value = [controller n4d8k2:valueText.integerValue];
        [controller b6k4d1:value forKey:key];
        zce119e8048.z68593f2227 = (float)value;
        zce119e8048.zacc65d5e7b = true;
        zce119e8048.z904d9bb65a = false;
        Z108056b942();
        [controller q7m2d8];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText()
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    UIPopoverPresentationController *popover = alert.popoverPresentationController;
    if (popover) {
        popover.sourceView = button;
        popover.sourceRect = button.bounds;
        popover.permittedArrowDirections = UIPopoverArrowDirectionAny;
    }

    UIViewController *presenter = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (presenter.presentedViewController) presenter = presenter.presentedViewController;
    [presenter presentViewController:alert animated:YES completion:nil];
}

- (void)r2c6m8:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    Z0418c1e0ae();
    [self y4n8d2:qsec_s_0082() defaultValue:9 selectedButton:_a9q2x4.t2m7k6];
}

- (void)t7p3v1:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    Z0418c1e0ae();
    [self y4n8d2:qsec_s_0083() defaultValue:108 selectedButton:_a9q2x4.c8x1p4];
}

- (void)g5x9q4:(NSNotification *)note {
    ZThemeLoad();
    _v2p6k1.backgroundColor = ZThemePanelColor();
    ApplyNeon(_v2p6k1, ZThemeBorder(), 24.0, 1.2);
    _v2p6k1.r6q2p8.backgroundColor = ZThemeButtonOff();
    [_v2p6k1.r6q2p8 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    ApplyNeon(_v2p6k1.r6q2p8, ZThemeBorder(), 12.0, 1.0);
    _v2p6k1.k3v9d4.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_v2p6k1.k3v9d4, ZThemeBorder(), 12.0, 1.0);
    _v2p6k1.x8p4n2.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_v2p6k1.x8p4n2, ZThemeBorder(), 8.0, 1.0);
    _a9q2x4.backgroundColor = ZThemePanelColor();
    ApplyNeon(_a9q2x4, ZThemeBorder(), 14.0, 1.2);
    if (_n7c3m8) {
        _n7c3m8.backgroundColor = ZThemePanelDarker();
        ApplyNeon(_n7c3m8, ZThemeBorder(), 18.0, 1.2);
        _n7c3m8.closeButton.backgroundColor = ZThemeButtonOff();
        ApplyNeon(_n7c3m8.closeButton, ZThemeBorder(), 6.0, 0.75);
        ZPlainIconButton(_n7c3m8.k3v9d4, ZCounterTrashIconImage());
        ZPlainIconButton(_n7c3m8.eyeButton, ZCounterEyeIconImage(_n7c3m8.r2c7m4 != 0));
        _n7c3m8.d9q3x5.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.10];
    }
    _d2q8n4.backgroundColor = ZThemePanelColor();
    ApplyNeon(_d2q8n4, ZThemeBorder(), 16.0, 1.1);
    if (_w7p3v6) [_w7p3v6 f5q1m9];
    if (_q72p9m4) [_q72p9m4 refreshTheme];
    [self q2n9v6];
    _b3n7v1.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_b3n7v1, ZThemeBorder(), 9.0, 1.0);
    if (_a9q2x4.r3n9d5) {
        _a9q2x4.r3n9d5.backgroundColor = ZThemeButtonOff();
        ApplyNeon(_a9q2x4.r3n9d5, ZThemeBorder(), 10.0, 1.2);
        _a9q2x4.r3n9d5.t2m8r5.backgroundColor = [UIColor clearColor];
        [self e7k3p9];
    }
    [self q7m2d8];
    if (_n7c3m8) {
        [_n7c3m8 setNeedsLayout];
        [_n7c3m8 n4q9c1];
    }
}

- (void)q7m2d8 {
    UIColor *buttonOff = ZThemeButtonOff();
    UIColor *border = ZThemeBorder();
    UIColor *green = ZThemeOnGreen();
    UIColor *red = ZThemeOffRed();
    UIColor *orange = ZThemeOrange();

    BOOL wifiOn = zce119e8048.z7180b46195;
    UIColor *wifiColor = wifiOn ? red : buttonOff;
    _a9q2x4.d5q9v3.r8m1v5 = wifiColor;
    [_a9q2x4.d5q9v3 setTitle:[NSString string] forState:UIControlStateNormal];
    [_a9q2x4.d5q9v3 setImage:Z9a3e7f9348() forState:UIControlStateNormal];
    _a9q2x4.d5q9v3.tintColor = ZThemeWhite();
    _a9q2x4.d5q9v3.imageEdgeInsets = UIEdgeInsetsMake(5.0, 5.0, 5.0, 5.0);
    _a9q2x4.d5q9v3.backgroundColor = wifiColor;
    ApplyNeon(_a9q2x4.d5q9v3, wifiOn ? red : border, 10.0, 1.2);

    BOOL speedAllowed = Ongnong::Zx8fSpeedAllowed();
    NSInteger speed9 = [self v3q9a5];
    NSInteger speed108 = [self x8r2n7];
    [_a9q2x4.t2m7k6 setImage:nil forState:UIControlStateNormal];
    [_a9q2x4.c8x1p4 setImage:nil forState:UIControlStateNormal];
    [_a9q2x4.t2m7k6 setTitle:[NSString stringWithFormat:qsec_s_0086(), (long)speed9] forState:UIControlStateNormal];
    [_a9q2x4.c8x1p4 setTitle:[NSString stringWithFormat:qsec_s_0086(), (long)speed108] forState:UIControlStateNormal];

    BOOL speed9Selected = speedAllowed && zce119e8048.zacc65d5e7b && ((NSInteger)lroundf(zce119e8048.z68593f2227) == speed9);
    BOOL speed108Selected = speedAllowed && zce119e8048.zacc65d5e7b && ((NSInteger)lroundf(zce119e8048.z68593f2227) == speed108);

    _a9q2x4.t2m7k6.enabled = speedAllowed;
    _a9q2x4.c8x1p4.enabled = speedAllowed;
    _a9q2x4.v6q2m8.enabled = speedAllowed;
    _a9q2x4.t2m7k6.alpha = speedAllowed ? 1.0 : 0.36;
    _a9q2x4.c8x1p4.alpha = speedAllowed ? 1.0 : 0.36;
    _a9q2x4.v6q2m8.alpha = speedAllowed ? 1.0 : 0.36;
    [_a9q2x4.t2m7k6 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.t2m7k6.backgroundColor = speed9Selected ? orange : buttonOff;
    _a9q2x4.t2m7k6.r8m1v5 = border;
    ApplyNeon(_a9q2x4.t2m7k6, speed9Selected ? orange : border, 10.0, 1.2);

    [_a9q2x4.c8x1p4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.c8x1p4.backgroundColor = speed108Selected ? orange : buttonOff;
    _a9q2x4.c8x1p4.r8m1v5 = border;
    ApplyNeon(_a9q2x4.c8x1p4, speed108Selected ? orange : border, 10.0, 1.2);

    [_a9q2x4.v6q2m8 setTitle:zce119e8048.z904d9bb65a ? qsec_s_0081() : qsec_s_0065() forState:UIControlStateNormal];
    [_a9q2x4.v6q2m8 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.v6q2m8.backgroundColor = (speedAllowed && zce119e8048.z904d9bb65a) ? orange : buttonOff;
    _a9q2x4.v6q2m8.r8m1v5 = border;
    ApplyNeon(_a9q2x4.v6q2m8, (speedAllowed && zce119e8048.z904d9bb65a) ? orange : border, 10.0, 1.2);

    BOOL skipOn = zce119e8048.z54007f39a0;
    UIColor *skipColor = skipOn ? red : buttonOff;
    _a9q2x4.k4p7c1.r8m1v5 = skipColor;
    [_a9q2x4.k4p7c1 setTitle:ZuiSkipText() forState:UIControlStateNormal];
    [_a9q2x4.k4p7c1 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [_a9q2x4.k4p7c1 setNeedsLayout];
    _a9q2x4.k4p7c1.backgroundColor = skipColor;
    ApplyNeon(_a9q2x4.k4p7c1, skipOn ? red : border, 10.0, 1.2);

    _a9q2x4.r3n9d5.backgroundColor = UIColor.clearColor;
    _a9q2x4.r3n9d5.layer.borderWidth = 0.0;
    _a9q2x4.r3n9d5.layer.shadowOpacity = 0.0;
    _a9q2x4.q4n8p2.backgroundColor = UIColor.clearColor;
    [_a9q2x4.q4n8p2 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.q4n8p2.layer.borderWidth = 0.0;
    _a9q2x4.q4n8p2.layer.shadowOpacity = 0.0;
    _a9q2x4.q4n8p2.layer.cornerRadius = 0.0;
    [_a9q2x4 setNeedsLayout];
    [self e7k3p9];

    Zcb66126fa3 *updateButton = _v2p6k1.a7m1c5.count > 0 ? _v2p6k1.a7m1c5[0] : nil;
    if (updateButton) {
        UIColor *redUpdate = RGB(220, 40, 45);
        updateButton.h5m2k8 = NO;
        updateButton.r8m1v5 = redUpdate;
        updateButton.backgroundColor = redUpdate;
        updateButton.x9c4n6.textColor = ZThemeWhite();
        updateButton.x9c4n6.layer.shadowOpacity = 0.0;
        ApplyNeon(updateButton, RGB(255, 80, 80), 14.0, 1.2);
    }
    Zcb66126fa3 *vipButton = _v2p6k1.a7m1c5.count > 1 ? _v2p6k1.a7m1c5[1] : nil;
    if (vipButton) {
        vipButton.x9c4n6.text = ZuiBuyVipText();
        [vipButton setNeedsLayout];
        UIColor *vipGold = RGB(203, 148, 20);
        vipButton.h5m2k8 = NO;
        vipButton.r8m1v5 = RGB(255, 212, 55);
        vipButton.backgroundColor = vipGold;
        vipButton.x9c4n6.textColor = ZThemeWhite();
        vipButton.x9c4n6.layer.shadowOpacity = 0.0;
        ApplyNeon(vipButton, RGB(255, 212, 55), 14.0, 1.2);
    }
    if (_v2p6k1.k3v9d4) {
        BOOL freeMode = [ZuiBuyVipText() isEqualToString:OX_NS("FREE")];
        _v2p6k1.k3v9d4.hidden = !freeMode;
        [_v2p6k1.k3v9d4 setTitle:ZVipBuyNowText() forState:UIControlStateNormal];
        _v2p6k1.k3v9d4.backgroundColor = RGB(18, 105, 45);
        _v2p6k1.k3v9d4.layer.borderColor = RGB(40, 155, 72).CGColor;
        [_v2p6k1 setNeedsLayout];
    }
    BOOL mainMenuVIP = Ongnong::Zx8fIsVIP();
    BOOL counterAllowed = Ongnong::Zx8fCounterAllowed();
    BOOL betCycleAllowed = Ongnong::Zx8fBetCycleAllowed();
    Ongnong::R3ni(betCycleAllowed);
    Zcb66126fa3 *betCycleButton = _v2p6k1.a7m1c5.count > 11 ? _v2p6k1.a7m1c5[11] : nil;
    if (!betCycleAllowed && _q72p9m4) _q72p9m4.hidden = YES;
    if (betCycleButton) {
        betCycleButton.hidden = !betCycleAllowed && mainMenuVIP;
        betCycleButton.enabled = betCycleAllowed || !mainMenuVIP;
        betCycleButton.alpha = betCycleAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        [self w2k7e5:betCycleButton color:border active:(betCycleAllowed && _q72p9m4 && !_q72p9m4.hidden)];
    }
    Zcb66126fa3 *mergeButton = _v2p6k1.a7m1c5.count > 12 ? _v2p6k1.a7m1c5[12] : nil;
    BOOL mergeAllowed = Ongnong::Zx8fAutoMergeAllowed();
    if (!mergeAllowed) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        if (self.k2m8v4) self.k2m8v4.hidden = YES;
    }
    if (mergeButton) {
        mergeButton.hidden = !mergeAllowed && mainMenuVIP;
        mergeButton.enabled = mergeAllowed || !mainMenuVIP;
        mergeButton.alpha = mergeAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        mergeButton.x9c4n6.text = ZuiAutoMergeText();
        [self w2k7e5:mergeButton
                       color:RGB(120, 235, 170)
                      active:(mergeAllowed &&
                              Ongnong::AutoMergeModuleIsEnabled())];
    }
    Zcb66126fa3 *counterButton = _v2p6k1.a7m1c5.count > 2 ? _v2p6k1.a7m1c5[2] : nil;
    if (counterButton) { counterButton.hidden = !counterAllowed && mainMenuVIP; counterButton.enabled = counterAllowed || !mainMenuVIP; counterButton.alpha = counterAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); }
    [self w2k7e5:counterButton color:border active:(counterAllowed && _n7c3m8 && !_n7c3m8.hidden)];
    Zcb66126fa3 *buildButton = _v2p6k1.a7m1c5.count > 3 ? _v2p6k1.a7m1c5[3] : nil;
    Zcb66126fa3 *raidButton = _v2p6k1.a7m1c5.count > 4 ? _v2p6k1.a7m1c5[4] : nil;
    Zcb66126fa3 *magicButton = _v2p6k1.a7m1c5.count > 5 ? _v2p6k1.a7m1c5[5] : nil;
    BOOL buildOn = Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending();
    BOOL buildAllowed = buildOn || Ongnong::Zx8fAutoBuildAllowed();
    BOOL magicAllowed = Ongnong::Zx8fMagicCardsAllowed();
    if (!magicAllowed) {
        if (Ongnong::MagicCardsModuleIsEnabled()) Ongnong::MagicCardsModuleSetEnabled(false);
        _r8m2d5 = NO;
        if (_u1x7p4) _u1x7p4.hidden = YES;
    }
    BOOL raidOn = Ongnong::RaidHammerModuleIsEnabled();
    BOOL magicOn = magicAllowed && Ongnong::MagicCardsModuleIsEnabled();
    if (!buildAllowed) {
        _v7m4q1 = NO;
        if (_b6p2x9) _b6p2x9.hidden = YES;
    }
    if (buildButton) { buildButton.hidden = !buildAllowed && mainMenuVIP; [self w2k7e5:buildButton color:border active:(buildAllowed && (buildOn || (_v7m4q1 && _b6p2x9 && !_b6p2x9.hidden)))]; }
    [self w2k7e5:raidButton color:border active:(raidOn || (_x4p7m2 && _e3k9d6 && !_e3k9d6.hidden))];
    BOOL buildLocked = raidOn || magicOn;
    BOOL raidLocked = buildOn || magicOn;
    BOOL magicLocked = buildOn || raidOn;
    if (buildButton) { buildButton.alpha = buildAllowed ? (buildLocked ? 0.42 : 1.0) : (mainMenuVIP ? 0.0 : 0.36); buildButton.enabled = buildAllowed ? !buildLocked : !mainMenuVIP; }
    if (raidButton) { raidButton.alpha = raidLocked ? 0.42 : 1.0; raidButton.enabled = !raidLocked; }
    if (_b6p2x9) { _b6p2x9.enabled = buildAllowed && !buildLocked; _b6p2x9.alpha = (buildAllowed && !buildLocked) ? 1.0 : 0.42; [self z3n8v5]; }
    if (_e3k9d6) { _e3k9d6.enabled = !raidLocked; _e3k9d6.alpha = raidLocked ? 0.42 : 1.0; [self w1p5c9]; }
    if (magicButton) {
        magicButton.hidden = !magicAllowed && mainMenuVIP;
        magicButton.x9c4n6.text = ZuiMagicCardsQuickText();
        [self w2k7e5:magicButton color:border active:(magicAllowed && (magicOn || (_r8m2d5 && _u1x7p4 && !_u1x7p4.hidden)))];
        magicButton.alpha = magicAllowed ? (magicLocked ? 0.42 : 1.0) : (mainMenuVIP ? 0.0 : 0.36);
        magicButton.enabled = magicAllowed ? !magicLocked : !mainMenuVIP;
    }
    if (_u1x7p4) {
        _u1x7p4.enabled = magicAllowed && !magicLocked;
        _u1x7p4.alpha = (magicAllowed && !magicLocked) ? 1.0 : 0.42;
    }
    Zcb66126fa3 *friendButton = _v2p6k1.a7m1c5.count > 13 ? _v2p6k1.a7m1c5[13] : nil;
    BOOL friendAllowed = Ongnong::Zx8fFriendInviteAllowed();
    if (friendButton) { friendButton.hidden = !friendAllowed && mainMenuVIP; friendButton.enabled = friendAllowed || !mainMenuVIP; friendButton.alpha = friendAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:friendButton color:RGB(90, 210, 255) active:NO]; }
    Zcb66126fa3 *potionMenuButton = _v2p6k1.a7m1c5.count > 14 ? _v2p6k1.a7m1c5[14] : nil;
    BOOL potionAllowed = Ongnong::Zx8fPotionAllowed();
    if (!potionAllowed && Ongnong::AutoPotionIsEnabled()) Ongnong::AutoPotionSetEnabled(NO);
    if (potionMenuButton) {
        BOOL potionOn = potionAllowed && Ongnong::AutoPotionIsEnabled();
        potionMenuButton.hidden = !potionAllowed && mainMenuVIP;
        potionMenuButton.enabled = potionAllowed || !mainMenuVIP;
        potionMenuButton.alpha = potionAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        potionMenuButton.x9c4n6.text = ZuiPotionStateText(potionOn);
        [self w2k7e5:potionMenuButton color:RGB(185, 105, 255) active:potionOn];
    }
    Zcb66126fa3 *autoClickButton = _v2p6k1.a7m1c5.count > 6 ? _v2p6k1.a7m1c5[6] : nil;
    BOOL autoClickAllowed = Ongnong::Zx8fAutoClickAllowed();
    if (!autoClickAllowed) [Z5e8402e1b3 d7x2p6:NO];
    if (autoClickButton) { autoClickButton.hidden = !autoClickAllowed && mainMenuVIP; autoClickButton.enabled = autoClickAllowed || !mainMenuVIP; autoClickButton.alpha = autoClickAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:autoClickButton color:border active:(autoClickAllowed && [Z5e8402e1b3 c3n9k5])]; }
    Zcb66126fa3 *toolsButton = _v2p6k1.a7m1c5.count > 7 ? _v2p6k1.a7m1c5[7] : nil;
    BOOL toolsAllowed = Ongnong::Zx8fToolsAllowed();
    if (!toolsAllowed && _a9q2x4) _a9q2x4.hidden = YES;
    BOOL toolVisible = toolsAllowed && (_a9q2x4 && !_a9q2x4.hidden);
    if (toolsButton) { toolsButton.hidden = !toolsAllowed && mainMenuVIP; toolsButton.enabled = toolsAllowed || !mainMenuVIP; toolsButton.alpha = toolsAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:toolsButton color:border active:toolVisible]; }
    Zcb66126fa3 *autoStopButton = _v2p6k1.a7m1c5.count > 8 ? _v2p6k1.a7m1c5[8] : nil;
    BOOL autoStopAllowed = Ongnong::Zx8fAutoStopAllowed();
    if (!autoStopAllowed && _d2q8n4) _d2q8n4.hidden = YES;
    if (autoStopButton) { autoStopButton.hidden = !autoStopAllowed && mainMenuVIP; autoStopButton.enabled = autoStopAllowed || !mainMenuVIP; autoStopButton.alpha = autoStopAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:autoStopButton color:border active:(autoStopAllowed && _d2q8n4 && !_d2q8n4.hidden)]; }
    Zcb66126fa3 *menuColorButton = _v2p6k1.a7m1c5.count > 9 ? _v2p6k1.a7m1c5[9] : nil;
    BOOL menuColorAllowed = Ongnong::Zx8fMenuColorAllowed();
    if (!menuColorAllowed && _w7p3v6) _w7p3v6.hidden = YES;
    if (menuColorButton) { menuColorButton.hidden = !menuColorAllowed && mainMenuVIP; menuColorButton.enabled = menuColorAllowed || !mainMenuVIP; menuColorButton.alpha = menuColorAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:menuColorButton color:border active:(menuColorAllowed && _w7p3v6 && !_w7p3v6.hidden)]; }
    BOOL raidAllowed = Ongnong::Zx8fRaidHammerAllowed();
    if (!raidAllowed) { Ongnong::RaidHammerModuleSetEnabled(false); _x4p7m2 = NO; if (_e3k9d6) _e3k9d6.hidden = YES; }
    if (raidButton) { raidButton.hidden = !raidAllowed && mainMenuVIP; raidButton.enabled = raidAllowed ? !raidLocked : !mainMenuVIP; raidButton.alpha = raidAllowed ? (raidLocked ? 0.42 : 1.0) : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:raidButton color:border active:(raidAllowed && (raidOn || (_x4p7m2 && _e3k9d6 && !_e3k9d6.hidden)))]; }
    [self zRefreshAltMenuTitles];
    [_v2p6k1 setNeedsLayout];
    Zcb66126fa3 *expeditionButton = _v2p6k1.a7m1c5.count > 10 ? _v2p6k1.a7m1c5[10] : nil;
    BOOL expeditionAllowed = Ongnong::R7f401();
    if (!expeditionAllowed) {
        if (Ongnong::ExpeditionAutoIsEnabled()) {
            Ongnong::ExpeditionAutoSetEnabled(false);
        }
        _m3k9a2 = NO;
        if (_q8z1u4) {
            _q8z1u4.hidden = YES;
        }
    }
    if (expeditionButton) {
        expeditionButton.hidden = !expeditionAllowed && mainMenuVIP;
        expeditionButton.enabled = expeditionAllowed || !mainMenuVIP;
        expeditionButton.alpha = expeditionAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        expeditionButton.x9c4n6.text = Zr7f421();
        [self w2k7e5:expeditionButton
                       color:border
                      active:(expeditionAllowed &&
                              _m3k9a2 &&
                              _q8z1u4 &&
                              !_q8z1u4.hidden)];
    }
    [self q2n9v6];
    if (_n7c3m8 && !_n7c3m8.hidden) {
        [_n7c3m8 setNeedsLayout];
        [_n7c3m8 n4q9c1];
    }
    if (_d2q8n4 && !_d2q8n4.hidden) {
        [_d2q8n4 r8p3d7];
        [_d2q8n4 a9m3c6];
        [_d2q8n4 setNeedsLayout];
    }
}

- (void)v4p9a1:(NSString *)code {
    [self d2x8q4];
    if (code.length == 0) code = qsec_s_0039();
    [[NSUserDefaults standardUserDefaults] setObject:code forKey:qsec_s_0075()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:OngnongUIVaultLanguageNotification() object:nil];
    [_v2p6k1 e4p7n1:code];
    if (_d2q8n4) {
        if (_d2q8n4.d7m2x6 <= 0) [_d2q8n4.h8m3x6 setTitle:ZuiSetText() forState:UIControlStateNormal];
        [_d2q8n4 setNeedsLayout];
    }
    if (_w7p3v6) [_w7p3v6 f5q1m9];
    [self h6d2q8];
    [self q7m2d8];
    [self q2n9v6];
    [self c3n7x5];
    [self zRefreshAltMenuTitles];
}

- (void)c8x3n6 {
    [self d2x8q4];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:ZuiLanguageTitle()
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    Z9abcb7bb90 *controller = self;

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0091()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0039()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0092()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0040()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0093()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0048()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0094()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0056()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultEnglishAction)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:OngnongUIVaultLangCodeEN()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText()
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    UIPopoverPresentationController *popover = alert.popoverPresentationController;
    if (popover) {
        popover.sourceView = _v2p6k1.r6q2p8;
        popover.sourceRect = _v2p6k1.r6q2p8.bounds;
        popover.permittedArrowDirections = UIPopoverArrowDirectionAny;
    }

    UIViewController *presenter = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (presenter.presentedViewController) presenter = presenter.presentedViewController;
    [presenter presentViewController:alert animated:YES completion:nil];
}

- (void)w2k7e5:(Zcb66126fa3 *)button color:(UIColor *)color active:(BOOL)active {
    if (!button) return;
    UIColor *useColor = active ? ZThemeActiveGreen() : ZThemeBorder();
    button.h5m2k8 = active;
    button.r8m1v5 = useColor;
    button.backgroundColor = active ? ZThemeActiveGreen() : ZThemeButtonOff();
    button.x9c4n6.textColor = ZThemeWhite();
    button.q3p7d2.textColor = active ? ZThemeWhite() : ZThemeBorder();
    button.x9c4n6.layer.shadowOpacity = 0.0;
    button.q3p7d2.layer.shadowOpacity = 0.0;
    ApplyNeon(button, active ? ZThemeActiveGreen() : ZThemeBorder(), 14.0, 1.1);
    [button setNeedsDisplay];
}


- (UIButton *)c4m8q2:(CGRect)frame title:(NSString *)title action:(SEL)action closeAction:(SEL)closeAction panAction:(SEL)panAction {
    UIButton *popup = [UIButton buttonWithType:UIButtonTypeCustom];
    popup.frame = frame;
    popup.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    popup.titleLabel.adjustsFontSizeToFitWidth = YES;
    popup.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    popup.layer.cornerRadius = 12.0;
    popup.layer.masksToBounds = NO;
    [popup setTitle:title forState:UIControlStateNormal];
    [popup setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [popup addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [popup addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:panAction];
    [popup addGestureRecognizer:pan];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeCustom];
    close.frame = CGRectMake(frame.size.width - 20.0, 2.0, 18.0, 18.0);
    [close setTitle:OX_NS("×") forState:UIControlStateNormal];
    [close setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    close.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    close.layer.cornerRadius = 9.0;
    close.layer.borderWidth = 0.7;
    close.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [close addTarget:self action:closeAction forControlEvents:UIControlEventTouchUpInside];
    [close addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [popup addSubview:close];
    return popup;
}

- (void)b2v7n4 {
    if (_b6p2x9) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 50.0;
    if ([ud objectForKey:OX_NS("ab_float_x")]) x = [ud floatForKey:OX_NS("ab_float_x")];
    if ([ud objectForKey:OX_NS("ab_float_y")]) y = [ud floatForKey:OX_NS("ab_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _b6p2x9 = [self c4m8q2:CGRectMake(x, y, w, h) title:ZuiAutoBuildStateText(NO) action:@selector(g7q3m8) closeAction:@selector(t5x9c2) panAction:@selector(k1d6p4:)];
    _b6p2x9.hidden = YES;
    [self.view addSubview:_b6p2x9];
    [self z3n8v5];
}

- (void)z3n8v5 {
    if (!_b6p2x9) return;
    BOOL pending = Ongnong::AutoBuildModuleIsPending();
    BOOL on = Ongnong::AutoBuildModuleIsEnabled();
    [_b6p2x9 setTitle:(pending ? [NSString stringWithFormat:OX_NS("%@ %@"), ZuiAutoBuildText(), OX_NS("CHỜ")] : ZuiAutoBuildStateText(on)) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : (pending ? [UIColor orangeColor] : ZThemeOffRed());
    _b6p2x9.backgroundColor = [color colorWithAlphaComponent:0.90];
    _b6p2x9.layer.borderWidth = 1.1;
    _b6p2x9.layer.borderColor = color.CGColor;
    _b6p2x9.layer.shadowColor = color.CGColor;
    _b6p2x9.layer.shadowOpacity = 0.45;
    _b6p2x9.layer.shadowRadius = 8.0;
    _b6p2x9.layer.shadowOffset = CGSizeZero;
}

- (void)k1d6p4:(UIPanGestureRecognizer *)pan {
    if (!_b6p2x9 || !_b6p2x9.superview) return;
    UIView *superview = _b6p2x9.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _n5c8r2 = _b6p2x9.center;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(_n5c8r2.x + translation.x, _n5c8r2.y + translation.y);
        CGFloat halfW = _b6p2x9.bounds.size.width * 0.5;
        CGFloat halfH = _b6p2x9.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _b6p2x9.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_b6p2x9.frame.origin.x forKey:OX_NS("ab_float_x")];
            [ud setFloat:_b6p2x9.frame.origin.y forKey:OX_NS("ab_float_y")];
            [ud synchronize];
        }
    }
}

- (void)t5x9c2 {
    Ongnong::AutoBuildModuleSetEnabled(false);
    [self u7m1c9];
    _v7m4q1 = NO;
    if (_b6p2x9) _b6p2x9.hidden = YES;
    [self z3n8v5];
    [self q7m2d8];
}

- (void)g7q3m8 {
    [self d2x8q4];
    BOOL buildActiveOrPending = Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending();
    BOOL willEnable = !buildActiveOrPending;
    if (willEnable && !Ongnong::Zx8fAutoBuildAllowed()) { [self q7m2d8]; return; }
    if (willEnable && (Ongnong::RaidHammerModuleIsEnabled() || Ongnong::MagicCardsModuleIsEnabled())) {
        [self z3n8v5];
        [self q7m2d8];
        return;
    }
    if (willEnable) {
        [self j6t3a8];
        [self y4d8p2];
        Ongnong::AutoBuildModuleSetEnabled(true);
        if (!(Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending())) [self u7m1c9];
    } else {
        Ongnong::AutoBuildModuleSetEnabled(false);
        [self u7m1c9];
    }
    [self z3n8v5];
    [self q7m2d8];
}

- (void)v5c2q8 {
    if (_e3k9d6) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 96.0;
    if ([ud objectForKey:OX_NS("rh_float_x")]) x = [ud floatForKey:OX_NS("rh_float_x")];
    if ([ud objectForKey:OX_NS("rh_float_y")]) y = [ud floatForKey:OX_NS("rh_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _e3k9d6 = [self c4m8q2:CGRectMake(x, y, w, h) title:ZuiAutoPigHammerStateText(NO) action:@selector(y6m1p7) closeAction:@selector(q4d8x3) panAction:@selector(a9r2k6:)];
    _e3k9d6.hidden = YES;
    [self.view addSubview:_e3k9d6];
    [self w1p5c9];
}

- (void)w1p5c9 {
    if (!_e3k9d6) return;
    BOOL on = Ongnong::RaidHammerModuleIsEnabled();
    [_e3k9d6 setTitle:ZuiAutoPigHammerStateText(on) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    _e3k9d6.backgroundColor = [color colorWithAlphaComponent:0.90];
    _e3k9d6.layer.borderWidth = 1.1;
    _e3k9d6.layer.borderColor = color.CGColor;
    _e3k9d6.layer.shadowColor = color.CGColor;
    _e3k9d6.layer.shadowOpacity = 0.45;
    _e3k9d6.layer.shadowRadius = 8.0;
    _e3k9d6.layer.shadowOffset = CGSizeZero;
}

- (void)a9r2k6:(UIPanGestureRecognizer *)pan {
    if (!_e3k9d6 || !_e3k9d6.superview) return;
    UIView *superview = _e3k9d6.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _h8q1v5 = _e3k9d6.center;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(_h8q1v5.x + translation.x, _h8q1v5.y + translation.y);
        CGFloat halfW = _e3k9d6.bounds.size.width * 0.5;
        CGFloat halfH = _e3k9d6.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _e3k9d6.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_e3k9d6.frame.origin.x forKey:OX_NS("rh_float_x")];
            [ud setFloat:_e3k9d6.frame.origin.y forKey:OX_NS("rh_float_y")];
            [ud synchronize];
        }
    }
}

- (void)q4d8x3 {
    Ongnong::RaidHammerModuleSetEnabled(false);
    _x4p7m2 = NO;
    if (_e3k9d6) _e3k9d6.hidden = YES;
    [self w1p5c9];
    Z108056b942();
    [self q7m2d8];
}

- (void)y6m1p7 {
    [self d2x8q4];
    if (!Ongnong::Zx8fRaidHammerAllowed()) { Ongnong::RaidHammerModuleSetEnabled(false); [self q7m2d8]; return; }
    BOOL willEnable = !Ongnong::RaidHammerModuleIsEnabled();
    if (willEnable && ((Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending()) || Ongnong::MagicCardsModuleIsEnabled())) {
        [self w1p5c9];
        [self q7m2d8];
        return;
    }
    Ongnong::RaidHammerModuleToggle();
    [self w1p5c9];
    Z108056b942();
    [self q7m2d8];
}

- (void)r9b4t1 {
    if (_u1x7p4) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 96.0;
    if ([ud objectForKey:OX_NS("mc_float_x")]) x = [ud floatForKey:OX_NS("mc_float_x")];
    if ([ud objectForKey:OX_NS("mc_float_y")]) y = [ud floatForKey:OX_NS("mc_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _u1x7p4 = [UIButton buttonWithType:UIButtonTypeCustom];
    _u1x7p4.frame = CGRectMake(x, y, w, h);
    _u1x7p4.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    _u1x7p4.titleLabel.adjustsFontSizeToFitWidth = YES;
    _u1x7p4.layer.cornerRadius = 12.0;
    _u1x7p4.layer.masksToBounds = NO;
    [_u1x7p4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [_u1x7p4 addTarget:self action:@selector(s2k6v4) forControlEvents:UIControlEventTouchUpInside];
    [_u1x7p4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(p3v7m5:)];
    [_u1x7p4 addGestureRecognizer:pan];
    UIButton *magicClose = [UIButton buttonWithType:UIButtonTypeCustom];
    magicClose.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
    [magicClose setTitle:OX_NS("×") forState:UIControlStateNormal];
    [magicClose setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    magicClose.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    magicClose.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    magicClose.layer.cornerRadius = 9.0;
    magicClose.layer.borderWidth = 0.7;
    magicClose.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [magicClose addTarget:self action:@selector(zMagicPopupClose) forControlEvents:UIControlEventTouchUpInside];
    [_u1x7p4 addSubview:magicClose];
    _u1x7p4.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    _u1x7p4.hidden = YES;
    [self.view addSubview:_u1x7p4];
    [self h6d2q8];
}

- (void)h6d2q8 {
    if (!_u1x7p4) return;
    BOOL on = Ongnong::MagicCardsModuleIsEnabled();
    [_u1x7p4 setTitle:ZuiMagicCardsStateText(on) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    _u1x7p4.backgroundColor = [color colorWithAlphaComponent:0.90];
    _u1x7p4.layer.borderWidth = 1.1;
    _u1x7p4.layer.borderColor = color.CGColor;
    _u1x7p4.layer.shadowColor = color.CGColor;
    _u1x7p4.layer.shadowOpacity = 0.45;
    _u1x7p4.layer.shadowRadius = 8.0;
    _u1x7p4.layer.shadowOffset = CGSizeZero;
    [_u1x7p4 setNeedsLayout];
}

- (void)p3v7m5:(UIPanGestureRecognizer *)pan {
    if (!_u1x7p4 || !_u1x7p4.superview) return;
    UIView *superview = _u1x7p4.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _r6q2p8 = _u1x7p4.center;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(_r6q2p8.x + translation.x, _r6q2p8.y + translation.y);
        CGFloat halfW = _u1x7p4.bounds.size.width * 0.5;
        CGFloat halfH = _u1x7p4.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _u1x7p4.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_u1x7p4.frame.origin.x forKey:OX_NS("mc_float_x")];
            [ud setFloat:_u1x7p4.frame.origin.y forKey:OX_NS("mc_float_y")];
            [ud synchronize];
        }
    }
}

- (void)z8a5c1 {
    if (_q8z1u4) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 142.0;
    if ([ud objectForKey:OX_NS("exp_float_x")]) x = [ud floatForKey:OX_NS("exp_float_x")];
    if ([ud objectForKey:OX_NS("exp_float_y")]) y = [ud floatForKey:OX_NS("exp_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _q8z1u4 = [UIButton buttonWithType:UIButtonTypeCustom];
    _q8z1u4.frame = CGRectMake(x, y, w, h);
    _q8z1u4.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    _q8z1u4.titleLabel.adjustsFontSizeToFitWidth = YES;
    _q8z1u4.titleLabel.minimumScaleFactor = 0.65;
    _q8z1u4.layer.cornerRadius = 12.0;
    _q8z1u4.layer.masksToBounds = NO;
    [_q8z1u4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [_q8z1u4 addTarget:self action:@selector(w3m7d2) forControlEvents:UIControlEventTouchUpInside];
    [_q8z1u4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(n1c8f5:)];
    pan.cancelsTouchesInView = NO;
    [_q8z1u4 addGestureRecognizer:pan];
    UIButton *forestClose = [UIButton buttonWithType:UIButtonTypeCustom];
    forestClose.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
    [forestClose setTitle:OX_NS("×") forState:UIControlStateNormal];
    [forestClose setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    forestClose.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    forestClose.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    forestClose.layer.cornerRadius = 9.0;
    forestClose.layer.borderWidth = 0.7;
    forestClose.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [forestClose addTarget:self action:@selector(zForestPopupClose) forControlEvents:UIControlEventTouchUpInside];
    [_q8z1u4 addSubview:forestClose];
    _q8z1u4.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    _q8z1u4.hidden = YES;
    [self.view addSubview:_q8z1u4];
    [self q2n9v6];
}

- (void)q2n9v6 {
    if (!_q8z1u4) return;
    if (!Ongnong::R7f401()) {
        if (Ongnong::ExpeditionAutoIsEnabled()) {
            Ongnong::ExpeditionAutoSetEnabled(false);
        }
        _m3k9a2 = NO;
        _q8z1u4.hidden = YES;
        return;
    }
    BOOL on = Ongnong::ExpeditionAutoIsEnabled() ? YES : NO;
    [_q8z1u4 setTitle:Zr7f422(on) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    _q8z1u4.backgroundColor = [color colorWithAlphaComponent:0.90];
    _q8z1u4.layer.borderWidth = 1.1;
    _q8z1u4.layer.borderColor = color.CGColor;
    _q8z1u4.layer.shadowColor = color.CGColor;
    _q8z1u4.layer.shadowOpacity = 0.45;
    _q8z1u4.layer.shadowRadius = 8.0;
    _q8z1u4.layer.shadowOffset = CGSizeZero;
    [_q8z1u4 setNeedsLayout];
}

- (void)v7b2c9 {
    if (!_q72p9m4 || !Ongnong::Zx8fBetCycleAllowed()) {
        Ongnong::R3ni(NO);
        if (_q72p9m4) _q72p9m4.hidden = YES;
        [self zShowMainVipRequiredAtIndex:11];
        [self q7m2d8];
        return;
    }
    _q72p9m4.hidden = !_q72p9m4.hidden;
    if (!_q72p9m4.hidden) {
        [_q72p9m4 refreshAll];
        [self.view bringSubviewToFront:_q72p9m4];
    }
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)h5p1k8 {
    [self d2x8q4];
    if (!Ongnong::R7f401()) {
        Ongnong::ExpeditionAutoSetEnabled(false);
        _m3k9a2 = NO;
        if (_q8z1u4) {
            _q8z1u4.hidden = YES;
        }
        [self zShowMainVipRequiredAtIndex:10];
        [self q7m2d8];
        return;
    }
    [self z8a5c1];
    _m3k9a2 = !_m3k9a2;
    if (_m3k9a2) {
        _q8z1u4.hidden = NO;
        [self.view bringSubviewToFront:_q8z1u4];
    } else {
        Ongnong::ExpeditionAutoSetEnabled(false);
        _q8z1u4.hidden = YES;
    }
    [self q2n9v6];
    [self q7m2d8];
}

- (void)w3m7d2 {
    if (!Ongnong::R7f401()) {
        Ongnong::ExpeditionAutoSetEnabled(false);
        _m3k9a2 = NO;
        if (_q8z1u4) {
            _q8z1u4.hidden = YES;
        }
        [self q7m2d8];
        return;
    }
    Ongnong::ExpeditionAutoSetEnabled(
        !Ongnong::ExpeditionAutoIsEnabled());
    [self q2n9v6];
    [self q7m2d8];
}

- (void)b6x4j9:(NSNotification *)note {
    (void)note;
    [self q2n9v6];
}

- (void)n1c8f5:(UIPanGestureRecognizer *)pan {
    if (!_q8z1u4 || !_q8z1u4.superview) return;
    UIView *superview = _q8z1u4.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _c7w2e6 = _q8z1u4.center;
        _zForestDragging = NO;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        if (!_zForestDragging && hypot(translation.x, translation.y) >= 7.0) _zForestDragging = YES;
        if (!_zForestDragging && pan.state == UIGestureRecognizerStateChanged) return;
        CGPoint c = CGPointMake(_c7w2e6.x + translation.x, _c7w2e6.y + translation.y);
        CGFloat halfW = _q8z1u4.bounds.size.width * 0.5;
        CGFloat halfH = _q8z1u4.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _q8z1u4.center = c;
        if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_q8z1u4.frame.origin.x forKey:OX_NS("exp_float_x")];
            [ud setFloat:_q8z1u4.frame.origin.y forKey:OX_NS("exp_float_y")];
            [ud synchronize];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.14 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.zForestDragging = NO;
            });
        }
    }
}


- (void)j6t3a8 {
    if (_n3q9c6) return;
    _c9m5r3 = zce119e8048.z68593f2227;
    _b7v1k8 = zce119e8048.zacc65d5e7b;
    _t4p6x2 = zce119e8048.z904d9bb65a;
    _n3q9c6 = YES;
}

- (void)y4d8p2 {
    zce119e8048.z68593f2227 = (float)[self v3q9a5];
    zce119e8048.zacc65d5e7b = true;
    zce119e8048.z904d9bb65a = false;
    Z108056b942();
}

- (void)u7m1c9 {
    if (!_n3q9c6) return;
    zce119e8048.z68593f2227 = _c9m5r3;
    zce119e8048.zacc65d5e7b = _b7v1k8;
    zce119e8048.z904d9bb65a = _t4p6x2;
    _n3q9c6 = NO;
    Z108056b942();
}

- (void)f3q6v8 {
    _n3q9c6 = NO;
}

- (void)m8c2r6 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoBuildAllowed()) { [self zShowMainVipRequiredAtIndex:3]; [self q7m2d8]; return; }
    [self b2v7n4];
    _v7m4q1 = YES;
    _b6p2x9.hidden = NO;
    [self.view bringSubviewToFront:_b6p2x9];
    [self z3n8v5];
    [self q7m2d8];
}

- (void)f5n9x1 {
    [self d2x8q4];
    if (!Ongnong::Zx8fRaidHammerAllowed()) { Ongnong::RaidHammerModuleSetEnabled(false); [self zShowMainVipRequiredAtIndex:4]; [self q7m2d8]; return; }
    [self v5c2q8];
    _x4p7m2 = YES;
    _e3k9d6.hidden = NO;
    [self.view bringSubviewToFront:_e3k9d6];
    [self w1p5c9];
    [self q7m2d8];
}

- (void)a7q3d8 {
    [self d2x8q4];
    if (!Ongnong::Zx8fMagicCardsAllowed()) {
        _r8m2d5 = NO;
        if (_u1x7p4) _u1x7p4.hidden = YES;
        Ongnong::MagicCardsModuleSetEnabled(false);
        [self zShowMainVipRequiredAtIndex:5];
        [self q7m2d8];
        return;
    }
    BOOL willShow = !_r8m2d5;
    if (willShow && ((Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending()) || Ongnong::RaidHammerModuleIsEnabled())) {
        [self q7m2d8];
        return;
    }
    [self r9b4t1];
    _r8m2d5 = willShow;
    if (_r8m2d5) {
        _u1x7p4.hidden = NO;
        [self.view bringSubviewToFront:_u1x7p4];
    } else {
        Ongnong::MagicCardsModuleSetEnabled(false);
        _u1x7p4.hidden = YES;
    }
    [self h6d2q8];
    [self w2k7e5:_v2p6k1.a7m1c5.count > 5 ? _v2p6k1.a7m1c5[5] : nil color:ZThemeBorder() active:_r8m2d5];
    [self q7m2d8];
}

- (void)s2k6v4 {
    if (!Ongnong::Zx8fMagicCardsAllowed()) {
        Ongnong::MagicCardsModuleSetEnabled(false);
        if (_u1x7p4) _u1x7p4.hidden = YES;
        _r8m2d5 = NO;
        [self q7m2d8];
        return;
    }
    BOOL willEnable = !Ongnong::MagicCardsModuleIsEnabled();
    if (willEnable && ((Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending()) || Ongnong::RaidHammerModuleIsEnabled())) {
        [self h6d2q8];
        [self q7m2d8];
        return;
    }
    Ongnong::MagicCardsModuleToggle();
    [self h6d2q8];
    [self q7m2d8];
}


- (void)z6m4a8 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoMergeAllowed()) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        if (self.k2m8v4) self.k2m8v4.hidden = YES;
        [self zShowMainVipRequiredAtIndex:12];
        [self q7m2d8];
        return;
    }
    [self u4m8p2];
    self.p7x3n6 = !self.p7x3n6;
    self.k2m8v4.hidden = !self.p7x3n6;
    if (self.p7x3n6) [self.view bringSubviewToFront:self.k2m8v4];
    [self c3n7x5];
    Zcb66126fa3 *button = _v2p6k1.a7m1c5.count > 12 ? _v2p6k1.a7m1c5[12] : nil;
    if (button) [self w2k7e5:button color:RGB(120, 235, 170) active:self.p7x3n6];
    [self q7m2d8];
}

- (void)u4m8p2 {
    if (self.k2m8v4) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0, h = 38.0;
    NSUserDefaults *ud = NSUserDefaults.standardUserDefaults;
    CGFloat x = screen.size.width - w - 14.0, y = 190.0;
    if ([ud objectForKey:OX_NS("merge_float_x")]) x = [ud floatForKey:OX_NS("merge_float_x")];
    if ([ud objectForKey:OX_NS("merge_float_y")]) y = [ud floatForKey:OX_NS("merge_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    self.k2m8v4 = [UIButton buttonWithType:UIButtonTypeCustom];
    self.k2m8v4.frame = CGRectMake(x, y, w, h);
    self.k2m8v4.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    self.k2m8v4.titleLabel.adjustsFontSizeToFitWidth = YES;
    self.k2m8v4.titleLabel.minimumScaleFactor = 0.65;
    self.k2m8v4.layer.cornerRadius = 12.0;
    self.k2m8v4.layer.masksToBounds = NO;
    [self.k2m8v4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [self.k2m8v4 addTarget:self action:@selector(r9k2d6) forControlEvents:UIControlEventTouchUpInside];
    [self.k2m8v4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UILongPressGestureRecognizer *orderHold = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(orderDiagHold:)];
    orderHold.minimumPressDuration = 1.0;
    orderHold.cancelsTouchesInView = YES;
    [self.k2m8v4 addGestureRecognizer:orderHold];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(y5v1q8:)];
    [self.k2m8v4 addGestureRecognizer:pan];
    UIButton *mergeClose = [UIButton buttonWithType:UIButtonTypeCustom];
    mergeClose.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
    [mergeClose setTitle:OX_NS("×") forState:UIControlStateNormal];
    [mergeClose setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    mergeClose.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    mergeClose.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    mergeClose.layer.cornerRadius = 9.0;
    mergeClose.layer.borderWidth = 0.7;
    mergeClose.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [mergeClose addTarget:self action:@selector(zMergePopupClose) forControlEvents:UIControlEventTouchUpInside];
    [self.k2m8v4 addSubview:mergeClose];
    self.k2m8v4.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    self.k2m8v4.hidden = YES;
    [self.view addSubview:self.k2m8v4];
    [self c3n7x5];
}

- (void)n8q4m2:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self c3n7x5];
        [self q7m2d8];
    });
}

- (void)c3n7x5 {
    if (!self.k2m8v4) return;
    if (!Ongnong::Zx8fAutoMergeAllowed()) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        self.k2m8v4.hidden = YES;
        return;
    }
    BOOL on = Ongnong::AutoMergeModuleIsEnabled();
    [self.k2m8v4 setTitle:OngnongUIVaultText(
                                on
                                    ? OngnongUIVaultAutoMergeOn
                                    : OngnongUIVaultAutoMergeOff)
                       forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    self.k2m8v4.backgroundColor = [color colorWithAlphaComponent:0.90];
    self.k2m8v4.layer.borderWidth = 1.1;
    self.k2m8v4.layer.borderColor = color.CGColor;
    self.k2m8v4.layer.shadowColor = color.CGColor;
    self.k2m8v4.layer.shadowOpacity = 0.45;
    self.k2m8v4.layer.shadowRadius = 8.0;
    self.k2m8v4.layer.shadowOffset = CGSizeZero;
}


- (void)orderDiagHold:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    NSString *details = Ongnong::AutoMergeOrderDebugCopy();
    [UIPasteboard generalPasteboard].string = details ?: @"";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:OX_NS("ĐÃ SAO CHÉP ORDER EXPRESS") message:OX_NS("Đã sao chép nhật ký vào bộ nhớ tạm. Dán trực tiếp vào cuộc trò chuyện để kiểm tra.") preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleDefault handler:nil]];
    UIViewController *top = self;
    while (top.presentedViewController) top = top.presentedViewController;
    [top presentViewController:alert animated:YES completion:nil];
}

- (void)r9k2d6 {
    if (!Ongnong::Zx8fAutoMergeAllowed()) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        if (self.k2m8v4) self.k2m8v4.hidden = YES;
        [self q7m2d8];
        return;
    }
    Ongnong::AutoMergeModuleToggle();
    [self c3n7x5];
    [self q7m2d8];
}

- (void)y5v1q8:(UIPanGestureRecognizer *)pan {
    if (!self.k2m8v4 || !self.k2m8v4.superview) return;
    UIView *superview = self.k2m8v4.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) self.a4q9d1 = self.k2m8v4.center;
    else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(self.a4q9d1.x + translation.x, self.a4q9d1.y + translation.y);
        CGFloat halfW = self.k2m8v4.bounds.size.width * 0.5, halfH = self.k2m8v4.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        self.k2m8v4.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = NSUserDefaults.standardUserDefaults;
            [ud setFloat:self.k2m8v4.frame.origin.x forKey:OX_NS("merge_float_x")];
            [ud setFloat:self.k2m8v4.frame.origin.y forKey:OX_NS("merge_float_y")];
            [ud synchronize];
        }
    }
}

- (void)e9m1p7 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoClickAllowed()) { [Z5e8402e1b3 d7x2p6:NO]; [self zShowMainVipRequiredAtIndex:6]; [self q7m2d8]; return; }
    BOOL willShow = ![Z5e8402e1b3 c3n9k5];
    [Z5e8402e1b3 d7x2p6:willShow];
    [self q7m2d8];
    [self w2k7e5:_v2p6k1.a7m1c5.count > 6 ? _v2p6k1.a7m1c5[6] : nil color:RGB(45, 255, 70) active:willShow];
}

- (void)b4x8c3 {
    [self d2x8q4];
    if (!Ongnong::Zx8fToolsAllowed()) { if (_a9q2x4) _a9q2x4.hidden = YES; [self zShowMainVipRequiredAtIndex:7]; [self q7m2d8]; return; }
    BOOL panelVisible = (_a9q2x4 && !_a9q2x4.hidden);
    if (panelVisible) {
        [self zSaveQuickPanelFrame];
        _a9q2x4.hidden = YES;
        _h1x9c5 = YES;
    } else {
        if (!_a9q2x4) return;
        _h1x9c5 = NO;
        if (CGRectIsEmpty(_a9q2x4.frame)) [self p8c4n2];
        _a9q2x4.hidden = NO;
        [self.view bringSubviewToFront:_a9q2x4];
        [self e7k3p9];
        [self zSaveQuickPanelFrame];
    }
    [self q7m2d8];
}

- (void)t6r2n9 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoStopAllowed()) { if (_d2q8n4) _d2q8n4.hidden = YES; [self zShowMainVipRequiredAtIndex:8]; [self q7m2d8]; return; }
    if (!_d2q8n4) return;
    _d2q8n4.hidden = !_d2q8n4.hidden;
    if (!_d2q8n4.hidden) {
        _d2q8n4.v3n8p4 = YES;
        [_d2q8n4 k9m2c8:YES];
        [self.view bringSubviewToFront:_d2q8n4];
    }
    [self q7m2d8];
}

- (void)j3v7q5 {
    [self d2x8q4];
    if (!Ongnong::Zx8fMenuColorAllowed()) { if (_w7p3v6) _w7p3v6.hidden = YES; [self zShowMainVipRequiredAtIndex:9]; [self q7m2d8]; return; }
    if (!_w7p3v6) return;
    _w7p3v6.hidden = !_w7p3v6.hidden;
    [[NSUserDefaults standardUserDefaults] setBool:!_w7p3v6.hidden forKey:ZThemeVisibleKey()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    if (!_w7p3v6.hidden) {
        [_w7p3v6 f5q1m9];
        [self.view bringSubviewToFront:_w7p3v6];
    }
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)d8k4m1 {
    zce119e8048.z7180b46195 = !zce119e8048.z7180b46195;
    Z108056b942();
    [self q7m2d8];
}

- (void)y2p6a9 {
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    zce119e8048.z68593f2227 = (float)[self v3q9a5];
    zce119e8048.zacc65d5e7b = true;
    zce119e8048.z904d9bb65a = false;
    Z108056b942();
    [self q7m2d8];
}

- (void)u7c3x8 {
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    if (Ongnong::AutoBuildModuleIsEnabled()) {
        Ongnong::AutoBuildModuleSetEnabled(false);
        [self f3q6v8];
        if (_v2p6k1.a7m1c5.count > 3) [self w2k7e5:_v2p6k1.a7m1c5[3] color:RGB(50, 190, 255) active:NO];
    }
    zce119e8048.z68593f2227 = (float)[self x8r2n7];
    zce119e8048.zacc65d5e7b = true;
    zce119e8048.z904d9bb65a = false;
    Z108056b942();
    [self q7m2d8];
}

- (void)n5q1r4 {
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    zce119e8048.z904d9bb65a = !zce119e8048.z904d9bb65a;
    zce119e8048.zacc65d5e7b = true;
    Z108056b942();
    [self q7m2d8];
}

- (void)g9v2d6 {
    zce119e8048.z54007f39a0 = !zce119e8048.z54007f39a0;
    Z108056b942();
    [self q7m2d8];
}

- (void)l4m8k3 {
    [self d2x8q4];
    if (!Ongnong::Zx8fCounterAllowed()) { if (_n7c3m8) _n7c3m8.hidden = YES; [self zShowMainVipRequiredAtIndex:2]; [self q7m2d8]; return; }
    [self h2p7m9];
    _n7c3m8.hidden = !_n7c3m8.hidden;
    if (!_n7c3m8.hidden) {
        [_n7c3m8 n4q9c1];
        [self.view bringSubviewToFront:_n7c3m8];
    }
    [self zSaveCounterPanelFrame];
    [self q7m2d8];
}

- (void)x1c7p5 {
    [self d2x8q4];
    if (!Ongnong::Zx8fCounterAllowed()) return;
    Z2b9185919a();
    Z5eca9eb2c9();
}

- (void)q6d9b2 {
    [self h9r3v7];
    CGFloat s = z067adc83c5();
    CGRect z7fa19172fd = _v2p6k1.frame;
    BOOL willCollapse = !_collapsed;

    if (willCollapse) {
        _x5m9c2 = _v2p6k1.frame;
        z7fa19172fd.origin.x = -z7fa19172fd.size.width;
        CGRect handleTarget = [self collapseHandleFrameForMenuFrame:z7fa19172fd collapsed:YES];

        _collapsed = YES;
        [_b3n7v1 setTitle:qsec_s_0081() forState:UIControlStateNormal];
        _v2p6k1.transform = CGAffineTransformIdentity;
        _v2p6k1.frame = z7fa19172fd;
        _b3n7v1.frame = handleTarget;
        return;
    }

    z7fa19172fd = _x5m9c2;
    z7fa19172fd.origin.x = MAX(6.0 * s, z7fa19172fd.origin.x);
    CGRect handleTarget = [self collapseHandleFrameForMenuFrame:z7fa19172fd collapsed:NO];

    [UIView animateWithDuration:0.12 animations:^{
        _v2p6k1.transform = CGAffineTransformIdentity;
        _v2p6k1.frame = z7fa19172fd;
        _b3n7v1.frame = handleTarget;
    } completion:^(BOOL finished) {
        _collapsed = NO;
        [_b3n7v1 setTitle:qsec_s_0038() forState:UIControlStateNormal];
        [self d2x8q4];
    }];
}

- (void)dealloc {
    [self h9r3v7];
    [_timer invalidate];
    _timer = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)v3n8a4:(NSString *)urlString {
    [self d2x8q4];
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:url];
        }
    });
}

- (void)k7p2m6 {
    NSString *url = Ongnong::Zx8fUpdateURL();
    if (url.length == 0) url = OX_NS("https://ongnong.io.vn/chungchi/game-download.php");
    [self v3n8a4:url];
}

- (void)zOpenInternationalCheckout {
    [self d2x8q4];
    NSString *device = Ongnong::Zx8fDeviceId() ?: OX_NS("");
    NSURLComponents *components = [NSURLComponents componentsWithString:OX_NS("https://ongnong.io.vn/pay")];
    if (!components) return;
    NSMutableArray<NSURLQueryItem *> *items = [NSMutableArray array];
    [items addObject:[NSURLQueryItem queryItemWithName:OX_NS("platform") value:OX_NS("ios")]];
    if (device.length > 0) [items addObject:[NSURLQueryItem queryItemWithName:OX_NS("code") value:device]];
    components.queryItems = items;
    NSURL *url = components.URL;
    if (!url) return;
    [self v3n8a4:url.absoluteString];
}

- (void)zShowBuyVipRegionPicker {
    [self d2x8q4];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:OX_NS("MUA VIP") message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:ZVipVietnamCustomerText() style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        [self zBuyVipPayOS];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:ZVipInternationalCustomerText() style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        [self zOpenInternationalCheckout];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *presenter = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (presenter.presentedViewController) presenter = presenter.presentedViewController;
    [presenter presentViewController:alert animated:YES completion:nil];
}

- (void)zBuyVipPayOS {
    [self d2x8q4];
    [self zVipLoadPlans];
}

- (void)zVipLoadPlans {
    NSString *device = Ongnong::Zx8fDeviceId() ?: OX_NS("");
    UIAlertController *loading = [UIAlertController alertControllerWithTitle:ZVipBuyNowText()
                                                                      message:ZuiPick5(OX_NS("Đang tải các gói từ máy chủ..."), OX_NS("正在从服务器加载套餐..."), OX_NS("กำลังโหลดแพ็กเกจจากเซิร์ฟเวอร์..."), OX_NS("Caricamento pacchetti dal server..."), OX_NS("Loading plans from server..."))
                                                               preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:loading animated:YES completion:nil];
    NSURL *url = [NSURL URLWithString:OX_NS("https://ongnong.io.vn/chungchi/keyshop/plans.php")];
    [[[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *json = error ? nil : ZVipJSON(data);
        NSArray *plans = [json[OX_NS("plans")] isKindOfClass:[NSArray class]] ? json[OX_NS("plans")] : nil;
        BOOL ok = [json[OX_NS("ok")] boolValue] && [json[OX_NS("enabled")] boolValue] && plans.count > 0;
        dispatch_async(dispatch_get_main_queue(), ^{
            [loading dismissViewControllerAnimated:NO completion:^{
                if (!ok) {
                    UIAlertController *e = [UIAlertController alertControllerWithTitle:ZVipBuyNowText()
                                                                                message:ZuiPick5(OX_NS("Không tải được gói VIP. Vui lòng thử lại."), OX_NS("无法加载 VIP 套餐，请重试。"), OX_NS("ไม่สามารถโหลดแพ็กเกจ VIP ได้ โปรดลองอีกครั้ง"), OX_NS("Impossibile caricare i pacchetti VIP. Riprova."), OX_NS("Could not load VIP plans. Please try again."))
                                                                         preferredStyle:UIAlertControllerStyleAlert];
                    [e addAction:[UIAlertAction actionWithTitle:ZVipCloseText() style:UIAlertActionStyleCancel handler:nil]];
                    [self presentViewController:e animated:YES completion:nil];
                    return;
                }
                NSString *msg = [NSString stringWithFormat:ZuiPick5(OX_NS("Mã kích hoạt: %@"), OX_NS("激活码：%@"), OX_NS("รหัสเปิดใช้งาน: %@"), OX_NS("Codice attivazione: %@"), OX_NS("Activation code: %@")), device];
                UIAlertController *picker = [UIAlertController alertControllerWithTitle:ZVipChoosePlanText() message:msg preferredStyle:UIAlertControllerStyleAlert];
                [picker addAction:[UIAlertAction actionWithTitle:ZVipCopyText() style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                    UIPasteboard.generalPasteboard.string = device;
                }]];
                for (NSDictionary *p in plans) {
                    NSString *pid = [p[OX_NS("id")] description] ?: OX_NS("");
                    NSInteger amount = [p[OX_NS("amount")] integerValue];
                    NSString *label = [p[OX_NS("label")] description] ?: pid;
                    if (pid.length == 0 || amount <= 0) continue;
                    NSString *title = [NSString stringWithFormat:OX_NS("%@  •  %@"), label, ZVipMoney(amount)];
                    [picker addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                        UIAlertController *wait = [UIAlertController alertControllerWithTitle:label
                                                                                      message:ZuiPick5(OX_NS("Đang tạo mã QR PayOS..."), OX_NS("正在生成 PayOS 二维码..."), OX_NS("กำลังสร้าง QR PayOS..."), OX_NS("Creazione QR PayOS..."), OX_NS("Creating PayOS QR..."))
                                                                               preferredStyle:UIAlertControllerStyleAlert];
                        [self presentViewController:wait animated:YES completion:nil];
                        NSDictionary *body = @{OX_NS("platform"):OX_NS("ios"), OX_NS("plan"):pid, OX_NS("device_id"):device, OX_NS("customer_name"):OX_NS(""), OX_NS("payment_method"):OX_NS("vn"), OX_NS("lang"):OngnongUIVaultResolvedLanguageCode() ?: OX_NS("vi")};
                        NSData *bodyData = [NSJSONSerialization dataWithJSONObject:body options:0 error:nil];
                        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:OX_NS("https://ongnong.io.vn/chungchi/keyshop/create.php")]];
                        req.HTTPMethod = OX_NS("POST");
                        req.timeoutInterval = 10.0;
                        req.HTTPBody = bodyData;
                        [req setValue:OX_NS("application/json; charset=utf-8") forHTTPHeaderField:OX_NS("Content-Type")];
                        [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *d, NSURLResponse *r, NSError *err) {
                            NSDictionary *j = err ? nil : ZVipJSON(d);
                            BOOL created = [j[OX_NS("ok")] boolValue];
                            NSString *order = [j[OX_NS("order_code")] description] ?: OX_NS("");
                            NSString *token = [j[OX_NS("status_token")] description] ?: OX_NS("");
                            NSString *qr = [j[OX_NS("qr_code")] description] ?: OX_NS("");
                            NSInteger finalAmount = [j[OX_NS("amount")] integerValue];
                            if (finalAmount <= 0) finalAmount = amount;
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [wait dismissViewControllerAnimated:NO completion:^{
                                    if (!created || order.length == 0 || token.length == 0 || qr.length == 0) {
                                        UIAlertController *e2 = [UIAlertController alertControllerWithTitle:ZVipBuyNowText()
                                                                                                     message:ZuiPick5(OX_NS("Không tạo được mã QR PayOS. Vui lòng thử lại."), OX_NS("无法创建 PayOS 二维码，请重试。"), OX_NS("ไม่สามารถสร้าง QR PayOS ได้ โปรดลองอีกครั้ง"), OX_NS("Impossibile creare il QR PayOS. Riprova."), OX_NS("Could not create the PayOS QR. Please try again."))
                                                                                              preferredStyle:UIAlertControllerStyleAlert];
                                        [e2 addAction:[UIAlertAction actionWithTitle:ZVipCloseText() style:UIAlertActionStyleCancel handler:nil]];
                                        [self presentViewController:e2 animated:YES completion:nil];
                                        return;
                                    }
                                    ZVipPayController *pay = [[ZVipPayController alloc] init];
                                    pay.orderCode = order;
                                    pay.statusToken = token;
                                    pay.modalPresentationStyle = UIModalPresentationOverFullScreen;
                                    UIView *panel = [[UIView alloc] initWithFrame:CGRectZero];
                                    panel.translatesAutoresizingMaskIntoConstraints = NO;
                                    panel.backgroundColor = [UIColor colorWithWhite:0.10 alpha:0.98];
                                    panel.layer.cornerRadius = 16.0;
                                    panel.layer.borderWidth = 1.0;
                                    panel.layer.borderColor = RGB(60, 180, 90).CGColor;
                                    [pay.view addSubview:panel];
                                    [NSLayoutConstraint activateConstraints:@[[panel.centerXAnchor constraintEqualToAnchor:pay.view.centerXAnchor], [panel.centerYAnchor constraintEqualToAnchor:pay.view.centerYAnchor], [panel.widthAnchor constraintLessThanOrEqualToConstant:390.0], [panel.widthAnchor constraintEqualToAnchor:pay.view.widthAnchor multiplier:0.88]]];
                                    UILabel *pt = [[UILabel alloc] init]; pt.translatesAutoresizingMaskIntoConstraints = NO; pt.textAlignment = NSTextAlignmentCenter; pt.textColor = UIColor.whiteColor; pt.font = [UIFont boldSystemFontOfSize:19.0]; pt.text = [NSString stringWithFormat:OX_NS("%@ — %@"), label, ZVipMoney(finalAmount)]; [panel addSubview:pt];
                                    UIImageView *iv = [[UIImageView alloc] initWithImage:ZVipQRImage(qr, 280.0)]; iv.translatesAutoresizingMaskIntoConstraints = NO; iv.contentMode = UIViewContentModeScaleAspectFit; iv.backgroundColor = UIColor.whiteColor; iv.layer.cornerRadius = 8.0; iv.clipsToBounds = YES; [panel addSubview:iv];
                                    UILabel *st = [[UILabel alloc] init]; st.translatesAutoresizingMaskIntoConstraints = NO; st.textAlignment = NSTextAlignmentCenter; st.numberOfLines = 2; st.textColor = UIColor.whiteColor; st.font = [UIFont boldSystemFontOfSize:14.0]; st.text = ZVipWaitingText(); [panel addSubview:st]; pay.statusLabel = st;
                                    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem]; close.translatesAutoresizingMaskIntoConstraints = NO; [close setTitle:ZVipCloseText() forState:UIControlStateNormal]; [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal]; close.titleLabel.font = [UIFont boldSystemFontOfSize:16.0]; close.backgroundColor = RGB(18, 105, 45); close.layer.cornerRadius = 8.0; [panel addSubview:close];
                                    [NSLayoutConstraint activateConstraints:@[[pt.topAnchor constraintEqualToAnchor:panel.topAnchor constant:16.0], [pt.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:12.0], [pt.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-12.0], [iv.topAnchor constraintEqualToAnchor:pt.bottomAnchor constant:12.0], [iv.centerXAnchor constraintEqualToAnchor:panel.centerXAnchor], [iv.widthAnchor constraintEqualToConstant:280.0], [iv.heightAnchor constraintEqualToConstant:280.0], [st.topAnchor constraintEqualToAnchor:iv.bottomAnchor constant:10.0], [st.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:12.0], [st.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-12.0], [close.topAnchor constraintEqualToAnchor:st.bottomAnchor constant:12.0], [close.centerXAnchor constraintEqualToAnchor:panel.centerXAnchor], [close.widthAnchor constraintEqualToConstant:180.0], [close.heightAnchor constraintEqualToConstant:42.0], [close.bottomAnchor constraintEqualToAnchor:panel.bottomAnchor constant:-16.0]]];
                                    [close addAction:[UIAction actionWithHandler:^(__unused UIAction *action) { pay.stopped = YES; [pay dismissViewControllerAnimated:YES completion:nil]; }] forControlEvents:UIControlEventTouchUpInside];
                                    [self presentViewController:pay animated:YES completion:nil];
                                    __weak ZVipPayController *weakPay = pay;
                                    __block void (^poll)(void) = nil;
                                    poll = ^{
                                        ZVipPayController *strongPay = weakPay;
                                        if (!strongPay || strongPay.stopped) return;
                                        NSString *escapedOrder = [order stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
                                        NSString *escapedToken = [token stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
                                        NSString *u = [NSString stringWithFormat:OX_NS("https://ongnong.io.vn/chungchi/keyshop/status.php?oc=%@&t=%@"), escapedOrder ?: OX_NS(""), escapedToken ?: OX_NS("")];
                                        [[[NSURLSession sharedSession] dataTaskWithURL:[NSURL URLWithString:u] completionHandler:^(NSData *sd, NSURLResponse *sr, NSError *se) {
                                            NSDictionary *sj = se ? nil : ZVipJSON(sd);
                                            BOOL paid = [sj[OX_NS("paid")] boolValue];
                                            BOOL activated = [sj[OX_NS("activated")] boolValue];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                ZVipPayController *pvc = weakPay;
                                                if (!pvc || pvc.stopped) return;
                                                if (activated) {
                                                    pvc.statusLabel.text = ZVipActivatedText();
                                                    Ongnong::Zx8fRefreshNow();
                                                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (!pvc.stopped) { pvc.stopped = YES; [pvc dismissViewControllerAnimated:YES completion:nil]; } });
                                                    return;
                                                }
                                                if (paid) pvc.statusLabel.text = ZVipPaidText();
                                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (poll) poll(); });
                                            });
                                        }] resume];
                                    };
                                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (poll) poll(); });
                                }];
                            });
                        }] resume];
                    }]];
                }
                [picker addAction:[UIAlertAction actionWithTitle:ZVipCloseText() style:UIAlertActionStyleCancel handler:nil]];
                [self presentViewController:picker animated:YES completion:nil];
            }];
        });
    }] resume];
}

- (void)zCollectLabelsFromView:(UIView *)view into:(NSMutableArray<UILabel *> *)labels {
    if (!view) return;
    if ([view isKindOfClass:[UILabel class]]) [labels addObject:(UILabel *)view];
    for (UIView *sub in view.subviews) [self zCollectLabelsFromView:sub into:labels];
}

- (void)zApplyBuyVipStyleInAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle {
    if (!alert || buyTitle.length == 0) return;
    NSMutableArray<UILabel *> *labels = [NSMutableArray array];
    [self zCollectLabelsFromView:alert.view into:labels];
    UIColor *fill = RGB(18, 122, 40);
    UIColor *border = RGB(112, 255, 145);
    for (UILabel *label in labels) {
        if (![label.text isKindOfClass:[NSString class]]) continue;
        if (![label.text isEqualToString:buyTitle]) continue;
        label.textColor = UIColor.whiteColor;
        label.font = [UIFont systemFontOfSize:label.font.pointSize weight:UIFontWeightBlack];
        UIView *target = nil;
        UIView *cursor = label.superview;
        for (NSInteger step = 0; step < 8 && cursor; step++) {
            CGFloat w = cursor.bounds.size.width;
            CGFloat h = cursor.bounds.size.height;
            if (w > 150.0 && h >= 36.0 && h <= 80.0) {
                target = cursor;
                break;
            }
            cursor = cursor.superview;
        }
        if (!target) continue;
        target.backgroundColor = fill;
        target.layer.cornerRadius = 15.0;
        target.layer.masksToBounds = YES;
        target.layer.borderWidth = 1.3;
        target.layer.borderColor = border.CGColor;
    }
}

- (void)zStyleBuyVipAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle {
    if (!alert || buyTitle.length == 0) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.02 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self zApplyBuyVipStyleInAlert:alert buyTitle:buyTitle];
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.18 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self zApplyBuyVipStyleInAlert:alert buyTitle:buyTitle];
    });
}

- (void)zCustomUINameEditorForTarget:(NSString *)target title:(NSString *)targetTitle {
    NSString *current = Ongnong::Zx8fCustomUINameForTarget(target) ?: OX_NS("");
    UIAlertController *a = [UIAlertController alertControllerWithTitle:targetTitle
                                                               message:ZuiPick5(OX_NS("Tự đặt tên, tối đa 16 ký tự"), OX_NS("自定义名称，最多16个字符"), OX_NS("ตั้งชื่อเอง สูงสุด 16 ตัวอักษร"), OX_NS("Nome personalizzato, massimo 16 caratteri"), OX_NS("Custom name, maximum 16 characters"))
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *f) {
        f.text = current;
        f.placeholder = ZuiPick5(OX_NS("Nhập tên muốn hiển thị"), OX_NS("输入显示名称"), OX_NS("ใส่ชื่อที่ต้องการแสดง"), OX_NS("Inserisci il nome da mostrare"), OX_NS("Enter display name"));
        f.autocapitalizationType = UITextAutocapitalizationTypeSentences;
        f.autocorrectionType = UITextAutocorrectionTypeNo;
        f.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("LƯU"), OX_NS("保存"), OX_NS("บันทึก"), OX_NS("SALVA"), OX_NS("SAVE")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        NSString *name = a.textFields.firstObject.text ?: OX_NS("");
        Ongnong::Zx8fSetCustomUINameForTarget(target, name);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self zBrandProfileEditor];
        });
    }]];
    if (current.length > 0) {
        [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("DÙNG MẶC ĐỊNH"), OX_NS("使用默认"), OX_NS("ใช้ค่าเริ่มต้น"), OX_NS("USA PREDEFINITO"), OX_NS("USE DEFAULT")) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *x) {
            Ongnong::Zx8fSetCustomUINameForTarget(target, OX_NS(""));
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self zBrandProfileEditor];
            });
        }]];
    }
    [a addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)zBrandProfileEditor {
    if (!Ongnong::Zx8fIsVIP()) {
        UIAlertController *vip = [UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("CẦN NÂNG CẤP VIP"), OX_NS("需要升级 VIP"), OX_NS("ต้องอัปเกรด VIP"), OX_NS("PASSA A VIP"), OX_NS("VIP UPGRADE REQUIRED"))
                                                                    message:nil
                                                             preferredStyle:UIAlertControllerStyleAlert];
        [vip addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:vip animated:YES completion:nil];
        return;
    }

    UIAlertController *a = [UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("ĐỔI GIAO DIỆN"), OX_NS("更改界面"), OX_NS("เปลี่ยนอินเทอร์เฟซ"), OX_NS("CAMBIA INTERFACCIA"), OX_NS("CHANGE INTERFACE"))
                                                               message:ZuiPick5(OX_NS("Chọn vị trí muốn đổi tên"), OX_NS("选择要改名的位置"), OX_NS("เลือกตำแหน่งที่ต้องการเปลี่ยนชื่อ"), OX_NS("Scegli dove cambiare il nome"), OX_NS("Choose where to change the name"))
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("TÊN CHÍNH"), OX_NS("主标题"), OX_NS("ชื่อหลัก"), OX_NS("NOME PRINCIPALE"), OX_NS("MAIN NAME")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        [self zCustomUINameEditorForTarget:OX_NS("main_title") title:ZuiPick5(OX_NS("TÊN CHÍNH"), OX_NS("主标题"), OX_NS("ชื่อหลัก"), OX_NS("NOME PRINCIPALE"), OX_NS("MAIN NAME"))];
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("BẢNG ĐẾM TỔNG"), OX_NS("总计数器"), OX_NS("ตารางนับรวม"), OX_NS("CONTATORE TOTALE"), OX_NS("TOTAL COUNTER")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        [self zCustomUINameEditorForTarget:OX_NS("counter_title") title:ZuiPick5(OX_NS("BẢNG ĐẾM TỔNG"), OX_NS("总计数器"), OX_NS("ตารางนับรวม"), OX_NS("CONTATORE TOTALE"), OX_NS("TOTAL COUNTER"))];
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("FPS / FOOTER"), OX_NS("FPS / 底部"), OX_NS("FPS / ด้านล่าง"), OX_NS("FPS / FOOTER"), OX_NS("FPS / FOOTER")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        [self zCustomUINameEditorForTarget:OX_NS("footer_name") title:OX_NS("FPS / FOOTER")];
    }]];
    NSString *fpsToggleTitle = Ongnong::Zx8fFPSVisible()
        ? ZuiPick5(OX_NS("ẨN FPS"), OX_NS("隐藏 FPS"), OX_NS("ซ่อน FPS"), OX_NS("NASCONDI FPS"), OX_NS("HIDE FPS"))
        : ZuiPick5(OX_NS("HIỆN FPS"), OX_NS("显示 FPS"), OX_NS("แสดง FPS"), OX_NS("MOSTRA FPS"), OX_NS("SHOW FPS"));
    [a addAction:[UIAlertAction actionWithTitle:fpsToggleTitle style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        Ongnong::Zx8fSetFPSVisible(!Ongnong::Zx8fFPSVisible());
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self zBrandProfileEditor];
        });
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("KHÔI PHỤC MẶC ĐỊNH"), OX_NS("恢复默认"), OX_NS("คืนค่าเริ่มต้น"), OX_NS("RIPRISTINA PREDEFINITO"), OX_NS("RESTORE DEFAULT")) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *x) {
        Ongnong::Zx8fResetAllCustomUINames();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self zBrandProfileEditor];
        });
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)d4u8s0 {
    [self d2x8q4];
    NSString *device = Ongnong::Zx8fDeviceId() ?: @"";
    NSString *message = [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultVipActivationMessageFormat), device];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:OngnongUIVaultText(OngnongUIVaultVipActivationTitle)
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultVipCopyActivation) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        UIPasteboard.generalPasteboard.string = device;
    }]];
    BOOL isVIP = Ongnong::Zx8fIsVIP();
    NSString *buyTitle = ZVipVietnamCustomerText();
    NSString *internationalTitle = ZVipInternationalCustomerText();
    if (isVIP) {
        NSString *enrollURL = Ongnong::Zx8fEnrollmentURL();
        if (enrollURL.length > 0) {
            [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultVipRestoreActivation) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                [self v3n8a4:enrollURL];
            }]];
        }
    } else {
        [alert addAction:[UIAlertAction actionWithTitle:buyTitle style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            [self zBuyVipPayOS];
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:internationalTitle style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            [self zOpenInternationalCheckout];
        }]];
        NSString *enrollURL = Ongnong::Zx8fEnrollmentURL();
        if (enrollURL.length > 0) {
            [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultFreeRestoreVipAction) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                [self v3n8a4:enrollURL];
            }]];
        }
    }
    [alert addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("ĐỔI GIAO DIỆN"), OX_NS("更改界面"), OX_NS("เปลี่ยนอินเทอร์เฟซ"), OX_NS("CAMBIA INTERFACCIA"), OX_NS("CHANGE INTERFACE")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        [self zBrandProfileEditor];
    }]];
    if (!isVIP) {
        [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultVipContactBuy) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            [self v3n8a4:OX_NS("https://zalo.me/84702136078")];
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:^{
        if (!isVIP) {
            [self zStyleBuyVipAlert:alert buyTitle:buyTitle];
            [self zStyleBuyVipAlert:alert buyTitle:internationalTitle];
        }
    }];
}

- (void)ongFriendClearLink:(UIButton *)sender {
    UIView *view = sender;
    UITextField *field = nil;
    while (view) {
        if ([view isKindOfClass:[UITextField class]]) { field = (UITextField *)view; break; }
        view = view.superview;
    }
    if (!field && [self.presentedViewController isKindOfClass:[UIAlertController class]]) {
        UIAlertController *alert = (UIAlertController *)self.presentedViewController;
        field = alert.textFields.firstObject;
    }
    field.text = @"";
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:OX_NS("ong_friend_last_link")];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)ongFriendModule {
    Z0418c1e0ae();
    if (!Ongnong::Zx8fFriendInviteAllowed()) { [self zShowMainVipRequiredAtIndex:13]; [self q7m2d8]; return; }
    UIAlertController *a=[UIAlertController alertControllerWithTitle:ZuiFriendInviteText() message:Ongnong::FriendInviteStatus() preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *f){
        f.placeholder=ZuiPick5(OX_NS("DÁN LINK MỜI CỦA NGƯỜI KHÁC"), OX_NS("粘贴其他玩家的邀请链接"), OX_NS("วางลิงก์เชิญของผู้เล่นอื่น"), OX_NS("INCOLLA IL LINK INVITO DI UN ALTRO GIOCATORE"), OX_NS("PASTE ANOTHER PLAYER'S INVITE LINK"));
        f.text=[[NSUserDefaults standardUserDefaults] stringForKey:OX_NS("ong_friend_last_link")];
        f.autocapitalizationType=UITextAutocapitalizationTypeNone;
        f.autocorrectionType=UITextAutocorrectionTypeNo;
        UIButton *clear=[UIButton buttonWithType:UIButtonTypeSystem];
        clear.frame=CGRectMake(0,0,54,30);
        [clear setTitle:ZuiFriendClearText() forState:UIControlStateNormal];
        clear.titleLabel.font=[UIFont boldSystemFontOfSize:13.0];
        [clear addTarget:self action:@selector(ongFriendClearLink:) forControlEvents:UIControlEventTouchUpInside];
        f.rightView=clear;
        f.rightViewMode=UITextFieldViewModeAlways;
    }];
    __weak UIAlertController *wa=a;
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("GỬI"), OX_NS("发送"), OX_NS("ส่ง"), OX_NS("INVIA"), OX_NS("SEND")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x){
        NSString *link=wa.textFields.firstObject.text ?: @"";
        if (link.length) {
            [[NSUserDefaults standardUserDefaults] setObject:link forKey:OX_NS("ong_friend_last_link")];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        BOOL ok=Ongnong::FriendInviteSend(link);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(1.2*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
            UIAlertController *r=[UIAlertController alertControllerWithTitle:ZuiFriendInviteText() message:(ok?Ongnong::FriendInviteStatus():ZuiPick5(OX_NS("LINK KHÔNG HỢP LỆ"), OX_NS("链接无效"), OX_NS("ลิงก์ไม่ถูกต้อง"), OX_NS("LINK NON VALIDO"), OX_NS("INVALID LINK"))) preferredStyle:UIAlertControllerStyleAlert];
            [r addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:r animated:YES completion:nil];
        });
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("LINK CỦA TÔI"), OX_NS("我的链接"), OX_NS("ลิงก์ของฉัน"), OX_NS("IL MIO LINK"), OX_NS("MY LINK")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x){
        if (!Ongnong::FriendInviteOpenMine()) {
            UIAlertController *r=[UIAlertController alertControllerWithTitle:ZuiFriendInviteText() message:ZuiPick5(OX_NS("GAME CHƯA SẴN SÀNG"), OX_NS("游戏尚未就绪"), OX_NS("เกมยังไม่พร้อม"), OX_NS("IL GIOCO NON È PRONTO"), OX_NS("GAME NOT READY")) preferredStyle:UIAlertControllerStyleAlert];
            [r addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:r animated:YES completion:nil];
        }
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("ĐÓNG"), OX_NS("关闭"), OX_NS("ปิด"), OX_NS("CHIUDI"), OX_NS("CLOSE")) style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)ongPotionModule {
    Z0418c1e0ae();
    if (!Ongnong::Zx8fPotionAllowed()) { Ongnong::AutoPotionSetEnabled(NO); [self zShowMainVipRequiredAtIndex:14]; [self q7m2d8]; return; }
    BOOL wasOn=Ongnong::AutoPotionIsEnabled();
    Ongnong::AutoPotionSetEnabled(wasOn ? NO : YES);

    
    
    Zcb66126fa3 *immediatePotionButton=(_v2p6k1.a7m1c5.count > 14) ? _v2p6k1.a7m1c5[14] : nil;
    if (immediatePotionButton) {
        BOOL immediateOn=Ongnong::AutoPotionIsEnabled();
        immediatePotionButton.x9c4n6.text=ZuiPotionStateText(immediateOn);
        [self w2k7e5:immediatePotionButton color:RGB(185, 105, 255) active:immediateOn];
        [immediatePotionButton setNeedsLayout];
        [_v2p6k1 setNeedsLayout];
    }

    UIAlertController *a=[UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("NHẬN THUỐC"), OX_NS("领取药水"), OX_NS("รับยา"), OX_NS("RITIRA POZIONE"), OX_NS("COLLECT POTION"))
                                                              message:Ongnong::AutoPotionStatus()
                                                       preferredStyle:UIAlertControllerStyleAlert];
    __weak UIAlertController *weakPotionAlert=a;
    [a addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];

    
    
    NSArray<NSNumber *> *delays=@[@0.35,@0.8,@1.3,@2.0,@3.0,@5.0,@8.0];
    for (NSNumber *delayNumber in delays) {
        NSTimeInterval d=delayNumber.doubleValue;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(d*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
            BOOL success=Ongnong::AutoPotionIsEnabled();
            NSString *status=Ongnong::AutoPotionStatus();
            UIAlertController *liveAlert=weakPotionAlert;
            if (liveAlert && liveAlert.presentingViewController) {
                liveAlert.message=status;
                if (success) liveAlert.title=ZuiPick5(OX_NS("NHẬN THUỐC - THÀNH CÔNG"), OX_NS("领取药水 - 成功"), OX_NS("รับยา - สำเร็จ"), OX_NS("RITIRA POZIONE - RIUSCITO"), OX_NS("COLLECT POTION - SUCCESS"));
            }

            Zcb66126fa3 *potionButton=(self->_v2p6k1.a7m1c5.count > 14) ? self->_v2p6k1.a7m1c5[14] : nil;
            if (potionButton) {
                potionButton.x9c4n6.text=ZuiPotionStateText(success);
                [self w2k7e5:potionButton color:RGB(185, 105, 255) active:success];
                [potionButton setNeedsLayout];
            }
            [self->_v2p6k1 setNeedsLayout];
        });
    }
}

@end

static Z68534fe442 *gWindow = nil;
static Z9abcb7bb90 *gController = nil;

static UIWindow *Z75012fe6de(void) {
    if (@available(iOS 13.0, *)) {
        UIWindow *fallback = nil;
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            UIWindowScene *windowScene = (UIWindowScene *)scene;
            for (UIWindow *window in windowScene.windows) {
                if (!fallback && !window.hidden) fallback = window;
                if (scene.activationState == UISceneActivationStateForegroundActive && window.isKeyWindow) return window;
            }
            if (scene.activationState == UISceneActivationStateForegroundActive && windowScene.windows.count) return windowScene.windows.firstObject;
        }
        if (fallback) return fallback;
    }
    UIWindow *keyWindow = UIApplication.sharedApplication.keyWindow;
    if (keyWindow) return keyWindow;
    return UIApplication.sharedApplication.windows.firstObject;
}

static UIWindowScene *Z75012fe6dd(void) {
    if (@available(iOS 13.0, *)) {
        UIWindow *host = Z75012fe6de();
        if (host.windowScene) return host.windowScene;
        UIWindowScene *fallback = nil;
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            UIWindowScene *windowScene = (UIWindowScene *)scene;
            if (!fallback) fallback = windowScene;
            if (scene.activationState == UISceneActivationStateForegroundActive) return windowScene;
            if (scene.activationState == UISceneActivationStateForegroundInactive) fallback = windowScene;
        }
        return fallback;
    }
    return nil;
}

namespace Ongnong {

void Z75012fe6dc() {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gWindow) {
            gWindow.hidden = NO;
            return;
        }
        UIWindow *hostWindow = Z75012fe6de();
        CGRect frame = hostWindow ? hostWindow.bounds : UIScreen.mainScreen.bounds;
        if (@available(iOS 13.0, *)) {
            UIWindowScene *windowScene = Z75012fe6dd();
            if (windowScene) {
                gWindow = [[Z68534fe442 alloc] initWithWindowScene:windowScene];
                frame = windowScene.coordinateSpace.bounds;
                gWindow.frame = frame;
            }
        }
        if (!gWindow) gWindow = [[Z68534fe442 alloc] initWithFrame:frame];
        gWindow.backgroundColor = [UIColor clearColor];
        gWindow.windowLevel = UIWindowLevelAlert + 20;
        gController = [[Z9abcb7bb90 alloc] init];
        gWindow.rootViewController = gController;
        [gWindow makeKeyAndVisible];
        [gController.view setNeedsLayout];
        [gController.view layoutIfNeeded];
        if (hostWindow && hostWindow != gWindow) [hostWindow makeKeyWindow];
    });
}

}
