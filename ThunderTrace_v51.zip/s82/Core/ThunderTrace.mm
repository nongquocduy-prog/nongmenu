#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>
#include <dlfcn.h>
#import "../PatchNonJB/PatchNonJB.h"
#import "../Helper/Il2cpp.h"

static NSMutableArray<NSString *> *thLines;
static NSLock *thLock;
static void THLog(NSString *s) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{ thLines=[NSMutableArray new]; thLock=[NSLock new]; });
    [thLock lock];
    [thLines addObject:[NSString stringWithFormat:@"%.3f %@",[NSDate timeIntervalSinceReferenceDate],s]];
    while (thLines.count>300) [thLines removeObjectAtIndex:0];
    [thLock unlock];
}
static NSString *THCopy(void) {
    [thLock lock]; NSString *s=[thLines componentsJoinedByString:@"\n"]; [thLock unlock];
    return [@"ONGNONG THUNDER TRACE (READ ONLY)\n" stringByAppendingString:s ?: @""];
}
@interface THButton : UIButton
@end
@implementation THButton
- (void)didMoveToWindow { [super didMoveToWindow]; }
@end
@interface THOverlay : NSObject
@property(nonatomic,strong) THButton *button;
@end
@implementation THOverlay
- (void)tapped:(id)sender { THLog(@"TRACE_BUTTON_TAP logger=ok"); }
- (void)hold:(UILongPressGestureRecognizer *)g {
    if (g.state!=UIGestureRecognizerStateBegan) return;
    [UIPasteboard generalPasteboard].string=THCopy();
    [self.button setTitle:@"COPIED" forState:UIControlStateNormal];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{ [self.button setTitle:@"THUNDER TRACE" forState:UIControlStateNormal]; });
}
- (void)pan:(UIPanGestureRecognizer *)g {
    UIView *v=self.button; CGPoint p=[g translationInView:v.superview];
    v.center=CGPointMake(v.center.x+p.x,v.center.y+p.y); [g setTranslation:CGPointZero inView:v.superview];
}
- (void)show {
    UIWindow *w=nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        if (scene.activationState!=UISceneActivationStateForegroundActive) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) if (candidate.isKeyWindow) {w=candidate;break;}
        if (w) break;
    }
    if (!w) w=UIApplication.sharedApplication.keyWindow;
    if (!w) { dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{[self show];}); return; }
    if (self.button.superview==w) return;
    THButton *b=[THButton buttonWithType:UIButtonTypeCustom];
    b.frame=CGRectMake(5,300,135,38); b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.8];
    b.layer.cornerRadius=11; b.layer.borderWidth=1; b.layer.borderColor=UIColor.cyanColor.CGColor;
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12]; [b setTitle:@"THUNDER TRACE" forState:UIControlStateNormal];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
    UILongPressGestureRecognizer *hold=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(hold:)];
    hold.minimumPressDuration=0.75; [b addGestureRecognizer:hold];
    [b addTarget:self action:@selector(tapped:) forControlEvents:UIControlEventTouchUpInside];
    [w addSubview:b]; self.button=b;
}
@end
static THOverlay *thOverlay;
static void THButtonTap(void) { THLog(@"TRACE_BUTTON_TAP logger=ok"); }

static void *(*thSpin)(void *,void *)=NULL;
static void *(*thResult)(void *,void *,int,void *)=NULL;
static void *(*thGrand)(void *,bool,int,void *,void *)=NULL;
static void (*thViewClick)(void *,void *)=NULL;
static void *(*thActive)(void *,void *)=NULL;
static void THViewClick(void *self,void *method) {
    THLog(@"VIEW_ON_SPIN_CLICKED"); if (thViewClick) thViewClick(self,method);
}
static void *THActive(void *self,void *method) {
    THLog(@"SPIN_ACTIVE_STATE"); return thActive ? thActive(self,method):NULL;
}
static void *THSpin(void *self,void *method) {
    THLog(@"SPIN_CLICK"); return thSpin ? thSpin(self,method):NULL;
}
static void *THResult(void *self,void *response,int before,void *method) {
    THLog([NSString stringWithFormat:@"SPIN_RESULT beforeTokens=%d responsePresent=%d",before,response!=NULL]);
    return thResult ? thResult(self,response,before,method):NULL;
}
static void *THGrand(void *self,bool newSkin,int iteration,void *loadTask,void *method) {
    THLog([NSString stringWithFormat:@"GRAND_PRIZE newSkin=%d iterationBeforeSwitch=%d",(int)newSkin,iteration]);
    return thGrand ? thGrand(self,newSkin,iteration,loadTask,method):NULL;
}
typedef void *(*THDomainGetFn)(void);
typedef void *(*THMethodFindFn)(void *, const char *, int);
// Direct ThunderSpinController read-only instrumentation.
static void *(*thTSStart)(void *,void *)=NULL;
static void *(*thTSStop)(void *,void *)=NULL;
static bool (*thTSValidate)(void *,void **,void **,void *)=NULL;
static void (*thTSCashback)(void *,void *,void *,void *)=NULL;
static void (*thTSMultiplier)(void *,void *,void *,void *)=NULL;
static void *(*thTSAfter)(void *,void *)=NULL;
static void *(*thTSFlow)(void *,void *)=NULL;
static void (*thTSUpdate)(void *,void *)=NULL;
static void *TH_TS_Start(void *o,void *m) { THLog([NSString stringWithFormat:@"THUNDER_START_SPIN controller=%p initialized=%d",o,o!=NULL]); return thTSStart?thTSStart(o,m):NULL; }
static void *TH_TS_Stop(void *o,void *m) { THLog([NSString stringWithFormat:@"THUNDER_STOP_SPIN controller=%p initialized=%d",o,o!=NULL]); return thTSStop?thTSStop(o,m):NULL; }
static bool TH_TS_Validate(void *o,void **a,void **b,void *m) {
    THLog(@"THUNDER_VALIDATE_ENTER"); bool r=thTSValidate?thTSValidate(o,a,b,m):false;
    THLog([NSString stringWithFormat:@"THUNDER_VALIDATE_EXIT ok=%d thunder=%d wheel=%d",(int)r,a&&*a!=NULL,b&&*b!=NULL]); return r;
}
static void TH_TS_Cashback(void *o,void *a,void *b,void *m) { THLog(@"THUNDER_CASHBACK"); if(thTSCashback)thTSCashback(o,a,b,m); }
static void TH_TS_Multiplier(void *o,void *a,void *b,void *m) { THLog(@"THUNDER_MULTIPLIER_WIN"); if(thTSMultiplier)thTSMultiplier(o,a,b,m); }
static void *TH_TS_After(void *o,void *m) { THLog(@"THUNDER_AFTER_SPIN"); return thTSAfter?thTSAfter(o,m):NULL; }
static void *TH_TS_Flow(void *o,void *m) { THLog(@"THUNDER_FLOW_AFTER_SPIN"); return thTSFlow?thTSFlow(o,m):NULL; }
static void TH_TS_Update(void *o,void *m) { THLog(@"THUNDER_LIMIT_UPDATE"); if(thTSUpdate)thTSUpdate(o,m); }
static bool thTSInstalled[8]={false};
static bool thThunderClassFound=false;
static int thThunderAttempts=0;
static void THInstallThunder(THMethodFindFn methodFind) {
    ++thThunderAttempts;
    const char *img=NULL;
    void *klass=Il2CppFindClassAnyImage("MoonActive.TokenWheel.ThunderSpin","ThunderSpinController",&img);
    thThunderClassFound=(klass!=NULL);
    THLog([NSString stringWithFormat:@"THUNDER_CONTROLLER_STATE attempt=%d classFound=%d class=%p methodResolver=%d",thThunderAttempts,thThunderClassFound,klass,methodFind!=NULL]);
    if(!klass || !methodFind) { THLog([NSString stringWithFormat:@"THUNDER_RESOLVE missing class=%p methodFind=%d",klass,methodFind!=NULL]); return; }
    THLog([NSString stringWithFormat:@"THUNDER_RESOLVE image=%s class=%p",img?img:"?",klass]);
    const char *lifecycle[]={".ctor","Awake","Start","OnEnable","Initialize","Init"};
    for(int j=0;j<6;j++){
        void *lm=methodFind(klass,lifecycle[j],-1);
        THLog([NSString stringWithFormat:@"THUNDER_LIFECYCLE_METHOD name=%s found=%d method=%p",lifecycle[j],lm!=NULL,lm]);
    }
    const char *names[]={"StartSpin","StopSpin","TryValidateSpinResult","StopSpinOnCashback","StopSpinOnMultiplierWin","AfterSpinFlowEnded","HandleThunderSpinFlowAfterSpin","UpdateLimitUsages"};
    const int counts[]={0,0,2,2,2,0,0,0};
    void *hooks[]={(void*)TH_TS_Start,(void*)TH_TS_Stop,(void*)TH_TS_Validate,(void*)TH_TS_Cashback,(void*)TH_TS_Multiplier,(void*)TH_TS_After,(void*)TH_TS_Flow,(void*)TH_TS_Update};
    void **originals[]={(void**)&thTSStart,(void**)&thTSStop,(void**)&thTSValidate,(void**)&thTSCashback,(void**)&thTSMultiplier,(void**)&thTSAfter,(void**)&thTSFlow,(void**)&thTSUpdate};
    for(int i=0;i<8;i++) {
        if(thTSInstalled[i])continue;
        void *mi=methodFind(klass,names[i],counts[i]); void *addr=mi?*(void**)mi:NULL;
        if(!addr){THLog([NSString stringWithFormat:@"THUNDER_HOOK_%d %s unresolved",i,names[i]]);continue;}
        int status=DobbyHook(addr,hooks[i],originals[i]);
        thTSInstalled[i]=(status==0 && *originals[i]!=NULL);
        THLog([NSString stringWithFormat:@"THUNDER_HOOK_%d %s address=%p status=%d installed=%d",i,names[i],addr,status,thTSInstalled[i]]);
    }
}

static int thAttempt=0;
static bool thInstalled[5]={false,false,false,false,false};
static void THInstall(void) {
    ++thAttempt;
    THDomainGetFn domainGet=(THDomainGetFn)dlsym(RTLD_DEFAULT,"il2cpp_domain_get");
    THMethodFindFn methodFind=(THMethodFindFn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_method_from_name");
    const char *imageName=NULL;
    void *klass=Il2CppFindClassAnyImage("TokenWheel.MVC","TokenWheelPopupController",&imageName);
    if (!klass) {
        THLog([NSString stringWithFormat:@"RESOLVE attempt=%d class=missing runtime=%d",thAttempt,domainGet!=NULL]);
    } else {
        THLog([NSString stringWithFormat:@"RESOLVE attempt=%d image=%s class=%p",thAttempt,imageName?imageName:"?",klass]);
        const char *names[]={"SpinClicked","ProcessSuccessSpinRequest","ProcessGrandPrize","OnSpinClicked","SpinClickedActiveState"};
        const int counts[]={0,2,3,0,0};
        void *hooks[]={(void*)THSpin,(void*)THResult,(void*)THGrand,(void*)THViewClick,(void*)THActive};
        void **originals[]={(void**)&thSpin,(void**)&thResult,(void**)&thGrand,(void**)&thViewClick,(void**)&thActive};
        for (int i=0;i<5;i++) {
            const char *targetImage=NULL;
            void *targetClass=(i==3) ? Il2CppFindClassAnyImage("TokenWheel.MVC","TokenWheelPopupView",&targetImage) : klass;
            if (!targetClass) { THLog([NSString stringWithFormat:@"HOOK_%d class_missing",i]); continue; }
            if (thInstalled[i]) continue;
            void *method=methodFind ? methodFind(targetClass,names[i],counts[i]) : NULL;
            void *addr=method ? *(void**)method : NULL;
            if (!addr) {
                THLog([NSString stringWithFormat:@"HOOK_%d unresolved method=%p",i,method]);
                continue;
            }
            int result=DobbyHook(addr,hooks[i],originals[i]);
            thInstalled[i]=(result==0 && *originals[i]!=NULL);
            THLog([NSString stringWithFormat:@"HOOK_%d address=%p status=%d original=%p installed=%d",i,addr,result,*originals[i],thInstalled[i]]);
        }
    }
    THInstallThunder(methodFind);
    bool allThunder=true; for(int i=0;i<8;i++) if(!thTSInstalled[i]) allThunder=false;
    THLog([NSString stringWithFormat:@"THUNDER_INSTALL_SUMMARY classFound=%d installed=%d/8",thThunderClassFound,([&](){int n=0;for(int i=0;i<8;i++)n+=thTSInstalled[i];return n;})()]);
    if ((!(thInstalled[0]&&thInstalled[1]&&thInstalled[2]&&thInstalled[3]&&thInstalled[4]) || !allThunder) && thAttempt<20) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(1.5*NSEC_PER_SEC)),dispatch_get_main_queue(),^{THInstall();});
    }
}
extern "C" void OngnongThunderTraceStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        THLog(@"TRACE_INIT v51");
        thOverlay=[THOverlay new];
        dispatch_async(dispatch_get_main_queue(),^{[thOverlay show]; THInstall();});
    });
}
