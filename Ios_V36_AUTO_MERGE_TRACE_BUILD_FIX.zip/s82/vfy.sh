#!/bin/sh
set -e
target="$1"
[ -n "$target" ] && [ -f "$target" ]
base=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
cd "$base"
if LC_ALL=C grep -Eq 'ONGNONG_INTERNAL_TEST|ONGNONG_TEST_DEFINE' Makefile Core/R7f7.mm Core/zx8f1a_gate.mm; then
    echo "[SECURITY FAIL] test branch enabled"
    exit 1
fi
if LC_ALL=C grep -Eq 'g_zx8fActivatedLicense\.store\(true|g_zx8fModuleMask\.store\(~0u|BOOL[[:space:]]+Zx8f(Allowed|MenuAllowed|SpeedAllowed|CounterAllowed|PotionAllowed|TokenAllowed|LightningAllowed|BetCycleAllowed|AutoMergeAllowed|AutoClickAllowed|RaidHammerAllowed|ToolsAllowed|AutoStopAllowed|MenuColorAllowed|FriendInviteAllowed|IsVIP|AutoBuildAllowed|MagicCardsAllowed|ExpeditionAllowed)\(void\)[[:space:]]*\{[[:space:]]*return[[:space:]]+YES;' Core/zx8f1a_gate.mm; then
    echo "[SECURITY FAIL] release gate bypass remains"
    exit 1
fi
if LC_ALL=C grep -Eq 'auto_merge_state\.log|AUTO_MERGE_S100_CORE_TRACE|PREPARE_|diag\(' Core/Qr74m.mm; then
    echo "[SECURITY FAIL] auto merge trace remains"
    exit 1
fi
for source in $(find Core UI Autoclick FPSDisplay Helper PatchNonJB -type f \( -name '*.h' -o -name '*.m' -o -name '*.mm' -o -name '*.c' -o -name '*.cc' -o -name '*.cpp' \)); do
    if LC_ALL=C grep -Eq '^[[:space:]]*//|/\*|\*/' "$source"; then
        echo "[SECURITY FAIL] source comment: $source"
        exit 1
    fi
done
for source in $(find Core UI Autoclick FPSDisplay Helper PatchNonJB -type f -name '*.m'); do
    if LC_ALL=C grep -Eq 'OX_(NS|C)\(' "$source"; then
        echo "[SECURITY FAIL] C++ string macro in Objective-C source: $source"
        exit 1
    fi
done
if ! LC_ALL=C grep -Fq 'ZX8F_M_AUTO_MERGE' Core/zx8f1a_gate.mm ||
   ! LC_ALL=C grep -Fq 'Zx8fAutoMergeAllowed' Core/zx8f1a_gate.h ||
   ! LC_ALL=C grep -Fq 'OX_NS("auto_merge")' Core/zx8f1a_gate.mm ||
   ! LC_ALL=C grep -Fq 'Zx8fAutoMergeAllowed' Core/Qr74m.mm ||
   ! LC_ALL=C grep -Fq 'OngnongUIVaultAutoMergeOn' UI/OngnongMenuView.mm; then
    echo "[SECURITY FAIL] auto merge release gate incomplete"
    exit 1
fi
for pair in \
    'ZX8F_M_MENU:kModuleMenu:Zx8fMenuAllowed' \
    'ZX8F_M_SPEED:kModuleSpeed:Zx8fSpeedAllowed' \
    'ZX8F_M_COUNTER:kModuleCounter:Zx8fCounterAllowed' \
    'ZX8F_M_POTION:kModulePotion:Zx8fPotionAllowed' \
    'ZX8F_M_TOKEN:kModuleToken:Zx8fTokenAllowed' \
    'ZX8F_M_LIGHTNING:kModuleLightning:Zx8fLightningAllowed' \
    'ZX8F_M_BET_CYCLE:kModuleBetCycle:Zx8fBetCycleAllowed'
do
    bit=${pair%%:*}
    rest=${pair#*:}
    keyfn=${rest%%:*}
    fn=${rest##*:}
    if ! LC_ALL=C grep -Fq "$bit" Core/zx8f1a_gate.mm ||
       ! LC_ALL=C grep -Fq "$keyfn()" Core/zx8f1a_gate.mm ||
       ! LC_ALL=C grep -Fq "$keyfn(void)" Core/zx8f1a_strings.h ||
       ! LC_ALL=C grep -Fq "$fn" Core/zx8f1a_gate.h ||
       ! LC_ALL=C grep -Fq "$fn" Core/zx8f1a_gate.mm; then
        echo "[SECURITY FAIL] module gate incomplete: $keyfn"
        exit 1
    fi
done
for pair in \
    'ZX8F_M_AUTO_BUILD:auto_build:Zx8fAutoBuildAllowed' \
    'ZX8F_M_MAGIC_CARDS:magic_cards:Zx8fMagicCardsAllowed' \
    'ZX8F_M_EXPEDITION:auto_expedition:Zx8fExpeditionAllowed' \
    'ZX8F_M_AUTO_MERGE:auto_merge:Zx8fAutoMergeAllowed' \
    'ZX8F_M_AUTO_CLICK:auto_click:Zx8fAutoClickAllowed' \
    'ZX8F_M_RAID_HAMMER:raid_hammer:Zx8fRaidHammerAllowed' \
    'ZX8F_M_TOOLS:tools:Zx8fToolsAllowed' \
    'ZX8F_M_AUTO_STOP:auto_stop:Zx8fAutoStopAllowed' \
    'ZX8F_M_MENU_COLOR:menu_color:Zx8fMenuColorAllowed' \
    'ZX8F_M_FRIEND_INVITE:friend_invite:Zx8fFriendInviteAllowed'
do
    bit=${pair%%:*}
    rest=${pair#*:}
    key=${rest%%:*}
    fn=${rest##*:}
    if ! LC_ALL=C grep -Fq "$bit" Core/zx8f1a_gate.mm ||
       ! LC_ALL=C grep -Fq "OX_NS(\"$key\")" Core/zx8f1a_gate.mm ||
       ! LC_ALL=C grep -Fq "$fn" Core/zx8f1a_gate.h ||
       ! LC_ALL=C grep -Fq "$fn" Core/zx8f1a_gate.mm; then
        echo "[SECURITY FAIL] module gate incomplete: $key"
        exit 1
    fi
done
for fn in Zx8fSpeedAllowed Zx8fCounterAllowed Zx8fPotionAllowed Zx8fTokenAllowed Zx8fLightningAllowed Zx8fBetCycleAllowed Zx8fAutoBuildAllowed Zx8fMagicCardsAllowed Zx8fAutoMergeAllowed Zx8fAutoClickAllowed Zx8fRaidHammerAllowed Zx8fToolsAllowed Zx8fAutoStopAllowed Zx8fMenuColorAllowed Zx8fFriendInviteAllowed
do
    if ! LC_ALL=C grep -Fq "$fn" UI/OngnongMenuView.mm &&
       ! LC_ALL=C grep -Fq "$fn" Core/OngnongHookManager.mm &&
       ! LC_ALL=C grep -Fq "$fn" Autoclick/OngnongAutoClickPopup.mm &&
       ! LC_ALL=C grep -Fq "$fn" Core/Qr74m.mm &&
       ! LC_ALL=C grep -Fq "$fn" Core/R7f4.mm &&
       ! LC_ALL=C grep -Fq "$fn" Core/Qr73c.mm &&
       ! LC_ALL=C grep -Fq "$fn" UI/X4f0a1.mm; then
        echo "[SECURITY FAIL] module not enforced outside gate: $fn"
        exit 1
    fi
done
for needle in \
    "AUTO HOANG ĐỊA" \
    "MUA VIP" \
    "BUY VIP" \
    "AUTO EXPEDITION" \
    "购买 VIP" \
    "ซื้อ VIP" \
    "ACQUISTA VIP" \
    "自动探险" \
    "ผจญภัยออโต้" \
    "SPEDIZIONE AUTO" \
    "MoonActive.Minigame.Expedition" \
    "NonLinearExpeditionStageCompletePopupController" \
    "TryCloseTooltip" \
    "m_InteractionId" \
    "KitHelpers.ProbabilityEngineKit" \
    "m_UILockOverlay" \
    "completion_gate" \
    "ongnong_vip_dark" \
    "il2cpp_runtime_invoke" \
    "r7f4" \
    "Zx8fActionTarget" \
    "zxCopyDevice" \
    "zxOpenTelegram" \
    "exp_hook_diag" \
    "_log_internal_impl" \
    "_CodePatch" \
    "_intercept_routing_common_bridge_handler" \
    "_vsyslog" \
    "Dobby-latest" \
    "/Users/admin/Documents/h5gg" \
    "__HOOK_TEXT" \
    "__HOOK_DATA" \
    "__hook_text" \
    "__hook_data" \
    "Il2CppHelper" \
    "PTFakeMetaTouch" \
    "KIFAdditions" \
    "ONGAC" \
    "refreshButtons" \
    "toggleAutoBuild" \
    "toggleAutoHeoBua" \
    "toggleMagicCards" \
    "toggleAutoClick" \
    "AUTO HOANG" \
    "ONGNONG.io.vn" \
    "om_theme_r" \
    "AUTO HỢP NHẤT" \
    "AUTO MERGE" \
    "自动合并" \
    "รวมอัตโนมัติ" \
    "UNIONE AUTO" \
    "MoonActive.Minigame.Merge" \
    "MergeMinigameBoardUIController" \
    "MergeMinigameProducerItem" \
    "AutoMergeModule" \
    "om_auto_merge" \
    "auto_merge_state.log" \
    "AUTO_MERGE_S100_CORE_TRACE" \
    "TRACE_AUTO_OFF" \
    "TRACE_SET_ENABLED" \
    "auto_after_" \
    "instant_after_money" \
    "NSAppTransportSecurity" \
    "POST %@ HTTP" \
    "frida" \
    "gum_interceptor_attach" \
    "frida_agent_main" \
    "cycript_main" \
    "cycript" \
    "revealserver" \
    "flexloader"
do
    if LC_ALL=C grep -aFq "$needle" "$target"; then
        echo "[SECURITY FAIL] $needle"
        exit 1
    fi
done
if command -v nm >/dev/null 2>&1; then
    if nm -gjU "$target" 2>/dev/null | grep -Eiq "R7f4(07|08|09|10|11|12|13|14)|ExpeditionAuto|Zx8fExpedition|AutoMergeModule|Zx8fAutoMerge"; then
        echo "[SECURITY FAIL] exported sensitive symbol"
        exit 1
    fi
fi
if command -v otool >/dev/null 2>&1; then
    if otool -l "$target" | grep -q "LC_FUNCTION_STARTS"; then
        echo "[SECURITY FAIL] LC_FUNCTION_STARTS"
        exit 1
    fi
    if otool -l "$target" | grep -q "LC_DATA_IN_CODE"; then
        echo "[SECURITY FAIL] LC_DATA_IN_CODE"
        exit 1
    fi
fi
echo "[SECURITY] PASS"
