#import "Qr71b.h"
#import "Qr71a.h"
#import "OngnongState.h"
#import <Foundation/Foundation.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

__attribute__((noinline)) static NSString *q72d(const uint8_t *v, NSUInteger n, uint8_t seed) {
    if (!v || n == 0) return [NSString string];
    uint8_t stack[96];
    uint8_t *out = n <= sizeof(stack) ? stack : (uint8_t *)malloc(n);
    if (!out) return [NSString string];
    for (NSUInteger i = 0; i < n; i++) out[i] = (uint8_t)(v[i] ^ (uint8_t)(seed + (uint8_t)(i * 17)) ^ (uint8_t)(((i * 13) + 0x5B) & 0xFF));
    NSString *s = [[NSString alloc] initWithBytes:out length:n encoding:NSUTF8StringEncoding] ?: [NSString string];
    memset(out, 0, n);
    if (out != stack) free(out);
    return s;
}

static NSString *q72s0(void) {
    static const uint8_t v[] = {0x13,0x3E,0x5B,0xB6,0x8B,0x8E,0x43,0x77,0x00,0x79,0x6B,0x60,0x70,0x6E,0x6D,0x56,0x7B,0x2F,0x6F,0x4C,0x45,0x94,0x81,0x77,0x5A,0x41,0x13};
    return q72d(v, sizeof(v), 0x27);
}
static NSString *q72s1(void) {
    static const uint8_t v[] = {0x77,0x54,0x79,0x98,0x76,0x6D,0x73};
    return q72d(v, sizeof(v), 0x48);
}
static NSString *q72s2(void) {
    static const uint8_t v[] = {0x50,0x73,0x8C,0x6D};
    return q72d(v, sizeof(v), 0x69);
}
static NSString *q72s3(void) {
    static const uint8_t v[] = {0xA4,0x9D,0xB5,0x59};
    return q72d(v, sizeof(v), 0x8B);
}

static NSString *q72k(NSString *account) {
    NSString *safe = account.length ? account : q72s1();
    return [q72s0() stringByAppendingString:safe];
}

static NSMutableDictionary *q72g(NSString *account) {
    id value = [[NSUserDefaults standardUserDefaults] objectForKey:q72k(account)];
    return [value isKindOfClass:[NSDictionary class]] ? [value mutableCopy] : [NSMutableDictionary dictionary];
}

static void q72w(NSString *account, NSMutableDictionary *state) {
    if (![state isKindOfClass:[NSMutableDictionary class]]) return;
    [[NSUserDefaults standardUserDefaults] setObject:state forKey:q72k(account)];
}


static NSString *q72pendingKey(void) { return @"l_pending"; }
static NSString *q72pendingSnapKey(void) { return @"l_pending_snap"; }
static NSString *q72lastHitSnapKey(void) { return @"l_last_hit_snap"; }

static NSInteger q72i(id value, NSInteger fallback) {
    if ([value isKindOfClass:[NSNumber class]]) return [value integerValue];
    if ([value isKindOfClass:[NSString class]] && [value length] > 0) return [value integerValue];
    return fallback;
}

BOOL q71b0(NSArray<Q71N *> *items, NSString *account, uint64_t snap) {
    if (![items isKindOfClass:[NSArray class]] || items.count == 0) return NO;
    NSMutableDictionary *state = q72g(account);
    NSString *barsKey = q72s2();
    NSMutableDictionary *bars = [NSMutableDictionary dictionary];
    for (Q71N *item in items) {
        if (![item isKindOfClass:[Q71N class]] || item.x0.length == 0 || item.x1 < 0) continue;
        bars[item.x0] = @(item.x1);
    }
    state[barsKey] = bars;
    [state removeObjectForKey:q72pendingKey()];
    [state removeObjectForKey:q72pendingSnapKey()];
    state[q72s3()] = @([NSDate timeIntervalSinceReferenceDate]);
    q72w(account, state);
    return NO;
}

BOOL q71b1(NSString *account, uint64_t snap, NSInteger countAtParse) {
    return NO;
}

BOOL q71b2(NSString *account, uint64_t snap) {
    return NO;
}
