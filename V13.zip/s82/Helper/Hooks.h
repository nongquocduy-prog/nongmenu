//Name: Hooks.h
#import "Helper.hpp"
#include <fstream>
#define FMT_HEADER_ONLY
#include "fmt/core.h"
#include <chrono>
#include <unordered_map>
#include <vector>
#include <sys/mman.h>
#include <sys/socket.h>
#include <netdb.h>
#include <errno.h>
#include <unistd.h>
#include <dlfcn.h>
#import <Foundation/Foundation.h>
#import <CFNetwork/CFNetwork.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#import "PatchNonJB/PatchNonJB.h"
#import "JRMemory.framework/Headers/MemScan.h"
#import "Il2cpp.h"

struct SlotSymbol3_Struct {
    void* isa; void* unk;
    int symbol1; int symbol2; int symbol3;
};

struct WinResult_Struct {
    void* isa; void* unk;
    int state1; 
    int state2; 
    long long amount;
};

struct SlotResult_Struct {
    void* isa; void* unk;
    SlotSymbol3_Struct* slotSymbols;
    WinResult_Struct* win;
};

struct MemoryFileInfo {
    uint32_t index;
    const struct mach_header *header;
    const char *name;
    long long address;
};

MemoryFileInfo getBaseInfo() {
    MemoryFileInfo _info;
    std::string applicationsPath = "/private/var/containers/Bundle/Application";
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *name = _dyld_get_image_name(i);
        if (!name) continue;
        std::string fullpath(name);
        if (strncmp(fullpath.c_str(), applicationsPath.c_str(), applicationsPath.size()) == 0) {
            _info.index = i;
            _info.header = _dyld_get_image_header(i);
            _info.name = _dyld_get_image_name(i);
            _info.address = _dyld_get_image_vmaddr_slide(i);
            break;
        }
    }
    return _info;
}

MemoryFileInfo getMemoryFileInfo(const std::string& fileName) {
    MemoryFileInfo _info;
    const uint32_t imageCount = _dyld_image_count();
    for (uint32_t i = 0; i < imageCount; i++) {
        const char *name = _dyld_get_image_name(i);
        if (!name) continue;
        std::string fullpath(name);
        if (fullpath.length() < fileName.length() || fullpath.compare(fullpath.length() - fileName.length(), fileName.length(), fileName) != 0) continue;
        _info.index = i;
        _info.header = _dyld_get_image_header(i);
        _info.name = _dyld_get_image_name(i);
        _info.address = _dyld_get_image_vmaddr_slide(i);
        break;
    }
    return _info;
}

uintptr_t getAbsoluteAddress(const char *fileName, uintptr_t address) {
    MemoryFileInfo info;
    if (fileName) info = getMemoryFileInfo(fileName);
    else info = getBaseInfo();
    if (info.address == 0) return 0;
    return info.address + address;
}

struct Vars_t {
    bool Enable = false;
    bool history = false;
    bool disconnect = false;
    bool SkipAttackRaid = false;
    
    int countAttack = 0;
    int countRaid = 0;
    int countSymbol = 0;
    int countSpin = 0;
    int countPoin = 0; // THÊM COUNT POIN
    
    int target = 0;
    bool resetOnTarget = false; 
    int lastSymbol1 = -1;
    int lastSymbol2 = -1;
    int lastSymbol3 = -1;

    std::vector<int> historyAttack;
    std::vector<int> historyRaid;
    std::vector<int> historySymbol;
    std::vector<int> historySpin;
    std::vector<int> historyPoin; // THÊM LỊCH SỬ POIN

    float speed = 1.0f;
    bool speedEnabled = false;
} Vars;

bool StreamerMode = false;

static void RegisterStopNotification() {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[NSNotificationCenter defaultCenter]
         addObserverForName:@"StopNowPlease"
         object:nil
         queue:[NSOperationQueue mainQueue]
         usingBlock:^(NSNotification *note) {
        }];
    });
}

void (*oActivateWinSequence)(void* ins, SlotResult_Struct* slotResult);

void ActivateWinSequence(void* ins, SlotResult_Struct* slotResult)
{
    if (Vars.SkipAttackRaid) 
    {
        if (slotResult != nullptr && slotResult->win != nullptr)
        {
            int winState = slotResult->win->state1;
            if (winState == 2 || winState == 4) 
            {
                slotResult->win->state1 = 1; 
            }
        }
    }
    return oActivateWinSequence(ins, slotResult);
}

void (*oOnSpinResultReceived)(void* ins, void* response);
void OnSpinResultReceived(void* ins, void* response)
{
    if(Vars.disconnect)
    {  
       if (response != NULL)
       {
           *(void**)((uint64_t)response + 0x8) = nullptr;
           *(void**)((uint64_t)response + 0x10) = nullptr;
       }
    }
    oOnSpinResultReceived(ins, response);
}

void (*oSetSlotBar)(void* ins, void* originalSymbols, void* replacedSymbols);

void SetSlotBar(void* ins, void* originalSymbols, void* replacedSymbols)
{
    if(Vars.Enable) 
    { 
        Vars.countAttack++;
        Vars.countRaid++;
        Vars.countSymbol++;
        Vars.countSpin++;
        Vars.countPoin++; 
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateAutoSpinCount" object:nil];
        });
        
        if(originalSymbols != NULL){
            int realS1 = *(int*)((uint64_t)originalSymbols + 0x10);
            int realS2 = *(int*)((uint64_t)originalSymbols + 0x14);
            int realS3 = *(int*)((uint64_t)originalSymbols + 0x18);
            
            Vars.lastSymbol1 = realS1;
            Vars.lastSymbol2 = realS2;
            Vars.lastSymbol3 = realS3;
            
            if(realS1 == realS2 && realS2 == realS3)
            {
                int hitSymbol = realS1;
                int hitCount = 0;
                
                if (hitSymbol == 3) {
                    hitCount = Vars.countAttack;
                    if(Vars.history && hitCount > 0){
                        Vars.historyAttack.insert(Vars.historyAttack.begin(), hitCount);
                        if(Vars.historyAttack.size() > 70) Vars.historyAttack.pop_back();
                    }
                    Vars.countAttack = 0;
                } else if (hitSymbol == 4) {
                    hitCount = Vars.countRaid;
                    if(Vars.history && hitCount > 0){
                        Vars.historyRaid.insert(Vars.historyRaid.begin(), hitCount);
                        if(Vars.historyRaid.size() > 70) Vars.historyRaid.pop_back();
                    }
                    Vars.countRaid = 0;
                } else if (hitSymbol == 30) {
                    hitCount = Vars.countSymbol;
                    if(Vars.history && hitCount > 0){
                        Vars.historySymbol.insert(Vars.historySymbol.begin(), hitCount);
                        if(Vars.historySymbol.size() > 70) Vars.historySymbol.pop_back();
                    }
                    Vars.countSymbol = 0;
                } else if (hitSymbol == 6) {
                    hitCount = Vars.countSpin;
                    if(Vars.history && hitCount > 0){
                        Vars.historySpin.insert(Vars.historySpin.begin(), hitCount);
                        if(Vars.historySpin.size() > 70) Vars.historySpin.pop_back();
                    }
                    Vars.countSpin = 0;
                } else if (hitSymbol == 54) { // XỬ LÝ KHI TRÚNG POIN
                    hitCount = Vars.countPoin;
                    if(Vars.history && hitCount > 0){
                        Vars.historyPoin.insert(Vars.historyPoin.begin(), hitCount);
                        if(Vars.historyPoin.size() > 70) Vars.historyPoin.pop_back();
                    }
                    Vars.countPoin = 0;
                }
                
                if(Vars.resetOnTarget && Vars.target != 0) 
                {
                    if(hitSymbol == Vars.target)
                    {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [[NSNotificationCenter defaultCenter] postNotificationName:@"StopNowPlease" object:nil];
 
                            [[NSNotificationCenter defaultCenter] postNotificationName:@"ResetAutoTargetCount" object:nil];
                        });
                    }
                }
            }
        }
    }
    return oSetSlotBar(ins, originalSymbols, replacedSymbols);
}

void (*oSetTimeScale)(float scale, void* method);

static void HookNSURLSession()
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class targetClass = objc_getClass("NSURLSession");
        if(!targetClass) return;
        
        SEL originalSelector = @selector(dataTaskWithRequest:completionHandler:);
        Method originalMethod = class_getInstanceMethod(targetClass, originalSelector);
        
        if(originalMethod) {
            IMP originalImplementation = method_getImplementation(originalMethod);
            typedef NSURLSessionDataTask* (*OriginalIMP)(id, SEL, NSURLRequest*, void(^)(NSData*, NSURLResponse*, NSError*));
            
            IMP newImplementation = imp_implementationWithBlock(^NSURLSessionDataTask *(id self, NSURLRequest *request, void (^completionHandler)(NSData *data, NSURLResponse *response, NSError *error)) {
                
                void (^wrappedCompletion)(NSData*, NSURLResponse*, NSError*) = ^(NSData *data, NSURLResponse *response, NSError *error) {
                    if(Vars.disconnect) {
                        NSError *fakeError = [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorNotConnectedToInternet userInfo:nil];
                        if(completionHandler) completionHandler(nil, nil, fakeError);
                    } else {
                        if(completionHandler) completionHandler(data, response, error);
                    }
                };
                
                NSURLSessionDataTask *task = ((OriginalIMP)originalImplementation)(self, originalSelector, request, wrappedCompletion);
                if(Vars.disconnect) [task cancel];
                return task;
            });
            method_setImplementation(originalMethod, newImplementation);
        }
        
        SEL originalSelector2 = @selector(dataTaskWithRequest:);
        Method originalMethod2 = class_getInstanceMethod(targetClass, originalSelector2);
        if(originalMethod2)
        {
            IMP originalImplementation2 = method_getImplementation(originalMethod2);
            typedef NSURLSessionDataTask* (*OriginalIMP2)(id, SEL, NSURLRequest*);
            
            IMP newImplementation2 = imp_implementationWithBlock(^NSURLSessionDataTask *(id self, NSURLRequest *request) {
                NSURLSessionDataTask *task = ((OriginalIMP2)originalImplementation2)(self, originalSelector2, request);
                if(Vars.disconnect) [task cancel];
                return task;
            });
            method_setImplementation(originalMethod2, newImplementation2);
        }
    });
}


struct CMSArray {
    void *klass;
    void *monitor;
    void *bounds;
    uintptr_t length;
    void *items[1];
};

static unsigned long long cmsTracePoll=0,cmsTraceCommit=0,cmsTraceHit=0,cmsTraceNotify=0,cmsTraceSave=0,cmsTraceLoad=0,cmsTraceEmpty=0,cmsTraceTriple=0,cmsTraceUnmapped=0;
static NSMutableArray<NSString *> *cmsTraceEvents=nil;
static void CMSLogHis(NSString *message) {
    if (!cmsTraceEvents) cmsTraceEvents=[NSMutableArray array];
    NSString *entry=[NSString stringWithFormat:@"%.1f %@",CACurrentMediaTime(),message];
    [cmsTraceEvents addObject:entry];
    if (cmsTraceEvents.count>30) [cmsTraceEvents removeObjectAtIndex:0];
}
static NSString *CMSHisReport() {
    return [NSString stringWithFormat:@"ONGNONG HIS TRACE V9\npoll=%llu commit=%llu hit=%llu notify=%llu save=%llu load=%llu empty=%llu triple=%llu unmapped=%llu\nenabled=%d history=%d gap=%d,%d,%d,%d,%d\nhis_sizes=%lu,%lu,%lu,%lu,%lu\n%@",cmsTracePoll,cmsTraceCommit,cmsTraceHit,cmsTraceNotify,cmsTraceSave,cmsTraceLoad,cmsTraceEmpty,cmsTraceTriple,cmsTraceUnmapped,Vars.Enable,Vars.history,Vars.countAttack,Vars.countRaid,Vars.countSymbol,Vars.countSpin,Vars.countPoin,(unsigned long)Vars.historyAttack.size(),(unsigned long)Vars.historyRaid.size(),(unsigned long)Vars.historySymbol.size(),(unsigned long)Vars.historySpin.size(),(unsigned long)Vars.historyPoin.size(),[cmsTraceEvents componentsJoinedByString:@"\n"]];
}

static void CMSCountSpin(int a,int b,int c) {
    if (!Vars.Enable) {++cmsTraceEmpty;return;}
    ++cmsTraceCommit;
    Vars.countAttack++;
    Vars.countRaid++;
    Vars.countSymbol++;
    Vars.countSpin++;
    Vars.countPoin++;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"UpdateAutoSpinCount" object:nil];
    Vars.lastSymbol1=a;
    Vars.lastSymbol2=b;
    Vars.lastSymbol3=c;
    if (a==b && b==c) {
        ++cmsTraceTriple;
        CMSLogHis([NSString stringWithFormat:@"TRIPLE id=%d enabled=%d hist=%d",a,Vars.Enable,Vars.history]);
        int *count=nullptr;
        std::vector<int> *history=nullptr;
        if (a==3) { count=&Vars.countAttack; history=&Vars.historyAttack; }
        else if (a==4) { count=&Vars.countRaid; history=&Vars.historyRaid; }
        else if (a==30) { count=&Vars.countSymbol; history=&Vars.historySymbol; }
        else if (a==6) { count=&Vars.countSpin; history=&Vars.historySpin; }
        else if (a==54) { count=&Vars.countPoin; history=&Vars.historyPoin; }
        if (count) {
            ++cmsTraceHit;
            CMSLogHis([NSString stringWithFormat:@"HIT id=%d gap=%d hist=%d",a,*count,Vars.history]);
            if (*count>0) {
                history->insert(history->begin(),*count);
                if (history->size()>70) history->pop_back();
            }
            *count=0;
            ++cmsTraceNotify;
            CMSLogHis([NSString stringWithFormat:@"NOTIFY id=%d size=%lu",a,(unsigned long)history->size()]);
            [[NSNotificationCenter defaultCenter] postNotificationName:@"CMSHistoryHit" object:nil];
        }
        if (!count) { ++cmsTraceUnmapped; CMSLogHis([NSString stringWithFormat:@"UNMAPPED id=%d",a]); }
        if (Vars.resetOnTarget && Vars.target==a) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"StopNowPlease" object:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"ResetAutoTargetCount" object:nil];
        }
    }
}

static void CMSPollSpin() {
    ++cmsTracePoll;
    static void *typeObj=nullptr;
    static void *(*findObjects)(void *)=nullptr;
    static void *(*findObjects2)(void *,bool)=nullptr;
    static int lastSerial=-1;
    static int pendingSerial=-1;
    static uintptr_t pendingResult=0;
    static int lastA=-1,lastB=-1,lastC=-1;
    if (!typeObj) {
        void *(*getClass)(const void *,const char *,const char *)=(decltype(getClass))dlsym(RTLD_DEFAULT,"il2cpp_class_from_name");
        void *(*getImage)(const void *)=(decltype(getImage))dlsym(RTLD_DEFAULT,"il2cpp_assembly_get_image");
        void *(*getType)(void *)=(decltype(getType))dlsym(RTLD_DEFAULT,"il2cpp_class_get_type");
        void *(*getObject)(void *)=(decltype(getObject))dlsym(RTLD_DEFAULT,"il2cpp_type_get_object");
        void *(*getDomain)()=(decltype(getDomain))dlsym(RTLD_DEFAULT,"il2cpp_domain_get");
        const void **(*getAssemblies)(void *,size_t *)=(decltype(getAssemblies))dlsym(RTLD_DEFAULT,"il2cpp_domain_get_assemblies");
        if (getClass && getImage && getType && getObject && getDomain && getAssemblies) {
            size_t count=0;
            const void **assemblies=getAssemblies(getDomain(),&count);
            for (size_t i=0;i<count && i<512;i++) {
                const void *image=getImage(assemblies[i]);
                if (!image) continue;
                void *klass=getClass(image,"","SlotMachineManager");
                if (klass) { typeObj=getObject(getType(klass)); break; }
            }
        }
    }
    if (!typeObj) return;
    if (!findObjects) findObjects=(decltype(findObjects))get_offset("UnityEngine.CoreModule.dll","UnityEngine","Object","FindObjectsOfType",1);
    if (!findObjects2) findObjects2=(decltype(findObjects2))get_offset("UnityEngine.CoreModule.dll","UnityEngine","Object","FindObjectsOfType",2);
    CMSArray *arr=findObjects2?(CMSArray *)findObjects2(typeObj,false):(findObjects?(CMSArray *)findObjects(typeObj):nullptr);
    if (!arr || arr->length==0 || arr->length>100000) return;
    uintptr_t slot=(uintptr_t)arr->items[0];
    if (!slot) return;
    int serial=*(int *)(slot+0x1B8);
    bool spinning=*(bool *)(slot+0x121);
    bool completed=*(bool *)(slot+0x219);
    uintptr_t result=*(uintptr_t *)(slot+0x188);
    if (lastSerial<0) {lastSerial=serial;pendingSerial=serial;pendingResult=result;return;}
    if (serial==lastSerial) return;
    if (serial!=pendingSerial) {pendingSerial=serial;pendingResult=result;}
    if (spinning || !result) return;
    uintptr_t symbols=*(uintptr_t *)(result+0x10);
    if (!symbols) return;
    int a=*(int *)(symbols+0x10),b=*(int *)(symbols+0x14),c=*(int *)(symbols+0x18);
    auto valid=[](int v){return v>=0 && (v<=6 || v==20 || v==21 || v==22 || v==23 || v==24 || v==25 || v==30 || v==40 || v==50 || v==54);};
    if (!valid(a)||!valid(b)||!valid(c)) return;
    if (!completed && result==pendingResult && a==lastA && b==lastB && c==lastC) return;
    lastSerial=serial;lastA=a;lastB=b;lastC=c;
    if (Vars.SkipAttackRaid) {
        uintptr_t win=*(uintptr_t *)(result+0x18);
        if (win) {
            int *state=(int *)(win+0x10);
            if (*state==2 || *state==4) *state=1;
        }
    }
    CMSCountSpin(a,b,c);
}

@interface CMSFrameBridge : NSObject
@property(nonatomic,strong) CADisplayLink *link;
+ (instancetype)shared;
- (void)tick:(CADisplayLink *)sender;
@end
@implementation CMSFrameBridge
+ (instancetype)shared {static CMSFrameBridge *instance=nil;static dispatch_once_t once;dispatch_once(&once,^{instance=[CMSFrameBridge new];});return instance;}
- (void)tick:(CADisplayLink *)sender {CMSPollSpin();}
@end

void CheatHandle()
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Attach();
        HookNSURLSession();
        RegisterStopNotification();

        oSetTimeScale = (void (*)(float, void*))get_offset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Time"), oxorany("set_timeScale"), 1);
        dispatch_async(dispatch_get_main_queue(), ^{
            CMSFrameBridge *bridge=[CMSFrameBridge shared];
            if (!bridge.link) {
                bridge.link=[CADisplayLink displayLinkWithTarget:bridge selector:@selector(tick:)];
                [bridge.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
            }
        });
    });
}
