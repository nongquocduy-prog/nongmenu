#!/usr/bin/env bash
set -euo pipefail
export THEOS="${THEOS:-$HOME/theos}"
if [[ -f s82/Makefile ]]; then cd s82; fi
rm -rf .theos/obj
make -j2 FINALPACKAGE=1
DYLIB="$(find .theos/obj -type f -name 'Ongnongios1.dylib' -size +0c -print -quit 2>/dev/null || true)"
if [[ -z "$DYLIB" ]]; then
  echo 'ERROR: Ongnongios1.dylib not built' >&2
  find .theos -maxdepth 5 -type f 2>/dev/null | sort || true
  exit 2
fi
if [[ "$DYLIB" != "./Ongnongios1.dylib" ]]; then cp -f "$DYLIB" Ongnongios1.dylib; fi
file Ongnongios1.dylib
