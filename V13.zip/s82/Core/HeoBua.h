#pragma once
#import <Foundation/Foundation.h>
void HBSetEnabled(bool enabled);
bool HBEnabled(void);
NSString *HBTrace(void);
