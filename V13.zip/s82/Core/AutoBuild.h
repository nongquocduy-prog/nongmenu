#pragma once
#import <Foundation/Foundation.h>
void ABStart(void);
void ABSetEnabled(bool enabled);
bool ABEnabled(void);
NSString *ABTrace(void);
