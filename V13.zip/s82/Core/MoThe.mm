#import "MoThe.h"
#import "../Helper/Il2cpp.h"
#import <UIKit/UIKit.h>
#import <dispatch/dispatch.h>
#import <dlfcn.h>
#import <mach/mach.h>
static bool mtEnabled=false;
static NSMutableArray<NSString *> *mtLines;
static bool mtLoopScheduled=false;
static unsigned long mtSession=0;
static unsigned long mtTick=0;
static NSTimeInterval mtLastResolve=0;
struct MTMethodSpec { const char *ns; const char *cls; const char *name; int argc; };
static const MTMethodSpec mtSpecs[]={
{"","GUI_hudControl","OnCardButtonClick",0},
{"","CardsCollectionPopup","OnOpenStoreClicked",0},
{"MoonActive.CardsFeatures.CardsV2","CardsScreenView","OnOpenStoreClicked",0},
{"MoonActive.StoreV2.Components","StoreItemComponent","ItemClick",0},
{"MoonActive.StoreV2.Components","StoreItemComponent","get_CurrentData",0},
{"MoonActive.Rewards.MultipleChests.Popup","OpenChestPopupController","OnSkipClick",0},
{"MoonActive.Rewards.MultipleChests.Popup","OpenChestPopupController","OnClick",0},
{"MoonActive.StoreV2.MultipleChests","MultipleChestsPurchasePopup","ShowPopup",5},
{"MoonActive.StoreV2.MultipleChests","MultipleChestsPurchasePopup","ClickOnPurchase",0},
{"MoonActive.StoreV2.MultipleChests","MultipleChestsPurchasePopup","NumberOfItemsUpdated",2},
{"MoonActive.StoreV2.MultipleChests","MultipleChestsPurchasePopup","CloseButtonClicked",0},
{"","CardsStoreChestInfoPopup","ShowPopup",5},
{"","CardsStoreChestInfoPopup","ClickOnPurchase",0},
{"","CardsPopup","NextStateClicked",0},
{"","CardsCollectionPopup","ShowPopup",2},
{"","CardsCollectionPopup","CloseButtonClicked",0},
{"","CardsPopup","ShowPopup",5},
{"","CardsPopup","CloseButtonClicked",0},
{"MoonActive.Rewards.MultipleChests.Popup","OpenChestPopupView","OnSkipClick",0}
};
static constexpr int mtMethodCount=sizeof(mtSpecs)/sizeof(mtSpecs[0]);
static void *mtMethods[mtMethodCount]={};
static bool mtNativeValidated[mtMethodCount]={};
static unsigned long mtResolutionEpoch=0;
static void MTLog(NSString *line) {
    if(!mtLines) mtLines=[NSMutableArray array];
    [mtLines addObject:[NSString stringWithFormat:@"%.3f %@",[NSDate timeIntervalSinceReferenceDate],line]];
    if(mtLines.count>250) [mtLines removeObjectsInRange:NSMakeRange(0,mtLines.count-250)];
}
static void MTResolve(void) {
    mtLastResolve=[NSDate timeIntervalSinceReferenceDate];
    mtResolutionEpoch++;
    int ready=0, validated=0;
    for(int i=0;i<mtMethodCount;i++) {
        const MTMethodSpec &spec=mtSpecs[i];
        void *p=get_offset("Assembly-CSharp.dll",spec.ns,spec.cls,spec.name,spec.argc);
        if(!p && spec.ns[0]) p=get_offset("Assembly-CSharp.dll","",spec.cls,spec.name,spec.argc);
        mtMethods[i]=p;
        Dl_info info={};
        bool mapped=p && dladdr(p,&info)!=0 && info.dli_fbase;
        mtNativeValidated[i]=mapped;
        if(p) ready++;
        if(mapped) validated++;
        MTLog([NSString stringWithFormat:@"METHOD_%@ class=%s method=%s argc=%d namespace=%s mapped=%d image=%s",p?@"FOUND":@"MISSING",spec.cls,spec.name,spec.argc,spec.ns,mapped?1:0,mapped&&info.dli_fname?info.dli_fname:"none"]);
    }
    MTLog([NSString stringWithFormat:@"RESOLVE_COMPLETE ready=%d total=%d native_mapped=%d epoch=%lu invocation=disabled_until_signature_and_object_verified",ready,mtMethodCount,validated,mtResolutionEpoch]);
}
typedef void *(*MTClassTypeFn)(void *);
typedef void *(*MTTypeObjectFn)(void *);
typedef void *(*MTIcallFn)(const char *);
typedef monoArray<void *> *(*MTFindFn)(void *,bool);
typedef monoArray<void *> *(*MTFindOneFn)(void *);
static MTClassTypeFn mtClassType=nullptr;
static MTTypeObjectFn mtTypeObject=nullptr;
static MTFindFn mtFind=nullptr;
static MTFindOneFn mtFindOne=nullptr;
static void *mtTypes[mtMethodCount]={};
static bool mtClassChecked[mtMethodCount]={};
static NSTimeInterval mtLastAction=0;
static NSTimeInterval mtStageAt=0;
static int mtStage=0;
static int mtLastStage=-1;
static bool mtHudRequested=false;
static NSTimeInterval mtHudRequestAt=0;
static NSTimeInterval mtLastHudAttempt=0;
static int mtHudAttempts=0;
static NSTimeInterval mtLastNavigationAt=0;
static void MTStage(int stage, NSString *reason) {
    if(mtStage!=stage) { mtStage=stage; mtStageAt=[NSDate timeIntervalSinceReferenceDate]; MTLog([NSString stringWithFormat:@"STAGE value=%d reason=%@",stage,reason]); }
}
static void MTResolveObjects(void) {
    mtClassType=(MTClassTypeFn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_type");
    mtTypeObject=(MTTypeObjectFn)dlsym(RTLD_DEFAULT,"il2cpp_type_get_object");
    MTIcallFn icall=(MTIcallFn)dlsym(RTLD_DEFAULT,"il2cpp_resolve_icall");
    if(icall) {
        mtFind=(MTFindFn)icall("UnityEngine.Object::FindObjectsOfType(System.Type,System.Boolean)");
        mtFindOne=(MTFindOneFn)icall("UnityEngine.Object::FindObjectsOfType(System.Type)");
    }
    MTLog([NSString stringWithFormat:@"OBJECT_RESOLVER class=%d type=%d find2=%d find1=%d",!!mtClassType,!!mtTypeObject,!!mtFind,!!mtFindOne]);
}
static void *MTObject(int index, int *count) {
    if(count) *count=0;
    if(index<0 || index>=mtMethodCount || !mtClassType || !mtTypeObject || (!mtFind && !mtFindOne)) return nullptr;
    if(!mtTypes[index]) {
        const MTMethodSpec &sp=mtSpecs[index];
        void *klass=Il2CppGetClassType("Assembly-CSharp.dll",sp.ns,sp.cls);
        if(!klass && sp.ns[0]) klass=Il2CppGetClassType("Assembly-CSharp.dll","",sp.cls);
        if(!klass) { if(!mtClassChecked[index]) MTLog([NSString stringWithFormat:@"CLASS_MISSING class=%s namespace=%s",sp.cls,sp.ns]); mtClassChecked[index]=true; return nullptr; }
        if(!mtClassChecked[index]) MTLog([NSString stringWithFormat:@"CLASS_FOUND class=%s namespace=%s",sp.cls,sp.ns]);
        mtClassChecked[index]=true;
        void *type=mtClassType(klass);
        if(type) mtTypes[index]=mtTypeObject(type);
    }
    if(!mtTypes[index]) return nullptr;
    monoArray<void *> *arr=mtFind?mtFind(mtTypes[index],false):(mtFindOne?mtFindOne(mtTypes[index]):nullptr);
    if((!arr || arr->getCapacity()==0) && mtFind) arr=mtFind(mtTypes[index],true);
    if(!arr) return nullptr;
    int n=arr->getCapacity();
    if(n<0 || n>100000) return nullptr;
    if(count) *count=n;
    if(n>0 && mtTick%10==1) MTLog([NSString stringWithFormat:@"OBJECT_FOUND class=%s count=%d",mtSpecs[index].cls,n]);
    for(int i=0;i<n && i<32;i++) if(arr->m_Items[i]) return arr->m_Items[i];
    return nullptr;
}
static bool MTCallable(int index, void *object) {
    if(index<0 || index>=mtMethodCount || !object || !mtMethods[index] || !mtNativeValidated[index]) return false;
    uintptr_t address=(uintptr_t)object;
    if(address<4096 || (address & (sizeof(void *)-1))!=0) return false;
    return true;
}
static bool MTInvoke(int index, void *obj, NSString *reason) {
    if(!MTCallable(index,obj)) { MTLog([NSString stringWithFormat:@"CALL_BLOCKED index=%d reason=%@",index,reason]); return false; }
    MTLog([NSString stringWithFormat:@"CALL_BEGIN index=%d reason=%@",index,reason]);
    ((void (*)(void *))mtMethods[index])(obj);
    mtLastAction=[NSDate timeIntervalSinceReferenceDate];
    MTLog([NSString stringWithFormat:@"CALL_RETURN index=%d",index]);
    return true;
}
static NSTimeInterval mtPayAt=0;
static NSTimeInterval mtQtyReadyAt=0;
static bool mtPurchasePending=false;
static int mtLastQty=-1;
static NSTimeInterval mtRewardSeenAt=0;
static NSTimeInterval mtSkipAt=0;
static NSTimeInterval mtLastSkipAt=0;
static bool mtWaitingRewardClose=false;
static bool MTContains(const char *s, NSString *term) {
    if(!s || !term) return false;
    NSString *value=[NSString stringWithUTF8String:s];
    return value && [value rangeOfString:term options:NSCaseInsensitiveSearch].location!=NSNotFound;
}
static const char *MTString(void *ptr) {
    if(!ptr) return nullptr;
    return ((Il2CppString *)ptr)->CString();
}
static void *MTReadPointer(void *base, uintptr_t offset) {
    if(!base) return nullptr;
    return *(void **)((uint8_t *)base+offset);
}
static bool MTExactMagic(void *item) {
    if(!item || !mtMethods[4] || !mtNativeValidated[4]) return false;
    void *data=((void *(*)(void *))mtMethods[4])(item);
    if(!data) return false;
    const char *chest=MTString(MTReadPointer(data,0x78));
    const char *store=MTString(MTReadPointer(data,0x18));
    bool matched=MTContains(chest,@"magic") || MTContains(chest,@"magical") || MTContains(store,@"magic") || MTContains(store,@"magical");
    if(matched) MTLog([NSString stringWithFormat:@"MAGIC_CHEST_MATCH chest=%s store=%s",chest?chest:"null",store?store:"null"]);
    return matched;
}
static void *MTFindMagicStoreItem(int *matches) {
    if(matches) *matches=0;
    if(!mtTypes[3] || !mtFind) return nullptr;
    for(int pass=0;pass<2;pass++) {
        monoArray<void *> *arr=mtFind(mtTypes[3],pass==1);
        int n=arr?arr->getCapacity():0;
        if(n<0 || n>10000) continue;
        for(int i=0;i<n && i<60;i++) {
            void *obj=arr->m_Items[i];
            if(obj && MTExactMagic(obj)) {
                if(matches) (*matches)++;
                return obj;
            }
        }
    }
    return nullptr;
}
static int MTChestQuantity(void *popup) {
    if(!popup) return -1;
    return *(int *)((uint8_t *)popup+0xF8);
}
static void MTStep(void) {
    NSTimeInterval now=[NSDate timeIntervalSinceReferenceDate];
    if(!mtClassType || !mtTypeObject || (!mtFind && !mtFindOne)) return;
    if(now-mtLastAction<0.04) return;
    int qtyCount=0,rewardCount=0,storeCount=0,collectionCount=0,screenCount=0;
    void *qty=MTObject(8,&qtyCount);
    void *reward=MTObject(18,&rewardCount);
    int rewardViewCount=rewardCount;
    int rewardMethod=18;
    if(!reward) { reward=MTObject(5,&rewardCount); rewardMethod=5; }
    if(reward && mtRewardSeenAt<=0) { mtRewardSeenAt=now; MTLog([NSString stringWithFormat:@"REWARD_VISIBLE method=%d view=%d controller=%d",rewardMethod,rewardViewCount,rewardCount]); }
    void *store=MTObject(3,&storeCount);
    void *collection=MTObject(1,&collectionCount);
    void *screen=MTObject(2,&screenCount);
    if(mtTick%10==1) MTLog([NSString stringWithFormat:@"OBJECT_SCAN qty=%d reward=%d store=%d cards=%d screen=%d",qtyCount,rewardCount,storeCount,collectionCount,screenCount]);
    if(reward) {
        MTStage(4,@"REWARD_POPUP_VISIBLE");
        if(mtPurchasePending && now-mtPayAt>=1.05 && now-mtRewardSeenAt>=0.18 && !mtWaitingRewardClose) {
            if(MTInvoke(rewardMethod,reward,@"REWARD_SKIP_2781")) {
                mtWaitingRewardClose=true;
                mtLastSkipAt=now;
                MTStage(7,@"WAIT_REWARD_CLOSE");
            }
        }
        return;
    }
    if(mtWaitingRewardClose) {
        if(now-mtLastSkipAt<0.04) return;
        mtWaitingRewardClose=false;
        mtPurchasePending=false;
        mtRewardSeenAt=0;
        mtPayAt=0;
        mtLastQty=-1;
        MTLog(@"REWARD_CLOSED_NEXT_LOOP");
        MTStage(1,@"READY_NEXT_MAGIC_CHEST");
    }
    if(mtPurchasePending) {
        if(now-mtPayAt<9.0) { MTStage(5,@"WAIT_PURCHASE_RESULT"); return; }
        MTLog(@"PURCHASE_WAIT_TIMEOUT_NO_CONFIRMED_REWARD");
        return;
    }
    if(qty) {
        int quantity=MTChestQuantity(qty);
        if(quantity!=mtLastQty) { MTLog([NSString stringWithFormat:@"QTY_OBSERVED count=%d",quantity]); mtLastQty=quantity; }
        MTStage(2,@"QUANTITY_POPUP_VISIBLE");
        if(quantity!=10 && mtMethods[9] && mtNativeValidated[9]) {
            MTLog(@"QTY_SET_REQUEST count=10");
            ((void (*)(void *,bool,int))mtMethods[9])(qty,true,10);
            mtLastAction=now;
            mtQtyReadyAt=now+0.35;
            return;
        }
        if(quantity==10 && now>=mtQtyReadyAt && mtMethods[8] && mtNativeValidated[8]) {
            MTLog(@"PURCHASE_REQUEST quantity=10");
            mtPurchasePending=true;
            mtPayAt=now;
            mtRewardSeenAt=0;
            mtWaitingRewardClose=false;
            MTInvoke(8,qty,@"PURCHASE_TEN_CHESTS");
            MTStage(3,@"WAIT_REWARD_AFTER_PURCHASE");
        }
        return;
    }
    if(store) {
        MTStage(1,@"STORE_ITEM_VISIBLE");
        int matches=0;
        void *magic=MTFindMagicStoreItem(&matches);
        if(mtTick%5==1) MTLog([NSString stringWithFormat:@"STORE_MAGIC_SCAN items=%d matches=%d",storeCount,matches]);
        if(magic && now-mtLastAction>=0.18) {
            if(MTInvoke(3,magic,@"SELECT_VERIFIED_MAGIC_CHEST")) MTStage(6,@"WAIT_QUANTITY_POPUP");
        }
        return;
    }
    if(collection) {
        MTStage(20,@"CARDS_COLLECTION_VISIBLE");
        mtHudRequested=false;
        if(now-mtLastNavigationAt>=0.18 && now-mtLastAction>=0.18) { mtLastNavigationAt=now; MTInvoke(1,collection,@"OPEN_STORE_FROM_COLLECTION"); }
        return;
    }
    if(screen) {
        MTStage(21,@"CARDS_SCREEN_VISIBLE");
        mtHudRequested=false;
        if(now-mtLastNavigationAt>=0.18 && now-mtLastAction>=0.18) { mtLastNavigationAt=now; MTInvoke(2,screen,@"OPEN_STORE_FROM_CARDS_SCREEN"); }
        return;
    }
    if(mtHudRequested) {
        MTStage(11,@"WAIT_CARDS_AFTER_HUD");
        if(mtTick%5==1) MTLog([NSString stringWithFormat:@"CARDS_TRANSITION_WAIT elapsed=%.2f screen=%d collection=%d",now-mtHudRequestAt,screenCount,collectionCount]);
        return;
    }
    int hudCount=0;
    void *hud=MTObject(0,&hudCount);
    if(mtTick%10==1) MTLog([NSString stringWithFormat:@"HUD_SCAN count=%d method=%d",hudCount,mtMethods[0]!=nullptr]);
    if(hud && mtMethods[0] && mtNativeValidated[0]) {
        MTStage(10,@"SPIN_HUD_FOUND");
        if(now-mtLastHudAttempt>=0.18 && mtHudAttempts<1) {
            mtLastHudAttempt=now;
            mtHudAttempts++;
            MTLog([NSString stringWithFormat:@"HUD_OPEN_REQUEST attempt=%d",mtHudAttempts]);
            if(MTInvoke(0,hud,@"OPEN_CARDS_FROM_SPIN")) { mtHudRequested=true; mtHudRequestAt=now; MTStage(11,@"HUD_REQUEST_SENT_WAIT_CARDS"); }
        }
        return;
    }
    MTStage(0,hudCount?@"HUD_METHOD_UNAVAILABLE":@"WAIT_HUD_INSTANCE");
}
static void MTTick(void) {
    if(!mtEnabled) return;
    mtTick++;
    NSTimeInterval now=[NSDate timeIntervalSinceReferenceDate];
    if(mtLastResolve==0 || now-mtLastResolve>15) { MTResolve(); MTResolveObjects(); }
    MTStep();
    if(mtTick%10==1) MTLog([NSString stringWithFormat:@"HEARTBEAT tick=%lu resolved=%d stage=OBJECT_AND_ABI_VALIDATION_REQUIRED",mtTick,(int)(mtMethods[0]!=nullptr)]);
}
static void MTSchedule(double delay) {
    if(!mtEnabled || mtLoopScheduled) return;
    mtLoopScheduled=true;
    unsigned long session=mtSession;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(delay*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
        if(session!=mtSession) return;
        mtLoopScheduled=false;
        if(!mtEnabled) return;
        @autoreleasepool { MTTick(); }
        MTSchedule(0.15);
    });
}
void MTSetEnabled(bool enabled) {
    if(mtEnabled==enabled) return;
    mtEnabled=enabled;
    MTLog([NSString stringWithFormat:@"TOGGLE enabled=%d",enabled?1:0]);
    if(!enabled) { mtSession++; mtLoopScheduled=false; }
    if(enabled) {
        mtStage=0; mtStageAt=[NSDate timeIntervalSinceReferenceDate]; mtLastAction=0; mtLastHudAttempt=0; mtLastNavigationAt=0; mtHudAttempts=0; mtHudRequested=false; mtHudRequestAt=0; mtPayAt=0; mtQtyReadyAt=0; mtPurchasePending=false; mtLastQty=-1; mtRewardSeenAt=0; mtWaitingRewardClose=false; mtLastSkipAt=0;
        mtSession++; mtLoopScheduled=false;
        MTTick();
        MTSchedule(0.15);
    }
}
bool MTEnabled(void) {return mtEnabled;}
NSString *MTTrace(void) {
    if(mtLastResolve==0) MTResolve();
    MTLog([NSString stringWithFormat:@"TRACE_COPY enabled=%d ticks=%lu",mtEnabled?1:0,mtTick]);
    return [@"ONGNONG MO THE TRACE V13\n" stringByAppendingString:mtLines?[mtLines componentsJoinedByString:@"\n"]:@"NO_EVENTS"];
}
