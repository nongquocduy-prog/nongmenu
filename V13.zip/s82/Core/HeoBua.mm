#import "HeoBua.h"
#import "../Helper/Il2cpp.h"
#import <UIKit/UIKit.h>
#import <dispatch/dispatch.h>
#import <dlfcn.h>
#import "../PatchNonJB/dobby.h"
static bool hbEnabled=false;
static dispatch_source_t hbTimer=nullptr;
static unsigned long hbTickCount=0;
static NSTimeInterval hbLastHeartbeat=0;
static NSMutableArray<NSString *> *hbLines;
static void *(*hbInstance)(void)=nullptr;
static int (*hbState)(void *)=nullptr;
static void (*hbAttack)(void *)=nullptr;
static void (*hbSummaryClose)(void *)=nullptr;
static void *hbTargetType=nullptr;
static void *hbSummaryType=nullptr;
static void *(*hbClassType)(void *)=nullptr;
static void *(*hbTypeObject)(void *)=nullptr;
static monoArray<void *> *(*hbFind)(void *,bool)=nullptr;
static monoArray<void *> *(*hbFindOne)(void *)=nullptr;
static NSTimeInterval hbLastResolve=0,hbTargetSeen=0,hbLastAction=0;
static void *hbLastTarget=nullptr;
static int hbPreviousState=-999;
static void *hbSlotType=nullptr,*hbRaidType=nullptr,*hbRaidViewType=nullptr,*hbBaseSummaryType=nullptr;
static void *hbRaidService=nullptr,*hbRaidView=nullptr;
static void (*hbBaseClose)(void *)=nullptr;
static void *(*hbObjectClass)(void *)=nullptr;
static void *(*hbClassMethod)(void *,const char *,int)=nullptr;
static void *(*hbInvoke)(void *,void *,void **,void **)=nullptr;
static size_t hbServiceOffset=SIZE_MAX,hbResultOffset=SIZE_MAX;
static int hbDigCount=0,hbLastResults=-1,hbHammerRetries=0;
static bool hbPigInFlight=false;
static int hbPigFinished=0;
static int hbPigSession=0;
static int hbPigResultBaseline=0;
static NSTimeInterval hbPigLastDig=0,hbLastSummary=0,hbLastScan=0;
static NSTimeInterval hbEnableAt=0,hbStateStableAt=0;
static int hbStableState=-999;

static void HBLog(NSString *s) {
    if(!hbLines) hbLines=[NSMutableArray array];
    [hbLines addObject:[NSString stringWithFormat:@"%.3f %@",[NSDate timeIntervalSinceReferenceDate],s]];
    if(hbLines.count>220) [hbLines removeObjectsInRange:NSMakeRange(0,hbLines.count-220)];
}
static void *HBFind(const char *name,void **cache) {
    if(!hbClassType || !hbTypeObject || (!hbFind && !hbFindOne)) return nullptr;
    if(!*cache) {
        void *c=Il2CppGetClassType("Assembly-CSharp.dll","",name);
        if(!c) return nullptr;
        void *t=hbClassType(c);
        if(t) *cache=hbTypeObject(t);
    }
    if(!*cache) return nullptr;
    monoArray<void *> *arr=hbFind?hbFind(*cache,false):hbFindOne(*cache);
    if(!arr) return nullptr;
    int n=arr->getCapacity();
    for(int i=0;i<n && i<12;i++) if(arr->m_Items[i]) return arr->m_Items[i];
    return nullptr;
}
static void *HBFindQualified(const char *ns,const char *name,void **cache) {
    if(!hbClassType || !hbTypeObject || (!hbFind && !hbFindOne)) return nullptr;
    if(!*cache) {
        void *c=Il2CppGetClassType("Assembly-CSharp.dll",ns,name);
        if(c) { void *t=hbClassType(c); if(t) *cache=hbTypeObject(t); }
    }
    if(!*cache) return nullptr;
    auto a=hbFind?hbFind(*cache,false):hbFindOne(*cache);
    if(!a) return nullptr;
    for(int i=0;i<a->getCapacity() && i<16;i++) if(a->m_Items[i]) return a->m_Items[i];
    return nullptr;
}
static int HBResultCount(void *view) {
    if(!view || hbResultOffset==SIZE_MAX) return -1;
    void *dict=*(void **)((uintptr_t)view+hbResultOffset);
    if(!dict) return 0;
    int n=*(int *)((uintptr_t)dict+0x20);
    return n>=0 && n<=64?n:-1;
}
static void HBPigTick(NSTimeInterval now) {
    void *view=HBFindQualified("MoonActive.Raid.UI","RaidMainView",&hbRaidViewType);
    if(!view) {if(hbRaidView) HBLog(@"PIG_VIEW_CLOSED");hbRaidView=nullptr;hbDigCount=0;hbPigInFlight=false;return;}
    if(view!=hbRaidView) {hbRaidView=view;hbPigSession++;hbDigCount=0;hbPigFinished=0;hbPigInFlight=false;hbLastResults=HBResultCount(view);hbPigResultBaseline=hbLastResults>=0?hbLastResults:0;hbPigLastDig=now;HBLog(@"PIG_VIEW_FOUND");}
    if(!hbRaidService) {
        void *slot=HBFind("SlotMachineManager",&hbSlotType);
        if(slot && hbServiceOffset!=SIZE_MAX) hbRaidService=*(void **)((uintptr_t)slot+hbServiceOffset);
    }
    if(!hbRaidService || !hbObjectClass || !hbClassMethod || !hbInvoke) {
        if(now-hbLastScan>2) {hbLastScan=now;HBLog([NSString stringWithFormat:@"PIG_WAIT service=%d invoke=%d",!!hbRaidService,!!hbInvoke]);}
        return;
    }
    int results=HBResultCount(view);
    if(results>hbLastResults && hbLastResults>=0) {
        hbLastResults=results;
        int confirmed=results-hbPigResultBaseline;
        if(confirmed>hbPigFinished) hbPigFinished=confirmed;
        if(hbPigInFlight && confirmed>=hbDigCount) {
            hbPigInFlight=false;
            HBLog([NSString stringWithFormat:@"PIG_RESULT_ACK dig=%d confirmed=%d",hbDigCount,confirmed]);
        }
        HBLog([NSString stringWithFormat:@"PIG_RESULT count=%d",results]);
    }
    if(hbDigCount>=3 || hbPigFinished>=3 || hbPigInFlight || now-hbPigLastDig<0.65) return;
    if(hbDigCount>0 && results>=0 && results-hbPigResultBaseline<hbDigCount) return;
    void *method=hbClassMethod(hbObjectClass(hbRaidService),"StealFromDigPoint",1);
    if(!method) {if(now-hbLastScan>2) {hbLastScan=now;HBLog(@"PIG_METHOD_MISSING");}return;}
    int point=hbDigCount;
    void *args[1]={&point},*exception=nullptr;
    hbPigLastDig=now;
    hbInvoke(method,hbRaidService,args,&exception);
    if(exception) {HBLog([NSString stringWithFormat:@"PIG_DIG_EXCEPTION point=%d",point]);return;}
    hbDigCount++;hbPigInFlight=true;
    HBLog([NSString stringWithFormat:@"PIG_DIG_CALL point=%d",point]);
}
static void (*hbOrigDigFinished)(void *,void *)=nullptr;
static void (*hbOrigDigComplete)(void *,void *)=nullptr;
static void (*hbOrigRaidReset)(void *,void *)=nullptr;
static void (*hbOrigHammerEnable)(void *)=nullptr;
static void (*hbOrigHammerShow)(void *)=nullptr;
static void (*hbOrigHammerShowTarget)(void *,float)=nullptr;
static void *hbHookAddresses[6]={};
static void HBDigFinished(void *ins,void *method) {
    if(hbOrigDigFinished) hbOrigDigFinished(ins,method);
    if(!hbEnabled || !hbRaidView || !hbPigInFlight) return;
    hbPigInFlight=false;
    hbPigFinished++;
    HBLog([NSString stringWithFormat:@"PIG_DIG_CONFIRMED session=%d finished=%d",hbPigSession,hbPigFinished]);
    if(hbPigFinished>=3) HBLog(@"PIG_THREE_DIGS_COMPLETE");
}
static void HBDigComplete(void *ins,void *method) {
    if(hbOrigDigComplete) hbOrigDigComplete(ins,method);
    if(!hbEnabled) return;
    HBLog([NSString stringWithFormat:@"PIG_VIEW_DIG_COMPLETE session=%d",hbPigSession]);
}
static void HBRaidReset(void *ins,void *method) {
    if(hbOrigRaidReset) hbOrigRaidReset(ins,method);
    if(!hbEnabled) return;
    hbRaidView=ins;hbPigSession++;hbPigFinished=0;hbDigCount=0;hbPigInFlight=false;
    hbLastResults=HBResultCount(ins);hbPigResultBaseline=hbLastResults>=0?hbLastResults:0;hbPigLastDig=[NSDate timeIntervalSinceReferenceDate];
    HBLog([NSString stringWithFormat:@"PIG_RAID_RESET session=%d",hbPigSession]);
}
static void HBHammerEnable(void *ins) {
    if(hbOrigHammerEnable) hbOrigHammerEnable(ins);
    if(hbEnabled && ins) {hbLastTarget=ins;hbTargetSeen=[NSDate timeIntervalSinceReferenceDate];hbHammerRetries=0;HBLog(@"HAMMER_CALLBACK_ENABLE");}
}
static void HBHammerShow(void *ins) {
    if(hbOrigHammerShow) hbOrigHammerShow(ins);
    if(hbEnabled && ins) {hbLastTarget=ins;hbTargetSeen=[NSDate timeIntervalSinceReferenceDate];hbHammerRetries=0;HBLog(@"HAMMER_CALLBACK_SHOW");}
}
static void HBHammerShowTarget(void *ins,float delay) {
    if(hbOrigHammerShowTarget) hbOrigHammerShowTarget(ins,delay);
    if(hbEnabled && ins) {hbLastTarget=ins;hbTargetSeen=[NSDate timeIntervalSinceReferenceDate];hbHammerRetries=0;HBLog(@"HAMMER_CALLBACK_TARGET");}
}
static void HBInstallCallbacks(void) {
    struct Entry {const char *ns;const char *cls;const char *method;int argc;void *replacement;void **original;};
    Entry entries[]={
        {"MoonActive.Raid","RaidServiceProxy","FinishedSuccessfulDig",0,(void *)HBDigFinished,(void **)&hbOrigDigFinished},
        {"MoonActive.Raid.UI","RaidMainView","DigComplete",0,(void *)HBDigComplete,(void **)&hbOrigDigComplete},
        {"MoonActive.Raid.UI","RaidMainView","ResetForNewRaid",0,(void *)HBRaidReset,(void **)&hbOrigRaidReset},
        {"","GUI_attackTergetControl","Enable",0,(void *)HBHammerEnable,(void **)&hbOrigHammerEnable},
        {"","GUI_attackTergetControl","Show",0,(void *)HBHammerShow,(void **)&hbOrigHammerShow},
        {"","GUI_attackTergetControl","ShowTarget",1,(void *)HBHammerShowTarget,(void **)&hbOrigHammerShowTarget}
    };
    for(int i=0;i<6;i++) {
        if(hbHookAddresses[i]) continue;
        void *address=get_offset("Assembly-CSharp.dll",entries[i].ns,entries[i].cls,entries[i].method,entries[i].argc);
        if(!address) {HBLog([NSString stringWithFormat:@"CALLBACK_MISSING index=%d",i]);continue;}
        int result=DobbyHook(address,entries[i].replacement,entries[i].original);
        if(result==0 && *entries[i].original) hbHookAddresses[i]=address;
        HBLog([NSString stringWithFormat:@"CALLBACK_INSTALL index=%d result=%d original=%d",i,result,!!*entries[i].original]);
    }
}
static void HBResolve(void) {
    Attach();
    hbInstance=(decltype(hbInstance))get_offset("Assembly-CSharp.dll","","MainManager","get_Instance",0);
    hbState=(decltype(hbState))get_offset("Assembly-CSharp.dll","","MainManager","get_CurrentGameState",0);
    hbAttack=(decltype(hbAttack))get_offset("Assembly-CSharp.dll","","GUI_attackTergetControl","OnAttackBtnClicked",0);
    hbSummaryClose=(decltype(hbSummaryClose))get_offset("Assembly-CSharp.dll","","AttackSummaryPopup","CloseButtonClicked",0);
    hbClassType=(decltype(hbClassType))dlsym(RTLD_DEFAULT,"il2cpp_class_get_type");
    hbTypeObject=(decltype(hbTypeObject))dlsym(RTLD_DEFAULT,"il2cpp_type_get_object");
    auto resolve=(void *(*)(const char *))dlsym(RTLD_DEFAULT,"il2cpp_resolve_icall");
    if(resolve) {
        hbFind=(decltype(hbFind))resolve("UnityEngine.Object::FindObjectsOfType(System.Type,System.Boolean)");
        hbFindOne=(decltype(hbFindOne))resolve("UnityEngine.Object::FindObjectsOfType(System.Type)");
    }
    hbBaseClose=(decltype(hbBaseClose))get_offset("Assembly-CSharp.dll","","BaseRaidAttackSummaryPopup","OnClick",0);
    hbObjectClass=(decltype(hbObjectClass))dlsym(RTLD_DEFAULT,"il2cpp_object_get_class");
    hbClassMethod=(decltype(hbClassMethod))dlsym(RTLD_DEFAULT,"il2cpp_class_get_method_from_name");
    hbInvoke=(decltype(hbInvoke))dlsym(RTLD_DEFAULT,"il2cpp_runtime_invoke");
    size_t so=Il2CppGetFieldOffset("Assembly-CSharp.dll","","SlotMachineManager","m_RaidService");
    if(so>0 && so<0x1000) hbServiceOffset=so;
    size_t ro=Il2CppGetFieldOffset("Assembly-CSharp.dll","MoonActive.Raid.UI","RaidMainView","m_DigResultById");
    if(ro>0 && ro<0x1000) hbResultOffset=ro;
    HBInstallCallbacks();
    HBLog([NSString stringWithFormat:@"PIG_RESOLVE serviceOffset=%d resultOffset=%d runtime=%d",hbServiceOffset!=SIZE_MAX,hbResultOffset!=SIZE_MAX,!!hbInvoke]);
    HBLog([NSString stringWithFormat:@"RESOLVE instance=%d state=%d attack=%d summary=%d find=%d",!!hbInstance,!!hbState,!!hbAttack,!!hbSummaryClose,!!hbFind||!!hbFindOne]);
}
static void HBTick(void) {
    if(!hbEnabled) return;
    NSTimeInterval now=[NSDate timeIntervalSinceReferenceDate];
    hbTickCount++;
    if(now-hbLastHeartbeat>=2.0) { hbLastHeartbeat=now; HBLog([NSString stringWithFormat:@"TICK_ALIVE count=%lu instance=%d state=%d",hbTickCount,!!hbInstance,!!hbState]); }
    if((!hbInstance || !hbState || !hbAttack) && now-hbLastResolve>3) {hbLastResolve=now;HBResolve();}
    if(!hbInstance || !hbState) return;
    void *mgr=hbInstance();
    if(!mgr) return;
    int state=hbState(mgr);
    if(state!=hbStableState) {hbStableState=state;hbStateStableAt=now;}
    if(state!=hbPreviousState) {
        HBLog([NSString stringWithFormat:@"STATE old=%d new=%d",hbPreviousState,state]);
        hbPreviousState=state;hbLastTarget=nullptr;hbTargetSeen=now;
    }
    if(now-hbEnableAt<3.0 || now-hbStateStableAt<0.45) {
        if(hbTickCount%14==1) HBLog([NSString stringWithFormat:@"FIRST_RUN_GUARD state=%d elapsed=%.2f",state,now-hbEnableAt]);
        return;
    }
    void *summary=state==1 ? HBFind("AttackSummaryPopup",&hbSummaryType) : nullptr;
    if(!summary && state==1) summary=HBFind("BaseRaidAttackSummaryPopup",&hbBaseSummaryType);
    if(summary && now-hbLastSummary>0.9) {
        hbLastSummary=now;
        if(hbSummaryClose && HBFind("AttackSummaryPopup",&hbSummaryType)==summary) {hbSummaryClose(summary);HBLog(@"HAMMER_SUMMARY_CLOSE");}
        else if(hbBaseClose) {hbBaseClose(summary);HBLog(@"HAMMER_BASE_SUMMARY_CLOSE");}
    }
    void *target=state!=1 || hbRaidView ? nullptr : HBFind("GUI_attackTergetControl",&hbTargetType);
    if(target && hbAttack) {
        if(target!=hbLastTarget) {hbLastTarget=target;hbTargetSeen=now;hbHammerRetries=0;HBLog(@"HAMMER_TARGET_FOUND");}
        if(now-hbTargetSeen>=2.0 && now-hbLastAction>=1.8 && hbHammerRetries<6) {
            hbLastAction=now;hbHammerRetries++;HBLog([NSString stringWithFormat:@"HAMMER_ATTACK_CALL retry=%d",hbHammerRetries]);hbAttack(target);
        }
    } else if(hbLastTarget) {hbLastTarget=nullptr;hbHammerRetries=0;HBLog(@"HAMMER_TARGET_CLOSED");}
    HBPigTick(now);
}
void HBSetEnabled(bool enabled) {
    static dispatch_once_t once;
    dispatch_once(&once,^{
        hbTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
        dispatch_source_set_timer(hbTimer,dispatch_time(DISPATCH_TIME_NOW,150*NSEC_PER_MSEC),150*NSEC_PER_MSEC,20*NSEC_PER_MSEC);
        dispatch_source_set_event_handler(hbTimer,^{HBTick();});
        dispatch_resume(hbTimer);
    });
    hbEnabled=enabled;hbEnableAt=[NSDate timeIntervalSinceReferenceDate];hbStableState=-999;hbStateStableAt=hbEnableAt;hbPreviousState=-999;hbLastTarget=nullptr;hbRaidView=nullptr;hbRaidService=nullptr;hbDigCount=0;hbPigInFlight=false;hbPigFinished=0;
    HBLog([NSString stringWithFormat:@"TOGGLE enabled=%d",enabled]);
    if(enabled) { HBResolve(); HBLog([NSString stringWithFormat:@"TIMER_READY retained=%d",hbTimer!=nullptr]); }
}
bool HBEnabled(void) {return hbEnabled;}
NSString *HBTrace(void) {return [@"ONGNONG HEO BUA TRACE V3 CALLBACK\n" stringByAppendingString:[hbLines componentsJoinedByString:@"\n"]?:@""];}
