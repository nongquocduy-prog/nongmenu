#import "AutoBuild.h"
#import "../Helper/Il2cpp.h"
#import <dispatch/dispatch.h>
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <cstring>
static NSMutableArray<NSString *> *abLines;
static bool abEnabled = false;
static bool abReady = false;
static bool abResolving = false;
static void *(*abGetInstance)(void) = nullptr;
static int (*abGetState)(void *) = nullptr;
static bool (*abCanLevel)(void *) = nullptr;
static void (*abBuild)(void *,int,bool,void *,void *,void *,bool) = nullptr;
static void (*abSwipeDown)(void *) = nullptr;
static void (*abSwipeUp)(void *) = nullptr;
static void (*abNextVillage)(void *) = nullptr;
static void (*abVillageClick)(void *) = nullptr;
static int abIndex = 0;
static int abLastState = -999;
static NSTimeInterval abStableAt = 0;
static NSTimeInterval abLastAction = 0;
static NSTimeInterval abLastResolve = 0;
static int abTicks = 0;
static void *abRewardCollect = nullptr;
static void *abSaleBack = nullptr;
static void *abRewardClose = nullptr;
static void *abChestSkip = nullptr;
static void *abChestClick = nullptr;
static void *abSaleClose = nullptr;
static bool abSaleCloseWithBool = false;
static NSTimeInterval abLastDiagnostic = 0;
static int abBuildCount = 0;
typedef void *(*ABClassGetType)(void *);
typedef void *(*ABTypeGetObject)(void *);
typedef void *(*ABResolveIcall)(const char *);
typedef monoArray<void *> *(*ABFindObjects)(void *,bool);
typedef monoArray<void *> *(*ABFindObjectsOne)(void *);
static ABClassGetType abClassGetType = nullptr;
static ABTypeGetObject abTypeGetObject = nullptr;
static ABFindObjects abFindObjects = nullptr;
static ABFindObjectsOne abFindObjectsOne = nullptr;
static void *abRewardType = nullptr, *abChestType = nullptr, *abChestCtrlType = nullptr, *abSaleType = nullptr;
static void *abChestCtrlSkip = nullptr, *abChestCtrlClick = nullptr;
static NSTimeInterval abRewardAt=0, abChestAt=0, abSaleAt=0, abNextAt=0, abChestWait=0;
static void *abLastChest=nullptr;
static int abChestStep=0;
static void ABLog(NSString *fmt, ...);
static void *ABFind(const char *klass, void **cache) {
    if ((!abFindObjects && !abFindObjectsOne) || !abClassGetType || !abTypeGetObject) return nullptr;
    if (!*cache) {
        void *c=Il2CppGetClassType("Assembly-CSharp.dll",((strcmp(klass,"OpenChestPopupController")==0 || strcmp(klass,"OpenChestPopupView")==0)?"MoonActive.Rewards.MultipleChests.Popup":""),klass);
        if (!c) return nullptr;
        void *t=abClassGetType(c);
        if (!t) return nullptr;
        *cache=abTypeGetObject(t);
    }
    monoArray<void *> *items=abFindObjects ? abFindObjects(*cache,false) : (abFindObjectsOne ? abFindObjectsOne(*cache) : nullptr);
    if (!items) return nullptr;
    int n=items->getCapacity();
    for(int i=0;i<n && i<20;i++) if(items->m_Items[i]) return items->m_Items[i];
    return nullptr;
}
static bool ABHandlePopups(NSTimeInterval now) {
    void *reward=ABFind("VillageMasterRewardsPopup",&abRewardType);
    if(reward) {
        if(now-abRewardAt>=1.8) {
            abRewardAt=now; abLastAction=now;
            if(abRewardCollect) {ABLog(@"REWARD_COLLECT"); ((void(*)(void *))abRewardCollect)(reward);}
            else if(abRewardClose) {ABLog(@"REWARD_CLOSE"); ((void(*)(void *))abRewardClose)(reward);}
            else ABLog(@"REWARD_NO_METHOD");
        }
        return true;
    }
    void *sale=ABFind("GenericSalePopup",&abSaleType);
    if(sale) {
        if(now-abSaleAt>=2.0) {
            abSaleAt=now;abLastAction=now;
            if(abSaleClose) {ABLog(@"SALE_CLOSE"); if (abSaleCloseWithBool) ((void(*)(void *,bool))abSaleClose)(sale,true);
                else ((void(*)(void *))abSaleClose)(sale);}
            else ABLog(@"SALE_NO_METHOD");
        }
        return true;
    }
    void *chest=ABFind("OpenChestPopupView",&abChestType);
    bool controller=false;
    if(!chest) {chest=ABFind("OpenChestPopupController",&abChestCtrlType);controller=chest!=nullptr;}
    if(!chest) {abLastChest=nullptr;abChestStep=0;return false;}
    if(chest!=abLastChest) {abLastChest=chest;abChestStep=0;abChestWait=now+0.25;ABLog(@"CHEST_FOUND controller=%d",controller);return true;}
    if(now<abChestWait || now-abChestAt<0.3) return true;
    void *fn=abChestStep<2?(controller?abChestCtrlSkip:abChestSkip):(controller?abChestCtrlClick:abChestClick);
    if(!fn) fn=controller?abChestCtrlClick:abChestClick;
    if(!fn) fn=controller?abChestCtrlSkip:abChestSkip;
    if(fn) {
        abChestAt=now;abLastAction=now;
        ABLog(@"CHEST_ACTION step=%d controller=%d",abChestStep,controller);
        ((void(*)(void *))fn)(chest);
        abChestStep++;abChestWait=now+(abChestStep<2?0.30:0.75);
    } else if(abChestStep==0) {ABLog(@"CHEST_NO_METHOD");abChestStep=1;}
    return true;
}

static void ABLog(NSString *fmt, ...) {
    va_list args; va_start(args,fmt);
    NSString *message = [[NSString alloc] initWithFormat:fmt arguments:args]; va_end(args);
    if (!abLines) abLines = [NSMutableArray array];
    [abLines addObject:[NSString stringWithFormat:@"%.3f %@",[NSDate timeIntervalSinceReferenceDate],message]];
    if (abLines.count > 220) [abLines removeObjectsInRange:NSMakeRange(0,abLines.count-220)];
}
static void ABResolve(void) {
    if (abResolving) return;
    abResolving = true;
    Attach();
    const char *dll="Assembly-CSharp.dll", *ns="", *cls="MainManager";
    abGetInstance=(decltype(abGetInstance))get_offset(dll,ns,cls,"get_Instance",0);
    abGetState=(decltype(abGetState))get_offset(dll,ns,cls,"get_CurrentGameState",0);
    abCanLevel=(decltype(abCanLevel))get_offset(dll,ns,cls,"get_ReadyToLevelUp",0);
    abBuild=(decltype(abBuild))get_offset(dll,ns,cls,"AttemptToBuildStructure",6);
    abSwipeDown=(decltype(abSwipeDown))get_offset(dll,ns,cls,"SwipeDown",0);
    abSwipeUp=(decltype(abSwipeUp))get_offset(dll,ns,cls,"SwipeUp",0);
    abNextVillage=(decltype(abNextVillage))get_offset(dll,ns,cls,"MoveToNextVillage",0);
    abVillageClick=(decltype(abVillageClick))get_offset(dll,ns,"VillageComplete","OnGoToNextIslandBtnClicked",0);
    ABResolveIcall resolve=(ABResolveIcall)dlsym(RTLD_DEFAULT,"il2cpp_resolve_icall");
    abClassGetType=(ABClassGetType)dlsym(RTLD_DEFAULT,"il2cpp_class_get_type");
    abTypeGetObject=(ABTypeGetObject)dlsym(RTLD_DEFAULT,"il2cpp_type_get_object");
    if(resolve) {
        abFindObjects=(ABFindObjects)resolve("UnityEngine.Object::FindObjectsOfType(System.Type,System.Boolean)");
        abFindObjectsOne=(ABFindObjectsOne)resolve("UnityEngine.Object::FindObjectsOfType(System.Type)");
    }
    ABLog(@"POPUP_FIND ready=%d",(!!abFindObjects || !!abFindObjectsOne) && !!abClassGetType && !!abTypeGetObject);
    abChestCtrlSkip=get_offset(dll,"MoonActive.Rewards.MultipleChests.Popup","OpenChestPopupController","OnSkipClick",0);
    abChestCtrlClick=get_offset(dll,"MoonActive.Rewards.MultipleChests.Popup","OpenChestPopupController","OnClick",0);
    abRewardCollect=get_offset(dll,ns,"VillageMasterRewardsPopup","CollectReward",0);
    abRewardClose=get_offset(dll,ns,"VillageMasterRewardsPopup","CloseButtonClicked",0);
    abChestSkip=get_offset(dll,"MoonActive.Rewards.MultipleChests.Popup","OpenChestPopupView","OnSkipClick",0);
    if (!abChestSkip) abChestSkip=get_offset(dll,ns,"OpenChestPopupView","OnSkipClick",0);
    abChestClick=get_offset(dll,"MoonActive.Rewards.MultipleChests.Popup","OpenChestPopupView","OnClick",0);
    if (!abChestClick) abChestClick=get_offset(dll,ns,"OpenChestPopupView","OnClick",0);
    abSaleClose=get_offset(dll,ns,"GenericSalePopup","CloseButtonClicked",1);
    abSaleCloseWithBool=(abSaleClose!=nullptr);
    if (!abSaleClose) abSaleClose=get_offset(dll,ns,"GenericSalePopup","OnBackPressed",0);
    ABLog(@"REWARD_RESOLVE collect=%d close=%d chestSkip=%d chestClick=%d ctrlSkip=%d ctrlClick=%d saleClose=%d find2=%d find1=%d",!!abRewardCollect,!!abRewardClose,!!abChestSkip,!!abChestClick,!!abChestCtrlSkip,!!abChestCtrlClick,!!abSaleClose,!!abFindObjects,!!abFindObjectsOne);
    abReady=abGetInstance && abGetState && abCanLevel && abBuild && (abSwipeDown || abSwipeUp);
    ABLog(@"RESOLVE ready=%d instance=%d state=%d level=%d build=%d down=%d up=%d next=%d click=%d",abReady,!!abGetInstance,!!abGetState,!!abCanLevel,!!abBuild,!!abSwipeDown,!!abSwipeUp,!!abNextVillage,!!abVillageClick);
    abResolving=false;
}
static void ABTick(void) {
    if (!abEnabled) return;
    NSTimeInterval now=[NSDate timeIntervalSinceReferenceDate];
    if (!abReady) {
        if (now-abLastResolve>3.0) {abLastResolve=now;ABResolve();}
        return;
    }
    void *manager=abGetInstance ? abGetInstance() : nullptr;
    if (!manager) {if (++abTicks%12==0) ABLog(@"WAIT manager_missing");return;}
    int state=abGetState(manager);
    if (state!=abLastState) {ABLog(@"STATE old=%d new=%d",abLastState,state);abLastState=state;abStableAt=now;return;}
    if (state!=0 && state!=3 && state!=5) {if (++abTicks%12==0) ABLog(@"WAIT state=%d",state);return;}
    if (now-abStableAt < (state==5?0.9:0.75)) return;
    if (ABHandlePopups(now)) return;
    if (now-abLastAction < (state==5 ? 1.0 : 0.08)) return;
    if (now-abLastDiagnostic>12.0) {
        abLastDiagnostic=now;
        ABLog(@"REWARD_WAIT popup_instance_tracking_missing collect=%d close=%d chest=%d next=%d",!!abRewardCollect,!!abRewardClose,!!abChestSkip,!!abNextVillage);
    }
    bool level=abCanLevel(manager);
    if (level) {
        if(now-abNextAt>3.0) {abNextAt=now;ABLog(@"LEVEL_READY state=%d next=%d click=%d",state,!!abNextVillage,!!abVillageClick);}
        return;
    }
    abLastAction=now;
    if (state==0 || state==3) {
        int index=abIndex++%5;
        ABLog(@"BUILD_CALL index=%d state=%d count=%d",index,state,++abBuildCount);
        abBuild(manager,index,true,nullptr,nullptr,nullptr,true);
    } else if (state==5) {
        ABLog(@"SWIPE_CALL down=%d",!!abSwipeDown);
        if (abSwipeDown) abSwipeDown(manager); else if(abSwipeUp) abSwipeUp(manager);
    }
}
void ABStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        ABLog(@"INIT AUTO_BUILD_V4 source=V13 reference_build_interval=0.08 reward_actions=1");
        dispatch_source_t timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
        dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,80*NSEC_PER_MSEC),80*NSEC_PER_MSEC,15*NSEC_PER_MSEC);
        dispatch_source_set_event_handler(timer,^{ABTick();});
        dispatch_resume(timer);
        (void)CFBridgingRetain(timer);
    });
}
void ABSetEnabled(bool enabled) {
    ABStart(); abEnabled=enabled;abLastState=-999;abStableAt=0;abLastAction=0;
    ABLog(@"TOGGLE enabled=%d",enabled);
    if (enabled) {abLastResolve=0;ABResolve();}
}
bool ABEnabled(void) {return abEnabled;}
NSString *ABTrace(void) {
    ABStart();
    return [@"ONGNONG AUTO BUILD TRACE V3\n" stringByAppendingString:[abLines componentsJoinedByString:@"\n"]];
}
