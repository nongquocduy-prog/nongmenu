#pragma once
#import <Foundation/Foundation.h>
void HDTraceSetEnabled(bool enabled);
bool HDTraceEnabled(void);
NSString *HDTraceCopy(void);
