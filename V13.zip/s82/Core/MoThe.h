#pragma once
#import <Foundation/Foundation.h>
void MTSetEnabled(bool enabled);
bool MTEnabled(void);
NSString *MTTrace(void);
