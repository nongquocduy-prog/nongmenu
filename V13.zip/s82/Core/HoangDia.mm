#import "HoangDia.h"
#import "../Helper/Il2cpp.h"
#import <UIKit/UIKit.h>
#import <dispatch/dispatch.h>
#import <dlfcn.h>
#import <cstring>
#import <cstdlib>
#import <cstdint>
static bool hdEnabled=false;
static unsigned long hdEpoch=0;
static unsigned long hdRunGeneration=0;
static unsigned long hdTickCount=0;
static bool hdStepScheduled=false;
static dispatch_source_t hdTraceTimer=nullptr;
static NSMutableArray<NSString *> *hdLines;
static const char *hdNamespace="MoonActive.Minigame.Expedition";
struct HDMethod {const char *cls;const char *name;int argc;};
static const HDMethod hdMethods[]={
{"NonLinearExpeditionInteractionSelectionManager","AutoSelectNextInteraction",1},
{"NonLinearExpeditionInteractionSelectionManager","SelectInteraction",1},
{"ExpeditionStateModel","get_CurrentState",0},
{"NonLinearExpeditionInfoModel","get_SelectedInteractionId",0},
{"NonLinearExpeditionInfoModel","IsPassedInteraction",1},
{"NonLinearExpeditionInfoModel","GetInteractionDataById",1},
{"NonLinearInteractionTooltipController","IsAnyTooltipOpen",0},
{"NonLinearInteractionTooltipController","TryCloseTooltip",1},
{"NonLinearInteractionTooltipController","GetInteractionIdForItemStateHolder",1},
{"NonLinearInteractionTooltipController","ExecuteInteractionAction",1},
{"NonLinearInteractionTooltipController","ExecuteTeleportAction",1},
{"NonLinearInteractionTooltipController","IsTeleportGateSpawnId",1},
{"NonLinearOutOfCurrencyController","ShowAutoOutOfCurrencyForInteraction",1}
};
static void HDLog(NSString *s){if(!hdLines)hdLines=[NSMutableArray array];[hdLines addObject:[NSString stringWithFormat:@"%.3f %@",[NSDate timeIntervalSinceReferenceDate],s]];if(hdLines.count>220)[hdLines removeObjectsInRange:NSMakeRange(0,hdLines.count-220)];}
// Read-only IL2CPP metadata inspection. No method invocation or object dereference.
static void HDMetadata(void){
    using ClassMethods=void*(*)(void*,void**);
    using MethodName=const char*(*)(void*);
    using MethodCount=uint32_t(*)(void*);
    using MethodParam=void*(*)(void*,uint32_t);
    using MethodReturn=void*(*)(void*);
    using TypeName=char*(*)(void*);
    using ClassFields=void*(*)(void*,void**);
    using FieldName=const char*(*)(void*);
    auto methods=(ClassMethods)dlsym(RTLD_DEFAULT,"il2cpp_class_get_methods");
    auto mname=(MethodName)dlsym(RTLD_DEFAULT,"il2cpp_method_get_name");
    auto mcount=(MethodCount)dlsym(RTLD_DEFAULT,"il2cpp_method_get_param_count");
    auto mparam=(MethodParam)dlsym(RTLD_DEFAULT,"il2cpp_method_get_param");
    auto mreturn=(MethodReturn)dlsym(RTLD_DEFAULT,"il2cpp_method_get_return_type");
    auto tname=(TypeName)dlsym(RTLD_DEFAULT,"il2cpp_type_get_name");
    auto freeName=(void(*)(void*))dlsym(RTLD_DEFAULT,"il2cpp_free");
    auto fields=(ClassFields)dlsym(RTLD_DEFAULT,"il2cpp_class_get_fields");
    auto fname=(FieldName)dlsym(RTLD_DEFAULT,"il2cpp_field_get_name");
    HDLog([NSString stringWithFormat:@"METADATA_API methods=%d name=%d count=%d param=%d return=%d type=%d fields=%d",methods!=nullptr,mname!=nullptr,mcount!=nullptr,mparam!=nullptr,mreturn!=nullptr,tname!=nullptr,fields!=nullptr]);
    if(!methods||!mname||!mcount||!mparam||!mreturn||!tname)return;
    for(const HDMethod &target:hdMethods){
        void *klass=Il2CppGetClassType("Assembly-CSharp.dll",hdNamespace,target.cls);
        if(!klass)continue;
        void *iter=nullptr;int matches=0;
        for(void *m=methods(klass,&iter);m && matches<5;m=methods(klass,&iter)){
            const char *name=mname(m);if(!name||strcmp(name,target.name))continue;
            uint32_t count=mcount(m);if(count>16)continue;
            NSMutableString *sig=[NSMutableString string];
            for(uint32_t i=0;i<count;i++){
                void *type=mparam(m,i);char *tn=type?tname(type):nullptr;
                [sig appendFormat:@"%@%s",i?@",":@"",tn?tn:"?"];
                if(tn&&freeName)freeName(tn);
            }
            void *ret=mreturn(m);char *rn=ret?tname(ret):nullptr;
            HDLog([NSString stringWithFormat:@"METHOD_SIGNATURE class=%s method=%s argc=%u expected=%d return=%s args=(%@) abi=unverified",target.cls,target.name,count,target.argc,rn?rn:"?",sig]);
            if(rn&&freeName)freeName(rn);
            matches++;
        }
        if(!matches)HDLog([NSString stringWithFormat:@"SIGNATURE_MISSING class=%s method=%s",target.cls,target.name]);
    }
    const char *important[]={"NonLinearExpeditionInteractionSelectionManager","NonLinearInteractionTooltipController","NonLinearExpeditionInfoModel"};
    if(fields&&fname)for(const char *cls:important){
        void *klass=Il2CppGetClassType("Assembly-CSharp.dll",hdNamespace,cls);
        if(!klass)continue;
        void *iter=nullptr;int n=0;
        for(void *f=fields(klass,&iter);f&&n<80;f=fields(klass,&iter),n++){
            const char *name=fname(f);if(!name)continue;
            NSString *field=[NSString stringWithUTF8String:name];
            NSString *lower=[field lowercaseString];
            if([lower containsString:@"instance"]||[lower containsString:@"controller"]||[lower containsString:@"manager"]||[lower containsString:@"model"])
                HDLog([NSString stringWithFormat:@"INSTANCE_FIELD_CANDIDATE class=%s field=%s value=not_read",cls,name]);
        }
        HDLog([NSString stringWithFormat:@"INSTANCE_SCAN class=%s fields_checked=%d instance_verified=0",cls,n]);
    }
}
static void HDNamespaceSearch(void){
    auto img=Il2CppGetImageByName("Assembly-CSharp.dll");
    auto count=(size_t(*)(void*))dlsym(RTLD_DEFAULT,"il2cpp_image_get_class_count");
    auto get=(void*(*)(void*,size_t))dlsym(RTLD_DEFAULT,"il2cpp_image_get_class");
    auto name=(const char*(*)(void*))dlsym(RTLD_DEFAULT,"il2cpp_class_get_name");
    auto ns=(const char*(*)(void*))dlsym(RTLD_DEFAULT,"il2cpp_class_get_namespace");
    if(!img||!count||!get||!name||!ns){HDLog(@"NAMESPACE_SCAN unavailable=1");return;}
    size_t total=count(img);size_t hits=0;
    for(size_t i=0;i<total && i<100000;i++){
        void *klass=get(img,i);if(!klass)continue;
        const char *n=name(klass);if(!n)continue;
        if(strstr(n,"ExpeditionStateModel")||strstr(n,"NonLinearInteractionData")){
            HDLog([NSString stringWithFormat:@"CLASS_CANDIDATE name=%s namespace=%s",n,ns(klass)?ns(klass):""]);hits++;
        }
    }
    HDLog([NSString stringWithFormat:@"NAMESPACE_SCAN classes=%lu candidates=%lu",(unsigned long)total,(unsigned long)hits]);
}

// V7: use the actual 2781 manager-discovery mechanism: IL2CPP liveness
// from statics, NOT UnityEngine.Object::FindObjectsOfType.
static void *hdManager=nullptr,*hdTooltip=nullptr,*hdInfo=nullptr,*hdState=nullptr;
static void *hdBound[sizeof(hdMethods)/sizeof(hdMethods[0])]={};
struct HDLiveResult {void *object=nullptr; int callbacks=0;};
static void *HDLiveRealloc(void *memory,size_t size,void *userData){
    (void)userData;
    if(!size){free(memory);return nullptr;}
    return realloc(memory,size);
}
static void HDLiveCallback(void **objects,int count,void *userData){
    HDLiveResult *r=(HDLiveResult*)userData;
    if(!r||!objects||count<=0)return;
    r->callbacks+=count;
    if(r->object)return;
    for(int i=0;i<count;i++)if((uintptr_t)objects[i]>0x10000){r->object=objects[i];break;}
}
static void HDDiscoverLiveObjects(void){
    hdManager=hdTooltip=hdInfo=hdState=nullptr;
    using Allocate=void*(*)(void*,int,void(*)(void**,int,void*),void*,void*(*)(void*,size_t,void*));
    using Calculate=void(*)(void*);
    using Free=void(*)(void*);
    using FieldFromName=void*(*)(void*,const char*);
    using FieldGetValue=void(*)(void*,void*,void*);
    auto allocate=(Allocate)dlsym(RTLD_DEFAULT,"il2cpp_unity_liveness_allocate_struct");
    auto calculate=(Calculate)dlsym(RTLD_DEFAULT,"il2cpp_unity_liveness_calculation_from_statics");
    auto finalize=(Calculate)dlsym(RTLD_DEFAULT,"il2cpp_unity_liveness_finalize");
    auto freeState=(Free)dlsym(RTLD_DEFAULT,"il2cpp_unity_liveness_free_struct");
    auto fieldFromName=(FieldFromName)dlsym(RTLD_DEFAULT,"il2cpp_class_get_field_from_name");
    auto fieldValue=(FieldGetValue)dlsym(RTLD_DEFAULT,"il2cpp_field_get_value");
    void *klass=Il2CppGetClassType("Assembly-CSharp.dll",hdNamespace,"NonLinearExpeditionInteractionSelectionManager");
    HDLog([NSString stringWithFormat:@"LIVENESS_API_V7 class=%d allocate=%d statics=%d finalize=%d free=%d field=%d value=%d",klass!=nullptr,allocate!=nullptr,calculate!=nullptr,finalize!=nullptr,freeState!=nullptr,fieldFromName!=nullptr,fieldValue!=nullptr]);
    if(!klass||!allocate||!calculate||!finalize||!freeState||!fieldFromName||!fieldValue){HDLog(@"LIVENESS_V7 blocked=missing_api");return;}
    HDLiveResult result;
    void *scan=allocate(klass,64,HDLiveCallback,&result,HDLiveRealloc);
    HDLog([NSString stringWithFormat:@"LIVENESS_ALLOC_V7 state=%d",scan!=nullptr]);
    if(!scan)return;
    calculate(scan);
    finalize(scan);
    freeState(scan);
    HDLog([NSString stringWithFormat:@"LIVENESS_RESULT_V7 callbacks=%d manager=%d",result.callbacks,result.object!=nullptr]);
    if(!result.object)return;
    void *ft=fieldFromName(klass,"m_NonLinearInteractionTooltipController");
    void *fi=fieldFromName(klass,"m_NonLinearExpeditionInfoModel");
    void *fs=fieldFromName(klass,"m_ExpeditionStateModel");
    void *tooltip=nullptr,*info=nullptr,*state=nullptr;
    if(ft)fieldValue(result.object,ft,&tooltip);
    if(fi)fieldValue(result.object,fi,&info);
    if(fs)fieldValue(result.object,fs,&state);
    HDLog([NSString stringWithFormat:@"LIVENESS_FIELDS_V7 tooltip_field=%d info_field=%d state_field=%d tooltip=%d info=%d state=%d",ft!=nullptr,fi!=nullptr,fs!=nullptr,tooltip!=nullptr,info!=nullptr,state!=nullptr]);
    if(tooltip&&info){hdManager=result.object;hdTooltip=tooltip;hdInfo=info;hdState=state;}
    HDLog([NSString stringWithFormat:@"INSTANCE_READY manager=%d tooltip=%d info=%d state=%d",hdManager!=nullptr,hdTooltip!=nullptr,hdInfo!=nullptr,hdState!=nullptr]);
    HDLog(@"ACTION_GATE status=one_shot_test method=AutoSelectNextInteraction");
}
// V8: one-shot managed callback, matching the original 2781 invocation pattern.
// Run only after a liveness scan has supplied a valid manager; never call raw
// method pointers as if UniTask were a C void return.
static void HDTryAutoSelectOnce(void){
    if (!hdEnabled || !hdManager) { HDLog(@"AUTO_SELECT_V8 blocked=no_manager"); return; }
    using GetMethods=void*(*)(void*,void**);
    using GetName=const char*(*)(void*);
    using GetCount=uint32_t(*)(void*);
    using Invoke=void*(*)(void*,void*,void**,void**);
    auto methods=(GetMethods)dlsym(RTLD_DEFAULT,"il2cpp_class_get_methods");
    auto name=(GetName)dlsym(RTLD_DEFAULT,"il2cpp_method_get_name");
    auto count=(GetCount)dlsym(RTLD_DEFAULT,"il2cpp_method_get_param_count");
    auto invoke=(Invoke)dlsym(RTLD_DEFAULT,"il2cpp_runtime_invoke");
    void *klass=Il2CppGetClassType("Assembly-CSharp.dll",hdNamespace,"NonLinearExpeditionInteractionSelectionManager");
    if(!klass||!methods||!name||!count||!invoke){HDLog(@"AUTO_SELECT_V8 blocked=missing_api");return;}
    void *method=nullptr,*iter=nullptr;
    for(void *m=methods(klass,&iter);m;m=methods(klass,&iter)){
        const char *n=name(m);
        if(n&&!strcmp(n,"AutoSelectNextInteraction")&&count(m)==1){method=m;break;}
    }
    if(!method){HDLog(@"AUTO_SELECT_V8 blocked=method_missing");return;}
    bool supportOutOfCurrency=false;
    void *args[]={&supportOutOfCurrency};
    void *exception=nullptr;
    HDLog(@"AUTO_SELECT_V8 invoke_begin supportOutOfCurrency=0");
    invoke(method,hdManager,args,&exception);
    HDLog([NSString stringWithFormat:@"AUTO_SELECT_V8 invoke_end exception=%d",exception!=nullptr]);
}
// V10: state-aware diagnostics inspired by the 2781 RunAutoStep phase machine.
// Read the selected interaction and tooltip state on each tick; do not blindly
// repeat a UniTask call when no gameplay progress has been observed.
static unsigned long hdStableTicks=0;
static NSString *hdLastSelection=nil;
static bool hdLastTooltip=false;
static bool hdHasObservedState=false;
// V13.2: selection confirmation followed by a single guarded collect attempt.
// Portal remains disabled pending separate verification.
static bool hdSelectionRequested=false;
static unsigned long hdSelectionRequestTick=0;
static NSString *hdSelectionBefore=nil;
static bool hdSelectionConfirmed=false;
static void *HDLookupMethod(const char *cls,const char *method,int argc){
    using Direct=void*(*)(void*,const char*,int);
    using Parent=void*(*)(void*);
    using Methods=void*(*)(void*,void**);
    using Name=const char*(*)(void*);
    using Count=uint32_t(*)(void*);
    auto direct=(Direct)dlsym(RTLD_DEFAULT,"il2cpp_class_get_method_from_name");
    auto parent=(Parent)dlsym(RTLD_DEFAULT,"il2cpp_class_get_parent");
    auto methods=(Methods)dlsym(RTLD_DEFAULT,"il2cpp_class_get_methods");
    auto name=(Name)dlsym(RTLD_DEFAULT,"il2cpp_method_get_name");
    auto count=(Count)dlsym(RTLD_DEFAULT,"il2cpp_method_get_param_count");
    void *klass=Il2CppGetClassType("Assembly-CSharp.dll",hdNamespace,cls);
    if(!klass){HDLog([NSString stringWithFormat:@"HD_LOOKUP_V11 class=%s method=%s result=class_missing",cls,method]);return nullptr;}
    for(int depth=0;klass&&depth<8;depth++,klass=parent?parent(klass):nullptr){
        if(direct){void *m=direct(klass,method,argc);if(m){HDLog([NSString stringWithFormat:@"HD_LOOKUP_V11 class=%s method=%s depth=%d path=direct found=1",cls,method,depth]);return m;}}
        if(methods&&name&&count){void *iter=nullptr;for(void *m=methods(klass,&iter);m;m=methods(klass,&iter)){
            const char *n=name(m);if(n&&!strcmp(n,method)&&count(m)==(uint32_t)argc){HDLog([NSString stringWithFormat:@"HD_LOOKUP_V11 class=%s method=%s depth=%d path=enumerate found=1",cls,method,depth]);return m;}
        }}
    }
    HDLog([NSString stringWithFormat:@"HD_LOOKUP_V11 class=%s method=%s result=not_found direct_api=%d enumerate_api=%d",cls,method,direct!=nullptr,methods!=nullptr]);
    return nullptr;
}
static NSString *HDManagedString(void *p){
    if(!p)return @"";
    auto *v=(Il2CppString*)p;
    int len=v->length;
    if(len<0||len>512)return @"<invalid_length>";
    return [[NSString alloc] initWithCharacters:(const unichar*)&v->start_char length:len]?:@"";
}
// V13.3: resolve action-data class across all loaded assemblies as in 2781.
static void *HDClassAnyImage(const char *ns,const char *cls,const char **imageName){
    if(imageName)*imageName=nullptr;
    using Domain=void*(*)();using Assemblies=void**(*)(void*,size_t*);
    using Image=void*(*)(void*);using FromName=void*(*)(void*,const char*,const char*);
    using ImageName=const char*(*)(void*);
    auto domain=(Domain)dlsym(RTLD_DEFAULT,"il2cpp_domain_get");
    auto assemblies=(Assemblies)dlsym(RTLD_DEFAULT,"il2cpp_domain_get_assemblies");
    auto image=(Image)dlsym(RTLD_DEFAULT,"il2cpp_assembly_get_image");
    auto fromName=(FromName)dlsym(RTLD_DEFAULT,"il2cpp_class_from_name");
    auto name=(ImageName)dlsym(RTLD_DEFAULT,"il2cpp_image_get_name");
    if(!domain||!assemblies||!image||!fromName)return nullptr;
    void *d=domain();if(!d)return nullptr;
    size_t count=0;void **items=assemblies(d,&count);
    if(!items||count>4096)return nullptr;
    for(size_t i=0;i<count;i++){
        void *im=items[i]?image(items[i]):nullptr;if(!im)continue;
        void *klass=fromName(im,ns,cls);
        if(klass){if(imageName&&name)*imageName=name(im);return klass;}
    }
    return nullptr;
}
static void *HDMethodInClass(void *klass,const char *method,int argc){
    using Direct=void*(*)(void*,const char*,int);
    auto direct=(Direct)dlsym(RTLD_DEFAULT,"il2cpp_class_get_method_from_name");
    return klass&&direct?direct(klass,method,argc):nullptr;
}
static uint32_t hdActionHandle=0;
static double hdActionHandleReleaseAt=0;
static void HDRetireActionHandle(bool force=false){
    if(!hdActionHandle)return;
    if(!force && [NSDate timeIntervalSinceReferenceDate]<hdActionHandleReleaseAt)return;
    using Free=void(*)(uint32_t);
    auto freeHandle=(Free)dlsym(RTLD_DEFAULT,"il2cpp_gchandle_free");
    if(freeHandle)freeHandle(hdActionHandle);
    hdActionHandle=0;hdActionHandleReleaseAt=0;
}
// V12: Port of 2781 CreateFreshInteractionActionData/InvokeCollectAction.
// Only issue one collect per selected target; wait for actual passed state.
static NSString *hdActionTarget=nil;
static bool hdActionIssued=false;
static unsigned long hdActionTicks=0;
static void HDCollectStepV12(void *selected, NSString *idValue, bool tooltipOpen){
    if(!selected || !idValue.length){hdActionTarget=nil;hdActionIssued=false;hdActionTicks=0;return;}
    if(![idValue isEqualToString:hdActionTarget]){hdActionTarget=[idValue copy];hdActionIssued=false;hdActionTicks=0;}
    using Invoke=void*(*)(void*,void*,void**,void**);
    using Unbox=void*(*)(void*);
    auto invoke=(Invoke)dlsym(RTLD_DEFAULT,"il2cpp_runtime_invoke");
    auto unbox=(Unbox)dlsym(RTLD_DEFAULT,"il2cpp_object_unbox");
    if(!invoke||!unbox)return;
    void *passedMethod=HDLookupMethod("NonLinearExpeditionInfoModel","IsPassedInteraction",1);
    if(!passedMethod){HDLog(@"HD_COLLECT_V12 blocked=passed_method_missing");return;}
    void *args[]={selected};void *ex=nullptr;
    void *passedObj=invoke(passedMethod,hdInfo,args,&ex);
    if(ex||!passedObj){HDLog(@"HD_COLLECT_V12 blocked=passed_query_failed");return;}
    void *raw=unbox(passedObj);if(!raw)return;
    bool passed=*(uint8_t*)raw!=0;
    if(passed && hdActionIssued){HDLog(@"HD_COLLECT_V13 result=passed_after_action target_confirmed=1");hdActionIssued=false;hdEnabled=false;HDLog(@"HD_PHASE_V13 phase=stopped reason=collect_confirmed_one_shot");return;}
    if(passed && !hdActionIssued){HDLog(@"HD_COLLECT_V13 phase=preexisting_passed_not_proof_of_collection");}
    if(hdActionIssued){
        hdActionTicks++;
        if(hdActionTicks==4||hdActionTicks==12)HDLog([NSString stringWithFormat:@"HD_COLLECT_V12 phase=waiting_result ticks=%lu tooltip=%d",hdActionTicks,tooltipOpen]);
        if(hdActionTicks>20){HDLog(@"HD_COLLECT_V13 stop=unconfirmed_action_no_retry");hdEnabled=false;}
        return;
    }
    if(!tooltipOpen){HDLog(@"HD_COLLECT_V12 phase=waiting_tooltip");return;}
    void *teleportMethod=HDLookupMethod("NonLinearInteractionTooltipController","IsTeleportGateSpawnId",1);
    if(!teleportMethod)return;
    ex=nullptr;void *teleportObj=invoke(teleportMethod,hdTooltip,args,&ex);
    if(ex||!teleportObj)return;
    raw=unbox(teleportObj);if(!raw)return;
    bool teleport=*(uint8_t*)raw!=0;
    if(teleport){HDLog(@"HD_ACTION_V13 blocked=portal_stage_not_enabled");return;}
    const char *cls=teleport?"ExpeditionTooltipTeleportActionData":"ExpeditionTooltipInteractionActionData";
    const char *action=teleport?"ExecuteTeleportAction":"ExecuteInteractionAction";
    const char *actionImage=nullptr;
    void *klass=HDClassAnyImage(hdNamespace,cls,&actionImage);
    void *ctor=HDMethodInClass(klass,".ctor",1);
    void *method=HDLookupMethod("NonLinearInteractionTooltipController",action,1);
    HDLog([NSString stringWithFormat:@"HD_ACTION_CLASS_V13 found=%d class=%s image=%s namespace=%s",klass!=nullptr,cls,actionImage?actionImage:"none",hdNamespace]);
    HDLog([NSString stringWithFormat:@"HD_ACTION_CTOR_V13 found=%d argc=1",ctor!=nullptr]);
    using NewObj=void*(*)(void*);
    auto newObj=(NewObj)dlsym(RTLD_DEFAULT,"il2cpp_object_new");
    if(!klass||!ctor||!method||!newObj){HDLog([NSString stringWithFormat:@"HD_COLLECT_V12 blocked=action_binding cls=%s class=%d ctor=%d action=%d",cls,klass!=nullptr,ctor!=nullptr,method!=nullptr]);return;}
    void *data=newObj(klass);if(!data)return;
    ex=nullptr;invoke(ctor,data,args,&ex);
    if(ex){HDLog(@"HD_COLLECT_V12 blocked=constructor_exception");return;}
    // Keep the action object rooted during asynchronous gameplay handling.
    using GcNew=uint32_t(*)(void*,bool);
    auto gcNew=(GcNew)dlsym(RTLD_DEFAULT,"il2cpp_gchandle_new");
    if(!gcNew){HDLog(@"HD_COLLECT_V12 blocked=gchandle_api_missing");return;}
    if(hdActionHandle){HDLog(@"HD_COLLECT_V13 blocked=prior_action_still_rooted");return;}
    hdActionHandle=gcNew(data,false);
    hdActionHandleReleaseAt=[NSDate timeIntervalSinceReferenceDate]+30.0;
    if(!hdActionHandle){HDLog(@"HD_COLLECT_V13 blocked=retain_failed");return;}
    void *actionArgs[]={data};ex=nullptr;
    HDLog([NSString stringWithFormat:@"HD_COLLECT_V12 action=invoke kind=%s",teleport?"teleport":"interaction"]);
    invoke(method,hdTooltip,actionArgs,&ex);
    if(ex){HDLog(@"HD_COLLECT_V12 result=invoke_exception");hdEnabled=false;return;}
    hdActionIssued=true;hdActionTicks=0;
    HDLog(@"HD_ACTION_V13 result=invoked_waiting_confirmation source=2781_action_data_ctor");
}
static void HDObserveStepV10(void){
    if(!hdManager||!hdTooltip||!hdInfo){HDLog(@"HD_STEP_V10 blocked=instance_missing");return;}
    using Invoke=void*(*)(void*,void*,void**,void**);
    auto invoke=(Invoke)dlsym(RTLD_DEFAULT,"il2cpp_runtime_invoke");
    if(!invoke){HDLog(@"HD_STEP_V10 blocked=invoke_missing");return;}
    void *getSelected=HDLookupMethod("NonLinearExpeditionInfoModel","get_SelectedInteractionId",0);
    void *isOpen=HDLookupMethod("NonLinearInteractionTooltipController","IsAnyTooltipOpen",0);
    if(!getSelected||!isOpen){HDLog([NSString stringWithFormat:@"HD_STEP_V11 blocked=method_missing selected=%d tooltip=%d",getSelected!=nullptr,isOpen!=nullptr]);return;}
    void *exception=nullptr;
    void *selected=invoke(getSelected,hdInfo,nullptr,&exception);
    if(exception){HDLog(@"HD_STEP_V10 blocked=selected_exception");return;}
    NSString *idValue=HDManagedString(selected);
    exception=nullptr;
    void *openBox=invoke(isOpen,hdTooltip,nullptr,&exception);
    if(exception){HDLog(@"HD_STEP_V10 blocked=tooltip_exception");return;}
    bool open=false;
    if(openBox){
        using Unbox=void*(*)(void*);
        auto unbox=(Unbox)dlsym(RTLD_DEFAULT,"il2cpp_object_unbox");
        if(unbox){void *raw=unbox(openBox);if(raw)open=*(uint8_t*)raw!=0;}
    }
    bool changed=!hdHasObservedState||![idValue isEqualToString:hdLastSelection]||open!=hdLastTooltip;
    hdStableTicks=changed?0:hdStableTicks+1;
    if(changed||hdStableTicks%10==0){
        HDLog([NSString stringWithFormat:@"HD_STEP_V11 phase=%@ selected_present=%d tooltip_open=%d changed=%d stable_ticks=%lu",open?@"waiting_tooltip":(idValue.length?@"selection_present":@"waiting_selection"),idValue.length>0,open,changed,hdStableTicks]);
        HDLog([NSString stringWithFormat:@"HD_ACTION_GATE_V13 action=selection_then_collect collect=guarded_one_shot portal=disabled selected_length=%lu",(unsigned long)idValue.length]);
    }
    // V13.2: do not issue a second asynchronous selection while a tooltip is open.
    if(!hdSelectionRequested && !open){
        hdSelectionRequested=true;
        hdSelectionRequestTick=hdTickCount;
        hdSelectionBefore=[idValue copy];
        HDLog([NSString stringWithFormat:@"HD_SELECT_V13 phase=request before_present=%d generation=%lu",idValue.length>0,hdRunGeneration]);
        HDTryAutoSelectOnce();
        HDLog(@"HD_PHASE_V13 phase=waiting_game_selection reason=selection_requested");
    }else if(hdSelectionRequested && !hdSelectionConfirmed &&
             (open || ![idValue isEqualToString:hdSelectionBefore])){
        hdSelectionConfirmed=true;
        HDLog([NSString stringWithFormat:@"HD_SELECT_V13 phase=confirmed reason=%@ after_ticks=%lu",open?@"tooltip_open":@"selected_id_changed",hdTickCount-hdSelectionRequestTick]);
        HDLog(@"HD_PHASE_V13 phase=selection_confirmed next=collect_guarded");
    }else if(hdSelectionRequested && !hdSelectionConfirmed && hdTickCount-hdSelectionRequestTick==12){
        HDLog([NSString stringWithFormat:@"HD_SELECT_V13 phase=timeout reason=no_selection_change tooltip_open=%d",open]);
    }
    if(hdSelectionConfirmed && open && selected && idValue.length){
        HDLog(@"HD_PHASE_V13 phase=collect_attempt_gate tooltip=1");
        HDCollectStepV12(selected,idValue,open);
    }else if(hdActionIssued){
        HDCollectStepV12(selected,idValue,open);
    }
    HDLog((changed || hdTickCount%10==0) ? [NSString stringWithFormat:@"HD_PHASE_V13 phase=%@ tooltip=%d selection_requested=%d confirmed=%d",hdSelectionConfirmed?@"selection_confirmed":(hdSelectionRequested?@"waiting_game_selection":@"ready"),open,hdSelectionRequested,hdSelectionConfirmed] : @"HD_PHASE_V13 tick=quiet");
    hdLastSelection=[idValue copy];hdLastTooltip=open;hdHasObservedState=true;
}
// V9: original 2781-style enable/generation/tick scheduling diagnostics.
// The timer runs on the main queue. Actions are deliberately not repeated
// until the original RunAutoStep state machine has been integrated.
static void HDStartTraceTicks(void){
    if(hdTraceTimer)return;
    hdTraceTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    dispatch_source_set_timer(hdTraceTimer,dispatch_time(DISPATCH_TIME_NOW,500*NSEC_PER_MSEC),500*NSEC_PER_MSEC,100*NSEC_PER_MSEC);
    dispatch_source_set_event_handler(hdTraceTimer,^{
        if(!hdEnabled)return;
        hdTickCount++;
        HDRetireActionHandle(false);
        if(hdManager)HDObserveStepV10();
        if(hdTickCount<=6 || hdTickCount%10==0){
            HDLog([NSString stringWithFormat:@"HD_TICK_V9 count=%lu generation=%lu manager=%d tooltip=%d info=%d state=%d scheduled=%d",hdTickCount,hdRunGeneration,hdManager!=nullptr,hdTooltip!=nullptr,hdInfo!=nullptr,hdState!=nullptr,hdStepScheduled]);
            HDLog([NSString stringWithFormat:@"HD_PHASE_V9 phase=%@ reason=%@",hdManager?@"manager_ready":@"waiting_manager",hdManager?@"collect_stage_v13_2":@"instance_unavailable"]);
        }
    });
    dispatch_resume(hdTraceTimer);
    HDLog(@"HD_INIT_V9 tick_source=main_queue interval_ms=500 source=2781_tick_pattern");
}
static void HDScan(void){
    if(!hdEnabled)return;
    hdEpoch++;
    int found=0,mapped=0;
    for(const HDMethod &m:hdMethods){
        void *fn=get_offset("Assembly-CSharp.dll",hdNamespace,m.cls,m.name,m.argc);
        Dl_info di={};bool ok=fn&&dladdr(fn,&di)!=0&&di.dli_fbase;
        if(fn)found++;if(ok)mapped++;hdBound[&m-hdMethods]=ok?fn:nullptr;
        HDLog([NSString stringWithFormat:@"METHOD_%@ class=%s method=%s argc=%d namespace=%s mapped=%d image=%s",fn?@"FOUND":@"MISSING",m.cls,m.name,m.argc,hdNamespace,ok?1:0,ok&&di.dli_fname?di.dli_fname:"none"]);
    }
    const char *classes[]={"NonLinearExpeditionInteractionSelectionManager","NonLinearInteractionTooltipController","NonLinearExpeditionInfoModel","ExpeditionStateModel","NonLinearInteractionData"};
    for(const char *name:classes){
        void *klass=Il2CppGetClassType("Assembly-CSharp.dll",hdNamespace,name);
        HDLog([NSString stringWithFormat:@"CLASS_%@ class=%s namespace=%s",klass?@"FOUND":@"MISSING",name,hdNamespace]);
    }
    HDMetadata();
    HDNamespaceSearch();
    HDDiscoverLiveObjects();
    HDLog(@"HD_STEP_ENTER_V13 phase=collect_stage_armed");
    HDLog([NSString stringWithFormat:@"METHOD_BINDINGS bound=%d instance_ready=%d",mapped,hdManager!=nullptr]);
    HDLog([NSString stringWithFormat:@"RESOLVE_COMPLETE ready=%d total=%lu native_mapped=%d epoch=%lu action=collect_stage_v13_3",found,(unsigned long)(sizeof(hdMethods)/sizeof(hdMethods[0])),mapped,hdEpoch]);
}
void HDTraceSetEnabled(bool enabled){
    dispatch_async(dispatch_get_main_queue(),^{
        hdRunGeneration++;
        hdEnabled=enabled;
        hdTickCount=0;hdStableTicks=0;hdHasObservedState=false;hdLastSelection=nil;hdSelectionRequested=false;hdSelectionRequestTick=0;hdSelectionBefore=nil;hdSelectionConfirmed=false;hdActionTarget=nil;hdActionIssued=false;hdActionTicks=0;
        HDLog([NSString stringWithFormat:@"HD_ENABLE_V9 enabled=%d generation=%lu",enabled?1:0,hdRunGeneration]);
        if(enabled){HDStartTraceTicks();HDScan();}
        else {HDLog(@"HD_STOP_REASON_V9 reason=user_disabled");hdManager=hdTooltip=hdInfo=hdState=nullptr;}
    });
}
bool HDTraceEnabled(void){return hdEnabled;}
NSString *HDTraceCopy(void){HDLog([NSString stringWithFormat:@"TRACE_COPY enabled=%d epoch=%lu",hdEnabled?1:0,hdEpoch]);return [@"ONGNONG HOANG DIA TRACE V13.3\n" stringByAppendingString:[hdLines componentsJoinedByString:@"\n"]?:@""];}
