#!/usr/bin/env bash
set -euo pipefail
test -s Ongnongios1.dylib
