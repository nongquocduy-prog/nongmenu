#pragma once
#import <Foundation/Foundation.h>
FOUNDATION_EXPORT void OngDiagAdd(NSString *line);
