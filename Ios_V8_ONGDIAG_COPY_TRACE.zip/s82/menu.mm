#import "Core/OngDiagCopy.h"
#import "Core/OngnongSecureStrings.h"
#import "Core/OngnongOxorany.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import "Core/OngnongState.h"
#import "Core/OngnongHookManager.h"
#import "Core/OngnongExtras.h"
#import "Helper/Il2cpp.h"
#import "Core/Qr73c.h"
#import "UI/OngnongMenuView.h"
#import "Core/zx8f1a_gate.h"

static NSMutableArray<NSString *> *ongDiagLines;
void OngDiagAdd(NSString *line) {
    if (!line) return;
    @synchronized([NSProcessInfo processInfo]) {
        if (!ongDiagLines) ongDiagLines = [NSMutableArray array];
        [ongDiagLines addObject:line];
        if (ongDiagLines.count > 120) [ongDiagLines removeObjectAtIndex:0];
    }
    NSLog(@"ONGDIAG %@", line);
}
@interface OngDiagCopyButton : NSObject
+ (instancetype)shared;
- (void)show;
- (void)copyTrace;
@end
@implementation OngDiagCopyButton
+ (instancetype)shared { static OngDiagCopyButton *v; static dispatch_once_t once; dispatch_once(&once, ^{ v = [OngDiagCopyButton new]; }); return v; }
- (void)show {
    UIWindow *w = UIApplication.sharedApplication.keyWindow;
    if (!w) { for (UIWindow *candidate in UIApplication.sharedApplication.windows) { if (!candidate.hidden && candidate.windowLevel == UIWindowLevelNormal) { w = candidate; break; } } }
    if (!w || [w viewWithTag:867120]) return;
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.tag = 867120;
    b.frame = CGRectMake(12, 115, 144, 36);
    b.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.82];
    b.layer.cornerRadius = 9;
    [b setTitle:@"SAO CHÉP TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [b addTarget:self action:@selector(copyTrace) forControlEvents:UIControlEventTouchUpInside];
    [w addSubview:b];
}
- (void)copyTrace {
    Ongnong::Zx8fPrintDiagnostics();
    NSString *result;
    @synchronized([NSProcessInfo processInfo]) { result = [ongDiagLines componentsJoinedByString:@"\n"]; }
    [UIPasteboard generalPasteboard].string = result.length ? result : @"ONGDIAG NO_DATA";
}
@end
static void Zx8fShowMenuOnce(NSInteger days) {
    static BOOL shown = NO;
    if (shown) return;
    shown = YES;
    Ongnong::Z75012fe6dc();
    if (days == -2 || days >= 0) Ongnong::Zx8fShowRemainingToast(days);
}

static BOOL Z67d0c5a1e4(void) {
    void *dg = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_domain_get"));
    void *ga = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_domain_get_assemblies"));
    void *ag = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_assembly_get_image"));
    void *in = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_image_get_name"));
    if (!dg || !ga || !ag || !in) return NO;
    typedef void *(*DomainGetFn)(void);
    DomainGetFn domainGet = (DomainGetFn)dg;
    return domainGet && domainGet() != NULL;
}

static void Z67e38ad2c9(void) {
    static BOOL done = NO;
    static NSInteger stable = 0;
    if (done) return;
    if (!Z67d0c5a1e4()) stable = 0;
    else stable++;
    if (stable < 6) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ Z67e38ad2c9(); });
        return;
    }
    done = YES;
    Ongnong::InstallHooks();
    Ongnong::Zx8fMarkRuntimeReady();
    Ongnong::Zx8fPrintDiagnostics();
    [[OngDiagCopyButton shared] show];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ Ongnong::Zx8fPrintDiagnostics(); [[OngDiagCopyButton shared] show]; });
    Ongnong::R3nh();
}


__attribute__((constructor)) static void OngnongStart(void) {
    (void)0;
    (void)0;
    dispatch_async(dispatch_get_main_queue(), ^{
        Ongnong::Z1124fca77a();
        Ongnong::Zx8fStart(^(NSInteger days) {
            Zx8fShowMenuOnce(days);
            Ongnong::ExtrasBootstrap();
        });
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        Z67e38ad2c9();
    });
}
