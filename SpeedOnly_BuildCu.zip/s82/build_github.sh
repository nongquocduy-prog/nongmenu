#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${THEOS:=$HOME/theos}"
export THEOS
[ -f "$THEOS/makefiles/common.mk" ] || { echo 'Theos not found'; exit 1; }
make clean >/dev/null 2>&1 || true
make FINALPACKAGE=1
FOUND=$(find .theos -type f -name 'OngnongSpeed.dylib' -print -quit)
[ -n "$FOUND" ] && [ -f "$FOUND" ] || { echo 'Build output missing'; exit 1; }
sh ./vfy.sh "$FOUND"
command -v ldid >/dev/null 2>&1 && ldid -S "$FOUND" || true
cp "$FOUND" ./Ongnongios1.dylib
cp "$FOUND" ./Ongnongos.dylib
ls -lh ./Ongnongios1.dylib
