#!/bin/sh
set -eu
[ "$#" -eq 1 ] && [ -s "$1" ] || { echo 'Missing dylib'; exit 1; }
file "$1"
