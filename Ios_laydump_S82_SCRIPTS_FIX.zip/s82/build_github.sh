#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ -z "${THEOS:-}" ]; then
  THEOS="$HOME/theos"
  export THEOS
fi
if [ ! -f "$THEOS/makefiles/common.mk" ]; then
  echo "[ERROR] Theos missing: $THEOS"
  exit 1
fi
make clean >/dev/null 2>&1 || true
make FINALPACKAGE=1
FOUND=$(find .theos -type f -name 'IOSIl2CppDumper.dylib' -print | head -n 1)
if [ -z "$FOUND" ] || [ ! -f "$FOUND" ]; then
  echo '[ERROR] IOSIl2CppDumper.dylib not found'
  exit 1
fi
cp "$FOUND" ./Ongnongios1.dylib
cp "$FOUND" ./Ongnongos.dylib
sh ./vfy.sh ./Ongnongios1.dylib
printf '[OUTPUT] %s\n' "$(pwd)/Ongnongios1.dylib"
