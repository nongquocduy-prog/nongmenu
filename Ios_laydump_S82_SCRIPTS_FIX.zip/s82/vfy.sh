#!/bin/sh
set -eu
TARGET="${1:-Ongnongios1.dylib}"
[ -s "$TARGET" ] || { echo '[ERROR] dylib missing or empty'; exit 1; }
if command -v file >/dev/null 2>&1; then
  file "$TARGET"
fi
if command -v otool >/dev/null 2>&1; then
  if otool -L "$TARGET" | grep -Eiq 'CydiaSubstrate|MobileSubstrate'; then
    echo '[ERROR] jailbreak-only dependency detected'
    exit 1
  fi
fi
echo '[VERIFY] PASS'
