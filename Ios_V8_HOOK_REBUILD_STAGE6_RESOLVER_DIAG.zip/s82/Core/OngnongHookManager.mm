#include "OngnongHookManager.h"
#include "GameResolver.h"
#include "CompatibilityTrace.h"
#include <Foundation/Foundation.h>
namespace Ongnong {
void InstallHooks() {
    @autoreleasepool {
        NSLog(@"ONGNONG HOOK STAGE4: compatibility trace; hooks disabled");
        StartCompatibilityTrace();
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            for(int attempt=0;attempt<12;attempt++) {
                auto result=ResolveGameMethod("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_position", 0);
                if(result.reason=="method_metadata_found_pointer_unverified" || result.reason=="class_not_found" || result.reason=="method_not_found" || result.reason=="assembly_not_found") break;
                [NSThread sleepForTimeInterval:1.0];
            }
            NSLog(@"%s", CompatibilityReport().c_str());
        });
    }
}
void Z2c1f8801fd() {}
bool AutoBuildModuleIsEnabled() { return false; }
bool AutoBuildModuleIsPending() { return false; }
void AutoBuildModuleSetEnabled(bool enabled) {}
void AutoBuildModuleToggle() {}
bool AutoPigModuleIsEnabled() { return false; }
void AutoPigModuleSetEnabled(bool enabled) {}
void AutoPigModuleToggle() {}
bool AutoHammerModuleIsEnabled() { return false; }
void AutoHammerModuleSetEnabled(bool enabled) {}
void AutoHammerModuleToggle() {}
bool RaidHammerModuleIsEnabled() { return false; }
void RaidHammerModuleSetEnabled(bool enabled) {}
void RaidHammerModuleToggle() {}
void BetCycleRaidAutoSync() {}
bool MagicCardsModuleIsEnabled() { return false; }
void MagicCardsModuleSetEnabled(bool enabled) {}
void MagicCardsModuleToggle() {}
void HBMagicChestToggleAutoFromButton() {}
bool HBMagicChestIsAutoEnabled() { return false; }
bool StopSpinForAutoTarget() { return false; }
bool SetSlotBetStateForCycle(int state) { return false; }
int GetSlotBetStateForCycle() { return 0; }
bool SlotIsSpinningForCycle() { return false; }
bool PauseAutoSpinForCycle() { return false; }
bool StartAutoSpinForCycle() { return false; }
bool AutoMergeTryCollectPendingReward() { return false; }
}
