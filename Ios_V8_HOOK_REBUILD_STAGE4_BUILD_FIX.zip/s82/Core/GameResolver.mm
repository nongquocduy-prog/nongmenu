#include "GameResolver.h"
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <mutex>
#include <sstream>
#include <vector>
#include <string>
#include <cstring>
namespace Ongnong {
namespace {
std::mutex lock;
std::vector<std::string> events;
template<typename T> T api(void *handle, const char *name) { return reinterpret_cast<T>(dlsym(handle,name)); }
void record(const std::string &message) {
    std::lock_guard<std::mutex> guard(lock);
    if(events.size()>=256) events.erase(events.begin());
    events.push_back(message);
}
}
ResolveResult ResolveGameMethod(const char *assembly, const char *namespaze, const char *klass, const char *method, int argc) {
    if(!assembly || !klass || !method || argc<0) return {nullptr,false,"invalid_request"};
    void *handle=dlopen("UnityFramework",RTLD_NOLOAD|RTLD_NOW);
    if(!handle) handle=dlopen(nullptr,RTLD_NOW);
    if(!handle) return {nullptr,false,"runtime_unavailable"};
    using domain_get_t=void *(*)();
    using domain_assemblies_t=const void **(*)(void *,size_t *);
    using assembly_image_t=void *(*)(const void *);
    using image_name_t=const char *(*)(void *);
    using class_from_name_t=void *(*)(void *,const char *,const char *);
    using class_get_method_t=const void *(*)(void *,const char *,int);

    auto domain_get=api<domain_get_t>(handle,"il2cpp_domain_get");
    auto domain_assemblies=api<domain_assemblies_t>(handle,"il2cpp_domain_get_assemblies");
    auto assembly_image=api<assembly_image_t>(handle,"il2cpp_assembly_get_image");
    auto image_name=api<image_name_t>(handle,"il2cpp_image_get_name");
    auto class_from_name=api<class_from_name_t>(handle,"il2cpp_class_from_name");
    auto class_get_method=api<class_get_method_t>(handle,"il2cpp_class_get_method_from_name");
    if(!domain_get || !domain_assemblies || !assembly_image || !image_name || !class_from_name || !class_get_method) {
        record(std::string("RESOLVE_MISSING_API ")+klass+"."+method);
        return {nullptr,false,"il2cpp_exports_unavailable"};
    }
    void *domain=domain_get();
    if(!domain) return {nullptr,false,"domain_unavailable"};
    size_t count=0;
    const void **assemblies=domain_assemblies(domain,&count);
    if(!assemblies || count>10000) return {nullptr,false,"assemblies_unavailable"};
    for(size_t i=0;i<count;i++) {
        void *img=assembly_image(assemblies[i]);
        const char *name=img?image_name(img):nullptr;
        if(!name || strcmp(name,assembly)!=0) continue;
        void *type=class_from_name(img,namespaze?namespaze:"",klass);
        if(!type) return {nullptr,false,"class_not_found"};
        const void *info=class_get_method(type,method,argc);
        if(!info) return {nullptr,false,"method_not_found"};
        record(std::string("RESOLVE_METADATA_OK ")+klass+"."+method);
        return {const_cast<void *>(info),true,"metadata_found_executable_pointer_not_verified"};
    }
    return {nullptr,false,"assembly_not_found"};
}
std::string CompatibilityReport() {
    std::lock_guard<std::mutex> guard(lock);
    std::ostringstream out;
    out<<"ONGNONG COMPATIBILITY TRACE V1\n";
    out<<"hook_installation=disabled\n";
    out<<"metadata_only=1\n";
    for(const auto &event:events) out<<event<<"\n";
    return out.str();
}
}
