#pragma once
namespace Ongnong { void StartCompatibilityTrace(); }
