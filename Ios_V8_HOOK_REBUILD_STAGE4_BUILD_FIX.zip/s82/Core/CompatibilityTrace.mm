#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "CompatibilityTrace.h"
#import "GameResolver.h"
@interface OngnongTraceControl : NSObject
@property(nonatomic,strong) UIButton *button;
@end
@implementation OngnongTraceControl
- (void)copyReport:(id)sender {
    NSString *report=[NSString stringWithUTF8String:Ongnong::CompatibilityReport().c_str()];
    [UIPasteboard generalPasteboard].string=report ?: @"TRACE_UNAVAILABLE";
    NSString *old=[self.button titleForState:UIControlStateNormal];
    [self.button setTitle:@"COPIED" forState:UIControlStateNormal];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(1.4*NSEC_PER_SEC)),dispatch_get_main_queue(),^{ [self.button setTitle:old forState:UIControlStateNormal]; });
}
@end
namespace Ongnong {
void StartCompatibilityTrace() {
    dispatch_async(dispatch_get_main_queue(), ^{
        static OngnongTraceControl *control=nil;
        if(control) return;
        UIWindow *window=nil;
        for(UIWindowScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if(![scene isKindOfClass:[UIWindowScene class]]) continue;
            if(scene.activationState!=UISceneActivationStateForegroundActive) continue;
            for(UIWindow *candidate in scene.windows) if(candidate.isKeyWindow) { window=candidate; break; }
            if(window) break;
        }
        if(!window) return;
        control=[OngnongTraceControl new];
        UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem];
        button.frame=CGRectMake(8, 96, 76, 30);
        button.backgroundColor=[UIColor colorWithWhite:0.1 alpha:0.75];
        button.layer.cornerRadius=8;
        [button setTitle:@"COPY TRACE" forState:UIControlStateNormal];
        [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        button.titleLabel.font=[UIFont systemFontOfSize:10 weight:UIFontWeightBold];
        [button addTarget:control action:@selector(copyReport:) forControlEvents:UIControlEventTouchUpInside];
        control.button=button;
        [window addSubview:button];
    });
}
}
