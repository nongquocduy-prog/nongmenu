#pragma once
#include <string>
namespace Ongnong {
struct ResolveResult {
    void *address;
    bool ready;
    std::string reason;
};
ResolveResult ResolveGameMethod(const char *assembly, const char *namespaze, const char *klass, const char *method, int argc);
std::string CompatibilityReport();
}
