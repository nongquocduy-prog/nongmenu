#include "GameResolver.h"
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <mutex>
#include <sstream>
#include <vector>
#include <string>
#include <cstring>
namespace Ongnong {
namespace {
std::mutex reportMutex;
std::vector<std::string> events;
void record(const std::string &message) {
    std::lock_guard<std::mutex> guard(reportMutex);
    if(events.size()>=256) events.erase(events.begin());
    events.push_back(message);
}
template<typename T> T symbol(void *handle, const char *name) { return reinterpret_cast<T>(dlsym(handle,name)); }
}
ResolveResult ResolveGameMethod(const char *assembly, const char *namespaze, const char *klass, const char *method, int argc) {
    if(!assembly || !klass || !method || argc<0) return {nullptr,false,"invalid_request"};
    void *handle=dlopen("UnityFramework",RTLD_NOLOAD|RTLD_NOW);
    if(!handle) handle=dlopen(nullptr,RTLD_NOW);
    if(!handle) { record("RUNTIME_UNAVAILABLE"); return {nullptr,false,"runtime_unavailable"}; }
    using domain_get_t=void *(*)();
    using domain_assemblies_t=const void **(*)(void *,size_t *);
    using assembly_image_t=void *(*)(const void *);
    using image_name_t=const char *(*)(void *);
    using class_from_name_t=void *(*)(void *,const char *,const char *);
    using class_get_method_t=const void *(*)(void *,const char *,int);
    auto domain_get=symbol<domain_get_t>(handle,"il2cpp_domain_get");
    auto domain_assemblies=symbol<domain_assemblies_t>(handle,"il2cpp_domain_get_assemblies");
    auto assembly_image=symbol<assembly_image_t>(handle,"il2cpp_assembly_get_image");
    auto image_name=symbol<image_name_t>(handle,"il2cpp_image_get_name");
    auto class_from_name=symbol<class_from_name_t>(handle,"il2cpp_class_from_name");
    auto class_get_method=symbol<class_get_method_t>(handle,"il2cpp_class_get_method_from_name");
    if(!domain_get || !domain_assemblies || !assembly_image || !image_name || !class_from_name || !class_get_method) {
        record("IL2CPP_EXPORTS_UNAVAILABLE");
        return {nullptr,false,"il2cpp_exports_unavailable"};
    }
    void *domain=domain_get();
    if(!domain) { record("DOMAIN_UNAVAILABLE"); return {nullptr,false,"domain_unavailable"}; }
    size_t count=0;
    const void **assemblies=domain_assemblies(domain,&count);
    if(!assemblies || count>10000) { record("ASSEMBLIES_UNAVAILABLE"); return {nullptr,false,"assemblies_unavailable"}; }
    for(size_t i=0;i<count;i++) {
        void *img=assembly_image(assemblies[i]);
        const char *name=img?image_name(img):nullptr;
        if(!name || strcmp(name,assembly)!=0) continue;
        void *type=class_from_name(img,namespaze?namespaze:"",klass);
        if(!type) { record(std::string("CLASS_NOT_FOUND ")+assembly+"/"+(namespaze?namespaze:"")+"."+klass); return {nullptr,false,"class_not_found"}; }
        record(std::string("CLASS_FOUND ")+klass);
        const void *info=class_get_method(type,method,argc);
        if(!info) { record(std::string("METHOD_NOT_FOUND ")+klass+"."+method); return {nullptr,false,"method_not_found"}; }
        record(std::string("METHOD_FOUND ")+klass+"."+method);
        using method_pointer_t=void *(*)(const void *,int *);
        auto method_pointer=symbol<method_pointer_t>(handle,"il2cpp_method_get_pointer");
        if(!method_pointer) {
            record(std::string("POINTER_UNAVAILABLE ")+klass+"."+method+" reason=api_not_exported");
            return {nullptr,false,"method_pointer_api_unavailable"};
        }
        int error=0;
        void *code=method_pointer(info,&error);
        if(error!=0 || !code) {
            record(std::string("POINTER_INVALID ")+klass+"."+method+" reason=null_or_error");
            return {nullptr,false,"method_pointer_unavailable"};
        }
        Dl_info symbolInfo={};
        if(!dladdr(code,&symbolInfo) || !symbolInfo.dli_fbase) {
            record(std::string("POINTER_INVALID ")+klass+"."+method+" reason=unmapped_image");
            return {nullptr,false,"pointer_image_unknown"};
        }
        record(std::string("POINTER_IMAGE_FOUND ")+klass+"."+method+" executable=UNVERIFIED");
        return {code,true,"method_pointer_image_found_execution_unverified"};
    }
    record(std::string("ASSEMBLY_NOT_FOUND ")+assembly);
    return {nullptr,false,"assembly_not_found"};
}
std::string CompatibilityReport() {
    std::lock_guard<std::mutex> guard(reportMutex);
    std::ostringstream out;
    out<<"ONGNONG COMPATIBILITY TRACE V4\n";
    out<<"hook_installation=disabled\n";
    out<<"metadata_only=0\nexecution_validation=disabled\n";
    for(const auto &event:events) out<<event<<"\n";
    return out.str();
}
}
