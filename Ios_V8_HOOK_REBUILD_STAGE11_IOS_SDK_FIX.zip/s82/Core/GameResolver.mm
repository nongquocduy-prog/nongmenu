#include "GameResolver.h"
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <mutex>
#include <sstream>
#include <vector>
#include <string>
#include <cstring>
#include <mach/mach.h>
#include <mach/vm_map.h>
#include <mach/vm_region.h>
#include <cstdint>
namespace Ongnong {
namespace {
std::mutex reportMutex;
std::vector<std::string> events;
unsigned successfulMethods=0;
unsigned failedMethods=0;
unsigned pointerCandidates=0;
void record(const std::string &message) {
    std::lock_guard<std::mutex> guard(reportMutex);
    if(events.size()>=512) events.erase(events.begin());
    events.push_back(message);
}
bool verifiedExecutablePointer(const void *methodInfo, void **out, std::string &why) {
    *out=nullptr;
    if(!methodInfo) { why="method_info_null"; return false; }
    uintptr_t candidate=0;
    vm_size_t copied=0;
    kern_return_t kr=vm_read_overwrite(mach_task_self(), (vm_address_t)methodInfo,
        (vm_size_t)sizeof(candidate), (vm_address_t)&candidate, &copied);
    if(kr!=KERN_SUCCESS || copied!=sizeof(candidate)) { why="method_info_unreadable"; return false; }
    if(candidate==0 || (candidate & 3)!=0) { why="candidate_null_or_unaligned"; return false; }
    vm_address_t region=(vm_address_t)candidate;
    vm_size_t size=0;
    vm_region_basic_info_data_64_t info={};
    mach_msg_type_number_t count=VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t object=MACH_PORT_NULL;
    kr=vm_region(mach_task_self(),&region,&size,VM_REGION_BASIC_INFO_64,
        (vm_region_info_t)&info,&count,&object);
    if(object!=MACH_PORT_NULL) mach_port_deallocate(mach_task_self(),object);
    if(kr!=KERN_SUCCESS || candidate<region || candidate-region>=size) { why="candidate_region_unavailable"; return false; }
    if(!(info.protection & VM_PROT_EXECUTE)) { why="candidate_not_executable"; return false; }
    Dl_info symbolInfo={};
    if(!dladdr((void*)candidate,&symbolInfo) || !symbolInfo.dli_fbase) { why="candidate_image_unknown"; return false; }
    *out=(void*)candidate;
    why="candidate_executable_image_verified_signature_unverified";
    return true;
}
template<typename T> T symbol(void *handle, const char *name) { return reinterpret_cast<T>(dlsym(handle,name)); }
}
ResolveResult ResolveGameMethod(const char *assembly, const char *namespaze, const char *klass, const char *method, int argc) {
    if(!assembly || !klass || !method || argc<0) return {nullptr,false,"invalid_request"};
    void *handle=dlopen("UnityFramework",RTLD_NOLOAD|RTLD_NOW);
    if(!handle) handle=dlopen(nullptr,RTLD_NOW);
    if(!handle) { record("RUNTIME_UNAVAILABLE"); return {nullptr,false,"runtime_unavailable"}; }
    using domain_get_t=void *(*)();
    using domain_assemblies_t=const void **(*)(void *,size_t *);
    using assembly_image_t=void *(*)(const void *);
    using image_name_t=const char *(*)(void *);
    using class_from_name_t=void *(*)(void *,const char *,const char *);
    using class_get_method_t=const void *(*)(void *,const char *,int);
    auto domain_get=symbol<domain_get_t>(handle,"il2cpp_domain_get");
    auto domain_assemblies=symbol<domain_assemblies_t>(handle,"il2cpp_domain_get_assemblies");
    auto assembly_image=symbol<assembly_image_t>(handle,"il2cpp_assembly_get_image");
    auto image_name=symbol<image_name_t>(handle,"il2cpp_image_get_name");
    auto class_from_name=symbol<class_from_name_t>(handle,"il2cpp_class_from_name");
    auto class_get_method=symbol<class_get_method_t>(handle,"il2cpp_class_get_method_from_name");
    if(!domain_get || !domain_assemblies || !assembly_image || !image_name || !class_from_name || !class_get_method) {
        record("IL2CPP_EXPORTS_UNAVAILABLE");
        return {nullptr,false,"il2cpp_exports_unavailable"};
    }
    void *domain=domain_get();
    if(!domain) { record("DOMAIN_UNAVAILABLE"); return {nullptr,false,"domain_unavailable"}; }
    size_t count=0;
    const void **assemblies=domain_assemblies(domain,&count);
    if(!assemblies || count>10000) { record("ASSEMBLIES_UNAVAILABLE"); return {nullptr,false,"assemblies_unavailable"}; }
    for(size_t i=0;i<count;i++) {
        void *img=assembly_image(assemblies[i]);
        const char *name=img?image_name(img):nullptr;
        if(!name || strcmp(name,assembly)!=0) continue;
        void *type=class_from_name(img,namespaze?namespaze:"",klass);
        if(!type) { failedMethods++; record(std::string("CLASS_NOT_FOUND ")+assembly+"/"+(namespaze?namespaze:"")+"."+klass); return {nullptr,false,"class_not_found"}; }
        record(std::string("CLASS_FOUND ")+klass);
        const void *info=class_get_method(type,method,argc);
        if(!info) { failedMethods++; record(std::string("METHOD_NOT_FOUND ")+klass+"."+method); return {nullptr,false,"method_not_found"}; }
        record(std::string("METHOD_FOUND ")+klass+"."+method);
        using method_param_count_t=uint32_t (*)(const void *);
        using method_get_name_t=const char *(*)(const void *);
        using method_get_flags_t=uint32_t (*)(const void *,uint32_t *);
        auto paramCount=symbol<method_param_count_t>(handle,"il2cpp_method_get_param_count");
        auto methodName=symbol<method_get_name_t>(handle,"il2cpp_method_get_name");
        auto methodFlags=symbol<method_get_flags_t>(handle,"il2cpp_method_get_flags");
        if(!paramCount || !methodName || !methodFlags) {
            record(std::string("METHOD_DIAG_UNAVAILABLE ")+klass+"."+method+" reason=metadata_exports_missing");
            return {nullptr,false,"metadata_diagnostics_unavailable"};
        }
        const char *resolvedName=methodName(info);
        uint32_t iflags=0;
        uint32_t flags=methodFlags(info,&iflags);
        uint32_t params=paramCount(info);
        if(!resolvedName || strcmp(resolvedName,method)!=0 || params!=(uint32_t)argc) {
            failedMethods++; record(std::string("SIGNATURE_MISMATCH ")+klass+"."+method);
            return {nullptr,false,"signature_mismatch"};
        }
        successfulMethods++;
        record(std::string("METHOD_SIGNATURE_OK ")+klass+"."+method+" argc="+std::to_string(params)+" flags="+std::to_string(flags));
        void *candidate=nullptr;
        std::string why;
        if(verifiedExecutablePointer(info,&candidate,why)) {
            pointerCandidates++;
            record(std::string("POINTER_CANDIDATE_VALID ")+klass+"."+method+" reason="+why);
            return {candidate,true,why};
        }
        record(std::string("POINTER_UNAVAILABLE ")+klass+"."+method+" reason="+why);
        return {nullptr,false,"pointer_not_verified"};
    }
    failedMethods++; record(std::string("ASSEMBLY_NOT_FOUND ")+assembly);
    return {nullptr,false,"assembly_not_found"};
}
std::string CompatibilityReport() {
    std::lock_guard<std::mutex> guard(reportMutex);
    std::ostringstream out;
    out<<"ONGNONG COMPATIBILITY TRACE V8 SDK FIX\n";
    out<<"hook_installation=disabled\n";
    out<<"metadata_only=0\nexecution_validation=memory_region_only\n";
    out<<"metadata_matches="<<successfulMethods<<"\n";
    out<<"metadata_failures="<<failedMethods<<"\n";
    out<<"pointer_candidates="<<pointerCandidates<<"\n";
    out<<"hook_installation_verified=0\ncallback_verified=0\n";
    for(const auto &event:events) out<<event<<"\n";
    return out.str();
}
}
