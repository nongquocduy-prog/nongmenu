#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#include <string.h>
#include <mach-o/dyld.h>
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"

static NSRecursiveLock *twLock;
static NSMutableArray<NSString *> *twLines;
static unsigned long twSeq=0;
static UITextView *twLiveView=nil;
static UIView *twLivePanel=nil;
static bool twLiveEnabled=true;
static unsigned long twSpinId=0;
static unsigned long twCalls[5]={0,0,0,0,0};
static bool twInstalled[5]={false,false,false,false,false};
static unsigned long twScanCount=0;
static unsigned long twLastReport=0;
static unsigned long twClassSeen[5]={0,0,0,0,0};
static unsigned long twMethodSeen[5]={0,0,0,0,0};
static void twLog(NSString *s) {
    [twLock lock];
    if(!twLines)twLines=[NSMutableArray array];
    [twLines addObject:[NSString stringWithFormat:@"%05lu | %@ | %@",++twSeq,[NSDate date],s?:@""]];
    while(twLines.count>600)[twLines removeObjectAtIndex:0];
    [twLock unlock];
    dispatch_async(dispatch_get_main_queue(), ^{
        if(twLiveView && twLiveEnabled){
            NSUInteger start=twLines.count>18?twLines.count-18:0;
            NSArray *tail=[twLines subarrayWithRange:NSMakeRange(start,twLines.count-start)];
            twLiveView.text=[tail componentsJoinedByString:@"\n"];
            if(twLiveView.text.length) [twLiveView scrollRangeToVisible:NSMakeRange(twLiveView.text.length-1,1)];
        }
    });
}
static NSString *twCopy(void) {
    [twLock lock];
    NSString *s=[[twLines copy] componentsJoinedByString:@"\n"];
    [twLock unlock];
    return [@"ONGNONG THUNDER SPIN TRACE V89\n" stringByAppendingString:s?:@""];
}
static void *(*origStart)(void *,const void *);
static void *(*origStop)(void *,const void *);
static bool (*origValidate)(void *,void **,void **,const void *);
static void *(*origPointerEnd)(void *,int,const void *);
static void *(*origUIActivate)(void *,bool,const void *);
static void *twStartSpin(void *s,const void *m) {
    twSpinId++;twCalls[0]++;
    twLog([NSString stringWithFormat:@"THUNDER_START spin=%lu controller=%p",twSpinId,s]);
    return origStart(s,m);
}
static void *twStopSpin(void *s,const void *m) {
    twCalls[1]++;twLog([NSString stringWithFormat:@"THUNDER_STOP spin=%lu controller=%p",twSpinId,s]);
    return origStop(s,m);
}
static bool twValidate(void *s,void **ts,void **tw,const void *m) {
    twCalls[2]++;
    bool ok=origValidate(s,ts,tw,m);
    twLog([NSString stringWithFormat:@"THUNDER_VALIDATE spin=%lu success=%d thunderReward=%p wheelReward=%p",twSpinId,(int)ok,ts?*ts:nullptr,tw?*tw:nullptr]);
    return ok;
}
static void *twPointerEnd(void *s,int slot,const void *m) {
    twCalls[3]++;twLog([NSString stringWithFormat:@"THUNDER_POINTER_END spin=%lu slot=%d pointer=%p",twSpinId,slot,s]);
    return origPointerEnd(s,slot,m);
}
static void *twUIActivate(void *s,bool animate,const void *m) {
    twCalls[4]++;twLog([NSString stringWithFormat:@"THUNDER_UI_ACTIVATE animate=%d view=%p",(int)animate,s]);
    return origUIActivate(s,animate,m);
}
static void twInstall(void) {
    const char *names[]={"StartSpin","StopSpin","TryValidateSpinResult","EndPointerSpin","ActivateThunderSpinUI"};
    const char *spaces[]={"MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin"};
    const char *classes[]={"ThunderSpinController","ThunderSpinController","ThunderSpinController","ThunderSpinPointer","ThunderSpinMainUIView"};
    const int counts[]={0,0,2,1,1};
    void *hooks[]={(void *)twStartSpin,(void *)twStopSpin,(void *)twValidate,(void *)twPointerEnd,(void *)twUIActivate};
    void **originals[]={(void **)&origStart,(void **)&origStop,(void **)&origValidate,(void **)&origPointerEnd,(void **)&origUIActivate};
    static const uintptr_t expectedRVA[5]={0x38CA1B8,0x38CA28C,0x38CA5E4,0x38D9964,0x38CFD20};
    twScanCount++;
    for(int i=0;i<5;i++) {
        if(twInstalled[i])continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage(spaces[i],classes[i],&img);
        if(!klass||!img){
            if(twScanCount==1||twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s class_missing scans=%lu",names[i],twScanCount]);
            continue;
        }
        MethodInfo *mi=Il2CppFindMethodInfoRaw(img,spaces[i],classes[i],names[i],counts[i],false);
        if(!mi||!mi->methodPointer){
            if(twScanCount==1||twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s method_missing",names[i]]);
            continue;
        }
        Dl_info info={0};
        bool mapped=dladdr(mi->methodPointer,&info)!=0;
        uintptr_t offset=mapped?(uintptr_t)mi->methodPointer-(uintptr_t)info.dli_fbase:0;
        twLog([NSString stringWithFormat:@"VERIFY %s class=%s assembly=%s offset=0x%llx expected=0x%llx",names[i],classes[i],img,(unsigned long long)offset,(unsigned long long)expectedRVA[i]]);
        if(!mapped||!info.dli_fname||!strstr(info.dli_fname,"UnityFramework")||offset!=expectedRVA[i]){
            twLog([NSString stringWithFormat:@"SKIP %s binary_or_RVA_mismatch",names[i]]);
            continue;
        }
        int rc=DobbyHook((void *)mi->methodPointer,hooks[i],originals[i]);
        if(rc==0&&*originals[i])twInstalled[i]=true;
        twLog([NSString stringWithFormat:@"HOOK %s status=%d installed=%d address=%p",names[i],rc,twInstalled[i],mi->methodPointer]);
    }
    if(twScanCount-twLastReport>=15){
        twLastReport=twScanCount;
        twLog([NSString stringWithFormat:@"LIVE_HEARTBEAT scans=%lu hooks=%d%d%d%d%d callbacks=%lu,%lu,%lu,%lu,%lu",twScanCount,twInstalled[0],twInstalled[1],twInstalled[2],twInstalled[3],twInstalled[4],twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4]]);
    }
}
@interface ONTokenTraceV87Button:UIButton
@end
@implementation ONTokenTraceV87Button
- (void)tap:(id)sender {
    NSString *message=[NSString stringWithFormat:@"Calls: start=%lu stop=%lu validate=%lu pointer=%lu ui=%lu\n\n%@",twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4],twCopy()];
    twLiveEnabled=!twLiveEnabled;
    if(twLivePanel)twLivePanel.hidden=!twLiveEnabled;
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"THUNDER TRACE V89" message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"COPY" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=message;}]];
    [a addAction:[UIAlertAction actionWithTitle:@"CLOSE" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *vc=self.window.rootViewController;
    if(!vc)return;
    while(vc.presentedViewController)vc=vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)hold:(UILongPressGestureRecognizer *)g {
    if(g.state==UIGestureRecognizerStateBegan){[UIPasteboard generalPasteboard].string=twCopy();twLog(@"TRACE_COPIED");}
}
- (void)drag:(UIPanGestureRecognizer *)g {
    CGPoint p=[g translationInView:self.superview];self.center=CGPointMake(self.center.x+p.x,self.center.y+p.y);[g setTranslation:CGPointZero inView:self.superview];
}
@end
static void twUI(void) {
    UIWindow *w=nil;
    for(UIScene *s in UIApplication.sharedApplication.connectedScenes){
        if(![s isKindOfClass:UIWindowScene.class])continue;
        for(UIWindow *x in ((UIWindowScene *)s).windows)if(x.isKeyWindow){w=x;break;}
        if(w)break;
    }
    if(!w)w=UIApplication.sharedApplication.keyWindow;
    if(!w)return;
    if([w viewWithTag:8172026]){
        if(twLivePanel && !twLivePanel.superview)[w addSubview:twLivePanel];
        return;
    }
    ONTokenTraceV87Button *b=[ONTokenTraceV87Button buttonWithType:UIButtonTypeSystem];
    b.tag=8172026;b.frame=CGRectMake(12,170,116,36);
    b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.78];b.layer.cornerRadius=9;
    [b setTitle:@"THUNDER TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [b addTarget:b action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
    [b addGestureRecognizer:[[UILongPressGestureRecognizer alloc]initWithTarget:b action:@selector(hold:)]];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc]initWithTarget:b action:@selector(drag:)]];
    [w addSubview:b];
    if(!twLivePanel){
        CGFloat width=MIN(w.bounds.size.width-24,390);
        UIView *panel=[[UIView alloc]initWithFrame:CGRectMake(12,215,width,235)];
        panel.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.87];
        panel.layer.cornerRadius=9;
        panel.clipsToBounds=YES;
        UILabel *head=[[UILabel alloc]initWithFrame:CGRectMake(9,4,width-18,22)];
        head.text=@"LIVE THUNDER SPIN • V89";
        head.textColor=[UIColor colorWithRed:0.5 green:1 blue:0.7 alpha:1];
        head.font=[UIFont boldSystemFontOfSize:12];
        [panel addSubview:head];
        UITextView *view=[[UITextView alloc]initWithFrame:CGRectMake(5,27,width-10,203)];
        view.backgroundColor=[UIColor clearColor];
        view.textColor=UIColor.whiteColor;
        view.font=[UIFont monospacedSystemFontOfSize:9 weight:UIFontWeightRegular];
        view.editable=NO;
        view.selectable=YES;
        [panel addSubview:view];
        twLiveView=view;twLivePanel=panel;
        [w addSubview:panel];
    }
}
__attribute__((constructor))static void twStart(void) {
    twLock=[NSRecursiveLock new];twLines=[NSMutableArray array];
    twLog(@"START V89 ThunderSpin controller/pointer live trace");
    dispatch_async(dispatch_get_main_queue(),^{twUI();});
    dispatch_source_t timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC),2*NSEC_PER_SEC,250*NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer,^{twInstall();twUI();});
    dispatch_resume(timer);
    static dispatch_source_t retainedTimer;
    retainedTimer=timer;
}
