#ifndef ONGNONG_PATCHNONJB_MAHOA_SHIM_H
#define ONGNONG_PATCHNONJB_MAHOA_SHIM_H
#include "../Helper/encrypt.h"
#endif
