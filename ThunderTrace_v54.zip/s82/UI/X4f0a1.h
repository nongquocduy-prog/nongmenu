#pragma once
#import <UIKit/UIKit.h>

@interface X4f0a1 : UIView
- (void)refreshAll;
- (void)refreshTheme;
@end
