#import "OngnongUIVault.h"
#import "../Core/OngnongOxorany.h"
#import "../Core/zx8f1a_gate.h"

static NSString *ov_lang(void) {
    NSString *code = [[NSUserDefaults standardUserDefaults] stringForKey:OX_NS("ongnong_menu_language")];
    if ([code isEqualToString:OX_NS("vi")] || [code isEqualToString:OX_NS("zh")] || [code isEqualToString:OX_NS("th")] || [code isEqualToString:OX_NS("it")] || [code isEqualToString:OX_NS("en")]) return code;
    return OX_NS("vi");
}

NSString *OngnongUIVaultLangCodeEN(void) { return OX_NS("en"); }
NSString *OngnongUIVaultResolvedLanguageCode(void) { return ov_lang(); }
NSString *OngnongUIVaultLanguageNotification(void) { return OX_NS("ongnong_language_changed"); }

static NSString *ov_vi(NSString *key, NSString *fallback) {
    return Ongnong::Zx8fMenuLabelVI(key, fallback);
}

static NSString *ov_pick_key(NSString *key, NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = ov_lang();
    if ([code isEqualToString:OX_NS("vi")]) return ov_vi(key, vi);
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return ov_vi(key, vi);
}

static NSString *ov_pick(NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = ov_lang();
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return vi ?: OX_NS("");
}

NSString *OngnongUIVaultText(OngnongUIVaultId ident) {
    switch ((NSUInteger)ident ^ 0x5Bu) {
        case (OngnongUIVaultLangButton ^ 0x5Bu): return ov_pick(OX_NS("🌐  VN  ▾"), OX_NS("🌐  中文  ▾"), OX_NS("🌐  ไทย  ▾"), OX_NS("🌐  IT  ▾"), OX_NS("🌐  EN  ▾"));
        case (OngnongUIVaultHistory ^ 0x5Bu): return ov_pick_key(OX_NS("history"), OX_NS("LỊCH SỬ"), OX_NS("历史"), OX_NS("ประวัติ"), OX_NS("STORIA"), OX_NS("HISTORY"));
        case (OngnongUIVaultAutoBuild ^ 0x5Bu): return ov_pick_key(OX_NS("auto_build"), OX_NS("TỰ ĐỘNG XÂY"), OX_NS("自动建造"), OX_NS("สร้างออโต้"), OX_NS("AUTO BUILD"), OX_NS("AUTO BUILD"));
        case (OngnongUIVaultPigHammer ^ 0x5Bu): return ov_pick_key(OX_NS("pig_hammer"), OX_NS("AUTO HEO / BÚA"), OX_NS("自动猪 / 锤"), OX_NS("หมู / ค้อน"), OX_NS("MAIALE / MARTELLO"), OX_NS("PIG / HAMMER"));
        case (OngnongUIVaultTools ^ 0x5Bu): return ov_pick_key(OX_NS("tools"), OX_NS("CÔNG CỤ"), OX_NS("工具"), OX_NS("เครื่องมือ"), OX_NS("STRUMENTI"), OX_NS("TOOLS"));
        case (OngnongUIVaultAutoClick ^ 0x5Bu): return ov_pick_key(OX_NS("auto_click"), OX_NS("AUTO CLICK"), OX_NS("自动点击"), OX_NS("คลิกออโต้"), OX_NS("AUTO CLICK"), OX_NS("AUTO CLICK"));
        case (OngnongUIVaultUpdate ^ 0x5Bu): return ov_pick_key(OX_NS("update"), OX_NS("CẬP NHẬT"), OX_NS("更新"), OX_NS("อัปเดต"), OX_NS("AGGIORNA"), OX_NS("UPDATE"));
        case (OngnongUIVaultAutoTarget ^ 0x5Bu): return ov_pick_key(OX_NS("auto_stop"), OX_NS("TỰ ĐỘNG DỪNG"), OX_NS("自动停止"), OX_NS("หยุดออโต้"), OX_NS("STOP AUTO"), OX_NS("AUTO STOP"));
        case (OngnongUIVaultSet ^ 0x5Bu): return ov_pick(OX_NS("CÀI"), OX_NS("设置"), OX_NS("ตั้ง"), OX_NS("SET"), OX_NS("SET"));
        case (OngnongUIVaultSave ^ 0x5Bu): return ov_pick(OX_NS("LƯU"), OX_NS("保存"), OX_NS("บันทึก"), OX_NS("SALVA"), OX_NS("SAVE"));
        case (OngnongUIVaultCancel ^ 0x5Bu): return ov_pick(OX_NS("HỦY"), OX_NS("取消"), OX_NS("ยกเลิก"), OX_NS("ANNULLA"), OX_NS("CANCEL"));
        case (OngnongUIVaultTargetPrompt ^ 0x5Bu): return ov_pick(OX_NS("Nhập số vòng:"), OX_NS("输入圈数："), OX_NS("ใส่จำนวนรอบ:"), OX_NS("Inserisci giri:"), OX_NS("Enter spins:"));
        case (OngnongUIVaultSkip ^ 0x5Bu): return ov_pick(OX_NS("SKIP"), OX_NS("跳过"), OX_NS("ข้าม"), OX_NS("SALTA"), OX_NS("SKIP"));
        case (OngnongUIVaultSpeedTitle ^ 0x5Bu): return ov_pick(OX_NS("ĐỔI TỐC ĐỘ"), OX_NS("修改速度"), OX_NS("เปลี่ยนความเร็ว"), OX_NS("CAMBIA VELOCITÀ"), OX_NS("CHANGE SPEED"));
        case (OngnongUIVaultSpeedMessage ^ 0x5Bu): return ov_pick(OX_NS("Nhập số từ 1 đến 201"), OX_NS("输入 1 到 201"), OX_NS("ใส่ตัวเลข 1 ถึง 201"), OX_NS("Inserisci un numero da 1 a 201"), OX_NS("Enter a number from 1 to 201"));
        case (OngnongUIVaultLanguageTitle ^ 0x5Bu): return ov_pick(OX_NS("CHỌN NGÔN NGỮ"), OX_NS("选择语言"), OX_NS("เลือกภาษา"), OX_NS("SCEGLI LINGUA"), OX_NS("SELECT LANGUAGE"));
        case (OngnongUIVaultEnglishAction ^ 0x5Bu): return OX_NS("🇬🇧 English");
        case (OngnongUIVaultMenuColor ^ 0x5Bu): return ov_pick_key(OX_NS("menu_color"), OX_NS("MÀU MENU"), OX_NS("颜色菜单"), OX_NS("เมนูสี"), OX_NS("MENU COLORE"), OX_NS("MENU COLOR"));
        case (OngnongUIVaultMagicCards ^ 0x5Bu): return ov_pick(OX_NS("MỞ THẺ"), OX_NS("开卡"), OX_NS("เปิดการ์ด"), OX_NS("APRI CARTE"), OX_NS("OPEN CARDS"));
        case (OngnongUIVaultMagicCardsQuick ^ 0x5Bu): return ov_pick_key(OX_NS("magic_cards"), OX_NS("MỞ THẺ NHANH"), OX_NS("快速开卡"), OX_NS("เปิดการ์ดเร็ว"), OX_NS("APRI CARTE RAPIDO"), OX_NS("QUICK CARDS"));
        case (OngnongUIVaultBuyVip ^ 0x5Bu): return OX_NS("FREE");
        case (OngnongUIVaultAutoExpedition ^ 0x5Bu): return ov_pick_key(OX_NS("auto_expedition"), OX_NS("AUTO HOANG ĐỊA"), OX_NS("自动探险"), OX_NS("ผจญภัยออโต้"), OX_NS("SPEDIZIONE AUTO"), OX_NS("AUTO EXPEDITION"));
        case (OngnongUIVaultAutoExpeditionOn ^ 0x5Bu): return [ov_lang() isEqualToString:OX_NS("vi")] ? [NSString stringWithFormat:OX_NS("%@: ON"), ov_vi(OX_NS("auto_expedition"), OX_NS("HOANG ĐỊA"))] : ov_pick(OX_NS("HOANG ĐỊA: ON"), OX_NS("探险: 开"), OX_NS("ผจญภัย: เปิด"), OX_NS("SPEDIZIONE: ON"), OX_NS("EXPEDITION: ON"));
        case (OngnongUIVaultAutoExpeditionOff ^ 0x5Bu): return [ov_lang() isEqualToString:OX_NS("vi")] ? [NSString stringWithFormat:OX_NS("%@: OFF"), ov_vi(OX_NS("auto_expedition"), OX_NS("HOANG ĐỊA"))] : ov_pick(OX_NS("HOANG ĐỊA: OFF"), OX_NS("探险: 关"), OX_NS("ผจญภัย: ปิด"), OX_NS("SPEDIZIONE: OFF"), OX_NS("EXPEDITION: OFF"));
        case (OngnongUIVaultAutoMerge ^ 0x5Bu): return ov_pick_key(OX_NS("auto_merge"), OX_NS("AUTO HỢP NHẤT"), OX_NS("自动合并"), OX_NS("รวมอัตโนมัติ"), OX_NS("UNIONE AUTO"), OX_NS("AUTO MERGE"));
        case (OngnongUIVaultAutoMergeOn ^ 0x5Bu): return [ov_lang() isEqualToString:OX_NS("vi")] ? [NSString stringWithFormat:OX_NS("%@: ON"), ov_vi(OX_NS("auto_merge"), OX_NS("HỢP NHẤT"))] : ov_pick(OX_NS("HỢP NHẤT: ON"), OX_NS("合并: 开"), OX_NS("รวม: เปิด"), OX_NS("UNIONE: ON"), OX_NS("MERGE: ON"));
        case (OngnongUIVaultAutoMergeOff ^ 0x5Bu): return [ov_lang() isEqualToString:OX_NS("vi")] ? [NSString stringWithFormat:OX_NS("%@: OFF"), ov_vi(OX_NS("auto_merge"), OX_NS("HỢP NHẤT"))] : ov_pick(OX_NS("HỢP NHẤT: OFF"), OX_NS("合并: 关"), OX_NS("รวม: ปิด"), OX_NS("UNIONE: OFF"), OX_NS("MERGE: OFF"));

        case (OngnongUIVaultQxMenu ^ 0x5Bu): return ov_pick_key(OX_NS("bet_cycle"), OX_NS("BẢNG VÒNG QUAY"), OX_NS("投注轮转"), OX_NS("ตารางรอบเดิมพัน"), OX_NS("CICLO PUNTATE"), OX_NS("BET CYCLE"));
        case (OngnongUIVaultQxTitle ^ 0x5Bu): return ov_pick(OX_NS("BẢNG VÒNG QUAY THEO BET"), OX_NS("按投注轮转表"), OX_NS("ตารางรอบตามเดิมพัน"), OX_NS("TABELLA CICLO PUNTATE"), OX_NS("BET SPIN CYCLE"));
        case (OngnongUIVaultQxSelectTarget ^ 0x5Bu): return ov_pick(OX_NS("CHỌN MỤC TIÊU"), OX_NS("选择目标"), OX_NS("เลือกเป้าหมาย"), OX_NS("SCEGLI OBIETTIVO"), OX_NS("SELECT TARGET"));
        case (OngnongUIVaultQxTargetSymbol ^ 0x5Bu): return ov_pick(OX_NS("Symbol"), OX_NS("符号"), OX_NS("สัญลักษณ์"), OX_NS("Simbolo"), OX_NS("Symbol"));
        case (OngnongUIVaultQxTargetPig ^ 0x5Bu): return ov_pick(OX_NS("Heo"), OX_NS("猪"), OX_NS("หมู"), OX_NS("Maiale"), OX_NS("Pig"));
        case (OngnongUIVaultQxTargetHammer ^ 0x5Bu): return ov_pick(OX_NS("Búa"), OX_NS("锤子"), OX_NS("ค้อน"), OX_NS("Martello"), OX_NS("Hammer"));
        case (OngnongUIVaultQxTargetSpin ^ 0x5Bu): return ov_pick(OX_NS("Spin"), OX_NS("旋转"), OX_NS("สปิน"), OX_NS("Spin"), OX_NS("Spin"));
        case (OngnongUIVaultQxTargetPotion ^ 0x5Bu): return ov_pick(OX_NS("Thuốc"), OX_NS("药水"), OX_NS("ยา"), OX_NS("Pozione"), OX_NS("Potion"));
        case (OngnongUIVaultQxTargetToken ^ 0x5Bu): return ov_pick(OX_NS("Token"), OX_NS("代币"), OX_NS("โทเคน"), OX_NS("Token"), OX_NS("Token"));
        case (OngnongUIVaultQxTargetLightning ^ 0x5Bu): return ov_pick(OX_NS("Tia sét"), OX_NS("闪电"), OX_NS("สายฟ้า"), OX_NS("Fulmine"), OX_NS("Lightning"));
        case (OngnongUIVaultQxTargetGeneric ^ 0x5Bu): return ov_pick(OX_NS("Mục tiêu"), OX_NS("目标"), OX_NS("เป้าหมาย"), OX_NS("Obiettivo"), OX_NS("Target"));
        case (OngnongUIVaultQxAutoStop ^ 0x5Bu): return ov_pick(OX_NS("TỰ DỪNG"), OX_NS("自动停止"), OX_NS("หยุดอัตโนมัติ"), OX_NS("STOP AUTO"), OX_NS("AUTO STOP"));
        case (OngnongUIVaultQxRow ^ 0x5Bu): return ov_pick(OX_NS("DÒNG"), OX_NS("行"), OX_NS("แถว"), OX_NS("RIGA"), OX_NS("ROW"));
        case (OngnongUIVaultQxSpins ^ 0x5Bu): return ov_pick(OX_NS("SỐ VÒNG"), OX_NS("轮数"), OX_NS("จำนวนรอบ"), OX_NS("GIRI"), OX_NS("SPINS"));
        case (OngnongUIVaultQxProgress ^ 0x5Bu): return ov_pick(OX_NS("TIẾN ĐỘ"), OX_NS("进度"), OX_NS("ความคืบหน้า"), OX_NS("PROGRESSO"), OX_NS("PROGRESS"));
        case (OngnongUIVaultQxAddRow ^ 0x5Bu): return ov_pick(OX_NS("+ DÒNG"), OX_NS("+ 添加"), OX_NS("+ เพิ่มแถว"), OX_NS("+ RIGA"), OX_NS("+ ROW"));
        case (OngnongUIVaultQxRemoveRow ^ 0x5Bu): return ov_pick(OX_NS("− DÒNG"), OX_NS("− 删除"), OX_NS("− ลบแถว"), OX_NS("− RIGA"), OX_NS("− ROW"));
        case (OngnongUIVaultQxReset ^ 0x5Bu): return ov_pick(OX_NS("RESET"), OX_NS("重置"), OX_NS("รีเซ็ต"), OX_NS("RESET"), OX_NS("RESET"));
        case (OngnongUIVaultQxPanelTitle ^ 0x5Bu): return ov_pick(OX_NS("BẢNG VÒNG QUAY"), OX_NS("轮转表"), OX_NS("ตารางรอบ"), OX_NS("TABELLA CICLO"), OX_NS("SPIN CYCLE"));
        case (OngnongUIVaultQxInvalidConfig ^ 0x5Bu): return ov_pick(OX_NS("Cấu hình không hợp lệ"), OX_NS("配置无效"), OX_NS("การตั้งค่าไม่ถูกต้อง"), OX_NS("Configurazione non valida"), OX_NS("Invalid configuration"));
        case (OngnongUIVaultQxOK ^ 0x5Bu): return OX_NS("OK");
        case (OngnongUIVaultQxMaxRows ^ 0x5Bu): return ov_pick(OX_NS("Tối đa 20 dòng bet."), OX_NS("最多 20 行投注。"), OX_NS("สูงสุด 20 แถวเดิมพัน"), OX_NS("Massimo 20 righe di puntata."), OX_NS("Maximum 20 bet rows."));
        case (OngnongUIVaultQxMinRow ^ 0x5Bu): return ov_pick(OX_NS("Phải giữ ít nhất một dòng."), OX_NS("至少保留一行。"), OX_NS("ต้องเหลืออย่างน้อยหนึ่งแถว"), OX_NS("Mantieni almeno una riga."), OX_NS("Keep at least one row."));
        case (OngnongUIVaultQxSummaryFormat ^ 0x5Bu): return ov_pick(OX_NS("%@ · x%ld · DÒNG %ld/%ld · TỔNG %ld/%ld"), OX_NS("%@ · x%ld · 行 %ld/%ld · 总计 %ld/%ld"), OX_NS("%@ · x%ld · แถว %ld/%ld · รวม %ld/%ld"), OX_NS("%@ · x%ld · RIGA %ld/%ld · TOTALE %ld/%ld"), OX_NS("%@ · x%ld · ROW %ld/%ld · TOTAL %ld/%ld"));
        case (OngnongUIVaultQxCompactFormat ^ 0x5Bu): return OX_NS("%@ | x%ld | %ld/%ld | %ld/%ld");
        case (OngnongUIVaultQxReady ^ 0x5Bu): return ov_pick(OX_NS("SẴN SÀNG"), OX_NS("就绪"), OX_NS("พร้อม"), OX_NS("PRONTO"), OX_NS("READY"));
        case (OngnongUIVaultQxSpinningFormat ^ 0x5Bu): return ov_pick(OX_NS("ĐANG QUAY x%ld"), OX_NS("正在旋转 x%ld"), OX_NS("กำลังหมุน x%ld"), OX_NS("IN ROTAZIONE x%ld"), OX_NS("SPINNING x%ld"));
        case (OngnongUIVaultQxAutoStartFailed ^ 0x5Bu): return ov_pick(OX_NS("KHÔNG THỂ KHỞI ĐỘNG AUTO SPIN"), OX_NS("无法启动自动旋转"), OX_NS("เริ่มหมุนอัตโนมัติไม่ได้"), OX_NS("IMPOSSIBILE AVVIARE AUTO SPIN"), OX_NS("CANNOT START AUTO SPIN"));
        case (OngnongUIVaultQxWaitSpinStopFailed ^ 0x5Bu): return ov_pick(OX_NS("KHÔNG THỂ CHỜ VÒNG QUAY DỪNG"), OX_NS("无法等待旋转停止"), OX_NS("รอให้การหมุนหยุดไม่ได้"), OX_NS("IMPOSSIBILE ATTENDERE LO STOP"), OX_NS("CANNOT WAIT FOR SPIN TO STOP"));
        case (OngnongUIVaultQxBetChangedFormat ^ 0x5Bu): return ov_pick(OX_NS("ĐÃ ĐỔI x%ld · ĐANG BẬT AUTO"), OX_NS("已切换 x%ld · 正在启动自动"), OX_NS("เปลี่ยนเป็น x%ld · กำลังเปิดออโต้"), OX_NS("CAMBIATO x%ld · AVVIO AUTO"), OX_NS("CHANGED TO x%ld · STARTING AUTO"));
        case (OngnongUIVaultQxBetUnsupportedFormat ^ 0x5Bu): return ov_pick(OX_NS("BET x%ld KHÔNG HỖ TRỢ"), OX_NS("不支持投注 x%ld"), OX_NS("ไม่รองรับเดิมพัน x%ld"), OX_NS("PUNTATA x%ld NON SUPPORTATA"), OX_NS("BET x%ld NOT SUPPORTED"));
        case (OngnongUIVaultQxChangingBetFormat ^ 0x5Bu): return ov_pick(OX_NS("ĐỔI BET x%ld"), OX_NS("切换投注 x%ld"), OX_NS("เปลี่ยนเดิมพัน x%ld"), OX_NS("CAMBIO PUNTATA x%ld"), OX_NS("CHANGING BET x%ld"));
        case (OngnongUIVaultQxSaved ^ 0x5Bu): return ov_pick(OX_NS("ĐÃ LƯU"), OX_NS("已保存"), OX_NS("บันทึกแล้ว"), OX_NS("SALVATO"), OX_NS("SAVED"));
        case (OngnongUIVaultQxOff ^ 0x5Bu): return ov_pick(OX_NS("ĐÃ TẮT"), OX_NS("已关闭"), OX_NS("ปิดแล้ว"), OX_NS("DISATTIVATO"), OX_NS("OFF"));
        case (OngnongUIVaultQxStarting ^ 0x5Bu): return ov_pick(OX_NS("ĐANG KHỞI ĐỘNG"), OX_NS("正在启动"), OX_NS("กำลังเริ่ม"), OX_NS("AVVIO"), OX_NS("STARTING"));
        case (OngnongUIVaultQxResetDone ^ 0x5Bu): return ov_pick(OX_NS("ĐÃ RESET"), OX_NS("已重置"), OX_NS("รีเซ็ตแล้ว"), OX_NS("RESET ESEGUITO"), OX_NS("RESET"));
        case (OngnongUIVaultQxTargetReached ^ 0x5Bu): return ov_pick(OX_NS("ĐÃ GẶP MỤC TIÊU · QUAY LẠI DÒNG 1"), OX_NS("已达到目标 · 返回第 1 行"), OX_NS("เจอเป้าหมายแล้ว · กลับแถว 1"), OX_NS("OBIETTIVO TROVATO · RITORNO ALLA RIGA 1"), OX_NS("TARGET FOUND · RETURNING TO ROW 1"));
        case (OngnongUIVaultQxCheckingTarget ^ 0x5Bu): return ov_pick(OX_NS("ĐANG KIỂM TRA MỤC TIÊU..."), OX_NS("正在检查目标..."), OX_NS("กำลังตรวจสอบเป้าหมาย..."), OX_NS("CONTROLLO OBIETTIVO..."), OX_NS("CHECKING TARGET..."));
        case (OngnongUIVaultQxStoppedFormat ^ 0x5Bu): return ov_pick(OX_NS("ĐÃ DỪNG · %ld/%ld VÒNG"), OX_NS("已停止 · %ld/%ld 轮"), OX_NS("หยุดแล้ว · %ld/%ld รอบ"), OX_NS("FERMATO · %ld/%ld GIRI"), OX_NS("STOPPED · %ld/%ld SPINS"));
        case (OngnongUIVaultQxErrTurnOffBeforeEdit ^ 0x5Bu): return ov_pick(OX_NS("Hãy tắt bảng vòng quay trước khi sửa cấu hình."), OX_NS("修改配置前请关闭轮转表。"), OX_NS("ปิดตารางรอบก่อนแก้ไขการตั้งค่า"), OX_NS("Disattiva la tabella prima di modificare."), OX_NS("Turn off the cycle before editing."));
        case (OngnongUIVaultQxErrBetSpinsPositive ^ 0x5Bu): return ov_pick(OX_NS("Mức bet và số vòng phải lớn hơn 0."), OX_NS("投注和轮数必须大于 0。"), OX_NS("เดิมพันและจำนวนรอบต้องมากกว่า 0"), OX_NS("Puntata e giri devono essere maggiori di 0."), OX_NS("Bet and spins must be greater than 0."));
        case (OngnongUIVaultQxErrNeedRow ^ 0x5Bu): return ov_pick(OX_NS("Phải có ít nhất một dòng bet."), OX_NS("至少需要一行投注。"), OX_NS("ต้องมีอย่างน้อยหนึ่งแถวเดิมพัน"), OX_NS("Serve almeno una riga di puntata."), OX_NS("At least one bet row is required."));
        case (OngnongUIVaultQxErrTargetNotAllowed ^ 0x5Bu): return ov_pick(OX_NS("Mục tiêu này hiện không được phép sử dụng."), OX_NS("当前不允许使用此目标。"), OX_NS("เป้าหมายนี้ยังใช้งานไม่ได้"), OX_NS("Questo obiettivo non è consentito."), OX_NS("This target is not allowed."));
        case (OngnongUIVaultQxErrAutoStopMinimumFormat ^ 0x5Bu): return ov_pick(OX_NS("Tự dừng phải từ %ld vòng trở lên."), OX_NS("自动停止必须至少为 %ld 轮。"), OX_NS("หยุดอัตโนมัติต้องอย่างน้อย %ld รอบ"), OX_NS("Lo stop automatico deve essere almeno %ld giri."), OX_NS("Auto stop must be at least %ld spins."));
        case (OngnongUIVaultQxErrSaveBeforeStart ^ 0x5Bu): return ov_pick(OX_NS("Cấu hình chưa hợp lệ. Hãy lưu lại bảng trước."), OX_NS("配置无效，请先保存。"), OX_NS("การตั้งค่าไม่ถูกต้อง กรุณาบันทึกก่อน"), OX_NS("Configurazione non valida. Salva prima."), OX_NS("Invalid configuration. Save the table first."));
        case (OngnongUIVaultVipActivationTitle ^ 0x5Bu): return ov_pick(OX_NS("MÃ KÍCH HOẠT / VIP"), OX_NS("激活码 / VIP"), OX_NS("รหัสเปิดใช้งาน / VIP"), OX_NS("CODICE ATTIVAZIONE / VIP"), OX_NS("ACTIVATION CODE / VIP"));
        case (OngnongUIVaultVipActivationMessageFormat ^ 0x5Bu): return ov_pick(OX_NS("Mã kích hoạt của thiết bị này:\n\n%@"), OX_NS("此设备的激活码：\n\n%@"), OX_NS("รหัสเปิดใช้งานของอุปกรณ์นี้:\n\n%@"), OX_NS("Codice di attivazione di questo dispositivo:\n\n%@"), OX_NS("Activation code for this device:\n\n%@"));
        case (OngnongUIVaultVipCopyActivation ^ 0x5Bu): return ov_pick(OX_NS("COPY MÃ KÍCH HOẠT"), OX_NS("复制激活码"), OX_NS("คัดลอกรหัสเปิดใช้งาน"), OX_NS("COPIA CODICE ATTIVAZIONE"), OX_NS("COPY ACTIVATION CODE"));
        case (OngnongUIVaultVipRestoreActivation ^ 0x5Bu): return ov_pick(OX_NS("BẢO LƯU VIP"), OX_NS("保留 VIP"), OX_NS("สำรอง VIP"), OX_NS("CONSERVA VIP"), OX_NS("PRESERVE VIP"));
        case (OngnongUIVaultVipContactBuy ^ 0x5Bu): return ov_pick(OX_NS("LIÊN HỆ MUA VIP"), OX_NS("联系购买 VIP"), OX_NS("ติดต่อซื้อ VIP"), OX_NS("CONTATTA PER VIP"), OX_NS("CONTACT TO BUY VIP"));
        case (OngnongUIVaultActiveRestoreVip ^ 0x5Bu): return OX_NS("VIP");
        case (OngnongUIVaultFreeBuyVipAction ^ 0x5Bu): return ov_pick_key(OX_NS("buy_vip"), OX_NS("MUA VIP"), OX_NS("购买 VIP"), OX_NS("ซื้อ VIP"), OX_NS("ACQUISTA VIP"), OX_NS("BUY VIP"));
        case (OngnongUIVaultFreeRestoreVipAction ^ 0x5Bu): return ov_pick(OX_NS("KHÔI PHỤC VIP"), OX_NS("恢复 VIP"), OX_NS("กู้คืน VIP"), OX_NS("RIPRISTINA VIP"), OX_NS("RESTORE VIP"));
        case (OngnongUIVaultFriendInvite ^ 0x5Bu): return ov_pick_key(OX_NS("friend_invite"), OX_NS("MỜI BẠN BÈ"), OX_NS("邀请好友"), OX_NS("เชิญเพื่อน"), OX_NS("INVITA AMICI"), OX_NS("INVITE FRIENDS"));
        case (OngnongUIVaultPotionOn ^ 0x5Bu): return [ov_lang() isEqualToString:OX_NS("vi")] ? [NSString stringWithFormat:OX_NS("%@: ON"), ov_vi(OX_NS("potion"), OX_NS("NHẬN THUỐC"))] : ov_pick(OX_NS("NHẬN THUỐC: ON"), OX_NS("领取药水: 开"), OX_NS("รับยา: เปิด"), OX_NS("RITIRA POZIONE: ON"), OX_NS("COLLECT POTION: ON"));
        case (OngnongUIVaultPotionOff ^ 0x5Bu): return [ov_lang() isEqualToString:OX_NS("vi")] ? [NSString stringWithFormat:OX_NS("%@: OFF"), ov_vi(OX_NS("potion"), OX_NS("NHẬN THUỐC"))] : ov_pick(OX_NS("NHẬN THUỐC: OFF"), OX_NS("领取药水: 关"), OX_NS("รับยา: ปิด"), OX_NS("RITIRA POZIONE: OFF"), OX_NS("COLLECT POTION: OFF"));
        case (OngnongUIVaultFriendClear ^ 0x5Bu): return ov_pick(OX_NS("XÓA"), OX_NS("清除"), OX_NS("ล้าง"), OX_NS("CANCELLA"), OX_NS("CLEAR"));
        default: return OX_NS("");
    }
}
