#pragma once
#import <UIKit/UIKit.h>

UIImage *OngnongCounterIconImage(NSInteger index);

namespace Ongnong {
void Z75012fe6dc();
}
