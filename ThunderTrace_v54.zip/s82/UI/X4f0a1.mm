#import "X4f0a1.h"
#import "OngnongMenuView.h"
#import "../Core/Qr73c.h"
#import "../Core/OngnongState.h"
#import "../Core/zx8f1a_gate.h"
#import "../Core/OngnongOxorany.h"
#import "OngnongUIVault.h"
#import <QuartzCore/QuartzCore.h>

using namespace Ongnong;

static UIColor *BC_RGB(CGFloat r, CGFloat g, CGFloat b) {
    return [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0];
}
static NSString *BCKey(NSString *s) { return [OX_NS("ongnong_bet_cycle_ui_") stringByAppendingString:s ?: @""]; }
static NSString *BCProfileText(NSUInteger idx) {
    NSString *lang = OngnongUIVaultResolvedLanguageCode();
    NSArray<NSArray<NSString *> *> *t = @[
        @[OX_NS("LƯU LẠI"), OX_NS("CẤU HÌNH"), OX_NS("Tên cấu hình"), OX_NS("Lưu cấu hình"), OX_NS("Đã lưu cấu hình"), OX_NS("Chưa có cấu hình đã lưu"), OX_NS("Chạm tên để dùng"), OX_NS("Đổi tên"), OX_NS("Xóa"), OX_NS("Xóa cấu hình này?"), OX_NS("Hủy"), OX_NS("Đã tải cấu hình"), OX_NS("Không đọc được cấu hình"), OX_NS("Tên không được để trống"), OX_NS("Tên này đã tồn tại"), OX_NS("Thay thế"), OX_NS("Đã xóa"), OX_NS("Đã đổi tên")],
        @[OX_NS("保存方案"), OX_NS("配置"), OX_NS("配置名称"), OX_NS("保存配置"), OX_NS("配置已保存"), OX_NS("暂无已保存配置"), OX_NS("点击名称使用"), OX_NS("重命名"), OX_NS("删除"), OX_NS("删除此配置？"), OX_NS("取消"), OX_NS("配置已加载"), OX_NS("无法读取配置"), OX_NS("名称不能为空"), OX_NS("名称已存在"), OX_NS("替换"), OX_NS("已删除"), OX_NS("已重命名")],
        @[OX_NS("บันทึกไว้"), OX_NS("การตั้งค่า"), OX_NS("ชื่อการตั้งค่า"), OX_NS("บันทึกการตั้งค่า"), OX_NS("บันทึกแล้ว"), OX_NS("ยังไม่มีการตั้งค่าที่บันทึก"), OX_NS("แตะชื่อเพื่อใช้"), OX_NS("เปลี่ยนชื่อ"), OX_NS("ลบ"), OX_NS("ลบการตั้งค่านี้?"), OX_NS("ยกเลิก"), OX_NS("โหลดการตั้งค่าแล้ว"), OX_NS("อ่านการตั้งค่าไม่ได้"), OX_NS("ชื่อต้องไม่ว่าง"), OX_NS("ชื่อนี้มีอยู่แล้ว"), OX_NS("แทนที่"), OX_NS("ลบแล้ว"), OX_NS("เปลี่ยนชื่อแล้ว")],
        @[OX_NS("SALVA PROFILO"), OX_NS("CONFIGURAZIONI"), OX_NS("Nome configurazione"), OX_NS("Salva configurazione"), OX_NS("Configurazione salvata"), OX_NS("Nessuna configurazione salvata"), OX_NS("Tocca il nome per usare"), OX_NS("Rinomina"), OX_NS("Elimina"), OX_NS("Eliminare questa configurazione?"), OX_NS("Annulla"), OX_NS("Configurazione caricata"), OX_NS("Impossibile leggere la configurazione"), OX_NS("Il nome non può essere vuoto"), OX_NS("Questo nome esiste già"), OX_NS("Sostituisci"), OX_NS("Eliminata"), OX_NS("Rinominata")],
        @[OX_NS("SAVE PRESET"), OX_NS("CONFIGS"), OX_NS("Configuration name"), OX_NS("Save configuration"), OX_NS("Configuration saved"), OX_NS("No saved configurations"), OX_NS("Tap name to use"), OX_NS("Rename"), OX_NS("Delete"), OX_NS("Delete this configuration?"), OX_NS("Cancel"), OX_NS("Configuration loaded"), OX_NS("Cannot read configuration"), OX_NS("Name cannot be empty"), OX_NS("This name already exists"), OX_NS("Replace"), OX_NS("Deleted"), OX_NS("Renamed")]
    ];
    NSUInteger li = [lang isEqualToString:OX_NS("zh")] ? 1 : [lang isEqualToString:OX_NS("th")] ? 2 : [lang isEqualToString:OX_NS("it")] ? 3 : [lang isEqualToString:OX_NS("en")] ? 4 : 0;
    return idx < t[li].count ? t[li][idx] : OX_NS("");
}
static void BCLightHaptic(void) {
    void (^fire)(void) = ^{
        if (@available(iOS 10.0, *)) {
            static UIImpactFeedbackGenerator *g = nil;
            static dispatch_once_t onceToken;
            dispatch_once(&onceToken, ^{
                g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
            });
            [g prepare];
            [g impactOccurred];
        }
    };
    if ([NSThread isMainThread]) fire();
    else dispatch_async(dispatch_get_main_queue(), fire);
}
static UIColor *BCPanel(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat r = [ud objectForKey:OX_NS("om_theme_r")] ? [ud floatForKey:OX_NS("om_theme_r")] : 34.0/255.0;
    CGFloat g = [ud objectForKey:OX_NS("om_theme_g")] ? [ud floatForKey:OX_NS("om_theme_g")] : 54.0/255.0;
    CGFloat b = [ud objectForKey:OX_NS("om_theme_b")] ? [ud floatForKey:OX_NS("om_theme_b")] : 88.0/255.0;
    CGFloat a = [ud objectForKey:OX_NS("om_theme_a")] ? [ud floatForKey:OX_NS("om_theme_a")] : 0.90;
    return [UIColor colorWithRed:MAX(0,MIN(1,r)) green:MAX(0,MIN(1,g)) blue:MAX(0,MIN(1,b)) alpha:MAX(.55,MIN(.96,a))];
}
static UIColor *BCPanelDark(void) {
    UIColor *c = BCPanel(); CGFloat r=0,g=0,b=0,a=0; [c getRed:&r green:&g blue:&b alpha:&a];
    return [UIColor colorWithRed:r*.72 green:g*.72 blue:b*.72 alpha:MIN(.96,a+.06)];
}
static UIColor *BCBorder(void) { return BC_RGB(82,211,255); }
static UIColor *BCOff(void) {
    UIColor *c=BCPanel(); CGFloat r=0,g=0,b=0,a=0; [c getRed:&r green:&g blue:&b alpha:&a];
    return [UIColor colorWithRed:r*.82 green:g*.82 blue:b*.82 alpha:MIN(.94,a+.02)];
}
static UILabel *BCLabel(NSString *text, CGFloat size, UIFontWeight weight, NSTextAlignment align) {
    UILabel *l=[[UILabel alloc] initWithFrame:CGRectZero]; l.text=text; l.textColor=UIColor.whiteColor;
    l.font=[UIFont systemFontOfSize:size weight:weight]; l.textAlignment=align; l.adjustsFontSizeToFitWidth=YES; l.minimumScaleFactor=.55; return l;
}
static void BCStyle(UIView *v, CGFloat radius) {
    v.layer.cornerRadius=radius; v.layer.borderWidth=1.0; v.layer.borderColor=BCBorder().CGColor; v.layer.shadowOpacity=0;
}
static UIViewController *BCTopVC(void) {
    UIWindow *w=UIApplication.sharedApplication.keyWindow;
    UIViewController *vc=w.rootViewController;
    while (vc.presentedViewController) vc=vc.presentedViewController;
    return vc;
}
static NSArray<NSNumber *> *BCTargetOrder(void) {
    NSMutableArray<NSNumber *> *targets = [NSMutableArray arrayWithArray:@[@(Z94881eb8d3), @(Z124338f2d8), @(Z700020a485), @(Z646dcbe562)]];
    if (Zx8fIsVIP()) {
        if (Zx8fPotionAllowed()) [targets addObject:@(Z2f0c1a9d77)];
        if (Zx8fTokenAllowed()) [targets addObject:@(Z87f6d0c11d)];
        if (Zx8fLightningAllowed()) [targets addObject:@(Z5d92a7e4c1)];
    }
    return targets;
}
static NSString *BCTargetName(NSInteger idx) {
    if (idx==Z94881eb8d3) return OngnongUIVaultText(OngnongUIVaultQxTargetSymbol);
    if (idx==Z124338f2d8) return OngnongUIVaultText(OngnongUIVaultQxTargetPig);
    if (idx==Z700020a485) return OngnongUIVaultText(OngnongUIVaultQxTargetHammer);
    if (idx==Z646dcbe562) return OngnongUIVaultText(OngnongUIVaultQxTargetSpin);
    if (idx==Z2f0c1a9d77) return OngnongUIVaultText(OngnongUIVaultQxTargetPotion);
    if (idx==Z87f6d0c11d) return OngnongUIVaultText(OngnongUIVaultQxTargetToken);
    if (idx==Z5d92a7e4c1) return OngnongUIVaultText(OngnongUIVaultQxTargetLightning);
    return OngnongUIVaultText(OngnongUIVaultQxTargetGeneric);
}
static UIImage *BCTargetIcon(NSInteger idx) {
    return OngnongCounterIconImage(idx);
}
static void BCApplyTargetViews(UIImageView *iconView, UILabel *nameLabel, NSInteger idx) {
    if (iconView) {
        iconView.image = BCTargetIcon(idx);
        iconView.contentMode = UIViewContentModeScaleAspectFit;
        iconView.clipsToBounds = NO;
    }
    if (nameLabel) nameLabel.text = BCTargetName(idx);
}
static UIImage *BCCollapseIcon(void) {
    static UIImage *image = nil;
    if (image) return image;
    CGSize size = CGSizeMake(30.0, 30.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    UIBezierPath *eye = [UIBezierPath bezierPath];
    eye.lineWidth = 2.2;
    eye.lineCapStyle = kCGLineCapRound;
    eye.lineJoinStyle = kCGLineJoinRound;
    [eye moveToPoint:CGPointMake(4.0, 15.0)];
    [eye addCurveToPoint:CGPointMake(15.0, 8.0) controlPoint1:CGPointMake(7.2, 10.2) controlPoint2:CGPointMake(11.2, 8.0)];
    [eye addCurveToPoint:CGPointMake(26.0, 15.0) controlPoint1:CGPointMake(18.8, 8.0) controlPoint2:CGPointMake(22.8, 10.2)];
    [eye addCurveToPoint:CGPointMake(15.0, 22.0) controlPoint1:CGPointMake(22.8, 19.8) controlPoint2:CGPointMake(18.8, 22.0)];
    [eye addCurveToPoint:CGPointMake(4.0, 15.0) controlPoint1:CGPointMake(11.2, 22.0) controlPoint2:CGPointMake(7.2, 19.8)];
    [BCBorder() setStroke];
    [eye stroke];
    UIBezierPath *pupil = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(11.0, 11.0, 8.0, 8.0)];
    [UIColor.whiteColor setFill];
    [pupil fill];
    UIBezierPath *dot = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(13.1, 13.1, 3.8, 3.8)];
    [BC_RGB(255,218,60) setFill];
    [dot fill];
    image = [UIGraphicsGetImageFromCurrentImageContext() imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UIGraphicsEndImageContext();
    return image;
}

@interface X4f0a1 () <UIGestureRecognizerDelegate, UITextFieldDelegate>
@property(nonatomic,strong) UILabel *titleLabel;
@property(nonatomic,strong) UIButton *eyeButton;
@property(nonatomic,strong) UISwitch *runSwitch;
@property(nonatomic,strong) UIButton *closeButton;
@property(nonatomic,strong) UIButton *targetButton;
@property(nonatomic,strong) UIImageView *targetIconView;
@property(nonatomic,strong) UILabel *targetNameLabel;
@property(nonatomic,strong) UILabel *targetChevronLabel;
@property(nonatomic,strong) UITextField *maxField;
@property(nonatomic,strong) UIView *maxLeftView;
@property(nonatomic,strong) UILabel *maxPrefixLabel;
@property(nonatomic,strong) UILabel *summaryLabel;
@property(nonatomic,strong) UIScrollView *rowsScroll;
@property(nonatomic,strong) UIButton *plusButton;
@property(nonatomic,strong) UIButton *minusButton;
@property(nonatomic,strong) UIButton *saveButton;
@property(nonatomic,strong) UIButton *resetButton;
@property(nonatomic,strong) UIButton *profileSaveButton;
@property(nonatomic,strong) UIButton *profilesButton;
@property(nonatomic,strong) UIImageView *compactIconView;
@property(nonatomic,strong) UILabel *compactLabel;
@property(nonatomic,strong) UIButton *resizeHandle;
@property(nonatomic,strong) UIControl *targetOverlay;
@property(nonatomic,strong) UIControl *profilesOverlay;
@property(nonatomic,strong) UIPanGestureRecognizer *profilesPan;
@property(nonatomic,strong) NSMutableArray<NSMutableDictionary *> *draftRows;
@property(nonatomic,assign) NSInteger draftTarget;
@property(nonatomic,assign) NSInteger selectedRow;
@property(nonatomic,assign) CGPoint dragStart;
@property(nonatomic,assign) CGSize resizeStart;
@property(nonatomic,assign) CGSize expandedSize;
@property(nonatomic,assign) BOOL applyingState;
@end

@implementation X4f0a1

- (instancetype)initWithFrame:(CGRect)frame {
    NSUserDefaults *sizeUd = [NSUserDefaults standardUserDefaults];
    CGFloat savedW = [sizeUd objectForKey:BCKey(OX_NS("w"))] ? [sizeUd floatForKey:BCKey(OX_NS("w"))] : 282.0;
    CGFloat savedH = [sizeUd objectForKey:BCKey(OX_NS("h"))] ? [sizeUd floatForKey:BCKey(OX_NS("h"))] : 276.0;
    savedW = MAX(210.0, MIN(430.0, savedW));
    savedH = MAX(210.0, MIN(520.0, savedH));
    self=[super initWithFrame:CGRectMake(frame.origin.x,frame.origin.y,savedW,savedH)]; if(!self) return nil;
    self.expandedSize = CGSizeMake(savedW, savedH);
    self.userInteractionEnabled=YES; self.clipsToBounds=YES; self.selectedRow=0;
    _titleLabel=BCLabel(OngnongUIVaultText(OngnongUIVaultQxTitle),13,UIFontWeightBlack,NSTextAlignmentLeft); [self addSubview:_titleLabel];
    _eyeButton=[UIButton buttonWithType:UIButtonTypeCustom];
    [_eyeButton setImage:BCCollapseIcon() forState:UIControlStateNormal];
    _eyeButton.imageView.contentMode=UIViewContentModeScaleAspectFit;
    _eyeButton.backgroundColor=[UIColor colorWithWhite:1 alpha:.08];
    BCStyle(_eyeButton,14.0);
    [_eyeButton addTarget:self action:@selector(hapticTouchDown:) forControlEvents:UIControlEventTouchDown];
    [_eyeButton addTarget:self action:@selector(eyeTapped) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_eyeButton];
    _runSwitch=[[UISwitch alloc] initWithFrame:CGRectZero]; _runSwitch.transform=CGAffineTransformMakeScale(.68,.68); _runSwitch.onTintColor=BC_RGB(30,185,95); [_runSwitch addTarget:self action:@selector(hapticTouchDown:) forControlEvents:UIControlEventTouchDown]; [_runSwitch addTarget:self action:@selector(runChanged:) forControlEvents:UIControlEventValueChanged]; [self addSubview:_runSwitch];
    _closeButton=[self smallButton:OX_NS("×") action:@selector(closeTapped)];
    _closeButton.titleLabel.font=[UIFont systemFontOfSize:17 weight:UIFontWeightBlack];
    [self addSubview:_closeButton];
    _targetButton=[UIButton buttonWithType:UIButtonTypeCustom];
    _targetButton.backgroundColor=BCOff(); BCStyle(_targetButton,8);
    [_targetButton addTarget:self action:@selector(hapticTouchDown:) forControlEvents:UIControlEventTouchDown];
    [_targetButton addTarget:self action:@selector(targetTapped:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_targetButton];
    _targetIconView=[[UIImageView alloc] initWithFrame:CGRectZero]; _targetIconView.contentMode=UIViewContentModeScaleAspectFit; _targetIconView.userInteractionEnabled=NO; [_targetButton addSubview:_targetIconView];
    _targetNameLabel=BCLabel(@"",11.5,UIFontWeightHeavy,NSTextAlignmentCenter); _targetNameLabel.userInteractionEnabled=NO; [_targetButton addSubview:_targetNameLabel];
    _targetChevronLabel=BCLabel(OX_NS("▾"),12.0,UIFontWeightBlack,NSTextAlignmentCenter); _targetChevronLabel.textColor=BCBorder(); _targetChevronLabel.userInteractionEnabled=NO; [_targetButton addSubview:_targetChevronLabel];
    _maxField=[[UITextField alloc] initWithFrame:CGRectZero]; _maxField.keyboardType=UIKeyboardTypeNumberPad; _maxField.textColor=UIColor.whiteColor; _maxField.textAlignment=NSTextAlignmentLeft; _maxField.font=[UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightBold]; _maxField.backgroundColor=BCOff(); BCStyle(_maxField,8); _maxField.delegate=self;
    _maxLeftView=[[UIView alloc] initWithFrame:CGRectZero]; _maxLeftView.userInteractionEnabled=NO;
    _maxPrefixLabel=BCLabel(OngnongUIVaultText(OngnongUIVaultQxAutoStop),9.0,UIFontWeightHeavy,NSTextAlignmentRight); _maxPrefixLabel.textColor=[UIColor colorWithWhite:1 alpha:.70];
    [_maxLeftView addSubview:_maxPrefixLabel];
    _maxField.leftView=_maxLeftView; _maxField.leftViewMode=UITextFieldViewModeAlways;
    [_maxField addTarget:self action:@selector(maxFieldChanged:) forControlEvents:UIControlEventEditingChanged];
    [self addSubview:_maxField];
    _summaryLabel=BCLabel(@"",11,UIFontWeightHeavy,NSTextAlignmentCenter); _summaryLabel.textColor=BC_RGB(255,238,83); [self addSubview:_summaryLabel];
    _rowsScroll=[[UIScrollView alloc] initWithFrame:CGRectZero]; _rowsScroll.backgroundColor=[UIColor colorWithWhite:0 alpha:.12]; BCStyle(_rowsScroll,9); _rowsScroll.alwaysBounceVertical=YES; [self addSubview:_rowsScroll];
    _plusButton=[self smallButton:OngnongUIVaultText(OngnongUIVaultQxAddRow) action:@selector(addRow)];
    _minusButton=[self smallButton:OngnongUIVaultText(OngnongUIVaultQxRemoveRow) action:@selector(removeRow)];
    _saveButton=[self smallButton:OngnongUIVaultText(OngnongUIVaultSave) action:@selector(saveConfig)];
    _resetButton=[self smallButton:OngnongUIVaultText(OngnongUIVaultQxReset) action:@selector(resetCycle)];
    _profileSaveButton=[self smallButton:BCProfileText(0) action:@selector(saveProfileTapped)];
    _profilesButton=[self smallButton:BCProfileText(1) action:@selector(showProfilesTapped)];
    _profileSaveButton.titleLabel.font=[UIFont systemFontOfSize:9.0 weight:UIFontWeightHeavy];
    _profilesButton.titleLabel.font=[UIFont systemFontOfSize:9.0 weight:UIFontWeightHeavy];
    for(UIView *v in @[_plusButton,_minusButton,_saveButton,_resetButton,_profileSaveButton,_profilesButton]) [self addSubview:v];
    _resizeHandle=[UIButton buttonWithType:UIButtonTypeCustom];
    [_resizeHandle setTitle:OX_NS("↘") forState:UIControlStateNormal];
    [_resizeHandle setTitleColor:BCBorder() forState:UIControlStateNormal];
    _resizeHandle.titleLabel.font=[UIFont systemFontOfSize:17 weight:UIFontWeightBlack];
    _resizeHandle.backgroundColor=[UIColor clearColor];
    UIPanGestureRecognizer *resizePan=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(resizeDragged:)];
    [_resizeHandle addGestureRecognizer:resizePan];
    [self addSubview:_resizeHandle];
    _compactIconView=[[UIImageView alloc] initWithFrame:CGRectZero]; _compactIconView.contentMode=UIViewContentModeScaleAspectFit; _compactIconView.hidden=YES; [self addSubview:_compactIconView];
    _compactLabel=BCLabel(@"",11.5,UIFontWeightBlack,NSTextAlignmentLeft); _compactLabel.font=[UIFont monospacedDigitSystemFontOfSize:11.5 weight:UIFontWeightBold]; _compactLabel.hidden=YES; [self addSubview:_compactLabel];
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(compactTapped)]; [_compactLabel addGestureRecognizer:tap]; _compactLabel.userInteractionEnabled=YES;
    UITapGestureRecognizer *iconTap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(compactTapped)]; [_compactIconView addGestureRecognizer:iconTap]; _compactIconView.userInteractionEnabled=YES;
    UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragged:)]; pan.delegate=self; [self addGestureRecognizer:pan];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moduleChanged:) name:R3n1() object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeChanged:) name:OX_NS("ongnong_theme_changed") object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(languageChanged:) name:OngnongUIVaultLanguageNotification() object:nil];
    [self refreshAll]; return self;
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; [self.targetOverlay removeFromSuperview]; [self.profilesOverlay removeFromSuperview]; }
- (void)hapticTouchDown:(UIControl *)sender { (void)sender; BCLightHaptic(); }
- (UIButton *)smallButton:(NSString *)title action:(SEL)action {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeCustom];
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont systemFontOfSize:11 weight:UIFontWeightHeavy];
    b.titleLabel.adjustsFontSizeToFitWidth=YES;
    b.titleLabel.minimumScaleFactor=.56;
    b.titleLabel.lineBreakMode=NSLineBreakByClipping;
    b.contentEdgeInsets=UIEdgeInsetsMake(0,3,0,3);
    b.backgroundColor=BCOff();
    BCStyle(b,7);
    [b addTarget:self action:@selector(hapticTouchDown:) forControlEvents:UIControlEventTouchDown];
    [b addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return b;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)g shouldReceiveTouch:(UITouch *)t { if (g == self.profilesPan) return YES; return ![t.view isKindOfClass:UIControl.class]; }
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)g shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)other { return (g == self.profilesPan || other == self.profilesPan); }
- (void)dragged:(UIPanGestureRecognizer *)pan { UIView *sv=self.superview; if(!sv)return; if(pan.state==UIGestureRecognizerStateBegan)self.dragStart=self.center; CGPoint tr=[pan translationInView:sv]; if(pan.state==UIGestureRecognizerStateChanged||pan.state==UIGestureRecognizerStateEnded){CGPoint c=CGPointMake(self.dragStart.x+tr.x,self.dragStart.y+tr.y); CGFloat hw=self.bounds.size.width/2,hh=self.bounds.size.height/2; c.x=MAX(hw,MIN(sv.bounds.size.width-hw,c.x)); c.y=MAX(hh+18,MIN(sv.bounds.size.height-hh,c.y)); self.center=c; if(pan.state==UIGestureRecognizerStateEnded){NSUserDefaults *ud=NSUserDefaults.standardUserDefaults;[ud setFloat:self.frame.origin.x forKey:BCKey(OX_NS("x"))];[ud setFloat:self.frame.origin.y forKey:BCKey(OX_NS("y"))];[ud synchronize];}} }
- (void)resizeDragged:(UIPanGestureRecognizer *)pan {
    if (R3n9()) return;
    UIView *sv = self.superview;
    if (!sv) return;
    if (pan.state == UIGestureRecognizerStateBegan) self.resizeStart = self.bounds.size;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint tr = [pan translationInView:sv];
        CGFloat maxW = MAX(210.0, sv.bounds.size.width - self.frame.origin.x - 4.0);
        CGFloat maxH = MAX(176.0, sv.bounds.size.height - self.frame.origin.y - 4.0);
        CGFloat nw = MAX(210.0, MIN(maxW, self.resizeStart.width + tr.x));
        CGFloat nh = MAX(210.0, MIN(maxH, self.resizeStart.height + tr.y));
        CGRect f = self.frame; f.size = CGSizeMake(nw, nh); self.frame = f;
        self.expandedSize = f.size;
        [self setNeedsLayout];
        [self layoutIfNeeded];
        [self reloadRows];
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:nw forKey:BCKey(OX_NS("w"))];
            [ud setFloat:nh forKey:BCKey(OX_NS("h"))];
            [ud synchronize];
        }
    }
}
- (void)layoutSubviews {
    [super layoutSubviews];
    BOOL compact = R3n9();
    if (compact) {
        self.eyeButton.frame = CGRectMake(3, 3, 28, 28);
        self.compactIconView.frame = CGRectMake(37, 4, 26, 26);
        self.compactLabel.frame = CGRectMake(68, 0, MAX(20.0, self.bounds.size.width - 74), self.bounds.size.height);
        self.resizeHandle.hidden = YES;
        return;
    }
    self.resizeHandle.hidden = NO;
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    BOOL narrow = w < 255.0;
    BOOL stackedButtons = w < 250.0;
    CGFloat headerH = 31.0;
    _titleLabel.frame = CGRectMake(8, 4, MAX(42.0, w - 126.0), 24);
    _titleLabel.font = [UIFont systemFontOfSize:narrow ? 10.5 : 13.0 weight:UIFontWeightBlack];
    _closeButton.frame = CGRectMake(w - 31.0, 3.0, 28.0, 28.0);
    _eyeButton.frame = CGRectMake(w - 63.0, 3.0, 28.0, 28.0);
    _runSwitch.bounds = CGRectMake(0, 0, 51, 31);
    _runSwitch.center = CGPointMake(w - 86.0, 17.0);
    CGFloat configY = headerH + 1.0;
    CGFloat configH = narrow ? 28.0 : 31.0;
    CGFloat innerW = w - 14.0;
    CGFloat leftW = narrow ? floor((innerW - 5.0) * .58) : MAX(130.0, w * .56 - 10.0);
    leftW = MIN(leftW, innerW - 72.0);
    _targetButton.frame = CGRectMake(7, configY, leftW, configH);
    CGFloat targetIconSide = narrow ? 22.0 : 25.0;
    _targetIconView.frame = CGRectMake(narrow ? 6.0 : 10.0, (configH-targetIconSide)/2.0, targetIconSide, targetIconSide);
    _targetChevronLabel.frame = CGRectMake(leftW-21.0, 0, 18.0, configH);
    _targetNameLabel.frame = CGRectMake(narrow ? 31.0 : 41.0, 0, MAX(24.0, leftW-(narrow ? 53.0 : 68.0)), configH);
    _targetNameLabel.font = [UIFont systemFontOfSize:narrow ? 10.0 : 11.5 weight:UIFontWeightHeavy];
    _maxField.frame = CGRectMake(CGRectGetMaxX(_targetButton.frame) + 5, configY, w - CGRectGetMaxX(_targetButton.frame) - 12, configH);
    _maxField.font = [UIFont monospacedDigitSystemFontOfSize:narrow ? 10.0 : 12.0 weight:UIFontWeightBold];
    _maxPrefixLabel.font = [UIFont systemFontOfSize:narrow ? 7.8 : 9.0 weight:UIFontWeightHeavy];
    NSString *numberText = _maxField.text ?: @"";
    CGFloat numberW = numberText.length > 0 ? ceil([numberText sizeWithAttributes:@{NSFontAttributeName:_maxField.font}].width) + 1.0 : 0.0;
    CGFloat textGap = numberText.length > 0 ? (narrow ? 2.0 : 3.0) : 0.0;
    CGFloat prefixMax = MAX(32.0, _maxField.bounds.size.width - numberW - textGap - 10.0);
    CGSize prefixFit = [_maxPrefixLabel sizeThatFits:CGSizeMake(prefixMax, configH)];
    CGFloat prefixW = MIN(prefixMax, MAX(32.0, prefixFit.width + 2.0));
    CGFloat groupW = prefixW + textGap + numberW;
    CGFloat leading = MAX(4.0, floor((_maxField.bounds.size.width - groupW) / 2.0));
    CGFloat leftViewW = MIN(_maxField.bounds.size.width - MAX(1.0, numberW), leading + prefixW + textGap);
    _maxLeftView.frame = CGRectMake(0, 0, leftViewW, configH);
    _maxPrefixLabel.frame = CGRectMake(leading, 0, prefixW, configH);
    CGFloat summaryY = CGRectGetMaxY(_targetButton.frame) + 1.0;
    CGFloat summaryH = h < 195.0 ? 17.0 : 21.0;
    _summaryLabel.frame = CGRectMake(7, summaryY, w - 14, summaryH);
    _summaryLabel.font = [UIFont systemFontOfSize:narrow ? 9.0 : 11.0 weight:UIFontWeightHeavy];
    CGFloat footerH = stackedButtons ? 84.0 : 68.0;
    CGFloat rowsY = CGRectGetMaxY(_summaryLabel.frame) + 2.0;
    CGFloat rowsBottom = h - footerH - 3.0;
    _rowsScroll.frame = CGRectMake(7, rowsY, w - 14, MAX(30.0, rowsBottom - rowsY));
    CGFloat gap = 4.0;
    CGFloat handleW = 23.0;
    NSArray *bs = @[_plusButton,_minusButton,_saveButton,_resetButton];
    CGFloat profileY = 0.0;
    if (stackedButtons) {
        CGFloat available = w - 14.0 - handleW - gap * 2.0;
        CGFloat bw = MAX(34.0, available / 2.0);
        CGFloat bh = 24.0;
        CGFloat y = h - 81.0;
        for (NSUInteger i=0; i<bs.count; i++) {
            NSUInteger row = i / 2;
            NSUInteger col = i % 2;
            ((UIView *)bs[i]).frame = CGRectMake(7.0 + col * (bw + gap), y + row * (bh + 3.0), bw, bh);
        }
        profileY = y + 2.0 * (bh + 3.0);
        CGFloat profileAvailable = w - 14.0 - handleW - gap;
        CGFloat profileW = MAX(62.0, profileAvailable / 2.0);
        _profileSaveButton.frame = CGRectMake(7.0, profileY, profileW, 27.0);
        _profilesButton.frame = CGRectMake(7.0 + profileW + gap, profileY, profileW, 27.0);
    } else {
        CGFloat available = w - 14.0 - handleW - gap * 3.0;
        CGFloat bw = MAX(34.0, available / 4.0);
        CGFloat y = h - 64.0;
        for (NSUInteger i=0; i<bs.count; i++) ((UIView *)bs[i]).frame = CGRectMake(7.0 + i*(bw+gap), y, bw, 28.0);
        profileY = y + 32.0;
        _profileSaveButton.frame = CGRectMake(7.0 + 2.0*(bw+gap), profileY, bw, 27.0);
        _profilesButton.frame = CGRectMake(7.0 + 3.0*(bw+gap), profileY, bw, 27.0);
    }
    _resizeHandle.frame = CGRectMake(w - 25, h - 27, 23, 23);
}

- (void)refreshTheme {
    self.backgroundColor=BCPanel();
    BCStyle(self,R3n9()?16:14);
    for(UIView *v in @[_targetButton,_maxField,_plusButton,_minusButton,_saveButton,_resetButton,_profileSaveButton,_profilesButton,_closeButton]){v.backgroundColor=BCOff();BCStyle(v,7);}
    _eyeButton.backgroundColor=[UIColor colorWithWhite:1 alpha:.08];
    BCStyle(_eyeButton,14.0);
    _targetChevronLabel.textColor=BCBorder();
    _rowsScroll.backgroundColor=[UIColor colorWithWhite:0 alpha:.12];
    BCStyle(_rowsScroll,9);
}
- (void)refreshTexts {
    _titleLabel.text=OngnongUIVaultText(OngnongUIVaultQxTitle);
    [self updateAutoStopPrefix];
    [_plusButton setTitle:OngnongUIVaultText(OngnongUIVaultQxAddRow) forState:UIControlStateNormal];
    [_minusButton setTitle:OngnongUIVaultText(OngnongUIVaultQxRemoveRow) forState:UIControlStateNormal];
    [_saveButton setTitle:OngnongUIVaultText(OngnongUIVaultSave) forState:UIControlStateNormal];
    [_resetButton setTitle:OngnongUIVaultText(OngnongUIVaultQxReset) forState:UIControlStateNormal];
    [_profileSaveButton setTitle:BCProfileText(0) forState:UIControlStateNormal];
    [_profilesButton setTitle:BCProfileText(1) forState:UIControlStateNormal];
    BCApplyTargetViews(_targetIconView,_targetNameLabel,self.draftTarget);
    [self refreshSummary];
    [self reloadRows];
}
- (void)themeChanged:(NSNotification *)n { (void)n; [self refreshTheme]; [self reloadRows]; }
- (void)languageChanged:(NSNotification *)n { (void)n; [self dismissTargetPicker]; [self refreshTexts]; [self setNeedsLayout]; }
- (void)moduleChanged:(NSNotification *)n {
    if (self.applyingState || self.hidden) return;
    if (R3n9()) {
        [self.runSwitch setOn:R3n8() animated:NO];
        [self refreshSummary];
        return;
    }
    if (R3n8()) {
        [self.runSwitch setOn:YES animated:NO];
        [self refreshSummary];
        [self reloadRows];
        return;
    }
    [self refreshAll];
}
- (void)refreshAll {
    self.applyingState=YES;
    R3ni(Zx8fBetCycleAllowed());
    self.draftRows=[NSMutableArray array];
    for(NSDictionary *r in R3n2()) [self.draftRows addObject:[r mutableCopy]];
    self.draftTarget=R3n3();
    if (![BCTargetOrder() containsObject:@(self.draftTarget)]) self.draftTarget=Z94881eb8d3;
    self.maxField.text=[NSString stringWithFormat:@"%ld",(long)R3n4()];
    [self updateAutoStopPrefix];
    [self.runSwitch setOn:R3n8() animated:NO];
    BCApplyTargetViews(self.targetIconView, self.targetNameLabel, self.draftTarget);
    [self applyCollapsed];
    [self reloadRows];
    [self refreshSummary];
    [self refreshTexts];
    [self refreshTheme];
    self.applyingState=NO;
}
- (void)applyCollapsed {
    BOOL c=R3n9();
    CGRect f=self.frame;
    if (c) {
        if (f.size.height > 40.0) self.expandedSize = f.size;
        f.size = CGSizeMake(MIN(260.0, MAX(210.0, self.expandedSize.width)), 34.0);
    } else {
        f.size = self.expandedSize.width > 0 ? self.expandedSize : CGSizeMake(282.0,238.0);
    }
    UIView *sv=self.superview;
    if(sv){
        if(CGRectGetMaxX(f)>sv.bounds.size.width)f.origin.x=sv.bounds.size.width-f.size.width-4;
        if(CGRectGetMaxY(f)>sv.bounds.size.height)f.origin.y=sv.bounds.size.height-f.size.height-4;
        f.origin.x=MAX(4,f.origin.x); f.origin.y=MAX(22,f.origin.y);
    }
    self.frame=f;
    for(UIView *v in @[_titleLabel,_runSwitch,_closeButton,_targetButton,_maxField,_summaryLabel,_rowsScroll,_plusButton,_minusButton,_saveButton,_resetButton,_profileSaveButton,_profilesButton,_resizeHandle]) v.hidden=c;
    _compactIconView.hidden=!c;
    _compactLabel.hidden=!c;
    _eyeButton.hidden=NO;
    self.layer.cornerRadius=c?17:14;
    [self setNeedsLayout];
}
- (void)refreshSummary {
    NSArray *rows=R3n2();
    NSInteger ri=R3n6();
    NSInteger rc=R3n7();
    NSInteger bet=0,quota=0;
    if(rows.count){
        ri=MAX(0,MIN(ri,(NSInteger)rows.count-1));
        bet=[rows[ri][OX_NS("bet")] integerValue];
        quota=[rows[ri][OX_NS("spins")] integerValue];
    }
    NSString *state=R3na();
    self.summaryLabel.text=[NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxSummaryFormat),state,(long)bet,(long)rc,(long)quota,(long)R3n5(),(long)R3n4()];
    NSInteger target=R3n3();
    self.compactIconView.image=BCTargetIcon(target);
    self.compactLabel.text=[NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultQxCompactFormat),BCTargetName(target),(long)bet,(long)rc,(long)quota,(long)R3n5(),(long)R3n4()];
}
- (void)reloadRows {
    for(UIView *v in _rowsScroll.subviews) [v removeFromSuperview];
    CGFloat w = MAX(160.0, _rowsScroll.bounds.size.width);
    CGFloat usable = MAX(152.0, w - 8.0);
    CGFloat rowCol = MAX(28.0, MIN(40.0, usable * .16));
    CGFloat rest = MAX(120.0, usable - rowCol - 6.0);
    CGFloat betCol = rest * .31;
    CGFloat spinCol = rest * .32;
    CGFloat progressCol = MAX(38.0, rest - betCol - spinCol);
    CGFloat x1=2.0, x2=x1+rowCol+2.0, x3=x2+betCol+3.0, x4=x3+spinCol+3.0;
    UILabel *h1=BCLabel(OngnongUIVaultText(OngnongUIVaultQxRow),10,UIFontWeightBold,NSTextAlignmentCenter);
    UILabel *h2=BCLabel(OX_NS("xBET"),10,UIFontWeightBold,NSTextAlignmentCenter);
    UILabel *h3=BCLabel(OngnongUIVaultText(OngnongUIVaultQxSpins),10,UIFontWeightBold,NSTextAlignmentCenter);
    UILabel *h4=BCLabel(OngnongUIVaultText(OngnongUIVaultQxProgress),10,UIFontWeightBold,NSTextAlignmentCenter);
    h1.frame=CGRectMake(x1,2,rowCol,20); h2.frame=CGRectMake(x2,2,betCol,20); h3.frame=CGRectMake(x3,2,spinCol,20); h4.frame=CGRectMake(x4,2,progressCol,20);
    for(UIView *v in @[h1,h2,h3,h4]) [_rowsScroll addSubview:v];
    BOOL running=R3n8(); NSInteger current=R3n6(); NSInteger currentCount=R3n7(); CGFloat y=24;
    for(NSInteger i=0;i<(NSInteger)self.draftRows.count;i++){
        NSMutableDictionary *r=self.draftRows[i];
        UIButton *sel=[UIButton buttonWithType:UIButtonTypeCustom];
        [sel setTitle:[NSString stringWithFormat:@"%ld",(long)i+1] forState:UIControlStateNormal]; sel.tag=i;
        [sel addTarget:self action:@selector(hapticTouchDown:) forControlEvents:UIControlEventTouchDown];
        [sel addTarget:self action:@selector(selectRow:) forControlEvents:UIControlEventTouchUpInside];
        sel.backgroundColor=(i==self.selectedRow)?BC_RGB(245,152,44):BCOff(); BCStyle(sel,6); sel.frame=CGRectMake(x1+2,y,rowCol-4,30); [_rowsScroll addSubview:sel];
        UITextField *bet=[self rowField:[r[OX_NS("bet")] stringValue] tag:1000+i]; bet.frame=CGRectMake(x2,y,betCol,30); [_rowsScroll addSubview:bet];
        UITextField *sp=[self rowField:[r[OX_NS("spins")] stringValue] tag:2000+i]; sp.frame=CGRectMake(x3,y,spinCol,30); [_rowsScroll addSubview:sp];
        NSInteger quota=[r[OX_NS("spins")] integerValue]; NSString *prog=@"0";
        if(i<current) prog=[NSString stringWithFormat:@"%ld/%ld",(long)quota,(long)quota];
        else if(i==current) prog=[NSString stringWithFormat:@"%ld/%ld",(long)currentCount,(long)quota];
        UILabel *pl=BCLabel(prog,10.5,UIFontWeightBold,NSTextAlignmentCenter); pl.frame=CGRectMake(x4,y,progressCol,30); [_rowsScroll addSubview:pl];
        bet.enabled=!running; sp.enabled=!running; sel.enabled=!running; y+=34;
    }
    _rowsScroll.contentSize=CGSizeMake(w,y+4);
    self.maxField.enabled=!running; self.targetButton.enabled=!running; self.plusButton.enabled=!running; self.minusButton.enabled=!running; self.saveButton.enabled=!running; self.profileSaveButton.enabled=!running; self.profilesButton.enabled=!running;
    CGFloat alpha=running?.42:1; self.maxField.alpha=alpha; self.targetButton.alpha=alpha; self.plusButton.alpha=alpha; self.minusButton.alpha=alpha; self.saveButton.alpha=alpha; self.profileSaveButton.alpha=alpha; self.profilesButton.alpha=alpha;
}

- (UITextField *)rowField:(NSString *)text tag:(NSInteger)tag { UITextField *f=[[UITextField alloc] initWithFrame:CGRectZero];f.text=text;f.tag=tag;f.keyboardType=UIKeyboardTypeNumberPad;f.textAlignment=NSTextAlignmentCenter;f.textColor=UIColor.whiteColor;f.font=[UIFont monospacedDigitSystemFontOfSize:11.5 weight:UIFontWeightBold];f.backgroundColor=BCOff();BCStyle(f,6);f.delegate=self;[f addTarget:self action:@selector(fieldChanged:) forControlEvents:UIControlEventEditingChanged];return f; }
- (void)fieldChanged:(UITextField *)f { NSInteger idx=f.tag%1000;if(idx<0||idx>=(NSInteger)self.draftRows.count)return;NSInteger v=MAX((NSInteger)0,f.text.integerValue);NSString *k=f.tag>=2000?OX_NS("spins"):OX_NS("bet");self.draftRows[idx][k]=@(v); }
- (void)maxFieldChanged:(UITextField *)field { (void)field; [self updateAutoStopPrefix]; [self setNeedsLayout]; }
- (void)updateAutoStopPrefix {
    NSString *title = OngnongUIVaultText(OngnongUIVaultQxAutoStop);
    self.maxPrefixLabel.text = self.maxField.text.length > 0 ? [title stringByAppendingString:OX_NS(":")] : title;
}
- (void)selectRow:(UIButton *)b { self.selectedRow=b.tag;[self reloadRows]; }
- (void)addRow { if(R3n8())return;if(self.draftRows.count>=20){[self showError:OngnongUIVaultText(OngnongUIVaultQxMaxRows)];return;}[self.draftRows addObject:[@{OX_NS("bet"):@1,OX_NS("spins"):@10} mutableCopy]];self.selectedRow=self.draftRows.count-1;[self reloadRows]; }
- (void)removeRow { if(R3n8())return;if(self.draftRows.count<=1){[self showError:OngnongUIVaultText(OngnongUIVaultQxMinRow)];return;}NSInteger idx=MAX(0,MIN(self.selectedRow,(NSInteger)self.draftRows.count-1));[self.draftRows removeObjectAtIndex:idx];self.selectedRow=MAX(0,MIN(idx,(NSInteger)self.draftRows.count-1));[self reloadRows]; }
- (void)saveConfig { [self endEditing:YES]; NSString *err=nil; BOOL ok=R3nb(self.draftRows,self.draftTarget,self.maxField.text.integerValue,&err); if(!ok){[self showError:err];return;}[self refreshAll]; }
- (void)resetCycle { R3ne(); [self refreshAll]; }
- (void)runChanged:(UISwitch *)sw { NSString *err=nil;BOOL ok=R3nc(sw.isOn,&err);if(!ok){[sw setOn:NO animated:YES];[self showError:err];} [self refreshAll]; }
- (void)eyeTapped { R3nd(!R3n9());[self applyCollapsed];[self refreshSummary]; }
- (void)compactTapped { BCLightHaptic(); if(R3n9()){R3nd(NO);[self applyCollapsed];[self refreshSummary];} }
- (void)closeTapped {
    BCLightHaptic();
    [self endEditing:YES];
    [self dismissTargetPicker];
    [self dismissProfiles];
    if (R3n8()) R3nc(NO, nullptr);
    [self.runSwitch setOn:NO animated:NO];
    self.hidden = YES;
}
- (NSMutableArray<NSMutableDictionary *> *)savedProfiles {
    NSArray *raw = [[NSUserDefaults standardUserDefaults] arrayForKey:BCKey(OX_NS("profiles_v1"))];
    NSMutableArray *out = [NSMutableArray array];
    NSArray *source = raw ? raw : @[];
    for (id obj in source) {
        if (![obj isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *d = (NSDictionary *)obj;
        id nameObj = [d objectForKey:OX_NS("name")];
        id rowsObj = [d objectForKey:OX_NS("rows")];
        NSString *name = [nameObj isKindOfClass:[NSString class]] ? (NSString *)nameObj : OX_NS("");
        NSArray *rows = [rowsObj isKindOfClass:[NSArray class]] ? (NSArray *)rowsObj : nil;
        if ([name length] == 0 || [rows count] == 0) continue;
        [out addObject:[d mutableCopy]];
    }
    return out;
}

- (BOOL)storeProfiles:(NSArray *)profiles {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:(profiles ? profiles : @[]) forKey:BCKey(OX_NS("profiles_v1"))];
    return [ud synchronize];
}

- (NSInteger)findProfileNamed:(NSString *)name inProfiles:(NSArray *)profiles except:(NSInteger)exceptIndex {
    if ([name length] == 0) return -1;
    for (NSInteger i = 0; i < (NSInteger)[profiles count]; i++) {
        if (i == exceptIndex) continue;
        id item = [profiles objectAtIndex:(NSUInteger)i];
        if (![item isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *profile = (NSDictionary *)item;
        id nameObj = [profile objectForKey:OX_NS("name")];
        NSString *storedName = [nameObj isKindOfClass:[NSString class]] ? (NSString *)nameObj : OX_NS("");
        if ([storedName caseInsensitiveCompare:name] == NSOrderedSame) return i;
    }
    return -1;
}

- (NSDictionary *)currentProfileNamed:(NSString *)name {
    if ([name length] == 0 || [self.draftRows count] == 0) return nil;
    NSMutableArray *rows = [NSMutableArray array];
    NSInteger minimum = 0;
    for (NSDictionary *row in self.draftRows) {
        NSInteger bet = [[row objectForKey:OX_NS("bet")] integerValue];
        NSInteger spins = [[row objectForKey:OX_NS("spins")] integerValue];
        if (bet <= 0 || spins <= 0) return nil;
        [rows addObject:@{ OX_NS("bet") : @(bet), OX_NS("spins") : @(spins) }];
        minimum += spins;
    }
    NSInteger maxTotal = [self.maxField.text integerValue];
    if (maxTotal < minimum || ![BCTargetOrder() containsObject:@(self.draftTarget)]) return nil;
    return @{ OX_NS("name") : name,
              OX_NS("rows") : rows,
              OX_NS("target") : @(self.draftTarget),
              OX_NS("max") : @(maxTotal) };
}

- (void)saveProfileTapped {
    if (R3n8()) {
        [self showError:OngnongUIVaultText(OngnongUIVaultQxErrTurnOffBeforeEdit)];
        return;
    }
    [self endEditing:YES];
    NSMutableArray *profiles = [self savedProfiles];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:BCProfileText(3)
                                                                    message:nil
                                                             preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = BCProfileText(2);
        textField.text = [NSString stringWithFormat:OX_NS("%@ %ld"), BCProfileText(1), (long)[profiles count] + 1];
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [alert addAction:[UIAlertAction actionWithTitle:BCProfileText(10)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    X4f0a1 *owner = self;
    [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultSave)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        (void)action;
        NSString *rawName = alert.textFields.firstObject.text;
        NSString *name = [rawName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if ([name length] == 0) {
            [owner showError:BCProfileText(13)];
            return;
        }

        NSDictionary *profile = [owner currentProfileNamed:name];
        if (!profile) {
            [owner showError:OngnongUIVaultText(OngnongUIVaultQxInvalidConfig)];
            return;
        }

        NSInteger oldIndex = [owner findProfileNamed:name inProfiles:profiles except:-1];
        void (^commitProfile)(void) = ^{
            NSMutableDictionary *copy = [profile mutableCopy];
            if (oldIndex >= 0) {
                [profiles replaceObjectAtIndex:(NSUInteger)oldIndex withObject:copy];
            } else {
                [profiles addObject:copy];
            }
            [owner storeProfiles:profiles];
        };

        if (oldIndex >= 0) {
            UIAlertController *replaceAlert = [UIAlertController alertControllerWithTitle:BCProfileText(14)
                                                                                   message:nil
                                                                            preferredStyle:UIAlertControllerStyleAlert];
            [replaceAlert addAction:[UIAlertAction actionWithTitle:BCProfileText(10)
                                                            style:UIAlertActionStyleCancel
                                                          handler:nil]];
            [replaceAlert addAction:[UIAlertAction actionWithTitle:BCProfileText(15)
                                                            style:UIAlertActionStyleDestructive
                                                          handler:^(UIAlertAction *replaceAction) {
                (void)replaceAction;
                commitProfile();
            }]];
            [BCTopVC() presentViewController:replaceAlert animated:YES completion:nil];
        } else {
            commitProfile();
        }
    }]];
    [BCTopVC() presentViewController:alert animated:YES completion:nil];
}

- (void)dismissProfiles {
    [self.profilesOverlay removeFromSuperview];
    self.profilesOverlay = nil;
    self.profilesPan = nil;
}

- (void)dragProfilesCard:(UIPanGestureRecognizer *)pan {
    UIView *card = pan.view;
    UIView *host = card.superview;
    if (!card || !host) return;
    CGPoint tr = [pan translationInView:host];
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(card.center.x + tr.x, card.center.y + tr.y);
        CGFloat hw = card.bounds.size.width * 0.5;
        CGFloat hh = card.bounds.size.height * 0.5;
        CGFloat margin = 6.0;
        c.x = MAX(hw + margin, MIN(host.bounds.size.width - hw - margin, c.x));
        c.y = MAX(hh + margin, MIN(host.bounds.size.height - hh - margin, c.y));
        card.center = c;
        [pan setTranslation:CGPointZero inView:host];
    }
}

- (void)showProfilesTapped {
    if (R3n8()) {
        [self showError:OngnongUIVaultText(OngnongUIVaultQxErrTurnOffBeforeEdit)];
        return;
    }
    [self dismissProfiles];
    UIView *host = BCTopVC().view;
    if (!host) return;

    NSMutableArray *profiles = [self savedProfiles];
    UIControl *overlay = [[UIControl alloc] initWithFrame:host.bounds];
    overlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    overlay.backgroundColor = [UIColor colorWithWhite:0 alpha:.20];
    self.profilesOverlay = overlay;

    CGFloat cardW = MIN(286.0, host.bounds.size.width - 18.0);
    NSInteger visibleRows = MIN((NSInteger)[profiles count], 6);
    CGFloat desiredH = ([profiles count] == 0) ? 104.0 : (54.0 + visibleRows * 38.0);
    CGFloat cardH = MIN(host.bounds.size.height - 34.0, MAX(104.0, desiredH));
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake((host.bounds.size.width-cardW)/2.0,
                                                            (host.bounds.size.height-cardH)/2.0,
                                                            cardW, cardH)];
    card.backgroundColor = BCPanelDark();
    BCStyle(card, 11);
    card.clipsToBounds = YES;
    [overlay addSubview:card];

    UIPanGestureRecognizer *movePan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragProfilesCard:)];
    movePan.delegate = self;
    movePan.cancelsTouchesInView = NO;
    [card addGestureRecognizer:movePan];
    self.profilesPan = movePan;

    UILabel *title = BCLabel(BCProfileText(1), 11.5, UIFontWeightBlack, NSTextAlignmentCenter);
    title.frame = CGRectMake(34, 2, cardW-68, 25);
    [card addSubview:title];

    UIButton *close = [self smallButton:OX_NS("×") action:@selector(dismissProfiles)];
    close.frame = CGRectMake(cardW-29, 2, 25, 25);
    close.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightBlack];
    [card addSubview:close];

    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(6, 29, cardW-12, cardH-35)];
    scroll.showsVerticalScrollIndicator = NO;
    [card addSubview:scroll];

    if ([profiles count] == 0) {
        UILabel *empty = BCLabel(BCProfileText(5), 10.5, UIFontWeightHeavy, NSTextAlignmentCenter);
        empty.frame = CGRectMake(4, 8, scroll.bounds.size.width-8, 46);
        [scroll addSubview:empty];
        scroll.contentSize = CGSizeMake(scroll.bounds.size.width, 62);
    } else {
        UILabel *hint = BCLabel(BCProfileText(6), 8.5, UIFontWeightMedium, NSTextAlignmentCenter);
        hint.textColor = [UIColor colorWithWhite:1 alpha:.60];
        hint.frame = CGRectMake(4, 0, scroll.bounds.size.width-8, 16);
        [scroll addSubview:hint];

        CGFloat y = 18.0;
        for (NSInteger i = 0; i < (NSInteger)[profiles count]; i++) {
            NSDictionary *profile = [profiles objectAtIndex:(NSUInteger)i];
            UIView *row = [[UIView alloc] initWithFrame:CGRectMake(0, y, scroll.bounds.size.width, 34)];
            row.backgroundColor = [UIColor colorWithWhite:1 alpha:.07];
            row.layer.cornerRadius = 7;
            [scroll addSubview:row];

            UIButton *nameButton = [UIButton buttonWithType:UIButtonTypeCustom];
            nameButton.tag = 10000 + i;
            nameButton.frame = CGRectMake(5, 2, MAX(56.0, row.bounds.size.width-79), 30);
            id displayNameObj = [profile objectForKey:OX_NS("name")];
            NSString *displayName = [displayNameObj isKindOfClass:[NSString class]] ? (NSString *)displayNameObj : BCProfileText(1);
            [nameButton setTitle:displayName forState:UIControlStateNormal];
            [nameButton setTitleColor:BC_RGB(126,205,255) forState:UIControlStateNormal];
            nameButton.titleLabel.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightHeavy];
            nameButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
            nameButton.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
            [nameButton addTarget:self action:@selector(loadProfileButton:) forControlEvents:UIControlEventTouchUpInside];
            [row addSubview:nameButton];

            UIButton *renameButton = [self smallButton:OX_NS("✎") action:@selector(renameProfileButton:)];
            renameButton.tag = 20000 + i;
            renameButton.frame = CGRectMake(row.bounds.size.width-70, 2, 31, 30);
            renameButton.titleLabel.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightHeavy];
            [row addSubview:renameButton];

            UIButton *deleteButton = [self smallButton:OX_NS("×") action:@selector(deleteProfileButton:)];
            deleteButton.tag = 30000 + i;
            deleteButton.frame = CGRectMake(row.bounds.size.width-35, 2, 31, 30);
            deleteButton.titleLabel.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightHeavy];
            [row addSubview:deleteButton];
            y += 38.0;
        }
        scroll.contentSize = CGSizeMake(scroll.bounds.size.width, y + 2.0);
    }
    [host addSubview:overlay];
}

- (void)loadProfileButton:(UIButton *)button {
    NSInteger idx = button.tag - 10000;
    NSArray *profiles = [self savedProfiles];
    if (idx < 0 || idx >= (NSInteger)[profiles count]) return;

    NSDictionary *profile = [profiles objectAtIndex:(NSUInteger)idx];
    id rowsObj = [profile objectForKey:OX_NS("rows")];
    NSArray *rows = [rowsObj isKindOfClass:[NSArray class]] ? (NSArray *)rowsObj : nil;
    NSInteger target = [[profile objectForKey:OX_NS("target")] integerValue];
    NSInteger maxTotal = [[profile objectForKey:OX_NS("max")] integerValue];
    if ([rows count] == 0) {
        [self showError:BCProfileText(12)];
        return;
    }

    if (R3n8()) R3nc(NO, nullptr);
    NSString *error = nil;
    if (!R3nb(rows, target, maxTotal, &error)) {
        [self showError:(error ? error : BCProfileText(12))];
        return;
    }

    self.selectedRow = 0;
    [self refreshAll];
}

- (void)deleteProfileButton:(UIButton *)button {
    NSInteger idx = button.tag - 30000;
    NSMutableArray *profiles = [self savedProfiles];
    if (idx < 0 || idx >= (NSInteger)[profiles count]) return;

    NSDictionary *profile = [profiles objectAtIndex:(NSUInteger)idx];
    NSString *profileName = [[profile objectForKey:OX_NS("name")] description];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:BCProfileText(9)
                                                                    message:profileName
                                                             preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:BCProfileText(10)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    X4f0a1 *owner = self;
    [alert addAction:[UIAlertAction actionWithTitle:BCProfileText(8)
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *action) {
        (void)action;
        if (idx < 0 || idx >= (NSInteger)[profiles count]) return;
        [profiles removeObjectAtIndex:(NSUInteger)idx];
        [owner storeProfiles:profiles];
        [owner dismissProfiles];
        [owner showProfilesTapped];
    }]];
    [BCTopVC() presentViewController:alert animated:YES completion:nil];
}

- (void)renameProfileButton:(UIButton *)button {
    NSInteger idx = button.tag - 20000;
    NSMutableArray *profiles = [self savedProfiles];
    if (idx < 0 || idx >= (NSInteger)[profiles count]) return;

    NSMutableDictionary *profile = [[profiles objectAtIndex:(NSUInteger)idx] mutableCopy];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:BCProfileText(7)
                                                                    message:nil
                                                             preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        id currentName = [profile objectForKey:OX_NS("name")];
        textField.text = [currentName isKindOfClass:[NSString class]] ? (NSString *)currentName : OX_NS("");
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [alert addAction:[UIAlertAction actionWithTitle:BCProfileText(10)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    X4f0a1 *owner = self;
    [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultSave)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        (void)action;
        NSString *rawName = alert.textFields.firstObject.text;
        NSString *name = [rawName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if ([name length] == 0) {
            [owner showError:BCProfileText(13)];
            return;
        }
        if ([owner findProfileNamed:name inProfiles:profiles except:idx] >= 0) {
            [owner showError:BCProfileText(14)];
            return;
        }

        [profile setObject:name forKey:OX_NS("name")];
        [profiles replaceObjectAtIndex:(NSUInteger)idx withObject:profile];
        [owner storeProfiles:profiles];
        [owner dismissProfiles];
        [owner showProfilesTapped];
    }]];
    [BCTopVC() presentViewController:alert animated:YES completion:nil];
}

- (void)dismissTargetPicker {
    [self.targetOverlay removeFromSuperview];
    self.targetOverlay = nil;
}
- (void)targetChoice:(UIButton *)button {
    NSInteger idx = button.tag;
    self.draftTarget = idx;
    BCApplyTargetViews(self.targetIconView, self.targetNameLabel, idx);
    [self dismissTargetPicker];
}
- (void)targetTapped:(UIButton *)sender {
    (void)sender;
    [self dismissTargetPicker];
    UIView *host = BCTopVC().view;
    if (!host) return;
    UIControl *overlay = [[UIControl alloc] initWithFrame:host.bounds];
    overlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    overlay.backgroundColor = [UIColor colorWithWhite:0 alpha:.24];
    [overlay addTarget:self action:@selector(dismissTargetPicker) forControlEvents:UIControlEventTouchUpInside];
    self.targetOverlay = overlay;

    NSArray<NSNumber *> *availableTargets = BCTargetOrder();
    CGFloat cardW = MIN(244.0, host.bounds.size.width - 30.0);
    CGFloat rowH = 34.0;
    CGFloat titleH = 38.0;
    CGFloat cardH = titleH + rowH * availableTargets.count + 8.0;
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake((host.bounds.size.width-cardW)/2.0, (host.bounds.size.height-cardH)/2.0, cardW, cardH)];
    card.backgroundColor = BCPanelDark();
    BCStyle(card, 13.0);
    card.clipsToBounds = YES;
    [overlay addSubview:card];

    UILabel *title = BCLabel(OngnongUIVaultText(OngnongUIVaultQxSelectTarget), 12.5, UIFontWeightBlack, NSTextAlignmentCenter);
    title.frame = CGRectMake(8, 2, cardW-16, titleH-4);
    [card addSubview:title];

    CGFloat y = titleH;
    for (NSNumber *n in availableTargets) {
        NSInteger idx = n.integerValue;
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = idx;
        b.frame = CGRectMake(0, y, cardW, rowH);
        b.backgroundColor = (idx == self.draftTarget) ? [BCBorder() colorWithAlphaComponent:.13] : [UIColor clearColor];
        [b addTarget:self action:@selector(hapticTouchDown:) forControlEvents:UIControlEventTouchDown];
        [b addTarget:self action:@selector(targetChoice:) forControlEvents:UIControlEventTouchUpInside];

        UIImageView *iconView = [[UIImageView alloc] initWithImage:BCTargetIcon(idx)];
        iconView.contentMode = UIViewContentModeScaleAspectFit;
        iconView.clipsToBounds = YES;
        CGFloat iconSide = (idx == Z87f6d0c11d || idx == Z5d92a7e4c1) ? 29.0 : 26.0;
        iconView.frame = CGRectMake(21.0, (rowH-iconSide)/2.0, iconSide, iconSide);
        iconView.userInteractionEnabled = NO;
        [b addSubview:iconView];

        UILabel *nameLabel = BCLabel(BCTargetName(idx), 13.0, UIFontWeightHeavy, NSTextAlignmentLeft);
        nameLabel.textColor = BC_RGB(126,205,255);
        nameLabel.frame = CGRectMake(58.0, 0, cardW-68.0, rowH);
        nameLabel.userInteractionEnabled = NO;
        [b addSubview:nameLabel];
        [card addSubview:b];
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(12, y+rowH-0.5, cardW-24, 0.5)];
        line.backgroundColor = [UIColor colorWithWhite:1 alpha:.20];
        [card addSubview:line];
        y += rowH;
    }
    [host addSubview:overlay];
}

- (void)showError:(NSString *)text {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:OngnongUIVaultText(OngnongUIVaultQxPanelTitle)
                                                               message:text?:OngnongUIVaultText(OngnongUIVaultQxInvalidConfig)
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultQxOK) style:UIAlertActionStyleDefault handler:nil]];
    [BCTopVC() presentViewController:a animated:YES completion:nil];
}
@end
