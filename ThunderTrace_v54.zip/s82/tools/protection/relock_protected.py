#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from protectlib import build_manifest

PHRASE='USER_TESTED_STABLE_RELOCK'

def main():
    ap=argparse.ArgumentParser(description='Create a new stable protection baseline after user testing.')
    ap.add_argument('--confirm',required=True,help=f'Must be exactly {PHRASE}')
    args=ap.parse_args()
    if args.confirm!=PHRASE:
        raise SystemExit('REFUSED: explicit stable-release confirmation phrase is required.')
    root=Path(__file__).resolve().parents[2]
    manifest=build_manifest(root)
    out=root/'tools/protection/protected_manifest.json'
    out.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'RELOCKED: {len(manifest["files"])} files')
    print(f'MODULES: {len(manifest["modules"])}')
    print('This source snapshot is now the new protected stable baseline.')

if __name__=='__main__': main()
