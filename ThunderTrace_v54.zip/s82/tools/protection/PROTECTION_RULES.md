# ÔNG NÔNG stable-source protection

This snapshot is the stable baseline. All existing source files and detected function/method regions are protected.

Before any edit:

```bash
python3 tools/protection/verify_protected.py
```

It must PASS before editing.

For a requested change, identify the exact protected function/method:

```bash
python3 tools/protection/list_protected.py --search AutoBuild
python3 tools/protection/list_protected.py --module auto_build
```

After editing, allow only the exact function(s) intentionally changed:

```bash
python3 tools/protection/verify_protected.py \
  --allow-segment 'Core/OngnongHookManager.mm::c:AutoBuildModuleSetEnabled'
```

If any other function, global region, file, script, asset, or binary changed, verification FAILS. Do not deliver that source until unintended changes are restored.

`--allow-file` and `--allow-module` exist for exceptional refactors, but exact `--allow-segment` is preferred.

Do not create a new baseline merely to make a failure disappear. Relock only after the user has tested the intended change and explicitly confirmed that the new source is stable:

```bash
python3 tools/protection/relock_protected.py --confirm USER_TESTED_STABLE_RELOCK
```

The protection tools are outside production runtime logic and do not change app behavior.
