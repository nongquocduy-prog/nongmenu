#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, re
from pathlib import Path

SOURCE_EXTS={'.mm','.m','.h','.hpp','.c','.cc','.cpp','.cxx'}
SKIP_DIRS={'.git','build','DerivedData','.theos','obj','out','tools/protection'}
SKIP_NAMES={'protected_manifest.json'}

MODULE_RULES=[
 ('auto_build', r'autobuild|auto_build|buildmodule|hbautobuild'),
 ('auto_pig_hammer_raid', r'hammer|raid|pig|steal|attack|autorevenge|revenge'),
 ('magic_cards', r'magic|chest|cards?'),
 ('auto_merge', r'automerge|auto_merge|merge'),
 ('auto_click', r'autoclick|auto_click|metatouch|fake.*touch'),
 ('expedition', r'expedition|wilderness|hoang|forest'),
 ('token', r'token'),
 ('potion', r'potion|medicine|thuoc'),
 ('lightning', r'lightning|lightningcount|tia.*set'),
 ('counter_history', r'counter|history|spin.*count|total.*count'),
 ('bet_cycle', r'betcycle|bet_cycle|xb(et)?|cycle'),
 ('speed', r'speed|timescale'),
 ('friend_invite', r'friend|invite'),
 ('auto_stop', r'autostop|auto_stop'),
 ('menu_color', r'menucolor|menu_color|color.*menu'),
 ('branding_profile', r'brand|profile|ui.?labels?|menu.?labels?|footer|main.?title'),
 ('notification', r'announce|announcement|notice|notif|link_text|link_url'),
 ('vip_free_license', r'vip|free|license|session|activate|activation|allowed|gate|hash|buildid|device'),
 ('payment', r'pay|paypal|payos|purchase|qr'),
 ('fps', r'fps'),
]

def sha256_bytes(b:bytes)->str:
    return hashlib.sha256(b).hexdigest()

def norm_header(s:str)->str:
    return re.sub(r'\s+',' ',s.strip())

def sanitize(text:str)->str:
    # Preserve byte-length-ish character positions/newlines for parsing. Python chars suffice for ASCII syntax.
    out=list(text)
    i=0; n=len(text); state='code'; quote=''
    while i<n:
        c=text[i]
        if state=='code':
            if c=='/' and i+1<n and text[i+1]=='/':
                out[i]=out[i+1]=' '; i+=2; state='line'; continue
            if c=='/' and i+1<n and text[i+1]=='*':
                out[i]=out[i+1]=' '; i+=2; state='block'; continue
            if c in ('"',"'"):
                quote=c; out[i]=' '; i+=1; state='string'; continue
            i+=1; continue
        if state=='line':
            if c=='\n': state='code'
            else: out[i]=' '
            i+=1; continue
        if state=='block':
            if c=='*' and i+1<n and text[i+1]=='/':
                out[i]=out[i+1]=' '; i+=2; state='code'; continue
            if c!='\n': out[i]=' '
            i+=1; continue
        if state=='string':
            if c=='\\' and i+1<n:
                out[i]=' '; out[i+1]=' ' if text[i+1]!='\n' else '\n'; i+=2; continue
            if c==quote:
                out[i]=' '; i+=1; state='code'; continue
            if c!='\n': out[i]=' '
            i+=1
    return ''.join(out)

def brace_pairs(san:str):
    stack=[]; pairs={}
    for i,c in enumerate(san):
        if c=='{': stack.append(i)
        elif c=='}' and stack:
            a=stack.pop(); pairs[a]=i
    return pairs

def line_no(text:str,pos:int)->int:
    return text.count('\n',0,pos)+1

def current_objc_class(text:str,pos:int)->str:
    # Last @implementation not closed by @end.
    prefix=text[:pos]
    toks=list(re.finditer(r'@(implementation|end)\b(?:\s+([A-Za-z_][\w]*))?', prefix))
    cls=''
    for m in toks:
        if m.group(1)=='implementation': cls=m.group(2) or 'Unknown'
        else: cls=''
    return cls or 'ObjC'

def header_start(san:str, brace:int)->int:
    # Go back to a structural boundary, but cap for safety.
    j=brace-1; limit=max(0,brace-2000)
    while j>limit:
        if san[j] in ';{}': return j+1
        j-=1
    # fallback line-ish block
    return limit

def objc_method_id(text:str,hdr:str,pos:int)->str|None:
    nh=norm_header(hdr)
    m=re.search(r'([+-])\s*\([^)]*\)\s*(.+)$',nh)
    if not m: return None
    rest=m.group(2)
    # selector pieces before ':'; if no colon, first identifier
    if ':' in rest:
        pieces=re.findall(r'([A-Za-z_][\w]*)\s*:',rest)
        sel=':'.join(pieces)+(':' if pieces else '')
    else:
        m2=re.match(r'([A-Za-z_][\w]*)',rest); sel=m2.group(1) if m2 else 'method'
    cls=current_objc_class(text,pos)
    return f'objc:{cls}:{m.group(1)}{sel}'

def c_func_id(hdr:str)->str|None:
    nh=norm_header(hdr)
    if not nh or ')' not in nh or '(' not in nh: return None
    low=nh.lower()
    if re.match(r'^(if|for|while|switch|catch|else|do|try|@autoreleasepool)\b',low): return None
    if re.match(r'^(namespace|class|struct|enum|union|typedef)\b',low): return None
    # strip common attributes at tail
    # Find identifiers followed by '('; pick last plausible before brace.
    candidates=list(re.finditer(r'([A-Za-z_~][\w:~]*)\s*\(',nh))
    if not candidates: return None
    name=candidates[-1].group(1)
    if name in {'if','for','while','switch','catch','sizeof','decltype','alignof'}: return None
    # reject macro-ish all caps calls where header begins with macro invocation and no return type
    return f'c:{name}'

def classify(path:str,symbol_id:str,header:str)->str:
    blob=(path+' '+symbol_id+' '+header).lower()
    if path.lower().startswith('autoclick/'): return 'auto_click'
    if path.lower().startswith('fpsdisplay/'): return 'fps'
    if path.lower().startswith('patchnonjb/'): return 'patch_nonjb'
    if path.lower().startswith('helper/'): return 'helper_il2cpp'
    for mod,pat in MODULE_RULES:
        if re.search(pat,blob,re.I): return mod
    if path.lower().startswith('ui/'): return 'ui_menu'
    if path.lower().startswith('core/'): return 'core_runtime'
    return 'other'

def extract_segments(path:Path, rel:str):
    raw=path.read_bytes()
    try: text=raw.decode('utf-8')
    except UnicodeDecodeError: text=raw.decode('utf-8','replace')
    san=sanitize(text); pairs=brace_pairs(san)
    funcs=[]; occupied_until=-1; occurrence={}
    opens=sorted(pairs)
    for b in opens:
        if b<=occupied_until: continue
        hs=header_start(san,b)
        hdr=text[hs:b]
        # trim leading preprocessor and implementation noise to last few lines
        # ObjC method first
        sid=objc_method_id(text,hdr,b)
        if sid is None:
            sid=c_func_id(hdr)
        if sid is None: continue
        e=pairs[b]+1
        # Include signature from first non-space after structural boundary
        st=hs
        while st<b and text[st].isspace(): st+=1
        base=sid
        occurrence[base]=occurrence.get(base,0)+1
        if occurrence[base]>1: sid=f'{base}#{occurrence[base]}'
        funcs.append((st,e,sid,norm_header(text[st:b])))
        occupied_until=e-1
    funcs.sort()
    segments=[]; cur=0; gap_idx=0
    for st,e,sid,hdr in funcs:
        if st>cur:
            gap=text[cur:st]
            if gap:
                segments.append({
                    'id':f'gap:{gap_idx}', 'kind':'gap','module':classify(rel,'gap',gap[:300]),
                    'start_line':line_no(text,cur),'end_line':line_no(text,st),
                    'sha256':sha256_bytes(gap.encode('utf-8'))
                })
                gap_idx+=1
        body=text[st:e]
        segments.append({
            'id':sid,'kind':'function','module':classify(rel,sid,hdr),
            'header':hdr[:500], 'start_line':line_no(text,st),'end_line':line_no(text,e),
            'sha256':sha256_bytes(body.encode('utf-8'))
        })
        cur=e
    if cur<len(text):
        gap=text[cur:]
        segments.append({
            'id':f'gap:{gap_idx}','kind':'gap','module':classify(rel,'gap',gap[:300]),
            'start_line':line_no(text,cur),'end_line':line_no(text,len(text)),
            'sha256':sha256_bytes(gap.encode('utf-8'))
        })
    return sha256_bytes(raw),segments

def iter_protected_files(root:Path):
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(root).as_posix()
        if rel.startswith('tools/protection/'): continue
        if p.name in SKIP_NAMES: continue
        if any(part in {'.git','build','DerivedData','.theos','obj','out'} for part in p.parts): continue
        yield p,rel

def build_manifest(root:Path):
    files={}; modules={}
    for p,rel in iter_protected_files(root):
        raw=p.read_bytes(); rec={'sha256':sha256_bytes(raw),'size':len(raw),'segments':[]}
        if p.suffix.lower() in SOURCE_EXTS:
            _,segs=extract_segments(p,rel); rec['segments']=segs
            for sg in segs:
                modules.setdefault(sg['module'],[]).append(f'{rel}::{sg["id"]}')
        else:
            mod='build_scripts' if p.suffix.lower() in {'.sh','.pl'} or p.name in {'Makefile','control'} else 'assets_binary'
            modules.setdefault(mod,[]).append(rel)
        files[rel]=rec
    return {
      'schema':2,
      'root':'s82',
      'policy':'Everything in this source snapshot is stable and protected. Future edits must explicitly allow only requested segments; all other segments must remain byte-identical.',
      'files':files,
      'modules':{k:sorted(v) for k,v in sorted(modules.items())}
    }

def load_manifest(root:Path):
    p=root/'tools/protection/protected_manifest.json'
    return json.loads(p.read_text(encoding='utf-8'))
