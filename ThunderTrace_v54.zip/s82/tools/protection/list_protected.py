#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from protectlib import load_manifest

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--module')
    ap.add_argument('--file')
    ap.add_argument('--search')
    args=ap.parse_args()
    root=Path(__file__).resolve().parents[2]
    m=load_manifest(root)
    if args.module:
        items=m.get('modules',{}).get(args.module,[])
        print(f'MODULE {args.module}: {len(items)} protected item(s)')
        for x in items: print(x)
        return
    q=(args.search or '').lower()
    for rel,rec in m['files'].items():
        if args.file and args.file not in rel: continue
        for sg in rec.get('segments',[]):
            text=f'{rel}::{sg["id"]} {sg.get("module","")} {sg.get("header","")}'
            if q and q not in text.lower(): continue
            print(f'{rel}::{sg["id"]}\t[{sg.get("module")}]\tL{sg.get("start_line")}-{sg.get("end_line")}\t{sg.get("header","")[:100]}')

if __name__=='__main__': main()
