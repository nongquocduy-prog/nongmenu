#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from protectlib import build_manifest, load_manifest

def main():
    ap=argparse.ArgumentParser(description='Verify protected source baseline. Any unapproved change fails.')
    ap.add_argument('--allow-file',action='append',default=[],help='Relative file path allowed to change completely.')
    ap.add_argument('--allow-segment',action='append',default=[],help='Exact FILE::SEGMENT ID allowed to change.')
    ap.add_argument('--allow-module',action='append',default=[],help='Module allowed to change; use sparingly.')
    ap.add_argument('--json',action='store_true')
    args=ap.parse_args()
    root=Path(__file__).resolve().parents[2]
    base=load_manifest(root); cur=build_manifest(root)
    allow_files=set(args.allow_file)
    allow_segments=set(args.allow_segment)
    allow_modules=set(args.allow_module)
    problems=[]; allowed_changes=[]
    bf=base['files']; cf=cur['files']
    for rel in sorted(set(bf)|set(cf)):
        if rel in allow_files:
            if bf.get(rel,{}).get('sha256')!=cf.get(rel,{}).get('sha256'): allowed_changes.append(f'FILE {rel}')
            continue
        if rel not in bf: problems.append(f'NEW FILE: {rel}'); continue
        if rel not in cf: problems.append(f'MISSING FILE: {rel}'); continue
        if bf[rel]['sha256']==cf[rel]['sha256']: continue
        bsegs={x['id']:x for x in bf[rel].get('segments',[])}
        csegs={x['id']:x for x in cf[rel].get('segments',[])}
        if not bsegs and not csegs:
            problems.append(f'CHANGED FILE: {rel}'); continue
        for sid in sorted(set(bsegs)|set(csegs)):
            key=f'{rel}::{sid}'
            b=bsegs.get(sid); c=csegs.get(sid)
            module=(c or b or {}).get('module','other')
            changed=(b is None or c is None or b.get('sha256')!=c.get('sha256'))
            if not changed: continue
            if key in allow_segments or module in allow_modules:
                allowed_changes.append(f'{key} [{module}]')
            else:
                if b is None: problems.append(f'NEW SEGMENT: {key} [{module}]')
                elif c is None: problems.append(f'MISSING SEGMENT: {key} [{module}]')
                else: problems.append(f'CHANGED SEGMENT: {key} [{module}] lines {b.get("start_line")}-{b.get("end_line")}')
    result={'ok':not problems,'problems':problems,'allowed_changes':allowed_changes}
    if args.json:
        print(json.dumps(result,ensure_ascii=False,indent=2))
    else:
        print('=== ÔNG NÔNG PROTECTED SOURCE CHECK ===')
        if allowed_changes:
            print('\nApproved changes:')
            for x in allowed_changes: print('  ALLOW',x)
        if problems:
            print('\nBLOCKED changes:')
            for x in problems[:200]: print('  FAIL ',x)
            if len(problems)>200: print(f'  ... and {len(problems)-200} more')
            print(f'\nRESULT: FAIL ({len(problems)} protected change(s))')
        else:
            print('\nRESULT: PASS - all protected areas unchanged')
    return 0 if not problems else 2

if __name__=='__main__': raise SystemExit(main())
