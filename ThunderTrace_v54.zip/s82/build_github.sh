#!/bin/sh
set -eu

cd "$(dirname "$0")"

if [ -z "${THEOS:-}" ]; then
    if [ -f /var/mobile/theos/makefiles/common.mk ]; then
        THEOS=/var/mobile/theos
    else
        THEOS="$HOME/theos"
    fi
    export THEOS
fi

if [ ! -f "$THEOS/makefiles/common.mk" ]; then
    echo "[ERROR] Khong tim thay Theos tai: $THEOS"
    exit 1
fi

rm -rf .theos Ongnongos.dylib Ongnongios1.dylib
make clean >/dev/null 2>&1 || true

if [ -n "${GITHUB_RUN_ID:-}" ] && [ -z "${ONGNONG_BUILD_CHANNEL:-}" ]; then
    RUN_ATTEMPT="${GITHUB_RUN_ATTEMPT:-1}"
    case "$GITHUB_RUN_ID:$RUN_ATTEMPT" in
        *[!0-9:]*|'':*) echo "[ERROR] Invalid GitHub run identifier"; exit 1 ;;
    esac
    ONGNONG_BUILD_CHANNEL="ongnong_GH${GITHUB_RUN_ID}_A${RUN_ATTEMPT}"
    export ONGNONG_BUILD_CHANNEL
fi

BUILD_ARGS="FINALPACKAGE=1"

if [ -n "${ONGNONG_BUILD_CHANNEL:-}" ]; then
    echo "[BUILD] channel=$ONGNONG_BUILD_CHANNEL"
    BUILD_ARGS="$BUILD_ARGS ONGNONG_BUILD_CHANNEL=$ONGNONG_BUILD_CHANNEL"
fi

if [ -n "${THEOS_TARGET_OVERRIDE:-}" ]; then
    echo "[BUILD] target=$THEOS_TARGET_OVERRIDE"
    BUILD_ARGS="$BUILD_ARGS TARGET=$THEOS_TARGET_OVERRIDE"
fi

make $BUILD_ARGS

FOUND=$(find .theos -type f -name 'Ongnongos.dylib' -print | head -n 1 || true)
if [ -z "$FOUND" ] || [ ! -f "$FOUND" ]; then
    echo "[ERROR] Build xong nhung khong tim thay Ongnongos.dylib"
    find .theos -maxdepth 5 -type f -print 2>/dev/null || true
    exit 1
fi

echo "[FOUND] $FOUND"
ls -lh "$FOUND"

if command -v strip >/dev/null 2>&1; then
    strip -S -x "$FOUND" 2>/dev/null || true
fi

sh ./vfy.sh "$FOUND"

if command -v ldid >/dev/null 2>&1; then
    ldid -S "$FOUND" 2>/dev/null || true
fi

cp -f "$FOUND" ./Ongnongios1.dylib
cp -f ./Ongnongios1.dylib ./Ongnongos.dylib

echo "[OUTPUT] $(pwd)/Ongnongios1.dylib"
ls -lh ./Ongnongios1.dylib
echo "[VERIFY_COMPAT] $(pwd)/Ongnongos.dylib"
ls -lh ./Ongnongos.dylib
file ./Ongnongios1.dylib || true
