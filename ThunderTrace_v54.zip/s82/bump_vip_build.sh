#!/bin/sh
set -e
cd "$(dirname "$0")" || exit 1
CUR=$(sed -n 's/^ONGNONG_BUILD_CHANNEL[[:space:]]*=[[:space:]]*ongnong_vip_dark\([0-9][0-9]*\).*/\1/p' Makefile | tail -n 1)
[ -n "$CUR" ] || CUR=0
NEXT=$((CUR + 1))
CHANNEL="ongnong_vip_dark${NEXT}"
if grep -q '^ONGNONG_BUILD_CHANNEL[[:space:]]*=' Makefile; then
    sed -i.bak "s/^ONGNONG_BUILD_CHANNEL[[:space:]]*=.*/ONGNONG_BUILD_CHANNEL = ${CHANNEL}/" Makefile
    rm -f Makefile.bak
else
    printf '\nONGNONG_BUILD_CHANNEL = %s\n' "$CHANNEL" >> Makefile
fi
rand64() {
    od -An -N8 -tx8 /dev/urandom |
        tr -d ' \n'
}
A=$(rand64)
B=$(rand64)
C=$(rand64)
D=$(rand64)
E=$(rand64)
TMP="Core/R7f8.h.tmp"
{
    printf '%s\n' '#pragma once'
    printf '%s\n' '#include <stdint.h>'
    printf '#define R7F8_A UINT64_C(0x%s)\n' "$A"
    printf '#define R7F8_B UINT64_C(0x%s)\n' "$B"
    printf '#define R7F8_C UINT64_C(0x%s)\n' "$C"
    printf '#define R7F8_D UINT64_C(0x%s)\n' "$D"
    printf '#define R7F8_E UINT64_C(0x%s)\n' "$E"
} > "$TMP"
mv "$TMP" Core/R7f8.h
echo "[VIP BUILD] ${CHANNEL}"
