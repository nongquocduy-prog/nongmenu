#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface X7q4M : NSObject

+ (NSInteger)x7q0:(NSInteger)pointId n2v5:(CGPoint)point k9m1:(UITouchPhase)phase;

+ (NSInteger)c4d8;

@end
