#import "../Core/OngnongSecureStrings.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "PTFakeMetaTouch.h"
#import "../Core/zx8f1a_gate.h"

#define ONG_AC_MAX_POINTS 20

#define ONG_AC_VISUAL_SCALE 0.55

@interface V2k8P : UIView
@property(nonatomic, assign) NSInteger index;
@property(nonatomic, strong) UILabel *label;
@end

@interface Z5e8402e1b3 : NSObject <UIGestureRecognizerDelegate>
@property(nonatomic, strong) UIWindow *window;
@property(nonatomic, strong) UIView *u2m7c4;
@property(nonatomic, strong) UIButton *r9x1p6;
@property(nonatomic, strong) UIView *v3d8k5;
@property(nonatomic, strong) UIView *a7m2q9;
@property(nonatomic, strong) UIButton *c4x6n1;
@property(nonatomic, strong) UIButton *p8v3d7;
@property(nonatomic, strong) UIButton *h5q9m2;
@property(nonatomic, strong) UILabel *k1c7x4;
@property(nonatomic, strong) UILabel *t6p2v8;
@property(nonatomic, strong) NSMutableArray<UIView *> *d3m9q5;
@property(nonatomic, strong) NSMutableArray<UIView *> *y7x1c6;
@property(nonatomic, strong) NSMutableArray<UIView *> *n4p8k2;
@property(nonatomic, strong) UIScrollView *b9v3m7;
@property(nonatomic, strong) NSMutableArray<NSValue *> *q2d6x1;
@property(nonatomic, strong) NSMutableArray<V2k8P *> *f8m4p9;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, assign) BOOL z26f020afac;
@property(nonatomic, assign) BOOL c5v1n7;
@property(nonatomic, assign) BOOL r3q8d2;
@property(nonatomic, assign) BOOL u9k4x6;
@property(nonatomic, assign) NSInteger a2m7p5;
@property(nonatomic, assign) NSTimeInterval v6c3q8;

+ (void)z6p1c8;
+ (void)d7x2p6:(BOOL)visible;
+ (void)m4q8v1;
+ (BOOL)c3n9k5;
- (void)q8v2c5;
- (void)b6q3m7:(CGPoint)p;
- (void)t2c9p5;
- (void)p3x9q4;
- (void)k7m2v6;
- (void)e4n8d1;
- (void)q6d1r9;
- (void)x3p7n4;
- (void)m8c2v6;
- (void)r2v6p5;
- (void)f4q9k1;
- (void)d7x3m8;
- (void)u8v1x4;
- (void)c3m8q7;
- (void)r8d1c5;
- (void)n2c6v9:(UIButton *)sender;
- (void)f5q1m7:(NSInteger)idx;
- (void)v3n9c6;
- (void)e7m1q8;
- (void)j4p6d2:(UIButton *)sender;
- (void)w9c3x7:(UIButton *)sender;
- (BOOL)d7p3k8:(UIView *)view;
- (void)v4p7m2;
- (void)h9x3n6:(NSInteger)i;
- (void)a2q8k5:(CGPoint)p;
- (void)d6m1v9;
- (void)c7p4x2:(UIButton *)sender;
- (void)zAutoClickPopupClose;
@end

static Z5e8402e1b3 *gONGAutoClick = nil;
static BOOL gONGAutoClickRequestedVisible = NO;

@interface L9d3W : UIWindow
@end

@implementation L9d3W
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];

    if (!hit) return nil;
    if (gONGAutoClick) {
        if (hit == self || hit == gONGAutoClick.u2m7c4) return nil;
    }
    return hit;
}
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {

    if (gONGAutoClick && gONGAutoClick.c5v1n7) return YES;
    if (!gONGAutoClick || !gONGAutoClick.u2m7c4) return NO;

    CGPoint rootPoint = [gONGAutoClick.u2m7c4 convertPoint:point fromView:self];
    UIView *hit = [gONGAutoClick.u2m7c4 hitTest:rootPoint withEvent:event];
    return (hit && hit != gONGAutoClick.u2m7c4);
}
@end

@interface C6m1R : UIView
@end

@implementation C6m1R
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    Z5e8402e1b3 *m = gONGAutoClick;
    if (m && m.c5v1n7) return self;
    UIView *hit = [super hitTest:point withEvent:event];

    if (!hit || hit == self) return nil;
    return hit;
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    Z5e8402e1b3 *m = gONGAutoClick;
    if (!m || !m.c5v1n7) return;
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView:self];
    m.c5v1n7 = NO;
    [m b6q3m7:p];
}
@end

@implementation V2k8P
- (instancetype)initWithIndex:(NSInteger)idx point:(CGPoint)p {
    self = [super initWithFrame:CGRectMake(p.x - 22, p.y - 22, 44, 44)];
    if (self) {
        _index = idx;
        self.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.78];
        self.layer.cornerRadius = 22;
        self.layer.borderWidth = 3;
        self.layer.borderColor = UIColor.whiteColor.CGColor;
        self.clipsToBounds = YES;
        _label = [[UILabel alloc] initWithFrame:self.bounds];
        _label.text = [NSString stringWithFormat:qsec_s_0086(), (long)idx + 1];
        _label.textColor = UIColor.whiteColor;
        _label.font = [UIFont boldSystemFontOfSize:20];
        _label.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_label];
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(n5q8r3:)];
        [self addGestureRecognizer:pan];
    }
    return self;
}
- (void)n5q8r3:(UIPanGestureRecognizer *)pan {
    Z5e8402e1b3 *m = gONGAutoClick;
    if (!m || m.z26f020afac) return;
    CGPoint t = [pan translationInView:m.u2m7c4];
    CGPoint c = self.center;
    c.x += t.x;
    c.y += t.y;
    CGFloat w = m.u2m7c4.bounds.size.width;
    CGFloat h = m.u2m7c4.bounds.size.height;
    c.x = MAX(22, MIN(w - 22, c.x));
    c.y = MAX(22, MIN(h - 22, c.y));
    self.center = c;
    [pan setTranslation:CGPointZero inView:m.u2m7c4];
    if (self.index >= 0 && self.index < m.q2d6x1.count) {
        m.q2d6x1[self.index] = [NSValue valueWithCGPoint:c];
    }
}
@end

static UIWindow *ONGBestHostWindow(void) {
    UIWindow *best = nil;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            UIWindowScene *ws = (UIWindowScene *)scene;
            for (UIWindow *w in ws.windows) {
                if (w.hidden || w.alpha <= 0.01) continue;
                if ([w isKindOfClass:L9d3W.class]) continue;
                if (w.windowLevel != UIWindowLevelNormal) continue;
                if (w.isKeyWindow) return w;
                if (!best) best = w;
            }
        }
    }
    if (!best) {
        for (UIWindow *w in UIApplication.sharedApplication.windows) {
            if (w.hidden || w.alpha <= 0.01) continue;
            if ([w isKindOfClass:L9d3W.class]) continue;
            if (w.windowLevel != UIWindowLevelNormal) continue;
            if (w.isKeyWindow) return w;
            if (!best) best = w;
        }
    }
    if (!best) best = UIApplication.sharedApplication.keyWindow;
    return best;
}

@implementation Z5e8402e1b3

+ (void)z6p1c8 {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gONGAutoClick) return;
        gONGAutoClick = [Z5e8402e1b3 new];
        [gONGAutoClick q8v2c5];
    });
}

+ (BOOL)c3n9k5 {
    return Ongnong::Zx8fAutoClickAllowed() && gONGAutoClickRequestedVisible;
}

+ (void)d7x2p6:(BOOL)visible {
    if (visible && !Ongnong::Zx8fAutoClickAllowed()) visible = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        gONGAutoClickRequestedVisible = visible;
        if (!gONGAutoClick) {
            gONGAutoClick = [Z5e8402e1b3 new];
            [gONGAutoClick q8v2c5];
        }
        if (!gONGAutoClick || !gONGAutoClick.u2m7c4) return;

        gONGAutoClick.u2m7c4.hidden = !visible;
        if (visible) {
            [gONGAutoClick d7x3m8];
        } else {
            [gONGAutoClick p3x9q4];
            if (gONGAutoClick.v3d8k5) gONGAutoClick.v3d8k5.hidden = YES;
            if (gONGAutoClick.a7m2q9) gONGAutoClick.a7m2q9.hidden = YES;
            for (UIView *point in gONGAutoClick.f8m4p9) point.hidden = YES;
        }
    });
}

+ (void)m4q8v1 {
    [self d7x2p6:!gONGAutoClickRequestedVisible];
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _q2d6x1 = [NSMutableArray array];
        _f8m4p9 = [NSMutableArray array];
        _d3m9q5 = [NSMutableArray array];
        _y7x1c6 = [NSMutableArray array];
        _n4p8k2 = [NSMutableArray array];
        _v6c3q8 = 0.25;
        _a2m7p5 = 0;
    }
    return self;
}

- (void)q8v2c5 {

    UIWindow *host = ONGBestHostWindow();
    if (!host) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self q8v2c5];
        });
        return;
    }

    self.window = host;
    CGRect screen = host.bounds;

    self.u2m7c4 = [[C6m1R alloc] initWithFrame:screen];
    self.u2m7c4.backgroundColor = UIColor.clearColor;
    self.u2m7c4.userInteractionEnabled = YES;
    self.u2m7c4.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

    [host addSubview:self.u2m7c4];
    [host bringSubviewToFront:self.u2m7c4];

    [self u3k7p5];
    [self c4v8n1];
    self.v3d8k5.hidden = YES;
    self.u2m7c4.hidden = !gONGAutoClickRequestedVisible;
    self.a7m2q9.hidden = !gONGAutoClickRequestedVisible;
    if (gONGAutoClickRequestedVisible) {
        [self.u2m7c4 bringSubviewToFront:self.a7m2q9];
    }
}

- (UIButton *)button:(NSString *)title frame:(CGRect)frame font:(CGFloat)font {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.frame = frame;
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont boldSystemFontOfSize:font];
    b.titleLabel.adjustsFontSizeToFitWidth = YES;
    b.titleLabel.minimumScaleFactor = 0.55;
    b.titleLabel.numberOfLines = 1;
    b.backgroundColor = [[UIColor darkGrayColor] colorWithAlphaComponent:0.9];
    b.layer.cornerRadius = MIN(frame.size.width, frame.size.height) / 2.0;
    b.clipsToBounds = YES;

    [b addTarget:self action:@selector(c7p4x2:) forControlEvents:UIControlEventTouchDown];
    return b;
}

- (void)d6m1v9 {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (@available(iOS 10.0, *)) {
            UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
            [gen prepare];
            [gen impactOccurred];
        }
    });
}

- (void)c7p4x2:(UIButton *)sender {
    [self d6m1v9];
}

- (UILabel *)label:(NSString *)text frame:(CGRect)frame font:(CGFloat)font color:(UIColor *)color align:(NSTextAlignment)align {
    UILabel *l = [[UILabel alloc] initWithFrame:frame];
    l.text = text;
    l.font = [UIFont boldSystemFontOfSize:font];
    l.textColor = color;
    l.textAlignment = align;
    l.adjustsFontSizeToFitWidth = YES;
    return l;
}

- (void)r4m9x1 {

    return;
    self.r9x1p6 = [self button:qsec_s_0098() frame:CGRectMake(18, 190, 58, 58) font:20];
    self.r9x1p6.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.75];
    self.r9x1p6.layer.borderWidth = 3;
    self.r9x1p6.layer.borderColor = UIColor.systemBlueColor.CGColor;
    [self.r9x1p6 addTarget:self action:@selector(q6d1r9) forControlEvents:UIControlEventTouchUpInside];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(y8d4r2:)];
    pan.cancelsTouchesInView = NO;
    [self.r9x1p6 addGestureRecognizer:pan];
    [self.u2m7c4 addSubview:self.r9x1p6];
}

- (BOOL)d7p3k8:(UIView *)view {
    UIView *v = view;
    while (v) {
        if ([v isKindOfClass:UIControl.class]) return YES;
        v = v.superview;
    }
    return NO;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {

    if (gestureRecognizer.view == self.a7m2q9) {
        return YES;
    }

    if ([self d7p3k8:touch.view]) return NO;
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {

    if (gestureRecognizer.view == self.a7m2q9) return YES;
    if (otherGestureRecognizer.view == self.a7m2q9) return YES;
    return NO;
}

- (void)n2c6v9:(UIButton *)sender {
    NSInteger idx = sender.tag - 100;
    [self f5q1m7:idx];
}

- (void)f5q1m7:(NSInteger)idx {
    for (UIView *v in self.v3d8k5.subviews) {
        if ([v isKindOfClass:UIButton.class] && v.tag >= 100 && v.tag <= 102) {
            UIButton *b = (UIButton *)v;
            b.backgroundColor = (b.tag == 100 + idx) ? [UIColor colorWithRed:0.35 green:0.65 blue:1 alpha:1] : [UIColor colorWithWhite:0.82 alpha:1];
        }
    }
    for (UIView *v in self.d3m9q5) v.hidden = (idx != 0);
    for (UIView *v in self.y7x1c6) v.hidden = (idx != 1);
    for (UIView *v in self.n4p8k2) v.hidden = (idx != 2);

    if (idx == 0) {
        self.k1c7x4.text = self.z26f020afac ? qsec_s_0099() : qsec_s_0100();
        self.k1c7x4.textColor = self.z26f020afac ? UIColor.greenColor : UIColor.redColor;
    } else if (idx == 1) {
        self.k1c7x4.text = qsec_s_0101();
        self.k1c7x4.textColor = UIColor.systemBlueColor;
        [self e7m1q8];
    } else {
        self.k1c7x4.text = [NSString stringWithFormat:qsec_s_0102(), self.v6c3q8, self.r3q8d2 ? qsec_s_0103() : qsec_s_0104()];
        self.k1c7x4.textColor = UIColor.blackColor;
    }
}

- (void)y8d4r2:(UIPanGestureRecognizer *)pan {
    CGPoint t = [pan translationInView:self.u2m7c4];
    CGPoint c = self.r9x1p6.center;
    c.x += t.x;
    c.y += t.y;
    c.x = MAX(30, MIN(self.u2m7c4.bounds.size.width - 30, c.x));
    c.y = MAX(30, MIN(self.u2m7c4.bounds.size.height - 30, c.y));
    self.r9x1p6.center = c;
    [pan setTranslation:CGPointZero inView:self.u2m7c4];
}

- (void)u3k7p5 {

    self.a7m2q9 = [[UIView alloc] initWithFrame:CGRectMake(120, 260, 135, 118)];
    self.a7m2q9.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.78];
    self.a7m2q9.layer.cornerRadius = 22;
    self.a7m2q9.clipsToBounds = YES;
    self.a7m2q9.hidden = NO;

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a9m2x6:)];
    pan.cancelsTouchesInView = NO;
    pan.delegate = self;
    [self.a7m2q9 addGestureRecognizer:pan];

    UIButton *clear = [self button:qsec_s_0105() frame:CGRectMake(11, 43, 38, 38) font:21];
    [clear addTarget:self action:@selector(t2c9p5) forControlEvents:UIControlEventTouchUpInside];
    [self.a7m2q9 addSubview:clear];

    UIButton *add = [self button:qsec_s_0106() frame:CGRectMake(86, 43, 38, 38) font:24];
    [add addTarget:self action:@selector(u8v1x4) forControlEvents:UIControlEventTouchUpInside];
    [self.a7m2q9 addSubview:add];

    self.c4x6n1 = [self button:qsec_s_0107() frame:CGRectMake(49, 38, 38, 38) font:13];
    self.c4x6n1.layer.borderWidth = 3;
    [self.c4x6n1 addTarget:self action:@selector(e4n8d1) forControlEvents:UIControlEventTouchUpInside];
    UILongPressGestureRecognizer *lp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(y5p2d9:)];
    lp.minimumPressDuration = 0.5;
    lp.cancelsTouchesInView = NO;
    [self.c4x6n1 addGestureRecognizer:lp];
    [self.a7m2q9 addSubview:self.c4x6n1];

    self.p8v3d7 = [self button:qsec_s_0104() frame:CGRectMake(38, 9, 60, 26) font:11];
    [self.p8v3d7 addTarget:self action:@selector(c3m8q7) forControlEvents:UIControlEventTouchUpInside];
    [self.a7m2q9 addSubview:self.p8v3d7];

    UIButton *close = [UIButton buttonWithType:UIButtonTypeCustom];
    close.frame = CGRectMake(self.a7m2q9.bounds.size.width - 22.0, 3.0, 19.0, 19.0);
    [close setTitle:@"×" forState:UIControlStateNormal];
    [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    close.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.30];
    close.layer.cornerRadius = 9.5;
    close.layer.borderWidth = 0.7;
    close.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [close addTarget:self action:@selector(zAutoClickPopupClose) forControlEvents:UIControlEventTouchUpInside];
    [self.a7m2q9 addSubview:close];

    UIButton *menu = [self button:qsec_s_0108() frame:CGRectMake(38, 84, 60, 24) font:12];
    [menu addTarget:self action:@selector(x3p7n4) forControlEvents:UIControlEventTouchUpInside];
    [self.a7m2q9 addSubview:menu];

    [self.u2m7c4 addSubview:self.a7m2q9];
    [self r8d1c5];
    [self f4q9k1];
}

- (void)zAutoClickPopupClose {
    gONGAutoClickRequestedVisible = NO;
    [self p3x9q4];
    if (self.v3d8k5) self.v3d8k5.hidden = YES;
    if (self.a7m2q9) self.a7m2q9.hidden = YES;
    if (self.u2m7c4) self.u2m7c4.hidden = YES;
    for (UIView *point in self.f8m4p9) point.hidden = YES;
}

- (void)a9m2x6:(UIPanGestureRecognizer *)pan {
    CGPoint t = [pan translationInView:self.u2m7c4];
    CGPoint c = self.a7m2q9.center;
    c.x += t.x;
    c.y += t.y;
    c.x = MAX(40, MIN(self.u2m7c4.bounds.size.width - 40, c.x));
    c.y = MAX(40, MIN(self.u2m7c4.bounds.size.height - 40, c.y));
    self.a7m2q9.center = c;
    [pan setTranslation:CGPointZero inView:self.u2m7c4];
}

- (void)c4v8n1 {
    CGFloat sw = self.u2m7c4.bounds.size.width;
    CGFloat sh = self.u2m7c4.bounds.size.height;

    CGFloat w = MIN(sw - 28, 270);
    CGFloat h = MIN(sh - 70, 315);
    CGFloat x = MAX(8, (sw - w) / 2.0);
    CGFloat y = MAX(28, (sh - h) / 2.0 - 10);

    self.v3d8k5 = [[UIView alloc] initWithFrame:CGRectMake(x, y, w, h)];
    self.v3d8k5.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.95];
    self.v3d8k5.layer.cornerRadius = 7;
    self.v3d8k5.layer.borderWidth = 1.2;
    self.v3d8k5.layer.borderColor = UIColor.grayColor.CGColor;
    self.v3d8k5.clipsToBounds = YES;

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(k2v8m5:)];
    pan.cancelsTouchesInView = NO;
    pan.delegate = self;
    [self.v3d8k5 addGestureRecognizer:pan];

    UILabel *title = [self label:qsec_s_0109() frame:CGRectMake(8, 3, w - 44, 28) font:14 color:UIColor.blackColor align:NSTextAlignmentLeft];
    [self.v3d8k5 addSubview:title];

    UIButton *close = [self button:qsec_s_0105() frame:CGRectMake(w - 37, 4, 30, 30) font:16];
    close.backgroundColor = [UIColor colorWithRed:0.55 green:0.74 blue:1 alpha:1];
    [close setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    [close addTarget:self action:@selector(m8c2v6) forControlEvents:UIControlEventTouchUpInside];
    [self.v3d8k5 addSubview:close];

    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 36, w, 1)];
    line.backgroundColor = UIColor.lightGrayColor;
    [self.v3d8k5 addSubview:line];

    NSArray *tabs = @[qsec_s_0110(), qsec_s_0111(), qsec_s_0112()];
    CGFloat tabY = 44;
    CGFloat tabGap = 5;
    CGFloat tabW = (w - 20 - tabGap * 2) / 3.0;
    for (NSInteger i = 0; i < tabs.count; i++) {
        UIButton *tab = [self button:tabs[i] frame:CGRectMake(10 + i * (tabW + tabGap), tabY, tabW, 29) font:11];
        tab.backgroundColor = i == 0 ? [UIColor colorWithRed:0.35 green:0.65 blue:1 alpha:1] : [UIColor colorWithWhite:0.82 alpha:1];
        [tab setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
        tab.layer.cornerRadius = 6;
        tab.tag = 100 + i;
        [tab addTarget:self action:@selector(n2c6v9:) forControlEvents:UIControlEventTouchUpInside];
        [self.v3d8k5 addSubview:tab];
    }

    CGFloat left = 12;
    CGFloat bw = w - left * 2;
    self.k1c7x4 = [self label:qsec_s_0100() frame:CGRectMake(left, 82, bw, 20) font:12 color:UIColor.redColor align:NSTextAlignmentLeft];
    self.k1c7x4.adjustsFontSizeToFitWidth = YES;
    [self.v3d8k5 addSubview:self.k1c7x4];

    UIButton *showJoy = [self button:qsec_s_0113() frame:CGRectMake(left, 110, bw, 30) font:12];
    self.h5q9m2 = showJoy;
    showJoy.backgroundColor = [UIColor colorWithRed:0.55 green:0.74 blue:1 alpha:1];
    [showJoy setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    [showJoy addTarget:self action:@selector(r2v6p5) forControlEvents:UIControlEventTouchUpInside];
    [self.v3d8k5 addSubview:showJoy];
    [self.d3m9q5 addObject:showJoy];

    UIButton *add = [self button:qsec_s_0114() frame:CGRectMake(left, 148, bw, 30) font:12];
    add.backgroundColor = [UIColor colorWithRed:0.25 green:0.7 blue:0.35 alpha:1];
    [add addTarget:self action:@selector(u8v1x4) forControlEvents:UIControlEventTouchUpInside];
    [self.v3d8k5 addSubview:add];
    [self.d3m9q5 addObject:add];

    UIButton *mode = [self button:qsec_s_0115() frame:CGRectMake(left, 186, bw, 30) font:11];
    mode.backgroundColor = [UIColor colorWithRed:0.28 green:0.28 blue:0.28 alpha:1];
    [mode addTarget:self action:@selector(c3m8q7) forControlEvents:UIControlEventTouchUpInside];
    [self.v3d8k5 addSubview:mode];
    [self.d3m9q5 addObject:mode];

    self.t6p2v8 = [self label:qsec_s_0116() frame:CGRectMake(left, 226, bw, 18) font:12 color:UIColor.blackColor align:NSTextAlignmentLeft];
    [self.v3d8k5 addSubview:self.t6p2v8];
    [self.d3m9q5 addObject:self.t6p2v8];

    UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(left, 246, bw, 24)];
    slider.minimumValue = 0.05;
    slider.maximumValue = 5.0;
    slider.value = self.v6c3q8;
    [slider addTarget:self action:@selector(a9k4n1:) forControlEvents:UIControlEventValueChanged];
    [self.v3d8k5 addSubview:slider];
    [self.d3m9q5 addObject:slider];

    UIButton *clear = [self button:qsec_s_0117() frame:CGRectMake(left, 276, bw, 30) font:12];
    clear.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.78];
    [clear addTarget:self action:@selector(t2c9p5) forControlEvents:UIControlEventTouchUpInside];
    [self.v3d8k5 addSubview:clear];
    [self.d3m9q5 addObject:clear];

    UIButton *saveProfile = [self button:qsec_s_0118() frame:CGRectMake(left, 110, bw, 31) font:12];
    saveProfile.backgroundColor = [UIColor colorWithRed:0.55 green:0.74 blue:1 alpha:1];
    [saveProfile setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    [saveProfile addTarget:self action:@selector(v3n9c6) forControlEvents:UIControlEventTouchUpInside];
    saveProfile.hidden = YES;
    [self.v3d8k5 addSubview:saveProfile];
    [self.y7x1c6 addObject:saveProfile];

    UILabel *savedTitle = [self label:qsec_s_0119() frame:CGRectMake(left, 150, bw, 20) font:12 color:UIColor.greenColor align:NSTextAlignmentLeft];
    savedTitle.hidden = YES;
    [self.v3d8k5 addSubview:savedTitle];
    [self.y7x1c6 addObject:savedTitle];

    self.b9v3m7 = [[UIScrollView alloc] initWithFrame:CGRectMake(left, 174, bw, h - 184)];
    self.b9v3m7.hidden = YES;
    self.b9v3m7.backgroundColor = UIColor.clearColor;
    [self.v3d8k5 addSubview:self.b9v3m7];
    [self.y7x1c6 addObject:self.b9v3m7];

    UILabel *settingsInfo = [self label:qsec_s_0120() frame:CGRectMake(left, 110, bw, 86) font:12 color:UIColor.blackColor align:NSTextAlignmentLeft];
    settingsInfo.numberOfLines = 0;
    settingsInfo.hidden = YES;
    [self.v3d8k5 addSubview:settingsInfo];
    [self.n4p8k2 addObject:settingsInfo];

    [self.u2m7c4 addSubview:self.v3d8k5];
}

- (NSMutableArray *)h6q3d9 {
    NSArray *arr = [[NSUserDefaults standardUserDefaults] objectForKey:qsec_s_0121()];
    if ([arr isKindOfClass:NSArray.class]) return [arr mutableCopy];
    return [NSMutableArray array];
}

- (void)t1p7m4:(NSArray *)profiles {
    [[NSUserDefaults standardUserDefaults] setObject:profiles forKey:qsec_s_0121()];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSArray *)b8x2k5 {
    NSMutableArray *arr = [NSMutableArray array];
    for (NSValue *v in self.q2d6x1) {
        CGPoint p = [v CGPointValue];
        [arr addObject:@{qsec_s_0122(): @(p.x), qsec_s_0123(): @(p.y)}];
    }
    return arr;
}

- (void)v3n9c6 {
    if (self.q2d6x1.count == 0) {
        self.k1c7x4.text = qsec_s_0124();
        self.k1c7x4.textColor = UIColor.orangeColor;
        return;
    }

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:qsec_s_0125() message:qsec_s_0126() preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) {
        tf.placeholder = qsec_s_0127();
        tf.text = [NSString stringWithFormat:qsec_s_0128(), (unsigned long)([self h6q3d9].count + 1)];
    }];
    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0089() style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0088() style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = alert.textFields.firstObject.text.length ? alert.textFields.firstObject.text : qsec_s_0129();
        NSMutableArray *profiles = [self h6q3d9];
        NSDictionary *profile = @{
            qsec_s_0130(): name,
            qsec_s_0131(): [self b8x2k5],
            qsec_s_0132(): @(self.v6c3q8),
            qsec_s_0133(): @(self.r3q8d2),
            qsec_s_0134(): @([[NSDate date] timeIntervalSince1970])
        };
        [profiles addObject:profile];
        [self t1p7m4:profiles];
        self.k1c7x4.text = [NSString stringWithFormat:qsec_s_0135(), name];
        self.k1c7x4.textColor = UIColor.greenColor;
        [self e7m1q8];
    }]];

    UIViewController *vc = self.window.rootViewController;
    if (!vc) vc = UIApplication.sharedApplication.keyWindow.rootViewController;
    [vc presentViewController:alert animated:YES completion:nil];
}

- (void)e7m1q8 {
    if (!self.b9v3m7) return;
    for (UIView *v in self.b9v3m7.subviews) [v removeFromSuperview];

    NSArray *profiles = [self h6q3d9];
    CGFloat w = self.b9v3m7.bounds.size.width;
    if (profiles.count == 0) {
        UILabel *empty = [self label:qsec_s_0136() frame:CGRectMake(0, 0, w, 34) font:18 color:UIColor.grayColor align:NSTextAlignmentLeft];
        [self.b9v3m7 addSubview:empty];
        self.b9v3m7.contentSize = CGSizeMake(w, 40);
        return;
    }

    CGFloat y = 0;
    for (NSInteger i = 0; i < profiles.count; i++) {
        NSDictionary *p = profiles[i];
        NSString *name = [p[qsec_s_0130()] isKindOfClass:NSString.class] ? p[qsec_s_0130()] : qsec_s_0129();
        NSArray *pts = [p[qsec_s_0131()] isKindOfClass:NSArray.class] ? p[qsec_s_0131()] : @[];

        UIView *row = [[UIView alloc] initWithFrame:CGRectMake(0, y, w, 42)];
        row.backgroundColor = [[UIColor colorWithWhite:0.92 alpha:1] colorWithAlphaComponent:0.9];
        row.layer.cornerRadius = 10;

        UILabel *nameLabel = [self label:[NSString stringWithFormat:qsec_s_0137(), name, (unsigned long)pts.count] frame:CGRectMake(8, 6, w - 132, 30) font:12 color:UIColor.blackColor align:NSTextAlignmentLeft];
        [row addSubview:nameLabel];

        UIButton *load = [self button:qsec_s_0138() frame:CGRectMake(w - 116, 7, 52, 28) font:11];
        load.tag = 2000 + i;
        load.backgroundColor = [UIColor colorWithRed:0.25 green:0.65 blue:1 alpha:1];
        [load addTarget:self action:@selector(j4p6d2:) forControlEvents:UIControlEventTouchUpInside];
        [row addSubview:load];

        UIButton *del = [self button:qsec_s_0139() frame:CGRectMake(w - 58, 7, 52, 28) font:11];
        del.tag = 3000 + i;
        del.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.8];
        [del addTarget:self action:@selector(w9c3x7:) forControlEvents:UIControlEventTouchUpInside];
        [row addSubview:del];

        [self.b9v3m7 addSubview:row];
        y += 48;
    }
    self.b9v3m7.contentSize = CGSizeMake(w, y + 10);
}

- (void)j4p6d2:(UIButton *)sender {
    NSInteger idx = sender.tag - 2000;
    NSArray *profiles = [self h6q3d9];
    if (idx < 0 || idx >= profiles.count) return;
    NSDictionary *profile = profiles[idx];
    NSArray *pts = [profile[qsec_s_0131()] isKindOfClass:NSArray.class] ? profile[qsec_s_0131()] : @[];

    [self p3x9q4];
    [self t2c9p5];
    for (NSDictionary *d in pts) {
        CGFloat x = [d[qsec_s_0122()] doubleValue];
        CGFloat y = [d[qsec_s_0123()] doubleValue];
        [self b6q3m7:CGPointMake(x, y)];
    }
    if (profile[qsec_s_0132()]) self.v6c3q8 = [profile[qsec_s_0132()] doubleValue];
    if (profile[qsec_s_0133()]) self.r3q8d2 = [profile[qsec_s_0133()] boolValue];
    [self.p8v3d7 setTitle:(self.r3q8d2 ? qsec_s_0103() : qsec_s_0104()) forState:UIControlStateNormal];
    self.t6p2v8.text = [NSString stringWithFormat:qsec_s_0140(), self.v6c3q8];
    self.k1c7x4.text = [NSString stringWithFormat:qsec_s_0141(), profile[qsec_s_0130()] ?: qsec_s_0129()];
    self.k1c7x4.textColor = UIColor.greenColor;
}

- (void)w9c3x7:(UIButton *)sender {
    NSInteger idx = sender.tag - 3000;
    NSMutableArray *profiles = [self h6q3d9];
    if (idx < 0 || idx >= profiles.count) return;
    [profiles removeObjectAtIndex:idx];
    [self t1p7m4:profiles];
    [self e7m1q8];
    self.k1c7x4.text = qsec_s_0142();
    self.k1c7x4.textColor = UIColor.redColor;
}

- (void)k2v8m5:(UIPanGestureRecognizer *)pan {
    CGPoint t = [pan translationInView:self.u2m7c4];
    CGPoint c = self.v3d8k5.center;
    c.x += t.x;
    c.y += t.y;
    c.x = MAX(80, MIN(self.u2m7c4.bounds.size.width - 80, c.x));
    c.y = MAX(50, MIN(self.u2m7c4.bounds.size.height - 50, c.y));
    self.v3d8k5.center = c;
    [pan setTranslation:CGPointZero inView:self.u2m7c4];
}

- (void)q6d1r9 { self.v3d8k5.hidden ? [self x3p7n4] : [self m8c2v6]; }
- (void)x3p7n4 { self.v3d8k5.hidden = NO; [self.u2m7c4 bringSubviewToFront:self.v3d8k5]; }
- (void)m8c2v6 {
    self.v3d8k5.hidden = YES;

    if (self.a7m2q9 && self.a7m2q9.hidden) {
        [self d7x3m8];
    }
}

- (void)f4q9k1 {
    if (!self.h5q9m2) return;
    BOOL hidden = (!self.a7m2q9 || self.a7m2q9.hidden);
    [self.h5q9m2 setTitle:(hidden ? qsec_s_0143() : qsec_s_0113()) forState:UIControlStateNormal];
}

- (void)d7x3m8 {
    self.u2m7c4.hidden = NO;
    if (!self.a7m2q9) {
        [self u3k7p5];
    }
    if (!self.a7m2q9.superview && self.u2m7c4) {
        [self.u2m7c4 addSubview:self.a7m2q9];
    }
    self.a7m2q9.hidden = NO;
    [self.u2m7c4 bringSubviewToFront:self.a7m2q9];
    if (self.v3d8k5 && !self.v3d8k5.hidden) [self.u2m7c4 bringSubviewToFront:self.v3d8k5];
    [self f4q9k1];
}

- (void)r2v6p5 {
    if (!self.a7m2q9 || !self.a7m2q9.superview) {
        [self d7x3m8];
        return;
    }

    BOOL shouldShow = self.a7m2q9.hidden;
    if (shouldShow) {
        [self d7x3m8];
    } else {
        self.a7m2q9.hidden = YES;
        [self f4q9k1];
        if (self.v3d8k5 && !self.v3d8k5.hidden) [self.u2m7c4 bringSubviewToFront:self.v3d8k5];
    }
}

- (void)a9k4n1:(UISlider *)slider {
    self.v6c3q8 = slider.value;
    self.t6p2v8.text = [NSString stringWithFormat:qsec_s_0140(), self.v6c3q8];
    if (self.z26f020afac) { [self p3x9q4]; [self k7m2v6]; }
}

- (void)c3m8q7 {
    self.r3q8d2 = !self.r3q8d2;
    [self.p8v3d7 setTitle:(self.r3q8d2 ? qsec_s_0103() : qsec_s_0104()) forState:UIControlStateNormal];
}

- (void)y5p2d9:(UILongPressGestureRecognizer *)lp {
    if (lp.state != UIGestureRecognizerStateBegan) return;
    self.u9k4x6 = !self.u9k4x6;
    for (UIView *v in self.a7m2q9.subviews) {
        if (v != self.c4x6n1) v.hidden = self.u9k4x6;
    }
    if (self.u9k4x6) {
        self.a7m2q9.bounds = CGRectMake(0, 0, 50, 50);
        self.a7m2q9.layer.cornerRadius = 25;
        self.c4x6n1.center = CGPointMake(25, 25);
    } else {
        self.a7m2q9.bounds = CGRectMake(0, 0, 135, 118);
        self.a7m2q9.layer.cornerRadius = 22;
        self.c4x6n1.center = CGPointMake(68, 57);
    }
}

- (void)u8v1x4 {
    if (self.q2d6x1.count >= ONG_AC_MAX_POINTS) return;
    self.c5v1n7 = YES;
    self.v3d8k5.hidden = YES;
    self.a7m2q9.hidden = NO;
}

- (void)b6q3m7:(CGPoint)p {
    if (self.q2d6x1.count >= ONG_AC_MAX_POINTS) return;
    NSInteger idx = self.q2d6x1.count;
    [self.q2d6x1 addObject:[NSValue valueWithCGPoint:p]];
    V2k8P *pv = [[V2k8P alloc] initWithIndex:idx point:p];
    [self.u2m7c4 addSubview:pv];
    [self.u2m7c4 bringSubviewToFront:self.a7m2q9];
    [self.u2m7c4 bringSubviewToFront:self.v3d8k5];
    [self.f8m4p9 addObject:pv];
}

- (void)t2c9p5 {
    [self p3x9q4];
    for (UIView *v in self.f8m4p9) [v removeFromSuperview];
    [self.f8m4p9 removeAllObjects];
    [self.q2d6x1 removeAllObjects];
    self.a2m7p5 = 0;
}

- (void)e4n8d1 { self.z26f020afac ? [self p3x9q4] : [self k7m2v6]; }

- (void)k7m2v6 {
    if (self.q2d6x1.count == 0) {
        if (self.k1c7x4) { self.k1c7x4.text = qsec_s_0151(); self.k1c7x4.textColor = UIColor.orangeColor; }
        return;
    }
    self.z26f020afac = YES;
    [self r8d1c5];
    [self.timer invalidate];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:self.v6c3q8 target:self selector:@selector(v4p7m2) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

- (void)p3x9q4 {
    self.z26f020afac = NO;
    [self r8d1c5];
    [self.timer invalidate];
    self.timer = nil;
}

- (void)r8d1c5 {
    [self.c4x6n1 setTitle:(self.z26f020afac ? qsec_s_0153() : qsec_s_0107()) forState:UIControlStateNormal];
    self.c4x6n1.layer.borderColor = (self.z26f020afac ? UIColor.greenColor.CGColor : UIColor.redColor.CGColor);
    if (self.k1c7x4) {
        self.k1c7x4.text = self.z26f020afac ? qsec_s_0099() : qsec_s_0100();
        self.k1c7x4.textColor = self.z26f020afac ? UIColor.greenColor : UIColor.redColor;
    }
}

- (void)v4p7m2 {
    if (!self.z26f020afac || self.q2d6x1.count == 0) return;
    if (self.r3q8d2) {
        for (NSInteger i = 0; i < self.q2d6x1.count; i++) {
            [self a2q8k5:[self.q2d6x1[i] CGPointValue]];
            [self h9x3n6:i];
        }
    } else {
        if (self.a2m7p5 >= self.q2d6x1.count) self.a2m7p5 = 0;
        CGPoint p = [self.q2d6x1[self.a2m7p5] CGPointValue];
        [self a2q8k5:p];
        [self h9x3n6:self.a2m7p5];
        self.a2m7p5++;
        if (self.a2m7p5 >= self.q2d6x1.count) self.a2m7p5 = 0;
    }
}

- (void)h9x3n6:(NSInteger)i {
    if (i < 0 || i >= self.f8m4p9.count) return;
    UIView *v = self.f8m4p9[i];
    UIColor *old = v.backgroundColor;
    v.backgroundColor = [[UIColor greenColor] colorWithAlphaComponent:0.9];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.08 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        v.backgroundColor = old;
    });
}

- (void)a2q8k5:(CGPoint)p {
    static BOOL ongTapBusy = NO;
    if (ongTapBusy) return;
    ongTapBusy = YES;

    BOOL oldInteraction = self.u2m7c4.userInteractionEnabled;
    self.u2m7c4.userInteractionEnabled = NO;

    NSInteger pointId = [X7q4M c4d8];
    [X7q4M x7q0:pointId n2v5:p k9m1:UITouchPhaseBegan];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [X7q4M x7q0:pointId n2v5:p k9m1:UITouchPhaseEnded];

        self.u2m7c4.userInteractionEnabled = oldInteraction;
        ongTapBusy = NO;
    });
}

@end

__attribute__((constructor))
static void Z12cee01d09(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [Z5e8402e1b3 z6p1c8];
    });
}
