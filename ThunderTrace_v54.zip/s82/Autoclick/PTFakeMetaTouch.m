#import "PTFakeMetaTouch.h"
#import "UITouch-KIFAdditions.h"
#import "UIApplication-KIFAdditions.h"
#import "UIEvent+KIFAdditions.h"
#import "../Core/OngnongSecureStrings.h"

static NSMutableArray *touchAry;

static NSString *pt_s0(void) { static const unsigned char q[] = {0x6B,0x3C,0xEA,0x84,0xD6,0x3F,0x00,0x37,0xF6,0xAA,0x85}; return qsec_make(q, sizeof(q), 0x31); }
static NSString *pt_s1(void) { static const unsigned char q[] = {0x18,0x30,0xF7,0xB4,0x90,0x46,0x21,0xE4,0xFE,0x84,0x74,0x5B,0x0A,0xF0,0xCF,0x8D,0x4A,0x20,0x1B,0xC5,0xA2,0x8E}; return qsec_make(q, sizeof(q), 0x4D); }
@implementation X7q4M

+ (void)load{
    KW_ENABLE_CATEGORY(T7A);
    KW_ENABLE_CATEGORY(E4B);
    touchAry = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i<100; i++) {
        UITouch *touch = [[UITouch alloc] initWithJ2a5];
        [touch n8s6:UITouchPhaseEnded];
        [touchAry addObject:touch];
    }
}

+ (BOOL)f6p2:(UIWindow *)window {
    if (!window) return NO;
    if (window.windowLevel > UIWindowLevelNormal + 5) return YES;
    NSString *rootName = NSStringFromClass([window.rootViewController.view class]);
    if ([rootName containsString:pt_s0()]) return YES;
    return NO;
}

+ (UIWindow *)h3w7 {
    UIWindow *mainWindow = nil;

    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            UIWindowScene *ws = (UIWindowScene *)scene;
            if (ws.activationState != UISceneActivationStateForegroundActive &&
                ws.activationState != UISceneActivationStateForegroundInactive) continue;

            for (UIWindow *window in ws.windows) {
                if (!window || window.hidden || window.alpha <= 0.01) continue;
                if ([self f6p2:window]) continue;
                if (window.windowLevel != UIWindowLevelNormal) continue;
                if (window.isKeyWindow) { mainWindow = window; break; }
            }

            if (!mainWindow) {
                for (UIWindow *window in ws.windows) {
                    if (!window || window.hidden || window.alpha <= 0.01) continue;
                    if ([self f6p2:window]) continue;
                    if (window.windowLevel == UIWindowLevelNormal) { mainWindow = window; break; }
                }
            }

            if (mainWindow) break;
        }
    }

    if (!mainWindow) {
        UIWindow *key = [UIApplication sharedApplication].keyWindow;
        if (key && !key.hidden && ![self f6p2:key] && key.windowLevel == UIWindowLevelNormal) {
            mainWindow = key;
        }
    }

    if (!mainWindow) {
        for (UIWindow *window in [UIApplication sharedApplication].windows) {
            if (!window || window.hidden || window.alpha <= 0.01) continue;
            if ([self f6p2:window]) continue;
            if (window.windowLevel == UIWindowLevelNormal) { mainWindow = window; break; }
        }
    }

    return mainWindow;
}

+ (NSInteger)x7q0:(NSInteger)pointId n2v5:(CGPoint)point k9m1:(UITouchPhase)phase{
    if (pointId==0) {
        pointId = [self c4d8];
        if (pointId==0) {
            return 0;
        }
    }
    pointId = pointId - 1;
    UITouch *touch = [touchAry objectAtIndex:pointId];
    if (phase == UITouchPhaseBegan) {
        touch = nil;
        UIWindow *safeWindow = [self h3w7];

        if (!safeWindow) {
            return 0;
        }

        touch = [[UITouch alloc] initWithB3k8:point inWindow:safeWindow];

        CGRect keyboardFrame = CGRectZero;
        if([[[UIApplication sharedApplication].windows lastObject] isKindOfClass:NSClassFromString(pt_s1())] && (CGRectContainsPoint(CGRectMake(0, safeWindow.frame.size.height-keyboardFrame.size.height, safeWindow.frame.size.width, keyboardFrame.size.height), point))) {
            touch = [[UITouch alloc] initWithB3k8:point inWindow:[[UIApplication sharedApplication].windows lastObject]];
        }

        [touchAry replaceObjectAtIndex:pointId withObject:touch];
        [touch m4q1:point];
    }else{
        [touch m4q1:point];
        [touch n8s6:phase];
    }

    UIEvent *event = [self e3v7:touchAry];
    [[UIApplication sharedApplication] sendEvent:event];
    if ((touch.phase==UITouchPhaseBegan)||touch.phase==UITouchPhaseMoved) {
        [touch n8s6:UITouchPhaseStationary];
    }
    return (pointId+1);
}

+ (UIEvent *)e3v7:(NSArray *)touches
{
    UIEvent *event = [[UIApplication sharedApplication] _touchesEvent];
    [event _clearTouches];
    [event q1e7:touches];

    for (UITouch *aTouch in touches) {
        [event _addTouch:aTouch forDelayedDelivery:NO];
    }

    return event;
}

+ (NSInteger)c4d8{
    NSInteger availablePointId=0;
    NSMutableArray *availableIds = [[NSMutableArray alloc]init];
    for (NSInteger i=0; i<touchAry.count-50; i++) {
        UITouch *touch = [touchAry objectAtIndex:i];
        if (touch.phase==UITouchPhaseEnded||touch.phase==UITouchPhaseStationary) {
            [availableIds addObject:@(i+1)];
        }
    }
    availablePointId = availableIds.count==0 ? 0 : [[availableIds objectAtIndex:(arc4random() % availableIds.count)] integerValue];
    return availablePointId;
}
@end
