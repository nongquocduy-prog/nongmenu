#define MAKE_CATEGORIES_LOADABLE(UNIQUE_NAME) @interface L3P_##UNIQUE_NAME : NSObject @end @implementation L3P_##UNIQUE_NAME @end
