#ifndef UIApplication_KIFAdditions_h
#define UIApplication_KIFAdditions_h

#import <UIKit/UIKit.h>

@interface UIApplication (Q7n2A)
- (UIEvent *)_touchesEvent;
@end

#endif
