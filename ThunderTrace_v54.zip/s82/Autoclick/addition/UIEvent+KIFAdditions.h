#import <UIKit/UIKit.h>
#import "FixCategoryBug.h"
QX7_CATEGORY_BUG_H(E4B)

@interface UIEvent (Q7n2P)
- (void)_addTouch:(UITouch *)touch forDelayedDelivery:(BOOL)arg2;
- (void)_clearTouches;
@end

@interface UIEvent (Q7n2)
- (void)q1e7:(NSArray *)touches;
@end
