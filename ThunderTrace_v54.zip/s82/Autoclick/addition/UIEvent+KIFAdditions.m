#import "UIEvent+KIFAdditions.h"
#import "LoadableCategory.h"
#import "IOHIDEvent+KIF.h"

QX7_CATEGORY_BUG_M(E4B)

MAKE_CATEGORIES_LOADABLE(E4B)

@interface P4x8G : NSObject
{
@public
    unsigned int flags;
    unsigned int type;
    unsigned int ignored1;
    float x1;
    float y1;
    float x2;
    float y2;
    unsigned int ignored2[10];
    unsigned int ignored3[7];
    float sizeX;
    float sizeY;
    float x3;
    float y3;
    unsigned int ignored4[3];
}
@end

@implementation P4x8G
@end

typedef struct __GSEvent * GSEventRef;

@interface UIEvent (Q7n2M)
- (void)_setGSEvent:(GSEventRef)event;
- (void)_setHIDEvent:(IOHIDEventRef)event;
- (void)_setTimestamp:(NSTimeInterval)timestemp;
@end

@implementation UIEvent (Q7n2)

- (void)q1e7:(NSArray *)touches
{
    NSOperatingSystemVersion iOS8 = {8, 0, 0};
    if ([NSProcessInfo instancesRespondToSelector:@selector(isOperatingSystemAtLeastVersion:)]
        && [[NSProcessInfo new] isOperatingSystemAtLeastVersion:iOS8]) {
        [self w8m3:touches];
    } else {
        [self r5t2:touches];
    }
}

- (void)r5t2:(NSArray *)touches
{
    UITouch *touch = touches[0];
    CGPoint location = [touch locationInView:touch.window];
    P4x8G *gsEventProxy = [[P4x8G alloc] init];
    gsEventProxy->x1 = location.x;
    gsEventProxy->y1 = location.y;
    gsEventProxy->x2 = location.x;
    gsEventProxy->y2 = location.y;
    gsEventProxy->x3 = location.x;
    gsEventProxy->y3 = location.y;
    gsEventProxy->sizeX = 1.0;
    gsEventProxy->sizeY = 1.0;
    gsEventProxy->flags = ([touch phase] == UITouchPhaseEnded) ? 0x1010180 : 0x3010180;
    gsEventProxy->type = 3001;

    [self _setGSEvent:(GSEventRef)gsEventProxy];

    [self _setTimestamp:(((UITouch*)touches[0]).timestamp)];
}

- (void)w8m3:(NSArray *)touches
{
    IOHIDEventRef event = kif_IOHIDEventWithTouches(touches);
    [self _setHIDEvent:event];
    CFRelease(event);
}

@end
