#import <UIKit/UIKit.h>
#import "IOHIDEvent+KIF.h"
#import "FixCategoryBug.h"

QX7_CATEGORY_BUG_H(T7A)

@interface UITouch ()

- (void)setWindow:(UIWindow *)window;
- (void)setView:(UIView *)view;
- (void)setTapCount:(NSUInteger)tapCount;
- (void)setIsTap:(BOOL)isTap;
- (void)setTimestamp:(NSTimeInterval)timestamp;
- (void)setPhase:(UITouchPhase)touchPhase;
- (void)setGestureView:(UIView *)view;
- (void)_setLocationInWindow:(CGPoint)location resetPrevious:(BOOL)resetPrevious;
- (void)_setIsFirstTouchForView:(BOOL)firstTouchForView;
- (void)_setIsTapToClick:(BOOL)isTapToClick;

- (void)_setHidEvent:(IOHIDEventRef)event;

@end

@interface UITouch (Q7n2)

- (id)initInView:(UIView *)view;
- (id)initWithB3k8:(CGPoint)point inView:(UIView *)view;
- (id)initWithB3k8:(CGPoint)point inWindow:(UIWindow *)window;
- (id)initWithJ2a5;
- (void)p7d4;

- (void)m4q1:(CGPoint)location;
- (void)n8s6:(UITouchPhase)phase;

@end
