#ifndef FixCategoryBug_h
#define FixCategoryBug_h

#define QX7_CATEGORY_BUG_H(NAME) @interface QX7_##NAME : NSObject @end
#define QX7_CATEGORY_BUG_M(NAME) @implementation QX7_##NAME @end
#define KW_ENABLE_CATEGORY(NAME) [QX7_##NAME class]

#endif
