#import "UITouch-KIFAdditions.h"
#import "LoadableCategory.h"
#import <objc/runtime.h>

QX7_CATEGORY_BUG_M(T7A)

MAKE_CATEGORIES_LOADABLE(T7A)

typedef struct {
    unsigned int _firstTouchForView:1;
    unsigned int _isTap:1;
    unsigned int _isDelayed:1;
    unsigned int _sentTouchesEnded:1;
    unsigned int _abandonForwardingRecord:1;
} UITouchFlags;

@implementation UITouch (Q7n2)

- (id)initInView:(UIView *)view;
{
    CGRect frame = view.frame;
    CGPoint centerPoint = CGPointMake(frame.size.width * 0.5f, frame.size.height * 0.5f);
    return [self initWithB3k8:centerPoint inView:view];
}

- (id)initWithB3k8:(CGPoint)point inWindow:(UIWindow *)window;
{
    self = [super init];
    if (self == nil) {
        return nil;
    }

    [self setWindow:window];

    [self _setLocationInWindow:point resetPrevious:YES];

    UIView *hitTestView = [window hitTest:point withEvent:nil];

    [self setView:hitTestView];
    [self setPhase:UITouchPhaseBegan];
    NSOperatingSystemVersion iOS14 = {14, 0, 0};
    if ([NSProcessInfo instancesRespondToSelector:@selector(isOperatingSystemAtLeastVersion:)] && [[NSProcessInfo new] isOperatingSystemAtLeastVersion:iOS14]) {
        [self _setIsTapToClick:NO];
    } else {
        [self _setIsFirstTouchForView:YES];
        [self setIsTap:NO];
    }
    [self setTimestamp:[[NSProcessInfo processInfo] systemUptime]];
    if ([self respondsToSelector:@selector(setGestureView:)]) {
        [self setGestureView:hitTestView];
    }

    NSOperatingSystemVersion iOS9 = {9, 0, 0};
    if ([NSProcessInfo instancesRespondToSelector:@selector(isOperatingSystemAtLeastVersion:)] && [[NSProcessInfo new] isOperatingSystemAtLeastVersion:iOS9]) {
        [self v6c9];
    }

    return self;
}

- (void)p7d4{

    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    CGPoint point = CGPointMake(0, 0);
    [self setWindow:window];

    [self _setLocationInWindow:CGPointMake(0, 0) resetPrevious:YES];

    UIView *hitTestView = [window hitTest:point withEvent:nil];

    NSOperatingSystemVersion iOS14 = {14, 0, 0};
    if ([NSProcessInfo instancesRespondToSelector:@selector(isOperatingSystemAtLeastVersion:)] && [[NSProcessInfo new] isOperatingSystemAtLeastVersion:iOS14]) {
        [self _setIsTapToClick:NO];
    } else {
        [self _setIsFirstTouchForView:YES];
        [self setIsTap:NO];
    }

    [self setView:hitTestView];
    [self setPhase:UITouchPhaseBegan];

    [self setTimestamp:[[NSProcessInfo processInfo] systemUptime]];
    if ([self respondsToSelector:@selector(setGestureView:)]) {
        [self setGestureView:hitTestView];
    }

    NSOperatingSystemVersion iOS9 = {9, 0, 0};
    if ([NSProcessInfo instancesRespondToSelector:@selector(isOperatingSystemAtLeastVersion:)] && [[NSProcessInfo new] isOperatingSystemAtLeastVersion:iOS9]) {
        [self v6c9];
    }
}

- (id)initWithJ2a5;
{

    self = [super init];
    if (self == nil) {
        return nil;
    }
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    CGPoint point = CGPointMake(0, 0);
    [self setWindow:window];

    [self _setLocationInWindow:point resetPrevious:YES];

    UIView *hitTestView = [window hitTest:point withEvent:nil];

    [self setView:hitTestView];
    [self setPhase:UITouchPhaseEnded];

    NSOperatingSystemVersion iOS14 = {14, 0, 0};
    if ([NSProcessInfo instancesRespondToSelector:@selector(isOperatingSystemAtLeastVersion:)] && [[NSProcessInfo new] isOperatingSystemAtLeastVersion:iOS14]) {
        [self _setIsTapToClick:NO];
    } else {
        [self _setIsFirstTouchForView:YES];
        [self setIsTap:NO];
    }
    [self setTimestamp:[[NSProcessInfo processInfo] systemUptime]];
    if ([self respondsToSelector:@selector(setGestureView:)]) {
        [self setGestureView:hitTestView];
    }

    NSOperatingSystemVersion iOS9 = {9, 0, 0};
    if ([NSProcessInfo instancesRespondToSelector:@selector(isOperatingSystemAtLeastVersion:)] && [[NSProcessInfo new] isOperatingSystemAtLeastVersion:iOS9]) {
        [self v6c9];
    }
    return self;
}

- (id)initWithB3k8:(CGPoint)point inView:(UIView *)view;
{
    return [self initWithB3k8:[view.window convertPoint:point fromView:view] inWindow:view.window];
}

- (void)m4q1:(CGPoint)location
{
    [self setTimestamp:[[NSProcessInfo processInfo] systemUptime]];
    [self _setLocationInWindow:location resetPrevious:NO];
}

- (void)n8s6:(UITouchPhase)phase
{

    [self setTimestamp:[[NSProcessInfo processInfo] systemUptime]];
    [self setPhase:phase];
}

- (void)v6c9 {
    IOHIDEventRef event = kif_IOHIDEventWithTouches(@[self]);
    [self _setHidEvent:event];
    CFRelease(event);
}

@end
