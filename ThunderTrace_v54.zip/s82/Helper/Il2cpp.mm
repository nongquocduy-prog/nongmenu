#include "Il2cpp.h"

#import "encrypt.h"
#import "../Core/OngnongOxorany.h"
#import <mach-o/dyld.h>
#import <pthread/pthread.h>
#import <thread>
#include <codecvt>
#include <locale>
#include <cstring>
#include <dlfcn.h>
#include <math.h>
#include <iostream>
#include <atomic>
#include <thread>
#include <chrono>

@implementation J4n8Q

namespace {
    const void *(*il2cpp_assembly_get_image)(const void *assembly);
    void *(*il2cpp_domain_get)();
    void **(*il2cpp_domain_get_assemblies)(const void *domain, size_t *size);
    const char *(*il2cpp_image_get_name)(void *image);
    void *(*il2cpp_class_from_name)(const void *image, const char *namespaze, const char *name);
    void *(*il2cpp_class_get_field_from_name)(void *klass, const char *name);
    void *(*il2cpp_class_get_method_from_name)(void *klass, const char *name, int argsCount);
    size_t (*il2cpp_field_get_offset)(void *field);
    void (*il2cpp_field_static_get_value)(void *field, void *value);
    void (*il2cpp_field_static_set_value)(void *field, void *value);
    void* (*il2cpp_image_get_class)(void *image, size_t index);
    size_t (*il2cpp_image_get_class_count)(void* Klass);
    size_t (*il2cpp_class_num_fields)(void* Klass);
    const void* (*il2cpp_class_get_image)(const void* Klass);
    const char *(*il2cpp_class_get_name)(void* Klass);
    const char *(*il2cpp_class_get_namespace)(void* Klass);
    void* (*il2cpp_class_get_fields)(void* Klass,void** iter);
    void* (*il2cpp_class_get_parent)(void* Klass);
    const char *(*il2cpp_field_get_name)(void *field);
    void *(*il2cpp_array_new)(void *elementTypeInfo, size_t length);
    uint16_t *(*il2cpp_string_chars)(void *str);
    Il2CppString *(*il2cpp_string_new)(const char *str);
    Il2CppString *(*il2cpp_string_new_utf16)(const wchar_t *str, int32_t length);
    char *(*il2cpp_type_get_name)(void *type);
    void* (*il2cpp_method_get_param)(void *method, uint32_t index);
    void* (*il2cpp_class_get_methods)(void *klass, void* *iter);
    const char* (*il2cpp_method_get_name)(void *method);
    uint32_t (*il2cpp_method_get_param_count)(void *method);
    void *(*il2cpp_object_new)(void *klass);
    void *(*il2cpp_object_unbox)(void *object);
    void *(*il2cpp_runtime_invoke)(const MethodInfo *method, void *obj, void **params, void **exc);
}

void Attach()
{

    il2cpp_assembly_get_image = (const void *(*)(const void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_assembly_get_image"));
    il2cpp_domain_get = (void *(*)()) dlsym(RTLD_DEFAULT, OX_C("il2cpp_domain_get"));
    il2cpp_domain_get_assemblies = (void **(*)(const void* , size_t*)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_domain_get_assemblies"));
    il2cpp_image_get_name = (const char *(*)(void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_image_get_name"));
    il2cpp_class_from_name = (void* (*)(const void*, const char*, const char *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_from_name"));
    il2cpp_class_get_field_from_name = (void* (*)(void*, const char *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_field_from_name"));
    il2cpp_class_get_method_from_name = (void* (*)(void *, const char*, int)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_method_from_name"));
    il2cpp_field_get_offset = (size_t (*)(void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_field_get_offset"));
    il2cpp_field_static_get_value = (void (*)(void*, void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_field_static_get_value"));
    il2cpp_field_static_set_value = (void (*)(void*, void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_field_static_set_value"));
    il2cpp_image_get_class = reinterpret_cast<void *(*)(void *, size_t)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_image_get_class")));
    il2cpp_image_get_class_count = reinterpret_cast<size_t (*)(void *)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_image_get_class_count")));
    il2cpp_class_num_fields = reinterpret_cast<size_t (*)(void *)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_num_fields")));
    il2cpp_class_get_image = reinterpret_cast<const void *(*)(const void *)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_image")));
    il2cpp_class_get_name = reinterpret_cast<const char *(*)(void *)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_name")));
    il2cpp_class_get_namespace = reinterpret_cast<const char *(*)(void *)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_namespace")));
    il2cpp_class_get_fields = reinterpret_cast<void *(*)(void *, void **)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_fields")));
    il2cpp_field_get_name = reinterpret_cast<const char *(*)(void *)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_field_get_name")));
    il2cpp_class_get_parent = reinterpret_cast<void *(*)(void *)>(dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_parent")));
    il2cpp_array_new = (void *(*)(void*, size_t)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_array_new"));
    il2cpp_string_chars = (uint16_t *(*)(void*)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_string_chars"));
    il2cpp_string_new = (Il2CppString *(*)(const char *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_string_new"));
    il2cpp_string_new_utf16 = (Il2CppString *(*)(const wchar_t *, int32_t)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_string_new"));
    il2cpp_type_get_name = (char *(*)(void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_type_get_name"));
    il2cpp_method_get_param = (void *(*)(void *, uint32_t)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_get_param"));
    il2cpp_class_get_methods = (void *(*)(void *, void **)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_methods"));
    il2cpp_method_get_name = (const char *(*)(void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_get_name"));
    il2cpp_method_get_param_count = (uint32_t (*)(void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_get_param_count"));
    il2cpp_object_new = (void *(*)(void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_object_new"));
    il2cpp_object_unbox = (void *(*)(void *)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_object_unbox"));
    il2cpp_runtime_invoke = (void *(*)(const MethodInfo *, void *, void **, void **)) dlsym(RTLD_DEFAULT, OX_C("il2cpp_runtime_invoke"));

}

typedef unsigned short UTF16;
typedef wchar_t UTF32;
typedef char UTF8;

int is_surrogate(UTF16 uc) {
    return (uc - 0xd800u) < 2048u;
}

int is_high_surrogate(UTF16 uc) {
    return (uc & 0xfffffc00) == 0xd800;
}

int is_low_surrogate(UTF16 uc) {
    return (uc & 0xfffffc00) == 0xdc00;
}

UTF32 surrogate_to_utf32(UTF16 high, UTF16 low) {
    return (high << 10) + low - 0x35fdc00;
}

const char* utf16_to_utf8(const UTF16* source, size_t len) {
    std::u16string s(source, source + len);
    std::wstring_convert<std::codecvt_utf8_utf16<char16_t>, char16_t> convert;
    std::string temp = convert.to_bytes(s);
    char* cstr = new char[temp.length() + 1];
    std::strcpy(cstr, temp.c_str());
    return cstr;

}

const wchar_t* utf16_to_utf32(const UTF16* source, size_t len) {
    auto output = new UTF32[len + 1];

    for (int i = 0; i < len; i++) {
        const UTF16 uc = source[i];
        if (!is_surrogate(uc)) {
            output[i] = uc;
        }
        else {
            if (is_high_surrogate(uc) && is_low_surrogate(source[i]))
                output[i] = surrogate_to_utf32(uc, source[i]);
            else
                output[i] = L'?';
        }
    }

    output[len] = L'\0';
    return output;
}

const char* Il2CppString::CString() {
    return utf16_to_utf8(&this->start_char, this->length);
}

const wchar_t* Il2CppString::WCString() {
    return utf16_to_utf32(&this->start_char, this->length);
}

Il2CppString *Il2CppString::Create(const char *s)
{
    return il2cpp_string_new(s);
}

Il2CppString *Il2CppString::Create(const wchar_t *s, int len)
{
    return il2cpp_string_new_utf16(s, len);
}

void *Il2CppGetImageByName(const char *image) {
    if (!image || !il2cpp_domain_get || !il2cpp_domain_get_assemblies || !il2cpp_assembly_get_image || !il2cpp_image_get_name) return nullptr;
    void *domain = il2cpp_domain_get();
    if (!domain) return nullptr;
    size_t size = 0;
    void **assemblies = il2cpp_domain_get_assemblies(domain, &size);
    if (!assemblies || size == 0) return nullptr;
    for(size_t i = 0; i < size; ++i)
    {
        if (!assemblies[i]) continue;
        void *img = (void *)il2cpp_assembly_get_image(assemblies[i]);
        if (!img) continue;
        const char *img_name = il2cpp_image_get_name(img);
        if(!img_name) continue;
        if(strcmp(img_name, image) == 0)
        {
            return img;
        }
    }
    return nullptr;
}

void *  Il2CppGetClassType(const char *image, const char *namespaze, const char *clazz) {
    static std::map<std::string, void *> cache;

    std::string s = image;
    s += namespaze;
    s += clazz;

    if (cache.count(s) > 0)
        return cache[s];

    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return nullptr;
    }

    void *klass = il2cpp_class_from_name(img, namespaze, clazz);
    if(!klass) {
        return nullptr;
    }

    cache[s] = klass;
    return klass;
}

void *Il2CppFindClassAnyImage(const char *namespaze,
                                  const char *clazz,
                                  const char **foundImageName) {
    if (foundImageName) *foundImageName = nullptr;
    if (!namespaze || !clazz || !il2cpp_domain_get ||
        !il2cpp_domain_get_assemblies || !il2cpp_assembly_get_image) {
        return nullptr;
    }

    void *domain = il2cpp_domain_get();
    if (!domain) return nullptr;

    size_t assemblyCount = 0;
    void **assemblies = il2cpp_domain_get_assemblies(domain, &assemblyCount);
    if (!assemblies || assemblyCount == 0) return nullptr;

    if (il2cpp_class_from_name) {
        for (size_t i = 0; i < assemblyCount; ++i) {
            if (!assemblies[i]) continue;
            void *image = (void *)il2cpp_assembly_get_image(assemblies[i]);
            if (!image) continue;
            void *klass = il2cpp_class_from_name(image, namespaze, clazz);
            if (klass) {
                if (foundImageName && il2cpp_image_get_name) {
                    *foundImageName = il2cpp_image_get_name(image);
                }
                return klass;
            }
        }
    }

    if (il2cpp_image_get_class_count && il2cpp_image_get_class &&
        il2cpp_class_get_name && il2cpp_class_get_namespace) {
        for (size_t i = 0; i < assemblyCount; ++i) {
            if (!assemblies[i]) continue;
            void *image = (void *)il2cpp_assembly_get_image(assemblies[i]);
            if (!image) continue;
            size_t classCount = il2cpp_image_get_class_count(image);
            for (size_t j = 0; j < classCount; ++j) {
                void *klass = il2cpp_image_get_class(image, j);
                if (!klass) continue;
                const char *className = il2cpp_class_get_name(klass);
                const char *classNamespace = il2cpp_class_get_namespace(klass);
                if (className && classNamespace &&
                    strcmp(className, clazz) == 0 &&
                    strcmp(classNamespace, namespaze) == 0) {
                    if (foundImageName && il2cpp_image_get_name) {
                        *foundImageName = il2cpp_image_get_name(image);
                    }
                    return klass;
                }
            }
        }
    }

    return nullptr;
}

void *Il2CppCreateClassInstanceFromClass(void *klass) {
    if (!klass || !il2cpp_object_new) return nullptr;
    return il2cpp_object_new(klass);
}

void *Il2CppCreateClassInstance(const char *image, const char *namespaze, const char *clazz) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return nullptr;
    }

    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return nullptr;
    }

    void *obj = il2cpp_object_new(klass);
    if(!obj)
    {
        return nullptr;
    }

    return obj;
}

void* Il2CppCreateArray(const char *image, const char *namespaze, const char *clazz, size_t length) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return nullptr;
    }
    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return nullptr;
    }

    return il2cpp_array_new(klass, length);
}

void Il2CppGetStaticFieldValue(const char *image, const char *namespaze, const char *clazz, const char *name, void *output) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
            return;
    }
    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return;
    }

    void *field = il2cpp_class_get_field_from_name(klass, name);
    if(!field) {
        return;
    }

    il2cpp_field_static_get_value(field, output);
}

void Il2CppSetStaticFieldValue(const char *image, const char *namespaze, const char *clazz, const char *name, void* value) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return;
    }
    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return;
    }

    void *field = il2cpp_class_get_field_from_name(klass, name);
    if(!field) {
        return;
    }

    il2cpp_field_static_set_value(field, value);
}

void *Il2CppGetMethodOffset(const char *image, const char *namespaze, const char *clazz, const char *name, int argsCount) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return nullptr;
    }

    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return nullptr;
    }

    void **method = (void**)il2cpp_class_get_method_from_name(klass, name, argsCount);
    if(!method) {
        return nullptr;
    }
    return *method;
}


void *Il2CppRuntimeInvoke(MethodInfo *method,
                          void *instance,
                          void **parameters,
                          void **exception) {
    if (!method || !il2cpp_runtime_invoke) {
        return nullptr;
    }

    void *localException = nullptr;
    void **exceptionOut = exception ? exception : &localException;

    void *result = il2cpp_runtime_invoke(
        method,
        instance,
        parameters,
        exceptionOut);

    return result;
}

void *Il2CppObjectUnbox(void *object) {
    if (!object) {
        return nullptr;
    }
    if (il2cpp_object_unbox) {
        return il2cpp_object_unbox(object);
    }
    return reinterpret_cast<void *>(
        reinterpret_cast<uintptr_t>(object) +
        sizeof(Il2CppObject));
}

MethodInfo *Il2CppFindMethodInfoRaw(const char *image,
                                    const char *namespaze,
                                    const char *clazz,
                                    const char *name,
                                    int argsCount,
                                    bool searchParents) {
    if (!image || !namespaze || !clazz || !name ||
        !il2cpp_class_get_method_from_name ||
        !il2cpp_class_get_methods ||
        !il2cpp_method_get_name) {
        return nullptr;
    }

    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if (!klass) return nullptr;

    for (void *current = klass;
         current != nullptr;
         current = searchParents && il2cpp_class_get_parent
                     ? il2cpp_class_get_parent(current)
                     : nullptr) {

        MethodInfo *direct = reinterpret_cast<MethodInfo *>(
            il2cpp_class_get_method_from_name(current, name, argsCount));
        if (direct) return direct;

        void *iter = nullptr;
        while (void *rawMethod = il2cpp_class_get_methods(current, &iter)) {
            const char *methodName = il2cpp_method_get_name(rawMethod);
            if (!methodName || strcmp(methodName, name) != 0) continue;

            if (il2cpp_method_get_param_count) {
                uint32_t count = il2cpp_method_get_param_count(rawMethod);
                if (static_cast<int>(count) != argsCount) continue;
            }

            return reinterpret_cast<MethodInfo *>(rawMethod);
        }

        if (!searchParents) break;
    }

    return nullptr;
}

MethodInfo *Il2CppFindMethodInfo(const char *image,
                                 const char *namespaze,
                                 const char *clazz,
                                 const char *name,
                                 int argsCount,
                                 bool searchParents) {
    if (!image || !namespaze || !clazz || !name ||
        !il2cpp_class_get_method_from_name ||
        !il2cpp_class_get_methods ||
        !il2cpp_method_get_name) {
        return nullptr;
    }

    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if (!klass) return nullptr;

    for (void *current = klass;
         current != nullptr;
         current = searchParents && il2cpp_class_get_parent
                     ? il2cpp_class_get_parent(current)
                     : nullptr) {

        MethodInfo *direct = reinterpret_cast<MethodInfo *>(
            il2cpp_class_get_method_from_name(current, name, argsCount));

        if (direct && direct->methodPointer) {
            return direct;
        }

        void *iter = nullptr;
        while (void *raw = il2cpp_class_get_methods(current, &iter)) {
            const char *methodName = il2cpp_method_get_name(raw);
            if (!methodName || strcmp(methodName, name) != 0) {
                continue;
            }

            if (il2cpp_method_get_param_count) {
                uint32_t count = il2cpp_method_get_param_count(raw);
                if (static_cast<int>(count) != argsCount) {
                    continue;
                }
            }

            MethodInfo *candidate = reinterpret_cast<MethodInfo *>(raw);
            if (candidate->methodPointer) {
                return candidate;
            }
        }

        if (!searchParents) break;
    }

    return nullptr;
}

void *Il2CppGetMethodOffsetDeep(const char *image,
                                const char *namespaze,
                                const char *clazz,
                                const char *name,
                                int argsCount,
                                bool searchParents) {
    MethodInfo *method = Il2CppFindMethodInfo(
        image, namespaze, clazz, name, argsCount, searchParents);

    return method ? method->methodPointer : nullptr;
}


bool Il2CppHookImpl(const char *image, const char *namespaze, const char *clazz, void* hook, void* orig, const char * name, int cnttt)
{
    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    MethodInfo* method = (MethodInfo*)il2cpp_class_get_method_from_name(klass, name, cnttt);

    if (!method || !hook) { return false; }

    if (orig) { *(void**)orig = (void*)method->methodPointer; }

    method->methodPointer = hook;

    return true;
}

void *Il2CppGetMethodOffset(const char *image, const char *namespaze, const char *clazz, const char *name, char** args, int argsCount) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return 0;
    }

    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return 0;
    }

    void *iter = 0;

    int score = 0;

    void **method = (void**) il2cpp_class_get_methods(klass, &iter);
    while(method) {
        const char *fname = il2cpp_method_get_name(method);
        if(strcmp(fname, name) == 0) {
            for (int i = 0; i < argsCount; i++) {
                void *arg = il2cpp_method_get_param(method, i);
                if (arg) {
                    const char *tname = il2cpp_type_get_name(arg);
                    if (strcmp(tname, args[i]) == 0) {
                        score++;
                    } else {
                        score = 0;
goto skip;
                    }
                }
            }
        }
        skip:

        if(score == argsCount)
        {
            return *method;
        }

        method = (void **) il2cpp_class_get_methods(klass, &iter);
    }
    return 0;
}

size_t Il2CppGetFieldOffset(const char *image, const char *namespaze, const char *clazz, const char *name) {
    void *img = Il2CppGetImageByName(image);
    if(!img) {
        return -1;
    }
    void *klass = Il2CppGetClassType(image, namespaze, clazz);
    if(!klass) {
        return -1;
    }

    void *field = il2cpp_class_get_field_from_name(klass, name);
    if(!field) {
        return -1;
    }
    auto result = il2cpp_field_get_offset(field);
    return result;
}

bool Il2CppIsAssembliesLoaded() {
    size_t size;
    void **assemblies = il2cpp_domain_get_assemblies(il2cpp_domain_get(), &size);

    return size != 0 && assemblies != 0;
}

void* Il2CppGetSingleton(const char *dllfilename, const char *namespaze, const char *className)
{
    void* dllfile = Il2CppGetImageByName(dllfilename);
    if(dllfile)
    {
        void* getClass = il2cpp_class_from_name(dllfile,namespaze,className);
        if(getClass)
        {
            void* parentclass = il2cpp_class_get_parent(getClass);
            int fieldsCount = il2cpp_class_num_fields(parentclass);
            if (fieldsCount > 0)
            {
                void* iterator = NULL;
                void* field = NULL;
                while ((field = il2cpp_class_get_fields(parentclass, &iterator)) != NULL)
                {
                    if(field ==NULL) break;
                    const char* fieldName = il2cpp_field_get_name(field);

                    if (strstr(fieldName, "_instance") != NULL)
                    {
                        uint64_t myFieldValue = 0;
                        il2cpp_field_static_get_value(field,(void*)&myFieldValue);
                        return (void*)myFieldValue;
                    }
                }
            }
        }
    }
    return nullptr;
}

void* Il2CppGetInstanceFromMethod(const char *dllfilename, const char *namespaze, const char *className, const char *methodName)
{
    void* methodPtr = Il2CppGetMethodOffset(dllfilename, namespaze, className, methodName, 0);
    if(methodPtr)
    {

        void* (*getInstanceFunc)() = (void* (*)())methodPtr;
        return getInstanceFunc();
    }
    return nullptr;
}

void* get_offset(const char *dllfilename, const char *namespaze, const char *className, const char *methodName, int argsCount) {
    return Il2CppGetMethodOffset(dllfilename, namespaze, className, methodName, argsCount);
}
size_t getFieldOffset(const char *dllFilename, const char *namespaceName, const char *className, const char *fieldName) {
    return Il2CppGetFieldOffset(dllFilename, namespaceName, className, fieldName);
}
int GetObscuredIntValue(uint64_t location) {
    int cryptoKey = *(int*)location;
    int obfuscatedValue = *(int*)(location + 0x4);

    return obfuscatedValue ^ cryptoKey;
}

int GetObscuredBoolValue(uint64_t location) {
    int cryptoKey = *(int*)(location + 0x8);
    int obfuscatedValue = *(int*)(location + 0xC);
    obfuscatedValue ^= cryptoKey;
    return obfuscatedValue;
}

void SetObscuredIntValue(uint64_t location, int value) {
    int cryptoKey = *(int*)location;

    *(int*)(location + 0x4) = value ^ cryptoKey;
}

float GetObscuredFloatValue(uint64_t location) {
    int cryptoKey = *(int*)location;
    int obfuscatedValue = *(int*)(location + 0x4);

    intfloat IF;
    IF.i = obfuscatedValue ^ cryptoKey;

    return IF.f;
}

void SetObscuredFloatValue(uint64_t location, float value) {
    int cryptoKey = *(int*)location;

    intfloat IF;
    IF.f = value;

    intfloat IF2;
    IF2.i = IF.i ^ cryptoKey;

    *(float*)(location + 0x4) = IF2.f;
}

@end
