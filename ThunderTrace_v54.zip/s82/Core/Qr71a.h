#pragma once
#import <Foundation/Foundation.h>

@interface Q71N : NSObject
@property (nonatomic, copy) NSString *x0;
@property (nonatomic, assign) NSInteger x1;
@end

BOOL q71a0(NSData *data);
NSArray<Q71N *> *q71a1(id json);
