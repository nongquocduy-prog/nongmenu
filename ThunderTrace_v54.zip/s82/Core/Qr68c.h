#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int q6slot(int *p);
int q6phase(int s, int r, int p);
bool q6gb(uint32_t tag);
bool q6gc(uint32_t tag);
#ifdef __cplusplus
}
#endif
