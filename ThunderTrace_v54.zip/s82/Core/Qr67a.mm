#import "Qr67a.h"
#import "Qr65b.h"
#import <Foundation/Foundation.h>

@implementation Q67A0
@end

static NSString *q67d0(const unsigned char *x, NSUInteger l, unsigned char k) {
    if (!x || l == 0) return @"";
    unsigned char b[96];
    if (l >= sizeof(b)) return @"";
    for (NSUInteger i = 0; i < l; i++) b[i] = (unsigned char)(x[i] ^ (unsigned char)(k + i * 17 + ((i & 3) * 29)));
    return [[NSString alloc] initWithBytes:b length:l encoding:NSUTF8StringEncoding] ?: @"";
}

NSString *q67a0(id v) {
    if (!v || v == [NSNull null]) return @"";
    NSString *s = [v isKindOfClass:[NSString class]] ? (NSString *)v : [v description];
    return s.lowercaseString ?: @"";
}

BOOL q67a1(id v, NSString *n, int d) {
    if (!v || v == [NSNull null] || d > 12) return NO;
    NSString *z = q67a0(n);
    if (z.length == 0) return NO;
    if ([v isKindOfClass:[NSString class]]) return [q67a0(v) containsString:z];
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSDictionary *m = (NSDictionary *)v;
        for (id k in m) {
            if ([q67a0(k) containsString:z]) return YES;
            id y = m[k];
            if ([y isKindOfClass:[NSDictionary class]] || [y isKindOfClass:[NSArray class]] || [y isKindOfClass:[NSString class]]) {
                if (q67a1(y, n, d + 1)) return YES;
            }
        }
    } else if ([v isKindOfClass:[NSArray class]]) {
        for (id y in (NSArray *)v) if (q67a1(y, n, d + 1)) return YES;
    }
    return NO;
}

NSInteger q67a2(NSDictionary *d, NSArray<NSString *> *k, NSInteger f) {
    if (![d isKindOfClass:[NSDictionary class]]) return f;
    for (NSString *w in k) {
        NSString *z = q67a0(w);
        for (id rk in d) {
            if ([q67a0(rk) isEqualToString:z]) return q65b6(d[rk], f);
        }
    }
    return f;
}

NSString *q67k0(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x56,0x06,0xe7,0xa8,0x0d,0xcc}; s = q67d0(x, sizeof(x), 0x37); return s; }
NSString *q67k1(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x2b,0x1b,0xd2,0xbd,0xf8,0xd9,0x83,0x7c}; s = q67d0(x, sizeof(x), 0x4a); return s; }
NSString *q67k2(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x3c,0xe8,0xcd,0x8e,0xd7,0xaa,0x9f,0x4a,0x97}; s = q67d0(x, sizeof(x), 0x5d); return s; }
NSString *q67k3(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x11,0xfd,0xb8,0x93,0xc2,0x87,0x72,0x5f,0x8a,0x4f,0x30}; s = q67d0(x, sizeof(x), 0x70); return s; }
NSString *q67k4(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xe2,0xd2,0xab,0x64,0xb1,0x90,0x42,0x32,0x68,0x4c,0x0a,0xe0,0x23,0x1c,0xdf,0xb0,0xfc,0xaf,0x8d,0x7c,0xa5,0x6c,0x57}; s = q67d0(x, sizeof(x), 0x83); return s; }
NSString *q67k5(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xe5,0xa1,0x9e,0x45,0xb9,0x7c,0x53,0x00}; s = q67d0(x, sizeof(x), 0x96); return s; }
NSString *q67k6(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xda,0xb2,0x69,0x56,0x8e,0x6f,0x2c,0x13,0x53,0x3e,0xff}; s = q67d0(x, sizeof(x), 0xa9); return s; }
NSString *q67k7(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xcf,0x8f,0x74,0x23,0x63,0x5a,0x39,0xee,0x26,0x13,0xd2,0xa7,0xec}; s = q67d0(x, sizeof(x), 0xbc); return s; }
NSString *q67k8(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xac,0x88,0x59,0x2b,0x76,0x2f,0x1b,0xff,0x36,0xf7}; s = q67d0(x, sizeof(x), 0xcf); return s; }
NSString *q67k9(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x81,0x65,0x4c,0x1e,0x43,0x3a,0xf6,0xd2,0x0b,0xea,0xaf,0x90}; s = q67d0(x, sizeof(x), 0xe2); return s; }
NSString *q67k10(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x94,0x40,0x32,0x0a,0x54,0x12,0xf9,0xa2,0x09,0xc2,0xb6,0x69,0xa3,0x8e,0x6f,0x38,0x67,0x4a,0x08,0xeb}; s = q67d0(x, sizeof(x), 0xf5); return s; }
NSString *q67k11(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x69,0x55,0x07,0xe7,0x21,0x0f,0xc4,0xb7,0xe4,0xd7,0x83,0x74,0x8b,0x60,0x51,0x2c,0x6b,0x19,0x16,0xdb,0x03,0xe3,0xdc}; s = q67d0(x, sizeof(x), 0x08); return s; }
NSString *q67k12(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x78,0x3c,0x05,0xd7,0x3a,0xe3,0xcf}; s = q67d0(x, sizeof(x), 0x1b); return s; }
NSString *q67k13(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x4d,0x29,0xf8,0xca,0x17,0xce,0xba,0x9d,0xdb,0x8b,0x67,0x2e,0x8e}; s = q67d0(x, sizeof(x), 0x2e); return s; }
NSString *q67k14(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x22,0x1a,0xef,0xb9,0xe0,0xdd,0x95,0x50,0xa8,0x9a,0x4a,0x26,0x63,0x4f}; s = q67d0(x, sizeof(x), 0x41); return s; }
NSString *q67k15(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x37,0xf7,0xc2,0xac,0xfd,0xa8,0x80,0x43,0xb1,0x65,0x4d,0x08,0x54,0x20,0x13,0xc4,0x07,0xf3,0xb0,0x9e,0xcd,0xb2}; s = q67d0(x, sizeof(x), 0x54); return s; }
NSString *q67k16(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x17,0xe7,0xac,0x96,0xd9,0xbc,0x74,0x46}; s = q67d0(x, sizeof(x), 0x67); return s; }
NSString *q67k17(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x1b,0xc5,0xb9,0x71,0xd0,0x98}; s = q67d0(x, sizeof(x), 0x7a); return s; }
NSString *q67k18(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xfb,0xda,0x85,0x62,0xb4}; s = q67d0(x, sizeof(x), 0x8d); return s; }
NSString *q67k19(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xd4,0xa1,0x88,0x4b,0x88}; s = q67d0(x, sizeof(x), 0xa0); return s; }
NSString *q67k20(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xc7,0x8e,0x7b,0x5c,0x9b,0x44,0x3e,0xee,0x4e,0x07,0xe3}; s = q67d0(x, sizeof(x), 0xb3); return s; }
NSString *q67k21(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xb2,0x9b,0x56,0x31,0x66,0x67,0x07,0xf9,0x21,0x09,0xc4,0xac}; s = q67d0(x, sizeof(x), 0xc6); return s; }
NSString *q67k22(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xad,0x68,0x41,0x02,0x71,0x2a,0x14,0xc8,0x14,0xe1,0xc9,0x85,0xca,0xbd,0x62,0x4e,0x99,0x67,0x20,0x17}; s = q67d0(x, sizeof(x), 0xd9); return s; }
NSString *q67k23(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x98,0x7b,0x3a,0x11,0x55,0x2a}; s = q67d0(x, sizeof(x), 0xec); return s; }
NSString *q67k24(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x8d,0x48,0x2a,0xfc,0x2a,0x03,0xfa,0xa9}; s = q67d0(x, sizeof(x), 0xff); return s; }
NSString *q67k25(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x7f,0x21,0x16}; s = q67d0(x, sizeof(x), 0x12); return s; }
NSString *q67k26(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x42,0x3c,0xe0,0xc3}; s = q67d0(x, sizeof(x), 0x25); return s; }
NSString *q67k27(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x4d,0x16,0xf0,0xa3,0x08,0xcf,0xbc,0x63,0xb6,0x8b,0x72,0x3e}; s = q67d0(x, sizeof(x), 0x38); return s; }
NSString *q67k28(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x38,0x10,0xc3,0xb0}; s = q67d0(x, sizeof(x), 0x4b); return s; }
NSString *q67k29(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x2c,0xe9,0xcd,0x89,0xd0,0xb4}; s = q67d0(x, sizeof(x), 0x5e); return s; }
NSString *q67k30(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x1c,0xf6,0xbe,0x88,0xdc,0x8c,0x7f}; s = q67d0(x, sizeof(x), 0x71); return s; }
NSString *q67k31(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xeb,0xd4,0x86,0x6b,0xba}; s = q67d0(x, sizeof(x), 0x84); return s; }
NSString *q67k32(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xf5,0xaa,0x9d,0x54,0xa8}; s = q67d0(x, sizeof(x), 0x97); return s; }
NSString *q67k33(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xc8,0xb9,0x74,0x47}; s = q67d0(x, sizeof(x), 0xaa); return s; }
NSString *q67k34(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xc9,0x82,0x74,0x22}; s = q67d0(x, sizeof(x), 0xbd); return s; }
NSString *q67k35(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xbc,0x91,0x4f,0x31,0x71,0x26,0x32,0xff,0x2a,0xcf,0xd0}; s = q67d0(x, sizeof(x), 0xd0); return s; }
NSString *q67k36(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x8f,0x70,0x4c,0x19,0x77,0x06}; s = q67d0(x, sizeof(x), 0xe3); return s; }
NSString *q67k37(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x84,0x4b,0x3d,0xf4}; s = q67d0(x, sizeof(x), 0xf6); return s; }
NSString *q67k38(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x2c,0x77,0x4b,0xb6,0x0d}; s = q67d0(x, sizeof(x), 0x09); return s; }
NSString *q67k39(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x39,0x0a,0x23,0x83,0x0c,0xfb,0xe1}; s = q67d0(x, sizeof(x), 0x1c); return s; }
NSString *q67k40(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x0a,0x31,0xef,0x96,0x56,0xcd,0xab}; s = q67d0(x, sizeof(x), 0x2f); return s; }
NSString *q67k41(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x2d,0x1e,0xf9,0xa2,0xe9,0xda,0x85,0x4f,0xbe,0x93,0x79,0x27,0x7a,0x5d,0x1e,0xfd,0x0d}; s = q67d0(x, sizeof(x), 0x42); return s; }
NSString *q67k42(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x21,0xec,0xda,0xba,0xf7,0x98,0x96,0x56,0xaf,0x79,0x5c,0x09,0x42,0x36,0x22,0xdc,0x0d,0xf6,0xa4,0x83,0xf6,0xa3,0x6a,0x58,0x88,0x75}; s = q67d0(x, sizeof(x), 0x55); return s; }
NSString *q67k43(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x1c,0xf9,0xaf,0x97,0xc2,0x85,0x7f,0x5e,0x95,0x7b,0x20}; s = q67d0(x, sizeof(x), 0x68); return s; }
NSString *q67k44(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0x0f,0xc6,0xbc,0x60,0xd1,0xc0,0x6c,0x21,0x66,0x54,0x33}; s = q67d0(x, sizeof(x), 0x7b); return s; }
NSString *q67k45(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xfe,0xd3,0x9e,0x71,0xbd,0x6e}; s = q67d0(x, sizeof(x), 0x8e); return s; }
NSString *q67k46(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xc4,0xb7,0x8d,0x4e,0x81,0x7a,0x35,0x06,0x46,0x39,0xda,0xd4,0x08,0xf5,0xac,0x85,0xd8,0xbc,0x52,0x4b,0x9a,0x57,0x38,0x10,0x57,0x38,0xf6,0xb6,0x0f,0xd9,0xbc,0x69,0xa2,0x96}; s = q67d0(x, sizeof(x), 0xa1); return s; }
NSString *q67k47(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xc4,0x8d,0x64,0x57,0x97,0x48,0x0b,0xe1,0x49,0x18,0xea,0xa3,0xee,0xcd,0xa5}; s = q67d0(x, sizeof(x), 0xb4); return s; }
NSString *q67k48(void) { static NSString *s = nil; if (s) return s; static const unsigned char x[] = {0xa0,0x90,0x4d,0x34,0x79,0x50,0x04,0xca,0x3f,0x12,0xdf,0xb0,0xfc,0xaf}; s = q67d0(x, sizeof(x), 0xc7); return s; }
