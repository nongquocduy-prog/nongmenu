#pragma once
#include <stdint.h>

namespace Ongnong {
bool R7f701(void);
uint64_t R7f702(uint64_t value);
}
