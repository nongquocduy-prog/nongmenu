#pragma once
#import <Foundation/Foundation.h>
#import "Qr67a.h"
void q67b9(id v, NSMutableArray<Q67A0 *> *m, NSMutableArray<Q67A0 *> *s, NSString *p, int d);
