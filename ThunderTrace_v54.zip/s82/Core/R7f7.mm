#import "R7f7.h"
#import "R7f8.h"
#import "R7f4.h"
#import "R7f5.h"
#import "zx8f1a_gate.h"
#import "OngnongOxorany.h"
#import <Foundation/Foundation.h>
#include <atomic>
#include <dlfcn.h>
#include <fcntl.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sysctl.h>
#include <unistd.h>

#ifndef P_TRACED
#define P_TRACED 0x00000800
#endif

namespace Ongnong {

static std::atomic<bool> gR7f701Denied(false);
static std::atomic<uint64_t> gR7f701Cookie(0);
static std::atomic<uint64_t> gR7f701Epoch(0);

static uint64_t R7f703(uint64_t value) {
    value ^= value >> 30;
    value *= R7F8_A | 1;
    value ^= value >> 27;
    value *= R7F8_B | 1;
    value ^= value >> 31;
    return value;
}

static bool R7f704(void) {
    typedef int (*R7f704Fn)(
        int *,
        u_int,
        void *,
        size_t *,
        void *,
        size_t);
    R7f704Fn fn = reinterpret_cast<R7f704Fn>(
        dlsym(RTLD_DEFAULT, OX_C("sysctl")));
    if (!fn) return false;
    int mib[4] = {
        CTL_KERN,
        KERN_PROC,
        KERN_PROC_PID,
        getpid()
    };
    struct kinfo_proc info;
    memset(&info, 0, sizeof(info));
    size_t size = sizeof(info);
    if (fn(mib, 4, &info, &size, nullptr, 0) != 0) {
        return false;
    }
    return (info.kp_proc.p_flag & P_TRACED) != 0;
}

static bool R7f705(void) {
    if (dlsym(
            RTLD_DEFAULT,
            OX_C("gum_interceptor_attach")) ||
        dlsym(
            RTLD_DEFAULT,
            OX_C("frida_agent_main")) ||
        dlsym(
            RTLD_DEFAULT,
            OX_C("cycript_main"))) {
        return true;
    }
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; ++i) {
        const char *raw = _dyld_get_image_name(i);
        if (!raw || !raw[0]) continue;
        NSString *name = [[NSString stringWithUTF8String:raw]
            lowercaseString];
        if ([name containsString:OX_NS("frida")] ||
            [name containsString:OX_NS("cycript")] ||
            [name containsString:OX_NS("revealserver")]) {
            return true;
        }
    }
    return false;
}

static bool R7f706(
    const struct mach_header_64 *header,
    int descriptor,
    const void *address) {
    if (!header ||
        descriptor < 0 ||
        !address ||
        header->magic != MH_MAGIC_64) {
        return true;
    }
    const uint8_t *cursor =
        reinterpret_cast<const uint8_t *>(header) +
        sizeof(struct mach_header_64);
    uint64_t textVm = 0;
    const struct segment_command_64 *segments[32] = {};
    uint32_t segmentCount = 0;
    for (uint32_t i = 0;
         i < header->ncmds &&
         segmentCount < 32;
         ++i) {
        const struct load_command *command =
            reinterpret_cast<const struct load_command *>(cursor);
        if (command->cmdsize < sizeof(struct load_command)) {
            return true;
        }
        if (command->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *segment =
                reinterpret_cast<
                    const struct segment_command_64 *>(cursor);
            segments[segmentCount++] = segment;
            if (strncmp(
                    segment->segname,
                    SEG_TEXT,
                    sizeof(segment->segname)) == 0) {
                textVm = segment->vmaddr;
            }
        }
        cursor += command->cmdsize;
    }
    uintptr_t slide =
        reinterpret_cast<uintptr_t>(header) -
        static_cast<uintptr_t>(textVm);
    uintptr_t runtime =
        reinterpret_cast<uintptr_t>(address);
    if (runtime < slide) return true;
    uint64_t unslid =
        static_cast<uint64_t>(runtime - slide);
    uint64_t fileOffset = UINT64_MAX;
    for (uint32_t i = 0; i < segmentCount; ++i) {
        const struct segment_command_64 *segment =
            segments[i];
        if (unslid >= segment->vmaddr &&
            unslid + 64 <=
                segment->vmaddr + segment->filesize) {
            fileOffset =
                segment->fileoff +
                (unslid - segment->vmaddr);
            break;
        }
    }
    if (fileOffset == UINT64_MAX) return true;
    uint8_t disk[64] = {};
    ssize_t readSize = pread(
        descriptor,
        disk,
        sizeof(disk),
        static_cast<off_t>(fileOffset));
    if (readSize != static_cast<ssize_t>(sizeof(disk))) {
        return true;
    }
    return memcmp(
               disk,
               reinterpret_cast<const void *>(runtime),
               sizeof(disk)) == 0;
}

static bool R7f707(void) {
    Dl_info info;
    memset(&info, 0, sizeof(info));
    if (dladdr(
            reinterpret_cast<const void *>(&R7f701),
            &info) == 0 ||
        !info.dli_fbase ||
        !info.dli_fname) {
        return true;
    }
    const struct mach_header_64 *header =
        reinterpret_cast<
            const struct mach_header_64 *>(info.dli_fbase);
    int descriptor =
        open(info.dli_fname, O_RDONLY);
    if (descriptor < 0) return true;
    const void *targets[] = {
        reinterpret_cast<const void *>(&R7f701),
        reinterpret_cast<const void *>(&R7f702),
        reinterpret_cast<const void *>(&R7f401),
        reinterpret_cast<const void *>(&R7f408),
        reinterpret_cast<const void *>(&R7f409),
        reinterpret_cast<const void *>(&R7f410),
        reinterpret_cast<const void *>(&R7f412),
        reinterpret_cast<const void *>(&R7f414)
    };
    for (const void *target : targets) {
        if (!R7f706(header, descriptor, target)) {
            close(descriptor);
            return false;
        }
    }
    close(descriptor);
    return true;
}

__attribute__((noinline, visibility("hidden")))
bool R7f701(void) {
    if (gR7f701Denied.load(
            std::memory_order_acquire)) {
        return false;
    }
    uint64_t epoch = static_cast<uint64_t>(
        [NSDate timeIntervalSinceReferenceDate] / 1.5);
    uint64_t previous =
        gR7f701Epoch.load(std::memory_order_acquire);
    if (previous != epoch &&
        gR7f701Epoch.compare_exchange_strong(
            previous,
            epoch,
            std::memory_order_acq_rel)) {
        if (R7f704() ||
            R7f705() ||
            !R7f707()) {
            gR7f701Denied.store(
                true,
                std::memory_order_release);
            gR7f701Cookie.store(
                0,
                std::memory_order_release);
            return false;
        }
        if (gR7f701Cookie.load(
                std::memory_order_acquire) == 0) {
            uint64_t entropy[2] = {0, 0};
            arc4random_buf(
                entropy,
                sizeof(entropy));
            uint64_t cookie = R7f703(
                entropy[0] ^
                entropy[1] ^
                R7F8_C ^
                reinterpret_cast<uintptr_t>(
                    &gR7f701Cookie));
            if (cookie == 0) cookie = R7F8_D | 1;
            gR7f701Cookie.store(
                cookie,
                std::memory_order_release);
        }
    }
    return !gR7f701Denied.load(
               std::memory_order_acquire) &&
           gR7f701Cookie.load(
               std::memory_order_acquire) != 0;
}

__attribute__((noinline, visibility("hidden")))
uint64_t R7f702(uint64_t value) {
    uint64_t cookie =
        gR7f701Cookie.load(std::memory_order_acquire);
    if (cookie == 0 ||
        gR7f701Denied.load(
            std::memory_order_acquire)) {
        return 0;
    }
    return R7f703(
        value ^
        cookie ^
        R7F8_D ^
        (R7F8_E << 1));
}

}
