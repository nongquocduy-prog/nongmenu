#pragma once
#import <Foundation/Foundation.h>
#import "Qr65b.h"

@interface Q66E0 : NSObject
@property(nonatomic, strong) Q65B0 *x0;
@property(nonatomic) NSInteger x1;
@end

Q66E0 *q66e9(NSArray<Q65B0 *> *z, NSMutableDictionary *b);
