#import "Qr65b.h"
#import "zx8f1a_pro.h"
#import <Foundation/Foundation.h>

@implementation Q65B0
@end

NSInteger q65b6(id v, NSInteger f) {
    if (!v || v == [NSNull null]) return f;
    if ([v isKindOfClass:[NSNumber class]]) return [(NSNumber *)v integerValue];
    if ([v isKindOfClass:[NSString class]]) return [(NSString *)v integerValue];
    return f;
}

static NSString *q65b1(id v) {
    if (!v || v == [NSNull null]) return @"";
    NSString *s = [v isKindOfClass:[NSString class]] ? (NSString *)v : [v description];
    return s.lowercaseString ?: @"";
}

static BOOL q65b2(id v, int n) {
    if (!v || v == [NSNull null] || n > 12) return NO;
    if ([v isKindOfClass:[NSString class]]) {
        NSString *s = q65b1(v);
        return ([s containsString:zxv_p07()] || [s containsString:zxv_p08()]);
    }
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSDictionary *d = (NSDictionary *)v;
        for (id k in d) {
            NSString *s = q65b1(k);
            if ([s containsString:zxv_p07()] || [s containsString:zxv_p08()]) return YES;
            if (q65b2(d[k], n + 1)) return YES;
        }
    } else if ([v isKindOfClass:[NSArray class]]) {
        for (id i in (NSArray *)v) if (q65b2(i, n + 1)) return YES;
    }
    return NO;
}

static BOOL q65b3(NSString *v) {
    NSString *s = v.lowercaseString ?: @"";
    return ([s containsString:zxv_p09()] && [s containsString:zxv_p10()]);
}

static BOOL q65b4(NSString *v) {
    NSString *s = v.lowercaseString ?: @"";
    return ([s isEqualToString:zxv_p11()] ||
            [s isEqualToString:zxv_p12()] ||
            [s isEqualToString:zxv_p13()] ||
            [s isEqualToString:zxv_p14()] ||
            [s isEqualToString:zxv_p15()] ||
            [s isEqualToString:zxv_p16()] ||
            [s isEqualToString:zxv_p17()] ||
            [s isEqualToString:zxv_p18()] ||
            [s isEqualToString:zxv_p19()] ||
            [s isEqualToString:zxv_p20()] ||
            [s isEqualToString:zxv_p21()] ||
            [s isEqualToString:zxv_p22()]);
}

static BOOL q65b5(id v, int n) {
    if (!v || v == [NSNull null] || n > 8) return NO;
    if ([v isKindOfClass:[NSString class]]) return q65b3((NSString *)v);
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSDictionary *d = (NSDictionary *)v;
        for (id k in d) {
            NSString *s = [k isKindOfClass:[NSString class]] ? (NSString *)k : [k description];
            if (q65b3(s)) return YES;
            id x = d[k];
            if ([x isKindOfClass:[NSDictionary class]] || [x isKindOfClass:[NSArray class]] || [x isKindOfClass:[NSString class]]) {
                if (q65b5(x, n + 1)) return YES;
            }
        }
    } else if ([v isKindOfClass:[NSArray class]]) {
        for (id i in (NSArray *)v) if (q65b5(i, n + 1)) return YES;
    }
    return NO;
}

static BOOL q65b7(id v, int n) {
    if (!v || v == [NSNull null] || n > 12) return NO;
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSDictionary *d = (NSDictionary *)v;
        for (id k in d) {
            NSString *s = [k isKindOfClass:[NSString class]] ? (NSString *)k : [k description];
            id x = d[k];
            if (q65b4(s) && q65b5(x, 0)) return YES;
            if ([x isKindOfClass:[NSDictionary class]] || [x isKindOfClass:[NSArray class]]) {
                if (q65b7(x, n + 1)) return YES;
            }
        }
    } else if ([v isKindOfClass:[NSArray class]]) {
        for (id i in (NSArray *)v) if (q65b7(i, n + 1)) return YES;
    }
    return NO;
}

static NSInteger q65b8(NSDictionary *d, NSArray<NSString *> *ks, NSInteger f) {
    if (![d isKindOfClass:[NSDictionary class]]) return f;
    for (NSString *w in ks) {
        id v = d[w];
        NSInteger n = q65b6(v, NSIntegerMin);
        if (n != NSIntegerMin) return n;
    }
    for (NSString *w in ks) {
        NSString *lw = w.lowercaseString ?: @"";
        for (id rk in d) {
            NSString *s = [rk isKindOfClass:[NSString class]] ? (NSString *)rk : [rk description];
            if ([s.lowercaseString isEqualToString:lw]) return q65b6(d[rk], f);
        }
    }
    return f;
}

static NSInteger q65c0(NSDictionary *d) {
    return q65b8(d, @[zxv_p23(), zxv_p24(), zxv_p25(), zxv_p26(), zxv_p27()], -1);
}

static NSInteger q65c1(NSDictionary *d) {
    return q65b8(d, @[zxv_p28(), zxv_p29(), zxv_p30(), zxv_p31(), zxv_p32(), zxv_p33()], -1);
}

static void q65c2(id v, NSMutableArray<Q65B0 *> *o, int n) {
    if (!v || v == [NSNull null] || n > 16 || ![o isKindOfClass:[NSMutableArray class]] || o.count >= 80) return;
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSDictionary *d = (NSDictionary *)v;
        id z = d[zxv_p34()];
        if ([z isKindOfClass:[NSDictionary class]]) {
            NSDictionary *m = (NSDictionary *)z;
            for (id rk in m) {
                if (o.count >= 80) break;
                id bo = m[rk];
                if (![bo isKindOfClass:[NSDictionary class]]) continue;
                NSDictionary *b = (NSDictionary *)bo;
                BOOL a = q65b2(b, 0);
                BOOL c = a ? NO : q65b7(b, 0);
                if (!a && !c) continue;
                NSInteger x = q65c0(b);
                NSInteger y = q65c1(b);
                if (x < 0 || y <= 0) continue;
                Q65B0 *r = [Q65B0 new];
                r.x0 = [rk isKindOfClass:[NSString class]] ? (NSString *)rk : [rk description];
                r.x1 = x;
                r.x2 = y;
                [o addObject:r];
            }
        }
        for (id k in d) {
            id x = d[k];
            if (x == z) continue;
            if ([x isKindOfClass:[NSDictionary class]] || [x isKindOfClass:[NSArray class]]) q65c2(x, o, n + 1);
            if (o.count >= 80) break;
        }
    } else if ([v isKindOfClass:[NSArray class]]) {
        NSArray *a = (NSArray *)v;
        NSUInteger lim = MIN((NSUInteger)80, a.count);
        for (NSUInteger i = 0; i < lim; i++) {
            q65c2(a[i], o, n + 1);
            if (o.count >= 80) break;
        }
    }
}

NSArray<Q65B0 *> *q65b9(id v) {
    NSMutableArray<Q65B0 *> *o = [NSMutableArray array];
    q65c2(v, o, 0);
    return o;
}
