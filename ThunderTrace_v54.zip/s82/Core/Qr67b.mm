#import "Qr67b.h"
#import "Qr65b.h"
#import <Foundation/Foundation.h>

static BOOL q67b0(id v) {
    return (q67a1(v, q67k42(), 0) || q67a1(v, q67k43(), 0) || q67a1(v, q67k44(), 0));
}

static BOOL q67b1(id v) {
    return (q67a1(v, q67k45(), 0) || q67a1(v, q67k46(), 0) || q67a1(v, q67k47(), 0) || q67a1(v, q67k48(), 0));
}

static NSInteger q67b2(NSDictionary *d) {
    return q67a2(d, @[q67k12(), q67k13(), q67k14(), q67k15(), q67k16(), q67k17(), q67k18()], -1);
}

static NSInteger q67b3(NSDictionary *d) {
    return q67a2(d, @[q67k19(), q67k20(), q67k21(), q67k22(), q67k23(), q67k24(), q67k25(), q67k26()], -1);
}

static BOOL q67b4(NSInteger a, NSInteger b) {
    return (a >= 0 && b > 0 && a <= b && b < 2000000000);
}

static NSString *q67b5(NSDictionary *d, NSDictionary *b) {
    if (![d isKindOfClass:[NSDictionary class]] || ![b isKindOfClass:[NSDictionary class]]) return nil;
    NSArray *k = @[q67k0(), q67k1(), q67k2(), q67k3(), q67k4(), q67k5(), q67k6(), q67k7(), q67k8(), q67k9()];
    for (NSString *x in k) {
        id v = d[x];
        if ([v isKindOfClass:[NSString class]] && b[v]) return v;
    }
    for (id rk in d) {
        NSString *z = q67a0(rk);
        if (!([z containsString:q67k0()] || [z containsString:q67k5()] || [z containsString:q67k12()])) continue;
        id v = d[rk];
        if ([v isKindOfClass:[NSString class]] && b[v]) return v;
    }
    return nil;
}

static BOOL q67b6(NSString *p) {
    NSString *s = q67a0(p);
    return ([s containsString:q67k27()] || [s containsString:q67k28()] || [s containsString:q67k29()] || [s containsString:q67k30()] || [s containsString:q67k31()] || [s containsString:q67k32()]);
}

static BOOL q67b7(NSString *p, int d) {
    if (q67b6(p)) return NO;
    return d <= 2;
}

void q67b9(id v, NSMutableArray<Q67A0 *> *m, NSMutableArray<Q67A0 *> *s, NSString *p, int d) {
    if (!v || v == [NSNull null] || d > 18 || m.count >= 96 || s.count >= 96) return;
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSDictionary *x = (NSDictionary *)v;
        id z = nil;
        for (id rk in x) {
            NSString *l = q67a0(rk);
            if ([l isEqualToString:q67k10()] || [l isEqualToString:q67k11()]) { z = x[rk]; break; }
        }
        if ([z isKindOfClass:[NSDictionary class]]) {
            NSDictionary *bd = (NSDictionary *)z;
            NSString *a = q67b5(x, bd);
            BOOL ok = q67b7(p ?: @"", d);
            for (id key in bd) {
                if (m.count >= 96 || s.count >= 96) break;
                id o = bd[key];
                if (![o isKindOfClass:[NSDictionary class]]) continue;
                NSDictionary *bar = (NSDictionary *)o;
                if (!q67b0(bar) || q67b1(bar)) continue;
                NSInteger c = q67b2(bar);
                NSInteger t = q67b3(bar);
                if (!q67b4(c, t)) continue;
                NSString *bid = [key isKindOfClass:[NSString class]] ? (NSString *)key : [key description];
                Q67A0 *r = [Q67A0 new];
                r.x0 = bid ?: @"";
                r.x1 = c;
                r.x2 = t;
                r.x3 = (a.length && [a isEqualToString:bid]);
                r.x4 = ok;
                r.x5 = (r.x3 ? 1000 : 0) + (c > 0 ? 8 : 0) + (ok ? 100 : 0);
                [(ok ? m : s) addObject:r];
            }
        }
        for (id rk in x) {
            id child = x[rk];
            if (child == z) continue;
            NSString *ks = [rk isKindOfClass:[NSString class]] ? (NSString *)rk : [rk description];
            NSString *np = [NSString stringWithFormat:q67k38(), p ?: q67k37(), ks ?: @"?"];
            q67b9(child, m, s, np, d + 1);
            if (m.count >= 96 || s.count >= 96) break;
        }
    } else if ([v isKindOfClass:[NSArray class]]) {
        NSArray *a = (NSArray *)v;
        NSUInteger lim = MIN((NSUInteger)80, a.count);
        for (NSUInteger i = 0; i < lim; i++) {
            NSString *np = [NSString stringWithFormat:q67k39(), p ?: q67k37(), (unsigned long)i];
            q67b9(a[i], m, s, np, d + 1);
            if (m.count >= 96 || s.count >= 96) break;
        }
    }
}
