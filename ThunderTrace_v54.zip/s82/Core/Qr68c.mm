#include "Qr68c.h"
int q6slot(int *p){ if(!p) return 0; int r=(*p)%5; if(r<0) r=0; *p=(r+1)%5; return r; }
int q6phase(int s,int r,int p){ int v=(s&7)|((r&1)<<3)|((p&1)<<4); return v ^ 0x2d; }

bool q6gb(uint32_t tag){ volatile uint32_t v=(tag+0xA5A5A5A5u)^0xC001D00Du; v=(v<<5)|(v>>27); return ((v^0x13579BDFu)|1u)&1u; }
bool q6gc(uint32_t tag){ volatile uint32_t v=(tag*33u)+0x5BD1E995u; v^=(v>>11); return ((v+0x2468ACE0u)|1u)&1u; }
