#import <Foundation/Foundation.h>
#pragma once

namespace Ongnong {
NSString *ExpeditionTraceText(void);
void ExpeditionTraceClear(void);
void R7f411(void);
void R7f412(void);
bool R7f413(void);
void R7f414(bool enabled);
}

#define InstallExpeditionAutoHooks R7f411
#define ExpeditionAutoTick R7f412
#define ExpeditionAutoIsEnabled R7f413
#define ExpeditionAutoSetEnabled R7f414
