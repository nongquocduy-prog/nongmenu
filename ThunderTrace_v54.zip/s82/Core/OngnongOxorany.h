#pragma once
#import <Foundation/Foundation.h>
#include "R7f8.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static inline NSString *onx76_make(const uint8_t *a, const uint8_t *b, size_t n, uint8_t k) {
    if (!a || !b || n == 0) return @"";
    char stackBuf[256];
    char *out = (n < sizeof(stackBuf)) ? stackBuf : (char *)malloc(n + 1);
    if (!out) return @"";
    for (size_t i = 0; i < n; i++) out[i] = (char)(a[i] ^ b[i] ^ (uint8_t)(k + (i * 17)));
    out[n] = 0;
    NSString *s = [[NSString alloc] initWithBytes:out length:n encoding:NSUTF8StringEncoding] ?: @"";
    memset(out, 0, n + 1);
    if (out != stackBuf) free(out);
    return s;
}

static inline NSString *onx76_mix(NSString *s) {
    if (![s isKindOfClass:[NSString class]] || s.length == 0) return @"";
    NSData *d = [s dataUsingEncoding:NSUTF8StringEncoding];
    if (d.length == 0) return @"";
    NSMutableData *m = [d mutableCopy];
    volatile uint8_t *p = (volatile uint8_t *)m.mutableBytes;
    for (NSUInteger i = 0; i < m.length; i++) p[i] = (uint8_t)(p[i] ^ 0x00);
    return [[NSString alloc] initWithData:m encoding:NSUTF8StringEncoding] ?: @"";
}

#ifdef __cplusplus
namespace ongnong_ox {
#if defined(__clang__) && __has_attribute(optnone)
#define ONX76_RUNTIME __attribute__((noinline, optnone))
#else
#define ONX76_RUNTIME __attribute__((noinline))
#endif
ONX76_RUNTIME static void decode_bytes(
    const char *input,
    char *output,
    unsigned count,
    uint32_t key) {
    if (!input || !output || count == 0) return;
    volatile const char *source = input;
    volatile uint32_t runtimeKey = key;
    for (unsigned i = 0; i < count; ++i) {
        uint32_t x =
            runtimeKey ^
            (0xA5B35705u + i * 0x9E3779B9u);
        x ^= x >> 16;
        x *= 0x7FEB352Du;
        x ^= x >> 15;
        x *= 0x846CA68Bu;
        x ^= x >> 16;
        volatile uint8_t mask =
            (uint8_t)(x ^ (x >> 8) ^ (i * 37u));
        output[i] =
            (char)((uint8_t)source[i] ^ mask);
    }
    __asm__ __volatile__("" : : "r"(output) : "memory");
}
template <unsigned N, unsigned K>
struct blob {
    char v[N];
    static constexpr uint8_t m(unsigned i) {
        uint32_t x = (uint32_t)K ^
                     (0xA5B35705u + i * 0x9E3779B9u);
        x ^= x >> 16;
        x *= 0x7FEB352Du;
        x ^= x >> 15;
        x *= 0x846CA68Bu;
        x ^= x >> 16;
        return (uint8_t)(x ^
                         (x >> 8) ^
                         (i * 37u));
    }
    constexpr blob(const char (&s)[N]) : v{} {
        for (unsigned i = 0; i < N; ++i) {
            v[i] = (char)((uint8_t)s[i] ^ m(i));
        }
    }
    NSString *ns() const {
        char out[N];
        decode_bytes(v, out, N, K);
        NSString *s = [[NSString alloc] initWithBytes:out length:(N ? N - 1 : 0) encoding:NSUTF8StringEncoding] ?: @"";
        memset(out, 0, sizeof(out));
        return s;
    }
    const char *c() const {
        thread_local char out[N];
        decode_bytes(v, out, N, K);
        return out;
    }
};
#undef ONX76_RUNTIME
}
#define OX_KEY_(L) ((unsigned)((L * 2654435761u) ^ 0x9E3779B9u ^ (__COUNTER__ * 0x45d9f3bu) ^ (uint32_t)R7F8_E))
#define OX_NS(S) ([](){ static constexpr ongnong_ox::blob<sizeof(S), OX_KEY_(__LINE__)> _b(S); return _b.ns(); }())
#define OX_C(S) ([](){ static constexpr ongnong_ox::blob<sizeof(S), OX_KEY_(__LINE__)> _b(S); return _b.c(); }())
#endif
