#import "R7f4.h"
#import "OngnongOxorany.h"
#import "zx8f1a_gate.h"
#import "../UI/OngnongUIVault.h"
#include <stdint.h>

namespace Ongnong {

BOOL R7f401(void) {
    return Zx8fExpeditionAllowed();
}

NSString *R7f402(void) {
    return OngnongUIVaultText(
        OngnongUIVaultAutoExpedition);
}

NSString *R7f403(BOOL enabled) {
    return OngnongUIVaultText(
        enabled
            ? OngnongUIVaultAutoExpeditionOn
            : OngnongUIVaultAutoExpeditionOff);
}

NSString *R7f404(void) {
    return OX_NS("r7f4.93");
}

double R7f405(void) {
    return [NSDate timeIntervalSinceReferenceDate];
}

bool R7f406(const void *value) {
    uintptr_t raw = reinterpret_cast<uintptr_t>(value);
    return raw >= 0x10000 &&
           (raw & (sizeof(uintptr_t) - 1)) == 0;
}

}
