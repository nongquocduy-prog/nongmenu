#import "R7f5.h"
#import "OngnongOxorany.h"
#import "R7f4.h"
#import "R7f7.h"
#import "R7f8.h"
#import "zx8f1a_gate.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <atomic>
#import <mutex>
#import <dlfcn.h>
#import <cstdio>
#import <cstdlib>
#import <cstring>
#import <cctype>
#import "../Helper/Il2cpp.h"

namespace Ongnong {

static const char *R7f432(void) {
    return OX_C("MoonActive.Minigame.Expedition");
}

enum class AutoPhase : int {
    Idle = 0,
    WaitingGameSelection = 1,
    WaitingTooltip = 2,
    WaitingResult = 3,
    WaitingPortalAction = 4,
    WaitingMapTransition = 5,
    WaitingTaskRedirect = 6,
    WaitingTaskRouteSelection = 7
};

using RegisterObjectCallbackFn =
    void (*)(void **objects, int count, void *userData);
using LivenessReallocateFn =
    void *(*)(void *memory, size_t size, void *userData);
using LivenessAllocateFn =
    void *(*)(void *filterClass,
              int maxObjectCount,
              RegisterObjectCallbackFn callback,
              void *userData,
              LivenessReallocateFn reallocate);
using LivenessFromStaticsFn = void (*)(void *state);
using LivenessFinalizeFn = void (*)(void *state);
using LivenessFreeFn = void (*)(void *state);
using GCHandleNewFn = uint32_t (*)(void *object, bool pinned);
using GCHandleFreeFn = void (*)(uint32_t handle);
using ResolveIcallFn = void *(*)(const char *name);
using ClassGetTypeFn = void *(*)(void *klass);
using TypeGetObjectFn = void *(*)(void *type);
using FindObjectsOfType2Fn =
    monoArray<void *> *(*)(void *typeObject, bool includeInactive);
using FindObjectsOfType1Fn =
    monoArray<void *> *(*)(void *typeObject);
using ClassGetMethodsFn =
    void *(*)(void *klass, void **iterator);
using MethodGetNameFn =
    const char *(*)(void *method);
using MethodGetParamCountFn =
    uint32_t (*)(void *method);
using MethodIsGenericFn =
    bool (*)(const MethodInfo *method);

static std::atomic<bool> gEnabled{false};
static std::atomic<bool> gRuntimeReady{false};
static std::atomic<bool> gInstallStarted{false};
static std::atomic<unsigned long long>
    gManagerScanGeneration{1};
static std::atomic<unsigned long long>
    gManagerScanPendingGeneration{0};
static std::atomic<bool> gStepScheduled{false};
static std::atomic<unsigned long long> gAutoRunGeneration{1};
static std::atomic<void *> gSelectionManager{nullptr};
static std::atomic<void *> gTooltipController{nullptr};
static std::atomic<void *> gInfoModel{nullptr};
static std::atomic<void *> gInventoryManager{nullptr};
static std::atomic<void *> gButtonsController{nullptr};
static std::atomic<void *> gStagePopupController{nullptr};
static std::atomic<void *> gBossWheelHolder{nullptr};
static std::atomic<void *> gBossActionButton{nullptr};
static std::atomic<void *> gBossUiLocker{nullptr};
static std::atomic<Il2CppString *> gCurrentTarget{nullptr};
static std::atomic<uint32_t> gManagerHandle{0};
static std::atomic<uint32_t> gButtonsControllerHandle{0};
static std::atomic<uint32_t> gStagePopupControllerHandle{0};
static std::atomic<uint32_t> gBossWheelHolderHandle{0};
static std::atomic<uint32_t> gBossActionButtonHandle{0};
static std::atomic<uint32_t> gBossUiLockerHandle{0};
static std::atomic<uint32_t> gTargetHandle{0};
static std::atomic<uint32_t> gActionDataHandle{0};
struct RetiredActionHandle {
    uint32_t handle = 0;
    double releaseAt = 0.0;
};
static RetiredActionHandle gRetiredActionHandles[256] = {};
static std::mutex gActionHandleMutex;
static std::atomic<int> gManagerScanAttempts{0};
static std::atomic<int> gRuntimeQueryFailures{0};
static std::atomic<int> gPhase{static_cast<int>(AutoPhase::Idle)};
static std::atomic<double> gPhaseStartedAt{0.0};
static std::atomic<double> gNextStepAt{0.0};
static std::atomic<double> gLastResultPollAt{0.0};
static std::atomic<double> gRouteIssuedAt{0.0};
static std::atomic<double> gLastTooltipTargetScanAt{0.0};
static std::atomic<bool> gDirectFallbackUsed{false};
static std::atomic<bool> gRouteInvocationIssued{false};
static std::atomic<bool> gWaitForNativeContinuation{false};
static std::atomic<bool> gCurrencyChecked{false};
static std::atomic<bool> gStagePopupCloseIssued{false};
static std::atomic<bool> gStagePopupLookupAttempted{false};
static std::atomic<bool> gAutoSelectIssued{false};
static std::atomic<bool> gProgressNavigationIssued{false};
static std::atomic<bool> gTransitionReleaseIssued{false};
static std::atomic<double> gAutoSelectIssuedAt{0.0};
static std::atomic<double> gNextManagerScanAllowedAt{0.0};
static std::atomic<double> gManagerScanReadyAt{0.0};
static std::atomic<bool> gTransitionChangeObserved{false};
static std::atomic<int> gTransitionStableSamples{0};
static std::atomic<int> gTransitionStartChapter{-1};
static std::atomic<int> gTransitionLastChapter{-1};
static std::atomic<double> gTransitionChangeObservedAt{0.0};
static std::atomic<double> gNextTransitionPollAt{0.0};
static std::atomic<double> gNextStagePopupLookupAt{0.0};
static std::atomic<bool> gUseConstructedActionData{false};
static std::atomic<bool> gCurrentActionUsedFresh{false};
static std::atomic<bool> gForceFreshActionNext{false};
static std::atomic<bool> gForceRouteRefresh{false};
static std::atomic<bool> gRequireSelectionChange{false};
static std::atomic<int> gResultRecoveryAttempts{0};
static std::atomic<double> gPortalRouteStartedAt{0.0};
static std::atomic<double> gNextPortalActionAt{0.0};
static std::atomic<int> gPortalActionAttempts{0};
static std::atomic<bool> gPortalActionInvoked{false};
static std::atomic<double> gNextPortalFlagAt{0.0};
static std::atomic<int> gPortalFlagAttempts{0};
static std::atomic<int> gTaskFlowAttempts{0};
static std::atomic<bool> gTaskFlowActive{false};
static std::atomic<bool> gTaskDetectedFromNotEnough{false};
static std::atomic<bool> gTaskClassificationRejected{false};
static std::atomic<bool> gCustomFlowObservedActive{false};
static std::atomic<int> gLastCustomFlowState{-1};
static std::atomic<bool> gBossAutoModeRequested{false};
static std::atomic<bool> gBossManualAttackMode{false};
static std::atomic<double> gNextBossUiLookupAt{0.0};
static std::atomic<double> gNextBossActionAt{0.0};
static std::atomic<int> gBossManualAttackCount{0};
static std::atomic<bool> gTaskCompletionAttempted{false};
static std::atomic<double> gTaskFlowStartedAt{0.0};
static std::atomic<double> gNextTaskCompletionCheckAt{0.0};
static std::atomic<double> gNextTaskFlowAttemptAt{0.0};
static std::atomic<bool> gTaskJourneyActive{false};
static std::atomic<bool> gTaskReturningToRoot{false};
static std::atomic<Il2CppString *> gTaskRootTarget{nullptr};
static std::atomic<uint32_t> gTaskRootHandle{0};
static std::atomic<Il2CppString *> gTaskSourceTarget{nullptr};
static std::atomic<uint32_t> gTaskSourceHandle{0};
static std::atomic<double> gTaskRouteStartedAt{0.0};
static std::atomic<double> gNextTaskRouteActionAt{0.0};
static std::atomic<double> gNextTaskRouteCurrencyCheckAt{0.0};
static std::atomic<int> gTaskRouteRootCurrencyState{-1};
static std::atomic<int> gTaskRouteFlagAttempts{0};
static std::atomic<bool> gTaskSourceSelectionIssued{false};
static std::atomic<bool> gResumeRouteAfterStagePopup{false};
static std::atomic<double> gResumeRouteAfterStagePopupAt{0.0};
static std::atomic<double> gCompletedTargetQuarantineUntil{0.0};
static char gCompletedTargetText[128] = {0};

static constexpr int kMaxManagerScanAttempts = 20;
static constexpr double kSelectionTimeout = 30.0;
static constexpr double kTooltipTimeout = 25.0;
static constexpr double kResultTimeout = 0.80;
static constexpr double kCollectReadyDelay = 0.015;
static constexpr double kResultFirstPollDelay = 0.04;
static constexpr double kResultPollInterval = 0.04;
static constexpr double kNextTargetDelay = 0.02;
static constexpr double kResultRecoveryDelay = 0.35;
static constexpr int kResultMaxRetries = 3;
static constexpr double kNativeContinuationDelay = 0.10;
static constexpr double kAutoSelectFallbackDelay = 0.16;
static constexpr double kProgressRouteDelayAfterAutoSelect = 2.0;
static constexpr double kMapTransitionMinimumQuiet = 3.0;
static constexpr double kMapTransitionPostChangeQuiet = 4.0;
static constexpr double kMapTransitionPollInterval = 0.5;
static constexpr double kMapTransitionTimeout = 45.0;
static constexpr double kMapTransitionNoChangeRecovery = 12.0;
static constexpr double kStagePopupRouteResumeDelay = 0.65;
static constexpr int kMapTransitionStableSamples = 4;
static constexpr double kManagerInitialWarmup = 3.0;
static constexpr double kManagerScanInterval = 2.25;
static constexpr double kPortalActionFirstDelay = 0.15;
static constexpr double kPortalActionRetryInterval = 0.35;
static constexpr double kPortalFlagFirstDelay = 0.8;
static constexpr double kPortalFlagRetryInterval = 1.5;
static constexpr double kPortalTooltipTimeout = 18.0;
static constexpr int kPortalActionMaxAttempts = 3;
static constexpr int kPortalFlagMaxAttempts = 3;
static constexpr double kTaskFlowRetryDelay = 0.75;
static constexpr double kTaskCompletionCheckDelay = 3.0;
static constexpr double kTaskFlowTimeout = 9.0;
static constexpr int kTaskFlowMaxAttempts = 3;
static constexpr double kTaskRouteInitialDelay = 0.35;
static constexpr double kTaskRouteSelectSettleDelay = 0.18;
static constexpr double kTaskRouteFlagRetryDelay = 0.45;
static constexpr double kTaskRouteCurrencyCheckInterval = 0.45;
static constexpr double kTaskRouteTimeout = 18.0;
static constexpr int kTaskRouteMaxFlagAttempts = 5;
static constexpr double kActionHandleRetention = 30.0;
static constexpr double kBossUiLookupInterval = 0.45;
static constexpr double kBossAutoModeRetryDelay = 1.25;
static constexpr double kBossManualAttackInterval = 1.10;
static constexpr int kBossObjectScanLimit = 24;

static LivenessAllocateFn gLivenessAllocate = nullptr;
static LivenessFromStaticsFn gLivenessFromStatics = nullptr;
static LivenessFinalizeFn gLivenessFinalize = nullptr;
static LivenessFreeFn gLivenessFree = nullptr;
static GCHandleNewFn gGCHandleNew = nullptr;
static GCHandleFreeFn gGCHandleFree = nullptr;
static ResolveIcallFn gResolveIcall = nullptr;
static ClassGetTypeFn gClassGetType = nullptr;
static TypeGetObjectFn gTypeGetObject = nullptr;
static FindObjectsOfType2Fn gFindObjectsOfType2 = nullptr;
static FindObjectsOfType1Fn gFindObjectsOfType1 = nullptr;
static ClassGetMethodsFn gClassGetMethods = nullptr;
static MethodGetNameFn gMethodGetName = nullptr;
static MethodGetParamCountFn gMethodGetParamCount = nullptr;
static MethodIsGenericFn gMethodIsGeneric = nullptr;

static void *gManagerClass = nullptr;
static const char *gManagerImageName = nullptr;
static size_t gManagerTooltipOffset = SIZE_MAX;
static size_t gManagerInfoModelOffset = SIZE_MAX;
static size_t gManagerInventoryOffset = SIZE_MAX;
static size_t gManagerStateModelOffset = SIZE_MAX;
static size_t gInfoSelectedInteractionIdOffset = SIZE_MAX;
static size_t gInfoCurrentChapterIndexOffset = SIZE_MAX;
static size_t gTooltipLastTargetOffset = SIZE_MAX;
static size_t gTooltipSelectedArrowIdOffset = SIZE_MAX;
static size_t gTooltipOutOfCurrencyControllerOffset = SIZE_MAX;
static size_t gTooltipDataProviderOffset = SIZE_MAX;
static size_t gTooltipProviderCustomModelOffset = SIZE_MAX;
static size_t gInteractionDataTypeOffset = SIZE_MAX;
static void *gButtonsControllerClass = nullptr;
static size_t gButtonsInfoModelOffset = SIZE_MAX;
static size_t gButtonsAllStageGatesPassedOffset = SIZE_MAX;
static void *gStageCompletePhaseClass = nullptr;
static size_t gStagePhaseInfoModelOffset = SIZE_MAX;
static size_t gStagePhasePopupControllerOffset = SIZE_MAX;
static void *gActionDataClass = nullptr;
static const char *gActionDataImageName = nullptr;
static size_t gActionDataIdOffset = SIZE_MAX;
static void *gTeleportActionDataClass = nullptr;
static const char *gTeleportActionDataImageName = nullptr;
static void *gCustomActionDataClass = nullptr;
static const char *gCustomActionDataImageName = nullptr;
static void *gNotEnoughActionDataClass = nullptr;
static const char *gNotEnoughActionDataImageName = nullptr;
static size_t gNotEnoughActionDataIdOffset = SIZE_MAX;
static void *gBossWheelHolderClass = nullptr;
static void *gBossWheelHolderType = nullptr;
static size_t gBossWheelContainersOffset = SIZE_MAX;
static size_t gBossContainersActionButtonOffset = SIZE_MAX;
static size_t gBossButtonDisableAutoOffset = SIZE_MAX;
static size_t gBossButtonIsAutoModeOffset = SIZE_MAX;
static size_t gBossButtonEventIdOffset = SIZE_MAX;
static void *gBossUiLockerClass = nullptr;
static void *gBossUiLockerType = nullptr;
static size_t gBossUiLockerOverlayOffset = SIZE_MAX;
static size_t gBossUiLockerEventIdOffset = SIZE_MAX;

static MethodInfo *gAutoSelectNextInteractionMethod = nullptr;
static MethodInfo *gSelectInteractionMethod = nullptr;
static MethodInfo *gGetSelectedInteractionIdMethod = nullptr;
static MethodInfo *gIsPassedInteractionMethod = nullptr;
static MethodInfo *gTooltipIsOpenMethod = nullptr;
static MethodInfo *gTooltipCloseMethod = nullptr;
static MethodInfo *gGetTooltipTargetIdMethod = nullptr;
static MethodInfo *gExecuteInteractionActionMethod = nullptr;
static MethodInfo *gFlagButtonPressedMethod = nullptr;
static MethodInfo *gProgressMapButtonPressedMethod = nullptr;
static MethodInfo *gStageProgressNavigationMethod = nullptr;
static MethodInfo *gIsEnoughCurrencyForAnyMethod = nullptr;
static MethodInfo *gIsEnoughCurrencyForInteractionMethod = nullptr;
static MethodInfo *gStagePopupIsOpenMethod = nullptr;
static MethodInfo *gStagePopupCloseMethod = nullptr;
static MethodInfo *gActionDataCtorMethod = nullptr;
static MethodInfo *gTeleportActionDataCtorMethod = nullptr;
static MethodInfo *gExecuteTeleportActionMethod = nullptr;
static MethodInfo *gCustomActionDataCtorMethod = nullptr;
static MethodInfo *gCustomEnteredWithoutTooltipSetter = nullptr;
static MethodInfo *gEnterCustomInteractionFlowMethod = nullptr;
static MethodInfo *gExecuteTooltipActionMethod = nullptr;
static MethodInfo *gCanNavigateForSourceMethod = nullptr;
static MethodInfo *gIsTeleportGateSpawnIdMethod = nullptr;
static MethodInfo *gShowAutoOutOfCurrencyMethod = nullptr;
static MethodInfo *gGetExpeditionStateMethod = nullptr;
static MethodInfo *gGetCustomInteractionDataMethod = nullptr;
static MethodInfo *gGetInteractionDataByIdMethod = nullptr;
static MethodInfo *gBossSendAutoModeMethod = nullptr;
static MethodInfo *gBossActionButtonDownMethod = nullptr;
static MethodInfo *gBossActionButtonUpMethod = nullptr;
static MethodInfo *gGameObjectActiveInHierarchyMethod = nullptr;

static NSString *gStatus = OX_NS("ĐANG KHỞI TẠO");
static NSString *gPrepareFailureStatus =
    OX_NS("ĐANG NẠP CLASS HOANG ĐỊA");
static std::mutex gTargetTextMutex;
static char gCurrentTargetText[128] = {0};
static char gSelectionBeforeText[128] = {0};
static char gActiveMapKey[96] = {0};
static char gTransitionStartMapKey[96] = {0};
static char gTransitionLastMapKey[96] = {0};
static char gPortalPreviousTargetText[128] = {0};
static char gResultRecoveryTargetText[128] = {0};
static char gTaskRootTargetText[128] = {0};
static char gTaskSourceTargetText[128] = {0};

#define Now R7f405
#define IsPlausiblePointer R7f406

static std::atomic<uint64_t> gR7f430{
    R7F8_A};

static __attribute__((always_inline))
inline bool R7f431(uint64_t tag) {
    uint64_t sequence =
        gR7f430.fetch_add(
            0x9E3779B97F4A7C15ULL,
            std::memory_order_relaxed);
    double moment = Now();
    uint64_t timeBits = 0;
    memcpy(&timeBits, &moment, sizeof(timeBits));
    uint64_t callsite =
        (uint64_t)(uintptr_t)__builtin_return_address(0);
    uint64_t challenge =
        tag ^
        sequence ^
        timeBits ^
        callsite ^
        (uint64_t)(uintptr_t)&gEnabled ^
        R7F8_B;
    challenge ^= challenge >> 29;
    challenge *= 0xD6E8FEB86659FD93ULL;
    challenge ^= challenge >> 32;
    if (!R7f701() || !R7f401()) return false;
    uint64_t seal = R7f702(
        challenge ^ tag ^ R7F8_E);
    if (seal == 0) return false;
    challenge ^= seal;
    uint64_t response = R7f408(challenge);
    if (response == 0 ||
        !R7f409(challenge, response)) {
        return false;
    }
    uint64_t tail = R7f702(
        response ^ seal ^ tag);
    return tail != 0;
}

static unsigned long long BeginManagerScanSession(
    double warmupDelay) {
    unsigned long long generation =
        gManagerScanGeneration.fetch_add(1) + 1;
    gManagerScanPendingGeneration.store(0);
    gManagerScanAttempts.store(0);
    gNextManagerScanAllowedAt.store(0.0);
    gManagerScanReadyAt.store(
        warmupDelay > 0.0
            ? Now() + warmupDelay
            : 0.0);
    return generation;
}

static bool ManagerScanSessionActive(
    unsigned long long generation) {
    return generation != 0 &&
           gManagerScanGeneration.load() == generation &&
           gEnabled.load() &&
           gRuntimeReady.load();
}

static bool ManagerScanSessionReady(
    unsigned long long generation) {
    return ManagerScanSessionActive(generation) &&
           !gSelectionManager.load() &&
           Now() >= gManagerScanReadyAt.load();
}

static void ReleaseManagerScanPending(
    unsigned long long generation) {
    unsigned long long expected = generation;
    gManagerScanPendingGeneration.compare_exchange_strong(
        expected,
        0);
}

static void HdTrace(NSString *event, NSString *detail) {
    (void)event;
    (void)detail;
}
NSString *ExpeditionTraceText(void) {
    return @"";
}
void ExpeditionTraceClear(void) {
}
static void SetStatus(NSString *status) {
    if (!status.length) return;

    bool changed = false;
    @synchronized ([NSObject class]) {
        if (![gStatus isEqualToString:status]) {
            gStatus = [status copy];
            changed = true;
        }
    }
    if (!changed) return;
    HdTrace(@"STATUS", status);

    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter]
            postNotificationName:R7f404()
                          object:nil];
    });
}

static void FreeHandle(std::atomic<uint32_t> &slot) {
    uint32_t handle = slot.exchange(0);
    if (handle && gGCHandleFree) {
        gGCHandleFree(handle);
    }
}

static void RetainObject(void *object,
                         std::atomic<uint32_t> &slot) {
    FreeHandle(slot);
    if (object && gGCHandleNew) {
        slot.store(gGCHandleNew(object, false));
    }
}

static void SweepRetiredActionHandles(bool force) {
    if (!gGCHandleFree) return;
    double now = Now();
    std::lock_guard<std::mutex> lock(gActionHandleMutex);
    for (RetiredActionHandle &entry : gRetiredActionHandles) {
        if (!entry.handle) continue;
        if (!force && now < entry.releaseAt) continue;
        gGCHandleFree(entry.handle);
        entry.handle = 0;
        entry.releaseAt = 0.0;
    }
}

static void RetireCurrentActionHandle(void) {
    uint32_t handle = gActionDataHandle.exchange(0);
    if (!handle || !gGCHandleFree) return;

    double now = Now();
    std::lock_guard<std::mutex> lock(gActionHandleMutex);
    RetiredActionHandle *available = nullptr;
    RetiredActionHandle *oldest = nullptr;
    for (RetiredActionHandle &entry : gRetiredActionHandles) {
        if (entry.handle && now >= entry.releaseAt) {
            gGCHandleFree(entry.handle);
            entry.handle = 0;
            entry.releaseAt = 0.0;
        }
        if (!entry.handle && !available) {
            available = &entry;
        }
        if (entry.handle &&
            (!oldest || entry.releaseAt < oldest->releaseAt)) {
            oldest = &entry;
        }
    }
    if (!available) {
        available = oldest;
        if (available && available->handle) {
            gGCHandleFree(available->handle);
        }
    }
    if (!available) {
        gGCHandleFree(handle);
        return;
    }
    available->handle = handle;
    available->releaseAt = now + kActionHandleRetention;
}

static void RetainActionObject(void *object) {
    RetireCurrentActionHandle();
    if (object && gGCHandleNew) {
        gActionDataHandle.store(gGCHandleNew(object, false));
    }
}

static void DiscardCurrentActionHandle(void) {
    FreeHandle(gActionDataHandle);
}

static bool CopyManagedString(Il2CppString *value,
                              char *output,
                              size_t outputSize) {
    if (!value || !output || outputSize == 0 ||
        value->length <= 0 || value->length > 512) {
        return false;
    }

    NSString *text = [[NSString alloc]
        initWithBytes:&value->start_char
               length:static_cast<NSUInteger>(value->length) *
                      sizeof(uint16_t)
             encoding:NSUTF16LittleEndianStringEncoding];
    if (!text.length) return false;

    const char *utf8 = text.UTF8String;
    if (!utf8 || !utf8[0]) return false;
    snprintf(output, outputSize, OX_C("%s"), utf8);
    return output[0] != '\0';
}

static bool ExtractMapKey(const char *interactionId,
                          char *output,
                          size_t outputSize) {
    if (!interactionId || !interactionId[0] ||
        !output || outputSize < 2) {
        return false;
    }
    const char *marker = strstr(interactionId, OX_C("_i"));
    size_t length = marker
        ? static_cast<size_t>(marker - interactionId)
        : strlen(interactionId);
    if (length == 0 || length >= outputSize) {
        return false;
    }
    memcpy(output, interactionId, length);
    output[length] = '\0';
    return true;
}

static bool RememberOrDetectMapChange(const char *interactionId) {
    char mapKey[96] = {0};
    if (!ExtractMapKey(interactionId, mapKey, sizeof(mapKey))) {
        return false;
    }
    std::lock_guard<std::mutex> lock(gTargetTextMutex);
    if (!gActiveMapKey[0]) {
        snprintf(gActiveMapKey, sizeof(gActiveMapKey), OX_C("%s"), mapKey);
        return false;
    }
    if (strcmp(gActiveMapKey, mapKey) == 0) {
        return false;
    }
    snprintf(gActiveMapKey, sizeof(gActiveMapKey), OX_C("%s"), mapKey);
    return true;
}

static bool ManagedStringsEqual(Il2CppString *left,
                                Il2CppString *right) {
    if (!left || !right ||
        left->length <= 0 ||
        right->length <= 0 ||
        left->length != right->length ||
        left->length > 512) {
        return false;
    }
    return memcmp(
        &left->start_char,
        &right->start_char,
        static_cast<size_t>(left->length) *
            sizeof(uint16_t)) == 0;
}

static void ResetResultRecoveryState() {
    gResultRecoveryAttempts.store(0);
    gCurrentActionUsedFresh.store(false);
    gForceFreshActionNext.store(false);
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        gResultRecoveryTargetText[0] = '\0';
    }
}

static void SyncResultRecoveryTarget(const char *targetText) {
    if (!targetText || !targetText[0]) return;
    bool changed = false;
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        if (!gResultRecoveryTargetText[0] ||
            strcmp(gResultRecoveryTargetText, targetText) != 0) {
            snprintf(gResultRecoveryTargetText,
                     sizeof(gResultRecoveryTargetText),
                     OX_C("%s"),
                     targetText);
            changed = true;
        }
    }
    if (changed) {
        gResultRecoveryAttempts.store(0);
        gCurrentActionUsedFresh.store(false);
        gForceFreshActionNext.store(false);
    }
}

static int RegisterResultTimeout(const char *targetText) {
    SyncResultRecoveryTarget(targetText);
    return gResultRecoveryAttempts.fetch_add(1) + 1;
}

static void ClearCompletedTargetQuarantine() {
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        gCompletedTargetText[0] = '\0';
    }
    gCompletedTargetQuarantineUntil.store(0.0);
}

static void QuarantineCompletedTarget(const char *targetText,
                                      double seconds) {
    if (!targetText || !targetText[0]) return;
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(gCompletedTargetText,
                 sizeof(gCompletedTargetText),
                 OX_C("%s"),
                 targetText);
    }
    gCompletedTargetQuarantineUntil.store(Now() + seconds);
}

static bool IsCompletedTargetQuarantined(const char *targetText) {
    if (!targetText || !targetText[0]) return false;
    double until = gCompletedTargetQuarantineUntil.load();
    if (until <= 0.0) return false;
    if (Now() >= until) {
        ClearCompletedTargetQuarantine();
        return false;
    }
    std::lock_guard<std::mutex> lock(gTargetTextMutex);
    return gCompletedTargetText[0] &&
           strcmp(gCompletedTargetText, targetText) == 0;
}

static bool ManagedStringMatchesText(Il2CppString *value,
                                     const char *text) {
    if (!IsPlausiblePointer(value) || !text || !text[0]) {
        return false;
    }
    char valueText[128] = {0};
    return CopyManagedString(value, valueText, sizeof(valueText)) &&
           strcmp(valueText, text) == 0;
}

static bool InvokeBossButtonMethod(void *button,
                                   MethodInfo *method) {
    if (!IsPlausiblePointer(button) || !method) {
        return false;
    }
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        method,
        button,
        nullptr,
        &exception);
    if (exception) {
        return false;
    }
    return true;
}

static void ResetBossCombatState(bool requestStop) {
    void *button = gBossActionButton.load();
    bool wasAuto = false;
    if (IsPlausiblePointer(button) &&
        gBossButtonIsAutoModeOffset != SIZE_MAX) {
        wasAuto = *reinterpret_cast<bool *>(
            reinterpret_cast<uintptr_t>(button) +
            gBossButtonIsAutoModeOffset);
    }
    if (requestStop && wasAuto &&
        gBossActionButtonDownMethod) {
        InvokeBossButtonMethod(button,
                               gBossActionButtonDownMethod);
    }
    gBossWheelHolder.store(nullptr);
    gBossActionButton.store(nullptr);
    gBossUiLocker.store(nullptr);
    FreeHandle(gBossWheelHolderHandle);
    FreeHandle(gBossActionButtonHandle);
    FreeHandle(gBossUiLockerHandle);
    gBossAutoModeRequested.store(false);
    gBossManualAttackMode.store(false);
    gNextBossUiLookupAt.store(0.0);
    gNextBossActionAt.store(0.0);
    gBossManualAttackCount.store(0);
}

static void ReleaseCycleObjects(void) {
    ResetBossCombatState(false);
    FreeHandle(gTargetHandle);
    RetireCurrentActionHandle();
    gCurrentTarget.store(nullptr);
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        gCurrentTargetText[0] = '\0';
        gSelectionBeforeText[0] = '\0';
    }
    gDirectFallbackUsed.store(false);
    gCurrencyChecked.store(false);
    gTaskFlowAttempts.store(0);
    gTaskFlowActive.store(false);
    gTaskDetectedFromNotEnough.store(false);
    gTaskClassificationRejected.store(false);
    gCustomFlowObservedActive.store(false);
    gLastCustomFlowState.store(-1);
    gTaskCompletionAttempted.store(false);
    gTaskFlowStartedAt.store(0.0);
    gNextTaskCompletionCheckAt.store(0.0);
    gNextTaskFlowAttemptAt.store(0.0);
}


static void ClearTaskJourneyState() {
    gTaskRootTarget.store(nullptr);
    gTaskSourceTarget.store(nullptr);
    FreeHandle(gTaskRootHandle);
    FreeHandle(gTaskSourceHandle);
    gTaskJourneyActive.store(false);
    gTaskReturningToRoot.store(false);
    gTaskRouteStartedAt.store(0.0);
    gNextTaskRouteActionAt.store(0.0);
    gNextTaskRouteCurrencyCheckAt.store(0.0);
    gTaskRouteRootCurrencyState.store(-1);
    gTaskRouteFlagAttempts.store(0);
    gTaskSourceSelectionIssued.store(false);
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        gTaskRootTargetText[0] = '\0';
        gTaskSourceTargetText[0] = '\0';
    }
}

static bool CopyTaskJourneyIds(char *rootOut,
                               size_t rootSize,
                               char *sourceOut,
                               size_t sourceSize) {
    if (!rootOut || rootSize == 0 || !sourceOut || sourceSize == 0) {
        return false;
    }
    std::lock_guard<std::mutex> lock(gTargetTextMutex);
    snprintf(rootOut, rootSize, OX_C("%s"), gTaskRootTargetText);
    snprintf(sourceOut, sourceSize, OX_C("%s"), gTaskSourceTargetText);
    return rootOut[0] && sourceOut[0];
}

static Il2CppString *CreateTaskIdString(const char *text) {
    if (!text || !text[0]) return nullptr;
    Il2CppString *value = Il2CppString::Create(text);
    return IsPlausiblePointer(value) ? value : nullptr;
}

static bool RememberTaskRootTarget(Il2CppString *target) {
    if (!IsPlausiblePointer(target)) return false;
    char text[128] = {0};
    if (!CopyManagedString(target, text, sizeof(text))) return false;
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(gTaskRootTargetText,
                 sizeof(gTaskRootTargetText),
                 OX_C("%s"),
                 text);
    }
    gTaskRootTarget.store(nullptr);
    FreeHandle(gTaskRootHandle);
    return true;
}

static bool RememberTaskSourceTarget(Il2CppString *target) {
    if (!IsPlausiblePointer(target)) return false;
    char text[128] = {0};
    if (!CopyManagedString(target, text, sizeof(text))) return false;
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(gTaskSourceTargetText,
                 sizeof(gTaskSourceTargetText),
                 OX_C("%s"),
                 text);
    }
    gTaskSourceTarget.store(nullptr);
    FreeHandle(gTaskSourceHandle);
    return true;
}

static void ResetCycle(NSString *status, double delay) {
    ReleaseCycleObjects();
    gPhase.store(static_cast<int>(AutoPhase::Idle));
    gPhaseStartedAt.store(0.0);
    gLastResultPollAt.store(0.0);
    gRouteIssuedAt.store(0.0);
    gLastTooltipTargetScanAt.store(0.0);
    gNextStepAt.store(Now() + delay);
    gRouteInvocationIssued.store(false);
    gAutoSelectIssued.store(false);
    gAutoSelectIssuedAt.store(0.0);
    gProgressNavigationIssued.store(false);
    gTransitionReleaseIssued.store(false);
    gPortalRouteStartedAt.store(0.0);
    gNextPortalActionAt.store(0.0);
    gPortalActionAttempts.store(0);
    gPortalActionInvoked.store(false);
    gNextPortalFlagAt.store(0.0);
    gPortalFlagAttempts.store(0);
    gResumeRouteAfterStagePopup.store(false);
    gResumeRouteAfterStagePopupAt.store(0.0);
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        gPortalPreviousTargetText[0] = '\0';
    }
    if (gEnabled.load() && status.length) {
        SetStatus(status);
    }
}

static MethodInfo *FindMethodAnyImage(const char *className,
                                      const char *methodName,
                                      int argumentCount,
                                      bool searchParents,
                                      const char **imageNameOut = nullptr) {
    const char *foundImage = nullptr;
    void *klass = Il2CppFindClassAnyImage(
        R7f432(),
        className,
        &foundImage);
    if (imageNameOut) *imageNameOut = foundImage;
    if (!klass || !foundImage) return nullptr;
    return Il2CppFindMethodInfoRaw(
        foundImage,
        R7f432(),
        className,
        methodName,
        argumentCount,
        searchParents);
}

static MethodInfo *FindNonGenericMethodAnyImage(
    const char *className,
    const char *methodName,
    int argumentCount) {
    if (!gClassGetMethods ||
        !gMethodGetName ||
        !gMethodGetParamCount ||
        !gMethodIsGeneric) {
        return nullptr;
    }

    const char *imageName = nullptr;
    void *klass = Il2CppFindClassAnyImage(
        R7f432(),
        className,
        &imageName);
    if (!klass || !imageName) {
        return nullptr;
    }

    void *iterator = nullptr;
    while (void *rawMethod =
               gClassGetMethods(klass, &iterator)) {
        const char *name = gMethodGetName(rawMethod);
        if (!name ||
            strcmp(name, methodName) != 0 ||
            static_cast<int>(
                gMethodGetParamCount(rawMethod)) !=
                argumentCount) {
            continue;
        }

        MethodInfo *method =
            reinterpret_cast<MethodInfo *>(rawMethod);
        if (!gMethodIsGeneric(method)) {
            return method;
        }
    }
    return nullptr;
}

static bool ResolveManagedMethods(void) {
    gClassGetMethods =
        reinterpret_cast<ClassGetMethodsFn>(
            dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_methods")));
    gMethodGetName =
        reinterpret_cast<MethodGetNameFn>(
            dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_get_name")));
    gMethodGetParamCount =
        reinterpret_cast<MethodGetParamCountFn>(
            dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_get_param_count")));
    gMethodIsGeneric =
        reinterpret_cast<MethodIsGenericFn>(
            dlsym(RTLD_DEFAULT, OX_C("il2cpp_method_is_generic")));

    gManagerClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("NonLinearExpeditionInteractionSelectionManager"),
        &gManagerImageName);

    if (gManagerClass && gManagerImageName) {
        gAutoSelectNextInteractionMethod = Il2CppFindMethodInfoRaw(
            gManagerImageName,
            R7f432(),
            OX_C("NonLinearExpeditionInteractionSelectionManager"),
            OX_C("AutoSelectNextInteraction"),
            1,
            false);
        gSelectInteractionMethod = Il2CppFindMethodInfoRaw(
            gManagerImageName,
            R7f432(),
            OX_C("NonLinearExpeditionInteractionSelectionManager"),
            OX_C("SelectInteraction"),
            1,
            false);

        gManagerTooltipOffset = Il2CppGetFieldOffset(
            gManagerImageName,
            R7f432(),
            OX_C("NonLinearExpeditionInteractionSelectionManager"),
            OX_C("m_NonLinearInteractionTooltipController"));
        if (gManagerTooltipOffset == SIZE_MAX) {
            gManagerTooltipOffset = 0x40;
        }

        gManagerInfoModelOffset = Il2CppGetFieldOffset(
            gManagerImageName,
            R7f432(),
            OX_C("NonLinearExpeditionInteractionSelectionManager"),
            OX_C("m_NonLinearExpeditionInfoModel"));
        if (gManagerInfoModelOffset == SIZE_MAX) {
            gManagerInfoModelOffset = 0x10;
        }

        gManagerInventoryOffset = Il2CppGetFieldOffset(
            gManagerImageName,
            R7f432(),
            OX_C("NonLinearExpeditionInteractionSelectionManager"),
            OX_C("m_NonLinearExpeditionInventoryManager"));
        if (gManagerInventoryOffset == SIZE_MAX) {
            gManagerInventoryOffset = 0x48;
        }

        gManagerStateModelOffset = Il2CppGetFieldOffset(
            gManagerImageName,
            R7f432(),
            OX_C("NonLinearExpeditionInteractionSelectionManager"),
            OX_C("m_ExpeditionStateModel"));
        if (gManagerStateModelOffset == SIZE_MAX) {
            gManagerStateModelOffset = 0x60;
        }

    }

    gGetExpeditionStateMethod = FindMethodAnyImage(
        OX_C("ExpeditionStateModel"),
        OX_C("get_CurrentState"),
        0,
        true);

    const char *infoModelImage = nullptr;
    void *infoModelClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("NonLinearExpeditionInfoModel"),
        &infoModelImage);
    gGetSelectedInteractionIdMethod = FindMethodAnyImage(
        OX_C("NonLinearExpeditionInfoModel"),
        OX_C("get_SelectedInteractionId"),
        0,
        true);
    if (infoModelClass && infoModelImage) {
        gInfoSelectedInteractionIdOffset = Il2CppGetFieldOffset(
            infoModelImage,
            R7f432(),
            OX_C("ExpeditionInfoModel"),
            OX_C("<SelectedInteractionId>k__BackingField"));
        gInfoCurrentChapterIndexOffset = Il2CppGetFieldOffset(
            infoModelImage,
            R7f432(),
            OX_C("ExpeditionInfoModel"),
            OX_C("<CurrentChapterIndex>k__BackingField"));
    }
    if (gInfoSelectedInteractionIdOffset == SIZE_MAX) {
        gInfoSelectedInteractionIdOffset = 0x20;
    }
    if (gInfoCurrentChapterIndexOffset == SIZE_MAX) {
        gInfoCurrentChapterIndexOffset = 0x44;
    }
    gIsPassedInteractionMethod = FindMethodAnyImage(
        OX_C("NonLinearExpeditionInfoModel"),
        OX_C("IsPassedInteraction"),
        1,
        true);
    gGetInteractionDataByIdMethod = FindMethodAnyImage(
        OX_C("NonLinearExpeditionInfoModel"),
        OX_C("GetInteractionDataById"),
        1,
        true);

    const char *interactionDataImage = nullptr;
    void *interactionDataClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("NonLinearInteractionData"),
        &interactionDataImage);
    if (interactionDataClass && interactionDataImage) {
        gInteractionDataTypeOffset = Il2CppGetFieldOffset(
            interactionDataImage,
            R7f432(),
            OX_C("NonLinearInteractionData"),
            OX_C("<Type>k__BackingField"));
    }
    if (gInteractionDataTypeOffset == SIZE_MAX) {
        gInteractionDataTypeOffset = 0x38;
    }

    const char *tooltipImage = nullptr;
    gTooltipIsOpenMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("IsAnyTooltipOpen"),
        0,
        true,
        &tooltipImage);
    gTooltipCloseMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("TryCloseTooltip"),
        1,
        true);
    gGetTooltipTargetIdMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("GetInteractionIdForItemStateHolder"),
        1,
        false);
    gExecuteInteractionActionMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("ExecuteInteractionAction"),
        1,
        false);
    gExecuteTeleportActionMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("ExecuteTeleportAction"),
        1,
        false);
    gIsTeleportGateSpawnIdMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("IsTeleportGateSpawnId"),
        1,
        false);
    gShowAutoOutOfCurrencyMethod = FindMethodAnyImage(
        OX_C("NonLinearOutOfCurrencyController"),
        OX_C("ShowAutoOutOfCurrencyForInteraction"),
        1,
        true);
    const char *buttonsImage = nullptr;
    gButtonsControllerClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("NonLinearButtonsController"),
        &buttonsImage);
    gFlagButtonPressedMethod = FindMethodAnyImage(
        OX_C("NonLinearButtonsController"),
        OX_C("OnFlagLocatorButtonPressed"),
        0,
        false);
    gProgressMapButtonPressedMethod = FindMethodAnyImage(
        OX_C("NonLinearButtonsController"),
        OX_C("OnProgressMapButtonPressed"),
        0,
        true);
    gStageProgressNavigationMethod = FindMethodAnyImage(
        OX_C("NonLinearButtonsController"),
        OX_C("StageProgressNavigation"),
        1,
        false);
    if (gButtonsControllerClass && buttonsImage) {
        gButtonsInfoModelOffset = Il2CppGetFieldOffset(
            buttonsImage,
            R7f432(),
            OX_C("NonLinearButtonsController"),
            OX_C("m_NonLinearExpeditionInfoModel"));
        gButtonsAllStageGatesPassedOffset = Il2CppGetFieldOffset(
            buttonsImage,
            R7f432(),
            OX_C("NonLinearButtonsController"),
            OX_C("m_AllStageGatesArePassed"));
    }
    if (gButtonsInfoModelOffset == SIZE_MAX) {
        gButtonsInfoModelOffset = 0x88;
    }
    if (gButtonsAllStageGatesPassedOffset == SIZE_MAX) {
        gButtonsAllStageGatesPassedOffset = 0x90;
    }

    const char *stagePhaseImage = nullptr;
    gStageCompletePhaseClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("NonLinearInteractionStageCompletePhase"),
        &stagePhaseImage);
    if (gStageCompletePhaseClass && stagePhaseImage) {
        gStagePhaseInfoModelOffset = Il2CppGetFieldOffset(
            stagePhaseImage,
            R7f432(),
            OX_C("NonLinearInteractionStageCompletePhase"),
            OX_C("m_NonLinearExpeditionInfoModel"));
        gStagePhasePopupControllerOffset = Il2CppGetFieldOffset(
            stagePhaseImage,
            R7f432(),
            OX_C("NonLinearInteractionStageCompletePhase"),
            OX_C("m_StageCompletePopupController"));
    }
    if (gStagePhaseInfoModelOffset == SIZE_MAX) {
        gStagePhaseInfoModelOffset = 0x28;
    }
    if (gStagePhasePopupControllerOffset == SIZE_MAX) {
        gStagePhasePopupControllerOffset = 0x38;
    }
    gStagePopupIsOpenMethod = FindMethodAnyImage(
        OX_C("NonLinearExpeditionStageCompletePopupController"),
        OX_C("get_IsPopupOpened"),
        0,
        true);
    gStagePopupCloseMethod = FindMethodAnyImage(
        OX_C("NonLinearExpeditionStageCompletePopupController"),
        OX_C("CloseButtonPressed"),
        0,
        true);

    gIsEnoughCurrencyForAnyMethod = FindMethodAnyImage(
        OX_C("NonLinearExpeditionInventoryManager"),
        OX_C("get_IsEnoughCurrencyForAnyInteraction"),
        0,
        false);
    gIsEnoughCurrencyForInteractionMethod = FindMethodAnyImage(
        OX_C("NonLinearExpeditionInventoryManager"),
        OX_C("IsEnoughCurrencyForInteraction"),
        1,
        false);

    if (tooltipImage) {
        gTooltipLastTargetOffset = Il2CppGetFieldOffset(
            tooltipImage,
            R7f432(),
            OX_C("InteractionTooltipController"),
            OX_C("m_LastSelectedTarget"));
        gTooltipSelectedArrowIdOffset = Il2CppGetFieldOffset(
            tooltipImage,
            R7f432(),
            OX_C("InteractionTooltipController"),
            OX_C("m_SelectedArrowInteractionId"));
        gTooltipOutOfCurrencyControllerOffset = Il2CppGetFieldOffset(
            tooltipImage,
            R7f432(),
            OX_C("NonLinearInteractionTooltipController"),
            OX_C("m_NonLinearOutOfCurrencyController"));
        gTooltipDataProviderOffset = Il2CppGetFieldOffset(
            tooltipImage,
            R7f432(),
            OX_C("InteractionTooltipController"),
            OX_C("m_InteractionTooltipDataProvider"));
    }
    if (gTooltipLastTargetOffset == SIZE_MAX) {
        gTooltipLastTargetOffset = 0x88;
    }
    if (gTooltipSelectedArrowIdOffset == SIZE_MAX) {
        gTooltipSelectedArrowIdOffset = 0x80;
    }
    if (gTooltipOutOfCurrencyControllerOffset == SIZE_MAX) {
        gTooltipOutOfCurrencyControllerOffset = 0xC0;
    }
    if (gTooltipDataProviderOffset == SIZE_MAX) {
        gTooltipDataProviderOffset = 0x48;
    }

    const char *tooltipProviderImage = nullptr;
    void *tooltipProviderClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("NonLinearInteractionTooltipDataProvider"),
        &tooltipProviderImage);
    if (tooltipProviderClass && tooltipProviderImage) {
        gTooltipProviderCustomModelOffset =
            Il2CppGetFieldOffset(
                tooltipProviderImage,
                R7f432(),
                OX_C("NonLinearInteractionTooltipDataProvider"),
                OX_C("m_CustomInteractionModel"));
    }
    if (gTooltipProviderCustomModelOffset == SIZE_MAX) {
        gTooltipProviderCustomModelOffset = 0x58;
    }
    gGetCustomInteractionDataMethod =
        FindNonGenericMethodAnyImage(
            OX_C("ExpeditionCustomInteractionModel"),
            OX_C("GetCustomInteractionDataByInteractionId"),
            1);

    gActionDataClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("ExpeditionTooltipInteractionActionData"),
        &gActionDataImageName);

    if (gActionDataClass && gActionDataImageName) {
        gActionDataCtorMethod = Il2CppFindMethodInfoRaw(
            gActionDataImageName,
            R7f432(),
            OX_C("ExpeditionTooltipInteractionActionData"),
            OX_C(".ctor"),
            1,
            false);
        const char *fieldNames[] = {
            OX_C("<InteractionId>k__BackingField"),
            OX_C("<InteractionID>k__BackingField"),
            OX_C("m_InteractionId"),
            OX_C("m_InteractionID"),
            OX_C("interactionId"),
            OX_C("interactionID"),
            OX_C("InteractionId"),
            OX_C("InteractionID")
        };
        for (const char *fieldName : fieldNames) {
            size_t offset = Il2CppGetFieldOffset(
                gActionDataImageName,
                R7f432(),
                OX_C("ExpeditionTooltipInteractionActionData"),
                fieldName);
            if (offset != SIZE_MAX) {
                gActionDataIdOffset = offset;
                break;
            }
        }

    }

    gTeleportActionDataClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("ExpeditionTooltipTeleportActionData"),
        &gTeleportActionDataImageName);
    if (gTeleportActionDataClass &&
        gTeleportActionDataImageName) {
        gTeleportActionDataCtorMethod = Il2CppFindMethodInfoRaw(
            gTeleportActionDataImageName,
            R7f432(),
            OX_C("ExpeditionTooltipTeleportActionData"),
            OX_C(".ctor"),
            1,
            false);
    }

    gCustomActionDataClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("ExpeditionTooltipCustomInteractionActionData"),
        &gCustomActionDataImageName);
    if (gCustomActionDataClass &&
        gCustomActionDataImageName) {
        gCustomActionDataCtorMethod = Il2CppFindMethodInfoRaw(
            gCustomActionDataImageName,
            R7f432(),
            OX_C("ExpeditionTooltipCustomInteractionActionData"),
            OX_C(".ctor"),
            1,
            false);
    }
    gCustomEnteredWithoutTooltipSetter = FindMethodAnyImage(
        OX_C("ExpeditionTooltipCustomInteractionActionData"),
        OX_C("set_IsEnteredWithoutTooltip"),
        1,
        false);
    gEnterCustomInteractionFlowMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("EnterCustomInteractionFlow"),
        1,
        false);
    gExecuteTooltipActionMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("ExecuteTooltipAction"),
        1,
        false);
    gCanNavigateForSourceMethod = FindMethodAnyImage(
        OX_C("NonLinearInteractionTooltipController"),
        OX_C("CanNavigateForSource"),
        1,
        false);

    gNotEnoughActionDataClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("ExpeditionTooltipNotEnoughCurrencyActionData"),
        &gNotEnoughActionDataImageName);
    if (gNotEnoughActionDataClass &&
        gNotEnoughActionDataImageName) {
        gNotEnoughActionDataIdOffset = Il2CppGetFieldOffset(
            gNotEnoughActionDataImageName,
            R7f432(),
            OX_C("ExpeditionTooltipNotEnoughCurrencyActionData"),
            OX_C("InteractionId"));
    }

    gResolveIcall =
        reinterpret_cast<ResolveIcallFn>(
            dlsym(RTLD_DEFAULT, OX_C("il2cpp_resolve_icall")));
    gClassGetType =
        reinterpret_cast<ClassGetTypeFn>(
            dlsym(RTLD_DEFAULT, OX_C("il2cpp_class_get_type")));
    gTypeGetObject =
        reinterpret_cast<TypeGetObjectFn>(
            dlsym(RTLD_DEFAULT, OX_C("il2cpp_type_get_object")));
    if (gResolveIcall) {
        gFindObjectsOfType2 =
            reinterpret_cast<FindObjectsOfType2Fn>(
                gResolveIcall(
                    OX_C("UnityEngine.Object::FindObjectsOfType(System.Type,System.Boolean)")));
        gFindObjectsOfType1 =
            reinterpret_cast<FindObjectsOfType1Fn>(
                gResolveIcall(
                    OX_C("UnityEngine.Object::FindObjectsOfType(System.Type)")));
    }

    const char *bossHolderImage = nullptr;
    gBossWheelHolderClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("ExpeditionAccumulativeWheelUiHolder"),
        &bossHolderImage);
    if (gBossWheelHolderClass && bossHolderImage) {
        gBossWheelContainersOffset = Il2CppGetFieldOffset(
            bossHolderImage,
            R7f432(),
            OX_C("ExpeditionAccumulativeWheelUiHolder"),
            OX_C("<Containers>k__BackingField"));
        if (gClassGetType && gTypeGetObject) {
            void *classType =
                gClassGetType(gBossWheelHolderClass);
            if (classType) {
                gBossWheelHolderType =
                    gTypeGetObject(classType);
            }
        }
    }
    if (gBossWheelContainersOffset == SIZE_MAX) {
        gBossWheelContainersOffset = 0x20;
    }

    const char *bossContainersImage = nullptr;
    void *bossContainersClass = Il2CppFindClassAnyImage(
        R7f432(),
        OX_C("AccumulativeWheelContainers"),
        &bossContainersImage);
    if (bossContainersClass && bossContainersImage) {
        gBossContainersActionButtonOffset =
            Il2CppGetFieldOffset(
                bossContainersImage,
                R7f432(),
                OX_C("AccumulativeWheelContainers"),
                OX_C("<ActionButtonView>k__BackingField"));
    }
    if (gBossContainersActionButtonOffset == SIZE_MAX) {
        gBossContainersActionButtonOffset = 0x18;
    }

    const char *bossButtonImage = nullptr;
    const char *bossButtonNamespace =
        OX_C("KitHelpers.ProbabilityEngineKit");
    void *bossButtonClass = Il2CppFindClassAnyImage(
        bossButtonNamespace,
        OX_C("ActionButtonView"),
        &bossButtonImage);
    if (bossButtonClass && bossButtonImage) {
        gBossSendAutoModeMethod =
            Il2CppFindMethodInfoRaw(
                bossButtonImage,
                bossButtonNamespace,
                OX_C("ActionButtonView"),
                OX_C("SendAndSetAutoModePressed"),
                0,
                false);
        gBossActionButtonDownMethod =
            Il2CppFindMethodInfoRaw(
                bossButtonImage,
                bossButtonNamespace,
                OX_C("ActionButtonView"),
                OX_C("ActionButtonDown"),
                0,
                false);
        gBossActionButtonUpMethod =
            Il2CppFindMethodInfoRaw(
                bossButtonImage,
                bossButtonNamespace,
                OX_C("ActionButtonView"),
                OX_C("ActionButtonUp"),
                0,
                false);
        gBossButtonDisableAutoOffset =
            Il2CppGetFieldOffset(
                bossButtonImage,
                bossButtonNamespace,
                OX_C("ActionButtonView"),
                OX_C("m_DisableAutoSpin"));
        gBossButtonIsAutoModeOffset =
            Il2CppGetFieldOffset(
                bossButtonImage,
                bossButtonNamespace,
                OX_C("ActionButtonView"),
                OX_C("m_IsAutoMode"));
        gBossButtonEventIdOffset =
            Il2CppGetFieldOffset(
                bossButtonImage,
                bossButtonNamespace,
                OX_C("ActionButtonView"),
                OX_C("m_EventId"));
    }
    if (gBossButtonDisableAutoOffset == SIZE_MAX) {
        gBossButtonDisableAutoOffset = 0x20;
    }
    if (gBossButtonIsAutoModeOffset == SIZE_MAX) {
        gBossButtonIsAutoModeOffset = 0xE0;
    }
    if (gBossButtonEventIdOffset == SIZE_MAX) {
        gBossButtonEventIdOffset = 0x100;
    }

    const char *bossUiLockerImage = nullptr;
    gBossUiLockerClass = Il2CppFindClassAnyImage(
        bossButtonNamespace,
        OX_C("ProbabilityEngineUILocker"),
        &bossUiLockerImage);
    if (gBossUiLockerClass && bossUiLockerImage) {
        gBossUiLockerOverlayOffset =
            Il2CppGetFieldOffset(
                bossUiLockerImage,
                bossButtonNamespace,
                OX_C("ProbabilityEngineUILocker"),
                OX_C("m_UILockOverlay"));
        gBossUiLockerEventIdOffset =
            Il2CppGetFieldOffset(
                bossUiLockerImage,
                bossButtonNamespace,
                OX_C("ProbabilityEngineUILocker"),
                OX_C("m_EventId"));
        if (gClassGetType && gTypeGetObject) {
            void *classType =
                gClassGetType(gBossUiLockerClass);
            if (classType) {
                gBossUiLockerType =
                    gTypeGetObject(classType);
            }
        }
    }
    if (gBossUiLockerOverlayOffset == SIZE_MAX) {
        gBossUiLockerOverlayOffset = 0x20;
    }
    if (gBossUiLockerEventIdOffset == SIZE_MAX) {
        gBossUiLockerEventIdOffset = 0x38;
    }

    const char *gameObjectImage = nullptr;
    const char *unityNamespace = OX_C("UnityEngine");
    void *gameObjectClass = Il2CppFindClassAnyImage(
        unityNamespace,
        OX_C("GameObject"),
        &gameObjectImage);
    if (gameObjectClass && gameObjectImage) {
        gGameObjectActiveInHierarchyMethod =
            Il2CppFindMethodInfoRaw(
                gameObjectImage,
                unityNamespace,
                OX_C("GameObject"),
                OX_C("get_activeInHierarchy"),
                0,
                true);
    }

    bool managerReady =
        gManagerClass &&
        gManagerTooltipOffset != SIZE_MAX &&
        gManagerInfoModelOffset != SIZE_MAX &&
        gManagerInventoryOffset != SIZE_MAX &&
        gManagerStateModelOffset != SIZE_MAX &&
        gAutoSelectNextInteractionMethod &&
        gGetSelectedInteractionIdMethod &&
        gIsPassedInteractionMethod;
    bool tooltipReady =
        gTooltipIsOpenMethod &&
        gGetTooltipTargetIdMethod &&
        gTooltipLastTargetOffset != SIZE_MAX &&
        gTooltipSelectedArrowIdOffset != SIZE_MAX &&
        gExecuteInteractionActionMethod;
    bool routeReady =
        gButtonsControllerClass &&
        gFlagButtonPressedMethod &&
        gButtonsInfoModelOffset != SIZE_MAX;
    bool currencyReady =
        gIsEnoughCurrencyForAnyMethod &&
        gIsEnoughCurrencyForInteractionMethod;
    bool actionDataReady =
        gActionDataClass &&
        gActionDataCtorMethod &&
        gActionDataIdOffset != SIZE_MAX;
    bool teleportActionReady =
        gTeleportActionDataClass &&
        gTeleportActionDataCtorMethod &&
        gExecuteTeleportActionMethod &&
        gIsTeleportGateSpawnIdMethod;
    bool customTaskReady =
        gCustomActionDataClass &&
        gCustomActionDataCtorMethod &&
        gEnterCustomInteractionFlowMethod &&
        gExecuteTooltipActionMethod &&
        gCanNavigateForSourceMethod &&
        gNotEnoughActionDataClass &&
        gNotEnoughActionDataIdOffset != SIZE_MAX &&
        gGetExpeditionStateMethod &&
        gManagerStateModelOffset != SIZE_MAX;
    bool customClassifierReady =
        (gGetCustomInteractionDataMethod &&
         gTooltipDataProviderOffset != SIZE_MAX &&
         gTooltipProviderCustomModelOffset != SIZE_MAX) ||
        (gGetInteractionDataByIdMethod &&
         gInteractionDataTypeOffset != SIZE_MAX);
    bool stageReady =
        gStageCompletePhaseClass &&
        gStagePhaseInfoModelOffset != SIZE_MAX &&
        gStagePhasePopupControllerOffset != SIZE_MAX &&
        gStagePopupIsOpenMethod &&
        gStagePopupCloseMethod;
    bool bossReady =
        gBossWheelHolderClass &&
        gBossWheelHolderType &&
        (gFindObjectsOfType2 ||
         gFindObjectsOfType1) &&
        gBossWheelContainersOffset != SIZE_MAX &&
        gBossContainersActionButtonOffset != SIZE_MAX &&
        gBossButtonDisableAutoOffset != SIZE_MAX &&
        gBossButtonIsAutoModeOffset != SIZE_MAX &&
        gBossButtonEventIdOffset != SIZE_MAX &&
        gBossUiLockerClass &&
        gBossUiLockerType &&
        gBossUiLockerOverlayOffset != SIZE_MAX &&
        gBossUiLockerEventIdOffset != SIZE_MAX &&
        gBossSendAutoModeMethod &&
        gBossActionButtonDownMethod &&
        gBossActionButtonUpMethod &&
        gGameObjectActiveInHierarchyMethod;

    if (!gManagerClass) {
        gPrepareFailureStatus = OX_NS("CHƯA THẤY CLASS MANAGER");
    } else if (!gAutoSelectNextInteractionMethod) {
        gPrepareFailureStatus = OX_NS("THIẾU BỘ CHỌN ĐƯỜNG CỦA GAME");
    } else if (!gGetSelectedInteractionIdMethod) {
        gPrepareFailureStatus = OX_NS("THIẾU ID GAME ĐÃ CHỌN");
    } else if (!gIsPassedInteractionMethod) {
        gPrepareFailureStatus = OX_NS("THIẾU HÀM XÁC NHẬN MỤC TIÊU");
    } else if (!routeReady) {
        gPrepareFailureStatus = OX_NS("THIẾU NÚT CỜ THẬT CỦA GAME");
    } else if (!currencyReady) {
        gPrepareFailureStatus = OX_NS("THIẾU KIỂM TRA THUỐC VÀ BÓNG");
    } else if (!gExecuteInteractionActionMethod) {
        gPrepareFailureStatus = OX_NS("THIẾU HÀM THU THẬP");
    } else if (!gTooltipIsOpenMethod ||
               !gGetTooltipTargetIdMethod) {
        gPrepareFailureStatus = OX_NS("THIẾU ID TOOLTIP HIỆN TẠI");
    } else if (!gActionDataClass) {
        gPrepareFailureStatus = OX_NS("CHƯA THẤY ACTION DATA");
    } else if (!gActionDataCtorMethod) {
        gPrepareFailureStatus = OX_NS("THIẾU HÀM TẠO ACTION DATA");
    } else if (!actionDataReady) {
        gPrepareFailureStatus = OX_NS("ACTION DATA CHƯA SẴN SÀNG");
    } else if (!teleportActionReady) {
        gPrepareFailureStatus = OX_NS("THIẾU ACTION ĐI VÀO CỔNG");
    } else if (!customTaskReady) {
        gPrepareFailureStatus = OX_NS("THIẾU ACTION NHIỆM VỤ");
    } else if (!customClassifierReady) {
        gPrepareFailureStatus = OX_NS("THIẾU BỘ NHẬN DIỆN NHIỆM VỤ BOSS");
    } else if (!bossReady) {
        gPrepareFailureStatus = OX_NS("THIẾU ĐIỀU KHIỂN ĐÁNH BOSS");
    } else if (!stageReady) {
        gPrepareFailureStatus = OX_NS("THIẾU ĐIỀU KHIỂN SANG MAP MỚI");
    } else {
        gPrepareFailureStatus = OX_NS("");
    }


    return managerReady && routeReady &&
           currencyReady && tooltipReady &&
           actionDataReady && teleportActionReady &&
           customTaskReady && customClassifierReady &&
           bossReady && stageReady;
}

static bool ResolveLiveness(void) {
    void *objectUnbox =
        dlsym(RTLD_DEFAULT, OX_C("il2cpp_object_unbox"));
    gLivenessAllocate =
        reinterpret_cast<LivenessAllocateFn>(
            dlsym(RTLD_DEFAULT,
                  OX_C("il2cpp_unity_liveness_allocate_struct")));
    gLivenessFromStatics =
        reinterpret_cast<LivenessFromStaticsFn>(
            dlsym(RTLD_DEFAULT,
                  OX_C("il2cpp_unity_liveness_calculation_from_statics")));
    gLivenessFinalize =
        reinterpret_cast<LivenessFinalizeFn>(
            dlsym(RTLD_DEFAULT,
                  OX_C("il2cpp_unity_liveness_finalize")));
    gLivenessFree =
        reinterpret_cast<LivenessFreeFn>(
            dlsym(RTLD_DEFAULT,
                  OX_C("il2cpp_unity_liveness_free_struct")));
    gGCHandleNew =
        reinterpret_cast<GCHandleNewFn>(
            dlsym(RTLD_DEFAULT,
                  OX_C("il2cpp_gchandle_new")));
    gGCHandleFree =
        reinterpret_cast<GCHandleFreeFn>(
            dlsym(RTLD_DEFAULT,
                  OX_C("il2cpp_gchandle_free")));

    bool ready =
        gLivenessAllocate &&
        gLivenessFromStatics &&
        gLivenessFinalize &&
        gLivenessFree &&
        gGCHandleNew &&
        gGCHandleFree;

    return ready;
}

struct FirstLiveObjectResult {
    void *object = nullptr;
    int callbacks = 0;
};

static void *ReallocateLivenessBuffer(void *memory,
                                      size_t size,
                                      void *userData) {
    (void)userData;
    if (size == 0) {
        free(memory);
        return nullptr;
    }
    return realloc(memory, size);
}

static void OnFirstLiveObject(void **objects,
                              int count,
                              void *userData) {
    FirstLiveObjectResult *result =
        reinterpret_cast<FirstLiveObjectResult *>(userData);
    if (!result || !objects || count <= 0) return;

    result->callbacks += count;
    if (result->object) return;

    for (int index = 0; index < count; ++index) {
        if (IsPlausiblePointer(objects[index])) {
            result->object = objects[index];
            return;
        }
    }
}

static void *FindFirstLiveObject(
    void *klass,
    unsigned long long generation) {
    if (!klass ||
        !gLivenessAllocate ||
        !gLivenessFromStatics ||
        !gLivenessFinalize ||
        !gLivenessFree ||
        !ManagerScanSessionReady(generation)) {
        return nullptr;
    }

    FirstLiveObjectResult result;
    void *state = gLivenessAllocate(
        klass,
        64,
        OnFirstLiveObject,
        &result,
        ReallocateLivenessBuffer);
    if (!state) {
        return nullptr;
    }

    if (!ManagerScanSessionReady(generation)) {
        gLivenessFree(state);
        return nullptr;
    }

    gLivenessFromStatics(state);
    gLivenessFinalize(state);
    gLivenessFree(state);

    if (!ManagerScanSessionActive(generation)) {
        return nullptr;
    }

    return result.object;
}

struct MatchingButtonsControllerResult {
    void *infoModel = nullptr;
    void *object = nullptr;
    int callbacks = 0;
    int inspected = 0;
};

static void OnMatchingButtonsController(
    void **objects,
    int count,
    void *userData) {
    MatchingButtonsControllerResult *result =
        reinterpret_cast<MatchingButtonsControllerResult *>(
            userData);
    if (!result || !objects || count <= 0 ||
        !result->infoModel ||
        gButtonsInfoModelOffset == SIZE_MAX) {
        return;
    }

    result->callbacks += count;
    if (result->object) return;

    for (int index = 0; index < count; ++index) {
        void *object = objects[index];
        if (!IsPlausiblePointer(object)) continue;
        result->inspected += 1;
        void *infoModel =
            *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(object) +
                gButtonsInfoModelOffset);
        if (infoModel == result->infoModel) {
            result->object = object;
            return;
        }
    }
}

static void *FindCurrentButtonsController(void) {
    void *cached = gButtonsController.load();
    if (IsPlausiblePointer(cached)) {
        return cached;
    }

    void *infoModel = gInfoModel.load();
    if (!infoModel ||
        !gButtonsControllerClass ||
        gButtonsInfoModelOffset == SIZE_MAX ||
        !gLivenessAllocate ||
        !gLivenessFromStatics ||
        !gLivenessFinalize ||
        !gLivenessFree) {
        return nullptr;
    }

    MatchingButtonsControllerResult result;
    result.infoModel = infoModel;
    void *state = gLivenessAllocate(
        gButtonsControllerClass,
        64,
        OnMatchingButtonsController,
        &result,
        ReallocateLivenessBuffer);
    if (!state) {
        return nullptr;
    }

    gLivenessFromStatics(state);
    gLivenessFinalize(state);
    gLivenessFree(state);
    if (IsPlausiblePointer(result.object)) {
        gButtonsController.store(result.object);
        RetainObject(
            result.object,
            gButtonsControllerHandle);
    }
    return result.object;
}

struct MatchingStagePopupResult {
    void *infoModel = nullptr;
    void *phase = nullptr;
    void *popupController = nullptr;
    int callbacks = 0;
    int inspected = 0;
};

static void OnMatchingStagePopup(
    void **objects,
    int count,
    void *userData) {
    MatchingStagePopupResult *result =
        reinterpret_cast<MatchingStagePopupResult *>(
            userData);
    if (!result || !objects || count <= 0 ||
        !result->infoModel ||
        gStagePhaseInfoModelOffset == SIZE_MAX ||
        gStagePhasePopupControllerOffset == SIZE_MAX) {
        return;
    }

    result->callbacks += count;
    if (result->popupController) return;

    for (int index = 0; index < count; ++index) {
        void *phase = objects[index];
        if (!IsPlausiblePointer(phase)) continue;
        result->inspected += 1;
        void *infoModel =
            *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(phase) +
                gStagePhaseInfoModelOffset);
        if (infoModel != result->infoModel) continue;

        void *popupController =
            *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(phase) +
                gStagePhasePopupControllerOffset);
        if (!IsPlausiblePointer(popupController)) continue;
        result->phase = phase;
        result->popupController = popupController;
        return;
    }
}

static void *FindCurrentStagePopupController(void) {
    void *cached = gStagePopupController.load();
    if (IsPlausiblePointer(cached)) {
        return cached;
    }
    double now = Now();
    if (now < gNextStagePopupLookupAt.load()) {
        return nullptr;
    }
    gNextStagePopupLookupAt.store(now + 1.0);
    if (gStagePopupLookupAttempted.exchange(true)) {
        return nullptr;
    }

    void *infoModel = gInfoModel.load();
    if (!infoModel ||
        !gStageCompletePhaseClass ||
        gStagePhaseInfoModelOffset == SIZE_MAX ||
        gStagePhasePopupControllerOffset == SIZE_MAX ||
        !gLivenessAllocate ||
        !gLivenessFromStatics ||
        !gLivenessFinalize ||
        !gLivenessFree) {
        gStagePopupLookupAttempted.store(false);
        return nullptr;
    }

    MatchingStagePopupResult result;
    result.infoModel = infoModel;
    void *state = gLivenessAllocate(
        gStageCompletePhaseClass,
        64,
        OnMatchingStagePopup,
        &result,
        ReallocateLivenessBuffer);
    if (!state) {
        gStagePopupLookupAttempted.store(false);
        return nullptr;
    }

    gLivenessFromStatics(state);
    gLivenessFinalize(state);
    gLivenessFree(state);
    if (IsPlausiblePointer(result.popupController)) {
        gStagePopupController.store(
            result.popupController);
        RetainObject(
            result.popupController,
            gStagePopupControllerHandle);
    } else {
        gStagePopupLookupAttempted.store(false);
    }
    return result.popupController;
}

static void CaptureManager(void *manager) {
    if (!IsPlausiblePointer(manager)) return;

    void *tooltip =
        *reinterpret_cast<void **>(
            reinterpret_cast<uintptr_t>(manager) +
            gManagerTooltipOffset);
    void *infoModel =
        *reinterpret_cast<void **>(
            reinterpret_cast<uintptr_t>(manager) +
            gManagerInfoModelOffset);
    void *inventoryManager =
        *reinterpret_cast<void **>(
            reinterpret_cast<uintptr_t>(manager) +
            gManagerInventoryOffset);
    if (!IsPlausiblePointer(tooltip)) {
        return;
    }
    if (!IsPlausiblePointer(infoModel)) {
        return;
    }
    if (!IsPlausiblePointer(inventoryManager)) {
        return;
    }

    void *previous = gSelectionManager.exchange(manager);
    gTooltipController.store(tooltip);
    gInfoModel.store(infoModel);
    gInventoryManager.store(inventoryManager);

    if (previous != manager || !gManagerHandle.load()) {
        RetainObject(manager, gManagerHandle);
    }
}

static void ClearManager() {
    BeginManagerScanSession(
        gEnabled.load()
            ? kManagerInitialWarmup
            : 0.0);
    gSelectionManager.store(nullptr);
    ResetBossCombatState(true);
    gButtonsController.store(nullptr);
    gStagePopupController.store(nullptr);
    gTooltipController.store(nullptr);
    gInfoModel.store(nullptr);
    gInventoryManager.store(nullptr);
    FreeHandle(gManagerHandle);
    FreeHandle(gButtonsControllerHandle);
    FreeHandle(gStagePopupControllerHandle);
    ReleaseCycleObjects();
    ClearCompletedTargetQuarantine();
    gPhase.store(static_cast<int>(AutoPhase::Idle));
    gNextStepAt.store(0.0);
    gWaitForNativeContinuation.store(false);
    gStagePopupCloseIssued.store(false);
    gStagePopupLookupAttempted.store(false);
    gAutoSelectIssued.store(false);
    gAutoSelectIssuedAt.store(0.0);
    gProgressNavigationIssued.store(false);
    gTransitionReleaseIssued.store(false);
    gTransitionChangeObserved.store(false);
    gTransitionStableSamples.store(0);
    gTransitionStartChapter.store(-1);
    gTransitionLastChapter.store(-1);
    gTransitionChangeObservedAt.store(0.0);
    gNextTransitionPollAt.store(0.0);
    gNextStagePopupLookupAt.store(0.0);
    gUseConstructedActionData.store(false);
    gForceRouteRefresh.store(false);
    gRequireSelectionChange.store(false);
    ResetResultRecoveryState();
    gPortalRouteStartedAt.store(0.0);
    gNextPortalActionAt.store(0.0);
    gPortalActionAttempts.store(0);
    gPortalActionInvoked.store(false);
    gNextPortalFlagAt.store(0.0);
    gPortalFlagAttempts.store(0);
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        gActiveMapKey[0] = '\0';
        gTransitionStartMapKey[0] = '\0';
        gTransitionLastMapKey[0] = '\0';
        gPortalPreviousTargetText[0] = '\0';
    }
    ClearTaskJourneyState();
}

enum class CurrencyState : int {
    Error = -1,
    NotEnough = 0,
    Enough = 1
};

static CurrencyState QueryCurrency(
    Il2CppString *interactionId) {
    void *inventoryManager = gInventoryManager.load();
    MethodInfo *method = interactionId
        ? gIsEnoughCurrencyForInteractionMethod
        : gIsEnoughCurrencyForAnyMethod;
    if (!inventoryManager || !method) {
        return CurrencyState::Error;
    }

    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        method,
        inventoryManager,
        interactionId ? parameters : nullptr,
        &exception);
    if (exception) {
        return CurrencyState::Error;
    }

    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return CurrencyState::Error;
    }

    bool enough = *reinterpret_cast<bool *>(unboxed);
    return enough
        ? CurrencyState::Enough
        : CurrencyState::NotEnough;
}

static int QueryExpeditionState(
    bool *querySucceeded = nullptr) {
    if (querySucceeded) *querySucceeded = false;
    void *manager = gSelectionManager.load();
    if (!IsPlausiblePointer(manager) ||
        gManagerStateModelOffset == SIZE_MAX ||
        !gGetExpeditionStateMethod) {
        return -1;
    }

    void *stateModel =
        *reinterpret_cast<void **>(
            reinterpret_cast<uintptr_t>(manager) +
            gManagerStateModelOffset);
    if (!IsPlausiblePointer(stateModel)) {
        return -1;
    }

    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        gGetExpeditionStateMethod,
        stateModel,
        nullptr,
        &exception);
    if (exception) {
        return -1;
    }

    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return -1;
    }

    if (querySucceeded) *querySucceeded = true;
    return *reinterpret_cast<int *>(unboxed);
}

static bool IsCustomInteractionRuntimeState(int state) {
    return state == 13 ||
           state == 14 ||
           state == 19 ||
           state == 20;
}

static bool IsBossCombatRuntimeState(int state) {
    return state == 13 ||
           state == 19;
}

static int QueryGameObjectActive(void *gameObject) {
    if (!IsPlausiblePointer(gameObject) ||
        !gGameObjectActiveInHierarchyMethod) {
        return -1;
    }
    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        gGameObjectActiveInHierarchyMethod,
        gameObject,
        nullptr,
        &exception);
    if (exception) {
        return -1;
    }
    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return -1;
    }
    return *reinterpret_cast<bool *>(unboxed) ? 1 : 0;
}

static void *FindBossActionButton(const char *taskText) {
    void *cached = gBossActionButton.load();
    if (IsPlausiblePointer(cached)) {
        return cached;
    }

    double now = Now();
    if (now < gNextBossUiLookupAt.load()) {
        return nullptr;
    }
    gNextBossUiLookupAt.store(
        now + kBossUiLookupInterval);
    if (!gBossWheelHolderType ||
        (!gFindObjectsOfType2 &&
         !gFindObjectsOfType1)) {
        return nullptr;
    }

    monoArray<void *> *objects = nullptr;
    if (gFindObjectsOfType2) {
        objects = gFindObjectsOfType2(
            gBossWheelHolderType,
            false);
    }
    if (!objects && gFindObjectsOfType1) {
        objects = gFindObjectsOfType1(
            gBossWheelHolderType);
    }
    if (!IsPlausiblePointer(objects)) {
        return nullptr;
    }

    int count = objects->getCapacity();
    if (count < 0) count = 0;
    if (count > kBossObjectScanLimit) {
        count = kBossObjectScanLimit;
    }
    for (int index = 0; index < count; ++index) {
        void *holder = objects->m_Items[index];
        if (!IsPlausiblePointer(holder)) continue;
        void *containers =
            *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(holder) +
                gBossWheelContainersOffset);
        if (!IsPlausiblePointer(containers)) continue;
        void *button =
            *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(containers) +
                gBossContainersActionButtonOffset);
        if (!IsPlausiblePointer(button)) continue;

        char eventText[128] = {0};
        Il2CppString *eventId =
            *reinterpret_cast<Il2CppString **>(
                reinterpret_cast<uintptr_t>(button) +
                gBossButtonEventIdOffset);
        bool hasEventId = CopyManagedString(
            eventId,
            eventText,
            sizeof(eventText));
        if (hasEventId &&
            taskText &&
            taskText[0] &&
            strcmp(eventText, taskText) != 0) {
            continue;
        }

        gBossWheelHolder.store(holder);
        gBossActionButton.store(button);
        RetainObject(
            holder,
            gBossWheelHolderHandle);
        RetainObject(
            button,
            gBossActionButtonHandle);
        return button;
    }

    return nullptr;
}

static void *FindBossUiLocker(const char *taskText) {
    void *cached = gBossUiLocker.load();
    if (IsPlausiblePointer(cached)) {
        return cached;
    }
    if (!gBossUiLockerType ||
        (!gFindObjectsOfType2 &&
         !gFindObjectsOfType1)) {
        return nullptr;
    }

    monoArray<void *> *objects = nullptr;
    if (gFindObjectsOfType2) {
        objects = gFindObjectsOfType2(
            gBossUiLockerType,
            false);
    }
    if (!objects && gFindObjectsOfType1) {
        objects = gFindObjectsOfType1(
            gBossUiLockerType);
    }
    if (!IsPlausiblePointer(objects)) {
        return nullptr;
    }

    int count = objects->getCapacity();
    if (count < 0) count = 0;
    if (count > kBossObjectScanLimit) {
        count = kBossObjectScanLimit;
    }
    for (int index = 0; index < count; ++index) {
        void *locker = objects->m_Items[index];
        if (!IsPlausiblePointer(locker)) continue;
        Il2CppString *eventId =
            *reinterpret_cast<Il2CppString **>(
                reinterpret_cast<uintptr_t>(locker) +
                gBossUiLockerEventIdOffset);
        char eventText[128] = {0};
        bool hasEventId = CopyManagedString(
            eventId,
            eventText,
            sizeof(eventText));
        if (hasEventId &&
            taskText &&
            taskText[0] &&
            strcmp(eventText, taskText) != 0) {
            continue;
        }
        void *overlay =
            *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(locker) +
                gBossUiLockerOverlayOffset);
        if (!IsPlausiblePointer(overlay)) continue;
        gBossUiLocker.store(locker);
        RetainObject(
            locker,
            gBossUiLockerHandle);
        return locker;
    }
    return nullptr;
}

static int QueryBossUiLockState(const char *taskText) {
    void *locker = FindBossUiLocker(taskText);
    if (!IsPlausiblePointer(locker)) {
        return -1;
    }
    void *overlay =
        *reinterpret_cast<void **>(
            reinterpret_cast<uintptr_t>(locker) +
            gBossUiLockerOverlayOffset);
    return QueryGameObjectActive(overlay);
}

static bool DriveBossCombat(double now,
                            Il2CppString *taskTarget,
                            const char *taskText) {
    if (!R7f431(0xA1C7E52D98436B0FULL)) {
        return false;
    }
    void *button = FindBossActionButton(taskText);
    if (!IsPlausiblePointer(button)) {
        SetStatus(OX_NS("ĐANG CHỜ NÚT ĐÁNH BOSS"));
        gNextStepAt.store(
            now + kBossUiLookupInterval);
        return false;
    }

    int lockState = QueryBossUiLockState(taskText);
    if (lockState < 0) {
        ResetBossCombatState(false);
        SetStatus(OX_NS("ĐANG ĐỒNG BỘ MÀN ĐÁNH BOSS"));
        gNextStepAt.store(
            now + kBossUiLookupInterval);
        return false;
    }
    if (lockState > 0) {
        SetStatus(OX_NS("BOSS ĐANG XỬ LÝ ĐÒN ĐÁNH"));
        gNextStepAt.store(now + 0.25);
        return false;
    }

    bool isAuto =
        *reinterpret_cast<bool *>(
            reinterpret_cast<uintptr_t>(button) +
            gBossButtonIsAutoModeOffset);
    if (isAuto) {
        SetStatus(OX_NS("ĐANG TỰ ĐÁNH BOSS"));
        gNextStepAt.store(now + 0.35);
        return true;
    }

    if (gBossAutoModeRequested.load() &&
        !gBossManualAttackMode.load()) {
        gBossManualAttackMode.store(true);
        gNextBossActionAt.store(
            now + kBossAutoModeRetryDelay);
    }

    CurrencyState currency =
        QueryCurrency(taskTarget);
    if (currency == CurrencyState::NotEnough) {
        SetStatus(OX_NS("KHÔNG ĐỦ THUỐC ĐỂ ĐÁNH BOSS"));
        gNextStepAt.store(now + 0.75);
        return false;
    }
    if (currency == CurrencyState::Error) {
        SetStatus(OX_NS("ĐANG KIỂM TRA THUỐC ĐÁNH BOSS"));
        gNextStepAt.store(now + 0.45);
        return false;
    }

    bool disableAuto =
        *reinterpret_cast<bool *>(
            reinterpret_cast<uintptr_t>(button) +
            gBossButtonDisableAutoOffset);
    if (!disableAuto &&
        !gBossAutoModeRequested.load()) {
        bool invoked = InvokeBossButtonMethod(
            button,
            gBossSendAutoModeMethod);
        bool enabled = invoked &&
            *reinterpret_cast<bool *>(
                reinterpret_cast<uintptr_t>(button) +
                gBossButtonIsAutoModeOffset);
        gBossAutoModeRequested.store(true);
        if (enabled) {
            SetStatus(OX_NS("ĐÃ BẬT TỰ ĐÁNH BOSS"));
            gNextStepAt.store(now + 0.35);
            return true;
        }
        gBossManualAttackMode.store(true);
        gNextBossActionAt.store(now + 0.08);
    } else if (disableAuto) {
        gBossAutoModeRequested.store(true);
        gBossManualAttackMode.store(true);
    }

    if (!gBossManualAttackMode.load()) {
        gNextStepAt.store(now + 0.35);
        return false;
    }
    if (now < gNextBossActionAt.load()) {
        SetStatus(OX_NS("ĐANG CHỜ ĐÒN ĐÁNH BOSS TIẾP THEO"));
        double nextAction =
            gNextBossActionAt.load();
        gNextStepAt.store(
            nextAction < now + 0.35
                ? nextAction
                : now + 0.35);
        return false;
    }

    bool down = InvokeBossButtonMethod(
        button,
        gBossActionButtonDownMethod);
    bool up = down &&
        InvokeBossButtonMethod(
            button,
            gBossActionButtonUpMethod);
    if (!up) {
        ResetBossCombatState(false);
        SetStatus(OX_NS("NÚT ĐÁNH BOSS CHƯA SẴN SÀNG"));
        gNextStepAt.store(
            now + kBossUiLookupInterval);
        return false;
    }

    int count =
        gBossManualAttackCount.fetch_add(1) + 1;
    gNextBossActionAt.store(
        now + kBossManualAttackInterval);
    SetStatus([NSString stringWithFormat:
        OX_NS("ĐANG TỰ ĐÁNH BOSS - ĐÒN %d"),
        count]);
    gNextStepAt.store(now + 0.25);
    return true;
}

static int ReadCurrentChapterIndexDirect(void *infoModel) {
    if (!IsPlausiblePointer(infoModel) ||
        gInfoCurrentChapterIndexOffset == SIZE_MAX) {
        return -1;
    }
    return *reinterpret_cast<int *>(
        reinterpret_cast<uintptr_t>(infoModel) +
        gInfoCurrentChapterIndexOffset);
}

static Il2CppString *ReadSelectedInteractionIdDirect(
    void *infoModel) {
    if (!IsPlausiblePointer(infoModel) ||
        gInfoSelectedInteractionIdOffset == SIZE_MAX) {
        return nullptr;
    }
    Il2CppString *selected =
        *reinterpret_cast<Il2CppString **>(
            reinterpret_cast<uintptr_t>(infoModel) +
            gInfoSelectedInteractionIdOffset);
    return IsPlausiblePointer(selected) ? selected : nullptr;
}

static bool RefreshManagerDependenciesDirect(void) {
    void *manager = gSelectionManager.load();
    if (!IsPlausiblePointer(manager)) return false;

    void *tooltip = *reinterpret_cast<void **>(
        reinterpret_cast<uintptr_t>(manager) +
        gManagerTooltipOffset);
    void *infoModel = *reinterpret_cast<void **>(
        reinterpret_cast<uintptr_t>(manager) +
        gManagerInfoModelOffset);
    void *inventory = *reinterpret_cast<void **>(
        reinterpret_cast<uintptr_t>(manager) +
        gManagerInventoryOffset);
    if (!IsPlausiblePointer(tooltip) ||
        !IsPlausiblePointer(infoModel) ||
        !IsPlausiblePointer(inventory)) {
        return false;
    }
    gTooltipController.store(tooltip);
    gInfoModel.store(infoModel);
    gInventoryManager.store(inventory);
    return true;
}

static void ResetTransitionTracking(void) {
    gTransitionChangeObserved.store(false);
    gTransitionStableSamples.store(0);
    gTransitionStartChapter.store(-1);
    gTransitionLastChapter.store(-1);
    gTransitionChangeObservedAt.store(0.0);
    gNextTransitionPollAt.store(0.0);
    gNextStagePopupLookupAt.store(0.0);
    std::lock_guard<std::mutex> lock(gTargetTextMutex);
    gTransitionStartMapKey[0] = '\0';
    gTransitionLastMapKey[0] = '\0';
}

static void BeginMapTransitionWait(bool changeAlreadyObserved) {
    double now = Now();
    ClearTaskJourneyState();
    ReleaseCycleObjects();
    RefreshManagerDependenciesDirect();

    int chapter = ReadCurrentChapterIndexDirect(
        gInfoModel.load());
    gTransitionStartChapter.store(chapter);
    gTransitionLastChapter.store(chapter);
    gTransitionChangeObserved.store(changeAlreadyObserved);
    gTransitionStableSamples.store(
        changeAlreadyObserved ? 1 : 0);
    gTransitionChangeObservedAt.store(
        changeAlreadyObserved ? now : 0.0);
    gNextTransitionPollAt.store(now + 0.5);

    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(gTransitionStartMapKey,
                 sizeof(gTransitionStartMapKey),
                 OX_C("%s"),
                 gActiveMapKey);
        snprintf(gTransitionLastMapKey,
                 sizeof(gTransitionLastMapKey),
                 OX_C("%s"),
                 changeAlreadyObserved
                    ? gActiveMapKey
                    : OX_C(""));
    }

    gProgressNavigationIssued.store(true);
    gTransitionReleaseIssued.store(false);
    gStagePopupLookupAttempted.store(false);
    gStagePopupCloseIssued.store(false);
    gNextStagePopupLookupAt.store(now + 0.5);
    gPhase.store(
        static_cast<int>(AutoPhase::WaitingMapTransition));
    gPhaseStartedAt.store(now);
    gNextStepAt.store(now + 0.25);
    SetStatus(OX_NS("ĐANG CHUYỂN MAP - TẠM DỪNG AUTO"));
}

static void CancelMapTransitionWait() {
    ResetTransitionTracking();
    gProgressNavigationIssued.store(false);
    gTransitionReleaseIssued.store(false);
    gPhase.store(
        static_cast<int>(AutoPhase::WaitingGameSelection));
    gPhaseStartedAt.store(Now());
    gNextStepAt.store(Now() + 1.0);
}

static bool PollMapTransitionReady(double now) {
    if (now < gNextTransitionPollAt.load()) {
        return false;
    }
    gNextTransitionPollAt.store(
        now + kMapTransitionPollInterval);

    bool dependenciesReady =
        RefreshManagerDependenciesDirect();
    void *infoModel = gInfoModel.load();
    int chapter = dependenciesReady
        ? ReadCurrentChapterIndexDirect(infoModel)
        : -1;
    Il2CppString *selected = dependenciesReady
        ? ReadSelectedInteractionIdDirect(infoModel)
        : nullptr;
    char selectedText[128] = {0};
    char mapKey[96] = {0};
    bool hasSelected = CopyManagedString(
        selected,
        selectedText,
        sizeof(selectedText));
    bool hasMap = hasSelected && ExtractMapKey(
        selectedText,
        mapKey,
        sizeof(mapKey));

    char startMap[96] = {0};
    char lastMap[96] = {0};
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(startMap, sizeof(startMap), OX_C("%s"),
                 gTransitionStartMapKey);
        snprintf(lastMap, sizeof(lastMap), OX_C("%s"),
                 gTransitionLastMapKey);
    }

    bool chapterChanged =
        chapter >= 0 &&
        gTransitionStartChapter.load() >= 0 &&
        chapter != gTransitionStartChapter.load();
    bool mapChanged =
        hasMap && startMap[0] &&
        strcmp(mapKey, startMap) != 0;
    bool changed = gTransitionChangeObserved.load() ||
                   chapterChanged || mapChanged;

    if (changed && !gTransitionChangeObserved.exchange(true)) {
        gTransitionChangeObservedAt.store(now);
        gTransitionStableSamples.store(0);
    }

    if (gTransitionChangeObserved.load()) {
        bool sameChapter =
            chapter >= 0 &&
            chapter == gTransitionLastChapter.load();
        bool sameMap =
            (!hasMap && !lastMap[0]) ||
            (hasMap && lastMap[0] &&
             strcmp(mapKey, lastMap) == 0);
        int stable = (sameChapter && sameMap)
            ? gTransitionStableSamples.fetch_add(1) + 1
            : 1;
        if (!(sameChapter && sameMap)) {
            gTransitionStableSamples.store(1);
        }
        gTransitionLastChapter.store(chapter);
        {
            std::lock_guard<std::mutex> lock(gTargetTextMutex);
            snprintf(gTransitionLastMapKey,
                     sizeof(gTransitionLastMapKey),
                     OX_C("%s"),
                     hasMap ? mapKey : OX_C(""));
            if (hasMap) {
                snprintf(gActiveMapKey,
                         sizeof(gActiveMapKey),
                         OX_C("%s"),
                         mapKey);
            }
        }

        double elapsed = now - gPhaseStartedAt.load();
        double changedFor = now -
            gTransitionChangeObservedAt.load();

        if (dependenciesReady &&
            stable >= kMapTransitionStableSamples &&
            elapsed >= kMapTransitionMinimumQuiet &&
            changedFor >= kMapTransitionPostChangeQuiet) {
            gUseConstructedActionData.store(true);
            ResetTransitionTracking();
            ResetCycle(OX_NS("MAP MỚI ĐÃ ỔN ĐỊNH - TIẾP TỤC AUTO"), 1.0);
            return true;
        }
    }

    double elapsed = now - gPhaseStartedAt.load();
    if (!gTransitionChangeObserved.load() &&
        elapsed >= kMapTransitionNoChangeRecovery) {
        CancelMapTransitionWait();
        gResumeRouteAfterStagePopup.store(true);
        gResumeRouteAfterStagePopupAt.store(
            now + kStagePopupRouteResumeDelay);
        SetStatus(OX_NS("CHƯA CHUYỂN MAP - ĐANG GỌI LẠI ĐƯỜNG ĐI"));
        return true;
    }
    if (elapsed >= kMapTransitionTimeout) {
        SetStatus(OX_NS("MAP ĐANG TẢI LÂU - AUTO VẪN TẠM DỪNG"));
    } else if (gTransitionChangeObserved.load()) {
        SetStatus(OX_NS("ĐÃ SANG MAP MỚI - CHỜ TẢI XONG"));
    } else {
        SetStatus(OX_NS("ĐANG CHỜ GAME CHUYỂN MAP"));
    }
    return false;
}

enum class StagePopupState : int {
    Error = -1,
    Closed = 0,
    Open = 1
};

static StagePopupState QueryStagePopupOpen(
    void *popupController) {
    if (!popupController ||
        !gStagePopupIsOpenMethod) {
        return StagePopupState::Error;
    }

    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        gStagePopupIsOpenMethod,
        popupController,
        nullptr,
        &exception);
    if (exception) {
        return StagePopupState::Error;
    }

    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return StagePopupState::Error;
    }
    return *reinterpret_cast<bool *>(unboxed)
        ? StagePopupState::Open
        : StagePopupState::Closed;
}

static bool HandleStagePopupIfOpen(double now) {
    void *popupController =
        FindCurrentStagePopupController();
    if (!popupController) return false;

    StagePopupState state =
        QueryStagePopupOpen(popupController);
    if (state == StagePopupState::Error) {
        return false;
    }
    if (state == StagePopupState::Closed) {
        gStagePopupCloseIssued.store(false);
        return false;
    }

    if (!gStagePopupCloseIssued.exchange(true)) {
        void *exception = nullptr;
        Il2CppRuntimeInvoke(
            gStagePopupCloseMethod,
            popupController,
            nullptr,
            &exception);
        if (exception) {
            gStagePopupCloseIssued.store(false);
            return false;
        }
        ReleaseCycleObjects();
        gProgressNavigationIssued.store(false);
        gAutoSelectIssued.store(false);
        gAutoSelectIssuedAt.store(0.0);
        gRouteInvocationIssued.store(false);
        gRouteIssuedAt.store(0.0);
        gResumeRouteAfterStagePopup.store(true);
        gResumeRouteAfterStagePopupAt.store(
            now + kStagePopupRouteResumeDelay);
        gPhase.store(
            static_cast<int>(AutoPhase::WaitingGameSelection));
        gPhaseStartedAt.store(now);
        gStagePopupCloseIssued.store(true);
        SetStatus(OX_NS("ĐÃ NHẬN CỜ - ĐANG GỌI ĐƯỜNG ĐI TIẾP"));
        gNextStepAt.store(now + kStagePopupRouteResumeDelay);
        return true;
    }

    SetStatus(OX_NS("ĐANG CHỜ MAP MỚI"));
    gNextStepAt.store(now + 0.35);
    return true;
}

static void StopAutoSafely(NSString *status) {
    gEnabled.store(false);
    gManagerScanAttempts.store(0);
    gRuntimeQueryFailures.store(0);
    ClearManager();
    SetStatus(status.length
        ? status
        : OX_NS("AUTO ĐÃ DỪNG AN TOÀN"));
}

static void StopAutoForCurrency() {
    StopAutoSafely(OX_NS("HẾT THUỐC HOẶC BÓNG - AUTO ĐÃ DỪNG"));
}

static bool ScanManager(
    unsigned long long generation) {
    if (!ManagerScanSessionReady(generation)) {
        return false;
    }

    void *manager = FindFirstLiveObject(
        gManagerClass,
        generation);
    if (!manager ||
        !ManagerScanSessionReady(generation)) {
        return false;
    }

    CaptureManager(manager);
    return gSelectionManager.load() != nullptr &&
           gTooltipController.load() != nullptr &&
           gInfoModel.load() != nullptr &&
           gInventoryManager.load() != nullptr;
}

static void RequestManagerScan(void) {
    if (!gEnabled.load() ||
        !gRuntimeReady.load() ||
        gSelectionManager.load()) {
        return;
    }

    unsigned long long generation =
        gManagerScanGeneration.load();
    double now = Now();
    if (now < gManagerScanReadyAt.load()) {
        SetStatus(OX_NS("ĐANG CHỜ HOANG ĐỊA ỔN ĐỊNH"));
        return;
    }
    if (now < gNextManagerScanAllowedAt.load()) {
        return;
    }

    unsigned long long expected = 0;
    if (!gManagerScanPendingGeneration.compare_exchange_strong(
            expected,
            generation)) {
        return;
    }
    if (!ManagerScanSessionReady(generation)) {
        ReleaseManagerScanPending(generation);
        return;
    }

    gNextManagerScanAllowedAt.store(now + kManagerScanInterval);
    int shownAttempt = gManagerScanAttempts.load() + 1;
    SetStatus([NSString stringWithFormat:
        OX_NS("ĐANG TÌM MANAGER %d/%d"),
        shownAttempt,
        kMaxManagerScanAttempts]);

    dispatch_async(dispatch_get_main_queue(), ^{
        if (!ManagerScanSessionReady(generation)) {
            ReleaseManagerScanPending(generation);
            return;
        }

        bool found = ScanManager(generation);
        ReleaseManagerScanPending(generation);

        if (!ManagerScanSessionActive(generation)) {
            return;
        }

        if (found) {
            gManagerScanAttempts.store(0);
            gNextManagerScanAllowedAt.store(0.0);
            gManagerScanReadyAt.store(0.0);
            ResetCycle(OX_NS("ĐÃ NHẬN MANAGER - ĐANG CHẠY"), 1.0);
            return;
        }

        int attempts = gManagerScanAttempts.fetch_add(1) + 1;
        if (attempts >= kMaxManagerScanAttempts) {
            SetStatus(OX_NS("KHÔNG THẤY MANAGER SAU 20 LẦN"));
            return;
        }

        dispatch_after(
            dispatch_time(DISPATCH_TIME_NOW,
                          static_cast<int64_t>(
                              kManagerScanInterval *
                              NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
            if (ManagerScanSessionActive(generation) &&
                !gSelectionManager.load()) {
                RequestManagerScan();
            }
        });
    });
}

static bool InvokeAutoSelectNextInteraction(
    void *manager,
    bool supportOutOfCurrency) {
    if (!manager || !gAutoSelectNextInteractionMethod) {
        return false;
    }
    void *parameters[1] = { &supportOutOfCurrency };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gAutoSelectNextInteractionMethod,
        manager,
        parameters,
        &exception);
    if (exception) {
        return false;
    }
    gAutoSelectIssued.store(true);
    gAutoSelectIssuedAt.store(Now());
    return true;
}

static bool ReadAllStageGatesPassed(
    void *buttonsController,
    bool *querySucceeded = nullptr) {
    if (querySucceeded) *querySucceeded = false;
    if (!IsPlausiblePointer(buttonsController) ||
        gButtonsAllStageGatesPassedOffset == SIZE_MAX) {
        return false;
    }
    bool passed = *reinterpret_cast<bool *>(
        reinterpret_cast<uintptr_t>(buttonsController) +
        gButtonsAllStageGatesPassedOffset);
    if (querySucceeded) *querySucceeded = true;
    return passed;
}

static bool InvokeProgressMapRoute(void) {
    if (!gProgressMapButtonPressedMethod) {
        return false;
    }
    void *buttonsController = FindCurrentButtonsController();
    if (!buttonsController) {
        return false;
    }

    bool gateQuerySucceeded = false;
    bool allGatesPassed = ReadAllStageGatesPassed(
        buttonsController,
        &gateQuerySucceeded);

    char previousTarget[128] = {0};
    Il2CppString *selected = ReadSelectedInteractionIdDirect(
        gInfoModel.load());
    CopyManagedString(selected,
                      previousTarget,
                      sizeof(previousTarget));

    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gProgressMapButtonPressedMethod,
        buttonsController,
        nullptr,
        &exception);
    if (exception) {
        return false;
    }

    double now = Now();
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(gPortalPreviousTargetText,
                 sizeof(gPortalPreviousTargetText),
                 OX_C("%s"),
                 previousTarget);
    }
    ReleaseCycleObjects();
    gProgressNavigationIssued.store(true);
    gPortalRouteStartedAt.store(now);
    gNextPortalActionAt.store(now + kPortalActionFirstDelay);
    gPortalActionAttempts.store(0);
    gPortalActionInvoked.store(false);
    gNextPortalFlagAt.store(now + kPortalFlagFirstDelay);
    gPortalFlagAttempts.store(0);
    gPhase.store(static_cast<int>(AutoPhase::WaitingPortalAction));
    gPhaseStartedAt.store(now);
    gNextStepAt.store(now + 0.25);

    SetStatus(OX_NS("ĐANG CHỜ NÚT ĐI VÀO CỦA CỔNG"));
    return true;
}

static void *CreateFreshTeleportActionData(
    Il2CppString *interactionId) {
    if (!interactionId ||
        !gTeleportActionDataClass ||
        !gTeleportActionDataCtorMethod) {
        return nullptr;
    }
    void *actionData = Il2CppCreateClassInstanceFromClass(
        gTeleportActionDataClass);
    if (!IsPlausiblePointer(actionData)) {
        return nullptr;
    }
    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gTeleportActionDataCtorMethod,
        actionData,
        parameters,
        &exception);
    if (exception) {
        return nullptr;
    }
    return actionData;
}

static bool InvokePortalTooltipAction(
    void *tooltip,
    Il2CppString *interactionId) {
    if (!R7f431(0x73B94F21D6A80CE5ULL)) {
        return false;
    }
    if (!tooltip ||
        !interactionId ||
        !gExecuteTeleportActionMethod) {
        return false;
    }

    char targetText[128] = {0};
    CopyManagedString(interactionId,
                      targetText,
                      sizeof(targetText));

    BeginMapTransitionWait(false);
    tooltip = gTooltipController.load();
    if (!IsPlausiblePointer(tooltip)) {
        CancelMapTransitionWait();
        return false;
    }

    void *actionData = CreateFreshTeleportActionData(
        interactionId);
    if (!actionData) {
        CancelMapTransitionWait();
        return false;
    }
    RetainActionObject(actionData);

    void *parameters[1] = { actionData };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gExecuteTeleportActionMethod,
        tooltip,
        parameters,
        &exception);
    if (exception) {
        DiscardCurrentActionHandle();
        CancelMapTransitionWait();
        return false;
    }

    gPortalActionInvoked.store(true);
    SetStatus(OX_NS("ĐÃ BẤM ĐI VÀO - CHỜ GAME CHUYỂN MAP"));
    return true;
}


static bool InvokeSelectInteraction(
    void *manager,
    Il2CppString *interactionId) {
    if (!manager ||
        !interactionId ||
        !gSelectInteractionMethod) {
        return false;
    }

    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gSelectInteractionMethod,
        manager,
        parameters,
        &exception);
    if (exception) {
        return false;
    }

    return true;
}

static bool InvokeTooltipClose(void *tooltip) {
    if (!tooltip || !gTooltipCloseMethod) return true;
    bool animate = false;
    void *parameters[1] = { &animate };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gTooltipCloseMethod,
        tooltip,
        parameters,
        &exception);
    if (exception) {
        return false;
    }
    return true;
}

static bool IsTooltipOpen(void *tooltip,
                          bool *querySucceeded = nullptr) {
    if (querySucceeded) *querySucceeded = false;
    if (!tooltip || !gTooltipIsOpenMethod) return false;

    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        gTooltipIsOpenMethod,
        tooltip,
        nullptr,
        &exception);
    if (exception) {
        return false;
    }

    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return false;
    }

    if (querySucceeded) *querySucceeded = true;
    return *reinterpret_cast<bool *>(unboxed);
}

static Il2CppString *ReadTooltipCurrentTarget(
    void *tooltip,
    bool *querySucceeded = nullptr) {
    if (querySucceeded) *querySucceeded = false;
    if (!tooltip ||
        gTooltipLastTargetOffset == SIZE_MAX ||
        !gGetTooltipTargetIdMethod) {
        return nullptr;
    }

    void *holder =
        *reinterpret_cast<void **>(
            reinterpret_cast<uintptr_t>(tooltip) +
            gTooltipLastTargetOffset);
    if (IsPlausiblePointer(holder)) {
        void *parameters[1] = { holder };
        void *exception = nullptr;
        void *result = Il2CppRuntimeInvoke(
            gGetTooltipTargetIdMethod,
            tooltip,
            parameters,
            &exception);
        if (!exception) {
            Il2CppString *target =
                reinterpret_cast<Il2CppString *>(result);
            if (IsPlausiblePointer(target)) {
                if (querySucceeded) *querySucceeded = true;
                return target;
            }
        }
    }

    if (gTooltipSelectedArrowIdOffset == SIZE_MAX) {
        return nullptr;
    }
    Il2CppString *arrowTarget =
        *reinterpret_cast<Il2CppString **>(
            reinterpret_cast<uintptr_t>(tooltip) +
            gTooltipSelectedArrowIdOffset);
    if (IsPlausiblePointer(arrowTarget)) {
        if (querySucceeded) *querySucceeded = true;
        return arrowTarget;
    }
    return nullptr;
}

static bool IsTeleportGateTarget(
    void *tooltip,
    Il2CppString *interactionId,
    bool *querySucceeded = nullptr) {
    if (querySucceeded) *querySucceeded = false;
    if (!IsPlausiblePointer(tooltip) ||
        !IsPlausiblePointer(interactionId) ||
        !gIsTeleportGateSpawnIdMethod) {
        return false;
    }

    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        gIsTeleportGateSpawnIdMethod,
        tooltip,
        parameters,
        &exception);
    if (exception) {
        return false;
    }
    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return false;
    }
    if (querySucceeded) *querySucceeded = true;
    return *reinterpret_cast<bool *>(unboxed);
}


static bool ContainsTextIgnoreCase(
    const char *text,
    const char *needle) {
    if (!text || !needle || !text[0] || !needle[0]) {
        return false;
    }
    size_t textLength = strlen(text);
    size_t needleLength = strlen(needle);
    if (needleLength > textLength) {
        return false;
    }
    for (size_t index = 0;
         index + needleLength <= textLength;
         ++index) {
        bool matched = true;
        for (size_t offset = 0;
             offset < needleLength;
             ++offset) {
            unsigned char left =
                static_cast<unsigned char>(
                    text[index + offset]);
            unsigned char right =
                static_cast<unsigned char>(
                    needle[offset]);
            if (std::tolower(left) !=
                std::tolower(right)) {
                matched = false;
                break;
            }
        }
        if (matched) {
            return true;
        }
    }
    return false;
}

static bool QueryInteractionTypeFromGameModel(
    Il2CppString *interactionId,
    const char *targetText,
    char *typeText,
    size_t typeTextSize) {
    if (typeText && typeTextSize > 0) {
        typeText[0] = '\0';
    }
    void *infoModel = gInfoModel.load();
    if (!IsPlausiblePointer(infoModel) ||
        !IsPlausiblePointer(interactionId) ||
        !typeText ||
        typeTextSize == 0 ||
        !gGetInteractionDataByIdMethod ||
        gInteractionDataTypeOffset == SIZE_MAX) {
        return false;
    }

    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    void *interactionData = Il2CppRuntimeInvoke(
        gGetInteractionDataByIdMethod,
        infoModel,
        parameters,
        &exception);
    if (exception) {
        return false;
    }
    if (!IsPlausiblePointer(interactionData)) {
        return false;
    }

    Il2CppString *type =
        *reinterpret_cast<Il2CppString **>(
            reinterpret_cast<uintptr_t>(interactionData) +
            gInteractionDataTypeOffset);
    return CopyManagedString(
        type,
        typeText,
        typeTextSize);
}

static bool QueryCustomTaskFromGameModel(
    void *tooltip,
    Il2CppString *interactionId,
    const char *targetText,
    bool *querySucceeded = nullptr) {
    if (querySucceeded) {
        *querySucceeded = false;
    }
    if (!IsPlausiblePointer(interactionId)) {
        return false;
    }

    if (IsPlausiblePointer(tooltip) &&
        gTooltipDataProviderOffset != SIZE_MAX &&
        gTooltipProviderCustomModelOffset != SIZE_MAX &&
        gGetCustomInteractionDataMethod) {
        void *provider =
            *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(tooltip) +
                gTooltipDataProviderOffset);
        void *customModel =
            IsPlausiblePointer(provider)
            ? *reinterpret_cast<void **>(
                reinterpret_cast<uintptr_t>(provider) +
                gTooltipProviderCustomModelOffset)
            : nullptr;
        if (IsPlausiblePointer(customModel)) {
            void *parameters[1] = { interactionId };
            void *exception = nullptr;
            void *customData = Il2CppRuntimeInvoke(
                gGetCustomInteractionDataMethod,
                customModel,
                parameters,
                &exception);
            if (!exception) {
                if (querySucceeded) {
                    *querySucceeded = true;
                }
                if (IsPlausiblePointer(customData)) {
                    return true;
                }
                return false;
            }
        }
    }

    void *infoModel = gInfoModel.load();
    if (!IsPlausiblePointer(infoModel) ||
        !gGetInteractionDataByIdMethod ||
        gInteractionDataTypeOffset == SIZE_MAX) {
        return false;
    }

    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    void *interactionData = Il2CppRuntimeInvoke(
        gGetInteractionDataByIdMethod,
        infoModel,
        parameters,
        &exception);
    if (exception) {
        return false;
    }
    if (!IsPlausiblePointer(interactionData)) {
        if (querySucceeded) {
            *querySucceeded = true;
        }
        return false;
    }

    Il2CppString *type =
        *reinterpret_cast<Il2CppString **>(
            reinterpret_cast<uintptr_t>(interactionData) +
            gInteractionDataTypeOffset);
    char typeText[128] = {0};
    bool hasType = CopyManagedString(
        type,
        typeText,
        sizeof(typeText));
    if (querySucceeded) {
        *querySucceeded = hasType;
    }
    if (!hasType) {
        return false;
    }

    bool custom =
        ContainsTextIgnoreCase(typeText, OX_C("boss")) ||
        ContainsTextIgnoreCase(typeText, OX_C("wheel")) ||
        ContainsTextIgnoreCase(typeText, OX_C("accumulative")) ||
        ContainsTextIgnoreCase(typeText, OX_C("multiplayer")) ||
        ContainsTextIgnoreCase(typeText, OX_C("custom"));
    return custom;
}

static bool IsLikelyCustomTaskTarget(
    void *tooltip,
    Il2CppString *interactionId,
    char *targetText,
    size_t targetTextSize) {
    char local[128] = {0};
    char *output = targetText && targetTextSize > 0
        ? targetText
        : local;
    size_t outputSize = targetText && targetTextSize > 0
        ? targetTextSize
        : sizeof(local);
    if (!CopyManagedString(
            interactionId,
            output,
            outputSize)) {
        return false;
    }
    bool modelQuerySucceeded = false;
    if (QueryCustomTaskFromGameModel(
            tooltip,
            interactionId,
            output,
            &modelQuerySucceeded)) {
        return true;
    }
    size_t length = strlen(output);
    return
        length >= 3 &&
        strcmp(output + length - 3, OX_C("_d2")) == 0;
}

struct MatchingNotEnoughActionResult {
    Il2CppString *target = nullptr;
    void *object = nullptr;
    int callbacks = 0;
    int inspected = 0;
};

static void OnMatchingNotEnoughAction(
    void **objects,
    int count,
    void *userData) {
    MatchingNotEnoughActionResult *result =
        reinterpret_cast<MatchingNotEnoughActionResult *>(
            userData);
    if (!result || !objects || count <= 0 ||
        !result->target ||
        gNotEnoughActionDataIdOffset == SIZE_MAX ||
        result->object) {
        return;
    }

    result->callbacks += count;
    for (int index = 0; index < count; ++index) {
        void *object = objects[index];
        if (!IsPlausiblePointer(object)) continue;
        result->inspected += 1;
        Il2CppString *interactionId =
            *reinterpret_cast<Il2CppString **>(
                reinterpret_cast<uintptr_t>(object) +
                gNotEnoughActionDataIdOffset);
        if (!IsPlausiblePointer(interactionId)) continue;
        if (ManagedStringsEqual(
                interactionId,
                result->target)) {
            result->object = object;
            return;
        }
    }
}

static void *FindMatchingNotEnoughActionData(
    Il2CppString *target) {
    if (!target ||
        !gNotEnoughActionDataClass ||
        gNotEnoughActionDataIdOffset == SIZE_MAX ||
        !gLivenessAllocate ||
        !gLivenessFromStatics ||
        !gLivenessFinalize ||
        !gLivenessFree) {
        return nullptr;
    }

    MatchingNotEnoughActionResult result;
    result.target = target;
    void *state = gLivenessAllocate(
        gNotEnoughActionDataClass,
        32,
        OnMatchingNotEnoughAction,
        &result,
        ReallocateLivenessBuffer);
    if (!state) {
        return nullptr;
    }

    gLivenessFromStatics(state);
    gLivenessFinalize(state);
    gLivenessFree(state);
    return result.object;
}

static bool QueryCanNavigateForSource(
    void *tooltip,
    void *actionData,
    bool *querySucceeded) {
    if (querySucceeded) {
        *querySucceeded = false;
    }
    if (!IsPlausiblePointer(tooltip) ||
        !IsPlausiblePointer(actionData) ||
        !gCanNavigateForSourceMethod) {
        return false;
    }

    void *parameters[1] = { actionData };
    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        gCanNavigateForSourceMethod,
        tooltip,
        parameters,
        &exception);
    if (exception) {
        return false;
    }

    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return false;
    }

    if (querySucceeded) {
        *querySucceeded = true;
    }
    bool canNavigate =
        *reinterpret_cast<bool *>(unboxed);
    return canNavigate;
}

static void *CreateFreshCustomActionData(
    Il2CppString *interactionId,
    bool enteredWithoutTooltip) {
    if (!interactionId ||
        !gCustomActionDataClass ||
        !gCustomActionDataCtorMethod) {
        return nullptr;
    }

    void *actionData =
        Il2CppCreateClassInstanceFromClass(
            gCustomActionDataClass);
    if (!IsPlausiblePointer(actionData)) {
        return nullptr;
    }

    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gCustomActionDataCtorMethod,
        actionData,
        parameters,
        &exception);
    if (exception) {
        return nullptr;
    }

    if (enteredWithoutTooltip &&
        gCustomEnteredWithoutTooltipSetter) {
        bool value = true;
        void *setterParameters[1] = { &value };
        exception = nullptr;
        Il2CppRuntimeInvoke(
            gCustomEnteredWithoutTooltipSetter,
            actionData,
            setterParameters,
            &exception);
    }
    return actionData;
}

static bool InvokeCustomTaskFlow(
    void *tooltip,
    Il2CppString *interactionId,
    bool retry,
    bool detectedFromNotEnough) {
    if (!R7f431(0xC48E2A9175D306BFULL)) {
        return false;
    }
    if (!tooltip || !interactionId ||
        !gExecuteTooltipActionMethod) {
        return false;
    }

    char targetText[128] = {0};
    bool likelyById = IsLikelyCustomTaskTarget(
        tooltip,
        interactionId,
        targetText,
        sizeof(targetText));
    if (!likelyById &&
        !detectedFromNotEnough) {
        return false;
    }
    if (!targetText[0] &&
        !CopyManagedString(
            interactionId,
            targetText,
            sizeof(targetText))) {
        return false;
    }

    int attempt = gTaskFlowAttempts.fetch_add(1) + 1;
    if (attempt > kTaskFlowMaxAttempts) {
        return false;
    }

    if (detectedFromNotEnough) {
        void *actionData =
            FindMatchingNotEnoughActionData(
                interactionId);
        if (!actionData) {
            gNextTaskFlowAttemptAt.store(
                Now() + kTaskFlowRetryDelay);
            return false;
        }

        bool navigationQuerySucceeded = false;
        bool canNavigate = QueryCanNavigateForSource(
            tooltip,
            actionData,
            &navigationQuerySucceeded);
        if (!navigationQuerySucceeded) {
            gNextTaskFlowAttemptAt.store(
                Now() + kTaskFlowRetryDelay);
            return false;
        }
        if (!canNavigate) {
            gTaskClassificationRejected.store(true);
            gNextTaskFlowAttemptAt.store(
                Now() + kTaskFlowRetryDelay);
            return false;
        }

        RetainActionObject(actionData);
        void *parameters[1] = { actionData };
        void *exception = nullptr;
        Il2CppRuntimeInvoke(
            gExecuteTooltipActionMethod,
            tooltip,
            parameters,
            &exception);
        if (exception) {
            DiscardCurrentActionHandle();
            gNextTaskFlowAttemptAt.store(
                Now() + kTaskFlowRetryDelay);
            return false;
        }

        RememberTaskRootTarget(
            interactionId);
        double now = Now();
        if (gTaskFlowStartedAt.load() <= 0.0) {
            gTaskFlowStartedAt.store(now);
        }
        gTaskFlowActive.store(true);
        gTaskClassificationRejected.store(false);
        gTaskDetectedFromNotEnough.store(true);
        gNextTaskFlowAttemptAt.store(
            now + kTaskFlowRetryDelay);
        gPhase.store(
            static_cast<int>(
                AutoPhase::WaitingTaskRedirect));
        gPhaseStartedAt.store(
            gTaskFlowStartedAt.load());
        gNextStepAt.store(now + 0.25);
        SetStatus(OX_NS("ĐÃ BẤM NHIỆM VỤ - GAME ĐANG TÌM VẬT PHẨM THIẾU"));
        return true;
    }

    gCustomFlowObservedActive.store(false);
    gLastCustomFlowState.store(-1);
    void *actionData = CreateFreshCustomActionData(
        interactionId,
        false);
    if (!actionData) {
        gNextTaskFlowAttemptAt.store(
            Now() + kTaskFlowRetryDelay);
        return false;
    }

    RetainActionObject(actionData);
    void *parameters[1] = { actionData };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gExecuteTooltipActionMethod,
        tooltip,
        parameters,
        &exception);
    if (exception) {
        DiscardCurrentActionHandle();
        gNextTaskFlowAttemptAt.store(
            Now() + kTaskFlowRetryDelay);
        return false;
    }

    double now = Now();
    if (gTaskFlowStartedAt.load() <= 0.0) {
        gTaskFlowStartedAt.store(now);
    }
    gTaskFlowActive.store(true);
    gTaskClassificationRejected.store(false);
    gTaskDetectedFromNotEnough.store(
        detectedFromNotEnough);
    gNextTaskFlowAttemptAt.store(
        now + kTaskFlowRetryDelay);
    gPhase.store(
        static_cast<int>(
            AutoPhase::WaitingTaskRedirect));
    gPhaseStartedAt.store(
        gTaskFlowStartedAt.load());
    gNextStepAt.store(now + 0.25);
    SetStatus(OX_NS("ĐÃ BẤM ACTION NHIỆM VỤ - CHỜ GAME CHỌN Ô"));
    return true;
}

enum class CollectInvokeState : int {
    Error = -1,
    NotReady = 0,
    Invoked = 1
};

static void *CreateFreshInteractionActionData(
    Il2CppString *interactionId) {
    if (!interactionId ||
        !gActionDataClass ||
        !gActionDataCtorMethod) {
        return nullptr;
    }
    void *actionData =
        Il2CppCreateClassInstanceFromClass(gActionDataClass);
    if (!IsPlausiblePointer(actionData)) {
        return nullptr;
    }
    void *parameters[1] = { interactionId };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gActionDataCtorMethod,
        actionData,
        parameters,
        &exception);
    if (exception) {
        return nullptr;
    }
    return actionData;
}

static CollectInvokeState InvokeCollectAction(
    void *tooltip,
    Il2CppString *interactionId) {
    HdTrace(@"ACTION", @"COLLECT REQUEST");
    if (!R7f431(0x5D20B8F3C7149E6AULL)) {
        return CollectInvokeState::Error;
    }
    if (!tooltip ||
        !interactionId ||
        !gExecuteInteractionActionMethod ||
        !gExecuteTeleportActionMethod) {
        return CollectInvokeState::Error;
    }

    bool teleportQuerySucceeded = false;
    bool isTeleport = IsTeleportGateTarget(
        tooltip,
        interactionId,
        &teleportQuerySucceeded);
    if (!teleportQuerySucceeded) {
        return CollectInvokeState::NotReady;
    }

    void *actionData = isTeleport
        ? CreateFreshTeleportActionData(interactionId)
        : CreateFreshInteractionActionData(interactionId);
    if (!actionData) {
        return CollectInvokeState::NotReady;
    }

    const char *className = OX_C("<unknown>");
    Il2CppObject *managedObject =
        reinterpret_cast<Il2CppObject *>(actionData);
    if (managedObject && managedObject->klass &&
        managedObject->klass->_1.name) {
        className = managedObject->klass->_1.name;
    }

    gCurrentActionUsedFresh.store(true);
    gForceFreshActionNext.store(false);
    RetainActionObject(actionData);
    void *parameters[1] = { actionData };
    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        isTeleport
            ? gExecuteTeleportActionMethod
            : gExecuteInteractionActionMethod,
        tooltip,
        parameters,
        &exception);
    if (exception) {
        DiscardCurrentActionHandle();
        return CollectInvokeState::Error;
    }

    return CollectInvokeState::Invoked;
}

enum class TargetPassedState : int {
    Error = -1,
    NotPassed = 0,
    Passed = 1
};

static Il2CppString *ReadGameSelectedTarget(
    void *infoModel,
    bool *querySucceeded = nullptr) {
    if (querySucceeded) *querySucceeded = false;
    if (!infoModel ||
        !gGetSelectedInteractionIdMethod) {
        return nullptr;
    }

    void *exception = nullptr;
    void *result = Il2CppRuntimeInvoke(
        gGetSelectedInteractionIdMethod,
        infoModel,
        nullptr,
        &exception);
    if (exception) {
        return nullptr;
    }

    if (querySucceeded) *querySucceeded = true;
    Il2CppString *selected =
        reinterpret_cast<Il2CppString *>(result);
    return IsPlausiblePointer(selected)
        ? selected
        : nullptr;
}

static bool InvokeFlagButtonRoute(void) {
    CurrencyState currencyState = QueryCurrency(nullptr);
    if (currencyState == CurrencyState::NotEnough) {
        StopAutoForCurrency();
        return false;
    }
    if (currencyState == CurrencyState::Error) {
        StopAutoSafely(OX_NS("KHÔNG ĐỌC ĐƯỢC TÀI NGUYÊN - AUTO ĐÃ DỪNG"));
        return false;
    }

    if (!gButtonsControllerClass ||
        !gFlagButtonPressedMethod) {
        return false;
    }

    void *buttonsController =
        FindCurrentButtonsController();
    if (!buttonsController) {
        return false;
    }

    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gFlagButtonPressedMethod,
        buttonsController,
        nullptr,
        &exception);
    if (exception) {
        return false;
    }

    gRouteInvocationIssued.store(true);
    gRouteIssuedAt.store(Now());
    return true;
}

static bool InvokePortalFlagRefresh(void) {
    if (!gFlagButtonPressedMethod) {
        return false;
    }

    void *buttonsController = gButtonsController.load();
    if (!IsPlausiblePointer(buttonsController)) {
        return false;
    }

    void *exception = nullptr;
    Il2CppRuntimeInvoke(
        gFlagButtonPressedMethod,
        buttonsController,
        nullptr,
        &exception);
    if (exception) {
        return false;
    }

    SetStatus(OX_NS("ĐANG GỌI CỜ ĐỂ HIỆN NÚT ĐI VÀO"));
    return true;
}

static bool AdoptGameSelectedTarget(
    Il2CppString *target) {
    char targetText[128] = {0};
    if (!CopyManagedString(
            target,
            targetText,
            sizeof(targetText))) {
        return false;
    }

    if (IsCompletedTargetQuarantined(targetText)) {
        SetStatus(OX_NS("GAME VẪN GIỮ Ô CŨ - ĐANG CHỜ Ô MỚI"));
        return false;
    }

    if (gRequireSelectionChange.load()) {
        char previousText[128] = {0};
        {
            std::lock_guard<std::mutex> lock(gTargetTextMutex);
            snprintf(previousText,
                     sizeof(previousText),
                     OX_C("%s"),
                     gSelectionBeforeText);
        }
        if (previousText[0] &&
            strcmp(targetText, previousText) == 0) {
            SetStatus(OX_NS("CHƯA ĐỦ CỜ - ĐANG CHỜ GAME CHỌN LÁ TIẾP"));
            return false;
        }
        if (previousText[0]) {
            gRequireSelectionChange.store(false);
        }
    }

    Il2CppString *stableTarget = Il2CppString::Create(targetText);
    if (!IsPlausiblePointer(stableTarget)) {
        return false;
    }

    SyncResultRecoveryTarget(targetText);
    gCurrentTarget.store(stableTarget);
    RetainObject(stableTarget, gTargetHandle);
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(gCurrentTargetText,
                 sizeof(gCurrentTargetText),
                 OX_C("%s"),
                 targetText);
    }
    gPhase.store(
        static_cast<int>(
            AutoPhase::WaitingTooltip));
    gPhaseStartedAt.store(Now());
    gNextStepAt.store(Now() + 0.12);
    SetStatus([NSString stringWithFormat:
        OX_NS("GAME CHỌN %@"), [NSString stringWithUTF8String:targetText]]);
    return true;
}

static TargetPassedState QueryCurrentTargetPassed(
    void *infoModel,
    Il2CppString *target) {
    if (!infoModel ||
        !target ||
        !gIsPassedInteractionMethod) {
        return TargetPassedState::Error;
    }

    void *parameters[1] = { target };
    void *exception = nullptr;
    void *boxed = Il2CppRuntimeInvoke(
        gIsPassedInteractionMethod,
        infoModel,
        parameters,
        &exception);
    if (exception) {
        return TargetPassedState::Error;
    }

    void *unboxed = Il2CppObjectUnbox(boxed);
    if (!unboxed) {
        return TargetPassedState::Error;
    }

    return *reinterpret_cast<bool *>(unboxed)
        ? TargetPassedState::Passed
        : TargetPassedState::NotPassed;
}


static bool PollTaskRedirect(double now) {
    void *tooltip = gTooltipController.load();
    void *infoModel = gInfoModel.load();
    Il2CppString *taskTarget = gCurrentTarget.load();
    if (!IsPlausiblePointer(tooltip) ||
        !IsPlausiblePointer(infoModel) ||
        !IsPlausiblePointer(taskTarget)) {
        ClearTaskJourneyState();
        ResetCycle(
            OX_NS("MẤT NHIỆM VỤ - ĐANG CHỌN LẠI"),
            0.8);
        return true;
    }

    char taskText[128] = {0};
    if (!gTaskFlowActive.load() ||
        !CopyManagedString(
            taskTarget,
            taskText,
            sizeof(taskText))) {
        ClearTaskJourneyState();
        ResetCycle(
            OX_NS("MẤT TRẠNG THÁI NHIỆM VỤ - ĐANG CHỌN LẠI"),
            0.5);
        return true;
    }

    TargetPassedState passedState =
        QueryCurrentTargetPassed(
            infoModel,
            taskTarget);
    if (passedState == TargetPassedState::Passed) {
        ClearTaskJourneyState();
        gWaitForNativeContinuation.store(true);
        ResetCycle(
            OX_NS("ĐÃ HOÀN THÀNH NHIỆM VỤ - ĐI TIẾP"),
            0.25);
        return true;
    }

    double startedAt = gTaskFlowStartedAt.load();
    double elapsed = startedAt > 0.0
        ? now - startedAt
        : 0.0;

    bool detectedFromNotEnough =
        gTaskDetectedFromNotEnough.load();
    bool stateQuerySucceeded = false;
    int expeditionState =
        QueryExpeditionState(&stateQuerySucceeded);
    if (stateQuerySucceeded) {
        gLastCustomFlowState.store(expeditionState);

        if (IsCustomInteractionRuntimeState(
                expeditionState)) {
            gCustomFlowObservedActive.store(true);
            if (IsBossCombatRuntimeState(
                    expeditionState)) {
                HdTrace(@"BOSS", @"MANUAL COMBAT REQUIRED");
                SetStatus(OX_NS("GẶP BOSS - HÃY ĐÁNH THỦ CÔNG"));
                gNextStepAt.store(now + 0.5);
                return false;
            }
            ResetBossCombatState(false);
            SetStatus(OX_NS("BOSS ĐÃ XONG - ĐANG CHỜ GAME XÁC NHẬN"));
            gNextStepAt.store(now + 0.35);
            return false;
        }

        if (gCustomFlowObservedActive.load() &&
            expeditionState == 3) {
            gWaitForNativeContinuation.store(true);
            ResetCycle(
                OX_NS("ĐÃ RỜI NHIỆM VỤ CHIẾN ĐẤU - AUTO TIẾP TỤC"),
                0.75);
            return true;
        }
    }

    if (!detectedFromNotEnough) {
        if (stateQuerySucceeded &&
            (expeditionState == 9 ||
             expeditionState == 16)) {
            SetStatus(OX_NS("ĐANG ĐI VÀO NHIỆM VỤ CHIẾN ĐẤU"));
            gNextStepAt.store(now + 0.35);
            return false;
        }
        if (elapsed >= kTaskFlowTimeout) {
            ResetCycle(
                OX_NS("NHIỆM VỤ CHIẾN ĐẤU CHƯA MỞ - ĐANG THỬ LẠI"),
                1.0);
            return true;
        }

        SetStatus(OX_NS("ĐANG MỞ NHIỆM VỤ CHIẾN ĐẤU"));
        gNextStepAt.store(now + 0.35);
        return false;
    }

    bool selectedQuerySucceeded = false;
    Il2CppString *selected =
        ReadGameSelectedTarget(
            infoModel,
            &selectedQuerySucceeded);
    char selectedText[128] = {0};
    bool hasSelected = CopyManagedString(
        selected,
        selectedText,
        sizeof(selectedText));

    if (hasSelected &&
        strcmp(selectedText, taskText) != 0) {
        if (gTaskReturningToRoot.load()) {
            SetStatus(OX_NS("ĐANG CHỜ GAME XÁC NHẬN TRẢ NHIỆM VỤ"));
            gNextStepAt.store(now + 0.25);
            return false;
        }

        if (!RememberTaskRootTarget(taskTarget) ||
            !RememberTaskSourceTarget(selected)) {
            ClearTaskJourneyState();
            ResetCycle(
                OX_NS("KHÔNG GIỮ ĐƯỢC ĐƯỜNG NHIỆM VỤ"),
                0.8);
            return true;
        }


        ReleaseCycleObjects();
        gTaskJourneyActive.store(true);
        gTaskReturningToRoot.store(false);
        gTaskRouteStartedAt.store(now);
        gNextTaskRouteActionAt.store(
            now + kTaskRouteInitialDelay);
        gNextTaskRouteCurrencyCheckAt.store(now);
        gTaskRouteRootCurrencyState.store(-1);
        gTaskRouteFlagAttempts.store(0);
        gTaskSourceSelectionIssued.store(false);
        gPhase.store(static_cast<int>(
            AutoPhase::WaitingTaskRouteSelection));
        gPhaseStartedAt.store(now);
        gNextStepAt.store(now + 0.08);
        SetStatus(OX_NS("ĐÃ TÌM THẤY VẬT PHẨM - ĐANG GỌI CỜ DỌN ĐƯỜNG"));
        return true;
    }

    if (elapsed >= kTaskFlowTimeout) {
        if (gTaskDetectedFromNotEnough.load()) {
            ClearTaskJourneyState();
            StopAutoForCurrency();
            return true;
        }
        ClearTaskJourneyState();
        gWaitForNativeContinuation.store(true);
        ResetCycle(
            OX_NS("NHIỆM VỤ CHƯA ĐỔI MỤC TIÊU - ĐANG MỞ LẠI"),
            1.0);
        return true;
    }

    SetStatus(OX_NS("ĐANG CHỜ GAME CHỈ VẬT PHẨM NHIỆM VỤ"));
    return false;
}

static bool BeginTaskRouteSelection(double delay,
                                    NSString *status) {
    if (!gTaskJourneyActive.load()) {
        return false;
    }
    ReleaseCycleObjects();
    double now = Now();
    gTaskRouteStartedAt.store(now);
    gNextTaskRouteActionAt.store(now + delay);
    gNextTaskRouteCurrencyCheckAt.store(now);
    gTaskRouteRootCurrencyState.store(-1);
    gTaskRouteFlagAttempts.store(0);
    gTaskSourceSelectionIssued.store(false);
    gPhase.store(static_cast<int>(
        AutoPhase::WaitingTaskRouteSelection));
    gPhaseStartedAt.store(now);
    gNextStepAt.store(now + 0.07);
    if (status.length) {
        SetStatus(status);
    }
    return true;
}

static bool PollTaskRouteSelection(double now) {
    void *manager = gSelectionManager.load();
    void *tooltip = gTooltipController.load();
    void *infoModel = gInfoModel.load();
    char rootId[128] = {0};
    char sourceId[128] = {0};
    bool hasJourneyIds = CopyTaskJourneyIds(
        rootId, sizeof(rootId), sourceId, sizeof(sourceId));
    Il2CppString *root = hasJourneyIds
        ? CreateTaskIdString(rootId)
        : nullptr;
    Il2CppString *source = hasJourneyIds
        ? CreateTaskIdString(sourceId)
        : nullptr;

    if (!gTaskJourneyActive.load() ||
        !IsPlausiblePointer(manager) ||
        !IsPlausiblePointer(tooltip) ||
        !IsPlausiblePointer(infoModel) ||
        !hasJourneyIds ||
        !IsPlausiblePointer(root) ||
        !IsPlausiblePointer(source)) {
        ClearTaskJourneyState();
        ResetCycle(
            OX_NS("MẤT ĐƯỜNG NHIỆM VỤ - ĐANG CHỌN LẠI"),
            0.8);
        return true;
    }

    TargetPassedState rootPassed =
        QueryCurrentTargetPassed(infoModel, root);
    if (rootPassed == TargetPassedState::Passed) {
        ClearTaskJourneyState();
        gWaitForNativeContinuation.store(true);
        ResetCycle(
            OX_NS("ĐÃ HOÀN THÀNH NHIỆM VỤ - ĐI TIẾP"),
            0.25);
        return true;
    }

    CurrencyState rootCurrency =
        static_cast<CurrencyState>(
            gTaskRouteRootCurrencyState.load());
    if (now >= gNextTaskRouteCurrencyCheckAt.load()) {
        rootCurrency = QueryCurrency(root);
        gTaskRouteRootCurrencyState.store(
            static_cast<int>(rootCurrency));
        gNextTaskRouteCurrencyCheckAt.store(
            now + kTaskRouteCurrencyCheckInterval);
    }
    if (rootCurrency == CurrencyState::Error) {
        SetStatus(OX_NS("ĐANG KIỂM TRA VẬT PHẨM NHIỆM VỤ"));
        gNextStepAt.store(now + 0.35);
        return false;
    }
    if (rootCurrency == CurrencyState::Enough) {
        gTaskReturningToRoot.store(true);
    }

    bool selectedQuerySucceeded = false;
    Il2CppString *selected =
        ReadGameSelectedTarget(
            infoModel,
            &selectedQuerySucceeded);
    char selectedText[128] = {0};
    bool hasSelected =
        CopyManagedString(
            selected,
            selectedText,
            sizeof(selectedText));

    bool routeTooltipQuerySucceeded = false;
    bool routeTooltipOpen =
        IsTooltipOpen(
            tooltip,
            &routeTooltipQuerySucceeded);
    Il2CppString *routeTooltipTarget = nullptr;
    char routeTooltipTargetText[128] = {0};
    if (routeTooltipQuerySucceeded &&
        routeTooltipOpen) {
        bool targetQuerySucceeded = false;
        routeTooltipTarget =
            ReadTooltipCurrentTarget(
                tooltip,
                &targetQuerySucceeded);
        if (!targetQuerySucceeded ||
            !CopyManagedString(
                routeTooltipTarget,
                routeTooltipTargetText,
                sizeof(routeTooltipTargetText))) {
            routeTooltipTarget = nullptr;
            routeTooltipTargetText[0] = '\0';
        }
    }

    if (gTaskReturningToRoot.load()) {
        if (IsPlausiblePointer(routeTooltipTarget) &&
            ManagedStringsEqual(routeTooltipTarget, root)) {
            TargetPassedState state =
                QueryCurrentTargetPassed(
                    infoModel,
                    routeTooltipTarget);
            if (state == TargetPassedState::NotPassed) {
                ReleaseCycleObjects();
                if (AdoptGameSelectedTarget(root)) {
                    SetStatus(OX_NS("ĐÃ VỀ NHIỆM VỤ - ĐANG TRẢ VẬT PHẨM"));
                    return true;
                }
            }
        }

        if (hasSelected &&
            ManagedStringsEqual(selected, root)) {
            TargetPassedState state =
                QueryCurrentTargetPassed(
                    infoModel,
                    selected);
            if (state == TargetPassedState::NotPassed) {
                ReleaseCycleObjects();
                if (AdoptGameSelectedTarget(root)) {
                    SetStatus(OX_NS("ĐÃ VỀ NHIỆM VỤ - ĐANG TRẢ VẬT PHẨM"));
                    return true;
                }
            }
        }

        if (now >= gNextTaskRouteActionAt.load()) {
            InvokeTooltipClose(tooltip);
            int attempt =
                gTaskRouteFlagAttempts.fetch_add(1) + 1;
            if (InvokeFlagButtonRoute()) {
                gNextTaskRouteActionAt.store(
                    now + kTaskRouteFlagRetryDelay);
                SetStatus(OX_NS("ĐỦ VẬT PHẨM - ĐANG GỌI CỜ VỀ TRẢ NHIỆM VỤ"));
                gNextStepAt.store(now + 0.08);
                return false;
            }

            if (attempt >= 3) {
                InvokeSelectInteraction(manager, root);
                gNextTaskRouteActionAt.store(
                    now + kTaskRouteSelectSettleDelay);
            } else {
                gNextTaskRouteActionAt.store(
                    now + kTaskRouteFlagRetryDelay);
            }
        }

        gNextStepAt.store(now + 0.08);
        return false;
    }

    if (IsPlausiblePointer(routeTooltipTarget) &&
        !ManagedStringsEqual(routeTooltipTarget, root)) {
        bool isSourceTooltip =
            ManagedStringsEqual(routeTooltipTarget, source);
        TargetPassedState state =
            QueryCurrentTargetPassed(
                infoModel,
                routeTooltipTarget);
        if (state == TargetPassedState::NotPassed &&
            (!isSourceTooltip ||
             gTaskRouteFlagAttempts.load() > 0)) {
            ReleaseCycleObjects();
            if (AdoptGameSelectedTarget(
                    routeTooltipTarget)) {
                SetStatus(isSourceTooltip
                    ? OX_NS("ĐÃ TỚI VẬT PHẨM NHIỆM VỤ - ĐANG THU")
                    : OX_NS("ĐANG THU CHƯỚNG NGẠI VẬT TRÊN ĐƯỜNG NHIỆM VỤ"));
                return true;
            }
        }
    }

    if (hasSelected &&
        !ManagedStringsEqual(selected, root) &&
        !ManagedStringsEqual(selected, source)) {
        TargetPassedState state =
            QueryCurrentTargetPassed(
                infoModel,
                selected);
        if (state == TargetPassedState::NotPassed) {
            ReleaseCycleObjects();
            if (AdoptGameSelectedTarget(selected)) {
                SetStatus(OX_NS("ĐANG THU CHƯỚNG NGẠI VẬT TRÊN ĐƯỜNG NHIỆM VỤ"));
                return true;
            }
        }
    }


    if (now >= gNextTaskRouteActionAt.load()) {
        bool sourceSelected =
            hasSelected &&
            ManagedStringsEqual(selected, source);

        if (!sourceSelected) {
            InvokeTooltipClose(tooltip);
            InvokeSelectInteraction(manager, source);
            gTaskSourceSelectionIssued.store(true);
            gNextTaskRouteActionAt.store(
                now + kTaskRouteSelectSettleDelay);
            SetStatus(OX_NS("ĐANG GIỮ MỤC TIÊU VẬT PHẨM NHIỆM VỤ"));
            gNextStepAt.store(now + 0.07);
            return false;
        }

        InvokeTooltipClose(tooltip);
        gTaskRouteFlagAttempts.fetch_add(1);
        if (InvokeFlagButtonRoute()) {
            gNextTaskRouteActionAt.store(
                now + kTaskRouteFlagRetryDelay);
            SetStatus(OX_NS("ĐÃ BẤM CỜ - ĐANG CHỜ CHƯỚNG NGẠI VẬT TRÊN ĐƯỜNG"));
        } else {
            gNextTaskRouteActionAt.store(
                now + kTaskRouteFlagRetryDelay);
            SetStatus(OX_NS("CHƯA BẤM ĐƯỢC CỜ NHIỆM VỤ - ĐANG THỬ LẠI"));
        }
        gNextStepAt.store(now + 0.08);
        return false;
    }

    double elapsed =
        now - gTaskRouteStartedAt.load();
    if (elapsed >= kTaskRouteTimeout ||
        gTaskRouteFlagAttempts.load() >=
            kTaskRouteMaxFlagAttempts) {
        InvokeSelectInteraction(manager, source);
        gTaskRouteStartedAt.store(now);
        gTaskRouteFlagAttempts.store(0);
        gNextTaskRouteCurrencyCheckAt.store(now);
        gTaskRouteRootCurrencyState.store(-1);
        gNextTaskRouteActionAt.store(
            now + kTaskRouteInitialDelay);
        SetStatus(OX_NS("ĐANG GỌI LẠI ĐƯỜNG TỚI VẬT PHẨM NHIỆM VỤ"));
    }

    if (!selectedQuerySucceeded) {
        SetStatus(OX_NS("ĐANG ĐỌC MỤC TIÊU TRÊN ĐƯỜNG NHIỆM VỤ"));
    }
    gNextStepAt.store(now + 0.08);
    return false;
}

static bool PollPortalTooltipAction(double now) {
    if (now < gNextPortalActionAt.load()) {
        return false;
    }
    gNextPortalActionAt.store(
        now + kPortalActionRetryInterval);

    void *tooltip = gTooltipController.load();
    void *infoModel = gInfoModel.load();
    if (!IsPlausiblePointer(tooltip) ||
        !IsPlausiblePointer(infoModel)) {
        SetStatus(OX_NS("ĐANG CHỜ TOOLTIP CỔNG"));
        return false;
    }

    bool selectedQuerySucceeded = false;
    Il2CppString *selected = ReadGameSelectedTarget(
        infoModel,
        &selectedQuerySucceeded);
    char selectedText[128] = {0};
    bool hasSelected = CopyManagedString(
        selected,
        selectedText,
        sizeof(selectedText));
    if (hasSelected &&
        RememberOrDetectMapChange(selectedText)) {
        BeginMapTransitionWait(true);
        return true;
    }

    bool tooltipQuerySucceeded = false;
    bool tooltipOpen = IsTooltipOpen(
        tooltip,
        &tooltipQuerySucceeded);
    bool tooltipTargetQuerySucceeded = false;
    Il2CppString *tooltipTarget = tooltipOpen
        ? ReadTooltipCurrentTarget(
              tooltip,
              &tooltipTargetQuerySucceeded)
        : nullptr;
    char tooltipText[128] = {0};
    bool hasTooltipTarget = CopyManagedString(
        tooltipTarget,
        tooltipText,
        sizeof(tooltipText));

    Il2CppString *candidate = hasTooltipTarget
        ? tooltipTarget
        : (hasSelected ? selected : nullptr);
    char candidateText[128] = {0};
    bool hasCandidate = CopyManagedString(
        candidate,
        candidateText,
        sizeof(candidateText));

    char previousText[128] = {0};
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(previousText,
                 sizeof(previousText),
                 OX_C("%s"),
                 gPortalPreviousTargetText);
    }
    TargetPassedState state = hasCandidate
        ? QueryCurrentTargetPassed(infoModel, candidate)
        : TargetPassedState::Error;
    bool candidateChanged =
        hasCandidate &&
        (!previousText[0] ||
         strcmp(candidateText, previousText) != 0);


    bool portalCandidate =
        hasTooltipTarget ||
        (hasSelected && candidateChanged);
    if (tooltipOpen &&
        hasCandidate &&
        portalCandidate) {
        int attempt = gPortalActionAttempts.fetch_add(1) + 1;
        if (attempt <= kPortalActionMaxAttempts &&
            InvokePortalTooltipAction(
                tooltip,
                candidate)) {
            return true;
        }
    }

    double elapsed = now - gPortalRouteStartedAt.load();
    if (!tooltipOpen &&
        hasSelected &&
        !candidateChanged &&
        state == TargetPassedState::Passed &&
        now >= gNextPortalFlagAt.load() &&
        gPortalFlagAttempts.load() < kPortalFlagMaxAttempts) {
        int flagAttempt = gPortalFlagAttempts.fetch_add(1) + 1;
        gNextPortalFlagAt.store(now + kPortalFlagRetryInterval);
        InvokePortalFlagRefresh();
        return false;
    }

    if (elapsed >= kPortalTooltipTimeout) {
        ResetCycle(OX_NS("CHƯA BẤM ĐƯỢC ĐI VÀO - ĐANG THỬ LẠI"), 1.0);
        return true;
    }

    if (tooltipOpen) {
        SetStatus(OX_NS("ĐÃ THẤY CỔNG - ĐANG BẤM ĐI VÀO"));
    } else {
        SetStatus(OX_NS("ĐANG CHỜ NÚT ĐI VÀO CỦA CỔNG"));
    }
    return false;
}


static bool BeginTargetCycle(void) {
    HdTrace(@"TARGET", @"BEGIN");
    void *manager = gSelectionManager.load();
    void *tooltip = gTooltipController.load();
    void *infoModel = gInfoModel.load();
    if (!manager || !tooltip || !infoModel) {
        return false;
    }

    bool forceRouteRefresh = gForceRouteRefresh.exchange(false);
    if (gTaskJourneyActive.load()) {
        return BeginTaskRouteSelection(
            forceRouteRefresh ? 0.15 : 0.25,
            gTaskReturningToRoot.load()
                ? OX_NS("ĐANG GỌI CỜ VỀ TRẢ NHIỆM VỤ")
                : OX_NS("ĐANG GỌI CỜ DỌN ĐƯỜNG NHIỆM VỤ"));
    }

    char beforeText[128] = {0};
    Il2CppString *before =
        ReadGameSelectedTarget(infoModel);
    bool hasBefore = CopyManagedString(
        before,
        beforeText,
        sizeof(beforeText));
    bool mapChanged = hasBefore &&
        RememberOrDetectMapChange(beforeText);
    if (mapChanged) {
        BeginMapTransitionWait(true);
        return true;
    }
    TargetPassedState beforeState =
        hasBefore
        ? QueryCurrentTargetPassed(infoModel, before)
        : TargetPassedState::Error;
    bool waitForNativeContinuation =
        gWaitForNativeContinuation.exchange(false);

    ReleaseCycleObjects();

    if (hasBefore &&
        beforeState == TargetPassedState::NotPassed &&
        !forceRouteRefresh) {
        return AdoptGameSelectedTarget(before);
    }
    {
        std::lock_guard<std::mutex> lock(gTargetTextMutex);
        snprintf(gSelectionBeforeText,
                 sizeof(gSelectionBeforeText),
                 OX_C("%s"),
                 beforeText);
    }

    gPhase.store(
        static_cast<int>(
            AutoPhase::WaitingGameSelection));
    gPhaseStartedAt.store(Now());
    gNextStepAt.store(Now() + 0.25);
    gRouteInvocationIssued.store(false);
    gRouteIssuedAt.store(0.0);
    if (waitForNativeContinuation) {
        SetStatus(OX_NS("ĐANG CHỜ GAME CHỌN Ô TIẾP"));
        return true;
    }

    InvokeTooltipClose(tooltip);
    HdTrace(@"TARGET", @"REQUEST NATIVE ROUTE SELECTION");
    if (InvokeFlagButtonRoute()) {
        HdTrace(@"TARGET", @"NATIVE FLAG ROUTE REQUESTED");
        SetStatus(OX_NS("ĐANG CHỌN MỤC TIÊU THEO ĐƯỜNG GAME"));
        return true;
    }
    if (InvokeAutoSelectNextInteraction(manager, false)) {
        HdTrace(@"TARGET", @"FALLBACK AUTO SELECT");
        SetStatus(OX_NS("ĐANG CHỌN MỤC TIÊU DỰ PHÒNG"));
        return true;
    }
    HdTrace(@"TARGET", @"NO TARGET ROUTE AVAILABLE");
    ResetCycle(OX_NS("CHƯA CHỌN ĐƯỢC MỤC TIÊU"), 1.0);
    return false;
}

static void RunAutoStep(void) {
    if (!R7f431(0xE9164C2B7A80D35FULL)) {
        ExpeditionAutoSetEnabled(false);
        return;
    }
    if (!gEnabled.load() || !gRuntimeReady.load()) return;

    SweepRetiredActionHandles(false);
    void *manager = gSelectionManager.load();
    void *tooltip = gTooltipController.load();
    void *infoModel = gInfoModel.load();
    if (!manager || !tooltip || !infoModel) {
        RequestManagerScan();
        return;
    }

    AutoPhase phase =
        static_cast<AutoPhase>(gPhase.load());
    double now = Now();

    if ((phase == AutoPhase::Idle ||
         phase == AutoPhase::WaitingGameSelection ||
         (phase == AutoPhase::WaitingMapTransition &&
          !gStagePopupCloseIssued.load() &&
          !gTransitionChangeObserved.load() &&
          now - gPhaseStartedAt.load() <
              kMapTransitionMinimumQuiet)) &&
        HandleStagePopupIfOpen(now)) {
        return;
    }

    if (phase == AutoPhase::Idle) {
        BeginTargetCycle();
        return;
    }

    if (phase == AutoPhase::WaitingPortalAction) {
        if (PollPortalTooltipAction(now)) {
            return;
        }
        gNextStepAt.store(now + 0.25);
        return;
    }

    if (phase == AutoPhase::WaitingMapTransition) {
        if (PollMapTransitionReady(now)) {
            return;
        }
        gNextStepAt.store(now + 0.25);
        return;
    }

    if (phase == AutoPhase::WaitingTaskRedirect) {
        if (PollTaskRedirect(now)) {
            return;
        }
        gNextStepAt.store(now + 0.25);
        return;
    }

    if (phase == AutoPhase::WaitingTaskRouteSelection) {
        if (PollTaskRouteSelection(now)) {
            return;
        }
        gNextStepAt.store(now + 0.08);
        return;
    }

    if (phase == AutoPhase::WaitingGameSelection) {
        double elapsed =
            now - gPhaseStartedAt.load();

        if (gResumeRouteAfterStagePopup.load() &&
            now >= gResumeRouteAfterStagePopupAt.load()) {
            gResumeRouteAfterStagePopup.store(false);
            gResumeRouteAfterStagePopupAt.store(0.0);
            InvokeTooltipClose(tooltip);
            if (InvokeFlagButtonRoute()) {
                gPhaseStartedAt.store(now);
                gNextStepAt.store(now + 0.25);
                SetStatus(OX_NS("ĐÃ BẤM CỜ - ĐANG ĐI TIẾP"));
                return;
            }
            gResumeRouteAfterStagePopup.store(true);
            gResumeRouteAfterStagePopupAt.store(now + 0.8);
            SetStatus(OX_NS("CHƯA GỌI ĐƯỢC CỜ - ĐANG THỬ LẠI"));
            gNextStepAt.store(now + 0.8);
            return;
        }

        bool tooltipQuerySucceeded = false;
        bool tooltipOpen =
            IsTooltipOpen(
                tooltip,
                &tooltipQuerySucceeded);
        if (tooltipQuerySucceeded && tooltipOpen) {
            bool tooltipTargetQuerySucceeded = false;
            Il2CppString *tooltipTarget =
                ReadTooltipCurrentTarget(
                    tooltip,
                    &tooltipTargetQuerySucceeded);
            char tooltipTargetText[128] = {0};
            bool hasTooltipTarget =
                tooltipTargetQuerySucceeded &&
                CopyManagedString(
                    tooltipTarget,
                    tooltipTargetText,
                    sizeof(tooltipTargetText));
            if (hasTooltipTarget) {
                TargetPassedState tooltipTargetState =
                    QueryCurrentTargetPassed(
                        infoModel,
                        tooltipTarget);
                if (tooltipTargetState ==
                    TargetPassedState::NotPassed) {
                    if (AdoptGameSelectedTarget(
                            tooltipTarget)) {
                        return;
                    }
                }
            }

        }

        bool querySucceeded = false;
        Il2CppString *selected =
            ReadGameSelectedTarget(
                infoModel,
                &querySucceeded);
        char selectedText[128] = {0};
        bool hasSelected =
            CopyManagedString(
                selected,
                selectedText,
                sizeof(selectedText));
        if (hasSelected &&
            RememberOrDetectMapChange(selectedText)) {
            BeginMapTransitionWait(true);
            return;
        }
        char beforeText[128] = {0};
        {
            std::lock_guard<std::mutex> lock(
                gTargetTextMutex);
            snprintf(beforeText,
                     sizeof(beforeText),
                     OX_C("%s"),
                     gSelectionBeforeText);
        }
        bool changed =
            hasSelected &&
            (!beforeText[0] ||
             strcmp(selectedText, beforeText) != 0);
        bool canAdopt = changed;
        bool requireSelectionChange =
            gRequireSelectionChange.load();

        if (hasSelected &&
            !changed &&
            elapsed >= 0.75) {
            TargetPassedState existingState =
                QueryCurrentTargetPassed(
                    infoModel,
                    selected);
            canAdopt =
                !requireSelectionChange &&
                existingState ==
                    TargetPassedState::NotPassed;
            if (existingState ==
                TargetPassedState::Passed) {
                SetStatus(OX_NS("GAME CHƯA CÓ MỤC TIÊU TIẾP"));
            }
        }

        if (hasSelected &&
            canAdopt) {
            if (AdoptGameSelectedTarget(selected)) {
                return;
            }
        }

        if (!gRouteInvocationIssued.load() &&
            elapsed >= kNativeContinuationDelay) {
            InvokeTooltipClose(tooltip);
            if (!InvokeFlagButtonRoute()) {
                ResetCycle(
                    OX_NS("ĐANG TÌM NÚT CỜ CỦA GAME"),
                    1.0);
                return;
            }
            SetStatus(OX_NS("ĐANG GỌI ĐƯỜNG TIẾP CỦA GAME"));
            gNextStepAt.store(now + 0.25);
            return;
        }

        double routeElapsed =
            gRouteInvocationIssued.load()
            ? now - gRouteIssuedAt.load()
            : elapsed;

        if (gRouteInvocationIssued.load() &&
            requireSelectionChange &&
            routeElapsed >= kAutoSelectFallbackDelay) {
            if (!gAutoSelectIssued.load()) {
                if (InvokeAutoSelectNextInteraction(
                        manager,
                        false)) {
                    SetStatus(OX_NS("CHƯA ĐỦ CỜ - GAME ĐANG TÌM LÁ TIẾP"));
                    gNextStepAt.store(now + 0.35);
                    return;
                }
                gAutoSelectIssued.store(true);
                gAutoSelectIssuedAt.store(now);
            }
            if (gAutoSelectIssued.load() &&
                now - gAutoSelectIssuedAt.load() >=
                    kProgressRouteDelayAfterAutoSelect) {
                gAutoSelectIssued.store(false);
                gAutoSelectIssuedAt.store(0.0);
                InvokeTooltipClose(tooltip);
                if (!InvokeFlagButtonRoute()) {
                    ResetCycle(
                        OX_NS("ĐANG TÌM NÚT CỜ CỦA GAME"),
                        1.0);
                    return;
                }
                SetStatus(OX_NS("CHƯA ĐỦ CỜ - ĐANG TÌM LÁ TIẾP"));
                gNextStepAt.store(now + 0.35);
                return;
            }
        }

        if (gRouteInvocationIssued.load() &&
            routeElapsed >= kAutoSelectFallbackDelay &&
            !requireSelectionChange &&
            !gProgressNavigationIssued.load()) {
            if (!gAutoSelectIssued.load()) {
                if (InvokeAutoSelectNextInteraction(
                        manager,
                        false)) {
                    SetStatus(OX_NS("ĐANG ĐỂ GAME TỰ CHỌN ĐƯỜNG TIẾP"));
                    gNextStepAt.store(now + 0.35);
                    return;
                }
                gAutoSelectIssued.store(true);
                gAutoSelectIssuedAt.store(now);
            }
            if (gAutoSelectIssued.load() &&
                now - gAutoSelectIssuedAt.load() >=
                    kProgressRouteDelayAfterAutoSelect) {
                if (InvokeProgressMapRoute()) {
                    return;
                }
                SetStatus(OX_NS("CHƯA BẤM ĐƯỢC NÚT SANG MAP - ĐANG THỬ LẠI"));
                gNextStepAt.store(now + 1.0);
                return;
            }
        }

        if (gRouteInvocationIssued.load() &&
            routeElapsed >= kSelectionTimeout) {
            ResetCycle(
                OX_NS("GAME CHƯA TRẢ VỀ MỤC TIÊU"),
                1.5);
            return;
        }

        if (!querySucceeded) {
            SetStatus(OX_NS("ĐANG ĐỌC MỤC TIÊU GAME CHỌN"));
        }
        gNextStepAt.store(now + 0.25);
        return;
    }

    if (phase == AutoPhase::WaitingTooltip) {
        Il2CppString *target = gCurrentTarget.load();
        if (!target) {
            ResetCycle(OX_NS("MẤT MỤC TIÊU - ĐANG CHỌN LẠI"), 1.0);
            return;
        }

        double elapsed = now - gPhaseStartedAt.load();
        bool querySucceeded = false;
        bool tooltipOpen =
            IsTooltipOpen(tooltip, &querySucceeded);

        if (querySucceeded &&
            tooltipOpen &&
            elapsed >= kCollectReadyDelay) {
            char selectedTargetText[128] = {0};
            CopyManagedString(
                target,
                selectedTargetText,
                sizeof(selectedTargetText));
            char interactionType[96] = {0};
            if (!QueryInteractionTypeFromGameModel(
                    target,
                    selectedTargetText,
                    interactionType,
                    sizeof(interactionType))) {
                SetStatus(OX_NS("ĐANG ĐỌC LOẠI MỤC TIÊU CỦA GAME"));
                gNextStepAt.store(now + 0.08);
                return;
            }
            if (strcmp(interactionType,
                       OX_C("completion_gate")) == 0) {
                void *buttonsController =
                    FindCurrentButtonsController();
                bool gateQuerySucceeded = false;
                bool allStageGatesPassed =
                    ReadAllStageGatesPassed(
                        buttonsController,
                        &gateQuerySucceeded);
                if (!gateQuerySucceeded) {
                    SetStatus(OX_NS("ĐANG KIỂM TRA TIẾN ĐỘ LÁ CỜ"));
                    gNextStepAt.store(now + 0.08);
                    return;
                }
                if (!allStageGatesPassed) {
                    InvokeTooltipClose(tooltip);
                    gWaitForNativeContinuation.store(false);
                    gRequireSelectionChange.store(true);
                    gForceRouteRefresh.store(true);
                    ResetCycle(
                        OX_NS("CHƯA ĐỦ CỜ - ĐANG TÌM LÁ TIẾP"),
                        0.15);
                    return;
                }
            }

            char taskTargetText[128] = {0};
            char savedTaskRootId[128] = {0};
            {
                std::lock_guard<std::mutex> lock(gTargetTextMutex);
                snprintf(savedTaskRootId,
                         sizeof(savedTaskRootId),
                         OX_C("%s"),
                         gTaskRootTargetText);
            }
            bool isReturningTaskRoot =
                gTaskJourneyActive.load() &&
                gTaskReturningToRoot.load() &&
                savedTaskRootId[0] &&
                ManagedStringMatchesText(
                    target,
                    savedTaskRootId);
            if (isReturningTaskRoot) {
                CopyManagedString(
                    target,
                    taskTargetText,
                    sizeof(taskTargetText));
            }
            bool returningTaskReady = false;
            if (isReturningTaskRoot) {
                CurrencyState returnState = QueryCurrency(target);
                if (returnState == CurrencyState::Enough) {
                    returningTaskReady = true;
                    gCurrencyChecked.store(true);
                    SetStatus(OX_NS("ĐỦ VẬT PHẨM - ĐANG TRẢ NHIỆM VỤ"));
                } else if (returnState == CurrencyState::Error) {
                    SetStatus(OX_NS("ĐANG KIỂM TRA VẬT PHẨM TRẢ NHIỆM VỤ"));
                    gNextStepAt.store(now + 0.25);
                    return;
                }
            }

            if (!returningTaskReady &&
                (isReturningTaskRoot ||
                 IsLikelyCustomTaskTarget(
                    tooltip,
                    target,
                    taskTargetText,
                    sizeof(taskTargetText)))) {
                if (gTaskFlowAttempts.load() <
                    kTaskFlowMaxAttempts) {
                    if (InvokeCustomTaskFlow(
                            tooltip,
                            target,
                            false,
                            isReturningTaskRoot)) {
                        return;
                    }
                    gNextTaskFlowAttemptAt.store(
                        now + 0.8);
                    SetStatus(OX_NS("ĐANG MỞ NHIỆM VỤ - THỬ LẠI"));
                    gNextStepAt.store(now + 0.8);
                    return;
                }
                ResetCycle(
                    OX_NS("KHÔNG MỞ ĐƯỢC NHIỆM VỤ - ĐANG CHỌN LẠI"),
                    1.0);
                return;
            }

            if (!gCurrencyChecked.load()) {
                CurrencyState currencyState =
                    QueryCurrency(target);
                if (currencyState ==
                    CurrencyState::NotEnough) {
                    double nextTaskAttempt =
                        gNextTaskFlowAttemptAt.load();
                    if (now >= nextTaskAttempt &&
                        gTaskFlowAttempts.load() <
                            kTaskFlowMaxAttempts) {
                        if (InvokeCustomTaskFlow(
                                tooltip,
                                target,
                                false,
                                true)) {
                            return;
                        }
                    }
                    if (gTaskClassificationRejected.load()) {
                        StopAutoForCurrency();
                        return;
                    }
                    if (gTaskFlowAttempts.load() <
                        kTaskFlowMaxAttempts) {
                        SetStatus(OX_NS("ĐANG KIỂM TRA NHIỆM VỤ TRƯỚC KHI BÁO HẾT THUỐC"));
                        gNextStepAt.store(
                            now + 0.35);
                        return;
                    }
                    StopAutoForCurrency();
                    return;
                }
                if (currencyState ==
                    CurrencyState::Error) {
                    StopAutoSafely(OX_NS("KHÔNG ĐỌC ĐƯỢC TÀI NGUYÊN - AUTO ĐÃ DỪNG"));
                    return;
                }
                gCurrencyChecked.store(true);
            }

            CollectInvokeState collectState =
                InvokeCollectAction(tooltip, target);
            if (collectState ==
                CollectInvokeState::NotReady) {
                SetStatus(OX_NS("ĐANG CHỜ NÚT THU THẬP CỦA GAME"));
                gNextStepAt.store(now + 0.07);
                return;
            }
            if (collectState ==
                CollectInvokeState::Error) {
                ResetCycle(
                    OX_NS("KHÔNG GỌI ĐƯỢC THU THẬP"),
                    1.5);
                return;
            }

            char targetText[128] = {0};
            {
                std::lock_guard<std::mutex> lock(
                    gTargetTextMutex);
                snprintf(targetText,
                         sizeof(targetText),
                         OX_C("%s"),
                         gCurrentTargetText);
            }
            gPhase.store(
                static_cast<int>(
                    AutoPhase::WaitingResult));
            gPhaseStartedAt.store(now);
            gLastResultPollAt.store(0.0);
            gNextStepAt.store(now + 0.08);
            SetStatus([NSString stringWithFormat:
                OX_NS("ĐANG THU THẬP %@"),
                [NSString stringWithUTF8String:targetText]]);
            return;
        }

        bool recoverySelectionPending =
            gResultRecoveryAttempts.load() > 0;
        double selectionFallbackDelay =
            recoverySelectionPending ? 0.08 : 5.0;
        if (!gDirectFallbackUsed.load() &&
            elapsed >= selectionFallbackDelay) {
            gDirectFallbackUsed.store(true);
            bool fallbackSelected =
                InvokeSelectInteraction(manager, target);
            if (recoverySelectionPending) {
                HdTrace(@"RECOVERY", fallbackSelected
                    ? @"FAST TOOLTIP RESELECT REQUESTED"
                    : @"FAST TOOLTIP RESELECT UNAVAILABLE");
            }
        }

        if (!querySucceeded &&
            elapsed >= 12.0) {
            char fallbackTaskText[128] = {0};
            if (IsLikelyCustomTaskTarget(
                    tooltip,
                    target,
                    fallbackTaskText,
                    sizeof(fallbackTaskText))) {
                if (gTaskFlowAttempts.load() <
                        kTaskFlowMaxAttempts &&
                    InvokeCustomTaskFlow(
                        tooltip,
                        target,
                        false,
                        false)) {
                    return;
                }
                ResetCycle(
                    OX_NS("ĐANG GỌI LẠI NHIỆM VỤ"),
                    0.8);
                return;
            }

            if (!gCurrencyChecked.load()) {
                CurrencyState currencyState =
                    QueryCurrency(target);
                if (currencyState ==
                    CurrencyState::NotEnough) {
                    if (now >=
                            gNextTaskFlowAttemptAt.load() &&
                        gTaskFlowAttempts.load() <
                            kTaskFlowMaxAttempts) {
                        if (InvokeCustomTaskFlow(
                                tooltip,
                                target,
                                false,
                                true)) {
                            return;
                        }
                    }
                    if (gTaskClassificationRejected.load()) {
                        StopAutoForCurrency();
                        return;
                    }
                    if (gTaskFlowAttempts.load() <
                        kTaskFlowMaxAttempts) {
                        SetStatus(OX_NS("ĐANG KIỂM TRA ACTION NHIỆM VỤ"));
                        gNextStepAt.store(
                            now + 0.35);
                        return;
                    }
                    StopAutoForCurrency();
                    return;
                }
                if (currencyState ==
                    CurrencyState::Error) {
                    StopAutoSafely(OX_NS("KHÔNG ĐỌC ĐƯỢC TÀI NGUYÊN - AUTO ĐÃ DỪNG"));
                    return;
                }
                gCurrencyChecked.store(true);
            }

            CollectInvokeState collectState =
                InvokeCollectAction(tooltip, target);
            if (collectState ==
                CollectInvokeState::NotReady) {
                SetStatus(OX_NS("CHƯA CÓ ACTION DATA THẬT"));
                gNextStepAt.store(now + 0.25);
                return;
            }
            if (collectState ==
                CollectInvokeState::Error) {
                ResetCycle(
                    OX_NS("KHÔNG GỌI ĐƯỢC THU THẬP"),
                    1.5);
                return;
            }
            gPhase.store(
                static_cast<int>(
                    AutoPhase::WaitingResult));
            gPhaseStartedAt.store(now);
            gLastResultPollAt.store(0.0);
            gNextStepAt.store(now + 0.08);
            SetStatus(OX_NS("ĐÃ GỌI THU THẬP - CHỜ KẾT QUẢ"));
            return;
        }

        if (elapsed >= kTooltipTimeout) {
            ResetCycle(
                OX_NS("MỤC TIÊU KHÔNG MỞ - ĐỔI Ô"),
                1.0);
            return;
        }

        if (!querySucceeded) {
            SetStatus(OX_NS("ĐANG CHỜ TOOLTIP MỤC TIÊU"));
        }
        gNextStepAt.store(now + 0.07);
        return;
    }

    if (phase == AutoPhase::WaitingResult) {
        double elapsed = now - gPhaseStartedAt.load();
        if (elapsed < kResultFirstPollDelay) {
            gNextStepAt.store(now + 0.04);
            return;
        }

        if (now - gLastResultPollAt.load() <
            kResultPollInterval) {
            gNextStepAt.store(now + 0.04);
            return;
        }
        gLastResultPollAt.store(now);

        Il2CppString *target =
            gCurrentTarget.load();
        Il2CppString *selectedAfterAction =
            ReadGameSelectedTarget(infoModel);
        char selectedAfterActionText[128] = {0};
        if (CopyManagedString(
                selectedAfterAction,
                selectedAfterActionText,
                sizeof(selectedAfterActionText)) &&
            RememberOrDetectMapChange(selectedAfterActionText)) {
            BeginMapTransitionWait(true);
            return;
        }
        TargetPassedState passedState =
            QueryCurrentTargetPassed(
                infoModel,
                target);
        if (passedState ==
            TargetPassedState::Error) {
            int failures =
                gRuntimeQueryFailures.fetch_add(1) + 1;
            if (failures >= 3) {
                gRuntimeQueryFailures.store(0);
                ClearManager();
                gManagerScanAttempts.store(0);
                RequestManagerScan();
                return;
            }
            SetStatus(OX_NS("LỖI KIỂM TRA KẾT QUẢ - ĐANG THỬ LẠI"));
            gNextStepAt.store(now + 1.0);
            return;
        }
        gRuntimeQueryFailures.store(0);
        if (passedState ==
            TargetPassedState::Passed) {
            char completedTarget[128] = {0};
            {
                std::lock_guard<std::mutex> lock(
                    gTargetTextMutex);
                snprintf(completedTarget,
                         sizeof(completedTarget),
                         OX_C("%s"),
                         gCurrentTargetText);
            }
            QuarantineCompletedTarget(completedTarget, 0.35);
            ResetResultRecoveryState();

            if (gTaskJourneyActive.load()) {
                bool completedRoot = false;
                {
                    std::lock_guard<std::mutex> lock(gTargetTextMutex);
                    completedRoot =
                        gTaskRootTargetText[0] &&
                        strcmp(completedTarget,
                               gTaskRootTargetText) == 0;
                }
                if (completedRoot) {
                    ClearTaskJourneyState();
                    gWaitForNativeContinuation.store(false);
                    ResetCycle(
                        OX_NS("ĐÃ HOÀN THÀNH NHIỆM VỤ - ĐANG BẤM CỜ ĐI TIẾP"),
                        0.20);
                    return;
                }

                bool completedSource = false;
                {
                    std::lock_guard<std::mutex> lock(gTargetTextMutex);
                    completedSource =
                        gTaskSourceTargetText[0] &&
                        strcmp(completedTarget,
                               gTaskSourceTargetText) == 0;
                }
                gWaitForNativeContinuation.store(false);
                BeginTaskRouteSelection(
                    completedSource ? 0.75 : 0.25,
                    completedSource
                        ? OX_NS("ĐÃ LẤY VẬT PHẨM - ĐANG KIỂM TRA ĐỂ VỀ TRẢ NHIỆM VỤ")
                        : OX_NS("ĐÃ DỌN XONG - ĐANG GỌI CỜ ĐI TIẾP"));
                return;
            }

            gWaitForNativeContinuation.store(true);
            ResetCycle(
                OX_NS("ĐÃ THU THẬP - CHỜ Ô TIẾP"),
                kNextTargetDelay);
            return;
        }

        if (elapsed >= kResultTimeout) {
            char timeoutTarget[128] = {0};
            {
                std::lock_guard<std::mutex> lock(
                    gTargetTextMutex);
                snprintf(timeoutTarget,
                         sizeof(timeoutTarget),
                         OX_C("%s"),
                         gCurrentTargetText);
            }
            int recoveryAttempt = RegisterResultTimeout(timeoutTarget);
            HdTrace(@"RECOVERY", [NSString stringWithFormat:
                @"TARGET %s TIMEOUT %d/%d",
                timeoutTarget, recoveryAttempt, kResultMaxRetries]);
            InvokeTooltipClose(tooltip);
            RetireCurrentActionHandle();
            gCurrentActionUsedFresh.store(false);
            gForceFreshActionNext.store(false);
            if (recoveryAttempt >= kResultMaxRetries) {
                HdTrace(@"RECOVERY", @"REPEATED TARGET FAILURE - STOP SAFELY");
                StopAutoSafely(OX_NS("MỤC TIÊU KHÔNG THU ĐƯỢC SAU 3 LẦN - AUTO TẠM DỪNG"));
                return;
            }
            gWaitForNativeContinuation.store(false);
            if (recoveryAttempt == 1) {
                Il2CppString *retryTarget = gCurrentTarget.load();
                bool selectedAgain = retryTarget &&
                    InvokeSelectInteraction(manager, retryTarget);
                HdTrace(@"RECOVERY", selectedAgain
                    ? @"RESELECT SAME TARGET BEFORE RETRY"
                    : @"SAME TARGET RETRY WITHOUT RESELECT");
                gForceRouteRefresh.store(false);
                gRequireSelectionChange.store(false);
                ResetCycle(
                    OX_NS("ĐANG THỬ LẠI THAO TÁC Ô HIỆN TẠI"),
                    0.05);
                return;
            }
            HdTrace(@"RECOVERY", @"SECOND FAILURE - REFRESH NATIVE ROUTE");
            gForceRouteRefresh.store(true);
            gRequireSelectionChange.store(false);
            ResetCycle(
                OX_NS("ĐANG KHÔI PHỤC ĐƯỜNG TƯƠNG TÁC"),
                1.0);
            return;
        }

        SetStatus(OX_NS("ĐANG CHỜ GAME XÁC NHẬN"));
        gNextStepAt.store(now + 0.25);
    }
}

static bool PrepareRuntime(void) {
    bool livenessReady = ResolveLiveness();
    bool methodsReady = ResolveManagedMethods();
    bool ready = livenessReady && methodsReady;
    if (!livenessReady) {
        gPrepareFailureStatus =
            OX_NS("THIẾU API QUÉT MANAGER");
    }
    gRuntimeReady.store(ready);
    return ready;
}

static void PrepareWithRetry(int attempt) {
    if (gRuntimeReady.load()) return;
    if (!gEnabled.load()) {
        gInstallStarted.store(false);
        return;
    }

    if (PrepareRuntime()) {
        if (gEnabled.load()) {
            BeginManagerScanSession(
                kManagerInitialWarmup);
            RequestManagerScan();
        } else {
            SetStatus(OX_NS("VÀO HOANG ĐỊA RỒI BẬT AUTO"));
        }
        return;
    }

    int shownAttempt = (attempt % 60) + 1;
    SetStatus([NSString stringWithFormat:
        OX_NS("%@ - THỬ LẠI %d"),
        gPrepareFailureStatus.length
            ? gPrepareFailureStatus
            : OX_NS("AUTO CHƯA SẴN SÀNG"),
        shownAttempt]);
    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW,
                      static_cast<int64_t>(
                          1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
        PrepareWithRetry(attempt + 1);
    });
}

bool ExpeditionAutoIsEnabled(void) {
    return gEnabled.load();
}

void ExpeditionAutoSetEnabled(bool value) {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            ExpeditionAutoSetEnabled(value);
        });
        return;
    }
    gAutoRunGeneration.fetch_add(1);
    HdTrace(@"AUTO", value ? @"ENABLE REQUEST" : @"DISABLE REQUEST");
    if (value &&
        !R7f431(0xB70A3D95E6248C1FULL)) {
        value = false;
    }
    gEnabled.store(value);

    if (!value) {
        gManagerScanAttempts.store(0);
        gRuntimeQueryFailures.store(0);
        if (!gRuntimeReady.load()) {
            gInstallStarted.store(false);
        }
        gNextManagerScanAllowedAt.store(0.0);
        ClearManager();
        SetStatus(OX_NS("ĐÃ TẮT"));
        return;
    }

    BeginManagerScanSession(
        kManagerInitialWarmup);
    gRuntimeQueryFailures.store(0);
    gWaitForNativeContinuation.store(false);
    ResetTransitionTracking();
    ResetCycle(nil, 0.0);

    if (!gRuntimeReady.load()) {
        SetStatus(OX_NS("ĐANG KHỞI TẠO AUTO S59"));
        if (!gInstallStarted.exchange(true)) {
            dispatch_async(dispatch_get_main_queue(), ^{
                Attach();
                PrepareWithRetry(0);
            });
        }
        return;
    }

    if (!gSelectionManager.load()) {
        RequestManagerScan();
        return;
    }

    ResetCycle(OX_NS("AUTO S59 ĐANG CHẠY"), 0.8);
}

void ExpeditionAutoTick(void) {
    if (!R7f431(0x2F8C61D4A90753BEULL)) {
        if (gEnabled.load()) {
            ExpeditionAutoSetEnabled(false);
        }
        return;
    }
    if (!gEnabled.load() || !gRuntimeReady.load()) return;

    if (!gSelectionManager.load()) {
        if (gManagerScanPendingGeneration.load() == 0 &&
            gManagerScanAttempts.load() <
                kMaxManagerScanAttempts) {
            RequestManagerScan();
        }
        return;
    }

    if (Now() < gNextStepAt.load()) return;

    bool expected = false;
    if (!gStepScheduled.compare_exchange_strong(
            expected,
            true)) {
        return;
    }

    unsigned long long runGeneration = gAutoRunGeneration.load();
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gEnabled.load() &&
            gAutoRunGeneration.load() == runGeneration) {
            @try {
                RunAutoStep();
            }
            @catch (NSException *exception) {
                if (gAutoRunGeneration.load() == runGeneration) {
                    ResetCycle(OX_NS("LỖI AUTO - ĐANG THỬ Ô KHÁC"), 1.5);
                }
            }
        }
        gStepScheduled.store(false);
    });
}

}

namespace Ongnong {

void InstallExpeditionAutoHooks(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        SetStatus(OX_NS("VÀO HOANG ĐỊA RỒI BẬT AUTO"));
        gInstallStarted.store(false);
    });
}

}
