#import "Qr65a.h"
#import "Qr65c.h"
#import "OngnongState.h"
#import "zx8f1a_gate.h"
#import "zx8f1a_pro.h"
#import "OngnongOxorany.h"
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

namespace {
static BOOL z63a = NO;
static dispatch_queue_t z63b = nil;
}


static NSString *z63ip(void) {
    static const uint8_t b[] = {0x06,0x77,0x7a,0x76,0x52,0x5e,0x57,0xb6,0xbf,0xab,0x8b,0x81,0x8e,0xf5};
    char tmp[sizeof(b) + 1];
    for (size_t i = 0; i < sizeof(b); i++) tmp[i] = (char)(b[i] ^ (uint8_t)(0x37 + (uint8_t)(i * 11)));
    tmp[sizeof(b)] = 0;
    return [NSString stringWithUTF8String:tmp] ?: @"";
}

static NSDictionary *z63ats(void) {
    static NSDictionary *ats = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSDictionary *ip = @{
            OX_NS("NSExceptionAllowsInsecureHTTPLoads"): @YES,
            OX_NS("NSIncludesSubdomains"): @YES,
            OX_NS("NSExceptionRequiresForwardSecrecy"): @NO,
            OX_NS("NSExceptionMinimumTLSVersion"): OX_NS("TLSv1.0")
        };
        ats = @{
            OX_NS("NSAllowsArbitraryLoads"): @YES,
            OX_NS("NSAllowsArbitraryLoadsInWebContent"): @YES,
            OX_NS("NSAllowsArbitraryLoadsForMedia"): @YES,
            OX_NS("NSExceptionDomains"): @{ z63ip(): ip }
        };
    });
    return ats;
}

static NSDictionary *z63atsMerge(NSDictionary *src) {
    NSMutableDictionary *m = src ? [src mutableCopy] : [NSMutableDictionary dictionary];
    NSDictionary *old = [m objectForKey:OX_NS("NSAppTransportSecurity")];
    NSMutableDictionary *ats = [z63ats() mutableCopy];
    if ([old isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *merged = [old mutableCopy];
        [merged addEntriesFromDictionary:ats];
        NSDictionary *oldDomains = [old objectForKey:OX_NS("NSExceptionDomains")];
        NSMutableDictionary *domains = [[ats objectForKey:OX_NS("NSExceptionDomains")] mutableCopy];
        if ([oldDomains isKindOfClass:[NSDictionary class]]) {
            [domains addEntriesFromDictionary:oldDomains];
            [domains setObject:[[z63ats() objectForKey:OX_NS("NSExceptionDomains")] objectForKey:z63ip()] forKey:z63ip()];
        }
        [merged setObject:domains forKey:OX_NS("NSExceptionDomains")];
        ats = merged;
    }
    [m setObject:ats forKey:OX_NS("NSAppTransportSecurity")];
    return m;
}

static void z63atsMutateMainBundle(void) {
    @try {
        NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
        if ([info isKindOfClass:[NSMutableDictionary class]]) {
            [(NSMutableDictionary *)info setObject:z63ats() forKey:OX_NS("NSAppTransportSecurity")];
        }
    } @catch (__unused NSException *e) {}
}

static void z63swz(Class cls, SEL a, SEL b, BOOL meta) {
    Class target = meta ? object_getClass(cls) : cls;
    Method m1 = meta ? class_getClassMethod(cls, a) : class_getInstanceMethod(cls, a);
    Method m2 = meta ? class_getClassMethod(cls, b) : class_getInstanceMethod(cls, b);
    if (!target || !m1 || !m2) return;
    method_exchangeImplementations(m1, m2);
}

@interface NSBundle (Zp63A)
- (NSDictionary *)z63_infoDictionary;
- (NSDictionary *)z63_localizedInfoDictionary;
- (id)z63_objectForInfoDictionaryKey:(NSString *)key;
@end

@implementation NSBundle (Zp63A)
- (NSDictionary *)z63_infoDictionary {
    NSDictionary *orig = [self z63_infoDictionary];
    if (self == [NSBundle mainBundle]) return z63atsMerge(orig);
    return orig;
}
- (NSDictionary *)z63_localizedInfoDictionary {
    NSDictionary *orig = [self z63_localizedInfoDictionary];
    if (self == [NSBundle mainBundle]) return z63atsMerge(orig);
    return orig;
}
- (id)z63_objectForInfoDictionaryKey:(NSString *)key {
    if ([key isEqualToString:OX_NS("NSAppTransportSecurity")] && self == [NSBundle mainBundle]) return z63ats();
    return [self z63_objectForInfoDictionaryKey:key];
}
@end

static void z63atsInstall(void) {
    static BOOL done = NO;
    if (done) return;
    done = YES;
    z63atsMutateMainBundle();
    Class b = [NSBundle class];
    z63swz(b, @selector(infoDictionary), @selector(z63_infoDictionary), NO);
    z63swz(b, @selector(localizedInfoDictionary), @selector(z63_localizedInfoDictionary), NO);
    z63swz(b, @selector(objectForInfoDictionaryKey:), @selector(z63_objectForInfoDictionaryKey:), NO);
    z63atsMutateMainBundle();
}

@interface Zp63R : NSURLProtocol <NSURLSessionDataDelegate>
@property(nonatomic, strong) NSURLSession *session;
@property(nonatomic, strong) NSURLSessionDataTask *task;
@property(nonatomic, strong) NSMutableData *body;
@property(nonatomic) BOOL bodyTooLarge;
@property(nonatomic) uint64_t spinSnapshot;
@end

@implementation Zp63R
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    if (!Ongnong::Zx8fPotionOrTokenAllowed() && !Ongnong::Zx8fLightningAllowed()) return NO;
    if ([NSURLProtocol propertyForKey:zxv_p39() inRequest:request]) return NO;
    return q65a0(request.URL.absoluteString ?: @"");
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }
- (void)startLoading {
    NSMutableURLRequest *req = [self.request mutableCopy];
    [NSURLProtocol setProperty:@YES forKey:zxv_p39() inRequest:req];
    self.bodyTooLarge = NO;
    self.spinSnapshot = Ongnong::Z9c4a7f611b();
    self.body = [NSMutableData data];
    NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration ephemeralSessionConfiguration];
    cfg.URLCache = nil;
    self.session = [NSURLSession sessionWithConfiguration:cfg delegate:self delegateQueue:nil];
    self.task = [self.session dataTaskWithRequest:req];
    [self.task resume];
}
- (void)stopLoading {
    [self.task cancel];
    self.task = nil;
    self.body = nil;
    self.bodyTooLarge = NO;
    [self.session invalidateAndCancel];
    self.session = nil;
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition disposition))completionHandler {
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
    if (completionHandler) completionHandler(NSURLSessionResponseAllow);
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    static const NSUInteger z63g = 12 * 1024 * 1024;
    if (!self.bodyTooLarge && self.body) {
        if (self.body.length + data.length <= z63g) {
            [self.body appendData:data];
        } else {
            self.bodyTooLarge = YES;
            self.body = nil;
        }
    }
    [self.client URLProtocol:self didLoadData:data];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
    NSData *d = nil;
    if (!self.bodyTooLarge && self.body.length > 0) d = self.body;
    self.body = nil;
    self.bodyTooLarge = NO;
    self.task = nil;
    [self.session finishTasksAndInvalidate];
    self.session = nil;
    if (error) {
        [self.client URLProtocol:self didFailWithError:error];
    } else {
        NSString *u = self.request.URL.absoluteString ?: @"";
        uint64_t snap = self.spinSnapshot;
        if (d.length > 0) {
            dispatch_async(z63b ?: dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                q65c9(d, u, snap);
            });
        }
        [self.client URLProtocolDidFinishLoading:self];
    }
}
@end

static NSArray *z63c(NSArray *classes) {
    NSMutableArray *arr = [NSMutableArray arrayWithObject:[Zp63R class]];
    for (Class c in classes) if (c != [Zp63R class]) [arr addObject:c];
    return arr;
}

static void z63d(Class cls, SEL a, SEL b) {
    Method m1 = class_getInstanceMethod(cls, a);
    Method m2 = class_getInstanceMethod(cls, b);
    if (m1 && m2) method_exchangeImplementations(m1, m2);
}

@interface NSURLSessionConfiguration (Zp63)
- (NSArray *)zq83_protocolClasses;
+ (NSURLSessionConfiguration *)zq83_defaultSessionConfiguration;
+ (NSURLSessionConfiguration *)zq83_ephemeralSessionConfiguration;
@end

@implementation NSURLSessionConfiguration (Zp63)
- (NSArray *)zq83_protocolClasses {
    NSArray *orig = [self zq83_protocolClasses];
    return z63c(orig ?: @[]);
}
+ (NSURLSessionConfiguration *)zq83_defaultSessionConfiguration {
    NSURLSessionConfiguration *cfg = [self zq83_defaultSessionConfiguration];
    cfg.protocolClasses = z63c(cfg.protocolClasses ?: @[]);
    return cfg;
}
+ (NSURLSessionConfiguration *)zq83_ephemeralSessionConfiguration {
    NSURLSessionConfiguration *cfg = [self zq83_ephemeralSessionConfiguration];
    cfg.protocolClasses = z63c(cfg.protocolClasses ?: @[]);
    return cfg;
}
@end

static void z63e(void) {
    z63atsInstall();
    if (z63a) return;
    z63a = YES;
    z63b = dispatch_queue_create([zxv_p43() UTF8String], DISPATCH_QUEUE_SERIAL);
    [NSURLProtocol registerClass:[Zp63R class]];
    Class cfgCls = [NSURLSessionConfiguration class];
    z63d(cfgCls, @selector(protocolClasses), @selector(zq83_protocolClasses));
    Method d1 = class_getClassMethod(cfgCls, @selector(defaultSessionConfiguration));
    Method d2 = class_getClassMethod(cfgCls, @selector(zq83_defaultSessionConfiguration));
    if (d1 && d2) method_exchangeImplementations(d1, d2);
    Method e1 = class_getClassMethod(cfgCls, @selector(ephemeralSessionConfiguration));
    Method e2 = class_getClassMethod(cfgCls, @selector(zq83_ephemeralSessionConfiguration));
    if (e1 && e2) method_exchangeImplementations(e1, e2);
}

__attribute__((constructor))
static void z63f(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        z63e();
    });
}
