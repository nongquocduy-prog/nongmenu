#import "Qr71a.h"
#import <Foundation/Foundation.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

@implementation Q71N
@end

__attribute__((noinline)) static NSString *q71d(const uint8_t *v, NSUInteger n, uint8_t seed) {
    if (!v || n == 0) return [NSString string];
    uint8_t stack[128];
    uint8_t *out = n <= sizeof(stack) ? stack : (uint8_t *)malloc(n);
    if (!out) return [NSString string];
    for (NSUInteger i = 0; i < n; i++) out[i] = (uint8_t)(v[i] ^ (uint8_t)(seed + (uint8_t)(i * 29)) ^ (uint8_t)(((i * 7) ^ 0xA5) & 0xFF));
    NSString *s = [[NSString alloc] initWithBytes:out length:n encoding:NSUTF8StringEncoding] ?: [NSString string];
    memset(out, 0, n);
    if (out != stack) free(out);
    return s;
}

static NSString *q71k0(void) {
    static const uint8_t v[] = {0xF5,0x8F,0xA3,0x4D,0x71,0x31,0x3C,0x09,0xF0,0xC5,0xDF,0xF6,0x3E,0x35,0x72,0x5B,0x96,0xB5,0xA9,0x1C};
    return q71d(v, sizeof(v), 0x31);
}
static NSString *q71k1(void) {
    static const uint8_t v[] = {0x90,0xA8,0x49,0x7C,0x0D,0x0C,0xEC,0xD6,0xC4,0xB8,0xE5,0x0B,0x3A,0x5B,0x4C,0xB0,0xA8,0x80,0xE2,0x2B,0xD8,0xE0,0xB0,0x8C,0x69,0x48,0x25,0x1E,0x66};
    return q71d(v, sizeof(v), 0x52);
}
static NSString *q71k2(void) {
    static const uint8_t v[] = {0xA6,0x53,0x74,0x1F,0x30,0xF6,0xEB,0xDC,0xA3,0x8C,0x02,0x13,0x5A};
    return q71d(v, sizeof(v), 0x73);
}
static NSString *q71k3(void) {
    static const uint8_t v[] = {0xE7,0xE9,0x82,0xBA,0x49,0x5A,0x34,0x39,0xF9,0xD3,0xD5,0xE6,0xF8};
    return q71d(v, sizeof(v), 0x21);
}
static NSString *q71k4(void) {
    static const uint8_t v[] = {0x81,0xB3,0x58,0x5C,0x67,0x30,0x0E};
    return q71d(v, sizeof(v), 0x47);
}
static NSString *q71k5(void) {
    static const uint8_t v[] = {0xAE,0x52,0x7B,0x7D,0x00,0x11,0xED,0xF1,0xAC,0x9B,0x1C,0x2A};
    return q71d(v, sizeof(v), 0x68);
}
static NSString *q71k6(void) {
    static const uint8_t v[] = {0x4E,0x68,0x00,0x24,0x29,0xE9};
    return q71d(v, sizeof(v), 0x8A);
}
static NSString *q71k7(void) {
    static const uint8_t v[] = {0xC8,0xFB,0x8C,0xA1,0x58,0x6D,0x25,0x1F,0xE9,0xEA,0xAC};
    return q71d(v, sizeof(v), 0x19);
}
static NSString *q71k8(void) {
    static const uint8_t v[] = {0xED,0x9A,0xAF,0x44,0x6C,0x3F};
    return q71d(v, sizeof(v), 0x3C);
}
static NSString *q71k9(void) {
    static const uint8_t v[] = {0x8F,0xB8,0x41,0x62,0x0E,0x1D,0xC2,0xD0,0xB4,0x8C,0x0D,0x01};
    return q71d(v, sizeof(v), 0x5E);
}
static NSString *q71ka(void) {
    static const uint8_t v[] = {0xB7,0x5F,0x6A,0x27,0x27,0xF9,0xD7,0xB0,0x8E};
    return q71d(v, sizeof(v), 0x7F);
}
static NSString *q71kb(void) {
    static const uint8_t v[] = {0xE9,0x9A,0xAB,0x6D,0x45,0x52,0x3F,0x0E,0xEA,0xF5,0xC3,0xE7,0x04,0x3D,0x63,0x4D};
    return q71d(v, sizeof(v), 0x2B);
}
static NSString *q71kc(void) {
    static const uint8_t v[] = {0x8F,0xB8,0x49,0x4B,0x1B,0x30,0x1D,0xE0,0xCC,0x97,0xE1,0x01,0x2A,0x5F,0x41,0xE2};
    return q71d(v, sizeof(v), 0x4D);
}
static NSString *q71kd(void) {
    static const uint8_t v[] = {0xA7,0x4B,0x70,0x11,0x3F,0xD9};
    return q71d(v, sizeof(v), 0x6F);
}
static NSString *q71ke(void) {
    static const uint8_t v[] = {0x46,0x69,0x17,0x39,0xCE,0xC0,0xC3};
    return q71d(v, sizeof(v), 0x91);
}
static NSString *q71kf(void) {
    static const uint8_t v[] = {0x32};
    return q71d(v, sizeof(v), 0xB3);
}

static NSString *q71s(id value) {
    if (!value || value == [NSNull null]) return [NSString string];
    NSString *s = [value isKindOfClass:[NSString class]] ? value : [value description];
    return s ?: [NSString string];
}

static NSString *q71l(id value) {
    return q71s(value).lowercaseString ?: [NSString string];
}

static id q71v(NSDictionary *d, NSString *key) {
    if (![d isKindOfClass:[NSDictionary class]] || key.length == 0) return nil;
    id direct = d[key];
    if (direct) return direct;
    NSString *needle = key.lowercaseString;
    for (id raw in d) if ([q71l(raw) isEqualToString:needle]) return d[raw];
    return nil;
}

static NSInteger q71i(id value, NSInteger fallback) {
    if ([value isKindOfClass:[NSNumber class]]) return [value integerValue];
    if ([value isKindOfClass:[NSString class]] && [value length] > 0) return [value integerValue];
    return fallback;
}

static NSInteger q71n(NSDictionary *d, NSArray<NSString *> *keys, NSInteger fallback) {
    for (NSString *key in keys) {
        NSInteger value = q71i(q71v(d, key), NSIntegerMin);
        if (value != NSIntegerMin) return value;
    }
    return fallback;
}

static BOOL q71b(NSString *key) {
    NSString *s = q71l(key);
    s = [s stringByReplacingOccurrencesOfString:@"_" withString:[NSString string]];
    s = [s stringByReplacingOccurrencesOfString:@"-" withString:[NSString string]];
    NSString *needle = q71k0().lowercaseString;
    needle = [needle stringByReplacingOccurrencesOfString:@"_" withString:[NSString string]];
    needle = [needle stringByReplacingOccurrencesOfString:@"-" withString:[NSString string]];
    return [s isEqualToString:needle];
}

static BOOL q71p(NSString *path) {
    NSString *s = q71l(path);
    return [s containsString:q71kb().lowercaseString] || [s containsString:q71kc().lowercaseString];
}

static BOOL q71m(NSString *parent) {
    return [q71l(parent) hasPrefix:q71kd().lowercaseString];
}

static void q71x(id value, NSString *path, NSMutableArray<Q71N *> *out, NSMutableSet<NSString *> *seen, int depth, NSUInteger *nodes) {
    if (!value || value == [NSNull null] || depth > 28 || out.count >= 64 || !nodes || *nodes > 30000) return;
    (*nodes)++;
    if ([value isKindOfClass:[NSDictionary class]]) {
        NSDictionary *d = value;
        for (id rawKey in d) {
            NSString *key = q71s(rawKey);
            NSString *next = path.length ? [path stringByAppendingFormat:@".%@", key ?: @"?"] : (key ?: @"?");
            id child = d[rawKey];
            if (q71b(key) && [child isKindOfClass:[NSDictionary class]] && q71p(next)) {
                NSDictionary *bars = child;
                for (id rawId in bars) {
                    id rawBar = bars[rawId];
                    if (![rawBar isKindOfClass:[NSDictionary class]]) continue;
                    NSDictionary *bar = rawBar;
                    NSDictionary *rewards = q71v(bar, q71ke());
                    if (![rewards isKindOfClass:[NSDictionary class]]) continue;
                    if (q71i(q71v(rewards, q71k1()), 0) <= 0) continue;
                    NSString *parent = q71s(q71v(bar, q71k2()));
                    if (!q71m(parent)) continue;
                    NSInteger current = q71n(bar, @[q71k3(), q71k4(), q71k5(), q71k6()], -1);
                    NSInteger target = q71n(bar, @[q71k7(), q71k8(), q71k9(), q71ka()], -1);
                    if (current < 0 || target <= 0) continue;
                    NSString *barId = q71s(rawId);
                    NSString *identity = [NSString stringWithFormat:@"%@|%@", parent ?: [NSString string], barId ?: [NSString string]];
                    if ([seen containsObject:identity]) continue;
                    [seen addObject:identity];
                    Q71N *item = [Q71N new];
                    item.x0 = identity;
                    item.x1 = current;
                    [out addObject:item];
                    if (out.count >= 64) break;
                }
            }
            q71x(child, next, out, seen, depth + 1, nodes);
            if (*nodes > 30000 || out.count >= 64) break;
        }
    } else if ([value isKindOfClass:[NSArray class]]) {
        NSArray *a = value;
        NSUInteger limit = MIN((NSUInteger)512, a.count);
        for (NSUInteger i = 0; i < limit; i++) {
            q71x(a[i], [path stringByAppendingFormat:@"[%lu]", (unsigned long)i], out, seen, depth + 1, nodes);
            if (*nodes > 30000 || out.count >= 64) break;
        }
    }
}

static BOOL q71r(NSData *data, NSString *needle) {
    NSData *n = [needle dataUsingEncoding:NSUTF8StringEncoding];
    if (!data || !n || n.length == 0 || n.length > data.length) return NO;
    return [data rangeOfData:n options:0 range:NSMakeRange(0, data.length)].location != NSNotFound;
}

BOOL q71a0(NSData *data) {
    if (!data || data.length == 0) return NO;
    
    
    if (q71r(data, q71k0())) return YES;
    NSString *child = q71kb();
    if (child.length > 0) child = [child substringToIndex:child.length - 1];
    return q71r(data, q71k1()) && q71r(data, child) && q71r(data, q71k2());
}

NSArray<Q71N *> *q71a1(id json) {
    if (!json) return @[];
    NSMutableArray<Q71N *> *out = [NSMutableArray array];
    NSMutableSet<NSString *> *seen = [NSMutableSet set];
    NSUInteger nodes = 0;
    q71x(json, q71kf(), out, seen, 0, &nodes);
    return out;
}
