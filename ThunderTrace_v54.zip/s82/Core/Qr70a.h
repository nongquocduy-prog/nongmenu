#pragma once
#import <Foundation/Foundation.h>
#include <stdint.h>
BOOL q70a0(NSData *data);
void q70a1(NSData *data, NSString *url, uint64_t snap);
