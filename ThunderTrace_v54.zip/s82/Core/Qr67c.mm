#import "Qr67c.h"
#import "Qr67b.h"
#import "Qr65a.h"
#import "Qr65b.h"
#import "OngnongState.h"
#import "zx8f1a_gate.h"
#import <Foundation/Foundation.h>

static NSString *q67c0(NSString *a) {
    NSString *z = ([a isKindOfClass:[NSString class]] && a.length) ? a : q65a1(nil);
    return [q67k41() stringByAppendingString:z ?: @""];
}

static NSMutableDictionary *q67c1(NSString *a) {
    id v = [[NSUserDefaults standardUserDefaults] objectForKey:q67c0(a)];
    return [v isKindOfClass:[NSDictionary class]] ? [(NSDictionary *)v mutableCopy] : [NSMutableDictionary dictionary];
}

static void q67c2(NSString *a, NSMutableDictionary *s) {
    if (![s isKindOfClass:[NSMutableDictionary class]]) return;
    [[NSUserDefaults standardUserDefaults] setObject:s forKey:q67c0(a)];
}

static NSMutableDictionary *q67c3(NSMutableDictionary *s) {
    id v = s[q67k33()];
    if ([v isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *m = [(NSDictionary *)v mutableCopy];
        s[q67k33()] = m;
        return m;
    }
    NSMutableDictionary *m = [NSMutableDictionary dictionary];
    s[q67k33()] = m;
    return m;
}

static NSDictionary *q67c4(NSMutableDictionary *b, NSString *i) {
    if (![b isKindOfClass:[NSDictionary class]] || ![i isKindOfClass:[NSString class]] || i.length == 0) return nil;
    id v = b[i];
    return [v isKindOfClass:[NSDictionary class]] ? (NSDictionary *)v : nil;
}

static NSDictionary *q67ca(NSMutableDictionary *st, NSString *i) {
    if (![st isKindOfClass:[NSDictionary class]] || ![i isKindOfClass:[NSString class]] || i.length == 0) return nil;
    NSString *lk = [st[q67k35()] isKindOfClass:[NSString class]] ? st[q67k35()] : @"";
    if (![lk isEqualToString:i]) return nil;
    NSString *v = [st[q67k36()] isKindOfClass:[NSString class]] ? st[q67k36()] : @"";
    if (v.length == 0) return nil;
    NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"(\\d+)" options:0 error:nil];
    NSArray *ms = [re matchesInString:v options:0 range:NSMakeRange(0, v.length)];
    if (ms.count < 2) return nil;
    NSInteger a = [[v substringWithRange:[ms[0] rangeAtIndex:1]] integerValue];
    NSInteger b = [[v substringWithRange:[ms[1] rangeAtIndex:1]] integerValue];
    if (a < 0 || b <= 0) return nil;
    return @{q67k12():@(a), q67k19():@(b)};
}

static NSInteger q67c5(Q67A0 *r, NSDictionary *o) {
    if (![r isKindOfClass:[Q67A0 class]] || ![o isKindOfClass:[NSDictionary class]]) return 0;
    NSInteger c = q65b6(o[q67k12()], -1);
    NSInteger t = q65b6(o[q67k19()], -1);
    if (c < 0 || t <= 0 || r.x2 <= 0) return 0;
    if (r.x1 > c) return r.x1 - c;
    NSInteger left = MAX((NSInteger)0, t - c);
    NSInteger diff = (r.x2 > t) ? (r.x2 - t) : (t - r.x2);
    NSInteger near = MAX((NSInteger)12, t / 5);
    NSInteger low = MAX((NSInteger)20, (r.x2 * 65) / 100);
    BOOL z0 = (c * 100 >= t * 55) || (left <= near);
    BOOL z1 = (r.x1 >= 0 && r.x1 <= low);
    BOOL z2 = (r.x2 == t || diff <= MAX((NSInteger)20, t / 2));
    if ((r.x1 < c || r.x2 != t) && z0 && z1 && z2) return left + r.x1 + 1;
    return 0;
}

static Q67A0 *q67c6(NSArray<Q67A0 *> *a, NSString *i) {
    if (![i isKindOfClass:[NSString class]] || i.length == 0) return nil;
    for (Q67A0 *r in a) if ([r.x0 isEqualToString:i]) return r;
    return nil;
}

static BOOL q67c8(NSString *a, NSString *b) {
    static NSMutableSet *z = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ z = [NSMutableSet set]; });
    NSString *k = [NSString stringWithFormat:q67k38(), a ?: @"", b ?: @""];
    if ([z containsObject:k]) return NO;
    if (z.count > 256) [z removeAllObjects];
    [z addObject:k];
    return YES;
}

static void q67c7(NSMutableDictionary *b, Q67A0 *r) {
    if (![b isKindOfClass:[NSMutableDictionary class]] || ![r isKindOfClass:[Q67A0 class]] || r.x0.length == 0) return;
    b[r.x0] = @{q67k12():@(r.x1), q67k19():@(r.x2), q67k34():@([NSDate timeIntervalSinceReferenceDate])};
}

static NSString *q67hit(void) { static NSString *s = nil; if (!s) s = @"t_last_hit_snap"; return s; }

NSInteger q67c9(id j, NSString *u, uint64_t snap) {
    if (!Ongnong::Zx8fTokenAllowed()) return 0;
    NSMutableArray<Q67A0 *> *m = [NSMutableArray array];
    NSMutableArray<Q67A0 *> *s = [NSMutableArray array];
    q67b9(j, m, s, q67k37(), 0);
    NSString *acc = q65a1(u);
    NSMutableDictionary *st = q67c1(acc);
    NSMutableDictionary *bs = q67c3(st);
    NSString *lk = [st[q67k35()] isKindOfClass:[NSString class]] ? st[q67k35()] : @"";
    Q67A0 *w = nil;
    if (lk.length) w = q67c6(m, lk);
    if (!w) {
        NSMutableArray *d = [NSMutableArray array];
        for (Q67A0 *r in m) if (q67c5(r, q67c4(bs, r.x0)) > 0) [d addObject:r];
        if (d.count == 1) w = d.firstObject;
    }
    if (!w && m.count == 1) w = m.firstObject;
    if (!w && m.count > 1) {
        NSMutableArray *h = [NSMutableArray array];
        for (Q67A0 *r in m) if (q67c4(bs, r.x0)) [h addObject:r];
        if (h.count == 1) w = h.firstObject;
    }
    if (!w && m.count > 1) {
        NSMutableArray *a = [NSMutableArray array];
        for (Q67A0 *r in m) if (r.x3) [a addObject:r];
        if (a.count == 1) w = a.firstObject;
    }
    if (w) {
        NSDictionary *o = q67c4(bs, w.x0);
        if (!o) o = q67ca(st, w.x0);
        NSInteger d = q67c5(w, o);
        st[q67k35()] = w.x0 ?: @"";
        st[q67k36()] = [NSString stringWithFormat:q67k40(), (long)w.x1, (long)w.x2];
        BOOL f = q67c8(acc, w.x0);
        BOOL cold = f && !o && bs.count == 0;
        if (o && d > 0 && !cold) {
            st[q67hit()] = @(snap);
            (void)0;
            Ongnong::Zed58c1f2a6s(snap);
            for (Q67A0 *r in m) q67c7(bs, r);
            for (Q67A0 *r in s) q67c7(bs, r);
            q67c2(acc, st);
            return 3;
        }
    }
    for (Q67A0 *r in m) q67c7(bs, r);
    for (Q67A0 *r in s) q67c7(bs, r);
    q67c2(acc, st);
    return m.count ? 1 : 0;
}

BOOL q67d0(NSString *u, uint64_t snap, NSInteger countAtParse) {
    if (!Ongnong::Zx8fTokenAllowed() || snap == 0 || countAtParse <= 0) return NO;
    NSString *acc = q65a1(u);
    NSMutableDictionary *st = q67c1(acc);
    uint64_t nowSpin = Ongnong::Z9c4a7f611b();
    NSInteger countNow = Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z87f6d0c11d];
    uint64_t lastHit = (uint64_t)q65b6(st[q67hit()], 0);
    BOOL allow = nowSpin > snap && countNow > countAtParse && lastHit != snap;
    (void)0;
    if (!allow) return NO;
    st[q67hit()] = @(snap);
    q67c2(acc, st);
    (void)0;
    Ongnong::Zed58c1f2a6s(snap);
    return YES;
}

BOOL q67d1(NSString *u, uint64_t snap) {
    if (snap == 0) return NO;
    NSString *acc = q65a1(u);
    NSMutableDictionary *st = q67c1(acc);
    return (uint64_t)q65b6(st[q67hit()], 0) == snap;
}
