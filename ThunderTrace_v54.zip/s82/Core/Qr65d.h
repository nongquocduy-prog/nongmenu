#pragma once
#import <Foundation/Foundation.h>
#include <stdint.h>
#import "Qr65b.h"
void q65d4(NSString *a, Q65B0 *b, uint64_t snap);
