#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
const char *q6a(uint32_t x);
uint32_t q6m(uint32_t v);
bool q6j(uint32_t a, uint32_t b);
#ifdef __cplusplus
}
#endif
