#pragma once
#import <Foundation/Foundation.h>

namespace Ongnong {
BOOL R7f401(void);
NSString *R7f402(void);
NSString *R7f403(BOOL enabled);
NSString *R7f404(void);
double R7f405(void);
bool R7f406(const void *value);
}
