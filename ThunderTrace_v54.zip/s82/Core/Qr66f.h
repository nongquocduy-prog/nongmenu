#pragma once
#import <Foundation/Foundation.h>
NSInteger q66f1(NSInteger a, NSInteger b, NSInteger c, NSInteger d);
BOOL q66f2(NSInteger a, NSInteger b);
BOOL q66f3(NSInteger a, NSInteger b, NSInteger c);
