#pragma once
#import <Foundation/Foundation.h>
#include <stdint.h>
@class Q71N;
BOOL q71b0(NSArray<Q71N *> *items, NSString *account, uint64_t snap);
BOOL q71b1(NSString *account, uint64_t snap, NSInteger countAtParse);
BOOL q71b2(NSString *account, uint64_t snap);
