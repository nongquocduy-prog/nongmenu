extern "C" __attribute__((visibility("hidden"), noinline))
void log_internal_impl(int,
                       const char *,
                       int,
                       const char *,
                       const char *,
                       ...) {
}

extern "C" __attribute__((visibility("hidden"), noinline))
void log_set_level(int) {
}

extern "C" __attribute__((visibility("hidden"), noinline))
void log_switch_to_file(const char *) {
}

extern "C" __attribute__((visibility("hidden"), noinline))
void log_switch_to_syslog(void) {
}
