#pragma once
#include <stdbool.h>

@class NSString;
namespace Ongnong {
NSString *AutoMergeOrderDebugCopy(void);
void AutoMergeModuleInstall(void);
void AutoMergeModuleSetEnabled(bool enabled);
void AutoMergeModuleToggle(void);
bool AutoMergeModuleIsEnabled(void);
void AutoMergeModuleTick(void);
}
