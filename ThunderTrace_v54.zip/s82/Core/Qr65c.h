#pragma once
#import <Foundation/Foundation.h>
#include <stdint.h>
void q65c9(NSData *d, NSString *u, uint64_t snap);
