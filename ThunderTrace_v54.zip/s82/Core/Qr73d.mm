#import "Qr73d.h"
#import "OngnongOxorany.h"

namespace Ongnong {

static NSString *K4p7x(const unsigned char *bytes, NSUInteger count, unsigned char key) {
    if (!bytes || count == 0) return @"";
    NSMutableData *data = [NSMutableData dataWithLength:count];
    unsigned char *out = (unsigned char *)data.mutableBytes;
    for (NSUInteger i = 0; i < count; i++) out[i] = bytes[i] ^ (unsigned char)(key + (i * 13u));
    NSString *value = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    memset(out, 0, count);
    return value ?: @"";
}

NSString *K4p7a(NSString *suffix) {
    static NSString *prefix = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        static const unsigned char v[] = {0x32,0x04,0x10,0xea,0xfe,0xf0,0xcc,0xe7,0xa7,0xb7,0xab,0xb3,0x9a,0x7f,0x70,0x4c,0x48,0x65};
        prefix = K4p7x(v, sizeof(v), 0x5d);
    });
    return [prefix stringByAppendingString:suffix ?: @""];
}

NSString *K4p7b(void) {
    static NSString *name = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        static const unsigned char v[] = {0x18,0xea,0xf6,0xf0,0xc4,0xd6,0xa2,0x8d,0xbd,0x89,0x8d,0x59,0x70,0x59,0x4e,0x56,0x22,0x0b,0x02,0x06,0x1a,0xe6,0xf2,0xc7,0xcb};
        name = K4p7x(v, sizeof(v), 0x77);
    });
    return name;
}

NSArray<NSDictionary *> *K4p7c(void) {
    return @[
        @{OX_NS("bet"):@1, OX_NS("spins"):@100},
        @{OX_NS("bet"):@15, OX_NS("spins"):@20},
        @{OX_NS("bet"):@6000, OX_NS("spins"):@10}
    ];
}

NSDictionary *K4p7d(id obj) {
    if (![obj isKindOfClass:[NSDictionary class]]) return nil;
    NSInteger bet = [obj[OX_NS("bet")] integerValue];
    NSInteger spins = [obj[OX_NS("spins")] integerValue];
    if (bet <= 0 || spins <= 0) return nil;
    if (bet > 1000000000LL) bet = 1000000000LL;
    if (spins > 1000000) spins = 1000000;
    return @{OX_NS("bet"):@(bet), OX_NS("spins"):@(spins)};
}

NSInteger K4p7e(NSArray<NSDictionary *> *rows) {
    NSInteger total = 0;
    for (NSDictionary *row in rows) {
        NSInteger spins = [row[OX_NS("spins")] integerValue];
        if (spins > NSIntegerMax - total) return NSIntegerMax;
        total += spins;
    }
    return total;
}

}
