#pragma once
#import <Foundation/Foundation.h>
BOOL q65a0(NSString *v);
NSString *q65a1(NSString *v);
