#pragma once
#include <stdint.h>
#define R7F8_A UINT64_C(0xb5a9cfbabfdccc44)
#define R7F8_B UINT64_C(0x9a246b174b8f2660)
#define R7F8_C UINT64_C(0xed5008a7a3738009)
#define R7F8_D UINT64_C(0x29232e7aedcae436)
#define R7F8_E UINT64_C(0x76d1188ccf730d20)
