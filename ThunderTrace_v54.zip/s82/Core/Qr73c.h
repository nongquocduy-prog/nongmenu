#pragma once

#import <Foundation/Foundation.h>
#include <stdint.h>

namespace Ongnong {

NSString *R3n1(void);
NSArray<NSDictionary *> *R3n2(void);
NSInteger R3n3(void);
NSInteger R3n4(void);
NSInteger R3n5(void);
NSInteger R3n6(void);
NSInteger R3n7(void);
BOOL R3n8(void);
BOOL R3n9(void);
NSString *R3na(void);

BOOL R3nb(NSArray<NSDictionary *> *rows, NSInteger target, NSInteger maxTotal, NSString **errorText);
BOOL R3nc(BOOL running, NSString **errorText);
void R3nd(BOOL collapsed);
void R3ne(void);
void R3nf(int symbol1, int symbol2, int symbol3, uint64_t spinSequence);
void R3ng(int targetIndex, uint64_t requestSnapshot);
void R3nh(void);
void R3ni(BOOL moduleAllowed);

}
