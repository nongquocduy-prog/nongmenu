#import "zx8f1a_gate.h"
#import "zx8f1a_strings.h"
#import "zx8f1a_pro.h"
#import "OngnongOxorany.h"
#import "R7f7.h"
#import "R7f8.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonHMAC.h>
#import <Security/Security.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <dlfcn.h>
#import <math.h>
#include <atomic>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netdb.h>
#include <unistd.h>

#ifndef ONGNONG_BUILD_CHANNEL
#define ONGNONG_BUILD_CHANNEL "ongnong_vip_dark0"
#endif


namespace Ongnong {

static BOOL g_zx8fAllowed = NO;
static BOOL g_zx8fMenuLocked = NO;
static BOOL g_zx8fRuntimeReady = NO;
static BOOL g_zx8fChecking = NO;
static BOOL g_zx8fOverlayVisible = NO;
static BOOL g_zx8fLastSigned = NO;
static std::atomic<bool> g_zx8fActivatedLicense(false);
static NSString *g_zx8fSessionToken = nil;
static NSTimeInterval g_zx8fSessionExpire = 0;
static NSString *g_zx8fMyKeyURL = nil;
static NSString *g_zx8fEnrollURL = nil;
static NSTimeInterval g_zx8fEnrollExpire = 0;
static NSString *g_zx8fCanonicalDeviceId = nil;
static BOOL g_zx8fEnrollmentPending = NO;
static NSTimeInterval g_zx8fEnrollmentUntil = 0;
static NSUInteger g_zx8fEnrollmentRetrySeed = 0;
static NSUInteger g_zx8fEnrollmentRetryCount = 0;
static BOOL g_zx8fOpenEnrollmentAfterRefresh = NO;
static NSUInteger g_zx8fRefreshSeed = 0;
static NSInteger g_zx8fLastDays = -1;
static NSTimeInterval g_zx8fLastAuthOKTime = 0;
static NSUInteger g_zx8fSoftFailCount = 0;
static NSUInteger g_zx8fNegativeLicenseCount = 0;
static NSTimeInterval g_zx8fNegativeLicenseTime = 0;
static BOOL g_zx8fWasInactive = NO;
static NSTimeInterval g_zx8fResumeGraceUntil = 0;
static const NSTimeInterval ZX8F_SOFT_AUTH_GRACE = 3600.0;
static const NSUInteger ZX8F_SOFT_FAIL_LIMIT = 5;
static const NSTimeInterval ZX8F_SOFT_RETRY_DELAY = 20.0;
static const NSUInteger ZX8F_NEGATIVE_LICENSE_LIMIT = 3;
static const NSTimeInterval ZX8F_NEGATIVE_LICENSE_WINDOW = 90.0;
static UIView *g_zx8fOverlay = nil;
static UILabel *g_zx8fStatus = nil;
static UILabel *g_zx8fDeviceLabel = nil;
static UIView *g_zx8fAnnOverlay = nil;
static NSString *g_zx8fAnnId = nil;
static NSString *g_zx8fAnnTitle = nil;
static NSString *g_zx8fAnnBody = nil;
static NSString *g_zx8fAnnLinkURL = nil;
static NSString *g_zx8fAnnLinkText = nil;
static BOOL g_zx8fAnnEnabled = NO;
static BOOL g_zx8fAnnForce = NO;
static NSTimeInterval g_zx8fAnnDelay = 39.0;
static BOOL g_zx8fAnnShownThisRun = NO;
static NSUInteger g_zx8fAnnRetry = 0;
static NSString *g_zx8fUpdateShownId = nil;
static NSString *g_zx8fUpdateURL = nil;
static NSDictionary *g_zx8fMenuLabelsVI = nil;
static BOOL g_zx8fMenuLabelsLoaded = NO;
static NSDictionary *g_zx8fUILabels = nil;
static BOOL g_zx8fUILabelsLoaded = NO;
static BOOL g_zx8fUpdateForcedLock = NO;
static Zx8fAllowBlock g_zx8fAllowBlock = nil;
static std::atomic<unsigned int> g_zx8fModuleMask(0);
static std::atomic<uint64_t> g_zx8fProofA(0);
static std::atomic<uint64_t> g_zx8fProofB(0);
static std::atomic<uint64_t> g_zx8fProofGeneration(0);
static std::atomic<uint64_t> g_zx8fProofDeadlineBits(0);
static std::atomic_flag g_zx8fProofLock = ATOMIC_FLAG_INIT;
static thread_local uint64_t g_zx8fPendingChallenge = 0;
static thread_local uint64_t g_zx8fPendingResponse = 0;
static thread_local uint64_t g_zx8fPendingGeneration = 0;
static thread_local NSTimeInterval g_zx8fPendingDeadline = 0;
static const unsigned int ZX8F_M_MENU = 1u << 0;
static const unsigned int ZX8F_M_SPEED = 1u << 1;
static const unsigned int ZX8F_M_COUNTER = 1u << 2;
static const unsigned int ZX8F_M_POTION = 1u << 3;
static const unsigned int ZX8F_M_TOKEN = 1u << 4;
static const unsigned int ZX8F_M_AUTO_BUILD = 1u << 5;
static const unsigned int ZX8F_M_MAGIC_CARDS = 1u << 6;
static const unsigned int ZX8F_M_EXPEDITION = 1u << 7;
static const unsigned int ZX8F_M_LIGHTNING = 1u << 8;
static const unsigned int ZX8F_M_BET_CYCLE = 1u << 9;
static const unsigned int ZX8F_M_AUTO_MERGE = 1u << 10;
static const unsigned int ZX8F_M_AUTO_CLICK = 1u << 11;
static const unsigned int ZX8F_M_RAID_HAMMER = 1u << 12;
static const unsigned int ZX8F_M_TOOLS = 1u << 13;
static const unsigned int ZX8F_M_AUTO_STOP = 1u << 14;
static const unsigned int ZX8F_M_MENU_COLOR = 1u << 15;
static const unsigned int ZX8F_M_FRIEND_INVITE = 1u << 16;
static const unsigned int ZX8F_M_ALL = ZX8F_M_MENU | ZX8F_M_SPEED | ZX8F_M_COUNTER | ZX8F_M_POTION | ZX8F_M_TOKEN | ZX8F_M_AUTO_BUILD | ZX8F_M_MAGIC_CARDS | ZX8F_M_EXPEDITION | ZX8F_M_LIGHTNING | ZX8F_M_BET_CYCLE | ZX8F_M_AUTO_MERGE | ZX8F_M_AUTO_CLICK | ZX8F_M_RAID_HAMMER | ZX8F_M_TOOLS | ZX8F_M_AUTO_STOP | ZX8F_M_MENU_COLOR | ZX8F_M_FRIEND_INVITE;

static NSString *Zx8fBuildChannel(void);

static uint64_t Zx8fMix64(uint64_t value) {
    value ^= value >> 30;
    value *= R7F8_A | 1;
    value ^= value >> 27;
    value *= R7F8_B | 1;
    value ^= value >> 31;
    return value;
}

static uint64_t Zx8fRotate64(uint64_t value,
                            unsigned shift) {
    shift &= 63;
    return (value << shift) |
           (value >> ((64 - shift) & 63));
}

static uint64_t Zx8fDoubleBits(NSTimeInterval value) {
    uint64_t bits = 0;
    memcpy(&bits, &value, sizeof(bits));
    return bits;
}

static NSTimeInterval Zx8fBitsDouble(uint64_t bits) {
    NSTimeInterval value = 0;
    memcpy(&value, &bits, sizeof(value));
    return value;
}

static BOOL Zx8fSameImageCaller(const void *address) {
    if (!address) return NO;
    static uintptr_t textStart = 0;
    static uintptr_t textEnd = 0;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Dl_info info;
        memset(&info, 0, sizeof(info));
        if (dladdr((const void *)&R7f408, &info) == 0 ||
            !info.dli_fbase) {
            return;
        }
        const struct mach_header_64 *header =
            reinterpret_cast<const struct mach_header_64 *>(
                info.dli_fbase);
        if (header->magic != MH_MAGIC_64) return;
        const uint8_t *cursor =
            reinterpret_cast<const uint8_t *>(header) +
            sizeof(struct mach_header_64);
        for (uint32_t i = 0; i < header->ncmds; ++i) {
            const struct load_command *command =
                reinterpret_cast<const struct load_command *>(cursor);
            if (command->cmdsize < sizeof(struct load_command)) {
                return;
            }
            if (command->cmd == LC_SEGMENT_64) {
                const struct segment_command_64 *segment =
                    reinterpret_cast<const struct segment_command_64 *>(
                        cursor);
                if (strncmp(segment->segname,
                            SEG_TEXT,
                            sizeof(segment->segname)) == 0) {
                    uintptr_t slide =
                        reinterpret_cast<uintptr_t>(header) -
                        static_cast<uintptr_t>(segment->vmaddr);
                    textStart = slide +
                        static_cast<uintptr_t>(segment->vmaddr);
                    textEnd = textStart +
                        static_cast<uintptr_t>(segment->vmsize);
                    return;
                }
            }
            cursor += command->cmdsize;
        }
    });
    uintptr_t value = reinterpret_cast<uintptr_t>(address);
    return textStart != 0 &&
           textEnd > textStart &&
           value >= textStart &&
           value < textEnd;
}

static void Zx8fClearExpeditionProof(void) {
    g_zx8fProofA.store(0, std::memory_order_release);
    g_zx8fProofB.store(0, std::memory_order_release);
    g_zx8fProofDeadlineBits.store(0, std::memory_order_release);
    g_zx8fProofGeneration.fetch_add(1, std::memory_order_acq_rel);
    g_zx8fPendingChallenge = 0;
    g_zx8fPendingResponse = 0;
    g_zx8fPendingGeneration = 0;
    g_zx8fPendingDeadline = 0;
}

static void Zx8fRefreshExpeditionProof(void) {
    if (g_zx8fProofLock.test_and_set(std::memory_order_acquire)) {
        return;
    }
    unsigned int mask =
        g_zx8fModuleMask.load(std::memory_order_acquire);
    NSTimeInterval now =
        [NSDate date].timeIntervalSince1970;
    if ((mask & ZX8F_M_EXPEDITION) == 0 ||
        g_zx8fSessionToken.length < 32 ||
        g_zx8fSessionExpire <= now + 5.0) {
        Zx8fClearExpeditionProof();
        g_zx8fProofLock.clear(std::memory_order_release);
        return;
    }

    uint64_t entropy[4] = {0, 0, 0, 0};
    arc4random_buf(entropy, sizeof(entropy));
    NSString *material = [NSString stringWithFormat:
        OX_NS("%@|%@|%@|%@|%.0f|%016llx|%016llx"),
        g_zx8fSessionToken ?: @"",
        Zx8fDeviceId() ?: @"",
        Zx8fProtectedHash() ?: @"",
        Zx8fBuildChannel() ?: @"",
        g_zx8fSessionExpire,
        (unsigned long long)entropy[0],
        (unsigned long long)entropy[1]];
    NSData *data = [material dataUsingEncoding:NSUTF8StringEncoding];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH] = {0};
    if (data.length > 0) {
        CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    }

    uint64_t digestA = 0;
    uint64_t digestB = 0;
    uint64_t digestC = 0;
    memcpy(&digestA, digest, sizeof(digestA));
    memcpy(&digestB, digest + 8, sizeof(digestB));
    memcpy(&digestC, digest + 16, sizeof(digestC));
    memset(digest, 0, sizeof(digest));

    uint64_t first = Zx8fMix64(
        digestA ^ entropy[2] ^
        (uint64_t)mask ^ R7F8_C);
    uint64_t second = Zx8fMix64(
        digestB ^ entropy[3] ^
        Zx8fRotate64(first, 19) ^ R7F8_D);
    first ^= Zx8fMix64(
        digestC ^ Zx8fRotate64(second, 31) ^ R7F8_E);
    if (first == 0) first = R7F8_C | 1;
    if (second == 0) second = R7F8_D | 1;

    NSTimeInterval lifetime =
        11.0 + (NSTimeInterval)arc4random_uniform(7);
    g_zx8fProofB.store(second, std::memory_order_release);
    g_zx8fProofA.store(first, std::memory_order_release);
    g_zx8fProofDeadlineBits.store(
        Zx8fDoubleBits(now + lifetime),
        std::memory_order_release);
    g_zx8fProofGeneration.fetch_add(1, std::memory_order_acq_rel);
    g_zx8fProofLock.clear(std::memory_order_release);
}

static NSString *Zx8fHex(const unsigned char *digest, size_t len) {
    static const char *hex = "0123456789abcdef";
    char *buf = (char *)malloc(len * 2 + 1);
    if (!buf) return @"";
    for (size_t i = 0; i < len; i++) {
        buf[i * 2] = hex[(digest[i] >> 4) & 0xF];
        buf[i * 2 + 1] = hex[digest[i] & 0xF];
    }
    buf[len * 2] = 0;
    NSString *out = [NSString stringWithUTF8String:buf] ?: @"";
    memset(buf, 0, len * 2);
    free(buf);
    return out;
}

static NSString *Zx8fSHA256Hex(NSString *payload) {
    if (![payload isKindOfClass:[NSString class]]) return @"";
    NSData *pd = [payload dataUsingEncoding:NSUTF8StringEncoding];
    if (pd.length == 0) return @"";
    unsigned char out[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(pd.bytes, (CC_LONG)pd.length, out);
    return Zx8fHex(out, CC_SHA256_DIGEST_LENGTH);
}

static NSString *Zx8fHMACSHA256Hex(NSString *key, NSString *payload) {
    if (![key isKindOfClass:[NSString class]] || ![payload isKindOfClass:[NSString class]]) return @"";
    NSData *kd = [key dataUsingEncoding:NSUTF8StringEncoding];
    NSData *pd = [payload dataUsingEncoding:NSUTF8StringEncoding];
    if (kd.length == 0 || pd.length == 0) return @"";
    unsigned char out[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, kd.bytes, kd.length, pd.bytes, pd.length, out);
    return Zx8fHex(out, CC_SHA256_DIGEST_LENGTH);
}

static NSString *Zx8fEnrollProofKey(void) {
    return OX_NS("0f7bef8d06985127ecb1cb4f780757f6cd1090ed74250744324b708f3788499c");
}

static NSData *Zx8fBase64Data(NSString *value) {
    if (![value isKindOfClass:[NSString class]] || value.length == 0) return nil;
    return [[NSData alloc] initWithBase64EncodedString:value options:NSDataBase64DecodingIgnoreUnknownCharacters];
}

static NSString *Zx8fStr(id v) {
    if (!v || v == [NSNull null]) return @"";
    if ([v isKindOfClass:[NSString class]]) return (NSString *)v;
    if ([v respondsToSelector:@selector(stringValue)]) return [v stringValue] ?: @"";
    return [[v description] copy] ?: @"";
}

static NSString *Zx8fSignJoin(NSArray<NSString *> *parts) {
    NSMutableArray *out = [NSMutableArray arrayWithCapacity:parts.count];
    for (NSString *s in parts) [out addObject:s ?: @""];
    return [out componentsJoinedByString:OX_NS("|")];
}

static NSString *Zx8fNonce(void) {
    uint8_t b[16];
    for (size_t i = 0; i < sizeof(b); i++) b[i] = (uint8_t)arc4random_uniform(256);
    NSMutableString *s = [NSMutableString stringWithCapacity:32];
    for (size_t i = 0; i < sizeof(b); i++) [s appendFormat:OX_NS("%02x"), b[i]];
    return s;
}

static NSString *Zx8fBuildChannel(void) {
    return [NSString stringWithUTF8String:
        OX_C(ONGNONG_BUILD_CHANNEL)] ?: @"";
}

static NSString *Zx8fClientPayload(NSString *device, NSString *build, NSString *hash, NSString *realHash, NSString *ts, NSString *nonce, NSString *bundle, NSString *clone, NSString *mainFlag) {
    return Zx8fSignJoin(@[device ?: @"", build ?: @"", hash ?: @"", realHash ?: @"", ts ?: @"", nonce ?: @"", bundle ?: @"", clone ?: @"", mainFlag ?: @""]);
}

static NSData *Zx8fPublicKeyDER(void) {
    static NSData *cached = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSArray<NSString *> *parts = @[
            OX_NS("MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA6S8rmNfqA8nJeIO5g+Qb1kj9T4vMKl2kIjoq"),
            OX_NS("Kmy7LzyB5hiDbxx56GCwQqk5nLKid+AH7M8OUmo2hXW1POIy///22UyXhbwJdF3z7vzCaVdmBjRP7Fa9"),
            OX_NS("GGFo/HLTh1wkPAiB1DCEaL6u+EVF0SD4InykrOmY2oGfihLTqcRvpaeuTiOj/9vzYxC2AIUHSF4WzK2u"),
            OX_NS("hoWrr7dRkpH3vQYme9VIV1BqlwEhZxRCJG4zfs9AKVGFU79mz6IifcVcegkgU3OURezMF8CT4Dvq/pjR"),
            OX_NS("yoA1JXeKz4DAyNV701h26SPhhA5rRFiO9lHa4zBOKZ+D+LslFsU/qnb9mAMnWFiUaQIDAQAB")
        ];
        NSString *joined = [parts componentsJoinedByString:@""];
        cached = Zx8fBase64Data(joined);
    });
    return cached;
}

static SecKeyRef Zx8fCreatePublicKey(void) {
    NSData *der = Zx8fPublicKeyDER();
    if (der.length == 0) return nil;
    NSDictionary *attrs = @{
        (__bridge id)kSecAttrKeyType: (__bridge id)kSecAttrKeyTypeRSA,
        (__bridge id)kSecAttrKeyClass: (__bridge id)kSecAttrKeyClassPublic,
        (__bridge id)kSecAttrKeySizeInBits: @2048
    };
    if (@available(iOS 10.0, *)) {
        return SecKeyCreateWithData((__bridge CFDataRef)der, (__bridge CFDictionaryRef)attrs, nil);
    }
    return nil;
}

__attribute__((noinline, visibility("hidden")))
BOOL R7f410(NSData *payload, NSData *signature) {
    if (payload.length == 0 || signature.length == 0) return NO;
    if (@available(iOS 10.0, *)) {
        SecKeyRef pub = Zx8fCreatePublicKey();
        if (!pub) return NO;
        CFErrorRef err = NULL;
        BOOL ok = SecKeyVerifySignature(pub, kSecKeyAlgorithmRSASignatureMessagePKCS1v15SHA256, (__bridge CFDataRef)payload, (__bridge CFDataRef)signature, &err);
        if (err) CFRelease(err);
        CFRelease(pub);
        return ok;
    }
    return NO;
}

static BOOL Zx8fSignedPayloadLooksCurrent(NSDictionary *json, NSString *expectedNonce) {
    NSString *alg = Zx8fStr(json[OX_NS("sig_alg")]);
    if (![alg isEqualToString:OX_NS("RS256")]) return NO;
    NSString *serverTime = Zx8fStr(json[kServerTime()]);
    NSString *nonce = Zx8fStr(json[kResponseNonce()]);
    if (serverTime.length == 0 || nonce.length < 8) return NO;
    if (![expectedNonce isKindOfClass:[NSString class]] || expectedNonce.length < 8) return NO;
    if (![nonce isEqualToString:expectedNonce]) return NO;
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    NSTimeInterval t = (NSTimeInterval)serverTime.longLongValue;
    if (t <= 0 || fabs(now - t) > 900.0) return NO;
    NSString *device = Zx8fStr(json[kDevice()]);
    NSString *submittedDevice = Zx8fStr(json[OX_NS("submitted_device_id")]);
    NSString *localDevice = Zx8fDeviceId();
    NSString *build = Zx8fStr(json[kBuildKey()]);
    NSString *hash = Zx8fStr(json[kHash()]);
    if (submittedDevice.length > 0) {
        if (![submittedDevice isEqualToString:localDevice]) return NO;
    } else if (device.length > 0 && ![device isEqualToString:localDevice]) {
        return NO;
    }
    if (build.length > 0 && ![build isEqualToString:kBuild()]) return NO;
    if (hash.length > 0 && [hash caseInsensitiveCompare:Zx8fProtectedHash()] != NSOrderedSame) return NO;
    return YES;
}

static NSDictionary *Zx8fVerifiedPayload(NSDictionary *packet, NSString *expectedNonce) {
    NSString *payloadB64 = Zx8fStr(packet[OX_NS("signed_payload")]);
    NSString *sigB64 = Zx8fStr(packet[kResponseSig()]);
    NSData *payloadData = Zx8fBase64Data(payloadB64);
    NSData *sigData = Zx8fBase64Data(sigB64);
    if (payloadData.length == 0 || sigData.length == 0) return nil;
    if (!R7f410(payloadData, sigData)) return nil;
    id obj = [NSJSONSerialization JSONObjectWithData:payloadData options:0 error:nil];
    if (![obj isKindOfClass:[NSDictionary class]]) return nil;
    NSDictionary *payload = (NSDictionary *)obj;
    if (!Zx8fSignedPayloadLooksCurrent(payload, expectedNonce)) return nil;
    return payload;
}

static void Zx8fUpdateSHA(CC_SHA256_CTX *ctx, NSString *s) {
    if (!ctx || !s) return;
    NSData *d = [s dataUsingEncoding:NSUTF8StringEncoding];
    if (d.length > 0) CC_SHA256_Update(ctx, d.bytes, (CC_LONG)d.length);
}

static void Zx8fUpdateBytes(CC_SHA256_CTX *ctx, const void *ptr, size_t len) {
    if (!ctx || !ptr || len == 0) return;
    const size_t chunk = 1024 * 1024;
    const uint8_t *p = (const uint8_t *)ptr;
    while (len > 0) {
        size_t n = len > chunk ? chunk : len;
        CC_SHA256_Update(ctx, p, (CC_LONG)n);
        p += n;
        len -= n;
    }
}

static uintptr_t Zx8fSlideForHeader(const struct mach_header_64 *mh) {
    if (!mh) return 0;
    const uint8_t *cursor = (const uint8_t *)mh + sizeof(struct mach_header_64);
    for (uint32_t i = 0; i < mh->ncmds; i++) {
        const struct load_command *lc = (const struct load_command *)cursor;
        if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *seg = (const struct segment_command_64 *)cursor;
            if (strncmp(seg->segname, "__TEXT", 16) == 0) return (uintptr_t)mh - (uintptr_t)seg->vmaddr;
        }
        cursor += lc->cmdsize;
    }
    return 0;
}

static void Zx8fUpdateTextSection(CC_SHA256_CTX *ctx) {
    Dl_info info;
    memset(&info, 0, sizeof(info));
    if (dladdr((const void *)&Zx8fProtectedHash, &info) == 0 || !info.dli_fbase) return;
    const struct mach_header_64 *mh = (const struct mach_header_64 *)info.dli_fbase;
    if (mh->magic != MH_MAGIC_64) return;
    uintptr_t slide = Zx8fSlideForHeader(mh);
    const uint8_t *cursor = (const uint8_t *)mh + sizeof(struct mach_header_64);
    for (uint32_t i = 0; i < mh->ncmds; i++) {
        const struct load_command *lc = (const struct load_command *)cursor;
        if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *seg = (const struct segment_command_64 *)cursor;
            const struct section_64 *sec = (const struct section_64 *)(cursor + sizeof(struct segment_command_64));
            for (uint32_t j = 0; j < seg->nsects; j++) {
                BOOL isText = (strncmp(sec[j].segname, "__TEXT", 16) == 0 && strncmp(sec[j].sectname, "__text", 16) == 0);
                if (isText && sec[j].size > 0) {
                    const void *start = (const void *)(slide + (uintptr_t)sec[j].addr);
                    Zx8fUpdateBytes(ctx, start, (size_t)sec[j].size);
                }
            }
        }
        cursor += lc->cmdsize;
    }
}

NSString *Zx8fProtectedHash(void) {
    CC_SHA256_CTX ctx;
    CC_SHA256_Init(&ctx);
    Zx8fUpdateSHA(&ctx, kStableSalt());
    Zx8fUpdateSHA(&ctx, kApiUrl());
    Zx8fUpdateSHA(&ctx, kBuild());
    Zx8fUpdateSHA(&ctx, Zx8fBuildChannel());
    Zx8fUpdateSHA(&ctx, kTgUrl());
    Zx8fUpdateSHA(&ctx, kTitle());
    Zx8fUpdateSHA(&ctx, kDevice());
    Zx8fUpdateSHA(&ctx, kBuildKey());
    Zx8fUpdateSHA(&ctx, kHash());
    Zx8fUpdateSHA(&ctx, kRealHash());
    Zx8fUpdateSHA(&ctx, kAction());
    Zx8fUpdateSHA(&ctx, kCheckAction());
    Zx8fUpdateTextSection(&ctx);
    unsigned char out[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256_Final(out, &ctx);
    return Zx8fHex(out, CC_SHA256_DIGEST_LENGTH);
}

NSString *Zx8fRealFileHash(void) {
    Dl_info info;
    memset(&info, 0, sizeof(info));
    if (dladdr((const void *)&Zx8fRealFileHash, &info) == 0 || !info.dli_fname) return @"";
    NSString *path = [NSString stringWithUTF8String:info.dli_fname] ?: @"";
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:path];
    if (!fh) return @"";
    CC_SHA256_CTX ctx;
    CC_SHA256_Init(&ctx);
    @autoreleasepool {
        while (true) {
            NSData *d = [fh readDataOfLength:1024 * 1024];
            if (d.length == 0) break;
            CC_SHA256_Update(&ctx, d.bytes, (CC_LONG)d.length);
        }
    }
    [fh closeFile];
    unsigned char out[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256_Final(out, &ctx);
    return Zx8fHex(out, CC_SHA256_DIGEST_LENGTH);
}

static NSString *Zx8fUUIDString(void) {
    NSString *uuid = [[NSUUID UUID] UUIDString] ?: OX_NS("00000000-0000-0000-0000-000000000000");
    NSCharacterSet *bad = [[NSCharacterSet alphanumericCharacterSet] invertedSet];
    NSString *compact = [[uuid componentsSeparatedByCharactersInSet:bad] componentsJoinedByString:@""];
    if (compact.length > 20) compact = [compact substringToIndex:20];
    return [kDevicePrefix() stringByAppendingString:compact.uppercaseString];
}

static NSString *Zx8fReadFromSharedFile(void) {
    NSString *shared = kSharedPath();
    NSDictionary *pack = [NSDictionary dictionaryWithContentsOfFile:shared];
    if (![pack isKindOfClass:[NSDictionary class]]) return nil;
    NSString *d = pack[kDevice()];
    if (![d isKindOfClass:[NSString class]] || d.length < 5) d = pack[kDeviceLegacy()];
    return ([d isKindOfClass:[NSString class]] && d.length > 4) ? d : nil;
}

static void Zx8fWriteSharedFile(NSString *deviceID) {
    if (![deviceID isKindOfClass:[NSString class]] || deviceID.length < 5) return;
    NSString *shared = kSharedPath();
    NSString *dir = [shared stringByDeletingLastPathComponent];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    NSDictionary *out = @{ kDevice(): deviceID, kDeviceLegacy(): deviceID, kUpdatedAt(): @((long long)[NSDate date].timeIntervalSince1970) };
    [out writeToFile:shared atomically:YES];
}

static NSString *Zx8fReadKeychain(void) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kKeychainService(),
        (__bridge id)kSecAttrAccount: kKeychainAccount(),
        (__bridge id)kSecReturnData: @YES,
        (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne
    };
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || !result) return nil;
    NSData *data = (__bridge_transfer NSData *)result;
    NSString *value = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return (value.length > 4) ? value : nil;
}

static void Zx8fWriteKeychain(NSString *deviceID) {
    if (![deviceID isKindOfClass:[NSString class]] || deviceID.length < 5) return;
    NSData *data = [deviceID dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kKeychainService(),
        (__bridge id)kSecAttrAccount: kKeychainAccount()
    };
    NSDictionary *update = @{(__bridge id)kSecValueData: data};
    OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)query, (__bridge CFDictionaryRef)update);
    if (status == errSecSuccess) return;
    NSMutableDictionary *add = [query mutableCopy];
    add[(__bridge id)kSecValueData] = data;
    add[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlock;
    SecItemAdd((__bridge CFDictionaryRef)add, NULL);
}

static void Zx8fPersistCanonicalDeviceId(NSString *deviceID) {
    if (![deviceID isKindOfClass:[NSString class]] || deviceID.length < 5 || deviceID.length > 96) return;
    g_zx8fCanonicalDeviceId = [deviceID copy];
    Zx8fWriteSharedFile(deviceID);
    Zx8fWriteKeychain(deviceID);
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:deviceID forKey:kDataFile()];
    [ud synchronize];
}

NSString *Zx8fDeviceId(void) {
    static NSString *cached = nil;
    if (g_zx8fCanonicalDeviceId.length > 0) return g_zx8fCanonicalDeviceId;
    if (cached.length > 0) return cached;

    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *d = Zx8fReadFromSharedFile();
    if (d.length > 4) {
        cached = d;
        Zx8fWriteKeychain(d);
        [ud setObject:d forKey:kDataFile()];
        [ud synchronize];
        return cached;
    }

    d = Zx8fReadKeychain();
    if (d.length > 4) {
        cached = d;
        Zx8fWriteSharedFile(d);
        [ud setObject:d forKey:kDataFile()];
        [ud synchronize];
        return cached;
    }

    d = [ud stringForKey:kDataFile()];
    if ([d isKindOfClass:[NSString class]] && d.length > 4) {
        cached = d;
        Zx8fWriteSharedFile(d);
        Zx8fWriteKeychain(d);
        return cached;
    }

    d = Zx8fUUIDString();
    cached = d;
    Zx8fWriteSharedFile(d);
    Zx8fWriteKeychain(d);
    [ud setObject:d forKey:kDataFile()];
    [ud synchronize];
    return cached;
}

NSString *Zx8fMyKeyURL(void) {
    if (g_zx8fMyKeyURL.length > 0) return g_zx8fMyKeyURL;
    return OX_NS("https://thuoc-api.ongnong.io.vn/thuoc_ios/mykey.php");
}

NSString *Zx8fEnrollmentURL(void) {
    return g_zx8fEnrollURL ?: @"";
}

NSString *Zx8fUpdateURL(void) {
    return g_zx8fUpdateURL ?: @"";
}

BOOL Zx8fHasSecureMyKeyURL(void) {
    if (g_zx8fMyKeyURL.length == 0) return NO;
    NSURLComponents *parts = [NSURLComponents componentsWithString:g_zx8fMyKeyURL];
    for (NSURLQueryItem *item in parts.queryItems) {
        if ([[item.name lowercaseString] isEqualToString:OX_NS("t")] && item.value.length > 20) return YES;
    }
    return NO;
}

static NSString *Zx8fEncode(NSString *s) {
    if (!s) return @"";
    NSMutableCharacterSet *allowed = [[NSCharacterSet URLQueryAllowedCharacterSet] mutableCopy];
    [allowed removeCharactersInString:OX_NS("&=+?/:#[]@!$'()*;,\"")];
    return [s stringByAddingPercentEncodingWithAllowedCharacters:allowed] ?: @"";
}

static NSData *Zx8fFormBody(NSDictionary<NSString *, NSString *> *items) {
    NSMutableArray *parts = [NSMutableArray array];
    for (NSString *key in items) {
        NSString *value = items[key] ?: @"";
        [parts addObject:[NSString stringWithFormat:OX_NS("%@=%@"), Zx8fEncode(key), Zx8fEncode(value)]];
    }
    NSString *body = [parts componentsJoinedByString:OX_NS("&")];
    return [body dataUsingEncoding:NSUTF8StringEncoding];
}

static BOOL Zx8fBoolValue(id obj, BOOL fallback) {
    if ([obj respondsToSelector:@selector(boolValue)]) return [obj boolValue];
    return fallback;
}

static NSInteger Zx8fIntValue(id obj, NSInteger fallback) {
    if ([obj respondsToSelector:@selector(integerValue)]) return [obj integerValue];
    return fallback;
}

static NSString *Zx8fMessageFromJSON(NSDictionary *json, NSString *fallback) {
    id m = json[kMessage()];
    if (![m isKindOfClass:[NSString class]] || [m length] == 0) m = json[kError()];
    if (![m isKindOfClass:[NSString class]] || [m length] == 0) return fallback;
    NSString *msg = (NSString *)m;
    if ([msg rangeOfString:zxv_g00() options:NSCaseInsensitiveSearch].location != NSNotFound) return kInvalid();
    if ([msg rangeOfString:zxv_g01() options:NSCaseInsensitiveSearch].location != NSNotFound) return kInvalid();
    return msg;
}

static UIWindow *Zx8fHostWindow(void) {
    UIApplication *app = [UIApplication sharedApplication];
    UIWindow *w = app.keyWindow;
    if (w) return w;
    for (UIWindow *candidate in app.windows) {
        if (!candidate.hidden && candidate.alpha > 0.01) return candidate;
    }
    return app.windows.firstObject;
}

static void Zx8fImpact(void) {
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [g prepare];
        [g impactOccurred];
    }
}

static NSString *Zx8fLocalizedOverlayStatus(NSString *message);

static void Zx8fSetStatus(NSString *msg) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (g_zx8fStatus) g_zx8fStatus.text = Zx8fLocalizedOverlayStatus(msg ?: @"");
    });
}

static void Zx8fRemoveOverlay(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [g_zx8fOverlay removeFromSuperview];
        g_zx8fOverlay = nil;
        g_zx8fStatus = nil;
        g_zx8fDeviceLabel = nil;
        g_zx8fOverlayVisible = NO;
    });
}

static void Zx8fTryFinish(NSInteger days) {
    g_zx8fAllowed = YES;
    g_zx8fLastDays = days;
    g_zx8fLastAuthOKTime = [NSDate date].timeIntervalSince1970;
    g_zx8fSoftFailCount = 0;
    g_zx8fNegativeLicenseCount = 0;
    g_zx8fNegativeLicenseTime = 0;
    Zx8fRemoveOverlay();
    Zx8fAllowBlock cb = g_zx8fAllowBlock;
    if (cb && Zx8fMenuAllowed()) dispatch_async(dispatch_get_main_queue(), ^{ cb(days); });
}

static void Zx8fCheckNow(BOOL manual);
static void Zx8fScheduleAnnouncement(NSUInteger attempt);
static void Zx8fScheduleRefresh(NSTimeInterval delay);
static void Zx8fScheduleSoftRetry(NSTimeInterval delay);
static void Zx8fHandleSoftFail(BOOL manual);
static BOOL Zx8fRecentAuthOK(void);

static void Zx8fOpenEnrollmentURL(NSString *link) {
    NSURL *url = [NSURL URLWithString:link ?: @""];
    if (!url) return;
    UIApplication *app = [UIApplication sharedApplication];
    if ([app respondsToSelector:@selector(openURL:options:completionHandler:)]) {
        [app openURL:url options:@{} completionHandler:nil];
    } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        [app openURL:url];
#pragma clang diagnostic pop
    }
}

static void Zx8fCancelEnrollmentPending(void) {
    g_zx8fEnrollmentPending = NO;
    g_zx8fEnrollmentUntil = 0;
    g_zx8fEnrollmentRetryCount = 0;
    g_zx8fOpenEnrollmentAfterRefresh = NO;
    ++g_zx8fEnrollmentRetrySeed;
}

static void Zx8fScheduleEnrollmentRetry(void) {
    if (!g_zx8fEnrollmentPending) return;
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    if (g_zx8fEnrollmentUntil <= now) {
        Zx8fCancelEnrollmentPending();
        return;
    }
    static const NSTimeInterval delays[] = {2.0, 5.0, 10.0, 20.0, 35.0};
    if (g_zx8fEnrollmentRetryCount >= sizeof(delays) / sizeof(delays[0])) return;
    NSTimeInterval delay = delays[g_zx8fEnrollmentRetryCount++];
    NSUInteger seed = g_zx8fEnrollmentRetrySeed;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (seed != g_zx8fEnrollmentRetrySeed || !g_zx8fEnrollmentPending) return;
        NSTimeInterval t = [NSDate date].timeIntervalSince1970;
        if (g_zx8fEnrollmentUntil <= t) {
            Zx8fCancelEnrollmentPending();
            return;
        }
        Zx8fCheckNow(NO);
    });
}

static void Zx8fBeginEnrollment(void) {
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    g_zx8fEnrollmentPending = YES;
    g_zx8fEnrollmentUntil = now + 900.0;
    g_zx8fEnrollmentRetryCount = 0;
    ++g_zx8fEnrollmentRetrySeed;
    NSString *link = g_zx8fEnrollURL;
    BOOL usable = link.length > 0 && (g_zx8fEnrollExpire <= 0 || g_zx8fEnrollExpire > now + 5.0);
    if (!usable) {
        g_zx8fOpenEnrollmentAfterRefresh = YES;
        Zx8fSetStatus(kChecking());
        Zx8fCheckNow(YES);
        return;
    }
    g_zx8fOpenEnrollmentAfterRefresh = NO;
    Zx8fOpenEnrollmentURL(link);
}

}

@interface Q9c2A : NSObject
@end

@implementation Q9c2A
- (void)p4m8a {
    Ongnong::Zx8fImpact();
    [UIPasteboard generalPasteboard].string = Ongnong::Zx8fDeviceId();
    Ongnong::Zx8fSetStatus(kCopied());
}
- (void)t7v2c {
    Ongnong::Zx8fImpact();
    NSURL *url = [NSURL URLWithString:kTgUrl()];
    if (url) {
        UIApplication *app = [UIApplication sharedApplication];
        if ([app respondsToSelector:@selector(openURL:options:completionHandler:)]) {
            [app openURL:url options:@{} completionHandler:nil];
        } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
            [app openURL:url];
#pragma clang diagnostic pop
        }
    }
}
- (void)u5e1r {
    Ongnong::Zx8fImpact();
    Ongnong::Zx8fBeginEnrollment();
}
- (void)k3d9x {
    Ongnong::Zx8fImpact();
    Ongnong::Zx8fSetStatus(kChecking());
    Ongnong::Zx8fCheckNow(YES);
}
- (void)v8q2l {
    Ongnong::Zx8fImpact();
    NSString *raw = Ongnong::g_zx8fAnnLinkURL ?: @"";
    NSURL *url = [NSURL URLWithString:[raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
    NSString *scheme = url.scheme.lowercaseString;
    if (!url || !([scheme isEqualToString:@"https"] || [scheme isEqualToString:@"http"])) return;
    UIApplication *app = [UIApplication sharedApplication];
    if ([app respondsToSelector:@selector(openURL:options:completionHandler:)]) {
        [app openURL:url options:@{} completionHandler:nil];
    } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        [app openURL:url];
#pragma clang diagnostic pop
    }
}
- (void)w6n1b {
    Ongnong::Zx8fImpact();
    if (Ongnong::g_zx8fAnnId.length > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:Ongnong::g_zx8fAnnId forKey:kAnnReadKey()];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    [Ongnong::g_zx8fAnnOverlay removeFromSuperview];
    Ongnong::g_zx8fAnnOverlay = nil;
}
@end

namespace Ongnong {

static Q9c2A *g_zx8fTarget = nil;

static UIButton *Zx8fButton(NSString *title, SEL sel) {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:title forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont boldSystemFontOfSize:14.5];
    b.titleLabel.adjustsFontSizeToFitWidth = YES;
    b.titleLabel.minimumScaleFactor = 0.65;
    b.backgroundColor = [UIColor colorWithWhite:0.02 alpha:0.70];
    [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    b.layer.cornerRadius = 9;
    b.layer.borderColor = [UIColor colorWithRed:1.0 green:0.78 blue:0.30 alpha:0.92].CGColor;
    b.layer.borderWidth = 1.2;
    [b addTarget:g_zx8fTarget action:sel forControlEvents:UIControlEventTouchUpInside];
    return b;
}

static NSString *Zx8fPhoneLang(void) {
    NSString *raw = [NSLocale preferredLanguages].firstObject ?: OX_NS("");
    NSString *code = [raw lowercaseString];
    if ([code hasPrefix:OX_NS("vi")]) return OX_NS("vi");
    if ([code hasPrefix:OX_NS("zh")]) return OX_NS("zh");
    if ([code hasPrefix:OX_NS("th")]) return OX_NS("th");
    if ([code hasPrefix:OX_NS("it")]) return OX_NS("it");
    return OX_NS("en");
}

static NSString *Zx8fLang(void) {
    return Zx8fPhoneLang();
}

static NSString *Zx8fMenuLang(void) {
    NSString *code = [[NSUserDefaults standardUserDefaults] stringForKey:OX_NS("ongnong_menu_language")];
    if ([code isEqualToString:OX_NS("vi")] || [code isEqualToString:OX_NS("zh")] || [code isEqualToString:OX_NS("th")] || [code isEqualToString:OX_NS("it")] || [code isEqualToString:OX_NS("en")]) return code;
    return OX_NS("vi");
}

static NSString *Zx8fMenuPickText(NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = Zx8fMenuLang();
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return vi ?: OX_NS("");
}

static NSString *Zx8fPickText(NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = Zx8fLang();
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return vi ?: OX_NS("");
}

static NSString *Zx8fAnnAckText(void) {
    return Zx8fMenuPickText(OX_NS("ĐÃ HIỂU"), OX_NS("我已了解"), OX_NS("เข้าใจแล้ว"), OX_NS("HO CAPITO"), OX_NS("UNDERSTOOD"));
}

static NSString *Zx8fOverlayTitleText(void) {
    return Zx8fPickText(OX_NS("MÃ KÍCH HOẠT / VIP"), OX_NS("激活码 / VIP"), OX_NS("รหัสเปิดใช้งาน / VIP"), OX_NS("CODICE ATTIVAZIONE / VIP"), OX_NS("ACTIVATION CODE / VIP"));
}

static NSString *Zx8fDeviceFormatText(void) {
    return Zx8fPickText(OX_NS("Mã kích hoạt:\n%@"), OX_NS("激活码：\n%@"), OX_NS("รหัสเปิดใช้งาน:\n%@"), OX_NS("Codice di attivazione:\n%@"), OX_NS("Activation code:\n%@"));
}

static NSString *Zx8fCopyText(void) {
    return Zx8fPickText(OX_NS("COPY MÃ KÍCH HOẠT"), OX_NS("复制激活码"), OX_NS("คัดลอกรหัสเปิดใช้งาน"), OX_NS("COPIA CODICE ATTIVAZIONE"), OX_NS("COPY ACTIVATION CODE"));
}

static NSString *Zx8fRestoreActivationText(void) {
    return Zx8fPickText(OX_NS("KHÔI PHỤC MÃ KÍCH HOẠT"), OX_NS("恢复激活码"), OX_NS("กู้คืนรหัสเปิดใช้งาน"), OX_NS("RIPRISTINA CODICE DI ATTIVAZIONE"), OX_NS("RESTORE ACTIVATION CODE"));
}

static NSString *Zx8fSendText(void) {
    return Zx8fPickText(OX_NS("LIÊN HỆ MUA VIP"), OX_NS("联系购买 VIP"), OX_NS("ติดต่อซื้อ VIP"), OX_NS("CONTATTA PER VIP"), OX_NS("CONTACT TO BUY VIP"));
}

static NSString *Zx8fCheckText(void) {
    return Zx8fPickText(OX_NS("KIỂM TRA KÍCH HOẠT"), OX_NS("检查激活状态"), OX_NS("ตรวจสอบการเปิดใช้งาน"), OX_NS("VERIFICA ATTIVAZIONE"), OX_NS("CHECK ACTIVATION"));
}

static NSString *Zx8fCheckingText(void) {
    return Zx8fPickText(OX_NS("Đang kiểm tra dữ liệu..."), OX_NS("正在检查数据..."), OX_NS("กำลังตรวจสอบข้อมูล..."), OX_NS("Verifica dati in corso..."), OX_NS("Checking data..."));
}

static NSString *Zx8fCopiedText(void) {
    return Zx8fPickText(OX_NS("Đã sao chép mã kích hoạt"), OX_NS("已复制激活码"), OX_NS("คัดลอกรหัสเปิดใช้งานแล้ว"), OX_NS("Codice di attivazione copiato"), OX_NS("Activation code copied"));
}

static NSString *Zx8fInactiveText(void) {
    return Zx8fPickText(OX_NS("Thiết bị chưa kích hoạt."), OX_NS("设备尚未激活。"), OX_NS("อุปกรณ์ยังไม่ได้เปิดใช้งาน"), OX_NS("Il dispositivo non è attivato."), OX_NS("Device is not activated."));
}

static NSString *Zx8fInvalidText(void) {
    return Zx8fPickText(OX_NS("Bản dylib không hợp lệ hoặc đã bị sửa"), OX_NS("Dylib 无效或已被修改"), OX_NS("dylib ไม่ถูกต้องหรือถูกแก้ไข"), OX_NS("Il dylib non è valido o è stato modificato"), OX_NS("The dylib is invalid or has been modified"));
}

static NSString *Zx8fNotReadyText(void) {
    return Zx8fPickText(OX_NS("Kết nối xác thực chưa sẵn sàng, vui lòng thử lại"), OX_NS("验证连接尚未就绪，请重试"), OX_NS("การเชื่อมต่อยืนยันยังไม่พร้อม โปรดลองอีกครั้ง"), OX_NS("La connessione di verifica non è pronta, riprova"), OX_NS("Verification connection is not ready, please try again"));
}

static NSString *Zx8fRecoveryNoteText(void) {
    return Zx8fPickText(
        OX_NS("Nếu đã mua VIP hay đổi ESIGN hiện bảng kích hoạt thì bấm KHÔI PHỤC MÃ KÍCH HOẠT (làm giống lúc cài ESIGN)."),
        OX_NS("如果已购买 VIP，或更换 ESIGN 后出现激活界面，请点击“恢复激活码”（操作方式与安装 ESIGN 时相同）。"),
        OX_NS("หากซื้อ VIP แล้ว หรือเปลี่ยน ESIGN แล้วหน้าต่างเปิดใช้งานปรากฏขึ้น ให้กด “กู้คืนรหัสเปิดใช้งาน” (ทำเหมือนตอนติดตั้ง ESIGN)"),
        OX_NS("Se hai già acquistato VIP o hai cambiato ESIGN e compare la schermata di attivazione, premi “RIPRISTINA CODICE DI ATTIVAZIONE” (come durante l’installazione di ESIGN)."),
        OX_NS("If you already purchased VIP, or changed ESIGN and this activation screen appears, tap RESTORE ACTIVATION CODE (same steps as when installing ESIGN).")
    );
}

static NSString *Zx8fLocalizedOverlayStatus(NSString *message) {
    if ([message isEqualToString:kChecking()]) return Zx8fCheckingText();
    if ([message isEqualToString:kCopied()]) return Zx8fCopiedText();
    if ([message isEqualToString:kInactive()]) return Zx8fInactiveText();
    if ([message isEqualToString:kInvalid()]) return Zx8fInvalidText();
    if ([message isEqualToString:kNotReady()]) return Zx8fNotReadyText();
    return message ?: OX_NS("");
}

static void Zx8fShowOverlay(NSString *message) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *host = Zx8fHostWindow();
        if (!host) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.7 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ Zx8fShowOverlay(message); });
            return;
        }
        if (!g_zx8fTarget) g_zx8fTarget = [Q9c2A new];
        NSString *deviceText = [NSString stringWithFormat:Zx8fDeviceFormatText(), Zx8fDeviceId()];
        if (g_zx8fOverlayVisible && g_zx8fOverlay) {
            g_zx8fStatus.text = Zx8fLocalizedOverlayStatus(message ?: @"");
            g_zx8fDeviceLabel.text = deviceText;
            return;
        }
        g_zx8fOverlayVisible = YES;
        CGRect bounds = host.bounds;
        UIView *root = [[UIView alloc] initWithFrame:bounds];
        root.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        root.backgroundColor = [UIColor colorWithWhite:0 alpha:0.50];
        root.userInteractionEnabled = YES;
        root.tag = 880055;

        CGFloat width = MIN(bounds.size.width - 42, (CGFloat)370);
        CGFloat height = 452;
        UIView *card = [[UIView alloc] initWithFrame:CGRectMake((bounds.size.width - width)/2, (bounds.size.height - height)/2, width, height)];
        card.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
        card.backgroundColor = [UIColor colorWithWhite:0.025 alpha:0.96];
        card.layer.cornerRadius = 18.0;
        card.layer.borderWidth = 1.6;
        card.layer.borderColor = [UIColor colorWithRed:0.18 green:0.85 blue:1.0 alpha:1.0].CGColor;
        card.layer.shadowColor = [UIColor colorWithRed:0.18 green:0.85 blue:1.0 alpha:1.0].CGColor;
        card.layer.shadowOpacity = 0.82;
        card.layer.shadowRadius = 18.0;
        card.layer.shadowOffset = CGSizeZero;
        [root addSubview:card];

        UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(18, 20, width-36, 32)];
        title.text = Zx8fOverlayTitleText();
        title.textColor = [UIColor colorWithRed:1.0 green:0.50 blue:0.10 alpha:1.0];
        title.textAlignment = NSTextAlignmentCenter;
        title.font = [UIFont systemFontOfSize:24 weight:UIFontWeightHeavy];
        [card addSubview:title];

        UILabel *status = [[UILabel alloc] initWithFrame:CGRectMake(18, 62, width-36, 64)];
        status.text = Zx8fLocalizedOverlayStatus(message ?: kChecking());
        status.textColor = [UIColor colorWithRed:1.0 green:0.28 blue:0.22 alpha:1.0];
        status.textAlignment = NSTextAlignmentCenter;
        status.font = [UIFont systemFontOfSize:15.5 weight:UIFontWeightBold];
        status.numberOfLines = 3;
        [card addSubview:status];
        g_zx8fStatus = status;

        UILabel *device = [[UILabel alloc] initWithFrame:CGRectMake(18, 134, width-36, 58)];
        device.text = deviceText;
        device.textColor = [UIColor colorWithRed:0.58 green:0.96 blue:1.0 alpha:1.0];
        device.textAlignment = NSTextAlignmentCenter;
        device.font = [UIFont monospacedDigitSystemFontOfSize:16 weight:UIFontWeightHeavy];
        device.numberOfLines = 2;
        [card addSubview:device];
        g_zx8fDeviceLabel = device;

        UILabel *recoveryNote = [[UILabel alloc] initWithFrame:CGRectMake(20, 194, width-40, 58)];
        recoveryNote.text = Zx8fRecoveryNoteText();
        recoveryNote.textColor = [UIColor colorWithRed:1.0 green:0.84 blue:0.42 alpha:1.0];
        recoveryNote.textAlignment = NSTextAlignmentCenter;
        recoveryNote.font = [UIFont systemFontOfSize:12.2 weight:UIFontWeightSemibold];
        recoveryNote.numberOfLines = 4;
        recoveryNote.adjustsFontSizeToFitWidth = YES;
        recoveryNote.minimumScaleFactor = 0.78;
        [card addSubview:recoveryNote];

        UIButton *b1 = Zx8fButton(Zx8fCopyText(), @selector(p4m8a));
        b1.frame = CGRectMake(22, 258, width-44, 38);
        [card addSubview:b1];
        UIButton *bRestore = Zx8fButton(Zx8fRestoreActivationText(), @selector(u5e1r));
        bRestore.frame = CGRectMake(22, 303, width-44, 38);
        [card addSubview:bRestore];
        UIButton *b2 = Zx8fButton(Zx8fSendText(), @selector(t7v2c));
        b2.frame = CGRectMake(22, 348, width-44, 38);
        [card addSubview:b2];
        UIButton *b3 = Zx8fButton(Zx8fCheckText(), @selector(k3d9x));
        b3.frame = CGRectMake(22, 393, width-44, 38);
        [card addSubview:b3];

        [host addSubview:root];
        g_zx8fOverlay = root;
    });
}

static NSString *Zx8fStringValue(id obj) {
    return [obj isKindOfClass:[NSString class]] ? (NSString *)obj : @"";
}

static NSDictionary *Zx8fSelectAnnouncementPack(NSDictionary *json) {
    NSString *source = Zx8fStringValue(json[kLicenseSource()]);
    id pack = nil;
    if ([source isEqualToString:kSrcFree()]) pack = json[kAnnFree()];
    else if ([source isEqualToString:kSrcVip()]) {
        id backup = json[OX_NS("announcement_vip_backup")];
        if ([backup isKindOfClass:[NSDictionary class]] && Zx8fBoolValue(((NSDictionary *)backup)[kAnnEnabled()], NO)) pack = backup;
        else pack = json[kAnnVip()];
    }
    if (![pack isKindOfClass:[NSDictionary class]]) pack = json[kAnnAll()];
    if (![pack isKindOfClass:[NSDictionary class]]) pack = json[kAnn()];
    return [pack isKindOfClass:[NSDictionary class]] ? (NSDictionary *)pack : nil;
}

static NSString *Zx8fAnnouncementLocalizedValue(NSDictionary *ann, NSString *plainKey, NSString *mapKey) {
    id map = ann[mapKey];
    if ([map isKindOfClass:[NSDictionary class]]) {
        NSString *code = Zx8fMenuLang();
        id value = ((NSDictionary *)map)[code];
        if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) return (NSString *)value;
        value = ((NSDictionary *)map)[OX_NS("en")];
        if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) return (NSString *)value;
        value = ((NSDictionary *)map)[OX_NS("vi")];
        if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) return (NSString *)value;
    }
    return Zx8fStringValue(ann[plainKey]);
}

static void Zx8fSaveAnnouncement(NSDictionary *json) {
    NSString *oldId = g_zx8fAnnId;
    g_zx8fAnnEnabled = NO;
    g_zx8fAnnForce = NO;
    g_zx8fAnnDelay = 39.0;
    g_zx8fAnnId = nil;
    g_zx8fAnnTitle = nil;
    g_zx8fAnnBody = nil;
    g_zx8fAnnLinkURL = nil;
    g_zx8fAnnLinkText = nil;
    NSDictionary *ann = Zx8fSelectAnnouncementPack(json);
    if (![ann isKindOfClass:[NSDictionary class]]) return;
    g_zx8fAnnEnabled = Zx8fBoolValue(ann[kAnnEnabled()], NO);
    if (!g_zx8fAnnEnabled) return;
    g_zx8fAnnId = Zx8fStringValue(ann[kAnnId()]);
    g_zx8fAnnTitle = Zx8fAnnouncementLocalizedValue(ann, kAnnTitle(), OX_NS("title_i18n"));
    g_zx8fAnnBody = Zx8fAnnouncementLocalizedValue(ann, kAnnBody(), OX_NS("body_i18n"));
    g_zx8fAnnLinkURL = Zx8fStringValue(ann[OX_NS("link_url")]);
    g_zx8fAnnLinkText = Zx8fAnnouncementLocalizedValue(ann, OX_NS("link_text"), OX_NS("link_text_i18n"));
    g_zx8fAnnForce = Zx8fBoolValue(ann[kAnnForce()], NO);
    NSInteger d = Zx8fIntValue(ann[kAnnDelay()], 39);
    if (d < 5) d = 5;
    if (d > 300) d = 300;
    g_zx8fAnnDelay = (NSTimeInterval)d;
    if (g_zx8fAnnId.length == 0) g_zx8fAnnId = [NSString stringWithFormat:OX_NS("%lld"), (long long)[NSDate date].timeIntervalSince1970];
    if (oldId.length > 0 && ![oldId isEqualToString:g_zx8fAnnId]) {
        g_zx8fAnnShownThisRun = NO;
        g_zx8fAnnRetry = 0;
    }
}

static BOOL Zx8fAnnouncementUIReady(void) {
    UIApplication *app = [UIApplication sharedApplication];
    if (app.applicationState != UIApplicationStateActive) return NO;
    if (g_zx8fOverlayVisible || g_zx8fOverlay != nil) return NO;
    if (g_zx8fAnnOverlay != nil) return NO;
    UIWindow *host = Zx8fHostWindow();
    if (!host || host.hidden || host.alpha < 0.01) return NO;
    if (!host.rootViewController) return NO;
    if (host.bounds.size.width < 80 || host.bounds.size.height < 120) return NO;
    return YES;
}

static void Zx8fShowAnnouncement(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!g_zx8fAnnEnabled || g_zx8fAnnBody.length == 0) return;
        if (g_zx8fAnnShownThisRun) return;
        if (!g_zx8fRuntimeReady && g_zx8fAnnRetry < 10) {
            Zx8fScheduleAnnouncement(g_zx8fAnnRetry + 1);
            return;
        }
        if (!Zx8fAnnouncementUIReady()) {
            if (g_zx8fAnnRetry < 12) Zx8fScheduleAnnouncement(g_zx8fAnnRetry + 1);
            return;
        }
        if (!g_zx8fAnnForce) {
            NSString *read = [[NSUserDefaults standardUserDefaults] stringForKey:kAnnReadKey()];
            if ([read isKindOfClass:[NSString class]] && [read isEqualToString:g_zx8fAnnId]) return;
        }
        UIWindow *host = Zx8fHostWindow();
        if (!host) return;
        if (!g_zx8fTarget) g_zx8fTarget = [Q9c2A new];
        g_zx8fAnnShownThisRun = YES;
        CGRect bounds = host.bounds;
        UIView *root = [[UIView alloc] initWithFrame:bounds];
        root.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        root.backgroundColor = [UIColor colorWithWhite:0 alpha:0.18];
        root.userInteractionEnabled = YES;
        CGFloat width = MAX(180.0, MIN(bounds.size.width - 48.0, (CGFloat)340.0));
        NSString *heading = g_zx8fAnnTitle.length ? g_zx8fAnnTitle : kAnnDefaultTitle();
        UIFont *headingFont = [UIFont systemFontOfSize:18 weight:UIFontWeightHeavy];
        UIFont *bodyFont = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
        NSString *linkRaw = [g_zx8fAnnLinkURL stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSURL *linkURL = linkRaw.length ? [NSURL URLWithString:linkRaw] : nil;
        NSString *linkScheme = linkURL.scheme.lowercaseString;
        BOOL hasCTA = linkURL && ([linkScheme isEqualToString:@"https"] || [linkScheme isEqualToString:@"http"]);
        CGFloat headingHeight = ceil([heading boundingRectWithSize:CGSizeMake(width-36.0, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:headingFont} context:nil].size.height);
        headingHeight = MAX(28.0, headingHeight);
        CGFloat bodyHeight = ceil([(g_zx8fAnnBody ?: @"") boundingRectWithSize:CGSizeMake(width-40.0, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:bodyFont} context:nil].size.height) + 12.0;
        bodyHeight = MAX(28.0, bodyHeight);
        CGFloat bodyTop = 16.0 + headingHeight + 12.0;
        CGFloat buttonArea = hasCTA ? 100.0 : 58.0;
        CGFloat maximumHeight = MAX(150.0, bounds.size.height - host.safeAreaInsets.top - host.safeAreaInsets.bottom - 32.0);
        CGFloat height = MIN(maximumHeight, bodyTop + bodyHeight + buttonArea);
        CGFloat visibleBodyHeight = MAX(24.0, height-bodyTop-buttonArea);
        UIView *card = [[UIView alloc] initWithFrame:CGRectMake((bounds.size.width-width)*0.5, (bounds.size.height-height)*0.5, width, height)];
        card.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
        card.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.82];
        card.layer.cornerRadius = 16;
        card.layer.borderWidth = 1.1;
        card.layer.borderColor = [UIColor colorWithRed:1.0 green:0.45 blue:0.06 alpha:0.85].CGColor;
        [root addSubview:card];
        UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(18, 16, width-36, headingHeight)];
        title.text = heading;
        title.numberOfLines = 0;
        title.textColor = [UIColor colorWithRed:1.0 green:0.50 blue:0.10 alpha:1.0];
        title.textAlignment = NSTextAlignmentCenter;
        title.font = headingFont;
        [card addSubview:title];
        UITextView *body = [[UITextView alloc] initWithFrame:CGRectMake(20, bodyTop, width-40, visibleBodyHeight)];
        body.text = g_zx8fAnnBody ?: @"";
        body.textColor = [UIColor colorWithRed:1.0 green:0.58 blue:0.16 alpha:1.0];
        body.textAlignment = NSTextAlignmentCenter;
        body.font = bodyFont;
        body.backgroundColor = UIColor.clearColor;
        body.editable = NO;
        body.selectable = YES;
        body.scrollEnabled = bodyHeight > visibleBodyHeight;
        body.showsVerticalScrollIndicator = body.scrollEnabled;
        body.dataDetectorTypes = UIDataDetectorTypeLink;
        body.textContainerInset = UIEdgeInsetsMake(4, 0, 4, 0);
        body.textContainer.lineFragmentPadding = 0;
        body.linkTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor colorWithRed:1.0 green:0.50 blue:0.08 alpha:1.0],
            NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)
        };
        [card addSubview:body];
        if (hasCTA) {
            NSString *ctaTitle = g_zx8fAnnLinkText.length ? g_zx8fAnnLinkText : OX_NS("BẤM VÀO ĐÂY");
            UIButton *cta = Zx8fButton(ctaTitle, @selector(v8q2l));
            cta.frame = CGRectMake(28, height-92, width-56, 36);
            cta.backgroundColor = [UIColor colorWithRed:0.95 green:0.34 blue:0.03 alpha:1.0];
            [cta setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
            cta.layer.cornerRadius = 10;
            cta.layer.borderWidth = 1.2;
            cta.layer.borderColor = [UIColor colorWithRed:1.0 green:0.55 blue:0.10 alpha:1.0].CGColor;
            [card addSubview:cta];
        }
        UIButton *ok = Zx8fButton(Zx8fAnnAckText(), @selector(w6n1b));
        [ok setTitleColor:[UIColor colorWithRed:1.0 green:0.58 blue:0.16 alpha:1.0] forState:UIControlStateNormal];
        ok.layer.borderColor = [UIColor colorWithRed:1.0 green:0.50 blue:0.10 alpha:0.92].CGColor;
        ok.frame = CGRectMake(28, height-50, width-56, 36);
        [card addSubview:ok];
        [host addSubview:root];
        g_zx8fAnnOverlay = root;
    });
}

static void Zx8fScheduleAnnouncement(NSUInteger attempt) {
    if (!g_zx8fAnnEnabled) return;
    g_zx8fAnnRetry = attempt;
    NSTimeInterval delay = (attempt == 0) ? g_zx8fAnnDelay : 5.0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        Zx8fShowAnnouncement();
    });
}

static void Zx8fShowMenuLockedToast(NSInteger days) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        Zx8fShowRemainingToast(days);
        UIWindow *host = Zx8fHostWindow();
        if (!host) return;
        UILabel *notice = [[UILabel alloc] initWithFrame:CGRectZero];
        notice.text = kMenuLockedText();
        notice.textColor = [UIColor whiteColor];
        notice.textAlignment = NSTextAlignmentCenter;
        notice.font = [UIFont boldSystemFontOfSize:14];
        notice.backgroundColor = [UIColor colorWithRed:0.65 green:0.06 blue:0.06 alpha:0.82];
        notice.layer.cornerRadius = 13;
        notice.layer.masksToBounds = YES;
        CGFloat w = MIN(host.bounds.size.width - 40, (CGFloat)300);
        notice.frame = CGRectMake((host.bounds.size.width - w)/2, 116, w, 42);
        notice.alpha = 0;
        [host addSubview:notice];
        [UIView animateWithDuration:0.2 animations:^{ notice.alpha = 1; } completion:^(__unused BOOL finished) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [UIView animateWithDuration:0.2 animations:^{ notice.alpha = 0; } completion:^(__unused BOOL done) { [notice removeFromSuperview]; }];
            });
        }];
    });
}

static void Zx8fClearSession(void) {
    g_zx8fLastSigned = NO;
    g_zx8fActivatedLicense.store(false, std::memory_order_release);
    Zx8fClearExpeditionProof();
    g_zx8fSessionToken = nil;
    g_zx8fSessionExpire = 0;
    g_zx8fLastAuthOKTime = 0;
    g_zx8fSoftFailCount = 0;
    g_zx8fNegativeLicenseCount = 0;
    g_zx8fNegativeLicenseTime = 0;
    g_zx8fResumeGraceUntil = 0;
    g_zx8fRefreshSeed++;
    g_zx8fModuleMask.store(0, std::memory_order_relaxed);
}

static BOOL Zx8fUpdateSessionFromJSON(NSDictionary *json) {
    NSString *token = Zx8fStr(json[kToken()]);
    NSTimeInterval exp = (NSTimeInterval)Zx8fStr(json[OX_NS("session_expires_at")]).longLongValue;
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    if (token.length < 32 || exp <= now + 30.0) return NO;
    g_zx8fSessionToken = [token copy];
    g_zx8fSessionExpire = exp;
    g_zx8fLastSigned = YES;
    NSTimeInterval delay = MAX(15.0, MIN(600.0, exp - now - 45.0));
    Zx8fScheduleRefresh(delay);
    return YES;
}

static BOOL Zx8fSessionAlive(void) {
    if (!g_zx8fLastSigned) return NO;
    if (g_zx8fSessionToken.length < 32) return NO;
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    if (g_zx8fSessionExpire > now) return YES;
    if (!g_zx8fAllowed || g_zx8fMenuLocked || g_zx8fLastAuthOKTime <= 0) return NO;
    if (g_zx8fResumeGraceUntil > now) return YES;
    return (now - g_zx8fLastAuthOKTime) <= ZX8F_SOFT_AUTH_GRACE;
}

static BOOL Zx8fBoolForModuleKeys(NSDictionary *mods, NSArray<NSString *> *keys) {
    if (![mods isKindOfClass:[NSDictionary class]]) return NO;
    for (NSString *key in keys) {
        id v = mods[key];
        if (v != nil) return Zx8fBoolValue(v, NO);
    }
    return NO;
}

static BOOL Zx8fModuleValue(NSDictionary *mods,
                            NSArray<NSString *> *keys,
                            BOOL *present) {
    if (present) *present = NO;
    if (![mods isKindOfClass:[NSDictionary class]]) return NO;
    for (NSString *key in keys) {
        id v = mods[key];
        if (v != nil) {
            if (present) *present = YES;
            return Zx8fBoolValue(v, NO);
        }
    }
    return NO;
}

static unsigned int Zx8fModulesFromJSON(NSDictionary *json,
                                        BOOL active,
                                        BOOL activatedLicense) {
    if (!active) return 0;
    id raw = json[kModules()];
    if (![raw isKindOfClass:[NSDictionary class]]) return 0;
    NSDictionary *mods = (NSDictionary *)raw;
    unsigned int m = 0;
    if (Zx8fBoolValue(mods[kModuleMenu()], NO)) m |= ZX8F_M_MENU;
    if (Zx8fBoolValue(mods[kModuleSpeed()], NO)) m |= ZX8F_M_SPEED;
    if (Zx8fBoolValue(mods[kModuleCounter()], NO)) m |= ZX8F_M_COUNTER;
    if (Zx8fBoolValue(mods[kModulePotion()], NO)) m |= ZX8F_M_POTION;
    if (Zx8fBoolValue(mods[kModuleToken()], NO)) m |= ZX8F_M_TOKEN;
    BOOL lightningPresent = NO;
    BOOL lightningEnabled = Zx8fModuleValue(
        mods,
        @[kModuleLightning(),
          OX_NS("lightning_counter"),
          OX_NS("tia_set"),
          OX_NS("thunder")],
        &lightningPresent);
    if (!lightningPresent) {
        lightningEnabled = (m & ZX8F_M_COUNTER) != 0;
    }
    if (lightningEnabled) m |= ZX8F_M_LIGHTNING;
    if (Zx8fBoolValue(mods[kModuleBetCycle()], YES)) m |= ZX8F_M_BET_CYCLE;
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("auto_build"), OX_NS("autobuild"), OX_NS("build_auto"), OX_NS("build")])) m |= ZX8F_M_AUTO_BUILD;
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("magic_cards"), OX_NS("open_cards"), OX_NS("quick_cards"), OX_NS("cards_quick"), OX_NS("cards")])) m |= ZX8F_M_MAGIC_CARDS;
    BOOL expeditionPresent = NO;
    BOOL expeditionEnabled = Zx8fModuleValue(
        mods,
        @[OX_NS("auto_expedition"),
          OX_NS("expedition_auto"),
          OX_NS("auto_hoang_dia"),
          OX_NS("expedition")],
        &expeditionPresent);
    BOOL expeditionAllowed =
        activatedLicense
            ? (!expeditionPresent ||
               expeditionEnabled)
            : (expeditionPresent &&
               expeditionEnabled);
    if (expeditionAllowed) {
        m |= ZX8F_M_EXPEDITION;
    }
    if (Zx8fBoolForModuleKeys(
            mods,
            @[OX_NS("auto_merge"),
              OX_NS("merge_auto"),
              OX_NS("auto_hop_nhat")])) {
        m |= ZX8F_M_AUTO_MERGE;
    }
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("auto_click"), OX_NS("autoclick")])) m |= ZX8F_M_AUTO_CLICK;
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("raid_hammer"), OX_NS("auto_pig_hammer"), OX_NS("pig_hammer")])) m |= ZX8F_M_RAID_HAMMER;
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("tools"), OX_NS("tool_panel")])) m |= ZX8F_M_TOOLS;
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("auto_stop"), OX_NS("auto_target")])) m |= ZX8F_M_AUTO_STOP;
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("menu_color"), OX_NS("theme")])) m |= ZX8F_M_MENU_COLOR;
    if (Zx8fBoolForModuleKeys(mods, @[OX_NS("friend_invite"), OX_NS("invite_friend")])) m |= ZX8F_M_FRIEND_INVITE;

    m &= ZX8F_M_ALL;
    if ((m & ZX8F_M_MENU) == 0) return 0;
    if ((m & ZX8F_M_COUNTER) == 0) m &= ~(ZX8F_M_POTION | ZX8F_M_TOKEN | ZX8F_M_LIGHTNING);
    return m;
}


static NSDictionary *Zx8fUpdateDictFromJSON(NSDictionary *json) {
    if (![json isKindOfClass:[NSDictionary class]]) return nil;
    id u = json[OX_NS("update")];
    if (![u isKindOfClass:[NSDictionary class]]) u = json[OX_NS("app_update")];
    if (![u isKindOfClass:[NSDictionary class]]) u = json[OX_NS("ios_update")];
    return [u isKindOfClass:[NSDictionary class]] ? (NSDictionary *)u : nil;
}

static NSInteger Zx8fCurrentUpdateBuild(void) {
    NSString *build = kBuild() ?: @"";
    NSInteger lastValue = 0;
    BOOL inDigits = NO;
    NSInteger current = 0;
    for (NSUInteger i = 0; i < build.length; i++) {
        unichar c = [build characterAtIndex:i];
        if (c >= '0' && c <= '9') {
            inDigits = YES;
            current = current * 10 + (NSInteger)(c - '0');
        } else {
            if (inDigits) lastValue = current;
            inDigits = NO;
            current = 0;
        }
    }
    if (inDigits) lastValue = current;
    return lastValue;
}

static NSString *Zx8fUpdateString(NSDictionary *u, NSArray<NSString *> *keys, NSString *fallback) {
    if (![u isKindOfClass:[NSDictionary class]]) return fallback ?: @"";
    for (NSString *k in keys) {
        id v = u[k];
        if ([v isKindOfClass:[NSString class]] && ((NSString *)v).length > 0) return (NSString *)v;
        if ([v respondsToSelector:@selector(stringValue)]) {
            NSString *s = [v stringValue];
            if (s.length > 0) return s;
        }
    }
    return fallback ?: @"";
}

static NSInteger Zx8fUpdateInt(NSDictionary *u, NSArray<NSString *> *keys, NSInteger fallback) {
    if (![u isKindOfClass:[NSDictionary class]]) return fallback;
    for (NSString *k in keys) {
        id v = u[k];
        if (v != nil) return Zx8fIntValue(v, fallback);
    }
    return fallback;
}

static BOOL Zx8fUpdateBool(NSDictionary *u, NSArray<NSString *> *keys, BOOL fallback) {
    if (![u isKindOfClass:[NSDictionary class]]) return fallback;
    for (NSString *k in keys) {
        id v = u[k];
        if (v != nil) return Zx8fBoolValue(v, fallback);
    }
    return fallback;
}

static UIViewController *Zx8fTopViewController(void) {
    UIWindow *w = UIApplication.sharedApplication.keyWindow;
    if (!w) {
        for (UIWindow *x in UIApplication.sharedApplication.windows) {
            if (!x.hidden && x.windowLevel == UIWindowLevelNormal) { w = x; break; }
        }
    }
    UIViewController *vc = w.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    return vc;
}

static void Zx8fOpenUpdateURL(NSString *urlString) {
    if (![urlString isKindOfClass:[NSString class]] || urlString.length == 0) return;
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIApplication *app = UIApplication.sharedApplication;
        if ([app respondsToSelector:@selector(openURL:options:completionHandler:)]) {
            [app openURL:url options:@{} completionHandler:nil];
        } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
            [app openURL:url];
#pragma clang diagnostic pop
        }
    });
}

static NSString *Zx8fUpdateLocalizedValue(NSDictionary *u, NSString *plainKey, NSString *mapKey, NSString *fallback) {
    id map = u[mapKey];
    if ([map isKindOfClass:[NSDictionary class]]) {
        NSString *code = Zx8fMenuLang();
        id value = ((NSDictionary *)map)[code];
        if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) return (NSString *)value;
        value = ((NSDictionary *)map)[OX_NS("en")];
        if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) return (NSString *)value;
        value = ((NSDictionary *)map)[OX_NS("vi")];
        if ([value isKindOfClass:[NSString class]] && ((NSString *)value).length > 0) return (NSString *)value;
    }
    NSString *plain = Zx8fUpdateString(u, @[plainKey], @"");
    if ([Zx8fMenuLang() isEqualToString:OX_NS("vi")] && plain.length > 0) return plain;
    return fallback ?: plain;
}

static NSString *Zx8fUpdateTitleText(BOOL force) {
    return force ? Zx8fMenuPickText(OX_NS("BẮT BUỘC CẬP NHẬT"), OX_NS("必须更新"), OX_NS("ต้องอัปเดต"), OX_NS("AGGIORNAMENTO OBBLIGATORIO"), OX_NS("UPDATE REQUIRED")) : Zx8fMenuPickText(OX_NS("CÓ BẢN CẬP NHẬT MỚI"), OX_NS("有新版本"), OX_NS("มีอัปเดตใหม่"), OX_NS("NUOVO AGGIORNAMENTO"), OX_NS("NEW UPDATE AVAILABLE"));
}

static NSString *Zx8fUpdateMessageText(BOOL force) {
    return force ? Zx8fMenuPickText(OX_NS("Vui lòng cập nhật bản mới để tiếp tục sử dụng."), OX_NS("请更新到最新版本后继续使用。"), OX_NS("โปรดอัปเดตเป็นเวอร์ชันล่าสุดเพื่อใช้งานต่อ"), OX_NS("Aggiorna all'ultima versione per continuare a utilizzare l'app."), OX_NS("Please update to the latest version to continue.")) : Zx8fMenuPickText(OX_NS("Đã có bản mới, cập nhật để dùng ổn định hơn."), OX_NS("已有新版本，更新后可获得更稳定的体验。"), OX_NS("มีเวอร์ชันใหม่ อัปเดตเพื่อการใช้งานที่เสถียรขึ้น"), OX_NS("È disponibile una nuova versione. Aggiorna per una maggiore stabilità."), OX_NS("A new version is available. Update for better stability."));
}

static NSString *Zx8fUpdateVersionLabel(void) {
    return Zx8fMenuPickText(OX_NS("Phiên bản mới"), OX_NS("新版本"), OX_NS("เวอร์ชันใหม่"), OX_NS("Nuova versione"), OX_NS("New version"));
}

static NSString *Zx8fUpdateBuildLabel(void) {
    return Zx8fMenuPickText(OX_NS("Build mới"), OX_NS("新 Build"), OX_NS("Build ใหม่"), OX_NS("Nuova build"), OX_NS("New build"));
}

static NSString *Zx8fUpdateNowText(BOOL force) {
    return force ? Zx8fMenuPickText(OX_NS("Cập nhật"), OX_NS("更新"), OX_NS("อัปเดต"), OX_NS("AGGIORNA"), OX_NS("UPDATE")) : Zx8fMenuPickText(OX_NS("Cập nhật ngay"), OX_NS("立即更新"), OX_NS("อัปเดตตอนนี้"), OX_NS("AGGIORNA ORA"), OX_NS("UPDATE NOW"));
}

static NSString *Zx8fUpdateLaterText(void) {
    return Zx8fMenuPickText(OX_NS("Để sau"), OX_NS("稍后"), OX_NS("ภายหลัง"), OX_NS("PIÙ TARDI"), OX_NS("LATER"));
}

static void Zx8fShowUpdateAlert(NSDictionary *u, BOOL force) {
    if (![u isKindOfClass:[NSDictionary class]]) return;
    NSInteger latest = Zx8fUpdateInt(u, @[OX_NS("latest_build"), OX_NS("build"), OX_NS("build_code")], 0);
    NSString *latestId = Zx8fUpdateString(u, @[OX_NS("latest_build_id")], @"");
    NSString *version = Zx8fUpdateString(u, @[OX_NS("version_name"), OX_NS("version")], @"");
    NSString *url = Zx8fUpdateString(u, @[OX_NS("download_url"), OX_NS("url"), OX_NS("link")], @"");
    NSString *title = Zx8fUpdateLocalizedValue(u, OX_NS("title"), OX_NS("title_i18n"), Zx8fUpdateTitleText(force));
    NSString *message = Zx8fUpdateLocalizedValue(u, OX_NS("message"), OX_NS("message_i18n"), Zx8fUpdateMessageText(force));
    NSString *uid = Zx8fUpdateString(u, @[OX_NS("id")], [NSString stringWithFormat:OX_NS("ios_%ld_%@"), (long)latest, version ?: @""]);
    if ([g_zx8fUpdateShownId isEqualToString:uid] && !force) return;

    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *vc = Zx8fTopViewController();
        if (!vc) return;
        if ([g_zx8fUpdateShownId isEqualToString:uid] && !force) return;
        g_zx8fUpdateShownId = uid;
        NSMutableString *body = [NSMutableString string];
        if (version.length > 0) [body appendFormat:OX_NS("%@: %@\n"), Zx8fUpdateVersionLabel(), version];
        if (latestId.length > 0) [body appendFormat:OX_NS("%@: %@\n"), Zx8fUpdateBuildLabel(), latestId];
        else if (latest > 0) [body appendFormat:OX_NS("%@: %ld\n"), Zx8fUpdateBuildLabel(), (long)latest];
        if (body.length > 0) [body appendString:OX_NS("\n")];
        [body appendString:message ?: @""];
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:body preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:Zx8fUpdateNowText(force) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            Zx8fOpenUpdateURL(url);
            if (force) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    Zx8fShowUpdateAlert(u, YES);
                });
            }
        }]];
        if (!force) {
            [alert addAction:[UIAlertAction actionWithTitle:Zx8fUpdateLaterText() style:UIAlertActionStyleCancel handler:nil]];
        }
        alert.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [vc presentViewController:alert animated:YES completion:nil];
    });
}

static BOOL Zx8fHandleUpdateFromJSON(NSDictionary *json, BOOL activeSessionOK) {
    NSDictionary *u = Zx8fUpdateDictFromJSON(json);
    if (![u isKindOfClass:[NSDictionary class]]) return NO;
    NSString *serverUpdateURL = Zx8fUpdateString(u, @[OX_NS("download_url"), OX_NS("url"), OX_NS("link")], @"");
    if (serverUpdateURL.length > 0) g_zx8fUpdateURL = [serverUpdateURL copy];
    BOOL enabled = Zx8fUpdateBool(u, @[OX_NS("enable_update_popup"), OX_NS("enable"), OX_NS("enabled")], NO);
    if (!enabled) return NO;
    NSString *latestId = Zx8fUpdateString(u, @[OX_NS("latest_build_id")], @"");
    if (latestId.length > 0) {
        if ([latestId isEqualToString:(kBuild() ?: @"")]) return NO;
    } else {
        NSInteger latest = Zx8fUpdateInt(u, @[OX_NS("latest_build"), OX_NS("build"), OX_NS("build_code")], 0);
        NSInteger current = Zx8fCurrentUpdateBuild();
        if (latest <= current) return NO;
    }
    BOOL force = Zx8fUpdateBool(u, @[OX_NS("force_update"), OX_NS("force"), OX_NS("required")], NO);
    Zx8fShowUpdateAlert(u, force);
    if (force && activeSessionOK) {
        g_zx8fUpdateForcedLock = YES;
        g_zx8fMenuLocked = YES;
        g_zx8fAllowed = NO;
        g_zx8fModuleMask.store(0, std::memory_order_relaxed);
        Zx8fClearSession();
        return YES;
    }
    return NO;
}

static NSString *Zx8fServerErrorCode(NSDictionary *json) {
    id value = json[kError()];
    if (![value isKindOfClass:[NSString class]]) return @"";
    return [(NSString *)value uppercaseString];
}

static BOOL Zx8fTransientServerError(NSDictionary *json) {
    NSString *code = Zx8fServerErrorCode(json);
    if (code.length == 0) return NO;
    static NSSet<NSString *> *codes;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        codes = [NSSet setWithArray:@[
            OX_NS("RATE_LIMIT"),
            OX_NS("TOO_MANY_REQUESTS"),
            OX_NS("SERVER_BUSY"),
            OX_NS("TEMPORARY"),
            OX_NS("TEMPORARY_ERROR"),
            OX_NS("TRY_LATER")
        ]];
    });
    return [codes containsObject:code];
}

static NSTimeInterval Zx8fTransientRetryDelay(NSDictionary *json) {
    NSString *code = Zx8fServerErrorCode(json);
    if ([code isEqualToString:OX_NS("RATE_LIMIT")] ||
        [code isEqualToString:OX_NS("TOO_MANY_REQUESTS")]) {
        return 100.0 + (NSTimeInterval)arc4random_uniform(41);
    }
    return ZX8F_SOFT_RETRY_DELAY;
}

static BOOL Zx8fDefinitiveServerError(NSDictionary *json) {
    NSString *code = Zx8fServerErrorCode(json);
    if (code.length > 0) {
        static NSArray<NSString *> *hardTokens;
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            hardTokens = @[
                OX_NS("NOT_ACTIVE"),
                OX_NS("INACTIVE"),
                OX_NS("CHUA_KICH"),
                OX_NS("EXPIRE"),
                OX_NS("REVOK"),
                OX_NS("BLOCK"),
                OX_NS("BANN"),
                OX_NS("SUSPEND"),
                OX_NS("FORBID"),
                OX_NS("DENIED"),
                OX_NS("INVALID"),
                OX_NS("BAD_BUILD"),
                OX_NS("TAMPER"),
                OX_NS("HASH_MISMATCH"),
                OX_NS("DEVICE_MISMATCH"),
                OX_NS("UDID_MISMATCH")
            ];
        });
        for (NSString *token in hardTokens) {
            if ([code rangeOfString:token options:NSCaseInsensitiveSearch].location != NSNotFound) return YES;
        }
        return NO;
    }
    NSString *raw = Zx8fStringValue(json[kMessage()]);
    if (raw.length == 0) return NO;
    return [raw rangeOfString:zxv_g02() options:NSCaseInsensitiveSearch].location != NSNotFound ||
           [raw rangeOfString:zxv_g03() options:NSCaseInsensitiveSearch].location != NSNotFound ||
           [raw rangeOfString:zxv_g04() options:NSCaseInsensitiveSearch].location != NSNotFound ||
           [raw rangeOfString:zxv_g00() options:NSCaseInsensitiveSearch].location != NSNotFound ||
           [raw rangeOfString:zxv_g01() options:NSCaseInsensitiveSearch].location != NSNotFound;
}

static BOOL Zx8fHasModule(unsigned int m, BOOL needSession) {
    if (m == 0 || (m & ~ZX8F_M_ALL) != 0) return NO;
    if (!g_zx8fAllowed || g_zx8fMenuLocked) return NO;
    unsigned int mask = g_zx8fModuleMask.load(std::memory_order_acquire);
    if ((mask & m) != m) return NO;
    if (needSession && !Zx8fSessionAlive()) return NO;
    return YES;
}

static NSString *Zx8fBrandProfileCacheKey(void) {
    return OX_NS("ongnong_brand_profile_code_v1");
}

static NSString *Zx8fCleanBrandProfileCode(NSString *raw) {
    if (![raw isKindOfClass:[NSString class]]) return OX_NS("");
    NSString *trim = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trim.length == 0) return OX_NS("");
    NSMutableString *out = [NSMutableString stringWithCapacity:MIN((NSUInteger)32, trim.length)];
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:OX_NS("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-.")];
    for (NSUInteger i = 0; i < trim.length && out.length < 32; i++) {
        unichar c = [trim characterAtIndex:i];
        if ([allowed characterIsMember:c]) [out appendFormat:OX_NS("%C"), c];
    }
    return [out lowercaseString];
}

NSString *Zx8fBrandProfileCode(void) {
    id raw = [[NSUserDefaults standardUserDefaults] objectForKey:Zx8fBrandProfileCacheKey()];
    return Zx8fCleanBrandProfileCode([raw isKindOfClass:[NSString class]] ? raw : OX_NS(""));
}

void Zx8fSetBrandProfileCode(NSString *code) {
    NSString *clean = Zx8fCleanBrandProfileCode(code);
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if (clean.length > 0) [ud setObject:clean forKey:Zx8fBrandProfileCacheKey()];
    else [ud removeObjectForKey:Zx8fBrandProfileCacheKey()];
    [ud removeObjectForKey:OX_NS("ongnong_server_ui_labels_v1")];
    [ud synchronize];
    g_zx8fUILabelsLoaded = YES;
    g_zx8fUILabels = @{};
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_menu_labels_changed") object:nil];
    Zx8fRefreshNow();
}

static NSString *Zx8fUILabelsCacheKey(void);
static NSString *Zx8fFPSVisibleKey(void);
static NSString *Zx8fFPSPendingKey(void);

static NSString *Zx8fCustomUIPendingTargetKey(void) {
    return OX_NS("ongnong_custom_ui_pending_target_v3");
}

static NSString *Zx8fCustomUINameCacheKeyForTarget(NSString *target) {
    NSString *t = [target isKindOfClass:[NSString class]] ? target : OX_NS("");
    if ([t isEqualToString:OX_NS("counter_title")]) return OX_NS("ongnong_custom_ui_counter_v2");
    if ([t isEqualToString:OX_NS("footer_name")]) return OX_NS("ongnong_custom_ui_footer_v2");
    return OX_NS("ongnong_custom_ui_main_v2");
}

static NSString *Zx8fCustomUIResetCacheKeyForTarget(NSString *target) {
    NSString *t = [target isKindOfClass:[NSString class]] ? target : OX_NS("");
    if ([t isEqualToString:OX_NS("counter_title")]) return OX_NS("ongnong_custom_ui_counter_reset_v2");
    if ([t isEqualToString:OX_NS("footer_name")]) return OX_NS("ongnong_custom_ui_footer_reset_v2");
    return OX_NS("ongnong_custom_ui_main_reset_v2");
}

static NSString *Zx8fCleanCustomUIName(NSString *raw) {
    if (![raw isKindOfClass:[NSString class]]) return OX_NS("");
    NSString *trim = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trim.length == 0) return OX_NS("");
    NSMutableString *out = [NSMutableString string];
    __block NSUInteger count = 0;
    [trim enumerateSubstringsInRange:NSMakeRange(0, trim.length)
                             options:NSStringEnumerationByComposedCharacterSequences
                          usingBlock:^(NSString *sub, NSRange r, NSRange er, BOOL *stop) {
        if (count >= 16) { *stop = YES; return; }
        unichar c = [sub characterAtIndex:0];
        if ([[NSCharacterSet controlCharacterSet] characterIsMember:c]) return;
        [out appendString:sub];
        count++;
    }];
    return [out stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

NSString *Zx8fCustomUINameForTarget(NSString *target) {
    id raw = [[NSUserDefaults standardUserDefaults] objectForKey:Zx8fCustomUINameCacheKeyForTarget(target)];
    return Zx8fCleanCustomUIName([raw isKindOfClass:[NSString class]] ? raw : OX_NS(""));
}

void Zx8fSetCustomUINameForTarget(NSString *target, NSString *name) {
    NSString *clean = Zx8fCleanCustomUIName(name);
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *nameKey = Zx8fCustomUINameCacheKeyForTarget(target);
    NSString *resetKey = Zx8fCustomUIResetCacheKeyForTarget(target);
    if (clean.length > 0) {
        [ud setObject:clean forKey:nameKey];
        [ud removeObjectForKey:resetKey];
    } else {
        [ud removeObjectForKey:nameKey];
        [ud setBool:YES forKey:resetKey];
    }
    [ud setObject:target ?: OX_NS("main_title") forKey:Zx8fCustomUIPendingTargetKey()];
    [ud removeObjectForKey:Zx8fUILabelsCacheKey()];
    [ud synchronize];
    g_zx8fUILabelsLoaded = YES;
    g_zx8fUILabels = @{};
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_menu_labels_changed") object:nil];
    Zx8fRefreshNow();
}

void Zx8fResetAllCustomUINames(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSArray *targets = @[OX_NS("main_title"), OX_NS("counter_title"), OX_NS("footer_name")];
    for (NSString *target in targets) {
        [ud removeObjectForKey:Zx8fCustomUINameCacheKeyForTarget(target)];
        [ud removeObjectForKey:Zx8fCustomUIResetCacheKeyForTarget(target)];
    }
    [ud setObject:OX_NS("__all__") forKey:Zx8fCustomUIPendingTargetKey()];
    [ud setBool:YES forKey:Zx8fFPSVisibleKey()];
    [ud setBool:YES forKey:Zx8fFPSPendingKey()];
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_fps_visibility_changed") object:nil];
    [ud removeObjectForKey:Zx8fUILabelsCacheKey()];
    [ud synchronize];
    g_zx8fUILabelsLoaded = YES;
    g_zx8fUILabels = @{};
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_menu_labels_changed") object:nil];
    Zx8fRefreshNow();
}

static NSString *Zx8fFPSVisibleKey(void) {
    return OX_NS("ongnong_fps_visible_v1");
}

static NSString *Zx8fFPSPendingKey(void) {
    return OX_NS("ongnong_fps_visible_pending_v1");
}

BOOL Zx8fFPSVisible(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if ([ud objectForKey:Zx8fFPSVisibleKey()] == nil) return YES;
    return [ud boolForKey:Zx8fFPSVisibleKey()];
}

void Zx8fSetFPSVisible(BOOL visible) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setBool:visible forKey:Zx8fFPSVisibleKey()];
    [ud setBool:YES forKey:Zx8fFPSPendingKey()];
    [ud synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_fps_visibility_changed") object:nil];
    Zx8fRefreshNow();
}

static NSString *Zx8fMenuPendingKey(void) { return OX_NS("ongnong_menu_pending_key_v1"); }
static NSString *Zx8fMenuPendingName(void) { return OX_NS("ongnong_menu_pending_name_v1"); }
static NSString *Zx8fMenuPendingReset(void) { return OX_NS("ongnong_menu_pending_reset_v1"); }
void Zx8fSetMenuName(NSString *key, NSString *name, BOOL reset) {
    if (key.length == 0 || !Zx8fAllowed()) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:key forKey:Zx8fMenuPendingKey()];
    [ud setObject:name ?: OX_NS("") forKey:Zx8fMenuPendingName()];
    [ud setBool:reset forKey:Zx8fMenuPendingReset()];
    [ud synchronize];
    Zx8fRefreshNow();
}

static NSString *Zx8fMenuLabelsCacheKey(void) {
    return [OX_NS("ongnong_server_menu_labels_vi_v1_") stringByAppendingString:Zx8fSHA256Hex(Zx8fDeviceId() ?: OX_NS(""))];
}

static NSString *Zx8fUILabelsCacheKey(void) {
    return OX_NS("ongnong_server_ui_labels_v1");
}

static NSDictionary *Zx8fCleanMenuLabels(id raw) {
    if (![raw isKindOfClass:[NSDictionary class]]) return nil;
    NSMutableDictionary *clean = [NSMutableDictionary dictionary];
    NSCharacterSet *ws = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    [(NSDictionary *)raw enumerateKeysAndObjectsUsingBlock:^(id keyObj, id valueObj, BOOL *stop) {
        if (![keyObj isKindOfClass:[NSString class]] || ![valueObj isKindOfClass:[NSString class]]) return;
        NSString *key = [(NSString *)keyObj stringByTrimmingCharactersInSet:ws];
        NSString *value = [(NSString *)valueObj stringByTrimmingCharactersInSet:ws];
        if (key.length == 0 || key.length > 64 || value.length == 0 || value.length > 80) return;
        clean[key] = value;
    }];
    return clean.count ? [clean copy] : @{};
}

static NSDictionary *Zx8fExtractMenuLabelsVI(NSDictionary *json, BOOL *present) {
    if (present) *present = NO;
    if (![json isKindOfClass:[NSDictionary class]]) return nil;
    id raw = json[OX_NS("menu_labels_vi")];
    if (raw != nil) {
        if (present) *present = YES;
        return Zx8fCleanMenuLabels(raw);
    }
    id labels = json[OX_NS("menu_labels")];
    if ([labels isKindOfClass:[NSDictionary class]]) {
        id vi = ((NSDictionary *)labels)[OX_NS("vi")];
        if (vi != nil) {
            if (present) *present = YES;
            return Zx8fCleanMenuLabels(vi);
        }
        NSDictionary *direct = Zx8fCleanMenuLabels(labels);
        if (direct.count > 0) {
            if (present) *present = YES;
            return direct;
        }
    }
    id config = json[OX_NS("config")];
    if ([config isKindOfClass:[NSDictionary class]]) {
        id configLabels = ((NSDictionary *)config)[OX_NS("menu_labels")];
        if ([configLabels isKindOfClass:[NSDictionary class]]) {
            id vi = ((NSDictionary *)configLabels)[OX_NS("vi")];
            if (vi != nil) {
                if (present) *present = YES;
                return Zx8fCleanMenuLabels(vi);
            }
        }
    }
    return nil;
}

static void Zx8fApplyMenuLabelsFromJSON(NSDictionary *json) {
    BOOL present = NO;
    NSDictionary *labels = Zx8fExtractMenuLabelsVI(json, &present);
    if (!present) return;
    g_zx8fMenuLabelsLoaded = YES;
    g_zx8fMenuLabelsVI = labels ?: @{};
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:g_zx8fMenuLabelsVI forKey:Zx8fMenuLabelsCacheKey()];
    [ud synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_menu_labels_changed") object:nil];
}

NSString *Zx8fMenuLabelVI(NSString *key, NSString *fallback) {
    if (key.length == 0) return fallback ?: OX_NS("");
    if (!g_zx8fMenuLabelsLoaded) {
        g_zx8fMenuLabelsLoaded = YES;
        id cached = [[NSUserDefaults standardUserDefaults] objectForKey:Zx8fMenuLabelsCacheKey()];
        g_zx8fMenuLabelsVI = Zx8fCleanMenuLabels(cached) ?: @{};
    }
    id value = g_zx8fMenuLabelsVI[key];
    if ([value isKindOfClass:[NSString class]] && [(NSString *)value length] > 0) return (NSString *)value;
    return fallback ?: OX_NS("");
}

static NSDictionary *Zx8fExtractUILabels(NSDictionary *json, BOOL *present) {
    if (present) *present = NO;
    if (![json isKindOfClass:[NSDictionary class]]) return nil;
    id raw = json[OX_NS("ui_labels")];
    if (raw != nil) {
        if (present) *present = YES;
        return Zx8fCleanMenuLabels(raw);
    }
    id config = json[OX_NS("config")];
    if ([config isKindOfClass:[NSDictionary class]]) {
        id configLabels = ((NSDictionary *)config)[OX_NS("ui_labels")];
        if (configLabels != nil) {
            if (present) *present = YES;
            return Zx8fCleanMenuLabels(configLabels);
        }
    }
    return nil;
}

static void Zx8fApplyUILabelsFromJSON(NSDictionary *json) {
    BOOL present = NO;
    NSDictionary *labels = Zx8fExtractUILabels(json, &present);
    if (!present) return;
    g_zx8fUILabelsLoaded = YES;
    g_zx8fUILabels = labels ?: @{};
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:g_zx8fUILabels forKey:Zx8fUILabelsCacheKey()];
    NSString *pendingTarget = [ud objectForKey:Zx8fCustomUIPendingTargetKey()];
    BOOL resetAllJustConfirmed = [pendingTarget isKindOfClass:[NSString class]] && [pendingTarget isEqualToString:OX_NS("__all__")];
    BOOL resetAck = Zx8fBoolValue(json[OX_NS("custom_ui_reset_all_confirmed")], NO);
    if (resetAllJustConfirmed && resetAck) {
        [ud removeObjectForKey:Zx8fBrandProfileCacheKey()];
    }

    if ([pendingTarget isKindOfClass:[NSString class]] && pendingTarget.length > 0) {
        if (!resetAllJustConfirmed) [ud removeObjectForKey:Zx8fCustomUIResetCacheKeyForTarget(pendingTarget)];
        if (!resetAllJustConfirmed || resetAck) [ud removeObjectForKey:Zx8fCustomUIPendingTargetKey()];
    }
    [ud synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_menu_labels_changed") object:nil];

}

NSString *Zx8fUILabel(NSString *key, NSString *fallback) {
    if (key.length == 0) return fallback ?: OX_NS("");
    if (!g_zx8fUILabelsLoaded) {
        g_zx8fUILabelsLoaded = YES;
        id cached = [[NSUserDefaults standardUserDefaults] objectForKey:Zx8fUILabelsCacheKey()];
        g_zx8fUILabels = Zx8fCleanMenuLabels(cached) ?: @{};
    }
    id value = g_zx8fUILabels[key];
    if ([value isKindOfClass:[NSString class]] && [(NSString *)value length] > 0) return (NSString *)value;
    return fallback ?: OX_NS("");
}

static void Zx8fHandleJSON(NSDictionary *json, BOOL manual) {
    id fpsVisibleRaw = json[OX_NS("fps_visible")];
    if (fpsVisibleRaw != nil && fpsVisibleRaw != [NSNull null]) {
        BOOL fpsVisible = [fpsVisibleRaw respondsToSelector:@selector(boolValue)] ? [fpsVisibleRaw boolValue] : YES;
        NSUserDefaults *fpsUD = [NSUserDefaults standardUserDefaults];
        [fpsUD setBool:fpsVisible forKey:Zx8fFPSVisibleKey()];
        [fpsUD removeObjectForKey:Zx8fFPSPendingKey()];
        [fpsUD synchronize];
        [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_fps_visibility_changed") object:nil];
    }
    NSString *menuPending = [[NSUserDefaults standardUserDefaults] stringForKey:Zx8fMenuPendingKey()];
    NSString *menuAck = Zx8fStringValue(json[OX_NS("custom_menu_confirmed_key")]);
    if (menuPending.length > 0 && [menuAck isEqualToString:menuPending]) {
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud removeObjectForKey:Zx8fMenuPendingKey()];
        [ud removeObjectForKey:Zx8fMenuPendingName()];
        [ud removeObjectForKey:Zx8fMenuPendingReset()];
        [ud synchronize];
    }
    Zx8fApplyMenuLabelsFromJSON(json);
    Zx8fApplyUILabelsFromJSON(json);
    NSString *myKeyURL = Zx8fStringValue(json[OX_NS("mykey_url")]);
    NSURL *parsedMyKey = [NSURL URLWithString:myKeyURL ?: @""];
    if ([[parsedMyKey.scheme lowercaseString] isEqualToString:OX_NS("https")] &&
        [[parsedMyKey.host lowercaseString] isEqualToString:OX_NS("thuoc-api.ongnong.io.vn")]) {
        g_zx8fMyKeyURL = [myKeyURL copy];
    }
    g_zx8fEnrollURL = nil;
    g_zx8fEnrollExpire = 0;
    NSString *enrollURL = Zx8fStringValue(json[OX_NS("device_enroll_url")]);
    NSTimeInterval enrollExpire = (NSTimeInterval)Zx8fIntValue(json[OX_NS("device_enroll_expires_at")], 0);
    NSURL *parsedEnroll = [NSURL URLWithString:enrollURL ?: @""];
    NSTimeInterval enrollNow = [NSDate date].timeIntervalSince1970;
    if ([[parsedEnroll.scheme lowercaseString] isEqualToString:OX_NS("https")] &&
        [[parsedEnroll.host lowercaseString] isEqualToString:OX_NS("thuoc-api.ongnong.io.vn")] &&
        enrollExpire > enrollNow + 5.0) {
        g_zx8fEnrollURL = [enrollURL copy];
        g_zx8fEnrollExpire = enrollExpire;
    }
    BOOL identityVerified = Zx8fBoolValue(json[OX_NS("identity_verified")], NO);
    NSString *identitySource = Zx8fStringValue(json[OX_NS("identity_source")]);
    NSString *canonicalDevice = Zx8fStringValue(json[OX_NS("canonical_device_id")]);
    if (identityVerified && [identitySource isEqualToString:OX_NS("udid_profile")] && canonicalDevice.length >= 5 && canonicalDevice.length <= 96) {
        Zx8fPersistCanonicalDeviceId(canonicalDevice);
        Zx8fCancelEnrollmentPending();
    } else if (g_zx8fEnrollmentPending) {
        if (g_zx8fOpenEnrollmentAfterRefresh && g_zx8fEnrollURL.length > 0) {
            g_zx8fOpenEnrollmentAfterRefresh = NO;
            Zx8fOpenEnrollmentURL(g_zx8fEnrollURL);
        } else {
            Zx8fScheduleEnrollmentRetry();
        }
    }

    Zx8fSaveAnnouncement(json);
    BOOL hadVerifiedVIP =
        g_zx8fActivatedLicense.load(std::memory_order_acquire) &&
        g_zx8fAllowed &&
        !g_zx8fMenuLocked &&
        g_zx8fLastAuthOKTime > 0;
    BOOL ok = Zx8fBoolValue(json[kOk()], NO);
    if (!ok && Zx8fTransientServerError(json)) {
        g_zx8fSoftFailCount++;
        if (g_zx8fAllowed && g_zx8fLastAuthOKTime > 0) Zx8fRemoveOverlay();
        if (manual && g_zx8fAllowed) Zx8fSetStatus(Zx8fCheckingText());
        Zx8fScheduleSoftRetry(Zx8fTransientRetryDelay(json));
        return;
    }
    if (!ok && hadVerifiedVIP && !Zx8fDefinitiveServerError(json) && Zx8fRecentAuthOK()) {
        Zx8fHandleSoftFail(manual);
        return;
    }
    BOOL lv = YES;
    if (json[kLoadviewEnabled()] != nil) lv = Zx8fBoolValue(json[kLoadviewEnabled()], YES);
    else if (json[kLoadview()] != nil) lv = Zx8fBoolValue(json[kLoadview()], YES);

    BOOL active = Zx8fBoolValue(json[kActive()], NO);
    id st = json[kStatus()];
    if ([st isKindOfClass:[NSString class]] && [(NSString *)st caseInsensitiveCompare:kTrue()] == NSOrderedSame) active = YES;

    BOOL isLifetime = Zx8fBoolValue(json[kIsLifetime()], NO);
    NSInteger days = Zx8fIntValue(json[kDaysRemaining()], -1);
    if (days < 0 && !isLifetime) days = Zx8fIntValue(json[kRemainingDays()], -1);
    if (days < 0 && !isLifetime) days = Zx8fIntValue(json[kDays()], -1);

    NSString *licenseSource = Zx8fStringValue(json[kLicenseSource()]);
    id activatedRaw = json[OX_NS("activated")];
    BOOL activatedLicense = NO;
    if (activatedRaw != nil) {
        activatedLicense = Zx8fBoolValue(activatedRaw, NO);
    } else {
        activatedLicense = [licenseSource isEqualToString:OX_NS("device_license")];
    }
    activatedLicense = active && activatedLicense;

    if (ok && hadVerifiedVIP && !activatedLicense) {
        NSTimeInterval negativeNow = [NSDate date].timeIntervalSince1970;
        if (g_zx8fNegativeLicenseTime <= 0 ||
            negativeNow - g_zx8fNegativeLicenseTime > ZX8F_NEGATIVE_LICENSE_WINDOW) {
            g_zx8fNegativeLicenseCount = 0;
        }
        g_zx8fNegativeLicenseTime = negativeNow;
        g_zx8fNegativeLicenseCount++;
        if (g_zx8fNegativeLicenseCount < ZX8F_NEGATIVE_LICENSE_LIMIT) {
            g_zx8fSoftFailCount++;
            Zx8fScheduleSoftRetry(ZX8F_SOFT_RETRY_DELAY);
            return;
        }
    } else if (activatedLicense) {
        g_zx8fNegativeLicenseCount = 0;
        g_zx8fNegativeLicenseTime = 0;
    }

    if (!activatedLicense) days = -1;
    else if (isLifetime) days = -2;
    g_zx8fActivatedLicense.store(
        activatedLicense,
        std::memory_order_release);
    g_zx8fModuleMask.store(
        Zx8fModulesFromJSON(json, active, activatedLicense),
        std::memory_order_relaxed);

    if (!ok) {
        Zx8fClearSession();
        g_zx8fModuleMask.store(0, std::memory_order_relaxed);
        g_zx8fMenuLocked = NO;
        NSString *raw = @"";
        id e = json[kError()];
        id m = json[kMessage()];
        if ([e isKindOfClass:[NSString class]]) raw = (NSString *)e;
        if (raw.length == 0 && [m isKindOfClass:[NSString class]]) raw = (NSString *)m;
        if ([raw rangeOfString:zxv_g02() options:NSCaseInsensitiveSearch].location != NSNotFound ||
            [raw rangeOfString:zxv_g03() options:NSCaseInsensitiveSearch].location != NSNotFound ||
            [raw rangeOfString:zxv_g04() options:NSCaseInsensitiveSearch].location != NSNotFound) {
            Zx8fShowOverlay(Zx8fInactiveText());
            return;
        }
        NSString *msg = Zx8fMessageFromJSON(json, kInvalid());
        Zx8fShowOverlay(msg);
        return;
    }

    g_zx8fMenuLocked = Zx8fBoolValue(json[kModLocked()], NO);
    if (g_zx8fMenuLocked) {
        Zx8fClearSession();
        g_zx8fModuleMask.store(0, std::memory_order_relaxed);
        g_zx8fAllowed = NO;
        g_zx8fLastDays = days;
        Zx8fRemoveOverlay();
        Zx8fShowMenuLockedToast(days);
        Zx8fScheduleAnnouncement(0);
        return;
    }

    if (!Zx8fUpdateSessionFromJSON(json)) {
        if (g_zx8fAllowed && g_zx8fLastAuthOKTime > 0 && Zx8fRecentAuthOK()) {
            Zx8fHandleSoftFail(manual);
            return;
        }
        Zx8fClearSession();
        g_zx8fAllowed = NO;
        g_zx8fModuleMask.store(0, std::memory_order_relaxed);
        Zx8fShowOverlay(Zx8fInvalidText());
        return;
    }
    Zx8fRefreshExpeditionProof();
    if (Zx8fHandleUpdateFromJSON(json, YES)) {
        Zx8fRemoveOverlay();
        Zx8fScheduleAnnouncement(0);
        return;
    }
    Zx8fTryFinish(days);
    Zx8fScheduleAnnouncement(0);
    return;
}

static NSString *Zx8fCleanClientField(NSString *value, NSUInteger maxLen) {
    if (![value isKindOfClass:[NSString class]]) return @"";
    NSMutableString *out = [NSMutableString string];
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:zxv_g11()];
    for (NSUInteger i = 0; i < value.length && out.length < maxLen; i++) {
        unichar ch = [value characterAtIndex:i];
        if ([allowed characterIsMember:ch]) [out appendFormat:@"%C", ch];
    }
    return out ?: @"";
}

static NSString *Zx8fBundleId(void) {
    NSString *bundle = [[NSBundle mainBundle] bundleIdentifier] ?: @"";
    return Zx8fCleanClientField(bundle, 160);
}

static NSString *Zx8fAppName(void) {
    NSBundle *b = [NSBundle mainBundle];
    NSString *name = [b objectForInfoDictionaryKey:zxv_g12()];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = [b objectForInfoDictionaryKey:zxv_g13()];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = zxv_g14();
    return Zx8fCleanClientField(name, 80);
}

static BOOL Zx8fIsMainApp(void) {
    NSString *bundle = [Zx8fBundleId() lowercaseString];
    NSString *name = [Zx8fAppName() lowercaseString];
    if ([bundle isEqualToString:zxv_g15()]) return YES;
    if ([bundle isEqualToString:zxv_g16()]) return YES;
    if ([bundle hasSuffix:zxv_g17()] || [bundle containsString:zxv_g18()] || [bundle containsString:zxv_g19()] || [bundle containsString:zxv_g20()] || [bundle containsString:zxv_g21()] || [bundle containsString:zxv_g22()] || [bundle containsString:zxv_g23()] || [bundle containsString:zxv_g24()]) return NO;
    if ([name hasPrefix:zxv_g19()] || [name containsString:zxv_g18()]) return NO;
    return YES;
}

static NSString *Zx8fCloneId(void) {
    NSString *bundle = Zx8fBundleId();
    NSString *name = Zx8fAppName();
    if (Zx8fIsMainApp()) return zxv_g25();
    NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:zxv_g26() options:0 error:nil];
    NSString *source = name ?: @"";
    NSTextCheckingResult *m = [re firstMatchInString:source options:0 range:NSMakeRange(0, source.length)];
    if (!m && bundle.length > 0) {
        source = bundle;
        m = [re firstMatchInString:source options:0 range:NSMakeRange(0, source.length)];
    }
    if (m && m.numberOfRanges > 1) {
        NSString *n = [source substringWithRange:[m rangeAtIndex:1]];
        NSInteger v = MAX(0, n.integerValue);
        return [NSString stringWithFormat:zxv_g27(), (long)v];
    }
    if (name.length > 0 && ![name isEqualToString:zxv_g14()]) return Zx8fCleanClientField(name, 60);
    if (bundle.length > 0) return Zx8fCleanClientField(bundle, 80);
    return zxv_g28();
}

static BOOL Zx8fSendAll(int fd, const void *buf, size_t len) {
    const uint8_t *p = (const uint8_t *)buf;
    size_t off = 0;
    while (off < len) {
        ssize_t n = send(fd, p + off, len - off, 0);
        if (n <= 0) return NO;
        off += (size_t)n;
    }
    return YES;
}

static NSData *Zx8fRawHttpPost(NSString *urlString, NSData *body, NSString *contentType, NSTimeInterval timeout) {
    @autoreleasepool {
        NSURL *url = [NSURL URLWithString:urlString ?: @""];
        if (!url || ![[url.scheme lowercaseString] isEqualToString:OX_NS("http")]) return nil;
        NSString *host = url.host ?: @"";
        if (host.length == 0) return nil;
        int port = url.port ? url.port.intValue : 80;
        NSString *path = url.path.length ? url.path : OX_NS("/");
        if (url.query.length) path = [path stringByAppendingFormat:OX_NS("?%@"), url.query];
        struct addrinfo hints;
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;
        char service[16];
        snprintf(service, sizeof(service), "%d", port);
        struct addrinfo *res = NULL;
        if (getaddrinfo(host.UTF8String, service, &hints, &res) != 0 || !res) return nil;
        int fd = -1;
        for (struct addrinfo *rp = res; rp; rp = rp->ai_next) {
            fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
            if (fd < 0) continue;
            struct timeval tv;
            tv.tv_sec = (int)MAX(1.0, timeout);
            tv.tv_usec = 0;
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
            if (connect(fd, rp->ai_addr, rp->ai_addrlen) == 0) {
                break;
            }
            close(fd);
            fd = -1;
        }
        freeaddrinfo(res);
        if (fd < 0) return nil;
        NSData *bodyData = body ?: [NSData data];
        NSString *head = [NSString stringWithFormat:OX_NS("POST %@ HTTP/1.0\r\nHost: %@\r\nContent-Type: %@\r\nContent-Length: %lu\r\nConnection: close\r\nAccept: application/json\r\n\r\n"), path, host, contentType ?: OX_NS("application/x-www-form-urlencoded"), (unsigned long)bodyData.length];
        NSData *headData = [head dataUsingEncoding:NSUTF8StringEncoding];
        BOOL ok = Zx8fSendAll(fd, headData.bytes, headData.length);
        if (ok && bodyData.length > 0) ok = Zx8fSendAll(fd, bodyData.bytes, bodyData.length);
        if (!ok) { close(fd); return nil; }
        NSMutableData *resp = [NSMutableData data];
        uint8_t buf[4096];
        for (;;) {
            ssize_t n = recv(fd, buf, sizeof(buf), 0);
            if (n > 0) {
                [resp appendBytes:buf length:(NSUInteger)n];
                if (resp.length > 1024 * 1024) break;
            } else {
                break;
            }
        }
        close(fd);
        if (resp.length == 0) return nil;
        NSData *sep = [OX_NS("\r\n\r\n") dataUsingEncoding:NSUTF8StringEncoding];
        NSRange r = [resp rangeOfData:sep options:0 range:NSMakeRange(0, resp.length)];
        if (r.location == NSNotFound) return resp;
        NSUInteger bodyStart = r.location + r.length;
        if (bodyStart >= resp.length) return nil;
        return [resp subdataWithRange:NSMakeRange(bodyStart, resp.length - bodyStart)];
    }
}

static BOOL Zx8fRecentAuthOK(void) {
    if (g_zx8fLastAuthOKTime <= 0) return NO;
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    return (now - g_zx8fLastAuthOKTime) <= ZX8F_SOFT_AUTH_GRACE;
}

static void Zx8fScheduleSoftRetry(NSTimeInterval delay) {
    NSUInteger seed = g_zx8fRefreshSeed;
    NSTimeInterval safeDelay = MAX(8.0, delay);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(safeDelay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (seed != g_zx8fRefreshSeed) return;
        if (g_zx8fMenuLocked) return;
        Zx8fCheckNow(NO);
    });
}

static void Zx8fHandleSoftFail(BOOL manual) {
    g_zx8fSoftFailCount++;
    BOOL hadOK = g_zx8fLastAuthOKTime > 0;
    if (hadOK && g_zx8fAllowed && !g_zx8fMenuLocked && Zx8fRecentAuthOK()) {
        if (manual) Zx8fSetStatus(Zx8fCheckingText());
        Zx8fScheduleSoftRetry(ZX8F_SOFT_RETRY_DELAY);
        return;
    }
    if (hadOK && g_zx8fSoftFailCount < ZX8F_SOFT_FAIL_LIMIT) {
        Zx8fScheduleSoftRetry(ZX8F_SOFT_RETRY_DELAY);
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{ Zx8fShowOverlay(Zx8fNotReadyText()); });
}

static void Zx8fProcessServerData(NSData *data, BOOL manual, NSString *expectedNonce) {
    if (data.length == 0) {
        Zx8fHandleSoftFail(manual);
        return;
    }
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if (![json isKindOfClass:[NSDictionary class]]) {
        Zx8fHandleSoftFail(manual);
        return;
    }
    NSDictionary *packet = (NSDictionary *)json;
    NSDictionary *verified = Zx8fVerifiedPayload(packet, expectedNonce);
    if (![verified isKindOfClass:[NSDictionary class]]) {
        if (g_zx8fAllowed && g_zx8fLastAuthOKTime > 0 && Zx8fRecentAuthOK()) {
            Zx8fHandleSoftFail(manual);
            return;
        }
        Zx8fClearSession();
        dispatch_async(dispatch_get_main_queue(), ^{ Zx8fShowOverlay(Zx8fInvalidText()); });
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{ Zx8fHandleJSON(verified, manual); });
}

static void Zx8fCheckNow(BOOL manual) {
    if (g_zx8fChecking) return;
    g_zx8fChecking = YES;
    NSString *device = Zx8fDeviceId();
    NSString *build = kBuild();
    NSString *hash = Zx8fProtectedHash();
    NSString *realHash = Zx8fRealFileHash();
    NSString *bundle = Zx8fBundleId();
    NSString *appName = Zx8fAppName();
    NSString *clone = Zx8fCloneId();
    NSString *mainFlag = Zx8fIsMainApp() ? zxv_g30() : zxv_g31();
    NSString *ts = [NSString stringWithFormat:OX_NS("%lld"), (long long)[NSDate date].timeIntervalSince1970];
    NSString *nonce = Zx8fNonce();
    NSString *clientPayload = Zx8fClientPayload(device, build, hash, realHash, ts, nonce, bundle, clone, mainFlag);
    NSString *clientSig = Zx8fSHA256Hex(clientPayload);
    NSString *enrollSig = Zx8fHMACSHA256Hex(Zx8fEnrollProofKey(), clientPayload);
    NSMutableDictionary *items = [@{
        kAction(): kCheckAction(),
        kApp(): kIos(),
        kDevice(): device,
        kBuildKey(): build,
        kBuildChannelField(): Zx8fBuildChannel(),
        kHash(): hash,
        kRealHash(): realHash,
        zxv_g07(): bundle,
        zxv_g08(): appName,
        zxv_g09(): clone,
        zxv_g10(): mainFlag,
        kClientTs(): ts,
        kClientNonce(): nonce,
        kClientSig(): clientSig,
        OX_NS("enroll_sig"): enrollSig
    } mutableCopy];
    NSString *brandProfile = Zx8fBrandProfileCode();
    if (brandProfile.length > 0) items[OX_NS("brand_profile")] = brandProfile;
    NSUserDefaults *fpsUD = [NSUserDefaults standardUserDefaults];
    if ([fpsUD boolForKey:Zx8fFPSPendingKey()]) items[OX_NS("fps_visible")] = Zx8fFPSVisible() ? OX_NS("1") : OX_NS("0");
    NSUserDefaults *customUIUD = [NSUserDefaults standardUserDefaults];
    NSString *pendingTarget = [customUIUD objectForKey:Zx8fCustomUIPendingTargetKey()];
    if ([pendingTarget isKindOfClass:[NSString class]] && pendingTarget.length > 0) {
        if ([pendingTarget isEqualToString:OX_NS("__all__")]) {
            items[OX_NS("custom_ui_reset_all")] = OX_NS("1");
        } else {
            NSString *name = Zx8fCustomUINameForTarget(pendingTarget);
            BOOL reset = [customUIUD boolForKey:Zx8fCustomUIResetCacheKeyForTarget(pendingTarget)];
            NSString *slot = OX_NS("main");
            if ([pendingTarget isEqualToString:OX_NS("counter_title")]) slot = OX_NS("counter");
            else if ([pendingTarget isEqualToString:OX_NS("footer_name")]) slot = OX_NS("footer");
            items[OX_NS("custom_ui_slot")] = slot;
            if (reset) items[OX_NS("custom_ui_reset")] = OX_NS("1");
            else if (name.length > 0) items[OX_NS("custom_ui_name")] = name;
        }
    }
    NSString *menuPending = [customUIUD stringForKey:Zx8fMenuPendingKey()];
    if (menuPending.length > 0) {
        items[OX_NS("custom_menu_key")] = menuPending;
        if ([customUIUD boolForKey:Zx8fMenuPendingReset()]) items[OX_NS("custom_menu_reset")] = OX_NS("1");
        else items[OX_NS("custom_menu_name")] = [customUIUD stringForKey:Zx8fMenuPendingName()] ?: OX_NS("");
    }
    NSString *api = kApiUrl();
    NSData *formBody = Zx8fFormBody(items);
    if ([[api lowercaseString] hasPrefix:OX_NS("http://")]) {
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSData *rawData = Zx8fRawHttpPost(api, formBody, zxv_g05(), 8.0);
            g_zx8fChecking = NO;
            Zx8fProcessServerData(rawData, manual, nonce);
        });
        return;
    }
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:api]];
    req.HTTPMethod = zxv_g29();
    req.timeoutInterval = 8.0;
    req.HTTPBody = formBody;
    [req setValue:zxv_g05() forHTTPHeaderField:zxv_g06()];
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        g_zx8fChecking = NO;
        if (error) {
            Zx8fHandleSoftFail(manual);
            return;
        }
        Zx8fProcessServerData(data, manual, nonce);
    }];
    [task resume];
}

void Zx8fRefreshNow(void) {
    Zx8fCheckNow(NO);
}

static void Zx8fScheduleRefresh(NSTimeInterval delay) {
    NSUInteger seed = ++g_zx8fRefreshSeed;
    NSTimeInterval safeDelay = MAX(15.0, delay);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(safeDelay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (seed != g_zx8fRefreshSeed) return;
        if (g_zx8fMenuLocked) return;
        Zx8fCheckNow(NO);
    });
}

void Zx8fStart(Zx8fAllowBlock allowBlock) {
    if (allowBlock) g_zx8fAllowBlock = [allowBlock copy];
    g_zx8fMenuLocked = NO;
    g_zx8fAllowed = NO;
    g_zx8fActivatedLicense.store(false, std::memory_order_release);
    g_zx8fModuleMask.store(0, std::memory_order_relaxed);
    Zx8fClearSession();
    Zx8fCheckNow(NO);
}

BOOL Zx8fAllowed(void) {
    return Zx8fHasModule(ZX8F_M_MENU, YES);
}

BOOL Zx8fMenuAllowed(void) {
    return Zx8fHasModule(ZX8F_M_MENU, YES);
}

BOOL Zx8fSpeedAllowed(void) {
    return Zx8fHasModule(ZX8F_M_SPEED, YES);
}

BOOL Zx8fCounterAllowed(void) {
    return Zx8fHasModule(ZX8F_M_COUNTER, YES);
}

BOOL Zx8fPotionAllowed(void) {
    return Zx8fHasModule(ZX8F_M_POTION, YES);
}

BOOL Zx8fTokenAllowed(void) {
    return Zx8fHasModule(ZX8F_M_TOKEN, YES);
}

BOOL Zx8fLightningAllowed(void) {
    return Zx8fHasModule(ZX8F_M_LIGHTNING, YES);
}

BOOL Zx8fBetCycleAllowed(void) {
    return Zx8fHasModule(ZX8F_M_BET_CYCLE, YES);
}

BOOL Zx8fAutoMergeAllowed(void) {
    return Zx8fHasModule(ZX8F_M_AUTO_MERGE, YES);
}

BOOL Zx8fAutoClickAllowed(void) {
    return Zx8fHasModule(ZX8F_M_AUTO_CLICK, YES);
}

BOOL Zx8fRaidHammerAllowed(void) {
    return Zx8fHasModule(ZX8F_M_RAID_HAMMER, YES);
}

BOOL Zx8fToolsAllowed(void) {
    return Zx8fHasModule(ZX8F_M_TOOLS, YES);
}

BOOL Zx8fAutoStopAllowed(void) {
    return Zx8fHasModule(ZX8F_M_AUTO_STOP, YES);
}

BOOL Zx8fMenuColorAllowed(void) {
    return Zx8fHasModule(ZX8F_M_MENU_COLOR, YES);
}

BOOL Zx8fFriendInviteAllowed(void) {
    return Zx8fHasModule(ZX8F_M_FRIEND_INVITE, YES);
}

BOOL Zx8fIsVIP(void) {
    return g_zx8fActivatedLicense.load(std::memory_order_acquire) &&
           Zx8fHasModule(ZX8F_M_MENU, YES);
}

BOOL Zx8fAutoBuildAllowed(void) {
    return Zx8fHasModule(ZX8F_M_AUTO_BUILD, NO);
}

BOOL Zx8fMagicCardsAllowed(void) {
    return Zx8fHasModule(ZX8F_M_MAGIC_CARDS, YES);
}

BOOL Zx8fExpeditionAllowed(void) {
    return Zx8fHasModule(
        ZX8F_M_EXPEDITION,
        YES);
}

__attribute__((noinline, visibility("hidden")))
uint64_t R7f408(uint64_t challenge) {
    const void *caller = __builtin_return_address(0);
    if (!Zx8fSameImageCaller(caller)) return 0;

    unsigned int mask =
        g_zx8fModuleMask.load(std::memory_order_acquire);
    NSTimeInterval now =
        [NSDate date].timeIntervalSince1970;
    NSTimeInterval proofDeadline = Zx8fBitsDouble(
        g_zx8fProofDeadlineBits.load(
            std::memory_order_acquire));
    if (proofDeadline <= now + 0.25) {
        Zx8fRefreshExpeditionProof();
        proofDeadline = Zx8fBitsDouble(
            g_zx8fProofDeadlineBits.load(
                std::memory_order_acquire));
    }
    if (!g_zx8fAllowed ||
        g_zx8fMenuLocked ||
        !Zx8fSessionAlive() ||
        (mask & ZX8F_M_EXPEDITION) == 0 ||
        proofDeadline <= now) {
        return 0;
    }

    uint64_t first =
        g_zx8fProofA.load(std::memory_order_acquire);
    uint64_t second =
        g_zx8fProofB.load(std::memory_order_acquire);
    uint64_t generation =
        g_zx8fProofGeneration.load(
            std::memory_order_acquire);
    if (first == 0 || second == 0 || generation == 0) {
        return 0;
    }

    uint64_t threadPart = Zx8fMix64(
        (uint64_t)(uintptr_t)pthread_self() ^
        generation ^ R7F8_A);
    uint64_t guard = R7f702(
        challenge ^ second ^ threadPart);
    if (guard == 0) return 0;
    uint64_t phase = Zx8fMix64(
        first ^ R7F8_D ^ guard ^
        Zx8fRotate64(second, 13));
    uint64_t response =
        Zx8fMix64(
            challenge ^ first ^ threadPart ^
            Zx8fRotate64(phase, 17) ^
            Zx8fRotate64(second, 29) ^
            R7F8_E ^ guard) ^
        phase ^ guard ^ second;
    if (response == 0) response = R7F8_E | 1;

    g_zx8fPendingChallenge = challenge;
    g_zx8fPendingResponse = response;
    g_zx8fPendingGeneration = generation;
    g_zx8fPendingDeadline = now + 0.20;
    return response;
}

__attribute__((noinline, visibility("hidden")))
BOOL R7f409(uint64_t challenge,
            uint64_t response) {
    const void *caller = __builtin_return_address(0);
    NSTimeInterval now =
        [NSDate date].timeIntervalSince1970;
    uint64_t generation =
        g_zx8fProofGeneration.load(
            std::memory_order_acquire);
    BOOL callerOK = Zx8fSameImageCaller(caller);
    BOOL ticketOK = callerOK &&
        g_zx8fPendingChallenge == challenge &&
        g_zx8fPendingResponse == response &&
        g_zx8fPendingGeneration == generation &&
        g_zx8fPendingDeadline >= now;
    uint64_t expected = g_zx8fPendingResponse;
    g_zx8fPendingChallenge = 0;
    g_zx8fPendingResponse = 0;
    g_zx8fPendingGeneration = 0;
    g_zx8fPendingDeadline = 0;
    if (!ticketOK ||
        !g_zx8fAllowed ||
        g_zx8fMenuLocked ||
        !Zx8fSessionAlive()) {
        return NO;
    }
    uint64_t difference = expected ^ response;
    difference |= difference >> 32;
    difference |= difference >> 16;
    difference |= difference >> 8;
    difference |= difference >> 4;
    difference |= difference >> 2;
    difference |= difference >> 1;
    return (difference & 1) == 0;
}

BOOL Zx8fPotionOrTokenAllowed(void) {
    return Zx8fPotionAllowed() || Zx8fTokenAllowed();
}

BOOL Zx8fMenuLocked(void) {
    return g_zx8fMenuLocked;
}

void Zx8fMarkRuntimeReady(void) {
    g_zx8fRuntimeReady = YES;
    if (g_zx8fAnnEnabled && !g_zx8fAnnShownThisRun) Zx8fScheduleAnnouncement(0);
}

void Zx8fShowRemainingToast(NSInteger days) {
    if (days != -2 && days < 0) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *host = Zx8fHostWindow();
        if (!host) return;
        NSString *msg = nil;
        if (days == -2) {
            msg = Zx8fMenuPickText(OX_NS("VIP VĨNH VIỄN"), OX_NS("VIP 永久"), OX_NS("VIP ตลอดชีพ"), OX_NS("VIP A VITA"), OX_NS("VIP LIFETIME"));
        } else {
            NSString *fmt = Zx8fMenuPickText(OX_NS("VIP còn %ld ngày"), OX_NS("VIP 剩余 %ld 天"), OX_NS("VIP เหลือ %ld วัน"), OX_NS("VIP: %ld giorni rimanenti"), OX_NS("VIP: %ld days remaining"));
            msg = [NSString stringWithFormat:fmt, (long)MAX((NSInteger)0, days)];
        }
        UILabel *toast = [[UILabel alloc] initWithFrame:CGRectZero];
        toast.text = msg;
        toast.textColor = [UIColor whiteColor];
        toast.textAlignment = NSTextAlignmentCenter;
        toast.font = [UIFont boldSystemFontOfSize:15];
        toast.numberOfLines = 2;
        toast.backgroundColor = [UIColor colorWithWhite:0 alpha:0.68];
        toast.layer.cornerRadius = 14;
        toast.layer.masksToBounds = YES;
        CGFloat w = MIN(host.bounds.size.width - 40, (CGFloat)290);
        toast.frame = CGRectMake((host.bounds.size.width - w)/2, 64, w, 46);
        toast.alpha = 0;
        [host addSubview:toast];
        [UIView animateWithDuration:0.25 animations:^{ toast.alpha = 1; } completion:^(__unused BOOL finished) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [UIView animateWithDuration:0.25 animations:^{ toast.alpha = 0; } completion:^(__unused BOOL done) { [toast removeFromSuperview]; }];
            });
        }];
    });
}

}
