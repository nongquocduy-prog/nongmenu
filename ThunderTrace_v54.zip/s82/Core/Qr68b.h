#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
double q6t(uint32_t x);
void q6max(double *p, double v);
bool q6ga(uint32_t tag);
#ifdef __cplusplus
}
#endif
