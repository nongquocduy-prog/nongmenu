#pragma once
#import <Foundation/Foundation.h>
#define FriendInviteSend R8k4a1
#define FriendInviteOpenMine R8k4a2
#define FriendInviteStatus R8k4a3
#define AutoPotionSetEnabled R8k4b1
#define AutoPotionIsEnabled R8k4b2
#define AutoPotionStatus R8k4b3
namespace Ongnong {
void ExtrasBootstrap(void);
BOOL FriendInviteSend(NSString *link);
BOOL FriendInviteOpenMine(void);
NSString *FriendInviteStatus(void);
void AutoPotionSetEnabled(BOOL enabled);
BOOL AutoPotionIsEnabled(void);
NSString *AutoPotionStatus(void);
}
