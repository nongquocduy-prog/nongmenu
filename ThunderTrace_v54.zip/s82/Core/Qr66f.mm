#import "Qr66f.h"

static NSInteger q66f0(NSInteger v) { return v < 0 ? -v : v; }

BOOL q66f2(NSInteger a, NSInteger b) {
    if (a < 0 || b <= 0) return NO;
    NSInteger r = b - a;
    NSInteger m = b / 10;
    if (b >= 100000 && m < 25000) m = 25000;
    if (m < 20) m = 20;
    if (a * 100 >= b * 70) return YES;
    return r >= 0 && r <= m;
}

BOOL q66f3(NSInteger a, NSInteger b, NSInteger c) {
    if (a < 0 || b < 0) return NO;
    if (b < a && c > 0) return YES;
    return NO;
}

NSInteger q66f1(NSInteger a, NSInteger b, NSInteger c, NSInteger d) {
    if (a < 0 || c <= 0 || b < 0 || d <= 0) return 0;
    if (b >= a) return 0;
    NSInteger s = q66f0(a - b);
    if (d != c) s += 500000;
    if (q66f2(a, c)) s += 260000;
    if (b * 100 <= d * 40) s += 120000;
    if (s < 250000) return 0;
    return s;
}
