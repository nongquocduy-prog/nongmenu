#import "Qr65a.h"
#import "zx8f1a_pro.h"
#import <Foundation/Foundation.h>

static NSString *q65a9(id v) {
    if (!v || v == [NSNull null]) return @"";
    NSString *s = [v isKindOfClass:[NSString class]] ? (NSString *)v : [v description];
    return s.lowercaseString ?: @"";
}

BOOL q65a0(NSString *v) {
    NSString *u = q65a9(v);
    NSString *a = zxv_p00();
    NSString *b = zxv_p01();
    if (![u hasPrefix:a] && ![u hasPrefix:b]) return NO;
    if (![u containsString:zxv_p02()]) return NO;
    return ([u containsString:zxv_p03()] || [u containsString:zxv_p04()]);
}

NSString *q65a1(NSString *v) {
    if (![v isKindOfClass:[NSString class]] || v.length == 0) return zxv_p05();
    NSRegularExpression *r = [NSRegularExpression regularExpressionWithPattern:zxv_p06() options:NSRegularExpressionCaseInsensitive error:nil];
    NSTextCheckingResult *m = [r firstMatchInString:v options:0 range:NSMakeRange(0, v.length)];
    if (m && m.numberOfRanges > 1) {
        NSString *x = [v substringWithRange:[m rangeAtIndex:1]];
        return x.length ? x : zxv_p05();
    }
    return zxv_p05();
}
