#import "Qr66e.h"
#import "Qr66f.h"
#import "zx8f1a_pro.h"

@implementation Q66E0
@end

static NSDictionary *q66e0(NSMutableDictionary *b, NSString *i) {
    if (![b isKindOfClass:[NSDictionary class]] || ![i isKindOfClass:[NSString class]] || i.length == 0) return nil;
    id v = b[i];
    return [v isKindOfClass:[NSDictionary class]] ? (NSDictionary *)v : nil;
}

static BOOL q66e1(NSSet *s, NSString *i) {
    return ([s isKindOfClass:[NSSet class]] && [i isKindOfClass:[NSString class]] && [s containsObject:i]);
}

static Q65B0 *q66e2(NSArray<Q65B0 *> *z) {
    Q65B0 *p = nil;
    NSInteger h = NSIntegerMax;
    for (Q65B0 *x in z) {
        if (![x isKindOfClass:[Q65B0 class]] || x.x0.length == 0 || x.x2 <= 0) continue;
        NSInteger r = (x.x1 * 1000000) / MAX((NSInteger)1, x.x2);
        if (!p || r < h || (r == h && x.x2 > p.x2)) {
            p = x;
            h = r;
        }
    }
    return p;
}

static Q66E0 *q66e3(Q65B0 *x, NSInteger s) {
    if (![x isKindOfClass:[Q65B0 class]] || s <= 0) return nil;
    Q66E0 *o = [Q66E0 new];
    o.x0 = x;
    o.x1 = s;
    return o;
}

static Q66E0 *q66e4(NSArray<Q65B0 *> *z, NSMutableDictionary *b) {
    Q66E0 *o = nil;
    for (Q65B0 *x in z) {
        if (![x isKindOfClass:[Q65B0 class]] || x.x0.length == 0) continue;
        NSDictionary *old = q66e0(b, x.x0);
        NSInteger a = q65b6(old[zxv_p24()], -1);
        NSInteger c = q65b6(old[zxv_p31()], -1);
        NSInteger s = q66f1(a, x.x1, c, x.x2);
        if (s > 0 && (!o || s > o.x1)) o = q66e3(x, s);
    }
    return o;
}

static Q66E0 *q66e5(NSArray<Q65B0 *> *z, NSMutableDictionary *b) {
    if (![b isKindOfClass:[NSDictionary class]] || z.count == 0) return nil;
    NSMutableSet *ids = [NSMutableSet set];
    for (Q65B0 *x in z) if ([x isKindOfClass:[Q65B0 class]] && x.x0.length) [ids addObject:x.x0];
    NSInteger best = 0;
    for (id rk in b) {
        NSString *k = [rk isKindOfClass:[NSString class]] ? (NSString *)rk : [rk description];
        if (q66e1(ids, k)) continue;
        NSDictionary *old = q66e0(b, k);
        NSInteger a = q65b6(old[zxv_p24()], -1);
        NSInteger c = q65b6(old[zxv_p31()], -1);
        if (!q66f2(a, c)) continue;
        NSInteger s = 320000 + MAX((NSInteger)0, c - a);
        if (s > best) best = s;
    }
    if (best <= 0) return nil;
    Q65B0 *p = q66e2(z);
    return q66e3(p, best);
}

Q66E0 *q66e9(NSArray<Q65B0 *> *z, NSMutableDictionary *b) {
    if (![z isKindOfClass:[NSArray class]] || z.count == 0 || ![b isKindOfClass:[NSMutableDictionary class]]) return nil;
    Q66E0 *a = q66e4(z, b);
    Q66E0 *c = q66e5(z, b);
    if (a && c) return a.x1 >= c.x1 ? a : c;
    return a ?: c;
}
