#pragma once
#import <Foundation/Foundation.h>
#include <stdint.h>
NSInteger q67c9(id j, NSString *u, uint64_t snap);
BOOL q67d0(NSString *u, uint64_t snap, NSInteger countAtParse);
BOOL q67d1(NSString *u, uint64_t snap);
