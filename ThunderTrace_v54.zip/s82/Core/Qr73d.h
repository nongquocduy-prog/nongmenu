#import <Foundation/Foundation.h>

namespace Ongnong {
NSString *K4p7a(NSString *suffix);
NSString *K4p7b(void);
NSArray<NSDictionary *> *K4p7c(void);
NSDictionary *K4p7d(id obj);
NSInteger K4p7e(NSArray<NSDictionary *> *rows);
}
