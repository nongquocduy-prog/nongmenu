#import "OngnongExtras.h"
#import "OngnongOxorany.h"
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"
#import <UIKit/UIKit.h>
#include <atomic>
#include <mutex>
#include <string>
#include <ctime>
#include <cctype>

static std::atomic<int> gFriendState(0);
static std::mutex gFriendLock;
static std::string gFriendLink;

static std::atomic<bool> gPotionEnabled(false);
static std::atomic<bool> gPotionHookReady(false);
static std::atomic<bool> gPotionHookBusy(false);
static std::atomic<bool> gPotionRequestPending(false);
static std::atomic<unsigned long long> gPotionRequestToken(0);
static std::atomic<long long> gPotionCurrent(0);
static std::atomic<long long> gPotionMax(0);
static std::atomic<long long> gPotionBeforeCurrent(-1);
static std::atomic<int> gPotionWaitCount(0);
static std::mutex gPotionLock;
static void *gPotionService = nullptr;
static std::string gPotionEventId;
static std::string gPotionRequestedEventId;
static void *gPotionModel = nullptr;

static std::string Il2CppText(Il2CppString *s) {
    if (!s) return std::string();
    const char *p = s->CString();
    return p ? std::string(p) : std::string();
}

static bool IsPotionGeneratorId(const std::string& raw) {
    if (raw.empty()) return false;
    std::string id=raw;
    for (char &c : id) c=(char)tolower((unsigned char)c);
    
    
    return id.find(OX_C("resource_generator"))!=std::string::npos &&
           id.find(OX_C("expedition"))!=std::string::npos;
}

static std::string FriendTokenFromLink(NSString *link) {
    if (!link.length) return std::string();
    NSString *value=[link stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSRange marker=[value rangeOfString:@"~" options:NSBackwardsSearch];
    if (marker.location==NSNotFound) return std::string();
    NSUInteger begin=NSMaxRange(marker);
    if (begin>=value.length) return std::string();
    NSRange q=[value rangeOfString:@"?" options:0 range:NSMakeRange(begin,value.length-begin)];
    NSUInteger end=(q.location==NSNotFound)?value.length:q.location;
    if (end<=begin) return std::string();
    NSString *token=[value substringWithRange:NSMakeRange(begin,end-begin)];
    NSCharacterSet *bad=[[NSCharacterSet alphanumericCharacterSet] invertedSet];
    if ([token rangeOfCharacterFromSet:bad].location!=NSNotFound) return std::string();
    return token.UTF8String ? std::string(token.UTF8String) : std::string();
}

static void InvokeFriendDirect(NSString *link) {
    std::string token=FriendTokenFromLink(link);
    if (token.empty()) {
        gFriendState.store(-1);
        return;
    }
    Attach();
    void *manager=Il2CppGetSingleton(OX_C("Assembly-CSharp.dll"),"",OX_C("FriendsManager"));
    MethodInfo *request=Il2CppFindMethodInfo(OX_C("Assembly-CSharp.dll"),"",OX_C("FriendsManager"),OX_C("GetFriendRequestFromServer"),2,true);
    if (!manager || !request) {
        gFriendState.store(-2);
        return;
    }
    Il2CppString *t=Il2CppString::Create(token.c_str());
    void *params[2]={t,nullptr};
    void *exc=nullptr;
    Il2CppRuntimeInvoke(request,manager,params,&exc);
    if (exc) {
        gFriendState.store(-3);
        return;
    }
    gFriendState.store(2);
}

static bool PotionReadModelAmounts(void *model, long long *currentOut, long long *maxOut) {
    if (!model) return false;
    
    
    void *currentReactive = *(void **)((uintptr_t)model + 0x60);
    void *maxReactive = *(void **)((uintptr_t)model + 0x68);
    
    if (!currentReactive || !maxReactive) return false;
    long long current = *(long long *)((uintptr_t)currentReactive + 0x10);
    long long max = *(long long *)((uintptr_t)maxReactive + 0x10);
    
    if (current < 0 || max <= 0 || current > max * 1000LL) return false;
    if (currentOut) *currentOut = current;
    if (maxOut) *maxOut = max;
    return true;
}

static bool PotionResolveEventIdFromModel(void *model, std::string *outId) {
    if (!model) return false;
    Attach();
    MethodInfo *getId = Il2CppFindMethodInfo(OX_C("Assembly-CSharp.dll"), OX_C("Moonactive.SpecialEvents.ResourceGenerator"), OX_C("ResourceGeneratorModel"), OX_C("get_Id"), 0, true);
    if (!getId) {
        
        return false;
    }
    void *exc = nullptr;
    void *ret = Il2CppRuntimeInvoke(getId, model, nullptr, &exc);
    
    if (exc || !ret) return false;
    std::string id = Il2CppText((Il2CppString *)ret);
    
    if (id.empty()) return false;
    if (outId) *outId = id;
    return true;
}

static void *PotionRefreshModel(void) {
    void *service = nullptr;
    std::string eventId;
    {
        std::lock_guard<std::mutex> guard(gPotionLock);
        service = gPotionService;
        eventId = gPotionEventId;
    }
    if (!service) return nullptr;
    if (eventId.empty()) {
        void *cachedModel = nullptr;
        {
            std::lock_guard<std::mutex> guard(gPotionLock);
            cachedModel = gPotionModel;
        }
        std::string resolved;
        if (PotionResolveEventIdFromModel(cachedModel, &resolved)) {
            std::lock_guard<std::mutex> guard(gPotionLock);
            gPotionEventId = resolved;
            eventId = resolved;
        }
    }
    if (eventId.empty()) return nullptr;
    Attach();
    MethodInfo *getModel = Il2CppFindMethodInfo(OX_C("Assembly-CSharp.dll"), OX_C("Moonactive.SpecialEvents.ResourceGenerator"), OX_C("ResourceGeneratorService"), OX_C("GetModel"), 1, true);
    if (!getModel) return nullptr;
    Il2CppString *id = Il2CppString::Create(eventId.c_str());
    void *params[1] = { id };
    void *exc = nullptr;
    void *ret = Il2CppRuntimeInvoke(getModel, service, params, &exc);
    
    if (exc || !ret) return nullptr;
    {
        std::lock_guard<std::mutex> guard(gPotionLock);
        gPotionModel = ret;
    }
    return ret;
}

static bool PotionRefreshAmounts(void) {
    void *model = PotionRefreshModel();
    if (!model) {
        std::lock_guard<std::mutex> guard(gPotionLock);
        model = gPotionModel;
    }
    long long current = 0, max = 0;
    if (!PotionReadModelAmounts(model, &current, &max)) return false;
    gPotionCurrent.store(current);
    gPotionMax.store(max);
    return true;
}

static bool PotionDiscoverService(void) {
    
    
    
    
    Attach();
    

    MethodInfo *getFacade = Il2CppFindMethodInfo(OX_C("Assembly-CSharp.dll"),
                                                OX_C("MoonActive.ServiceLocator"),
                                                OX_C("ServiceGet"),
                                                OX_C("get_ResourceGeneratorDomainFacade"),
                                                0,
                                                true);
    
    if (!getFacade) return false;

    void *exc = nullptr;
    void *facade = Il2CppRuntimeInvoke(getFacade, nullptr, nullptr, &exc);
    
    if (exc || !facade) return false;

    
    void *service = *(void **)((uintptr_t)facade + 0x18);
    
    if (!service) return false;

    
    auto *dict = *(monoDictionary<Il2CppString *, void *> **)((uintptr_t)service + 0x10);
    
    if (!dict || !dict->entries) return false;

    int count = dict->count;
    int capacity = dict->entries->capacity;
    if (count < 0 || count > 512 || capacity < 0 || capacity > 2048) {
        
        return false;
    }
    

    int seen = 0;
    for (int i = 0; i < capacity && seen < count; ++i) {
        auto &entry = dict->entries->m_Items[i];
        if (entry.hashCode < 0 || !entry.key || !entry.value) continue;
        ++seen;
        std::string id = Il2CppText(entry.key);
        if (id.empty()) continue;
        if (!IsPotionGeneratorId(id)) continue;

        void *model = entry.value;
        {
            std::lock_guard<std::mutex> guard(gPotionLock);
            gPotionService = service;
            gPotionModel = model;
            gPotionEventId = id;
        }
        gPotionHookReady.store(true);
        
        return true;
    }

    
    return false;
}

static void EnsurePotionHook(void) {
    
    
    PotionDiscoverService();
}

static BOOL PotionInvoke(NSString *name) {
    void *service=nullptr;
    std::string eventId;
    {
        std::lock_guard<std::mutex> guard(gPotionLock);
        service=gPotionService;
        eventId=gPotionEventId;
    }
    
    if (!service || eventId.empty()) {
        
        return NO;
    }
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
        
        return NO;
    }
    Attach();
    MethodInfo *m=Il2CppFindMethodInfo(OX_C("Assembly-CSharp.dll"),OX_C("Moonactive.SpecialEvents.ResourceGenerator"),OX_C("ResourceGeneratorService"),name.UTF8String,1,true);
    
    if (!m) return NO;
    Il2CppString *id=Il2CppString::Create(eventId.c_str());
    
    void *params[1]={id};
    void *exc=nullptr;
    
    Il2CppRuntimeInvoke(m,service,params,&exc);
    
    return exc==nullptr;
}

static void PotionCheckResult(unsigned long long token, long long before, int attempt) {
    if (!gPotionRequestPending.load() || token != gPotionRequestToken.load()) return;
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
        gPotionRequestPending.store(false);
        gPotionEnabled.store(false);
        
        return;
    }
    bool refreshed = PotionRefreshAmounts();
    long long now = gPotionCurrent.load();
    
    if (refreshed && before > 0 && now < before) {
        gPotionEnabled.store(true);
        gPotionRequestPending.store(false);
        
        return;
    }
    if (attempt >= 8) {
        gPotionRequestPending.store(false);
        gPotionEnabled.store(false);
        
        return;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.75*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ PotionCheckResult(token, before, attempt+1); });
}

static void PotionCollectAfterRefresh(unsigned long long token) {
    if (!gPotionRequestPending.load() || token != gPotionRequestToken.load()) return;
    if (!PotionRefreshAmounts()) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.75*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ PotionCollectAfterRefresh(token); });
        return;
    }
    long long current = gPotionCurrent.load();
    
    if (current <= 0) {
        gPotionRequestPending.store(false);
        gPotionEnabled.store(false);
        
        return;
    }
    gPotionBeforeCurrent.store(current);
    if (!PotionInvoke(OX_NS("Collect"))) {
        gPotionRequestPending.store(false);
        gPotionEnabled.store(false);
        
        return;
    }
    PotionCheckResult(token, current, 0);
}

static void PotionStartRequest(unsigned long long token) {
    
    if (!gPotionRequestPending.load() || token != gPotionRequestToken.load()) { return; }
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
        gPotionRequestPending.store(false);
        return;
    }
    void *service = nullptr;
    std::string eventId;
    {
        std::lock_guard<std::mutex> guard(gPotionLock);
        service = gPotionService;
        eventId = gPotionEventId;
    }
    if (!service || !IsPotionGeneratorId(eventId)) {
        gPotionRequestPending.store(false);
        gPotionEnabled.store(false);
        gPotionWaitCount.store(0);
        
        return;
    }
    {
        std::lock_guard<std::mutex> guard(gPotionLock);
        gPotionRequestedEventId = eventId;
    }
    PotionRefreshAmounts();
    long long current = gPotionCurrent.load();
    gPotionBeforeCurrent.store(current);
    

    if (current > 0) {
        if (!PotionInvoke(OX_NS("Collect"))) {
            gPotionRequestPending.store(false);
            gPotionEnabled.store(false);
            
            return;
        }
        PotionCheckResult(token, current, 0);
    } else {
        if (!PotionInvoke(OX_NS("UpdateState"))) {
            gPotionRequestPending.store(false);
            gPotionEnabled.store(false);
            
            return;
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(2.0*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ PotionCollectAfterRefresh(token); });
    }
}


static NSString *ZextrasPick5(NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = [[NSUserDefaults standardUserDefaults] stringForKey:OX_NS("ongnong_menu_language")];
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return vi ?: OX_NS("");
}

namespace Ongnong {
void ExtrasBootstrap(void) {
    gPotionEnabled.store(false);
    gPotionRequestPending.store(false);
    gPotionBeforeCurrent.store(-1);
    
    
    
}

BOOL FriendInviteSend(NSString *link) {
    if (link.length==0 || [link rangeOfString:OX_NS("getcoinmaster.com/") options:NSCaseInsensitiveSearch].location==NSNotFound) return NO;
    std::string token=FriendTokenFromLink(link);
    if (token.empty()) return NO;
    {
        std::lock_guard<std::mutex> guard(gFriendLock);
        gFriendLink=link.UTF8String ?: "";
    }
    gFriendState.store(1);
    dispatch_async(dispatch_get_main_queue(),^{ InvokeFriendDirect(link); });
    return YES;
}

BOOL FriendInviteOpenMine(void) {
    Attach();
    MethodInfo *m=Il2CppFindMethodInfo(OX_C("Assembly-CSharp.dll"),"",OX_C("InviteFriends"),OX_C("ShowPopupWithSourceAnalytics"),1,true);
    if (!m) return NO;
    Il2CppString *src=Il2CppString::Create(OX_C("ongnong"));
    void *params[1]={src};
    void *exc=nullptr;
    Il2CppRuntimeInvoke(m,nullptr,params,&exc);
    return exc==nullptr;
}

NSString *FriendInviteStatus(void) {
    int s=gFriendState.load();
    if (s==1) return ZextrasPick5(OX_NS("ĐANG GỬI LINK..."), OX_NS("正在发送链接..."), OX_NS("กำลังส่งลิงก์..."), OX_NS("INVIO LINK..."), OX_NS("SENDING LINK..."));
    if (s==2) return ZextrasPick5(OX_NS("ĐÃ GỬI YÊU CẦU KẾT BẠN"), OX_NS("好友请求已发送"), OX_NS("ส่งคำขอเป็นเพื่อนแล้ว"), OX_NS("RICHIESTA DI AMICIZIA INVIATA"), OX_NS("FRIEND REQUEST SENT"));
    if (s<0) return ZextrasPick5(OX_NS("LỖI GỬI LINK"), OX_NS("发送链接失败"), OX_NS("ส่งลิงก์ล้มเหลว"), OX_NS("ERRORE INVIO LINK"), OX_NS("LINK SEND FAILED"));
    return ZextrasPick5(OX_NS("SẴN SÀNG"), OX_NS("就绪"), OX_NS("พร้อม"), OX_NS("PRONTO"), OX_NS("READY"));
}

void AutoPotionSetEnabled(BOOL enabled) {
    
    if (!enabled) {
        gPotionRequestToken.fetch_add(1);
        gPotionRequestPending.store(false);
        gPotionEnabled.store(false);
        gPotionBeforeCurrent.store(-1);
        gPotionWaitCount.store(0);
        {
            std::lock_guard<std::mutex> guard(gPotionLock);
            gPotionRequestedEventId.clear();
        }
        
        return;
    }
    if (gPotionEnabled.load()) return;
    
    
    EnsurePotionHook();
    void *service = nullptr;
    std::string eventId;
    {
        std::lock_guard<std::mutex> guard(gPotionLock);
        service = gPotionService;
        eventId = gPotionEventId;
    }
    if (service && eventId.empty()) {
        void *model = nullptr;
        {
            std::lock_guard<std::mutex> guard(gPotionLock);
            model = gPotionModel;
        }
        std::string resolved;
        if (PotionResolveEventIdFromModel(model, &resolved)) {
            {
                std::lock_guard<std::mutex> guard(gPotionLock);
                gPotionEventId = resolved;
                eventId = resolved;
            }
        }
    }
    if (!service || !IsPotionGeneratorId(eventId)) {
        gPotionRequestPending.store(false);
        gPotionEnabled.store(false);
        gPotionBeforeCurrent.store(-1);
        gPotionWaitCount.store(0);
        
        return;
    }

    gPotionRequestPending.store(true);
    gPotionEnabled.store(false);
    gPotionBeforeCurrent.store(-1);
    gPotionWaitCount.store(0);
    unsigned long long token=gPotionRequestToken.fetch_add(1)+1;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.10*NSEC_PER_SEC)),dispatch_get_main_queue(),^{ PotionStartRequest(token); });
}

BOOL AutoPotionIsEnabled(void) { return gPotionEnabled.load(); }

NSString *AutoPotionStatus(void) {
    if (gPotionEnabled.load()) return ZextrasPick5(OX_NS("ON - ĐÃ NHẬN THUỐC"), OX_NS("开 - 已领取药水"), OX_NS("เปิด - รับยาแล้ว"), OX_NS("ON - POZIONE RITIRATA"), OX_NS("ON - POTION COLLECTED"));
    if (gPotionRequestPending.load()) return ZextrasPick5(OX_NS("ĐANG NHẬN THUỐC..."), OX_NS("正在领取药水..."), OX_NS("กำลังรับยา..."), OX_NS("RITIRO POZIONE..."), OX_NS("COLLECTING POTION..."));
    return ZextrasPick5(OX_NS("OFF"), OX_NS("关"), OX_NS("ปิด"), OX_NS("OFF"), OX_NS("OFF"));
}

}
