#pragma once
#import <Foundation/Foundation.h>

@interface Q65B0 : NSObject
@property(nonatomic, copy) NSString *x0;
@property(nonatomic) NSInteger x1;
@property(nonatomic) NSInteger x2;
@end

NSArray<Q65B0 *> *q65b9(id v);
NSInteger q65b6(id v, NSInteger f);
