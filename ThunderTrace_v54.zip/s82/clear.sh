#!/bin/sh
set -e
export THEOS=/var/mobile/theos
cd "$(dirname "$0")" || exit 1
rm -rf /var/root/.cache/clang/ModuleCache
rm -rf /var/mobile/.cache/clang/ModuleCache
rm -rf .theos packages *.deb Ongnongos.dylib Ongnongios1.dylib
make clean || true
chmod +x ./bump_vip_build.sh 2>/dev/null || true
./bump_vip_build.sh
make FINALPACKAGE=1 package
FOUND=""
for DYLIB in $(find .theos -name "Ongnongos.dylib" -type f 2>/dev/null); do
    FOUND="$DYLIB"
    echo "[SIZE] Found: $DYLIB"
    ls -lh "$DYLIB"
    strip -S -x "$DYLIB" 2>/dev/null || true
    sh ./vfy.sh "$DYLIB"
    ldid -S "$DYLIB" 2>/dev/null || true
    ls -lh "$DYLIB"
done
if [ -n "$FOUND" ] && [ -f "$FOUND" ]; then
    cp -f "$FOUND" ./Ongnongios1.dylib
    cp -f ./Ongnongios1.dylib ./Ongnongos.dylib
    echo "[DYLIB] ./Ongnongios1.dylib"
    ls -lh ./Ongnongios1.dylib
    echo "[VERIFY_COMPAT] ./Ongnongos.dylib"
    ls -lh ./Ongnongos.dylib
fi
if ls packages/*.deb >/dev/null 2>&1; then
    echo "[DEB]"
    ls -lh packages/*.deb
fi
echo "[DONE] Build xong, chưa cài vào máy."
