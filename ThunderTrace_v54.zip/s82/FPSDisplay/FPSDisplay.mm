#import "../Core/OngnongSecureStrings.h"
#import "../Core/OngnongOxorany.h"
#import "../Core/zx8f1a_gate.h"
#import "FPSDisplay.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


static UIColor *FPSMainMenuColor(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat r = [ud objectForKey:OX_NS("om_theme_r")] ? [ud floatForKey:OX_NS("om_theme_r")] : 34.0 / 255.0;
    CGFloat g = [ud objectForKey:OX_NS("om_theme_g")] ? [ud floatForKey:OX_NS("om_theme_g")] : 54.0 / 255.0;
    CGFloat b = [ud objectForKey:OX_NS("om_theme_b")] ? [ud floatForKey:OX_NS("om_theme_b")] : 88.0 / 255.0;
    CGFloat a = [ud objectForKey:OX_NS("om_theme_a")] ? [ud floatForKey:OX_NS("om_theme_a")] : 0.86;
    r = MAX(0.0, MIN(1.0, r));
    g = MAX(0.0, MIN(1.0, g));
    b = MAX(0.0, MIN(1.0, b));
    a = MAX(0.30, MIN(1.0, a));
    return [UIColor colorWithRed:r green:g blue:b alpha:a];
}

static void FPSApplyMainMenuTheme(UILabel *label) {
    if (!label) return;
    label.textColor = [UIColor whiteColor];
    label.backgroundColor = FPSMainMenuColor();
    label.layer.borderColor = [UIColor colorWithRed:82.0 / 255.0 green:211.0 / 255.0 blue:1.0 alpha:1.0].CGColor;
    label.layer.shadowColor = [UIColor clearColor].CGColor;
    label.layer.shadowOpacity = 0.0;
}

@interface Za5b7ad7389 ()
@property (strong, nonatomic) UILabel *q8m2v5;
@property (strong, nonatomic) CADisplayLink *link;
@property (assign, nonatomic) NSInteger count;
@property (assign, nonatomic) NSTimeInterval a9q1d7;

@property (strong, nonatomic) CAGradientLayer *r4c9p1;
@property (strong, nonatomic) CATextLayer *d7x3n6;

@property (copy, nonatomic) NSString *k2v8m4;
@end

@implementation Za5b7ad7389

+ (instancetype)z24320fade0 {
    static Za5b7ad7389 *shareDisplay;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareDisplay = [[Za5b7ad7389 alloc] init];
    });
    return shareDisplay;
}

+ (void)load {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [Za5b7ad7389 z24320fade0];
    });
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self z66531018df];
    }
    return self;
}

- (UIWindow *)f6p3x8 {
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if (scene.activationState != UISceneActivationStateForegroundActive) continue;
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            UIWindowScene *ws = (UIWindowScene *)scene;
            for (UIWindow *w in ws.windows) {
                if (w.isKeyWindow) return w;
            }
            if (ws.windows.count) return ws.windows.firstObject;
        }
    }
    UIWindow *kw = [UIApplication sharedApplication].keyWindow;
    if (kw) return kw;
    return [UIApplication sharedApplication].windows.firstObject;
}

- (CGFloat)h4m9c2 {
    return 30.0;
}

- (void)t7v1q5 {
    UIWindow *w = [self f6p3x8];
    if (!w) return;

    NSString *text = self.k2v8m4 ?: [NSString string];
    UIFont *font = self.q8m2v5.font;

    CGSize fit = [text sizeWithAttributes:@{NSFontAttributeName: font}];
    CGFloat screenW = CGRectGetWidth(w.bounds);
    CGFloat maxWidth = MAX(120.0, screenW - 20.0);
    CGFloat width = MIN(ceil(fit.width) + 16.0, maxWidth);
    CGFloat x = floor((screenW - width) * 0.5);

    CGFloat y = CGRectGetHeight(w.bounds) - [self h4m9c2] - 10.0;

    self.q8m2v5.frame = CGRectMake(x, y, width, [self h4m9c2]);

    if (self.r4c9p1) self.r4c9p1.frame = self.q8m2v5.bounds;
    if (self.d7x3n6) self.d7x3n6.frame = self.q8m2v5.bounds;
}

- (void)z66531018df {

    self.q8m2v5 = [[UILabel alloc] initWithFrame:CGRectZero];
    self.q8m2v5.textAlignment = NSTextAlignmentCenter;
    self.q8m2v5.numberOfLines = 1;
    self.q8m2v5.adjustsFontSizeToFitWidth = YES;
    self.q8m2v5.minimumScaleFactor = 0.68;
    self.q8m2v5.lineBreakMode = NSLineBreakByClipping;

    self.q8m2v5.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightBlack];
    FPSApplyMainMenuTheme(self.q8m2v5);
    self.q8m2v5.layer.cornerRadius = 12.0;
    if (@available(iOS 13.0, *)) self.q8m2v5.layer.cornerCurve = kCACornerCurveContinuous;
    self.q8m2v5.layer.masksToBounds = YES;
    self.q8m2v5.layer.borderWidth = 1.2;
    FPSApplyMainMenuTheme(self.q8m2v5);
    self.q8m2v5.layer.shadowRadius = 0.0;
    self.q8m2v5.layer.shadowOffset = CGSizeZero;

    self.r4c9p1 = nil;
    self.d7x3n6 = nil;

    [UIDevice currentDevice].batteryMonitoringEnabled = YES;

    UIWindow *w = [self f6p3x8];
    if (w) [w addSubview:self.q8m2v5];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(zFPSVisibilityChanged:) name:OX_NS("ongnong_fps_visibility_changed") object:nil];
    self.q8m2v5.hidden = !Ongnong::Zx8fFPSVisible();

    self.k2v8m4 = [NSString string];
    [self t7v1q5];

    [self zb2361d47b8];
}

- (void)zFPSVisibilityChanged:(NSNotification *)note {
    (void)note;
    self.q8m2v5.hidden = !Ongnong::Zx8fFPSVisible();
}

- (void)zb2361d47b8 {
    self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(n3d8k6:)];
    if (@available(iOS 10.0, *)) self.link.preferredFramesPerSecond = 15;
    [self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)n3d8k6:(CADisplayLink *)link {
    if (self.a9q1d7 == 0) {
        self.a9q1d7 = link.timestamp;
        return;
    }

    self.count++;
    NSTimeInterval delta = link.timestamp - self.a9q1d7;

    if (delta >= 1.0) {
        float fps = self.count / delta;
        self.count = 0;
        self.a9q1d7 = link.timestamp;
        [self za0e7c648c3:fps];
    }
}

- (void)za0e7c648c3:(float)fps {

    self.q8m2v5.hidden = !Ongnong::Zx8fFPSVisible();
    if (self.q8m2v5.hidden) return;

    double batLeft = (double)[UIDevice currentDevice].batteryLevel * 100.0;
    if (batLeft < 0) batLeft = 0;

    NSString *dateStr = [self z6ca2dbc5ef];

    NSString *footerName = Ongnong::Zx8fUILabel(OX_NS("footer_name"), OX_NS("ONGNONG.io.vn"));
    NSString *footerPin = Ongnong::Zx8fUILabel(OX_NS("footer_pin"), OX_NS("Pin"));
    NSString *text = [NSString stringWithFormat:OX_NS("%@  %@  %@: %0.0f"),
                      footerName, dateStr, footerPin, batLeft];

    self.k2v8m4 = text;

    UIColor *cyanColor = [UIColor colorWithRed:37.0 / 255.0
                                          green:224.0 / 255.0
                                           blue:1.0
                                          alpha:1.0];
    UIColor *pinkColor = [UIColor colorWithRed:1.0
                                          green:82.0 / 255.0
                                           blue:218.0 / 255.0
                                          alpha:1.0];

    NSMutableAttributedString *coloredText =
        [[NSMutableAttributedString alloc] initWithString:text
                                               attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];

    NSRange nameRange = [text rangeOfString:footerName];
    if (nameRange.location != NSNotFound) {
        [coloredText addAttribute:NSForegroundColorAttributeName value:cyanColor range:nameRange];
    }

    NSRange timeRange = [text rangeOfString:dateStr];
    if (timeRange.location != NSNotFound) {
        [coloredText addAttribute:NSForegroundColorAttributeName value:pinkColor range:timeRange];
    }

    NSRange pinRange = [text rangeOfString:footerPin];
    if (pinRange.location != NSNotFound) {
        NSRange fullPinRange = NSMakeRange(pinRange.location, text.length - pinRange.location);
        [coloredText addAttribute:NSForegroundColorAttributeName value:pinkColor range:fullPinRange];
    }

    FPSApplyMainMenuTheme(self.q8m2v5);
    self.q8m2v5.attributedText = coloredText;

    [self t7v1q5];
}

- (NSString *)z6ca2dbc5ef {
    NSDate *currentDate = [NSDate date];
    static NSDateFormatter *df;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        df = [[NSDateFormatter alloc] init];
        [df setDateFormat:qsec_s_0155()];
    });
    return [df stringFromDate:currentDate];
}

@end
