#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Za5b7ad7389 : NSObject
+ (instancetype)z24320fade0;
@end
