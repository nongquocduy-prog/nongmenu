#!/usr/bin/env bash
set -euo pipefail
export THEOS="${THEOS:-$HOME/theos}"
if [[ -f s82/Makefile ]]; then cd s82; fi
rm -rf .theos/obj
make -j2 FINALPACKAGE=1
DYLIB="$(find .theos/obj -type f -name 'KhoiOSHistory.dylib' -size +0c -print -quit 2>/dev/null || true)"
if [[ -z "$DYLIB" ]]; then
  echo 'ERROR: KhoiOSHistory.dylib not built' >&2
  find .theos -maxdepth 5 -type f 2>/dev/null | sort || true
  exit 2
fi
cp -f "$DYLIB" Ongnongios1.dylib
file Ongnongios1.dylib
