#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#include <string.h>
#include <mach-o/dyld.h>
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"

static NSRecursiveLock *twLock;
static NSMutableArray<NSString *> *twLines;
static unsigned long twSeq=0;
static UITextView *twLiveView=nil;
static UIView *twLivePanel=nil;
static bool twLiveEnabled=true;
static unsigned long twSpinId=0;
static unsigned long twCalls[5]={0,0,0,0,0};
static bool twInstalled[5]={false,false,false,false,false};
static unsigned long twScanCount=0;
static unsigned long twLastReport=0;
static unsigned long twClassSeen[5]={0,0,0,0,0};
static unsigned long twMethodSeen[5]={0,0,0,0,0};
static void twLog(NSString *s) {
    [twLock lock];
    if(!twLines)twLines=[NSMutableArray array];
    [twLines addObject:[NSString stringWithFormat:@"%05lu | %@ | %@",++twSeq,[NSDate date],s?:@""]];
    while(twLines.count>600)[twLines removeObjectAtIndex:0];
    [twLock unlock];
    dispatch_async(dispatch_get_main_queue(), ^{
        if(twLiveView && twLiveEnabled){
            NSUInteger start=twLines.count>18?twLines.count-18:0;
            NSArray *tail=[twLines subarrayWithRange:NSMakeRange(start,twLines.count-start)];
            twLiveView.text=[tail componentsJoinedByString:@"\n"];
            if(twLiveView.text.length) [twLiveView scrollRangeToVisible:NSMakeRange(twLiveView.text.length-1,1)];
        }
    });
}
static NSString *twCopy(void) {
    [twLock lock];
    NSString *s=[[twLines copy] componentsJoinedByString:@"\n"];
    [twLock unlock];
    return [@"ONGNONG THUNDER SPIN TRACE V90\n" stringByAppendingString:s?:@""];
}
static NSString *twManagedString(void *p) {
    if(!p)return @"(null)";
    uint32_t len=*(uint32_t *)((uint8_t *)p+0x10);
    if(len>512)return @"(invalid-length)";
    return [[NSString alloc]initWithCharacters:(const unichar *)((uint8_t *)p+0x14) length:len]?:@"(decode-failed)";
}
static void *twField(void *p,size_t off){return p?*(void **)((uint8_t *)p+off):nullptr;}
static void twEventData(void *data,NSString *source){
    if(!data){twLog([NSString stringWithFormat:@"EVENT_DATA %@ null",source]);return;}
    NSString *eid=twManagedString(twField(data,0x10));
    NSString *name=twManagedString(twField(data,0x18));
    NSString *sub=twManagedString(twField(data,0x20));
    NSString *parent=twManagedString(twField(data,0x48));
    NSString *group=twManagedString(twField(data,0x50));
    NSString *eventName=twManagedString(twField(data,0x68));
    twLog([NSString stringWithFormat:@"EVENT_ID source=%@ id=%@ name=%@ subtype=%@ eventName=%@ parent=%@ group=%@ data=%p",source,eid,name,sub,eventName,parent,group,data]);
}
static void (*origEventCtor)(void *,void *,void *,void *,void *,void *,void *,void *,void *,void *,void *,const void *);
static void twEventCtor(void *self,void *data,void *message,void *analytics,void *loader,void *reporter,void *controller,void *error,void *service,void *tracking,void *signal,const void *method){
    twCalls[0]++;
    twEventData(data,@"ThunderSpinEvent.ctor");
    origEventCtor(self,data,message,analytics,loader,reporter,controller,error,service,tracking,signal,method);
    twLog([NSString stringWithFormat:@"THUNDER_EVENT_CREATED instance=%p controller=%p",self,controller]);
}
static void (*origEventInvoke)(void *,void *,const void *);
static void twEventInvoke(void *self,void *callback,const void *method){
    twCalls[1]++;twLog([NSString stringWithFormat:@"THUNDER_EVENT_INVOKE instance=%p",self]);
    origEventInvoke(self,callback,method);
}
static void (*origPluginUpdate)(void *,void *,const void *);
static void twPluginUpdate(void *self,void *data,const void *method){
    twCalls[2]++;twLog([NSString stringWithFormat:@"THUNDER_PLUGIN_DATA controller=%p plugin=%p",self,data]);
    origPluginUpdate(self,data,method);
}
static void *(*origOpen)(void *,bool,const void *);
static void *twOpen(void *self,bool validate,const void *method){
    twCalls[3]++;twLog([NSString stringWithFormat:@"THUNDER_OPEN controller=%p validate=%d",self,(int)validate]);
    return origOpen(self,validate,method);
}
static void (*origBalanceUpdate)(void *,void *,const void *);
static void twBalanceUpdate(void *self,void *other,const void *method){
    NSString *sub=twManagedString(twField(other,0x20));
    NSString *name=twManagedString(twField(other,0x18));
    NSString *joined=[[sub stringByAppendingString:@" "] stringByAppendingString:name];
    if([joined localizedCaseInsensitiveContainsString:@"thunder"] || [joined localizedCaseInsensitiveContainsString:@"token"]){
        twCalls[4]++;twEventData(other,@"SpecialEventBalanceData.Update");
    }
    origBalanceUpdate(self,other,method);
}
static void twInstall(void){
    const char *names[]={".ctor","Invoke","DataUpdateEventHandler","TryActivateOnOpen","Update"};
    const char *spaces[]={"MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin",""};
    const char *classes[]={"ThunderSpinEvent","ThunderSpinEvent","ThunderSpinController","ThunderSpinController","SpecialEventBalanceData"};
    const int counts[]={10,1,1,1,1};
    const uintptr_t rvas[]={0x38D0D8C,0x38D0E10,0x38C96DC,0x38CB7A0,0x31BE05C};
    void *hooks[]={(void *)twEventCtor,(void *)twEventInvoke,(void *)twPluginUpdate,(void *)twOpen,(void *)twBalanceUpdate};
    void **originals[]={(void **)&origEventCtor,(void **)&origEventInvoke,(void **)&origPluginUpdate,(void **)&origOpen,(void **)&origBalanceUpdate};
    twScanCount++;
    for(int i=0;i<5;i++){
        if(twInstalled[i])continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage(spaces[i],classes[i],&img);
        if(!klass||!img){if(twScanCount==1||twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s.%s class_missing",classes[i],names[i]]);continue;}
        MethodInfo *mi=Il2CppFindMethodInfoRaw(img,spaces[i],classes[i],names[i],counts[i],false);
        if(!mi||!mi->methodPointer){if(twScanCount==1||twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s.%s method_missing",classes[i],names[i]]);continue;}
        Dl_info info={0};bool mapped=dladdr(mi->methodPointer,&info)!=0;
        uintptr_t offset=mapped?(uintptr_t)mi->methodPointer-(uintptr_t)info.dli_fbase:0;
        twLog([NSString stringWithFormat:@"VERIFY %s.%s offset=0x%llx expected=0x%llx",classes[i],names[i],(unsigned long long)offset,(unsigned long long)rvas[i]]);
        if(!mapped||!info.dli_fname||!strstr(info.dli_fname,"UnityFramework")||offset!=rvas[i]){twLog([NSString stringWithFormat:@"SKIP %s.%s RVA_mismatch",classes[i],names[i]]);continue;}
        int rc=DobbyHook((void *)mi->methodPointer,hooks[i],originals[i]);
        if(rc==0&&*originals[i])twInstalled[i]=true;
        twLog([NSString stringWithFormat:@"HOOK %s.%s status=%d installed=%d",classes[i],names[i],rc,twInstalled[i]]);
    }
    if(twScanCount-twLastReport>=15){twLastReport=twScanCount;twLog([NSString stringWithFormat:@"LIVE_HEARTBEAT scans=%lu hooks=%d%d%d%d%d callbacks=%lu,%lu,%lu,%lu,%lu",twScanCount,twInstalled[0],twInstalled[1],twInstalled[2],twInstalled[3],twInstalled[4],twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4]]);}
}
@interface ONTokenTraceV87Button:UIButton
@end
@implementation ONTokenTraceV87Button
- (void)tap:(id)sender {
    NSString *message=[NSString stringWithFormat:@"Calls: event_ctor=%lu invoke=%lu plugin=%lu open=%lu balance=%lu\n\n%@",twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4],twCopy()];
    twLiveEnabled=!twLiveEnabled;
    if(twLivePanel)twLivePanel.hidden=!twLiveEnabled;
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"THUNDER TRACE V90" message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"COPY" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=message;}]];
    [a addAction:[UIAlertAction actionWithTitle:@"CLOSE" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *vc=self.window.rootViewController;
    if(!vc)return;
    while(vc.presentedViewController)vc=vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)hold:(UILongPressGestureRecognizer *)g {
    if(g.state==UIGestureRecognizerStateBegan){[UIPasteboard generalPasteboard].string=twCopy();twLog(@"TRACE_COPIED");}
}
- (void)drag:(UIPanGestureRecognizer *)g {
    CGPoint p=[g translationInView:self.superview];self.center=CGPointMake(self.center.x+p.x,self.center.y+p.y);[g setTranslation:CGPointZero inView:self.superview];
}
@end
static void twUI(void) {
    UIWindow *w=nil;
    for(UIScene *s in UIApplication.sharedApplication.connectedScenes){
        if(![s isKindOfClass:UIWindowScene.class])continue;
        for(UIWindow *x in ((UIWindowScene *)s).windows)if(x.isKeyWindow){w=x;break;}
        if(w)break;
    }
    if(!w)w=UIApplication.sharedApplication.keyWindow;
    if(!w)return;
    if([w viewWithTag:8172026]){
        if(twLivePanel && !twLivePanel.superview)[w addSubview:twLivePanel];
        return;
    }
    ONTokenTraceV87Button *b=[ONTokenTraceV87Button buttonWithType:UIButtonTypeSystem];
    b.tag=8172026;b.frame=CGRectMake(12,170,116,36);
    b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.78];b.layer.cornerRadius=9;
    [b setTitle:@"THUNDER TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [b addTarget:b action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
    [b addGestureRecognizer:[[UILongPressGestureRecognizer alloc]initWithTarget:b action:@selector(hold:)]];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc]initWithTarget:b action:@selector(drag:)]];
    [w addSubview:b];
    if(!twLivePanel){
        CGFloat width=MIN(w.bounds.size.width-24,390);
        UIView *panel=[[UIView alloc]initWithFrame:CGRectMake(12,215,width,235)];
        panel.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.87];
        panel.layer.cornerRadius=9;
        panel.clipsToBounds=YES;
        UILabel *head=[[UILabel alloc]initWithFrame:CGRectMake(9,4,width-18,22)];
        head.text=@"LIVE THUNDER SPIN • V90";
        head.textColor=[UIColor colorWithRed:0.5 green:1 blue:0.7 alpha:1];
        head.font=[UIFont boldSystemFontOfSize:12];
        [panel addSubview:head];
        UITextView *view=[[UITextView alloc]initWithFrame:CGRectMake(5,27,width-10,203)];
        view.backgroundColor=[UIColor clearColor];
        view.textColor=UIColor.whiteColor;
        view.font=[UIFont monospacedSystemFontOfSize:9 weight:UIFontWeightRegular];
        view.editable=NO;
        view.selectable=YES;
        [panel addSubview:view];
        twLiveView=view;twLivePanel=panel;
        [w addSubview:panel];
    }
}
__attribute__((constructor))static void twStart(void) {
    twLock=[NSRecursiveLock new];twLines=[NSMutableArray array];
    twLog(@"START V90 ThunderSpin controller/pointer live trace");
    dispatch_async(dispatch_get_main_queue(),^{twUI();});
    dispatch_source_t timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC),2*NSEC_PER_SEC,250*NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer,^{twInstall();twUI();});
    dispatch_resume(timer);
    static dispatch_source_t retainedTimer;
    retainedTimer=timer;
}
