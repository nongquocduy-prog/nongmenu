#import "QrLightningTrace.h"
#import "OngnongSecureStrings.h"
#import "OngnongOxorany.h"
#import "OngnongState.h"
#import "Qr73c.h"
#import "zx8f1a_gate.h"
#import <UIKit/UIKit.h>

namespace Ongnong {

State zce119e8048 = {
    true,
    true,
    false,
    false,
    true,
    false,
    false,
    false,
    ((float)qsec_num(9, 0x11D)),
    30,
    {0, 0, 0, 0, 0, 0, 0, 0},
    {}
};

NSString *Z973e694cc8 = nil;
NSString *Zefaf4f9e5d = nil;
NSString *Z1e3f87b2aa = nil;
NSString *Z9a421e103d = nil;
NSString *Z02a7e13d91 = nil;
NSString *Z6a3e9c1d74 = nil;

void ZPotionTrace(NSString *event) {
    (void)event;
}

NSString *ZPotionTraceCopy() {
    return @"";
}

static BOOL Zb6a0d43c2f = NO;
static uint64_t Z7613e6b66b = 0;
static uint64_t Z926c56d6e2 = 0;
static NSTimeInterval Zd3e9be50f4 = 0;
static BOOL Z67c2e74b92 = NO;
static uint64_t Z67e41c8a30 = 0;
static BOOL Zb0ac7d3f19 = NO;
static uint64_t Z1f84ad72be = 0;
static BOOL Z4d2a8f7c31 = NO;
static uint64_t Z8b6e1c4a29 = 0;
static uint64_t Z2b0bff1030 = 0;
static NSTimeInterval Z5b8e90fc22 = 0;

static BOOL Z8eaebf6ee5 = NO;
static BOOL Zc91e7b4a20 = NO;
static const size_t ZHistoryMaxRows = 22;

static NSArray *Z2b91f80eaa(const std::vector<int> &items);

static NSString *Z5b3cd5a3b8(void) {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *dir = paths.count ? paths.firstObject : NSHomeDirectory();
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return [dir stringByAppendingPathComponent:OX_NS("OngnongState.plist")];
}

static NSString *Z91caa81a6f(void) {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *dir = paths.count ? paths.firstObject : NSHomeDirectory();
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return [dir stringByAppendingPathComponent:qsec_s_0157()];
}

static BOOL Z0db75c859f(void) {
    for (int i = 0; i < Za94c0d401a; i++) {
        if (!zce119e8048.zf791f4202f[i].empty()) return YES;
    }
    return NO;
}

static NSArray *Z4da0b7cf29(void) {
    NSMutableArray *history = [NSMutableArray array];
    for (int i = 0; i < Za94c0d401a; i++) [history addObject:Z2b91f80eaa(zce119e8048.zf791f4202f[i])];
    return history;
}

static void Z0c16b3d3e5(void) {
    NSString *path = Z91caa81a6f();
    if (!Z0db75c859f()) return;
    NSDictionary *pack = @{ OX_NS("history"): Z4da0b7cf29(), OX_NS("time"): @([NSDate timeIntervalSinceReferenceDate]) };
    [pack writeToFile:path atomically:YES];
}

static BOOL Z3fe5de1f85(void) {
    if (Z0db75c859f()) return NO;
    NSDictionary *pack = [NSDictionary dictionaryWithContentsOfFile:Z91caa81a6f()];
    if (![pack isKindOfClass:[NSDictionary class]]) return NO;
    NSArray *history = pack[OX_NS("history")];
    if (![history isKindOfClass:[NSArray class]]) return NO;
    BOOL loaded = NO;
    for (int i = 0; i < Za94c0d401a && i < (int)history.count; i++) {
        NSArray *items = history[i];
        if (![items isKindOfClass:[NSArray class]]) continue;
        zce119e8048.zf791f4202f[i].clear();
        for (NSNumber *n in items) {
            if (![n isKindOfClass:[NSNumber class]]) continue;
            zce119e8048.zf791f4202f[i].push_back(n.intValue);
            if (zce119e8048.zf791f4202f[i].size() >= ZHistoryMaxRows) break;
        }
        if (!zce119e8048.zf791f4202f[i].empty()) loaded = YES;
    }
    return loaded;
}

static NSArray *Z2b91f80eaa(const std::vector<int> &items) {
    NSMutableArray *arr = [NSMutableArray array];
    for (int v : items) [arr addObject:@(v)];
    return arr;
}

static void Z69a2baf5f1(void) {
    NSMutableArray *counts = [NSMutableArray array];
    for (int i = 0; i < Za94c0d401a; i++) {
        [counts addObject:@(zce119e8048.zc9f4191bf8[i])];
    }
    NSDictionary *pack = @{ OX_NS("counts"): counts, OX_NS("history"): Z4da0b7cf29(), OX_NS("time"): @([NSDate timeIntervalSinceReferenceDate]) };
    [pack writeToFile:Z5b3cd5a3b8() atomically:YES];
    Z0c16b3d3e5();
}


static BOOL Z31e4065e0e(void) {
    NSDictionary *pack = [NSDictionary dictionaryWithContentsOfFile:Z5b3cd5a3b8()];
    if (![pack isKindOfClass:[NSDictionary class]]) return NO;
    BOOL loaded = NO;
    NSArray *counts = pack[OX_NS("counts")];
    if ([counts isKindOfClass:[NSArray class]]) {
        loaded = YES;
        for (int i = 0; i < Za94c0d401a && i < (int)counts.count; i++) {
            NSNumber *n = counts[i];
            if ([n isKindOfClass:[NSNumber class]]) zce119e8048.zc9f4191bf8[i] = n.intValue;
        }
    }
    NSArray *history = pack[OX_NS("history")];
    if ([history isKindOfClass:[NSArray class]]) {
        loaded = YES;
        for (int i = 0; i < Za94c0d401a && i < (int)history.count; i++) {
            NSArray *items = history[i];
            if (![items isKindOfClass:[NSArray class]]) continue;
            zce119e8048.zf791f4202f[i].clear();
            for (NSNumber *n in items) {
                if (![n isKindOfClass:[NSNumber class]]) continue;
                zce119e8048.zf791f4202f[i].push_back(n.intValue);
                if (zce119e8048.zf791f4202f[i].size() >= ZHistoryMaxRows) break;
            }
        }
    }
    return loaded;
}


static void Z7e25c57c82(void) {
    if (Z8eaebf6ee5) return;
    Z8eaebf6ee5 = YES;
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserverForName:UIApplicationWillResignActiveNotification object:nil queue:nil usingBlock:^(__unused NSNotification *n) { Z108056b942(); }];
    [nc addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:nil usingBlock:^(__unused NSNotification *n) { Z108056b942(); }];
    [nc addObserverForName:UIApplicationWillTerminateNotification object:nil queue:nil usingBlock:^(__unused NSNotification *n) { Z108056b942(); }];
    [nc addObserverForName:UIApplicationDidReceiveMemoryWarningNotification object:nil queue:nil usingBlock:^(__unused NSNotification *n) { [[NSURLCache sharedURLCache] removeAllCachedResponses]; }];
}

static NSString *Z6f40c3e71b(const unsigned char *buf, NSUInteger len, uint8_t key) {
    if (!buf || len == 0) return [NSString string];
    unsigned char out[96];
    if (len > sizeof(out)) return [NSString string];
    for (NSUInteger i = 0; i < len; i++) out[i] = (unsigned char)(buf[i] ^ (uint8_t)(key + i * 17));
    return [[NSString alloc] initWithBytes:out length:len encoding:NSUTF8StringEncoding] ?: [NSString string];
}

__attribute__((constructor))
static void qsec_init_notifications(void) {
    Z973e694cc8 = qsec_s_0000();
    Zefaf4f9e5d = qsec_s_0001();
    static const unsigned char a[] = {0x32,0x1A,0x20,0xE3,0xD1,0xDB,0xAD,0x8B,0x80,0x80,0x62,0x76,0x5D,0x65,0x7C,0x6E};
    static const unsigned char b[] = {0x15,0xFF,0xC3,0xDD,0xD1,0xBB,0x89,0x9E,0x6C,0x4C,0x4C,0x5C,0x32,0x08,0x5F,0x4B};
    Z1e3f87b2aa = Z6f40c3e71b(a, sizeof(a), 0x5D);
    Z9a421e103d = Z6f40c3e71b(b, sizeof(b), 0x7A);
    static const unsigned char c[] = {0x23,0x33,0x09,0x11,0xff,0xcf,0xd5,0x9c,0xae,0x8e,0xa9,0x62,0x6e,0x5d};
    Z02a7e13d91 = Z6f40c3e71b(c, sizeof(c), 0x4C);
    Z6a3e9c1d74 = OX_NS("ongnong_lightning_counter_reset");
}

static NSString *Key(NSString *name) {
    return [qsec_s_0002() stringByAppendingString:name];
}

static NSString *CountKey(int index) {
    return [NSString stringWithFormat:qsec_s_0003(), index];
}

static NSString *HistoryKey(int index) {
    return [NSString stringWithFormat:qsec_s_0004(), index];
}

static NSString *Zc52a6c4e14(void) {
    return OX_NS("OngnongCounterSaved");
}

static NSString *Zf7a942d309(void) {
    return qsec_s_0156();
}

static BOOL Zdc97561358(NSUserDefaults *ud) {
    if ([ud objectForKey:Zc52a6c4e14()]) return YES;
    for (int i = 0; i < Za94c0d401a; i++) {
        if ([ud objectForKey:CountKey(i)]) return YES;
        if ([ud objectForKey:HistoryKey(i)]) return YES;
    }
    return NO;
}

int Z1562633390(int symbol) {
    if (symbol == qsec_num(3, 0x5C1)) return Z700020a485;
    if (symbol == qsec_num(4, 0x6D4)) return Z124338f2d8;
    if (symbol == qsec_num(30, 0x7B2)) return Z94881eb8d3;
    if (symbol == qsec_num(6, 0x126)) return Z646dcbe562;
    if (symbol == 54) return Zdb004c459e;
    if (symbol == 5) return Zshield5e2026;
    return -1;
}

NSArray<NSNumber *> *Z76e4c1b909(void) {
    NSMutableArray<NSNumber *> *z = [NSMutableArray arrayWithCapacity:7];
    [z addObject:@(Zshield5e2026)];
    [z addObject:@(Z700020a485)];
    [z addObject:@(Z124338f2d8)];
    [z addObject:@(Z94881eb8d3)];
    [z addObject:@(Z646dcbe562)];
    if (Zx8fPotionAllowed()) [z addObject:@(Z2f0c1a9d77)];
    if (Zx8fTokenAllowed()) [z addObject:@(Z87f6d0c11d)];
    if (Zx8fLightningAllowed()) [z addObject:@(Z5d92a7e4c1)];
    return z;
}

int Z76d01f2a88(NSInteger slot) {
    NSArray<NSNumber *> *z = Z76e4c1b909();
    if (slot < 0 || slot >= (NSInteger)z.count) return Z700020a485;
    return z[slot].intValue;
}

BOOL Z76e20b7f66(int index) {
    volatile int k = Z2f0c1a9d77;
    return index == k;
}

BOOL Z76f880a1d(NSInteger slot) {
    return Z76e20b7f66(Z76d01f2a88(slot));
}

BOOL Z76c51b907e(int index) {
    volatile int k = Z87f6d0c11d;
    return index == k;
}

BOOL Z76d7aa0492(NSInteger slot) {
    return Z76c51b907e(Z76d01f2a88(slot));
}

BOOL Z76a9d34c1e(int index) {
    volatile int k = Z5d92a7e4c1;
    return index == k;
}

BOOL Z76b8e20f53(NSInteger slot) {
    return Z76a9d34c1e(Z76d01f2a88(slot));
}

BOOL Z76f45d8a2c(int index) {
    return Z76e20b7f66(index) || Z76c51b907e(index) || Z76a9d34c1e(index);
}

int Ze669ef335a(int index) {
    switch (index) {
        case Zshield5e2026: return 5;
        case Z700020a485: return 3;
        case Z124338f2d8: return 4;
        case Z94881eb8d3: return 30;
        case Z646dcbe562: return 6;
        case Zdb004c459e: return 54;
        default: return 0;
    }
}

NSString *Z57eb159d41(int index) {
    switch (index) {
        case Zshield5e2026: return OX_NS("KHIÊN");
        case Z700020a485: return qsec_s_0005();
        case Z124338f2d8: return qsec_s_0006();
        case Z94881eb8d3: return qsec_s_0007();
        case Z646dcbe562: return qsec_s_0008();
        case Zdb004c459e: return qsec_s_0009();
        case Z2f0c1a9d77: return OX_NS("🧪");
        case Z87f6d0c11d: return OX_NS("⚡");
        case Z5d92a7e4c1: return OX_NS("🔨");
        default: return [NSString string];
    }
}

UIColor *Z07aec8e446(int index) {
    switch (index) {
        case Zshield5e2026: return [UIColor colorWithRed:0.92 green:0.48 blue:0.17 alpha:1.0];
        case Z700020a485: return [UIColor colorWithRed:1.00 green:0.23 blue:0.17 alpha:1.0];
        case Z124338f2d8: return [UIColor colorWithRed:1.00 green:0.65 blue:0.13 alpha:1.0];
        case Z94881eb8d3: return [UIColor colorWithRed:0.24 green:0.83 blue:1.00 alpha:1.0];
        case Z646dcbe562: return [UIColor colorWithRed:0.36 green:1.00 blue:0.30 alpha:1.0];
        case Zdb004c459e: return [UIColor colorWithRed:1.00 green:0.16 blue:0.89 alpha:1.0];
        case Z2f0c1a9d77: return [UIColor colorWithRed:0.65 green:0.35 blue:1.00 alpha:1.0];
        case Z87f6d0c11d: return [UIColor colorWithRed:1.00 green:0.72 blue:0.08 alpha:1.0];
        case Z5d92a7e4c1: return [UIColor colorWithRed:0.35 green:0.88 blue:1.00 alpha:1.0];
        default: return [UIColor whiteColor];
    }
}

NSArray<NSNumber *> *Zd282eb67ef(int index) {
    if (index < 0 || index >= Za94c0d401a) return @[];
    NSMutableArray<NSNumber *> *array = [NSMutableArray array];
    for (int value : zce119e8048.zf791f4202f[index]) {
        [array addObject:@(value)];
    }
    return array;
}

void Z1124fca77a() {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if ([ud objectForKey:Key(qsec_s_0010())]) zce119e8048.z26f020afac = [ud boolForKey:Key(qsec_s_0010())];
    if ([ud objectForKey:Key(qsec_s_0011())]) zce119e8048.z8ba2f43efe = [ud boolForKey:Key(qsec_s_0011())];
    zce119e8048.z7180b46195 = [ud boolForKey:Key(qsec_s_0012())];
    zce119e8048.z54007f39a0 = [ud boolForKey:Key(qsec_s_0013())];
    zce119e8048.zacc65d5e7b = [ud objectForKey:Key(qsec_s_0014())] ? [ud boolForKey:Key(qsec_s_0014())] : true;
    zce119e8048.z904d9bb65a = true;
    zce119e8048.z7377de64e5 = false;
    zce119e8048.zfd92661903 = false;
    [ud setBool:NO forKey:Key(qsec_s_0016())];
    [ud setBool:NO forKey:Key(qsec_s_0017())];
    float savedSpeed = [ud floatForKey:Key(qsec_s_0018())];
    if (savedSpeed >= 0.0f && savedSpeed <= ((float)qsec_num(201, 0x3A5))) zce119e8048.z68593f2227 = savedSpeed > 0.0f ? savedSpeed : ((float)qsec_num(9, 0x11D));
    NSInteger savedTarget = [ud integerForKey:Key(qsec_s_0019())];
    if (savedTarget > 0) zce119e8048.z7fa19172fd = (int)savedTarget;

    BOOL didApplyDefaults = [ud boolForKey:Key(qsec_s_0020())];
    if (!didApplyDefaults) {
        zce119e8048.z68593f2227 = ((float)qsec_num(9, 0x11D));
        zce119e8048.zacc65d5e7b = true;
        zce119e8048.z904d9bb65a = true;
        zce119e8048.z54007f39a0 = false;
        [ud setFloat:zce119e8048.z68593f2227 forKey:Key(qsec_s_0018())];
        [ud setBool:zce119e8048.zacc65d5e7b forKey:Key(qsec_s_0014())];
        [ud setBool:zce119e8048.z904d9bb65a forKey:Key(qsec_s_0015())];
        [ud setBool:zce119e8048.z54007f39a0 forKey:Key(qsec_s_0013())];
        [ud setBool:YES forKey:Key(qsec_s_0020())];
        [ud synchronize];
    }

    BOOL hasCounterState = Zdc97561358(ud);
    NSDictionary *filePack = [NSDictionary dictionaryWithContentsOfFile:Z5b3cd5a3b8()];
    NSTimeInterval fileTime = 0;
    if ([filePack isKindOfClass:[NSDictionary class]]) {
        NSNumber *t = filePack[OX_NS("time")];
        if ([t isKindOfClass:[NSNumber class]]) fileTime = t.doubleValue;
    }
    NSTimeInterval defaultsTime = [ud doubleForKey:Zf7a942d309()];
    BOOL loadedFile = NO;
    if ([filePack isKindOfClass:[NSDictionary class]]) loadedFile = Z31e4065e0e();
    if (loadedFile && hasCounterState && defaultsTime > fileTime) {
        for (int i = 0; i < Za94c0d401a; i++) {
            if ([ud objectForKey:CountKey(i)]) zce119e8048.zc9f4191bf8[i] = (int)[ud integerForKey:CountKey(i)];
        }
    }
    if (!loadedFile) {
        for (int i = 0; i < Za94c0d401a; i++) {
            zce119e8048.zc9f4191bf8[i] = (int)[ud integerForKey:CountKey(i)];
            zce119e8048.zf791f4202f[i].clear();
            NSArray *saved = [ud arrayForKey:HistoryKey(i)];
            if (![saved isKindOfClass:[NSArray class]]) saved = @[];
            for (NSNumber *number in saved) {
                if (![number isKindOfClass:[NSNumber class]]) continue;
                zce119e8048.zf791f4202f[i].push_back(number.intValue);
                if (zce119e8048.zf791f4202f[i].size() >= ZHistoryMaxRows) break;
            }
        }
    } else {
        for (int i = 0; i < Za94c0d401a; i++) {
            if (!zce119e8048.zf791f4202f[i].empty()) continue;
            NSArray *saved = [ud arrayForKey:HistoryKey(i)];
            if (![saved isKindOfClass:[NSArray class]]) continue;
            for (NSNumber *number in saved) {
                if (![number isKindOfClass:[NSNumber class]]) continue;
                zce119e8048.zf791f4202f[i].push_back(number.intValue);
                if (zce119e8048.zf791f4202f[i].size() >= ZHistoryMaxRows) break;
            }
        }
    }
    Z3fe5de1f85();
    Zc91e7b4a20 = YES;
    Z7e25c57c82();
}


void Z108056b942() {
    if (!Zc91e7b4a20) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setBool:zce119e8048.z26f020afac forKey:Key(qsec_s_0010())];
    [ud setBool:zce119e8048.z8ba2f43efe forKey:Key(qsec_s_0011())];
    [ud setBool:zce119e8048.z7180b46195 forKey:Key(qsec_s_0012())];
    [ud setBool:zce119e8048.z54007f39a0 forKey:Key(qsec_s_0013())];
    [ud setBool:zce119e8048.zacc65d5e7b forKey:Key(qsec_s_0014())];
    [ud setBool:zce119e8048.z904d9bb65a forKey:Key(qsec_s_0015())];
    [ud setBool:zce119e8048.z7377de64e5 forKey:Key(qsec_s_0016())];
    [ud setBool:zce119e8048.zfd92661903 forKey:Key(qsec_s_0017())];
    [ud setFloat:zce119e8048.z68593f2227 forKey:Key(qsec_s_0018())];
    [ud setInteger:zce119e8048.z7fa19172fd forKey:Key(qsec_s_0019())];

    for (int i = 0; i < Za94c0d401a; i++) {
        [ud setInteger:zce119e8048.zc9f4191bf8[i] forKey:CountKey(i)];
        NSMutableArray<NSNumber *> *items = [NSMutableArray array];
        for (int value : zce119e8048.zf791f4202f[i]) {
            [items addObject:@(value)];
        }
        [ud setObject:items forKey:HistoryKey(i)];
    }
    [ud setBool:YES forKey:Zc52a6c4e14()];
    [ud setDouble:[NSDate timeIntervalSinceReferenceDate] forKey:Zf7a942d309()];
    [ud synchronize];
    Z69a2baf5f1();
}


static void Z91e65af547(void) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (Z7613e6b66b - Z2b0bff1030 >= 8 || now - Z5b8e90fc22 >= 2.5) {
        Z2b0bff1030 = Z7613e6b66b;
        Z5b8e90fc22 = now;
        Z108056b942();
    }
}


static void Zb4e6a1d2f8(void) {
    if (!Zc91e7b4a20) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    for (int i = 0; i < Za94c0d401a; i++) [ud setInteger:zce119e8048.zc9f4191bf8[i] forKey:CountKey(i)];
    [ud setBool:YES forKey:Zc52a6c4e14()];
    [ud setDouble:[NSDate timeIntervalSinceReferenceDate] forKey:Zf7a942d309()];
    [ud synchronize];
}


uint64_t Z9c4a7f611b() {
    return Z7613e6b66b;
}

static BOOL Z3d96c4407a(uint64_t snap) {
    return snap > 0 && Z7613e6b66b <= snap;
}

void Z2b9185919a() {
    for (int i = 0; i < Za94c0d401a; i++) zce119e8048.zc9f4191bf8[i] = 0;
    Zb6a0d43c2f = NO;
    Z926c56d6e2 = Z7613e6b66b;
    Z108056b942();
    Z8167e05f9c();
}

void Z5eca9eb2c9() {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    for (int i = 0; i < Za94c0d401a; i++) {
        zce119e8048.zf791f4202f[i].clear();
        [ud removeObjectForKey:HistoryKey(i)];
    }
    [[NSFileManager defaultManager] removeItemAtPath:Z91caa81a6f() error:nil];
    Z108056b942();
    [ud synchronize];
    [[NSFileManager defaultManager] removeItemAtPath:Z91caa81a6f() error:nil];
    Z0c16b3d3e5();
    Z8167e05f9c();
}

static void Z62831d89f0x(int index, int extra) {
    if (index < 0 || index >= Za94c0d401a) return;
    int value = zce119e8048.zc9f4191bf8[index] + (extra > 0 ? extra : 0);
    if (zce119e8048.z8ba2f43efe && value > 0) {
        zce119e8048.zf791f4202f[index].insert(zce119e8048.zf791f4202f[index].begin(), value);
        if (zce119e8048.zf791f4202f[index].size() > ZHistoryMaxRows) zce119e8048.zf791f4202f[index].pop_back();
    }
    zce119e8048.zc9f4191bf8[index] = 0;
    Z108056b942();
}

static void Z62831d89f0(int index) {
    Z62831d89f0x(index, 0);
}

static void Zf542ae2b99() {
    if (!Zb6a0d43c2f) return;
    Zb6a0d43c2f = NO;
    Z926c56d6e2 = Z7613e6b66b;
    Zd3e9be50f4 = [NSDate timeIntervalSinceReferenceDate];
    Z62831d89f0(Z2f0c1a9d77);
    Z5b100328e3();
}

void Z33f3ef693d() {
    uint64_t nextSpin = Z7613e6b66b + 1;
    (void)0;
    BOOL usedPotionSkip = NO;
    BOOL usedTokenSkip = NO;
    BOOL usedLightningSkip = NO;
    for (int i = 0; i < Za94c0d401a; i++) {
        if (i == Z2f0c1a9d77 && Z67c2e74b92 && Z67e41c8a30 == nextSpin) {
            usedPotionSkip = YES;
            continue;
        }
        if (i == Z87f6d0c11d && Zb0ac7d3f19 && Z1f84ad72be == nextSpin) {
            usedTokenSkip = YES;
            continue;
        }
        if (i == Z5d92a7e4c1 && Z4d2a8f7c31 && Z8b6e1c4a29 == nextSpin) {
            usedLightningSkip = YES;
            continue;
        }
        zce119e8048.zc9f4191bf8[i]++;
    }
    Z7613e6b66b = nextSpin;
    (void)0;
    if (usedPotionSkip || (Z67c2e74b92 && Z67e41c8a30 <= Z7613e6b66b)) {
        Z67c2e74b92 = NO;
        Z67e41c8a30 = 0;
    }
    if (usedTokenSkip || (Zb0ac7d3f19 && Z1f84ad72be <= Z7613e6b66b)) {
        Zb0ac7d3f19 = NO;
        Z1f84ad72be = 0;
    }
    if (usedLightningSkip || (Z4d2a8f7c31 && Z8b6e1c4a29 <= Z7613e6b66b)) {
        Z4d2a8f7c31 = NO;
        Z8b6e1c4a29 = 0;
    }
    Zf542ae2b99();
    Zb4e6a1d2f8();
    Z91e65af547();
    Z8167e05f9c();
}

void Z74902605ad(int symbol) {
    int index = Z1562633390(symbol);
    if (index == Z5d92a7e4c1) (void)0;
    if (index < 0 || index >= Za94c0d401a) return;
    Z62831d89f0(index);
}

void Za184ac7ef2() {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        if (Z7613e6b66b > Z926c56d6e2 && zce119e8048.zc9f4191bf8[Z2f0c1a9d77] > 0) {
            Z926c56d6e2 = Z7613e6b66b;
            Zd3e9be50f4 = now;
            Zb6a0d43c2f = NO;
            Z62831d89f0(Z2f0c1a9d77);
            R3ng(Z2f0c1a9d77, Z7613e6b66b > 0 ? Z7613e6b66b - 1 : 0);
            Z5b100328e3();
            Z8167e05f9c();
        } else {
            if (Z7613e6b66b == Z926c56d6e2 && now - Zd3e9be50f4 < 0.20) return;
            Zb6a0d43c2f = YES;
        }
    });
}

void Z67a0d1f8e9s(uint64_t snap) {
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL addCurrent = Z3d96c4407a(snap);
        Zb6a0d43c2f = NO;
        Z926c56d6e2 = Z7613e6b66b;
        Zd3e9be50f4 = [NSDate timeIntervalSinceReferenceDate];
        Z62831d89f0x(Z2f0c1a9d77, addCurrent ? 1 : 0);
        R3ng(Z2f0c1a9d77, snap);
        Z5b100328e3();
        Z67c2e74b92 = addCurrent;
        Z67e41c8a30 = addCurrent ? (Z7613e6b66b + 1) : 0;
        Z8167e05f9c();
    });
}

void Z67a0d1f8e9() {
    Z67a0d1f8e9s(0);
}

void Zed58c1f2a6s(uint64_t snap) {
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL addCurrent = Z3d96c4407a(snap);
        Z62831d89f0x(Z87f6d0c11d, addCurrent ? 1 : 0);
        R3ng(Z87f6d0c11d, snap);
        Z4c97f7e81a();
        Zb0ac7d3f19 = addCurrent;
        Z1f84ad72be = addCurrent ? (Z7613e6b66b + 1) : 0;
        Z8167e05f9c();
    });
}

void Zed58c1f2a6() {
    Zed58c1f2a6s(0);
}

void Z3c8e1a6d52s(uint64_t snap) {
    QLT(@"RESET_ENTER snap=%llu", (unsigned long long)snap);
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL addCurrent = Z3d96c4407a(snap);
        QLT(@"RESET_EXEC snap=%llu gapBefore=%ld addCurrent=%d", (unsigned long long)snap, (long)zce119e8048.zc9f4191bf8[Z5d92a7e4c1], (int)addCurrent);
        Z62831d89f0x(Z5d92a7e4c1, addCurrent ? 1 : 0);
        R3ng(Z5d92a7e4c1, snap);
        if (Z6a3e9c1d74) [[NSNotificationCenter defaultCenter] postNotificationName:Z6a3e9c1d74 object:nil];
        Z4d2a8f7c31 = addCurrent;
        Z8b6e1c4a29 = addCurrent ? (Z7613e6b66b + 1) : 0;
        (void)0;
        Z8167e05f9c();
    });
}

void Z3c8e1a6d52() {
    Z3c8e1a6d52s(0);
}

void Z6cb2075a89() {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!Z1e3f87b2aa) return;
        [[NSNotificationCenter defaultCenter] postNotificationName:Z1e3f87b2aa object:nil];
    });
}

void Z5b100328e3() {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!Z9a421e103d) return;
        [[NSNotificationCenter defaultCenter] postNotificationName:Z9a421e103d object:nil];
    });
}

void Z4c97f7e81a() {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!Z02a7e13d91) return;
        [[NSNotificationCenter defaultCenter] postNotificationName:Z02a7e13d91 object:nil];
    });
}

void Z8167e05f9c() {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:Z973e694cc8 object:nil];
    });
}

}
