#import "Qr71b.h"
#import "QrLightningTrace.h"
#import "Qr71a.h"
#import "OngnongState.h"
#import <Foundation/Foundation.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

__attribute__((noinline)) static NSString *q72d(const uint8_t *v, NSUInteger n, uint8_t seed) {
    if (!v || n == 0) return [NSString string];
    uint8_t stack[96];
    uint8_t *out = n <= sizeof(stack) ? stack : (uint8_t *)malloc(n);
    if (!out) return [NSString string];
    for (NSUInteger i = 0; i < n; i++) out[i] = (uint8_t)(v[i] ^ (uint8_t)(seed + (uint8_t)(i * 17)) ^ (uint8_t)(((i * 13) + 0x5B) & 0xFF));
    NSString *s = [[NSString alloc] initWithBytes:out length:n encoding:NSUTF8StringEncoding] ?: [NSString string];
    memset(out, 0, n);
    if (out != stack) free(out);
    return s;
}

static NSString *q72s0(void) {
    static const uint8_t v[] = {0x13,0x3E,0x5B,0xB6,0x8B,0x8E,0x43,0x77,0x00,0x79,0x6B,0x60,0x70,0x6E,0x6D,0x56,0x7B,0x2F,0x6F,0x4C,0x45,0x94,0x81,0x77,0x5A,0x41,0x13};
    return q72d(v, sizeof(v), 0x27);
}
static NSString *q72s1(void) {
    static const uint8_t v[] = {0x77,0x54,0x79,0x98,0x76,0x6D,0x73};
    return q72d(v, sizeof(v), 0x48);
}
static NSString *q72s2(void) {
    static const uint8_t v[] = {0x50,0x73,0x8C,0x6D};
    return q72d(v, sizeof(v), 0x69);
}
static NSString *q72s3(void) {
    static const uint8_t v[] = {0xA4,0x9D,0xB5,0x59};
    return q72d(v, sizeof(v), 0x8B);
}

static NSString *q72k(NSString *account) {
    NSString *safe = account.length ? account : q72s1();
    return [q72s0() stringByAppendingString:safe];
}

static NSMutableDictionary *q72g(NSString *account) {
    id value = [[NSUserDefaults standardUserDefaults] objectForKey:q72k(account)];
    return [value isKindOfClass:[NSDictionary class]] ? [value mutableCopy] : [NSMutableDictionary dictionary];
}

static void q72w(NSString *account, NSMutableDictionary *state) {
    if (![state isKindOfClass:[NSMutableDictionary class]]) return;
    [[NSUserDefaults standardUserDefaults] setObject:state forKey:q72k(account)];
}


static NSString *q72pendingKey(void) { return @"l_pending"; }
static NSString *q72pendingSnapKey(void) { return @"l_pending_snap"; }
static NSString *q72lastHitSnapKey(void) { return @"l_last_hit_snap"; }

static NSInteger q72i(id value, NSInteger fallback) {
    if ([value isKindOfClass:[NSNumber class]]) return [value integerValue];
    if ([value isKindOfClass:[NSString class]] && [value length] > 0) return [value integerValue];
    return fallback;
}

BOOL q71b0(NSArray<Q71N *> *items, NSString *account, uint64_t snap) {
    if (![items isKindOfClass:[NSArray class]] || items.count == 0) return NO;
    NSMutableDictionary *state = q72g(account);
    NSString *barsKey = q72s2();
    id raw = state[barsKey];
    NSMutableDictionary *bars = [raw isKindOfClass:[NSDictionary class]] ? [raw mutableCopy] : [NSMutableDictionary dictionary];
    state[barsKey] = bars;
    BOOL hit = NO;
    NSInteger bestDelta = 0;
    uint64_t nowSpin = Ongnong::Z9c4a7f611b();
    BOOL liveSpin = nowSpin > snap;
    BOOL hasGap = Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z5d92a7e4c1] > 0;

    NSDictionary *pending = [state[q72pendingKey()] isKindOfClass:[NSDictionary class]] ? state[q72pendingKey()] : nil;
    uint64_t pendingSnap = (uint64_t)q72i(state[q72pendingSnapKey()], 0);
    uint64_t lastHitSnap = (uint64_t)q72i(state[q72lastHitSnapKey()], 0);

    QLT(@"PARSE snap=%llu spin=%llu gap=%ld items=%lu pending=%lu last=%llu", (unsigned long long)snap, (unsigned long long)nowSpin, (long)Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z5d92a7e4c1], (unsigned long)items.count, (unsigned long)pending.count, (unsigned long long)lastHitSnap);

    if (pending.count > 0 && pendingSnap > 0) {
        if (nowSpin > pendingSnap && hasGap && lastHitSnap != pendingSnap) {
            QLT(@"HIT_PENDING snap=%llu pendingSnap=%llu", (unsigned long long)snap, (unsigned long long)pendingSnap);
            hit = YES;
            bestDelta = 1;
            state[q72lastHitSnapKey()] = @(pendingSnap);
            [state removeObjectForKey:q72pendingKey()];
            [state removeObjectForKey:q72pendingSnapKey()];
            (void)0;
        } else {
            (void)0;
        }
    }

    NSMutableDictionary *newPending = [NSMutableDictionary dictionary];
    NSUInteger idx = 0;
    for (Q71N *item in items) {
        if (![item isKindOfClass:[Q71N class]] || item.x0.length == 0 || item.x1 < 0) continue;
        NSInteger previous = q72i(bars[item.x0], -1);
        NSString *shortId = item.x0.length > 52 ? [item.x0 substringFromIndex:item.x0.length - 52] : item.x0;
        QLT(@"ITEM index=%lu id=%@ prev=%ld value=%ld", (unsigned long)idx++, shortId, (long)previous, (long)item.x1);

        if (previous < 0) {
            if (liveSpin && hasGap && !hit && lastHitSnap != snap) {
                QLT(@"HIT_FIRST_SEEN snap=%llu", (unsigned long long)snap);
                hit = YES;
                bestDelta = 1;
                if (snap > 0) state[q72lastHitSnapKey()] = @(snap);
                (void)0;
            } else if (!liveSpin && snap > 0 && item.x1 > 0) {
                newPending[item.x0] = @(item.x1);
                (void)0;
            }
        } else if (item.x1 > previous) {
            NSInteger delta = item.x1 - previous;
            QLT(@"HIT_INCREASE delta=%ld", (long)delta);
            if (!hit || delta > bestDelta) {
                hit = YES;
                bestDelta = delta;
            }
            if (snap > 0 && lastHitSnap != snap) {
                state[q72lastHitSnapKey()] = @(snap);
                lastHitSnap = snap;
                (void)0;
            }
            (void)0;
        } else if (item.x1 < previous) {
            NSInteger decrease = previous - item.x1;
            QLT(@"DECREASE delta=%ld", (long)decrease);
            (void)0;

            if (snap > 0 && decrease > 0 && hasGap && lastHitSnap != snap) {
                newPending[item.x0] = @(item.x1);
                (void)0;
            } else {
                (void)0;
            }
        }
        bars[item.x0] = @(item.x1);
    }

    if (newPending.count > 0 && !hit) {
        state[q72pendingKey()] = newPending;
        state[q72pendingSnapKey()] = @(snap);
        (void)0;
    } else if (hit) {
        [state removeObjectForKey:q72pendingKey()];
        [state removeObjectForKey:q72pendingSnapKey()];
    }

    if (bars.count > 96) {
        NSMutableDictionary *trimmed = [NSMutableDictionary dictionary];
        for (Q71N *item in items) if (item.x0.length && item.x1 >= 0) trimmed[item.x0] = @(item.x1);
        bars = trimmed;
        state[barsKey] = bars;
        (void)0;
    }

    state[q72s3()] = @([NSDate timeIntervalSinceReferenceDate]);
    q72w(account, state);
    (void)0;
    QLT(@"PARSE_RESULT hit=%d delta=%ld snap=%llu", (int)hit, (long)bestDelta, (unsigned long long)snap);
    return hit;
}

BOOL q71b1(NSString *account, uint64_t snap, NSInteger countAtParse) {
    if (snap == 0 || countAtParse <= 0) return NO;
    NSMutableDictionary *state = q72g(account);
    uint64_t nowSpin = Ongnong::Z9c4a7f611b();
    NSInteger countNow = Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z5d92a7e4c1];
    uint64_t lastHitSnap = (uint64_t)q72i(state[q72lastHitSnapKey()], 0);
    NSDictionary *pending = [state[q72pendingKey()] isKindOfClass:[NSDictionary class]] ? state[q72pendingKey()] : nil;

    BOOL spinAdvanced = nowSpin > snap;
    BOOL countAdvanced = countNow > countAtParse;
    BOOL sameHit = lastHitSnap == snap;
    BOOL canConfirm = spinAdvanced && countAdvanced && !sameHit && pending.count == 0;

    (void)0;

    QLT(@"RETRY_CONFIRM snap=%llu spin=%llu countBefore=%ld countNow=%ld pending=%lu same=%d confirm=%d", (unsigned long long)snap, (unsigned long long)nowSpin, (long)countAtParse, (long)countNow, (unsigned long)pending.count, (int)sameHit, (int)canConfirm);
    if (!canConfirm) return NO;

    state[q72lastHitSnapKey()] = @(snap);
    [state removeObjectForKey:q72pendingKey()];
    [state removeObjectForKey:q72pendingSnapKey()];
    state[q72s3()] = @([NSDate timeIntervalSinceReferenceDate]);
    q72w(account, state);
    (void)0;
    return YES;
}

BOOL q71b2(NSString *account, uint64_t snap) {
    if (snap == 0) return NO;
    NSMutableDictionary *state = q72g(account);
    uint64_t lastHitSnap = (uint64_t)q72i(state[q72lastHitSnapKey()], 0);
    return lastHitSnap == snap;
}
