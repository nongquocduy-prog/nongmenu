#pragma once
#import <Foundation/Foundation.h>
#include <stdarg.h>
static inline void QLT(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    @synchronized([NSUserDefaults standardUserDefaults]) {
        NSString *line = [NSString stringWithFormat:@"%.3f %@\n", [NSDate timeIntervalSinceReferenceDate], msg];
        NSLog(@"LIGHTNING_TRACE %@", msg);
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        NSString *old = [ud stringForKey:@"ongnong_lightning_trace"] ?: @"";
        NSString *next = [old stringByAppendingString:line];
        if (next.length > 40000) next = [next substringFromIndex:next.length - 30000];
        [ud setObject:next forKey:@"ongnong_lightning_trace"];
        NSString *dir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        if (dir.length) [next writeToFile:[dir stringByAppendingPathComponent:@"LightningTrace.txt"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
}
