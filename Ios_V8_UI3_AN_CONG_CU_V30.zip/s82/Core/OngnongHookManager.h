#pragma once

namespace Ongnong {
void InstallHooks();
void Z2c1f8801fd();

bool AutoBuildModuleIsEnabled();
bool AutoBuildModuleIsPending();
void AutoBuildModuleSetEnabled(bool enabled);
void AutoBuildModuleToggle();

bool AutoPigModuleIsEnabled();
void AutoPigModuleSetEnabled(bool enabled);
void AutoPigModuleToggle();
bool AutoHammerModuleIsEnabled();
void AutoHammerModuleSetEnabled(bool enabled);
void AutoHammerModuleToggle();
bool RaidHammerModuleIsEnabled();
void RaidHammerModuleSetEnabled(bool enabled);
void RaidHammerModuleToggle();
void BetCycleRaidAutoSync();

bool MagicCardsModuleIsEnabled();
void MagicCardsModuleSetEnabled(bool enabled);
void MagicCardsModuleToggle();

void HBMagicChestToggleAutoFromButton();
bool HBMagicChestIsAutoEnabled();

bool StopSpinForAutoTarget();
bool SetSlotBetStateForCycle(int state);
int GetSlotBetStateForCycle();
bool SlotIsSpinningForCycle();
bool PauseAutoSpinForCycle();
bool StartAutoSpinForCycle();
bool AutoMergeTryCollectPendingReward();
}
