#!/usr/bin/env bash
set -euo pipefail
find . -type f -name 'KhoiOSHistory.dylib' -size +0c -print -quit | grep -q .
