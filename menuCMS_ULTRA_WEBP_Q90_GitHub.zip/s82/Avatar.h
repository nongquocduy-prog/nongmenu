#ifndef AvatarImage_h
#define AvatarImage_h
#define AvatarImage @""
#endif
