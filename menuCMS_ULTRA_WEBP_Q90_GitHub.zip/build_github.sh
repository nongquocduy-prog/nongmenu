#!/usr/bin/env bash
set -euo pipefail
export THEOS="${THEOS:-$HOME/theos}"
if [[ -f s82/Makefile ]]; then cd s82; fi
if [[ ! -f libwebp_ios.a ]]; then
  SRC_DIR="${RUNNER_TEMP:-/tmp}/libwebp-source"
  git clone --depth 1 --branch v1.5.0 https://github.com/webmproject/libwebp.git "$SRC_DIR"
  SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
  CC="$(xcrun --sdk iphoneos --find clang)"
  OBJ="${RUNNER_TEMP:-/tmp}/webp-objects"
  mkdir -p "$OBJ" webp
  SRC="$SRC_DIR/src"
  while IFS= read -r -d '' file; do
    base="${file#"$SRC/"}"
    obj="$OBJ/${base//\//_}.o"
    "$CC" -arch arm64 -isysroot "$SDK" -miphoneos-version-min=14.0 -Oz -DNDEBUG -DWEBP_USE_THREAD=0 -I"$SRC_DIR" -I"$SRC" -c "$file" -o "$obj"
  done < <(find "$SRC/dec" "$SRC/dsp" "$SRC/utils" -maxdepth 1 -name '*.c' -type f -print0)
  xcrun --sdk iphoneos ar rcs libwebp_ios.a "$OBJ"/*.o
  cp "$SRC/webp/decode.h" "$SRC/webp/types.h" webp/
fi
make clean || true
make -j2 FINALPACKAGE=1
