#include "LoadView/Includes.h"
#include "oxorany/oxorany_include.h"
#import "LoadView/DTTJailbreakDetection.h"
#import "Helper/Mem.h"
#include "font.h"
#include "Helper/font.h"
//#include "Helper/data.h"
#import "FTNotificationIndicator.h"
ImFont* verdana_smol;
ImFont* pixel_big = {};
ImFont* pixel_smol = {};
ImFont* semakin_font = {};
#import "Helper/Hooks.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>