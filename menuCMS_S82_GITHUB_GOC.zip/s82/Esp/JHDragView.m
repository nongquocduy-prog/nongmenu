#import "JHDragView.h"
#import <UIKit/UIKit.h>

@interface JHDragView ()
@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, assign) CGPoint panStartCenter;
@property (nonatomic, assign) CGFloat edgeInset;
@end

@implementation JHDragView

- (instancetype)initWithFrame:(CGRect)frame
{

    if (CGSizeEqualToSize(frame.size, CGSizeZero)) {
        frame.size = CGSizeMake(56, 56); 
    }

    self = [super initWithFrame:frame];
    if (self) {
        self.edgeInset = 10.0; 
        self.backgroundColor = UIColor.clearColor;
        self.clipsToBounds = YES;
        self.userInteractionEnabled = YES;

        _iconView = [[UIImageView alloc] initWithFrame:self.bounds];
        _iconView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _iconView.contentMode = UIViewContentModeScaleAspectFill;
        _iconView.clipsToBounds = YES;
        [self addSubview:_iconView];

        self.layer.cornerRadius = CGRectGetWidth(self.bounds) * 0.5;
        self.alpha = 1.0;

        UIPanGestureRecognizer *pan =
        [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
        pan.maximumNumberOfTouches = 1;
        [self addGestureRecognizer:pan];
    }
    return self;
}

- (instancetype)init
{
    return [self initWithFrame:CGRectMake(0, 0, 56, 56)];
}

#pragma mark - Public
- (void)setIconImage:(UIImage *)image {
    self.iconView.image = image;
}

- (void)setEdgeInsetValue:(CGFloat)inset {
    self.edgeInset = MAX(0.0, inset);
    [self clampToBounds:NO];
}

#pragma mark - Drag
- (void)handlePan:(UIPanGestureRecognizer *)pan
{
    UIView *container = self.superview;
    if (!container) return;

    if (pan.state == UIGestureRecognizerStateBegan) {
        self.panStartCenter = self.center;
    }

    CGPoint t = [pan translationInView:container];
    CGPoint c = CGPointMake(self.panStartCenter.x + t.x,
                            self.panStartCenter.y + t.y);

    UIEdgeInsets safe = UIEdgeInsetsZero;
    if (@available(iOS 11.0, *)) safe = container.safeAreaInsets;

    CGFloat halfW = CGRectGetWidth(self.bounds) * 0.5;
    CGFloat halfH = CGRectGetHeight(self.bounds) * 0.5;

    CGFloat minX = safe.left + self.edgeInset + halfW;
    CGFloat maxX = CGRectGetWidth(container.bounds) - safe.right - self.edgeInset - halfW;
    CGFloat minY = safe.top + self.edgeInset + halfH;
    CGFloat maxY = CGRectGetHeight(container.bounds) - safe.bottom - self.edgeInset - halfH;

    c.x = MIN(MAX(c.x, minX), maxX);
    c.y = MIN(MAX(c.y, minY), maxY);

    self.center = c;
    
}

- (void)didMoveToSuperview {
    [super didMoveToSuperview];
    [self clampToBounds:NO];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.layer.cornerRadius = CGRectGetWidth(self.bounds) * 0.5;
}

- (void)clampToBounds:(BOOL)animated {
    UIView *container = self.superview;
    if (!container) return;

    UIEdgeInsets safe = UIEdgeInsetsZero;
    if (@available(iOS 11.0, *)) safe = container.safeAreaInsets;

    CGFloat halfW = CGRectGetWidth(self.bounds) * 0.5;
    CGFloat halfH = CGRectGetHeight(self.bounds) * 0.5;

    CGPoint c = self.center;
    c.x = MIN(MAX(c.x, safe.left + self.edgeInset + halfW),
              CGRectGetWidth(container.bounds) - safe.right - self.edgeInset - halfW);
    c.y = MIN(MAX(c.y, safe.top + self.edgeInset + halfH),
              CGRectGetHeight(container.bounds) - safe.bottom - self.edgeInset - halfH);

    if (animated) {
        [UIView animateWithDuration:0.2 animations:^{ self.center = c; }];
    } else {
        self.center = c;
    }
}

@end