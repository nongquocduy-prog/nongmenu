
#import <UIKit/UIKit.h>
#import <objc/message.h>
#include "Includes.h"
#include "Obfuscate.h"
#import <objc/runtime.h>

#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^

@interface ImGuiDrawView (SpeedHudToggle)
- (void)toggleSpeedHudFromIcon;
@end

@interface MenuLoad ()
@property (nonatomic, strong) ImGuiDrawView *vna;

- (ImGuiDrawView *)GetImGuiView;
+ (void)updateMenuTouchViewFrame:(CGRect)menuRect;
- (void)initTapGes;
- (void)showMenu;
- (void)closeMenu;
@end

static MenuLoad *extraInfo;
UIButton *InvisibleMenuButton;
UIButton *VisibleMenuButton;
MenuInteraction *menuTouchView;
UITextField *hideRecordTextfield;
UIView *hideRecordView;

static CGRect currentMenuRect = CGRectZero;

@interface MenuInteraction ()
@end

@implementation MenuInteraction

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [[extraInfo GetImGuiView] updateIOWithTouchEvent:event];
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [[extraInfo GetImGuiView] updateIOWithTouchEvent:event];
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [[extraInfo GetImGuiView] updateIOWithTouchEvent:event];
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [[extraInfo GetImGuiView] updateIOWithTouchEvent:event];
}

@end

@implementation MenuLoad

- (ImGuiDrawView *)GetImGuiView
{
    return _vna;
}

+ (void)updateMenuTouchViewFrame:(CGRect)menuRect
{
    if (!menuTouchView)
        return;

    if (!CGRectEqualToRect(currentMenuRect, menuRect)) {
        currentMenuRect = menuRect;
    }

    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *mainView = [UIApplication sharedApplication].keyWindow.rootViewController.view;
        if (!mainView && [UIApplication sharedApplication].windows.count > 0) {
            mainView = [UIApplication sharedApplication].windows[0].rootViewController.view;
        }
        if (!mainView) return;

        if (menuTouchView.superview != mainView) {
            [menuTouchView removeFromSuperview];
            [mainView addSubview:menuTouchView];
        }

        CGFloat padding = 10.0f;
        CGRect expandedRect = CGRectInset(currentMenuRect, -padding, -padding);
        CGRect screenBounds = mainView.bounds;
        expandedRect = CGRectIntersection(expandedRect, screenBounds);
        menuTouchView.frame = expandedRect;
        [mainView bringSubviewToFront:menuTouchView];
    });
}

static void didFinishLaunching(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef info)
{
    timer(1.0)
    {
        extraInfo = [MenuLoad new];
        [extraInfo initTapGes];
        
    });
}

__attribute__((constructor)) static void initialize()
{
    CFNotificationCenterAddObserver(CFNotificationCenterGetLocalCenter(),
                                    NULL,
                                    &didFinishLaunching,
                                    (CFStringRef)UIApplicationDidFinishLaunchingNotification,
                                    NULL,
                                    CFNotificationSuspensionBehaviorDrop);
}


-(void)toggleMenu {
    BOOL isShowing = [ImGuiDrawView isMenuShowing];
    if (isShowing) {
        [self closeMenu];
    } else {
        [self showMenu];
    }
}

- (void)toggleSpeedHud {
    
    if (!self.vna) {
        [self initTapGes];
    }
    (void)self.vna.view; 

    [self.vna toggleSpeedHudFromIcon];

    if (menuTouchView) {
        menuTouchView.frame = CGRectZero;
        menuTouchView.userInteractionEnabled = NO;
        currentMenuRect = CGRectZero;
    }
}

- (void)initTapGes
{
    UIView *mainView = [UIApplication sharedApplication].windows[0].rootViewController.view;
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    CGRect screenBounds = UIScreen.mainScreen.bounds;

    hideRecordTextfield = [[UITextField alloc] init];
    UIView *baseRecordView = [[UIView alloc] initWithFrame:screenBounds];
    [baseRecordView setBackgroundColor:[UIColor clearColor]];
    [baseRecordView setUserInteractionEnabled:YES];
    hideRecordTextfield.secureTextEntry = true;
    [baseRecordView addSubview:hideRecordTextfield];

    CALayer *layer = hideRecordTextfield.layer;
    if ([layer.sublayers.firstObject.delegate isKindOfClass:[UIView class]]) {
        
        hideRecordView = (UIView *)layer.sublayers.firstObject.delegate;
    } else {
        
        hideRecordView = baseRecordView;
    }

    [keyWindow addSubview:hideRecordView];

    if (!_vna) {
        ImGuiDrawView *vc = [[ImGuiDrawView alloc] init];
        _vna = vc;
    }

    [ImGuiDrawView showChange:false];
    [hideRecordView addSubview:_vna.view];

    menuTouchView = [[MenuInteraction alloc] initWithFrame:mainView.frame];
    [mainView addSubview:menuTouchView];

}

-(void)showMenu {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    UIView *mainView = keyWindow.rootViewController.view;
    if (!mainView && [UIApplication sharedApplication].windows.count > 0) {
        mainView = [UIApplication sharedApplication].windows[0].rootViewController.view;
        keyWindow = [UIApplication sharedApplication].windows[0];
    }
    if (!mainView || !keyWindow) return;

    CGRect screenBounds = UIScreen.mainScreen.bounds;

    if (hideRecordView) {
        if (hideRecordView.superview != keyWindow) {
            [hideRecordView removeFromSuperview];
            [keyWindow addSubview:hideRecordView];
        }
        [keyWindow bringSubviewToFront:hideRecordView];

        if (_vna && _vna.view) {
            if (_vna.view.superview != hideRecordView) {
                [_vna.view removeFromSuperview];
                [hideRecordView addSubview:_vna.view];
            }
            [hideRecordView bringSubviewToFront:_vna.view];
        }
    } else {
        
        if (_vna && _vna.view) {
            if (_vna.view.superview != keyWindow) {
                [_vna.view removeFromSuperview];
                [keyWindow addSubview:_vna.view];
            }
            _vna.view.frame = screenBounds;
            [keyWindow bringSubviewToFront:_vna.view];
        }
    }

    if (menuTouchView) {
        if (menuTouchView.superview != mainView) {
            [menuTouchView removeFromSuperview];
            [mainView addSubview:menuTouchView];
        }
        menuTouchView.frame = mainView.bounds;
        menuTouchView.userInteractionEnabled = YES;
        [mainView bringSubviewToFront:menuTouchView];
    }


    [ImGuiDrawView showChange:true];
}

-(void)closeMenu {
    [ImGuiDrawView showChange:false];

    if (menuTouchView) {
        menuTouchView.frame = CGRectZero;
        menuTouchView.userInteractionEnabled = NO;
        currentMenuRect = CGRectZero;
    }
}

@end