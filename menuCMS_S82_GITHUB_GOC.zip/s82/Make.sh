rm -rf /var/root/.cache/clang/ModuleCache
rm -rf .theos/ModuleCache
rm -rf .theos/obj
make clean
make