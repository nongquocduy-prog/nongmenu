// Copyright © 2026 Mr Khói
#import "FPSDisplay.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface FPSDisplay ()
@property (strong, nonatomic) UILabel *displayLabel;
@property (strong, nonatomic) CADisplayLink *link;
@property (assign, nonatomic) NSInteger count;
@property (assign, nonatomic) NSTimeInterval lastTime;

@property (strong, nonatomic) CAGradientLayer *textGradientLayer;
@property (strong, nonatomic) CATextLayer *textMaskLayer;

@property (copy, nonatomic) NSString *cachedText;
@end

@implementation FPSDisplay

+ (instancetype)shareFPSDisplay {
    static FPSDisplay *shareDisplay;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareDisplay = [[FPSDisplay alloc] init];
    });
    return shareDisplay;
}

+ (void)load {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [FPSDisplay shareFPSDisplay];
    });
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self initDisplayLabel];
    }
    return self;
}

#pragma mark - Window

- (UIWindow *)_bestWindow {
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if (scene.activationState != UISceneActivationStateForegroundActive) continue;
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            UIWindowScene *ws = (UIWindowScene *)scene;
            for (UIWindow *w in ws.windows) {
                if (w.isKeyWindow) return w;
            }
            if (ws.windows.count) return ws.windows.firstObject;
        }
    }
    UIWindow *kw = [UIApplication sharedApplication].keyWindow;
    if (kw) return kw;
    return [UIApplication sharedApplication].windows.firstObject;
}

#pragma mark - Layout

- (CGFloat)_labelHeight {
    return 22.0; 
}

- (void)_layoutLabel {
    UIWindow *w = [self _bestWindow];
    if (!w) return;

    NSString *text = self.cachedText ?: @"";
    UIFont *font = self.displayLabel.font;

    CGSize fit = [text sizeWithAttributes:@{NSFontAttributeName: font}];
    CGFloat width = ceil(fit.width) + 14.0;

    CGFloat screenW = CGRectGetWidth(w.bounds);
    CGFloat x = floor((screenW - width) * 0.5);

    
    CGFloat y = CGRectGetHeight(w.bounds) - [self _labelHeight] - 5.0;

    self.displayLabel.frame = CGRectMake(x, y, width, [self _labelHeight]);

    self.textGradientLayer.frame = self.displayLabel.bounds;
    self.textMaskLayer.frame = self.displayLabel.bounds;
}

#pragma mark - Init UI

- (void)initDisplayLabel {

    self.displayLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.displayLabel.textAlignment = NSTextAlignmentCenter;
    self.displayLabel.numberOfLines = 1;

    self.displayLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightBlack];

    self.displayLabel.backgroundColor = [UIColor clearColor];
    self.displayLabel.layer.borderWidth = 0;

    self.displayLabel.layer.shadowColor = [UIColor blackColor].CGColor;
    self.displayLabel.layer.shadowOpacity = 0.7;
    self.displayLabel.layer.shadowRadius = 4;
    self.displayLabel.layer.shadowOffset = CGSizeMake(0, 1);

    self.textGradientLayer = [CAGradientLayer layer];
    self.textGradientLayer.startPoint = CGPointMake(0, 0.5);
    self.textGradientLayer.endPoint   = CGPointMake(1, 0.5);
    self.textGradientLayer.colors = @[
        (id)[UIColor cyanColor].CGColor,
        (id)[UIColor yellowColor].CGColor,
        (id)[UIColor magentaColor].CGColor
    ];
    [self.displayLabel.layer addSublayer:self.textGradientLayer];

    self.textMaskLayer = [CATextLayer layer];
    self.textMaskLayer.contentsScale = [UIScreen mainScreen].scale;
    self.textMaskLayer.alignmentMode = kCAAlignmentCenter;

    UIFont *f = self.displayLabel.font;
    CGFontRef cgFont = CGFontCreateWithFontName((CFStringRef)f.fontName);
    self.textMaskLayer.font = cgFont;
    self.textMaskLayer.fontSize = f.pointSize;
    CGFontRelease(cgFont);

    self.textGradientLayer.mask = self.textMaskLayer;

    [UIDevice currentDevice].batteryMonitoringEnabled = YES;

    UIWindow *w = [self _bestWindow];
    if (w) [w addSubview:self.displayLabel];

    self.cachedText = @"";
    [self _layoutLabel];

    [self initCADisplayLink];
}

#pragma mark - FPS

- (void)initCADisplayLink {
    self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
    [self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)tick:(CADisplayLink *)link {
    if (self.lastTime == 0) {
        self.lastTime = link.timestamp;
        return;
    }

    self.count++;
    NSTimeInterval delta = link.timestamp - self.lastTime;

    if (delta >= 1.0) {
        float fps = self.count / delta;
        self.count = 0;
        self.lastTime = link.timestamp;
        [self updateDisplayLabelText:fps];
    }
}

- (void)updateDisplayLabelText:(float)fps {

    double batLeft = (double)[UIDevice currentDevice].batteryLevel * 100.0;
    if (batLeft < 0) batLeft = 0;

    NSString *dateStr = [self getSystemDate];

    NSString *text = [NSString stringWithFormat:@"0947500021  %@  Pin: %0.0f",
                      dateStr, batLeft];

    self.cachedText = text;

    self.textMaskLayer.string = text;

    [self _layoutLabel];

    static CGFloat t = 0;
    t += 0.03;
    if (t > 1) t = 0;

    self.textGradientLayer.locations = @[@(t-0.3), @(t), @(t+0.3)];
}

- (NSString *)getSystemDate {
    NSDate *currentDate = [NSDate date];
    static NSDateFormatter *df;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"HH:mm:ss"];
    });
    return [df stringFromDate:currentDate];
}

#pragma mark - Visibility Control

- (void)setDisplayHidden:(BOOL)hidden {
    if (self.displayLabel) {
        self.displayLabel.hidden = hidden;
    }
}

@end