
//FPS By Mr Khói

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FPSDisplay : NSObject
+ (instancetype)shareFPSDisplay;
- (void)setDisplayHidden:(BOOL)hidden; 

@end

