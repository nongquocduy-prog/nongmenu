#import "Core/OngnongSecureStrings.h"
#import "Core/OngnongOxorany.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import "Core/OngnongState.h"
#import "Core/OngnongHookManager.h"
#import "Core/OngnongExtras.h"
#import "Helper/Il2cpp.h"
#import "Core/Qr73c.h"
#import "UI/OngnongMenuView.h"
#import "Core/zx8f1a_gate.h"

static void Zx8fShowMenuOnce(NSInteger days) {
    static BOOL shown = NO;
    if (shown) return;
    shown = YES;
    Ongnong::Z75012fe6dc();
    if (days == -2 || days >= 0) Ongnong::Zx8fShowRemainingToast(days);
}

static BOOL Z67d0c5a1e4(void) {
    void *dg = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_domain_get"));
    void *ga = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_domain_get_assemblies"));
    void *ag = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_assembly_get_image"));
    void *in = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_image_get_name"));
    if (!dg || !ga || !ag || !in) return NO;
    typedef void *(*DomainGetFn)(void);
    DomainGetFn domainGet = (DomainGetFn)dg;
    return domainGet && domainGet() != NULL;
}

static void Z67e38ad2c9(void) {
    static BOOL done = NO;
    static NSInteger stable = 0;
    if (done) return;
    if (!Z67d0c5a1e4()) stable = 0;
    else stable++;
    if (stable < 6) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ Z67e38ad2c9(); });
        return;
    }
    Ongnong::InstallHooks();
    if (!Ongnong::AreCoreHooksReady()) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ Z67e38ad2c9(); });
        return;
    }
    done = YES;
    Ongnong::Zx8fMarkRuntimeReady();
    Ongnong::R3nh();
}


__attribute__((constructor)) static void OngnongStart(void) {
    (void)0;
    (void)0;
    dispatch_async(dispatch_get_main_queue(), ^{
        Ongnong::Z1124fca77a();
        Ongnong::Zx8fStart(^(NSInteger days) {
            Zx8fShowMenuOnce(days);
            Ongnong::ExtrasBootstrap();
        });
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        Z67e38ad2c9();
    });
}
