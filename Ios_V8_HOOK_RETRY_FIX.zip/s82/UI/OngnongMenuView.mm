#import "../Core/OngnongSecureStrings.h"
#import "../Core/OngnongOxorany.h"
#import "OngnongUIVault.h"
#import "OngnongMenuView.h"
#import "X4f0a1.h"
#import "../Core/OngnongState.h"
#import "../Core/OngnongHookManager.h"
#import "../Core/OngnongExtras.h"
#import "../Core/R7f5.h"
#import "../Core/R7f4.h"
#import "../Core/zx8f1a_gate.h"
#import "../Core/Qr73c.h"
#import "../Core/Qr74m.h"
#import "../Autoclick/PTFakeMetaTouch.h"
#import <QuartzCore/QuartzCore.h>
#import <CoreImage/CoreImage.h>
#import <math.h>

@interface ZVipPayController : UIViewController
@property (nonatomic, copy) NSString *orderCode;
@property (nonatomic, copy) NSString *statusToken;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, assign) BOOL stopped;
@end

@implementation ZVipPayController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0.07 alpha:0.98];
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    self.stopped = YES;
}
@end

@interface Z5e8402e1b3 : NSObject
+ (void)m4q8v1;
+ (void)d7x2p6:(BOOL)visible;
+ (BOOL)c3n9k5;
@end

using namespace Ongnong;

static const NSInteger ZHistoryVisibleRows = 22;

static CGFloat z067adc83c5(void) {
    CGSize size = UIScreen.mainScreen.bounds.size;
    CGFloat shortSide = MIN(size.width, size.height);
    if (shortSide <= 390.0) return 0.58;
    if (shortSide <= 430.0) return 0.62;
    return 0.70;
}

static CGFloat zb1d8336499(CGFloat base, CGFloat minSize) {
    return MAX(minSize, base * z067adc83c5());
}

static UIColor *RGB(CGFloat r, CGFloat g, CGFloat b) {
    return [UIColor colorWithRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:1.0];
}

static BOOL Zde31f8c6b2(NSInteger idx) {
    if (idx == Z2f0c1a9d77) return Ongnong::Zx8fPotionAllowed();
    if (idx == Z87f6d0c11d) return Ongnong::Zx8fTokenAllowed();
    if (idx == Z5d92a7e4c1) return Ongnong::Zx8fLightningAllowed();
    return YES;
}

static void Z0418c1e0ae(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (@available(iOS 10.0, *)) {
            UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
            [gen prepare];
            [gen impactOccurred];
        }
    });
}

static void ZAutoStopTargetStrongHaptic(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (@available(iOS 10.0, *)) {
            UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleHeavy];
            [gen prepare];
            for (NSInteger i = 0; i < 3; i++) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(i * 0.11 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (@available(iOS 13.0, *)) {
                        [gen impactOccurredWithIntensity:1.0];
                    } else {
                        [gen impactOccurred];
                    }
                });
            }
        }
    });
}

static NSString *Z6ddd40608f(void) {
    return Ongnong::Zx8fUILabel(OX_NS("main_title"), OX_NS("ÔNG NÔNG"));
}

static NSString *ZAltLanguageText(void) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("zh")]) return OX_NS("中文");
    if ([code isEqualToString:OX_NS("th")]) return OX_NS("ไทย");
    if ([code isEqualToString:OX_NS("it")]) return OX_NS("Italiano");
    if ([code isEqualToString:OX_NS("en")]) return OX_NS("English");
    return OX_NS("Việt Nam");
}

static NSString *ZAltLanguageHeaderText(void) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("zh")]) return OX_NS("语言");
    if ([code isEqualToString:OX_NS("th")]) return OX_NS("ภาษา");
    if ([code isEqualToString:OX_NS("it")]) return OX_NS("LINGUA");
    if ([code isEqualToString:OX_NS("en")]) return OX_NS("LANGUAGE");
    return OX_NS("NGÔN NGỮ");
}

static NSString *ZuiServerPick5(NSString *key, NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("vi")]) return Ongnong::Zx8fMenuLabelVI(key, vi);
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return Ongnong::Zx8fMenuLabelVI(key, vi);
}

static NSString *ZuiPick5(NSString *vi, NSString *zh, NSString *th, NSString *it, NSString *en) {
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    if ([code isEqualToString:OX_NS("zh")]) return zh ?: vi;
    if ([code isEqualToString:OX_NS("th")]) return th ?: vi;
    if ([code isEqualToString:OX_NS("it")]) return it ?: vi;
    if ([code isEqualToString:OX_NS("en")]) return en ?: vi;
    return vi ?: OX_NS("");
}

static NSString *ZVipBuyNowText(void) {
    return ZuiServerPick5(OX_NS("buy_vip"), OX_NS("MUA VIP"), OX_NS("购买 VIP"), OX_NS("ซื้อ VIP"), OX_NS("ACQUISTA VIP"), OX_NS("BUY VIP"));
}
static NSString *ZVipVietnamCustomerText(void) {
    return ZuiPick5(OX_NS("🇻🇳 KHÁCH HÀNG VIỆT NAM"), OX_NS("🇻🇳 越南客户"), OX_NS("🇻🇳 ลูกค้าเวียดนาม"), OX_NS("🇻🇳 CLIENTI VIETNAMITI"), OX_NS("🇻🇳 VIETNAM CUSTOMERS"));
}
static NSString *ZVipInternationalCustomerText(void) {
    return ZuiPick5(OX_NS("🌍 KHÁCH HÀNG QUỐC TẾ"), OX_NS("🌍 国际客户"), OX_NS("🌍 ลูกค้าต่างประเทศ"), OX_NS("🌍 CLIENTI INTERNAZIONALI"), OX_NS("🌍 INTERNATIONAL CUSTOMERS"));
}
static NSString *ZVipChoosePlanText(void) {
    return ZuiPick5(OX_NS("CHỌN GÓI VIP"), OX_NS("选择 VIP 套餐"), OX_NS("เลือกแพ็กเกจ VIP"), OX_NS("SCEGLI PACCHETTO VIP"), OX_NS("SELECT VIP PLAN"));
}
static NSString *ZVipCopyText(void) {
    return ZuiPick5(OX_NS("SAO CHÉP"), OX_NS("复制"), OX_NS("คัดลอก"), OX_NS("COPIA"), OX_NS("COPY"));
}
static NSString *ZVipCloseText(void) {
    return ZuiPick5(OX_NS("ĐÓNG"), OX_NS("关闭"), OX_NS("ปิด"), OX_NS("CHIUDI"), OX_NS("CLOSE"));
}
static NSString *ZVipWaitingText(void) {
    return ZuiPick5(OX_NS("Đang chờ thanh toán..."), OX_NS("等待付款..."), OX_NS("กำลังรอการชำระเงิน..."), OX_NS("In attesa del pagamento..."), OX_NS("Waiting for payment..."));
}
static NSString *ZVipActivatedText(void) {
    return ZuiPick5(OX_NS("✓ THANH TOÁN THÀNH CÔNG — VIP ĐÃ ĐƯỢC KÍCH HOẠT"), OX_NS("✓ 支付成功 — VIP 已激活"), OX_NS("✓ ชำระเงินสำเร็จ — เปิด VIP แล้ว"), OX_NS("✓ PAGAMENTO RIUSCITO — VIP ATTIVATO"), OX_NS("✓ PAYMENT SUCCESSFUL — VIP ACTIVATED"));
}
static NSString *ZVipPaidText(void) {
    return ZuiPick5(OX_NS("Đã nhận thanh toán, đang kích hoạt VIP..."), OX_NS("已收到付款，正在激活 VIP..."), OX_NS("รับชำระเงินแล้ว กำลังเปิด VIP..."), OX_NS("Pagamento ricevuto, attivazione VIP..."), OX_NS("Payment received, activating VIP..."));
}
static NSString *ZVipMoney(NSInteger amount) {
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    f.numberStyle = NSNumberFormatterDecimalStyle;
    f.groupingSeparator = OX_NS(".");
    f.usesGroupingSeparator = YES;
    return [NSString stringWithFormat:OX_NS("%@đ"), [f stringFromNumber:@(amount)] ?: @(amount).stringValue];
}

static NSDictionary *ZVipJSON(NSData *data) {
    if (!data.length) return nil;
    id obj = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    return [obj isKindOfClass:[NSDictionary class]] ? obj : nil;
}

static UIImage *ZVipQRImage(NSString *payload, CGFloat side) {
    if (payload.length == 0) return nil;
    NSData *data = [payload dataUsingEncoding:NSUTF8StringEncoding];
    CIFilter *filter = [CIFilter filterWithName:OX_NS("CIQRCodeGenerator")];
    [filter setValue:data forKey:OX_NS("inputMessage")];
    [filter setValue:OX_NS("M") forKey:OX_NS("inputCorrectionLevel")];
    CIImage *out = filter.outputImage;
    if (!out) return nil;
    CGRect extent = CGRectIntegral(out.extent);
    CGFloat scale = MIN(side / CGRectGetWidth(extent), side / CGRectGetHeight(extent));
    CIImage *scaled = [out imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
    CIContext *ctx = [CIContext contextWithOptions:nil];
    CGImageRef cg = [ctx createCGImage:scaled fromRect:scaled.extent];
    if (!cg) return nil;
    UIImage *img = [UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp];
    CGImageRelease(cg);
    return img;
}


static UIImage *Z9a3e7f9348(void) {
    static UIImage *wifiImage = nil;
    if (wifiImage) return wifiImage;

    CGSize size = CGSizeMake(64.0, 64.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(ctx, UIColor.whiteColor.CGColor);
    CGContextSetFillColorWithColor(ctx, UIColor.whiteColor.CGColor);
    CGContextSetLineWidth(ctx, 6.5);
    CGContextSetLineCap(ctx, kCGLineCapRound);

    CGPoint c = CGPointMake(32.0, 47.0);
    CGFloat start = 1.17 * M_PI;
    CGFloat end = 1.83 * M_PI;
    CGContextAddArc(ctx, c.x, c.y, 28.0, start, end, 0);
    CGContextStrokePath(ctx);
    CGContextAddArc(ctx, c.x, c.y, 19.0, start, end, 0);
    CGContextStrokePath(ctx);
    CGContextAddArc(ctx, c.x, c.y, 10.0, start, end, 0);
    CGContextStrokePath(ctx);
    CGContextFillEllipseInRect(ctx, CGRectMake(27.0, 45.0, 10.0, 10.0));

    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    wifiImage = [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    return wifiImage;
}

static const CGFloat Ze25ebfed17 = 210.0;
static const CGFloat Zed1192a6d1 = 100.0;

static NSString *ZThemeNotify(void) { return OX_NS("ongnong_theme_changed"); }
static NSString *ZThemeKeyR(void) { return OX_NS("om_theme_r"); }
static NSString *ZThemeKeyG(void) { return OX_NS("om_theme_g"); }
static NSString *ZThemeKeyB(void) { return OX_NS("om_theme_b"); }
static NSString *ZThemeKeyA(void) { return OX_NS("om_theme_a"); }
static NSString *ZThemeVisibleKey(void) { return OX_NS("om_color_visible"); }
static NSString *ZThemePosXKey(void) { return OX_NS("om_color_x"); }
static NSString *ZThemePosYKey(void) { return OX_NS("om_color_y"); }
static NSString *Z0f21de981b(void) { return OX_NS("om_qx_slot"); }

static CGFloat g_themeR = 5.0 / 255.0;
static CGFloat g_themeG = 91.0 / 255.0;
static CGFloat g_themeB = 89.0 / 255.0;
static CGFloat g_themeA = 0.86;
static BOOL g_themeLoaded = NO;

static CGFloat ZClamp01(CGFloat v) { return MAX(0.0, MIN(1.0, v)); }
static void ZThemeDefaults(void) {
    g_themeR = 5.0 / 255.0;
    g_themeG = 91.0 / 255.0;
    g_themeB = 89.0 / 255.0;
    g_themeA = 0.86;
}
static NSInteger g_themeLoadedMode = -1;
static void ZThemeLoad(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSInteger mode = [ud objectForKey:OX_NS("ongnong_layout_three_mode")] ? [ud integerForKey:OX_NS("ongnong_layout_three_mode")] : 3;
    if (g_themeLoaded && g_themeLoadedMode == mode) return;
    g_themeLoaded = YES;
    g_themeLoadedMode = mode;
    ZThemeDefaults();
    BOOL hasR = [ud objectForKey:ZThemeKeyR()] != nil;
    BOOL hasG = [ud objectForKey:ZThemeKeyG()] != nil;
    BOOL hasB = [ud objectForKey:ZThemeKeyB()] != nil;
    BOOL legacyTeal = hasR && hasG && hasB &&
        fabs([ud floatForKey:ZThemeKeyR()] - 5.0 / 255.0) < 0.005 &&
        fabs([ud floatForKey:ZThemeKeyG()] - 91.0 / 255.0) < 0.005 &&
        fabs([ud floatForKey:ZThemeKeyB()] - 89.0 / 255.0) < 0.005;
    if (mode == 3 && !hasR && !hasG && !hasB) {
        g_themeR = 52.0 / 255.0;
        g_themeG = 59.0 / 255.0;
        g_themeB = 67.0 / 255.0;
        g_themeA = 0.92;
    } else {
        if (hasR) g_themeR = ZClamp01([ud floatForKey:ZThemeKeyR()]);
        if (hasG) g_themeG = ZClamp01([ud floatForKey:ZThemeKeyG()]);
        if (hasB) g_themeB = ZClamp01([ud floatForKey:ZThemeKeyB()]);
        if ([ud objectForKey:ZThemeKeyA()]) g_themeA = ZClamp01([ud floatForKey:ZThemeKeyA()]);
    }
    if (g_themeA < 0.30) g_themeA = 0.30;
}
static void ZThemeSave(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setFloat:g_themeR forKey:ZThemeKeyR()];
    [ud setFloat:g_themeG forKey:ZThemeKeyG()];
    [ud setFloat:g_themeB forKey:ZThemeKeyB()];
    [ud setFloat:g_themeA forKey:ZThemeKeyA()];
    [ud synchronize];
}
static UIColor *ZThemePanelColor(void) { ZThemeLoad(); return [UIColor colorWithRed:g_themeR green:g_themeG blue:g_themeB alpha:g_themeA]; }
static UIColor *ZThemePanelDarker(void) { ZThemeLoad(); return [UIColor colorWithRed:g_themeR * 0.72 green:g_themeG * 0.72 blue:g_themeB * 0.72 alpha:MIN(0.94, g_themeA + 0.08)]; }
static UIColor *ZThemeButtonOff(void) { ZThemeLoad(); return [UIColor colorWithRed:g_themeR * 0.82 green:g_themeG * 0.82 blue:g_themeB * 0.82 alpha:MIN(0.90, g_themeA + 0.02)]; }
static UIColor *ZThemeBorder(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSInteger mode = [ud objectForKey:OX_NS("ongnong_layout_three_mode")] ? [ud integerForKey:OX_NS("ongnong_layout_three_mode")] : 3;
    BOOL custom = [ud objectForKey:ZThemeKeyR()] || [ud objectForKey:ZThemeKeyG()] || [ud objectForKey:ZThemeKeyB()];
    BOOL legacyTeal = custom && fabs([ud floatForKey:ZThemeKeyR()] - 5.0 / 255.0) < 0.005 && fabs([ud floatForKey:ZThemeKeyG()] - 91.0 / 255.0) < 0.005 && fabs([ud floatForKey:ZThemeKeyB()] - 89.0 / 255.0) < 0.005;
    return mode == 3 && !custom ? RGB(170, 180, 191) : RGB(82, 211, 255);
}
static UIColor *ZThemeActiveGreen(void) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSInteger mode = [ud objectForKey:OX_NS("ongnong_layout_three_mode")] ? [ud integerForKey:OX_NS("ongnong_layout_three_mode")] : 3;
    return mode == 3 ? RGB(53, 180, 106) : RGB(30, 165, 255);
}
static UIColor *ZThemeOnGreen(void) { return RGB(30, 185, 95); }
static UIColor *ZThemeOffRed(void) { return RGB(210, 42, 48); }
static UIColor *ZThemeOrange(void) { return RGB(245, 152, 44); }
static UIColor *ZThemeWhite(void) { return [UIColor whiteColor]; }
static UIColor *ZThemeHisWhite(void) { return [UIColor colorWithWhite:0.96 alpha:1.0]; }
static UIColor *ZThemeGapYellow(void) { return RGB(255, 238, 83); }

static void ApplyNeon(UIView *view, UIColor *color, CGFloat radius, CGFloat width) {
    view.layer.cornerRadius = radius;
    view.layer.borderWidth = width;
    view.layer.borderColor = color.CGColor;
    view.layer.shadowOpacity = 0.0;
    view.layer.shadowRadius = 0.0;
    view.layer.shadowOffset = CGSizeZero;
    view.layer.shadowColor = [UIColor clearColor].CGColor;
}

static UILabel *Label(NSString *text, CGFloat size, UIFontWeight weight, UIColor *color, NSTextAlignment alignment) {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.text = text;
    label.textColor = color;
    label.font = [UIFont systemFontOfSize:size weight:weight];
    label.textAlignment = alignment;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.55;
    label.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    return label;
}

static CGFloat Z7cb9c1a47a(CGFloat width, NSUInteger len, CGFloat maxSize, CGFloat minSize, CGFloat k) {
    CGFloat w = MAX(1.0, width);
    CGFloat n = MAX(1.0, (CGFloat)MAX((NSUInteger)1, len));
    CGFloat f = w / MAX(1.0, n * k);
    return MAX(minSize, MIN(maxSize, f));
}

static void Z611a3d09ce(UIButton *button, CGFloat maxSize, CGFloat minSize) {
    if (!button) return;
    NSString *text = [button titleForState:UIControlStateNormal] ?: [NSString string];
    CGFloat innerW = MAX(1.0, button.bounds.size.width - 2.0);
    CGFloat f = Z7cb9c1a47a(innerW, text.length, maxSize, minSize, 0.72);
    button.titleLabel.font = [UIFont systemFontOfSize:f weight:UIFontWeightBlack];
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    button.titleLabel.minimumScaleFactor = 0.18;
    button.titleLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    button.titleLabel.lineBreakMode = NSLineBreakByClipping;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
}

static void Z3218ec4b5a(UILabel *label, NSString *text, CGFloat maxSize, CGFloat minSize, UIFontWeight weight) {
    if (!label) return;
    NSString *v = text ?: [NSString string];
    label.text = v;
    CGFloat innerW = MAX(1.0, label.bounds.size.width - 1.0);
    CGFloat f = Z7cb9c1a47a(innerW, v.length, maxSize, minSize, 0.60);
    label.font = [UIFont monospacedDigitSystemFontOfSize:f weight:weight];
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.30;
    label.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    label.lineBreakMode = NSLineBreakByClipping;
}

static UIImage *ZCounterTrashIconImage(void) {
    CGSize size = CGSizeMake(32.0, 32.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    UIColor *c = [UIColor whiteColor];
    [c setStroke];
    [c setFill];
    UIBezierPath *lid = [UIBezierPath bezierPath];
    lid.lineWidth = 2.8;
    lid.lineCapStyle = kCGLineCapRound;
    [lid moveToPoint:CGPointMake(8.0, 10.0)];
    [lid addLineToPoint:CGPointMake(24.0, 10.0)];
    [lid moveToPoint:CGPointMake(13.0, 7.0)];
    [lid addLineToPoint:CGPointMake(19.0, 7.0)];
    [lid stroke];

    UIBezierPath *body = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(10.0, 12.0, 12.0, 14.0) cornerRadius:2.4];
    body.lineWidth = 2.6;
    [body stroke];

    UIBezierPath *lines = [UIBezierPath bezierPath];
    lines.lineWidth = 1.8;
    lines.lineCapStyle = kCGLineCapRound;
    [lines moveToPoint:CGPointMake(14.0, 15.0)];
    [lines addLineToPoint:CGPointMake(14.0, 23.0)];
    [lines moveToPoint:CGPointMake(18.0, 15.0)];
    [lines addLineToPoint:CGPointMake(18.0, 23.0)];
    [lines stroke];

    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return [img imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

static UIImage *ZCounterEyeIconImage(BOOL slash) {
    CGSize size = CGSizeMake(32.0, 32.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);

    UIColor *eyeStroke = RGB(90, 235, 255);
    UIColor *pupilFill = RGB(255, 220, 55);
    UIColor *pupilRing = RGB(255, 255, 255);
    UIColor *slashColor = RGB(255, 80, 80);

    UIBezierPath *eye = [UIBezierPath bezierPath];
    eye.lineWidth = 2.8;
    eye.lineCapStyle = kCGLineCapRound;
    eye.lineJoinStyle = kCGLineJoinRound;
    [eye moveToPoint:CGPointMake(4.0, 16.0)];
    [eye addCurveToPoint:CGPointMake(16.0, 8.0) controlPoint1:CGPointMake(7.5, 10.5) controlPoint2:CGPointMake(11.5, 8.0)];
    [eye addCurveToPoint:CGPointMake(28.0, 16.0) controlPoint1:CGPointMake(20.5, 8.0) controlPoint2:CGPointMake(24.5, 10.5)];
    [eye addCurveToPoint:CGPointMake(16.0, 24.0) controlPoint1:CGPointMake(24.5, 21.5) controlPoint2:CGPointMake(20.5, 24.0)];
    [eye addCurveToPoint:CGPointMake(4.0, 16.0) controlPoint1:CGPointMake(11.5, 24.0) controlPoint2:CGPointMake(7.5, 21.5)];
    [eyeStroke setStroke];
    [eye stroke];

    UIBezierPath *ring = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10.4, 10.4, 11.2, 11.2)];
    ring.lineWidth = 1.6;
    [pupilRing setStroke];
    [ring stroke];

    UIBezierPath *pupil = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(12.3, 12.3, 7.4, 7.4)];
    [pupilFill setFill];
    [pupil fill];

    if (slash) {
        UIBezierPath *line = [UIBezierPath bezierPath];
        line.lineWidth = 3.2;
        line.lineCapStyle = kCGLineCapRound;
        [line moveToPoint:CGPointMake(7.0, 25.0)];
        [line addLineToPoint:CGPointMake(25.0, 7.0)];
        [slashColor setStroke];
        [line stroke];
    }

    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return [img imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

static void ZPlainIconButton(UIButton *button, UIImage *image) {
    if (!button) return;
    [button setTitle:[NSString string] forState:UIControlStateNormal];
    [button setImage:image forState:UIControlStateNormal];
    button.tintColor = ZThemeWhite();
    button.backgroundColor = [UIColor clearColor];
    button.imageView.contentMode = UIViewContentModeScaleAspectFit;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    button.contentEdgeInsets = UIEdgeInsetsMake(1.0, 1.0, 1.0, 1.0);
    button.layer.cornerRadius = 0.0;
    button.layer.borderWidth = 0.0;
    button.layer.borderColor = [UIColor clearColor].CGColor;
    button.layer.shadowOpacity = 0.0;
    button.layer.shadowRadius = 0.0;
    button.layer.shadowOffset = CGSizeZero;
    button.layer.shadowColor = [UIColor clearColor].CGColor;
}

static NSString *ZuiLanguageButtonText(void) { return OngnongUIVaultText(OngnongUIVaultLangButton); }
static NSString *ZuiHistoryText(void) { return OngnongUIVaultText(OngnongUIVaultHistory); }
static NSString *ZuiAutoBuildText(void) { return OngnongUIVaultText(OngnongUIVaultAutoBuild); }
static NSString *ZuiAutoPigHammerText(void) { return OngnongUIVaultText(OngnongUIVaultPigHammer); }
static NSString *ZuiToolsText(void) { return OngnongUIVaultText(OngnongUIVaultTools); }
static NSString *ZuiAutoClickText(void) { return OngnongUIVaultText(OngnongUIVaultAutoClick); }
static NSString *ZuiUpdateText(void) { return OngnongUIVaultText(OngnongUIVaultUpdate); }
static NSString *ZuiBuyVipText(void) { return OngnongUIVaultText(Ongnong::Zx8fIsVIP() ? OngnongUIVaultActiveRestoreVip : OngnongUIVaultBuyVip); }
static NSString *ZuiAutoTargetText(void) { return OngnongUIVaultText(OngnongUIVaultAutoTarget); }
static NSString *ZuiBetCycleText(void) { return OngnongUIVaultText(OngnongUIVaultQxMenu); }
static NSString *ZuiSetText(void) { return OngnongUIVaultText(OngnongUIVaultSet); }
static NSString *ZuiSaveText(void) { return OngnongUIVaultText(OngnongUIVaultSave); }
static NSString *ZuiCancelText(void) { return OngnongUIVaultText(OngnongUIVaultCancel); }
static NSString *ZuiAutoTargetPrompt(void) { return OngnongUIVaultText(OngnongUIVaultTargetPrompt); }
static NSString *ZuiSkipText(void) { return OngnongUIVaultText(OngnongUIVaultSkip); }
static NSString *ZuiSpeedTitle(void) { return OngnongUIVaultText(OngnongUIVaultSpeedTitle); }
static NSString *ZuiSpeedMessage(void) { return OngnongUIVaultText(OngnongUIVaultSpeedMessage); }
static NSString *ZuiLanguageTitle(void) { return OngnongUIVaultText(OngnongUIVaultLanguageTitle); }
static NSString *ZuiMenuColorText(void) { return OngnongUIVaultText(OngnongUIVaultMenuColor); }
static NSString *ZuiMagicCardsText(void) { return OngnongUIVaultText(OngnongUIVaultMagicCards); }
static NSString *ZuiMagicCardsQuickText(void) { return OngnongUIVaultText(OngnongUIVaultMagicCardsQuick); }
static NSString *ZuiAutoMergeText(void) {
    return OngnongUIVaultText(OngnongUIVaultAutoMerge);
}
static NSString *ZuiFriendInviteText(void) { return OngnongUIVaultText(OngnongUIVaultFriendInvite); }
static NSString *ZuiPotionStateText(BOOL on) { return OngnongUIVaultText(on ? OngnongUIVaultPotionOn : OngnongUIVaultPotionOff); }
static NSString *ZuiFriendClearText(void) { return OngnongUIVaultText(OngnongUIVaultFriendClear); }
static NSString *ZuiInterfaceText(void) { return ZuiServerPick5(OX_NS("interface"), OX_NS("GIAO DIỆN"), OX_NS("界面"), OX_NS("หน้าตา"), OX_NS("INTERFACCIA"), OX_NS("INTERFACE")); }
static NSString *ZuiMagicCardsStateText(BOOL on) { return [NSString stringWithFormat:OX_NS("%@ %@"), ZuiMagicCardsText(), on ? OX_NS("ON") : OX_NS("OFF")]; }
static NSString *ZuiAutoBuildStateText(BOOL on) { return [NSString stringWithFormat:OX_NS("%@ %@"), ZuiAutoBuildText(), on ? OX_NS("ON") : OX_NS("OFF")]; }
static NSString *ZuiAutoPigHammerStateText(BOOL on) { return [NSString stringWithFormat:OX_NS("%@ %@"), ZuiAutoPigHammerText(), on ? OX_NS("ON") : OX_NS("OFF")]; }
static NSString *Zr7f421(void) { return Ongnong::R7f402(); }
static NSString *Zr7f422(BOOL on) { return Ongnong::R7f403(on); }

static NSString *Z3dc983e2b1(NSString *name) {
    if ([name isEqualToString:qsec_s_0021()]) return qsec_s_0022();
    if ([name isEqualToString:qsec_s_0023()]) return qsec_s_0024();
    if ([name isEqualToString:qsec_s_0025()]) return qsec_s_0026();
    if ([name isEqualToString:qsec_s_0027()]) return qsec_s_0028();
    return nil;
}

static UIImage *Z0da1985399(NSString *name) {
    static NSMutableDictionary *z92a7d4c1 = nil;
    static dispatch_once_t z6cbe0d29;
    dispatch_once(&z6cbe0d29, ^{
        z92a7d4c1 = [NSMutableDictionary dictionary];
    });
    UIImage *cached = name ? [z92a7d4c1 objectForKey:name] : nil;
    if (cached) return cached;
    NSString *b64 = Z3dc983e2b1(name);
    if (!b64) return nil;
    NSData *data = [[NSData alloc] initWithBase64EncodedString:b64 options:0];
    if (!data) return nil;
    UIImage *img = [UIImage imageWithData:data];
    if (img && name) [z92a7d4c1 setObject:img forKey:name];
    return img;
}

static UIImage *Z67b9f0c2a1(void) {
    static UIImage *img = nil;
    if (img) return img;
    NSString *b64 =
        @"iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAMwElEQVR42rWYa5BlVXXHf2vvc85937797p4Hw9DMjEMPIGSI"
        @"+EC7AZVUfORLdyqiJj4pH3mUiSWVVHKnfVQRQU1VPlhgFKRSJt6ORkkkTnAcQDSENwUzDMK8H9093T093X2f55y9Vz6MpkoM"
        @"zEDwVO2vZ/1q/9f677WW8Kp9IdWvxJU1+QfK0OaEubY+9dHSKbQFOAB0AktNvYjouf5V/j9IqioA90/f/Id9xWffn/XHNwfJ"
        @"apm4g2tro90KZjs68FQ9uuhHhy686Z73vcXMgFKtVs3U1JT/jQLu3l0Nxsan3L3TX/rwG1/75G1hex80FRpNaLYh6YDrgPMk"
        @"rQxHVvtOnwwu/6dnX3P7Zz8wLrOqKudyk+aVAo7N71XBqpx6/G1h9wWe7G91XDurrlNSl3Rr0q5o3K74uFN0YlI3UjpYeX3h"
        @"+x973bNXP3T39N2XiYhqtXrW+PaVwNVqE3bb5LS75ztfvW7dwreqpfaC5fI/CykMi1k5LCaJxXhEMCIaGEdgUpNRVU0Gi8d6"
        @"VpeOvmn4/c//w9gnx93Ub+IG+/ecFFUVv/rkZZu3SIbGfm+e/SKyvBfXt5Vk+GIY3ojtGyTo6SHT1UU2VxQJyyFByRfd/NDe"
        @"A+QE9Jd5/GJf8EoA50cHVET0/q997QfPzD35+a3bQ0O7gT+6k2RuiaUloRkXsbkcJhR23jPHb2+vMNiN1o+tmAPxhuaXbiae"
        @"vvHssV42YLVaNRMTO/y/7/rZhp/kX/tF7vo5rZm7ZfS6TWRKDXRuhXhxjubcHK0mtBPoacPMowvMOG8KeavZ8v71j371pouA"
        @"R9mxQwB9FSUeMyKih11lavPm/Nuf6Lnaz+zeIw/fej9PP7hIW0PKPXlKPSHFSkC+aDlvwFDIQLYQal/Riea6lsOtHzwOwI4d"
        @"+qrm4N7RMVVVOZ6a3o05XGF4RI6FRTbpKZYeOsCPvnOS+x707J8znG4LiYe2FzoSQDvxT0VXEF9z0yfeMT44W6vV7Nms5hXk"
        @"4B4rss2985+ftZvnsF+7fpO7f+gu7vtelfOjnzC02ubwETjYgVgMHsEjVMKYufJWnn7Xd7kk4ErgW9PTZ49mzj331IAwPbkt"
        @"1t21otV07cFldKmZypXXjLPls/dz5D272HfZx1gc3EYS5UljT7PuaDdSZmWIOzf+lfStXUevrP4uwPT0pHtViqRWUzs5KU6r"
        @"VfPNd37khq/G9s+zJTtS1ERnGtasnI5ZaEGy9WrMlqvR5ZjW7HGaC3OkzToSZAgHNvDJgX7tXet57rH0MVVlcnraTk++NORZ"
        @"AWuqdlLE3fKDvZtr6/q+sWVN/xsXW3BJPtFiWSXXZ1iaDzlZT3hqdpkjy006XlHJYXIjRHkhL46wXue/Vxc1Ywd43fLCv4mI"
        @"fvTWR8z/dhKvBLBWq52B2/XcG7au6/veGzZV+q2QnqinJp4Vs//HCQ9nlhl5S4lCdxZdTIl9yPxyk1MrDZqtFnGrQ9xJ8C4k"
        @"e/mF5m3a1Fxx4ENfv/+xuz/05svnq1U1U1PiXzZgVdVMirgv3fPMxZuG+/7jzZsr5TwuPfj9NFjcKQyfMBSOhzx2wvFQ714y"
        @"Y1laWypIySKRYIsBgc1ACJGPsF3dVEZKJl5J/YaLR68y9ZmdN92zf7z1AKsv1TgEL9ZG7QBu3vlEYbi7Mn3ZSKWsaeIO3JwG"
        @"/Cxg23pLqwinB6EnGmR2oYc9d8xwKjlGbrBN95AhLCuNwOO8hyCiPxNzaeApX5kxR5eSZPvG4cvS5Oid752Sd+8dVftiUstL"
        @"FcXXHzh40xUXn/+ZvqJPW1/sBKVDIf03GrStpLtg9VHh9IJy7Kjn8NGYRjumnXSoJ01a2iaWlNQo3ggilqHiAOs+USTzkZDF"
        @"0ybZ2G3Cg8///AMfG99yxy9jnvUGq1U1k5PibvnhU+u7y11/HOXwyz9u2cozEf1/a/BDIBjMWqUsysK3YWa/I3YOa4R8Jks2"
        @"k0G9IiIokKonFYfvQOOWGFNWMhMZO1dHu7srn6/ufvpfJsdo/F9S/7oPjt1rALJh7o8G13Tn09XUP/65RArvMjAExIJPweZh"
        @"dUZ57gkPxpAJAqxaxAviz7yuzntSl6LqERUwnqYmtG73JIcTs5R4H3UNrB3S8HpEdMe999qzGvWOsTEHSBhE786V0Jn7OtJ8"
        @"LAtHBV0AjcAGkNTgmW8IHQCjiBisGAwGwWB/ecQgCuIUEwt9hQLLp1d58tszSGRYbKGZTOa9ANx7r39JiavVqhER//nvPDIc"
        @"RNmtziPHdnozdH6GbAfcLrAjytIxx0N/10GKEYXQkjQCYq901CE+xXjFo2ceOVUiK4ShQFY5njvBzpnHyd63lrXvWW/ahUB6"
        @"THjpp27d3Td1w/jCC2X+FcDR0VEBCMJgpFgq5jurTusHrFx0oRAr+INK8Lzlttvm+Wm0wvbbLqD5mVkKc46yzZLrBIQSEhlB"
        @"8ThxtE2HU67BiXiJ/c0Zjp1axHqDm2+ydKQtuQuLWpZcqauUHQEWJqenf8W8X1AkE2dKW4Iek8nSrnvvYmuzm4VGVsHBnn2O"
        @"XScTfF/IrjvqNA4vk55aIsp7shlFmwlhoBhNcT4ldjGdNCFOYywQ2ggMJKmnvpBgLsQHUd7aQPrOEEwwfTYf9N5Jx0PiIS0K"
        @"Sa/SqoCLhV3HExYKBYK0SXLXIpLJYLK95C7PE13Txfzn9iGSID7BaIBoQBAoYaDgY5wmGBVsmCFOlMSBBhYxQXjORp0Pw9PN"
        @"VkyxEEraL9RLUOqF2ZPKYx1DcyiHiUK8pmiSYkoJ8Zyg320i/b0Yn2JcDD5GXAdNU4xz2Cgi9I5AFcnl8aEhTRFvY+JOXAeY"
        @"finAPXvOtN7dhfjIfL2R5Ms9YXvE61wG6eqG5xfhUK+h1WNQLN5F0HFIx2MTj22n0Bdh4xQbd7BJBxN3yJYdYQh+sUkgSlYt"
        @"vrcIXSGiGN9a8XG7eQLgogle3AenplBQeZ9fOiouPtBwSvYSdJ+FlTIcKsHpDULnAqG5wdLYYGmcH9I4P6KxIUPj/Dyt4Tyt"
        @"wQKt/jJxb4Uk6KJw/QUU/mIrRF0Yk8eUykQbivjuyBcDpRj64yeOHD0AsOMF88kLJBat7tZAxsfTOx8+eteSk09n1ovf1xLT"
        @"nSone6G+HtRC6sCpQCKYWDEtsC0laFps0xI0A1wzJIoi5p8VguNtgnyBMM0Qd0f0jBYhZ/15JRG7kv7km1MfaNdqakV+9bn7"
        @"9RwcwwMMZNJv1FdXPrXfFczAiNcfNq34gqezBpwFVVB3xhAkEaQDNAXbUsKGJVg1uFWLK1j8YkJ4yJEtFQgjJbPRYi/N0xsZ"
        @"6aYtiyv128+55Z8S8RO1mr3uko37wuWZrxcja05779YMKceygg6BDggMgAwCA+D7wQ2CroV0jdBeK7TXGdprDe2hgPa6DJ31"
        @"OZI1WWRTDhkrUOyz7rIB7MKJQw9+/HdGd1WrVXNOzQJAbWLC76iqybcfuLF/NX/dAVl/3qnZtlt/XmT3B0LSASO/aIYSyGcV"
        @"TaC9KEisaBPiOviCQB5Ytti2IQwswRbou8joaJdVtzyvq8v1PwV0dHTUnPPQJCLKDrj+HVctFZOVie1mvhUvRfbggy3d0Ejo"
        @"6lbMoMH3gHYDXb843UCPQI8gfeD7hbhfYBiyrzHkrwpYf6noBlzaG2qwvDD7lzdOXvHQRK1mJ19kNpFzGZZu/88nr5kL+mp3"
        @"z5Yrj8/Gkhs0Uh7J0BgOWS1Y2ghpqpACHYGWQgNsQ6ikMJyBnqxil5q+fDrVt24p23Dp+b+/4erNf1Kt7g6mpsbTV7wfrNae"
        @"jqYmt8Wf/dcn/vrCSy+d+vJ9K+mTM0loQkPUExD2B5g+i+YFHyipEYyDqA25hifXSXGnYhrHm25LJW/fsdXSowuf++CbRv5m"
        @"olaz05MTHl58eD/rVDfKqKuqms739/5XlHbkC+O54Cs/TdNdp8SuDuWE4QCcEqx4TMsjbWDF055rs7zSJG20qET4a0eL9g1r"
        @"Vg+U2yuf/uA1F3/3DNykf6m9zDntB6enp3SMHfKFjw/sf83Vv98Y6i2OT1xRCbcUEBu33UqY+HrB4bvB9QmubHCxIEspeZfq"
        @"lZsK8Sfe2h8WVp77xzE59K53vv1NT9Rqaqcmt7lzmcnPfQWsKojoF+7ed0lfT9dnCoXsu7srlUKscLgJh1sJJxqexbrSqUPG"
        @"C6XI8NoNIaXTR5vLs8dHp/7g9YdufeSR8Ibt25PfyBL9F7I4gOpdT5+XBLlrC5F5SzkbjJYiO+xVivW2D5djjb36lSSOj/WV"
        @"oocHTOe266/atMerGhHxLyfmy16iV1XN3mlk+gWmeu1N93StC1y5O0smZ5PWBaFb+ciHf29VX6DAy433P3P9PKhp79phAAAA"
        @"AElFTkSuQmCC";
    NSData *data = [[NSData alloc] initWithBase64EncodedString:b64 options:0];
    if (!data) return nil;
    img = [UIImage imageWithData:data];
    return img;
}

static UIImage *Zc83f0d7b42(void) {
    static UIImage *img = nil;
    if (img) return img;

    CGSize size = CGSizeMake(48.0, 48.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextClearRect(ctx, CGRectMake(0.0, 0.0, size.width, size.height));

    CGPoint c = CGPointMake(24.0, 24.0);

    UIColor *glowOuter = [RGB(95, 240, 255) colorWithAlphaComponent:0.42];
    [glowOuter setStroke];
    UIBezierPath *glowRing = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(4.0, 4.0, 40.0, 40.0)];
    glowRing.lineWidth = 4.0;
    [glowRing stroke];

    UIColor *glowInner = [RGB(170, 255, 255) colorWithAlphaComponent:0.24];
    [glowInner setFill];
    UIBezierPath *halo = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(7.0, 7.0, 34.0, 34.0)];
    [halo fill];

    UIBezierPath *outer = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(8.0, 8.0, 32.0, 32.0)];
    [RGB(255, 221, 58) setFill];
    [outer fill];

    UIBezierPath *rimShade = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10.1, 10.1, 27.8, 27.8)];
    [RGB(255, 147, 33) setFill];
    [rimShade fill];

    UIBezierPath *rim = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(11.6, 11.6, 24.8, 24.8)];
    [RGB(119, 43, 197) setFill];
    [rim fill];

    UIBezierPath *body = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(13.5, 13.5, 21.0, 21.0)];
    [RGB(196, 61, 255) setFill];
    [body fill];

    UIBezierPath *highlight = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(16.0, 14.0, 8.6, 6.4)];
    [[UIColor colorWithWhite:1.0 alpha:0.44] setFill];
    [highlight fill];

    UIBezierPath *bolt = [UIBezierPath bezierPath];
    [bolt moveToPoint:CGPointMake(26.2, 11.0)];
    [bolt addLineToPoint:CGPointMake(16.3, 24.3)];
    [bolt addLineToPoint:CGPointMake(22.0, 24.3)];
    [bolt addLineToPoint:CGPointMake(18.7, 37.0)];
    [bolt addLineToPoint:CGPointMake(31.8, 20.8)];
    [bolt addLineToPoint:CGPointMake(25.1, 20.8)];
    [bolt closePath];
    [RGB(255, 246, 73) setFill];
    [bolt fill];
    [RGB(255, 116, 23) setStroke];
    bolt.lineWidth = 1.35;
    [bolt stroke];

    CGContextSetLineCap(ctx, kCGLineCapRound);
    CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithWhite:1.0 alpha:0.70].CGColor);
    CGContextSetLineWidth(ctx, 1.7);
    CGContextAddArc(ctx, c.x, c.y, 14.5, 1.05 * M_PI, 1.40 * M_PI, 0);
    CGContextStrokePath(ctx);

    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

static UIImage *Z71a4c9e2d6(void) {
    static UIImage *img = nil;
    static CGFloat lastR = -1.0;
    static CGFloat lastG = -1.0;
    static CGFloat lastB = -1.0;
    static CGFloat lastA = -1.0;
    ZThemeLoad();
    if (img && fabs(lastR - g_themeR) < 0.0001 && fabs(lastG - g_themeG) < 0.0001 && fabs(lastB - g_themeB) < 0.0001 && fabs(lastA - g_themeA) < 0.0001) return img;
    lastR = g_themeR;
    lastG = g_themeG;
    lastB = g_themeB;
    lastA = g_themeA;

    CGSize size = CGSizeMake(48.0, 48.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextClearRect(ctx, CGRectMake(0.0, 0.0, size.width, size.height));

    UIColor *themeGlow = [ZThemeBorder() colorWithAlphaComponent:0.28];
    UIColor *themeAura = [ZThemeButtonOff() colorWithAlphaComponent:0.22];
    UIColor *outline = RGB(122, 66, 14);
    UIColor *sideShade = RGB(219, 146, 18);
    UIColor *mainFill = RGB(255, 238, 78);
    UIColor *mainFill2 = RGB(255, 224, 53);
    UIColor *shadow = [UIColor colorWithWhite:0.0 alpha:0.14];

    UIBezierPath *shadowPath = [UIBezierPath bezierPath];
    [shadowPath moveToPoint:CGPointMake(17.0, 8.5)];
    [shadowPath addQuadCurveToPoint:CGPointMake(25.3, 10.8) controlPoint:CGPointMake(22.0, 7.8)];
    [shadowPath addLineToPoint:CGPointMake(33.9, 14.5)];
    [shadowPath addLineToPoint:CGPointMake(34.2, 23.0)];
    [shadowPath addQuadCurveToPoint:CGPointMake(31.5, 26.6) controlPoint:CGPointMake(34.2, 25.4)];
    [shadowPath addLineToPoint:CGPointMake(39.0, 31.6)];
    [shadowPath addQuadCurveToPoint:CGPointMake(39.2, 35.3) controlPoint:CGPointMake(40.4, 33.6)];
    [shadowPath addLineToPoint:CGPointMake(22.8, 46.4)];
    [shadowPath addQuadCurveToPoint:CGPointMake(18.3, 45.2) controlPoint:CGPointMake(20.1, 47.6)];
    [shadowPath addLineToPoint:CGPointMake(12.4, 40.2)];
    [shadowPath addQuadCurveToPoint:CGPointMake(11.7, 35.9) controlPoint:CGPointMake(10.9, 38.6)];
    [shadowPath addLineToPoint:CGPointMake(17.5, 28.1)];
    [shadowPath addLineToPoint:CGPointMake(14.1, 24.8)];
    [shadowPath addQuadCurveToPoint:CGPointMake(13.2, 20.2) controlPoint:CGPointMake(12.7, 23.0)];
    [shadowPath addLineToPoint:CGPointMake(13.0, 11.8)];
    [shadowPath closePath];
    CGContextSaveGState(ctx);
    CGContextTranslateCTM(ctx, 1.0, 1.2);
    [shadow setFill];
    [shadowPath fill];
    CGContextRestoreGState(ctx);

    UIBezierPath *aura = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(7.0, 5.0, 33.0, 38.0) cornerRadius:12.0];
    [themeAura setFill];
    [aura fill];

    UIBezierPath *glow = [UIBezierPath bezierPath];
    [glow moveToPoint:CGPointMake(15.8, 7.4)];
    [glow addLineToPoint:CGPointMake(24.9, 10.1)];
    [glow addLineToPoint:CGPointMake(33.0, 13.8)];
    [glow addLineToPoint:CGPointMake(32.5, 22.2)];
    [glow addLineToPoint:CGPointMake(29.6, 25.4)];
    [glow addLineToPoint:CGPointMake(36.5, 30.4)];
    [glow addLineToPoint:CGPointMake(21.7, 43.7)];
    [glow addLineToPoint:CGPointMake(14.0, 38.7)];
    [glow addLineToPoint:CGPointMake(19.6, 28.2)];
    [glow addLineToPoint:CGPointMake(15.3, 24.3)];
    [glow addLineToPoint:CGPointMake(15.0, 12.8)];
    [glow closePath];
    [themeGlow setStroke];
    glow.lineWidth = 5.0;
    glow.lineJoinStyle = kCGLineJoinRound;
    [glow stroke];

    UIBezierPath *body = [UIBezierPath bezierPath];
    [body moveToPoint:CGPointMake(14.8, 6.8)];
    [body addQuadCurveToPoint:CGPointMake(25.2, 9.5) controlPoint:CGPointMake(21.1, 6.1)];
    [body addLineToPoint:CGPointMake(33.5, 13.4)];
    [body addQuadCurveToPoint:CGPointMake(34.0, 22.3) controlPoint:CGPointMake(34.4, 16.0)];
    [body addQuadCurveToPoint:CGPointMake(30.8, 25.8) controlPoint:CGPointMake(34.0, 24.9)];
    [body addLineToPoint:CGPointMake(39.0, 31.6)];
    [body addQuadCurveToPoint:CGPointMake(38.8, 35.4) controlPoint:CGPointMake(40.4, 33.7)];
    [body addLineToPoint:CGPointMake(22.3, 46.2)];
    [body addQuadCurveToPoint:CGPointMake(18.0, 45.1) controlPoint:CGPointMake(19.6, 47.0)];
    [body addLineToPoint:CGPointMake(12.0, 40.0)];
    [body addQuadCurveToPoint:CGPointMake(11.3, 35.8) controlPoint:CGPointMake(10.5, 38.4)];
    [body addLineToPoint:CGPointMake(17.8, 28.0)];
    [body addLineToPoint:CGPointMake(14.0, 24.4)];
    [body addQuadCurveToPoint:CGPointMake(13.2, 20.0) controlPoint:CGPointMake(12.4, 22.7)];
    [body addLineToPoint:CGPointMake(13.0, 11.5)];
    [body addQuadCurveToPoint:CGPointMake(14.8, 6.8) controlPoint:CGPointMake(13.0, 8.8)];
    [body closePath];
    [mainFill setFill];
    [body fill];
    [outline setStroke];
    body.lineWidth = 1.8;
    body.lineJoinStyle = kCGLineJoinRound;
    [body stroke];

    UIBezierPath *side = [UIBezierPath bezierPath];
    [side moveToPoint:CGPointMake(24.9, 10.0)];
    [side addLineToPoint:CGPointMake(33.3, 13.6)];
    [side addQuadCurveToPoint:CGPointMake(33.8, 22.0) controlPoint:CGPointMake(34.1, 15.9)];
    [side addQuadCurveToPoint:CGPointMake(30.9, 25.3) controlPoint:CGPointMake(33.8, 24.5)];
    [side addLineToPoint:CGPointMake(38.7, 31.3)];
    [side addQuadCurveToPoint:CGPointMake(38.3, 34.9) controlPoint:CGPointMake(39.9, 33.6)];
    [side addLineToPoint:CGPointMake(22.1, 46.0)];
    [side addLineToPoint:CGPointMake(20.0, 38.5)];
    [side addLineToPoint:CGPointMake(25.0, 29.1)];
    [side addLineToPoint:CGPointMake(22.5, 24.9)];
    [side addLineToPoint:CGPointMake(24.4, 19.0)];
    [side closePath];
    [sideShade setFill];
    [side fill];

    UIBezierPath *inner = [UIBezierPath bezierPath];
    [inner moveToPoint:CGPointMake(17.8, 10.0)];
    [inner addQuadCurveToPoint:CGPointMake(24.3, 10.8) controlPoint:CGPointMake(21.2, 9.0)];
    [inner addLineToPoint:CGPointMake(28.7, 12.7)];
    [inner addQuadCurveToPoint:CGPointMake(29.0, 18.6) controlPoint:CGPointMake(29.4, 14.3)];
    [inner addQuadCurveToPoint:CGPointMake(27.1, 20.9) controlPoint:CGPointMake(29.0, 20.1)];
    [inner addLineToPoint:CGPointMake(31.2, 24.4)];
    [inner addLineToPoint:CGPointMake(20.7, 37.5)];
    [inner addLineToPoint:CGPointMake(19.2, 31.5)];
    [inner addLineToPoint:CGPointMake(22.4, 26.8)];
    [inner addLineToPoint:CGPointMake(19.0, 23.6)];
    [inner addQuadCurveToPoint:CGPointMake(17.5, 20.3) controlPoint:CGPointMake(17.9, 22.6)];
    [inner addLineToPoint:CGPointMake(17.4, 12.6)];
    [inner closePath];
    [mainFill2 setFill];
    [inner fill];

    UIBezierPath *shine = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(17.0, 8.8, 12.5, 3.8) cornerRadius:2.0];
    [[UIColor colorWithWhite:1.0 alpha:0.42] setFill];
    [shine fill];

    UIBezierPath *shine2 = [UIBezierPath bezierPath];
    [shine2 moveToPoint:CGPointMake(24.6, 21.9)];
    [shine2 addQuadCurveToPoint:CGPointMake(28.9, 24.2) controlPoint:CGPointMake(27.2, 22.2)];
    shine2.lineWidth = 2.0;
    shine2.lineCapStyle = kCGLineCapRound;
    [[UIColor colorWithWhite:1.0 alpha:0.30] setStroke];
    [shine2 stroke];

    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

static UIImage *ZNewCounterArt(NSInteger slot);
static UIImage *ZTokenUnifiedArt(void) {
    static UIImage *img = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *encoded =
        @"iVBORw0KGgoAAAANSUhEUgAAALQAAAClCAYAAAD1R9cMAADdFElEQVR42uy9d5xdZ3Xu/13vu8up05s06rJkS3LvDWwDBoNtuk0vIUAggRAIaVwS2VxILgkB"
        @"AgQIJQRIKBKhFxswxsbdlqusYvWRRtP7nLr3+67fH/tINtwUuCH5kXs5n8/5zGg0c+bM3s9ee5XneRb8X/RQVbsweehynZxsU0VU1fDrx/9TD/N/E5hFxNGY"
        @"eF6leeizIqiIeFWVX5/mn/sYyq8B/Svz2ApAEOe/WiwsPrc+ueNzqtrP1q3mFzlRqiqqW6zqZvP/GphFRH99Wf+KRRdV7aoPffOg1m/Q6tiejwPozTcHvz5C"
        @"//6xu081VNXw10fkV+bEIACNw7d9TQ/8uavv/GS9sTj2itZJMz/PSa1OPbJ8fuSHfzgzfN+Z/0e3YVUh+5mf+Zh9XR///18VMBvVzUZVbXXqwAfr80c3/jzH"
        @"61f18X9Z5FID4nzUexOu9Gxt3BGGc6v+vlmbLYvIR1U1EJH0X0lZDOAazemndwzY907sOXIjcMV114kA+lO35uuuk2t2bJKtx1KdrQBbPaA88bYt8jMfQX42"
        @"3bvmmtaXrgG2snnjRr3uuuv0P/v2n12oP7bHjkdt/AX/TNp4rs+f/QEArrvu1xHyVyHaADRUT2k8+rFm47E3+2TXn3o39YCvLx59Zut7gn/5Z7OceW5877rK"
        @"6LdvHT98xztUVf7u7/4uZMsWyzXXWH4Kj9k/AiAEYitE1qCq+R/84L52vWaL1S3bIwXRz9yc081bos9v/nybjmlJVW0oEBnB/JuFzDXZ79282fwyovrj9YHa"
        @"Y1+bn5/vcQsj79aJ72ht5K4JVe3+71wgyq84QH+hQkU3bzZy/fVeVZcmR36w3S7e0unKODmy18i6t41ovOw1YWnwRlW1RoxT9F/+fZvVcL34Jx4k2wLe3Q88"
        @"0PHKT3y9KyyUVi1GrE7U9BnhxFqSDnh1RTB9iCk0k2SOXE6bjVRDawNVNBBfDpHEV2vTrt6cjPBVqaWj7bnItIfBrlJDd64baB9++VPOH3nK1U+eTpIU97Pn"
        @"65prDBs3Ktdfp/ALHBtVI/L43zQ0NJRf2mPfKsa+3kzdvtJXHvFp+wvuj/pOPu9Yd+i/Y5Eo/zcA+X//qwQ3vfNWM/rJJ6U9J3k//HWJ7Eni1781URe+Iyj0"
        @"v+8JOaJex3Vy/dYdwrVbj+MnBr5w++19/7TzwEmPTi+saRhzsmu6NTkxp5hcPJDvbCvl+3vQzg6CYpGpXI6GDWmq4MUgYUQVA15InEfFID5FmwnadGjSgHqN"
        @"oFonnZtDpiYxY1PYuZlavFibCBere4qaPtAXFw6sKMR3XHfV0/af+pyL5huJe+JlaLjmGtEtW/y/dbyOgVlVJW1MXBnY4Dlpo/akIB+cyOj91Ea/3Mh3ronT"
        @"4gu3hP0bX6S6xYpc634doX/JjwOqudUi9V807RARny4e/qqd+9bzmjO3u+DE19vm3a/1cd9vGdd9sVJc9pwwt+xbP3sgvN4XXvuFB04d8cGFU/PNJ4dR7uJi"
        @"V/dAedlSSv19RIUiNs6xYCKm1TDn8DNNtFpLqDRSGg0HqcsyZREwAqrZxyAAa8AKWAvWtEpY1ADiEUlTQ9oQadYwc7OYyRnM6Ahy+HAjmp4dam8k24sLiz8e"
        @"LIf3fvK1v/3g2otX1BL/0+Bmyxb/xDz+GDirc0cujOLc31hJziYSqEyTTA95Hfs6lJoamaXW9b36Rtux9plwnYhc738N6F9GdB4ZKTIwUK6PP/CHQbh4qav2"
        @"viS3bMNu1c3m5znIqjcHIpelrjb8P40/8M7mA7+ZBud+LnCzXyN9+AMa9r5JZc1L1RbWfBHT8T9/+LW/mPr2fGPT0bDrKWmx6/L2rr7zyv0rbdTZQ1gsMBbE"
        @"HEiNH2ugkw2YSlLxdS94wDtBHVY9hUAox4a2yFIMhJKBYiCUraFgITAQSZZrL6Ls98pBb5hfUBYXHUndk9Y84lRVRI1BCQ0mAHzTSqOOzM5ghoawe/eqHZ3Y"
        @"OeCatw8G4fe/8qKrf7DkinPmGq6F42uusa3i0ohI2qxMnmtCbrLSKCWzo5501kttzJjpHxvfGUNjEV0IXXj2u9Ql5g+DXN8Hjg+qfg3o/+M0w4qIq03tfUNY"
        @"KPxVc/ZoKd9Wo1lpf1Hcd+qWn/c2eAzQSeXIe4Jw8h3JPa9KZfXZgSz9CH78UszwLBReRbPtRO7bv3dxV5U5133O4ODKDeTbuzlsQn4C/j6H7m+mprKYQlMF"
        @"Y8AY+i0syRk6rNIRCkUj5ANDABgU65V66qmniktTNPWoV1CwqpQRQhHmEMaMUBFhRmDWGKpqaKaQVBxabaK1BE1StKkKRolDlXyE0cTa+iKMjRLseYz80KFd"
        @"7XPz33/yyqU3ve+Vz7qld+3auWMHamrk0KZSOdgamsaG5tyR1PqFQJpjyMw2PHdgNv0p7v7/hbGnp/asPw5cPf5OUBy86mdz7l8D+hcGdBaB6/PDJ8nCrtsk"
        @"aOuSfH8aSHQ2pf5HgEBEkp87QlcO/7WJpt+WPPjHKV0PBGb1g4jMohOvYfFwr05HV3vbf6FNe9YyKRG7cO57jVR+4kWGvQgitAmsQDnVCCsCQ7eBGKWqMJ56"
        @"xpqOoQZMVFMWkpRK09OsN2kkDpc4SFtPryAme5pjfQ1pNQMVCcBYQazFRAaNAohDCAxiTfatTqHu8ZUUX0tVMSqFSI11xjbqYqfHCHY9QrRz1yPrtP6jU5f0"
        @"fPWj171luaX5kbQ61dGc2udDd9RIMow09qMLX0NO+k3IPR1//zWY/Etg8BovHSc1nAufFBV7t/13BPWvUB/6OoXrybWv3NUcvnEobG7v9pIEFFY9R0QeBpJW"
        @"ISfAv14EbSvL5s0Yb4OCCYqYuA3EIe4WxF6Lb/8oxfYuiaIOO0JTd6Tj+qDzMkLetpsi15iIASOsB7oEqipMqrKzmXJbw7On7hmpp8w1PD7xkCg4B6KIKsal"
        @"iPdE6kEUb7MUOpv6OMQ7suRZUBG8CKRACupTXKtbpq00XC1IHCKFCFMICXtDglxejEPcXEI636Sh1rNklbJ0uc2de94pj40OnTK566G3vPm6d/PC89Zz1imr"
        @"fN5OGKntRuwhpG0P9PdgOn8fN/1eJBREUjRZUBMHeWrJq4Ftv+o11q80oEVEdfNmw3XXaTKxewI5QPPIF1xu2XPf5ZLJJcb7T4rIAz+TovgnDj22bLnGytln"
        @"J2B4x+/PLVuYuBWaSKH0J6icg6rHhptQfydpMoaXXlktXdIX9BDTxnKJ6RKYVc+dTvlH57jVwcFEaTY8JB484MCiBFaPd1XEe9S77O2o4p0HzaKzV0UdGG29"
        @"2ScOXMSACEpWMAqSgRlFRBBA6wm+2sQDEgquEBKUYkw5omugnZVGTX3BcXiiplP5Nq2feqbmNq23O7ffwVfu+aHW991gzt8otK9LoMuj0TIkeDdoP2Ifgbgd"
        @"JQUaQnUK7/LPVNWSiCxq9jb014D+P3lceqkRkdRVxu5mvvx0KXqaB76gURy90dulr3O1ozeasPCP2Mo3RaR6DNhbt17LNdds9SJbnarmv3vDO958+30ff8qK"
        @"/hN02ca/MprvRdwu8KOo6QcGKAkUpQOVNVjJoz5hmBo3pPBtL9zpDQe9Ae8wmhIYjwnAp1k6q6IoLYR6UO8h9eA94hVVRbySXXJZ9MabLOSJbyFEEEvW0lPN"
        @"LhZzDOutVANFgtbPGUED8M7TnKmhczVq+ZBaZFjbFnLV+i6JVGT37AKHj0yTW7uMTae9RJZVthNW78X7GUy8CZHnoe4isDMQFSFnoVZHXVW0voAG8bJ6fa4P"
        @"WGzdK34N6P8zQLeir42mKQwiUwGyfKWku/7G2SUvCmTg1Cux4ZW+KfdoMvVnBA/f9Pgo2/A3H3nOFV/47ua3n7Dm3Kf2LTuXemkpB/0YA+ndtMkCnm68N1i7"
        @"DnQN6qvAKBWtsY+Iu33EvRIzQZ4cEW1qqXmH9ym+BTj1HlUyAJLNNsQq3ntQj7gUVQ/Og9cM6M4fv49IK52ALDgfB7so/hjI5RiwJev8SYYpNR4xgjEWJ4I3"
        @"FtQzW6mzrV7l/sUaJ8bCRfmAp520kqg2Rn7hAPVCkXj1JoLCKahcgEgXqAeNMEEbPpqDhVlwTUnTxNtyFPokOQXYfyzt+O8yaPkV43JcmpVJrnGQeClSbxgJ"
        @"l8CyBesOvUdN9eXe5/sIutaei+m5ATZtTxojX/vRt98zfLRSe37v2ic9vffMK5nN9fhdri5RsktOZZjYFEDORehF1aHeIrIIcg/oKIv0McYA8xici0icw/kE"
        @"41KMV7y2UKhZ9BXnUKeoy1IQRVEjEAUQBsgxkDoFfyxNyUCtKKqA96hko+/s9R2IBe/ABKgxWQ7dut/rsUwlEJriCTssK7stbVaYqMLwrMOkCbvmGuyaSthQ"
        @"slzbIQwM9FJsLODSYQLdCXJO1hvXFK9FTPAKKN6JP7oPbVZxLtUwCKw0fRvAtm3bjKp6EdH/DqD+lSQnBSKT3oMpnyJ65EuY0z+Kl33iJ/7Bir+MtHHYa/FE"
        @"wTVO3n/gwZPzvcs486kv4mD7Kr7o8JONitlgmlwWlFmmA8R+Bi+7gUmMrEaxqB4E3Y93lqqrUWWemggNhFQVq5aCF6w31BQaCqkYiAwmFwIGgyBJE6k3kVoN"
        @"W6nhKhWoNZBGCkmCJC6L0ibrcmgYIbk8Js7hgxDNFTBhiLcWRTKsZVd1lpNrFiNNAC6waJxw2vIcr6wd5ZK/+yJdB0cZeemzeNcZT+bG/Y4oMIRxzLxLuGVs"
        @"jlowzxVlx+r2bqABTKHSi/oI9DCaRBC/FGn/Gj4ZIkk2kEsdTq0DOOtb33Jy9tm6+b9Jx+NXDdAK0LTBrNRSZ/NLrc5NKrNfErvkC7jib8DinZhkqUmGvsnY"
        @"3IAP1v++FlY/me8D9zfqxtvQrImLLE8c6fQ0RyoPscQ+SrnokUIfBOdjuAjVCfBTuHof1dTREEfTpDipo+JwRKRhjDMRcZSnZARTTWB2jvTIMP7QYdyREfzo"
        @"GOnkPDo/T1qp4xpNSFPUZb2M44WiCRAsagQJY2wUo2EAhTxBZyfS04cdWIIOLEV7evAd7fg4jxODdylok7Z8g2esaed3vv5VznnTOwl7BWmrsvITX+T3P/83"
        @"bH/mizh6tIKKp47D2ZiahhxeMJzg6yzrqeBjj0HAPAB6F9T24/ZvY+axhKB/TEsDgalWamhQ2p41n64Lp3/zyusLk7df+raRR9/SvmTT3b/K7bxfTfposwli"
        @"RW0A8Rq0+h2k43cx5U/iix9DK3eDvZalZ7/SHAjy3Nmc57At0RnnKFdmKR/aw5HJx6j7SQYLSjPfz6Cr0OnnkeJNaDgAUkCSKo0Uqj6kokpCgosLUOqkz+TZ"
        @"kC7SN7EX2XeQkV2HGd47wvzhYRqT0/h6iksdGkQQxHgBHwRoPkDEIpq1547Nt72CSoDzHp8m2bPucNMJyaEDiFhMFCFxgIljgp4OomVLCdasoHjiGrpWdHHF"
        @"YBdv+MjfsvSPNpO+++noizbib/wytYU5TvsfH+SCK67kK7kcNBqkChU1LBKwYHIsUMS7KUTLeHYhyT9gKiGLyVomBzYyXDnIY3fs8UvH77EXPX3VZ9vblz7M"
        @"NdfYqbm50zrjQ39k4joLCwxkJ2ir/DpC/wKP1ATTIXZWwnyXj3qQcAx1d6L+WRh5M7T9DkFbgXq6m7nUUIrW0LM4z9ThnUyNHGQ2aVAMBR93oGmKT1LUWnyl"
        @"Tpcfx7bdAuGFaBpSTVLmrWWu0MF83IOtpKx7ZAcdj9xNc/ejTI+OcHAqYTqJcUGMxDnCvh7wDnGOwKXQaKCNGpKkpJUmPkkwaYpvkZIQASsEUQRhmJGXopg0"
        @"F5OYHGkYZa8NmCTBNhfIjcyQP7qbnnsSetvzLFnXz6tHJln6tW/iv/wS4pPH0E/+NeYOiNeHhN8b5sT9BwiWbEAbgjOWhmsBWgMWHfikhC2AaXwGP1tndL7E"
        @"3kadXWaA/auey/yKUA588/u8901/1vujz3++57KXvWxy6v3vb4Sm90AyNnn72AkXfa81W/e/BvRP5xUi/O+9zeO0RWOO1ucO7gqL7Rf62bJXl7PQyNplBBgN"
        @"UH+IxFiCtEBj3y3MDh1gtqY0bRFMkQSH854kMTjJIqUXQbWXHjmEdJyKN/3UCj3Mu05m9h9mdtt3qT6ynZmJafY2Pc0wB/lOTH9Al1FcrUo6O0nt6AzN6Vm0"
        @"XsM1GoQ0KeWEQqQEgSfOC7mCRUVwzqPekzqozkHSdNSawmLNYzXE2gBbyBN2tBGUysSFAlGpSKFQoCCWkgYMRIYXf+u7rBkfw3/tKoLoPrjxMXRvgKAYB956"
        @"2io1it6xoIr3kCBUEereUm/W8LIS27iVxfFphisnsCspsrdZZnc9ZcfkJPPLTzC5171J3ekPPes1X/rWDWdd8/rNp65e9Z3PP5ieeu0p0SKaHJ8Z/BrQPz1v"
        @"13+Nm7F161az+c9Uw0L7RHL0VioHb6LtzBeDvQpRwTuDdwliHK7yKHP79zE36UjoohEUqWgA3tAQQ8MJDeNIE5O1uBCkEBOopVv34p1Q2X4zE/cMUzs4ja1Y"
        @"NGyH3l7a1OEXZnHj+2iOT2Gq8xQkoVxO6e7LMXBGyLJlMX19lt7+iN4eQylXIwqFKBCsekQVdRbvLE4NSWKoNx0L9ZjJGWFsNGV8AoYPNxnaP8zwkQaLcyml"
        @"wNLXVaJUKlHu7uIlwxOcMrdI8s1nEzTuRraNII0IOZoi7QZXdyRBGzODy0lsCGkNdSlN8dTx1ERxhEQ2YHrkfh5dWM+epJ39rsR+V+IIBcaahvHHRmAeWXX+"
        @"Of7U9evOevQjn/l66epXveU3zoo/iiZs3rzZXH/9rzYL778c0C3FiPuXmFybN2821157rTM25ooLPtQT1Xey4ox3Il3nQXoYbAy2jPo2jN+Dm76ZaqOfNOqi"
        @"WguoOaGmBm8CjApVDw1nUVECyRGVivgwwRzYQyG8hVy5C/PwTYSLy2jr6qFR9PjRMRqHdyCTk5RMnSVLAlY8Nce6U/OsOiGit69KudSA0INPoCHQjKEZQVoA"
        @"sXgVvBPAI+ox6gglpRinEDsGSg3WDSickUAesBEuCZic7OLwoZixXZ7Z3RVG989w4X3DnBIVaHzhUiK9C3PvKNId4h4RTF1hKdhhy1wzZe4bX6T3zCs4OrgO"
        @"9QmuMkvTeRY1JZ8vUZ0b5bbZAXan/RxMIg66IqM+ZsJHTBOSqOAPjPDIyIJpXniSu+Rdb7X3fPHbfzvR1Xf5na++8jWnPelJM1xzjWXrVvf/PKCP9TCPHj0a"
        @"FaLKp+bGdtzY1rfhc8f7m9ddJ9dnapPoj9957R//ZGTunLOf/wHd01ayB5p7WBoV6akPEbl7kPwFqCuRNANqFKl7Q0MNDQ1JJCQxFsESuBSJI0xPLz6p0tz2"
        @"ELX9t2Dq+2hf1WTlhRvId/dQGp6ndGiI5vgcBTyrTymy4fwiJ5yap38wweSaoAHUO3G1M0iba/C+F7URkl9AijUwCSI10FlgEcEj2sz63pJNA1O1qISIFvGu"
        @"AEkHaA/GJEghpX/A0X9yA65cBKap/OH9BPss7gtXEwW3IveMAtCIu5Ajixhp4CNDMOWZKsf4H3+PU394Cx2nXMjM5VdiV68mmXc0F8Yp+0Vum465pdnHqMsx"
        @"7DIgz7iAGReQesn650FIWK2w+0eP2Obpy/XZL7nKjwz0P/cpn/jKqpe8+wO/8cV3vvVBvWRzwC3Xp/9PA1pEdMuWLXZwcLA6PbItbBvI/cPk0QcueUz1jZde"
        @"d53j+uvTv/n83yx7/u+9+iMrn3rVc0ae+XK+hKPdVWmXtSw78AgrJ+9gWXSI/s79lHueitMOGt6TaoAjwJvs6QCxAb6nn8TVcHfeh957K2b2EKVeqC5tY3p6"
        @"iiW77yIeX6QwlHDy+jJLX9nD4MYm7QNVEAeNlbj0ApLquUi4CnKKFI4Cj2HTR9D0IOLGoTEPvp4NRVKPuGNtjWxobERQI6gFE0RoVMbmymjbUoRBjAuhCX5i"
        @"ET+7E+9GSD62iPs7sN+8lrB0N9x5BNMwNDuXYtvXYA78BGmzeCu4Uc+eDo/LR5TqhiX330b7I9tobjoZvfDJFJfHDDVCvjvXx0GKHJUiM2qZ8ZaqWjySDbc1"
        @"q240CohSx4H7Dsgnp+vy/MvOcWf295z+3Q9+fsvTXr/5tT/8xPW3ajbL/JVLP/5L2y+6WQ3Xic7Nja01jb2fKPcsuWxolOeuHFzzjd/78PvPvmXv3s+0veDa"
        @"k9MnXeL3NZ3pjgxLpmYoPngnfQuHWJ53DERNlkZ1NnQJ5XyB7x1VHm12MpQWmPYFqhLQ6O6lGRjctnso//hGuudG6O8u0tMO7ckYSxZGOTGYZeNFbUSn9+M7"
        @"RykuawI5tH4izl8B4SVI2IeaMYS7wd2Opjsx/iiaVBGn4ANQg3iL+sypQBzgWlwOfUJzXSRjJwUWghCiCCILlXmYXoRJ0KOt6+KmAPcl0C8+l9ymh5A79yC1"
        @"kHRa4TXnoV84jPzTEGalxXVa5J89f1OC+9pi8sv6qHb0MedKuMVFbAAXX34K9bOezm2F5UxWE8Y1puoDGj4b5ojPyFN4EPWZhqbFRUlrTXSgk1WXrXe5sRk7"
        @"+r5/mF47NvKK7V/+wHcbzdRkf+ivTpH4/1s/ccsWtZc+ec//jEvlp73mrz79j/fWK38Qv/Y3l02dsNZN150thYaOnXso7thJ0dXpioTusE6PbdATJvSYhAu6"
        @"mxxOY+6odjDcjJktDzDZ1kN1+0OE3/82bUcPUi7l6Wy3tDUn6Jg6whKzwKbTIzZd1UnXaZ0ZNdOBq18F9ulIWEbMflR/gvqHQY8gMgUOSA3GJ9nI26UZbdQr"
        @"tEhIeiwyuyfErta4W0QQK6hV1FrEWjRpIpMpTBhkTHB1RW8xJF9MkM+/kOiCXfCThzBpgBsFd1U/4fo2khc9hplUZLXBzRj8LmX842V+9H3lrpurHJkP8Ev7"
        @"CboHKYeGwbKyv5Zj30kXcvSyZzMdl9G5BYyEiGbTyYxklV2IaHZRoorxDuoJrr1M+eL1Xqwz7q/+Ptl06NBv3/ePf/WpNP1TA9cr/Gow8v5/AfTNqsFlIqmq"
        @"dvz+Jz82/IXDkwX3W69jYXDA1+ve5BoNzH2PYA8doRxbihaKxtEWeNqChI6gQaeFgajJCfkaD7oe9ratZ2JqksYPv0fw4AMU44D2rpj2dIZgaB+lZI6znlzg"
        @"yS8OGTi5DhTx6TOAV4CcALIX1a+B3gY6gUgMdAEBShVcA5IaktYeB7Mq6rIIR6qoU4xTNMnAoMcI/NrirB3TFAYZL0RnPTIqMAFaU/y2iOTvq+jHriF39Sjc"
        @"9BNMGuNHU9wFnQSXnYL/yQH87x8k6AjwayG9XXAr8hT/RqHa5MhsgS9vdfzgexUI8izbuIp63MvQjDI332R85XoWr3whzfWn4BaqSJKiJmv//RSoPUir5Sjq"
        @"IEnx+Rz23BN9WLSGv/qkW/Hg/a/Z+92//1yavsDCr0ahaP/rm9AqnxXRXBSyZXzxuhtSLuZtb9LZth58oiaemsb/6D78xDRRHGJ99iYFOS708BLig4C6Wmql"
        @"LqJSJyO33Ybf8jnax47Q1V2kM6wSHd5Nx/gBLroo5po/6eb8F89T6rOkjReh+peIfSbwAJ6/RPVjGB7JijlTRIkRglbX3AMp4lJIU3A+i9JpgqRNxCeIuFbC"
        @"bDBxiORDTBxichESh5goQK2A9eBTdFaRMUXHFeoG/3BA8qkavPcZ5K6ZRm66DUlCdMSTnpojeNrFiNmE2/pjzHaFDqAnwN2ZIC9dgjz1XOoTMaXkCE96co2L"
        @"ntGH1i0H7jvCkZE5XLHEYqmHxvQszbvuROdmCTaejCuUoZlAEKDWgLGIMYhpKQxEWncXg0kS/NE58eU2lcvOl8XhsavP6F2zd3THZx72eo2FHfp/XYTOVCVb"
        @"5V/qMbc6HVLI5/zSa9/wxyObTvyL4HderfOSw3qVYM9B3IM7seqJAyFWR5TxgYgDIbKOglWKodBWCOjo6yM/NUr3TZ9jaudjNAvd5PKeeHqYYPQwa9YbLv2N"
        @"NtZdmAA9pI1rEfsikBD4Lug3QPaR0erDVt6byaUyxkOuFaEd4htIuoh3VYwRxOZAyuBL+DSPr0W4hZS01sTVS/h6iKZVVONsAG5zSK5BWFSC3AymsQ8Zb8JY"
        @"irs3wH+ghnvHVeTeksJ3b4BGBKOOdG0Be80gxr4brb+f9PV3YA8FyIBH2wLqX/ZEf20wF+cxy8/Cyam4oYfINe+GvogHtkf87Qcq3Pdggl91AjNda5ltKPW5"
        @"ecyylQQv/g2SE0/FzS+2aKumdQ277OJNHfg0K3a94pMmiEFOXu+DnoKRD3+ictaRQ2++6x/e+5n0+S/8hVp6mXWbGv4tBdL/n4B+Ir0wcyL6KUsrAQiM6LKX"
        @"vvEDU+ec/Xv6hle4ahoY20jFbN9Nuns/YWjIiSeHEplM+R9biENDEEJMSrGjnWJvP+FPvkfPXd+k0zaJCjmoTmGGDtLb3uCil3RyypUNCPOkjeeBfR3GFFB/"
        @"C+gNiDncGvEsgNQR9S1CUaYYyT4zIDkIYwwFlBI+CUnGHc0DdWoHq9SGajRG56hNVvFzDbTZwDVT0maLydF6LRSCyBKElihvae90lMue2Af4z1fRV15G/BcD"
        @"cOMXMVMRfjwl7S8QvqobCd8JQRXd/g7c79SxAcgyoTlpqN+vlP8uQMI6WlJk9XLofxau2oce+mciuwMfFfjajW18/JMz7Jhqp7FyPZVCD8liFSMh0fNeSHr1"
        @"C2lWE0wzRQKbcbqTBjSbSJpAkgl+JU3QZiOL5Cdv8LYtNuFHP9k44+iBF93+2fd9wz/5koBbbkn/PZwA5omziO3bt0cnn3xy81cF0KJZwhguTh16vQT5x0od"
        @"/d8HuPnmm4NLL71U5dpr0S1bZM3Lf+s9o6ef84e86dW+mQZiGonIvQ/B4SNEuYhIHTk8sYHQQmCFMFDC0BIHSty/lJwowVf/nq4dd7NkoERn3hFOHKZt9ign"
        @"XFzg7FeXKfQKLnkayhsxdhmqj6LMY+gjE1DdgtFvoswgNFsnMMlIRYGBuAdlBUIHbqRJY/cite1T1PYcpX5kmmS2iqYt/atkQd+E5nG9kkqmasmujgzcqhiv"
        @"RB4KVmhPLOFtCY2Xnk/0gVWYn3wZmbQw5knyBexrykj5BZBeAdH70c/fBR+qI92CrDHUbhFcF5SuA+pAUZBCgm9XpG8D2nY+fqKBDP+YIBzhyFwXm99f52s3"
        @"NpH1G6gNnEAzEWSxSnj++chvvZF6rguqzSxQJyk0a9CsIfUmNJrZMXIJmiRokMdsOMEbnAk/+rHp53bYl/3je/7whn9t+PK/A9lSm9r/eg/nzjejtyxZsqTy"
        @"H+Vcyy8vOmej7MXxg68thpOfnFvkf7QvO+svjylKBLjwdW++bue6Eze73/stv1ALxC5WxWx7EDs+QS4yxOqJRImMJzRCZJUoNISRJQwMZmA5ZuwQbV/9FP0L"
        @"o/R1R/TYOcojB+lrr3D6q3tZckEvXtfik1djwksRP41SA1mGajtCFUhAHgP/dmAMoY6mNdTkkWgN6vvxRwzJw7PU799Nc88wbq5O6gADJhTEZBNBvGb+dFax"
        @"Ro4fVGtAVUnTzL7DimI064ZEgRD7EPOjOslVTyL6+MXInX+FjCgypSSSx7yyG9NzLpo8F2EPar6Af9thzF1N6BdYHbD4OUf4soDccx3UJMuA8iA5A/k6lHPQ"
        @"dQFeN+L2PEg8dTt05fjsd4u89yMLjMTLaKzeSGJK6MIiwYkbyf/JW6gsXUoynRB5g2ukSKWC1heRajUDdpoAKb7pkSCEE1c726jbwt9/9rFXDeSf/8E/e9uj"
        @"11yzxX5l67XOt0AM4o9f66pRUp15A4uPPTXsHnx2Zd6/s9S18j2/DFrqLxHQLbmcCXTh0Hd+UspXLp6vLbkvLQ58p6tr1U0ve+Nrz7i7d/DPp//gjwuzJk9U"
        @"qUnhjjuJJycJcjGxekKjRKKEVokCIWc9UWjI5fOkgyvQB++k/PXPMZh39HVCd32U3rnDrD43z0mvOomofQ1p8nSMuRIkAOaAHqCt9SYdyjQiDtV/RvzHUVlA"
        @"gnZgJX62B79jmvSe7fidh9D5FCWLvBhL6sGoYgMlCLKWsrVknQsPJEozFZxmT/WK0cyvIxQhsAKxIa0I6XdrNM7aQHHrq5C9f43unsaMQZqEyEt7sYMr8cnl"
        @"WR4fbIMjPyZ5zTRBqpgl4MohC59NKf2VJVzrUCdQyqI0ecnytACQGlruRDqfSjqVR3feSFwa4+HhHn7vugr3HMrDaedQLy9FnGCWrWb5776UxrpVHKl5wvkA"
        @"P1eH6iyyuAj1RpaK+ASrCUkjRYptyKYTXTA8bAsf/ejtHz+x44prr79+sYWvJzq39jZrc0/R+UO/FdvDlxHkqaWrP1joXfPWVmTmP9r++2Xn0EZE/NzU3AVh"
        @"5eYfxhwqoB3cdO+w/uO2gzL+lj9jb6Gks7NNGXhoG9HUFC4IMKIEBkIDsc3SjVxoyFvI5fMkK9bhf/R1On/ydXrbI/oKNdqnDtOnE2x62SBLLjsP1TPw7rkY"
        @"sxpljowk0Zm1oHAt0anL2mV6I/i/RgJB5ST8iEe3PYw8vAMzsYBrgpiWdYz3BBZMBIRZO8svKpNzISOzAaMzAYcXcowuhIxWoNIMaDhLQ1PEK2URSjYhFyyy"
        @"zDbZ1G15kqmQrj6J6PNvwshH0Id2Y/aGpJOCvLAbe0IR3zgfsTF4A9Fd+K8P4d41i+0LsKuE+kGhuU/o2BLgh+toCtJhoSQQS2aJahXFIq4JQQr9p+Hjs0ge"
        @"eZD84v3MRZ38jw/B129x1DeezXzXOjTXQW7len7zNVeya3U/N86khOPgK3NIZR5qNUia+DShQ2pEJMwnCrkyZs2gy9+zzXZ+55vfuuMfPvzG3lJp+PDhw909"
        @"ncFFAfa3NFk8J6jt63Xzd+JT65Kuqx8pDJx8FtddB78kC+Ff6ui7Rf80IubO6f0/+WI+f+Q3avMH03jo69FlL3uv7osdAzNHpProo+jcLLVCDq9NxAiBEWID"
        @"eaPkAiW2nly5nWDJCprf/ST5B39M30CB3miWtvEhuroW2PS6DZROuBiXXIqYyxFjgQrQ1zK0cFm7LxPnZXc+vQXkdgguxI/N4B/ahux6ADPrMiVHZ4hJstuN"
        @"zXkIPCwaRiYsBw4UeHSoxPaRMgfmS8xqG0o7QgFDjpAigQR4UoxAiDJHQsocJT/NnOxlpe6FJw8SffofsZ0PokdmMXMGXwGe1U1wAvjmiWDrQI1MeD2FuzPB"
        @"WoNYRXMGHVa07pm8I6Lz7BiTM/jFKuINIhFeHThpiWFDqAVw4CGk5zDRGU+nPjRA26Eb+cg785x4Qshffvw20lXz1E5+EpW2dv5+2wi/YQzDg708Oplgj5lb"
        @"GzJhsPF4lFPDKnXfZHJhlmDvpG0/c7Vq8/yrr3vfX5xbqwwPu0YyGKP9LD5MOv0QdZlwupj4aMXLQoq978ows8X+shQw/xltOwviK43kiubDf/6dKN/Q/OCT"
        @"ZGj8HtkrJzI0Ms3szDzTtkDNZbdmjBBZITBKMVDKgSXKx4TdK2je9AWCx+4h39lOpx+ndHQ/S04KWf2bFxK0n0navBobnIpSRbQMlAFPpqFuKahVQBqoPojK"
        @"NmRhEt1zA37X3Zh5MN7iEwNesTFIqFAVDh+MeeCBIvfubmf/5BIW/AAJ3YTSRdn2UTJdRJSxEgABhhCHw3lHiCECAhbo0EVODhLO7vsL2jaMwic+SbjipZB8"
        @"Dn3oDehDCf6sZYSnJ2iyGpUy4EDzEByFiRHcq8ewVYUujx+0NL7kqbbDWFGJVhr6X9lJ+6UnoIv70fkxCHOZcNxLVvAev6ATfBlk+YXo/AB++/eIOqt88aY2"
        @"/uwvZ1k46ULmLn4Z9a6l0Eg4+fx17Dn5VJp7p7HNeWhUIW1gXIMOX+OUcIHntU2xbz5hIQ2w7e209y/zc1/5grlqsMgzn3E+taFv+zCOVLr6xI8NaW71G2wt"
        @"XvX2Qrn3r3/Zcq5fPjnpuutUrkfGatOP3XzrgeY5Jy/Ga9Y/U1cMPImOQ5+hz+cYa1vCjGtQ84aEAMQQWshZS0RKd14Z6F/O0M2foHL0YaLlHRQbR8gNH2Lp"
        @"JT0se/Ez8bIenzwPG/QC8wgDIBHZvbfFqzgO5iboNKJHYOIbsPcmZFoJohAtZjyGIM7U2fWhgIfuKHPX/X08OjrAOD3kWU5XuIbBcADVIl7zeA1JvKOmVVJN"
        @"UePwPkEkg3ZEE9UmnSQsU8PpPZ+ke80wjb+6jnjFPNr4Wzj6EfRIA3/aCdjTm/ik/3jur1hEU0Tm8A8ojCcwEEC74GoByVwTf4KQy0FzTBn68ynKtxZY8rpL"
        @"iU8YxQ/fjq+BmPjxCaBRxISYmsLwT5Al58A5L6Hx0Ld5yaXD9HX28ofvuhtbrzF+0lNxQYnt2+6g+NJn48+8CLd/BiPZ60QonZJiVSmEjt9ZU+Hh0TnwBXLV"
        @"WVO46iRNbvwHnbn/K9J1xiuNllbSfOgffH7wtbYaL3tfsdz711u2bPmlG0L+0gEtO3aIiLj/8Qe//5L+k0+Ml244y3cf+qopr34rbSe8iRPjdzMwO8tMs48K"
        @"ASkWEYhsSGwTSpHSM7COmbu/RGliJ7mBDnLVI4STR1h61Wp6r3gWLt2I6qUYGwDzwMoMALTaEKrHzYky84sGKt+G+b9GpvejJkZy2Ymx7QpNz+TdMQ9/r5v7"
        @"HlnOvmQpBdYzEK5gqekn0h6qXlhIGyR4BA/SxKliCAlpkZRaBzQnUFJPO1XW084FfR+nreseGu9+O/H67ejwT5CpaXT3In7ZidizE0i6QPpaKVMzm1LqApDg"
        @"7q5mt9IQaDe4PZ4wFsrdAhXPYlFIsVTuPcTB7cP0vuwSOq55KTJzAzo5hYRxFqBVs3uyCJLm0Yn7ke4GwVkvof7wDTx143be/64+3vqnD+GbDWbXXECaQvMz"
        @"/0QcRTRWrUcPDxGitBlHh4EVocO7Bl1Fw5Ubu1icfZRQhgjLkUQvO118fDlSMiSP/LkP+l4v9Y7Tx8S6D7VaeL/0yeIvNeU4pmh4xhve8oxmV+ErJ/z2a4un"
        @"Vod58sx35aTOEYJ1fwfJTph8F352hiTpwUtWfFlTwRYHCPuuoP7gpxnd/hC1oBM3O4YZHmPgOWfQ9eQLSJNNGPMMYBSIgBXZ8IMCx4bkqG/5WFhgEdVvgn4G"
        @"qe6FyUV0qoYYxaSeuVsDHvxCHw8+uIwKawiCEyjaNcSsYMEJFU1JjCPJ2uyIFhHNgVhUsxmjMRaDJ0QIMcSa0oVjBXlOLP8VPZ0fIfnIS4jPPoQ+egcmzeP2"
        @"13CDywivyIMWUdnYujgnECpZr1zmYTEiee1BwokEugU9IcB/V7l/l0dOFs5bocw7mGuCj7IpdjKTUjxrJUvediphx0P4w0cwLSGvHFtHEIJEARo66FiO5q4h"
        @"efhWcumt3LGvnze9Y4rp9rVMr76QqlqMCtFrfgPX30t58ih91rE6qHFqNMuFxUku7tpF++DLskJa92TdpfASqD/C/LefSm7d21286Y22Xmn8br5j1Yf/s+x6"
        @"g182mN+95VuDn/rmDZ/ofc21pSNB3hem582KOcugjtE5/efQdT068LdIx4eJ6w9gyOERCDdC6VWk+9+HG72HuNyJzh6lOT5J3wvOp/PCc0kaA5jgPGAnSgD0"
        @"IzIDtLdYjAVapraIeNB9GUi0DjII4Sza7pBISe9OGfuHHh758QrGG+tZ1nUSce4Eqs02qi4k8UKcQpS0o80CKQZPQBTkKdmYCEtMiFUBb1BvsUaybo1v0knE"
        @"iaXPUIg+QuO6K4jPOIC/7S6M5tDhGml7N+FlAVnJcXlmlqhjIHOtToxHAo/fkSBDDbQ7wIRKKgZ/tMm9ro2bHyxw0cgi15xcYcUAzNaVBQV6I+YfOUTtLSMs"
        @"fcuZtF3QhjuwK6O7hhmRX7VlseBCmD2KlL9IeOpraTwScuHqm3j/O3t565/tI4pCppaeRi1V/Kc+Tv4Nb6CtlKOrOsNglLA0ajIQNcjHEU4nkOC54M8FY8Ht"
        @"xix+joMzm7zbiz19U7z95jse+EQrOv+ncKl/WeQkueWWW0RV7Yvf86FP+aueeUF43jmuMXzU9o/vo10X6Q1ydNttaHkAkdOR8FI0tx6NV0PuWUj8Cvzcp2Ho"
        @"86gvkc5OUt8/TdeV59N18Tp80ovYC4AdrchcyCROLXM5EYtqMyPSmCFUPwHsRY5Tm6oQN5CFaRpfNkx+bDWLh86is/8KBnsup9x5Mq5YxOZz5HLdFGw/BdNH"
        @"Z7GbZUvb2XBCmTPWlTljVZFNK3KsGwhZvcSwpNfQU4b2AphUMY2E3ihmZfgVYvdy0nc/nfjZi/CDO7FpjIw2SaISwfNKmNgg9oUgSxAdBx5CaCCSkZ8kCEi/"
        @"MY99oIq0W+gG34TF24o8Er6CedPLPfOWG4aEQFPOWOHIhdCoe4JCSNJImfnBEWzcR/GiQbQ2nvG4g5YSXchwpQHaXEB5DLv8pTQmm6zr2sGyFR3cesNhSoEn"
        @"V2wnai5S3LeL4tlnsCJMWWcWWBtXObE0Q3u7ILnzQAey926akHyRxtQ0ox2XuO/dvteMTVU+9rznvuimHTt22GuvvdY/cYJ4/fXX/9dEaD0+6dkKXKP/YkV6"
        @"zTUm+Od/dme/6brfm1u/4YXx5U9xh8fn7MrxSWrVOtOFHGMuYnk1T67+eSiej2gZ4bzjSY/6B5D6F7NJXDJGc2iRjssvpPtJK0jrFUxwMnAnQg+eBMM8SjHj"
        @"GgPqq0jQBelP0MqfI7kahBtRP4OY9ajpQLdPI19eAo+up7zsNHpWXkCS9HI4STBe6Gx0QyOPCSJyRaHcDu0dQs4IdsFAIvi6kjY8WMGnQhgIBaP05mB1OaUy"
        @"HpPXW8ktvpzGH15A/CKHfv92TDNE5xNSyRE8pw0petS+DMwKRMdR7keYa6VMFgk8NIpw7yLkDWocdIToroQZ7aOuT2K5hoThbnbrNt798H5+cPggf3TBHOsG"
        @"LCPTiuQszUgZ/fvtJGNr6H/TBTC1Da01My7GMcd/nyAmhPmjoB8jPPWt1B9IuOrC25l+XRfv++QO+iJLrXM1+enDRN/6En0vvZplzSorowW6c7OQXw66EcQi"
        @"gYAJwUVUFpW5cr80zl/Khz//vQtUNScizSxfEz2mZvovSzlav8z9O6mGe8Mnvvikz9350Lu49rl+oYEpjU5gJ0ap5gLqalj0IbW0nVwyA7ID1QvAN/ACVkKU"
        @"/ZmdrNRIjyySP38DXU8ZwNUnwV6Jyj1ko7AEw2KrLZdFZ9U5CJbCwhfRI+9GbAE6BtDSASgoWhuDByYxt5yEWzwZe+55lBonIsNNXMOxNCnjmzE6GBCcCLmT"
        @"IOwRKIAzkEx7GkMeuVMJhsOMz+wzfkYggFFEHEFbRFx6mOS+Z9N400nEby6hN/wAqQZI1ZM0A+RFHZjuBJXXofYkjJ9EuRPYf9zoU1UgMOijTWRfEykZsB4X"
        @"GfxjnnHWUVNY0JSCnsvJsp790Y+4dabAru8O844LxnjWxpSJGcdCE0x3xPQN+0nnUgb/+Cwk2IYuNCAMEacZ302TTHkzcwiRvyU47c00t03wyiv2cnSkja9+"
        @"fyfdxZiwvZfOg9vouS/H4FPOZtDtIWrLQfAilAjkNozbj6ZtmOgEUnYwMj5vqyec590Fladf+Ftve4sR3uuvvdYCTlVlcXFfb6m0duI/dbByjCRSqVSWNmYf"
        @"e76bP9qT9j1565Lu8qM/8z0cUO24+CW/+576Vc8qsmLQm8eGJRofRULTolqaTHZkIozGePTxwk0VhyCSwwR1/GIFu34t7ZetxNW3g30eYrZnRHlClNnjlazg"
        @"Ub+AhGvR0c/hd30IIxGUU7BzSLkNv2MHekcPZvYS/OBTYO0pmOkcOlOFvhyxyxP3gWwyyCZBejKw+jrQUGyFjKPRD+k6h/+II5gP0EBR37rBRB7JRSh78Pdd"
        @"gX9ZL9H/WAY/+C5m0ULD4xYN5rk9yOAi3r0KCc9AdA7YhbCt1YHIjOxEHRCR3jmPqSrSnbVOXA0aQ4Zh2YD4gEhC5rSG0xJreCGd4Qb2+dv4wzsf46HRvbzt"
        @"oipx5Jla9EhXxNydQ6R/2mD59WdizEPofA0Ce9y2DHGZsGF6L4T/gJzyRpr3vZu3vaLGxHjEweEd9PafRU8pz8pDt7N8IqFzfQCF3wQRTPIBqO0jqRhqVcXR"
        @"Sxj3ktZnGR2fFX/ppezbNfJH1//lJ7b86R+8/iDA5OSut1vc+ZS4FvBZLfR/Dux/K0IbwNXmpp/WndvzYewjjA7v+63Jip7dU5RhVRW59loj4K593TteMbVy"
        @"7ZPss57mmqMVG4wfJdKEMAyJrRIbIbIWG6SoiUDXIGKygyeZdEnNmVmPtytPtPF0SB9C5VIwQ63KvxeYBm1m/GSpoT5Ewg34PR+DR76INTk0Bg1q2HJK8jVF"
        @"7zgN7EW4TVchXWthvAFOkc4u/GpBTlXM+hbvoQp+zkNdsiFdLWtr4z2kYEtCssTDmEIuIyB5nyJRhMYj6P1Xkj7LEr7vFLj1G+iMyVLUecE/s4fgpFk0eRHE"
        @"T0F1HpFp0B+3yFJB66I1YMC7AL2/DlEmrpV2g06nJLU+cvEl9LkujvoGRWJq0qTplS5zHrFdwh5zI589UGR4/jGuf+o0/e3K+Lwn15Vj4aExDr/LsOLdZyF6"
        @"D7qQIkZaMjGT6R7TPGZsGwysxG36X0S7f4e3v7HMX/3FIh2zO1i6ZD0b+hosq95M1P4xfDqEzm2hXnXMVTuZrLcxleSZqlpEhFwAfnpSjvac6CuXXNr591u+"
        @"8ieBkden3otzh2+oNflCl4hT+A+7m/5b+5wVwOSW3TIxMrcfW6CvNDLQmNh9BcC2bdsCtm71H/jmD1bsXKi/mRdeqYkLRI6MEMxNEwdCYDyxVfLiKJuUOFxA"
        @"C9eAGUDZhtMPofplsBWMLEELm5ETLwD2oG49YueB3QiK6gzKbNYFkDm8G4NwEL/jU3DLF7GLMb7qwHtsE2Y/2s78356P1p+HrH0V0lyG7KkhrogsLcIlBvM8"
        @"g9loM/nUtIdFRVJBjk2dXWaJK2lWVmpdYEaO7YDLitEoxBdm8Y9ejTtzgeDDl8C938VMg7UGP+PxT+7Bnr6AJs+A+CrwC6AJ+BuAsSyuSEuW532Wbgyl8FgD"
        @"ioLi8e0W3Zcyz1q8X84mTucku5GlZhVdbgUlU6ChC4RugFP0xayLLuGGqU289lu9TM0blnYJkSSUeiIqD45w9H/uhvYNEGU+1qIt03anqEvQRg7Gvort2E+y"
        @"4u0s6ZniFa8u0zY3Q3/9IIPd05ROeQNu/G6qE19meLKbh2bWc/fCMu6p9HFPpYN7kl6+vbCEH1b7kEaDxoHDkpx1hk5s3PDqp73mD84H0YGBFY+sWLFiuNVD"
        @"/g+nHObf4WVIV5ccqgRnXDlyuHBnPXfFYpDPzQG8d/9+n4sj/dstN/xF/aJz1+lJJ6genjM6OUKuNUmKjaMQKB2BodeOEHddDPHVaOPj6PTvIcN/g47/AVRe"
        @"gaY7kPhqJHg53p8MwQo897e6O/PZNFDngBnwY0i0Ht2xBW7+OiaJ8TWHWEWmPUPvWc3Rbz4LLb8Q2/08GBdkMkGSNrTPwiXABoHQo02FJkhrvzwLilY123vS"
        @"FEgFkoxR5/Y5zOHWfjbv0dCiHXV0z/NJVu3G/t3TMbu+hRxpABY/k6Ln9GEvXECa5yHRb4DWWnnKbaD3t6YlvkVXlBaZKkbvrSFTDpMXJCBzftqvjLKRmkY0"
        @"vTAQdHPtWf2c3ruEtnQZndJDKB6nESvcMzg5egq76qfz+hsHGZqEZR1CoI5Cd8T8HUcY+eAodvBU1GZKb6OCeBCX0VylGsLoBzGDq2iWn8UZ507yjKuLrE1H"
        @"WXr2pSzu/QH7v/4XbN/RwQPpJu6pdnNPvZd7G11sa/TwQKOdXa7EnUk39yZtRNMzIqlqcvWV4SMN3quq8ZYtW+zmzZvNf0lR+AST610jqpc3oLtfZAg2m63X"
        @"Xuue8Y7/9YwfH5l/UfCsy30y40WOHkHSBnFkCU1KwXjKBnrMND0dXZjuq0nH3gUzN8PEYUQSjFRJF76GnjZMsORDCC/PVjboBzESZgDQBkbizPjbLSDRM/CP"
        @"/Ai56etYYrykmA6DG4eHP3YSi8MXs+7E59HRdyF6aBJTzKHtHfjTBPN0QfKgqSJqWst6WgLReY9UJVsElCi4ll8Fgk8c+h0lSAyEHhNafFlxe16O772D6NMv"
        @"wxz9BuyfR8IIP9rEn9iFfUoNklPQ+LdaYLaguxH9fvb58ZthazuWUVQj3F2TGCtoIFAwaMXTHM8xaU4mpoxiSL2nPWd55uk5uvd2c/fBPMbkWDQzLLgKS93l"
        @"FMIuHkxDXvt94WNPO8LanpTxBUX6YmZuHCJe2kHPyzeQ7nkUY6PMxgDTEvcamK1D/oPY1e8lHXqU9VdNUzvwbKbv/Al7hxcYbQxyaO8djF55GuPxABNJwLwL"
        @"WPBQdcJiKlQc1DUHiUMPDBk9Z4OfO+uMiy98yVuvvvNLH/xKa4/6L+Vhfp4ux+bNm80SkUqXyFDWxrteVTW8/9EDf+Qvv8S6Jd3KkQnxc5NYa4hQcnhK4miT"
        @"GstzddqWXExl6LNMjR1heHuDsaGU+fEGcw/OszDTT9AHmvwuyG2IeQ6iq0EX0DSFtIG6Ot5NINHJ6P6j8O1/xtZDXOKQSHCTcPv7N3Dw8JMY7H0BhdIFzI7N"
        @"4hfKMNuFP00Inh0gsaDNlu61qVn6moJOeZgTaPgsYqctv4pE8TlIvucID1qIfdZZ6bL4I2/ENb+K/cgrMPWb8I9MZeO66RS/vB37jAT8UiT+vVZakRmOwzdB"
        @"WnRh8cckwBmuA4sfS2F7DSlZ1Ch0GNKRBvNJD7NmBXkNAMEaS70O9apy9pqQKzeW6ZVuimk3bbaNhBqd/ixOD57FtDuNN/9wOUfnDf3tEBlPvidk4nMPs3Br"
        @"TLBsEG3WjjHwUW3tkPF5mNqBJPdC/0eRwaeRdg5x93f2sOdojl2zEY8NN3nk5vvZGSzlUJrnqMsx5nKM+5gZH1JzId5ZvIbo+DR+PtH06qeb/VHuT1S1zNYt"
        @"vtUe/q8ZrNxyyy2qqnLddRi59qOGHTv87dX4RbslfLv5jZd6XzOWvfuRtEbOKu3G0W0Tltga5+SmuWj1MibHH2XfQsToUIWpxx6j6UMqI9NMjghLXryOID4C"
        @"2gfmpmxwYl8F+k3EzYMP0WQOiVfA+FL0Hz+dGSuKYHJZ4Pve36zj0JGLOavrhbQVzmHYTZMzJYquhLvEEbwqzLKXWgZgmoATtKHouMfMy/E0Q9JjhH1BCkJy"
        @"e0rwgwBpEzRU6IzQyd/Hz/0t5m9fg22/Ddm2D0OETie4ziL2eREStiPB21A6EWoZ7ZJvIDzUGg754+wDwWR3iiDG3+Xg63OYbosECisCmvclDA2fwWFzFZ10"
        @"4wiQwNLXJTgvNBLoyBuWRSELtQJpGuClwbyfo40VdNoSe9Jp7h9KuXzdIuWCJ2lmCJi/Z5zyJRsJ2udgMWkJZVvprMl0rBqMYNrfja/vJceX2LmvnQfvnWY8"
        @"6GQ06Gf8yBRHBtcy27OC+Zqj6jOzTO+OHc9sRbQ0U0CMnrzUMz6z9Mef2bJn331PeeD6HTssO3bof3qEfmKkFrle2bpVVTW6b9ehN8sznobvLCrDE7A4hwSW"
        @"0AixKHnxdFPnrL6IA+Nj3DrVy2ONZex6aDdHq0Ump+oc2Vmn89LlFJaM4ReLYAowvwNpvgOj30HM5sxTLl0A04Ymp5F+8QuYidYSHquYFL718VVsGz6D9aVn"
        @"kdfz2edmMM0S8VwRd5bHvjpAGgIzilQz/Z0koPPAsCKzkjnFNlpBNFW0mWkEkvsd8l3BlFrtua4QbbyPZP79yPtfQ7DmYfT+3RlAKym+FGOuMtmdIHgbKssR"
        @"mUMlBe5D9a6fArPIEwKTeiCGuyoYDxJJ1q4LDelBGGU9VkoohoY6vHqSpuCaQlQRZMaxpGR4Vl/MWukk77toM2VqOk/RbWJjdDk7qpt45/f7sdZQyilxbKHW"
        @"ZPgDu9Dyesi1dsK0FiOpc6jJoVE/vv5eyL8KokEueWZCXWBqdJqJZsysj1j80e0sSkhdIlJvM3GClxYtoaWttAJHx9A5p+7qp/BQ3b1xet++drZu9fwSovQv"
        @"lrts3mzk1lv8DYfqzx4qFd9qXv4SXGItu/ejaQ0TCCXj6bSODq3zzM4Z1Cs/mCwz3r6Ko/ffR3J4P9YKyYEhygMFznp9GT9VwbSfjSzcizSa2TTD/QiCQTQ4"
        @"HZI7oO1S0q/cjXnwCKYYoihBTvjeFwa4bfcpnJ1/Acu4nCE7Q9F00JWWKJ/pid5sCApBZuriWgc3EXQKZEIzoDdBmpJF5KTFQC0aku0OviEEuQCKKVKOcPbz"
        @"aPO3sX/4KsKzhuGe25A0RhZTnIaYK9uQrhTkd8Ccmpk3CghHEP8VhMUWQ0gfj86tf6sB5sv4vx3FJkC7YLqEhrMs3GR50D6XgI3EUiTBYgjpLlhCKxRST/4a"
        @"sE9RcjlP/5QwORNSMRkXfEEXaNfVFEK4e3GaxZlZnrGhSbPpkTigtm8BR4nypT3o5Him+m3VyVIqQWUCqd+AKTwNF15MKd5CbaGL2++eZj7fz3i+i8rYDLZz"
        @"AD+4Air17O9LWx2U4+THAJopmMDYTQNeDo4tu/fbP9m9976bH+TRR//DUfrnry5VheuvV+81PjA+/Qecd4H1nQXM0WmozkNgCNWRE48xsCFXZS4J+OrMEg4V"
        @"V/DoyDzD9z5II2jDzU6yOFXnlJf2YppTaHwmmhyBykxW8CcJ1AJ07iPQeBjaX4S7cw/u5h1ILgSvBCW47VslvvXwOjbmruAEfxX7m/OYWjuF+SLtazzxqwRb"
        @"CvAjPou8VYVJQQ8rMplxlrSmWb+5qlDVrAYNheTuFNkqBIFFSwnSEeM6vo12vRLz1lcRXNKO7vgBmBjjfMa1u7wNM1BD5G2IfQFoipIiLAA/AJlseYJkG7Ce"
        @"SHrU1ENQwG/3cCRF2my2FKszwO9vMKv9zJvlhATUaJGUEBoVSKYUTkuxbzQEXYbwJMvAcyxXbSqyPO0kppOSKVKnxoCex+roNL50cC1fub9AT5chMEq+N2Dh"
        @"a3uo7e5ClvejPks9TBgglXlMpYJUBGY3Y4vPxucv4elPW6CrLCRjB/DeQBjgbrmFoKmoDVuWG3K87j3WSZLAosOTpBW0/MyLdft85WVhYGDrVv8fZYD+/IC+"
        @"9loD6FPe9hcvne3sOs9cdIHXOW90ZAwRRQyEohgPA9LAmJgf1pZw0OXYXxhg4q77aVYapEmVxSNjrL+sm6WnNUgWujGFEsztyNpV6hGfOXhKPYDGXehiBX3w"
        @"McKcoE6xsefAwzH/dMcaBsOL2MSLOJQuYk0buWqJri5P/jlgVgUw4pEq6AwwKcgUsNganCwKLErW2aiA1AWNDemdKXwdrLUQOyjF+J67kQ3PI3jVSzEXPA+d"
        @"+mckakPSFN8UuLgNs7oB/vVo8NsgaxHpRCRBuQX8w5ks7FiqoY9vk1XIfO4owEMLWY8hp6hXfCToXscsq0npwxCQqOJaab6rKLUZSHMGWSp40yIYGmHgAuHp"
        @"gwV6024K0k4kIVXfZI1eTk9wMu+7f5BHRyw9nZDLQxQpk5/eiY+XQqFlOOOy3nRmAJhH5+6H6hfx7X9Kqb/Bs5+Sg4kR8gtj+DDCHx1CdjyMlNsyd6lWLFRM"
        @"xskWRWyAqdZo7hk3veuXE5+w4qLzfuOdTwaUa64x/zWAznJns333gRfq2WcbHexWHZ9F52ZQazAihGIomUxPd6/rZFzyjBf7GB2Zxjy2g6CYJ5kYIdSEc17e"
        @"h1YaSPsFaG1HZmYiJjMP9JliGoDSebh/vAU7uYD0Bti8p7pg+ey3l5GzZ3KeeQmHmjWqIoRJmc4eT9dTPOYsg4yCzrXAPCfZiV4EFhUWQRZbUbmaFYPeeNIf"
        @"NjHfswRxgEYuizT5h5Fzno95zkswJ38a3BAS9aNJiiag53Zj1qdo8gYk/F/ge45HJ2Enone0OhrHUoyfETc7RYxB6zFsm0Vik/FFCoqrK+4QjMh6xBeAAC+W"
        @"BCVBSVNDQ2H2QcXv8tmF6kFqkFZhzSbLM8sddLh+CloAlFQLrDFPo8oa/uKWbpwY2gpKviMg3TXF4o1V7OpVqCatvvhx9xVMEqMT70HCdfj2Z3LVMyqs6RHs"
        @"kV3YRhXiGH/HHViXgg0zIB+z68VkBaZmlmkcnREP/tTLzs/vPDL+4tAa2LjxvyDlyBrf+tz/8cFTF3O5yzjrDHUNDFMTmaIaJUTJGSUXWI5qkUnNM2dyTBW6"
        @"aN5yEzapE1uHHhnnzGcN0L5kgbS2ChMoVA+gNte6M5lWf7gB3ato3FuhdudR/EQITcWWDV+/oYedlTVcEL2AhuthThrErp1C7FlxLpgnG0zDoOMeWchOLlVF"
        @"K4pUtBWRs/RCKpLJ97zivqkEtwbY0CDiMTaE8jBy9rORi09HBv4eXA4x56JND0kVPWkpZl0A7jeR8N2oBhmJTBzKIyjfR2i2UJyteNNWb1tap0CTBOI8ug90"
        @"Tx2KFlrjbjfpWVwoMGzXEEmEx+BESVGcehqqJBZmdhsq33XYBmhDs3qgCt7CiasCzqeNWNpol3YSbRD5ZZwUXswD8yfw+btL5MuGWJRip6XyrYOkc8uhO9+S"
        @"btmMnSegxNA4DAufx3X8Pm1rPM9+SgxT4xTrM1CIcUcOIo89luXe2ip85fG/GM0orFJrsme4Lj3nbKRjac9z3vD+T/Zy/fX+PzJo+fl+8PrMwuuRx/a9rLl+"
        @"Q15XrPWMLYjOzUJssEbJ4ykYpW4CqhLRUM98uZ2FyUniHQ+SK0QEE0P0daScd00XfqoKxTPQ+gMYbzM+83GarkKhhFZXU91yHxhD2oTQwc4783xv13I2RU+l"
        @"mJ7BET9LiR4itazd4MltAgYMjDyeG2uNrLtRE7Qm2dfqkv3bCG7Kk37ZYx+ymMiizmVcCjuDbLoKLiqj3Z/GJQaPg/SHiBvDLz8Pc0If6l4H5j2oWlTT1sDk"
        @"COjXMTrJ42ojecLzCYVSswlBEb9tJrtrFLJoSF7wBxNmWcaCLCMmJFWP0zQbh4uSqNBUqDYMo9/RTMFVBW1mMjRJBSkrGwsRG3wvkRbIkaOuVfr0ApaEp/LJ"
        @"h5eye9jS1gn5kiGcrbD49WHMwMlo6DI1fSitpyImj8x/EpFetHQuz35qlTU9QmHmCEYdGgh+292YwGZtP2mZPz7eMUPFEgCLQ7PmaD7yG84/Y+lXb7zvGVbg"
        @"+h075D8N0K1Biv/c7Q/1TyzUr5FTz8BbhMlJ1NUJrVKwULBgxOBbfFhjDbViG3rfXXSQUDI1ZOQwZ13ZT6FnBpdswuTykI7jTZFjKnnF4H0d6T6Vxe+P4I9W"
        @"CHOWKPI0ZoVP39xPYE5iA1cylM4RmBKhKzG4WulbaUiXKnbWZLfeFmhZbPWf69lTaxkvQ2Ih3Z2Sfhb8/oBEwFcd4gKQCvQ/B90wAqs/jZERTLAd4b1Q/yw+"
        @"OgmzdCPwYsT8EaphtjpZWodUfwA8hmJbw5P/rQ2aQTzxmZeeK8O9Cxgrx5Vkzlj8Xs8Ya0kpE6qhSYJTj1dHitLI7JvxoTB5p2V+p8N4yVqTqaBJtn45X4TT"
        @"pJ0O2og0h0FoqGeFnEdNT+ATt/cieUsu8sRtluSWPaRHe5CBwUx9EhUgV4IoBFuE9AhS/S5J/iX0rk+44twYxo6Qr05BqYAfOoCdGIE437p4H3ePVRFETJaV"
        @"LTZ4qIH2POksTCH3utSr+Y8Uh//+pDArBvn05756aaOra6VZv87LYmq0Oo8xSg6lKEreQmANVpTACFIqUV9cpPzAHRRLEfnFMZa2e865qhs/20TKZ4EOoaaA"
        @"WEFsCDZCxCHtS0jHB1i44QFMwWJQgoLhe3d1srOykrPCq2j4Mqk15HwXxYJywjqLCz2m3cKchwS0KWhD0AZZRG5kQxjjBcHTvDUl/argKyZb8rOoGdjTBC29"
        @"hPTEe5BL/xRxn0Lrn4D5P4KxP0erIG19oP0Ivw0atcxsaBV+B0F/mIlp/xWl0bHerNabSC6HDnvYuZClGwYoCK6mNEfhsFlJ6CNMRoAEHI4E1bQV7bJi0NUt"
        @"QzdkQlhRwddbkbrRkoapYZ3pJqRAXmKaWiX2g6yLzuW2oyv5yfaIsE0IYiFsJNR/9BjScSLEARS78J2d0FnKCE1aguq3kPAkaB/kqos9bb5GNHsUQou6Orrz"
        @"UaRYaIHZZoJlY1BrUWvQwBKIcPhI1Rxeu4zCYP/ZV73luo2Abt68+T8H0GzdqIExPLLv4PP92vWqnd0qszOQ1IgCSwElj5KzQmQzg8VQHWlnO8HOh+hanKEY"
        @"p8STI5xx2QBtgw1cshbJtYMuIGEX2Bg1YdajNIrpPJPKD3ZiKwlRzhDnYGRI+PLDS1gdnE2XP4MpnSNPO8ZbTjhJyXvBtYMxWYpBU5AGSCPrO9PMBirGCG7W"
        @"U/2qp3azoaqWZlOQisfWssghudfhlnwL89LfRyqfQfd9Hj34z7Drh+hEB3QMAlXEvB4vBZQkA5ZKa2fdlxDd0QKzf3zq9tMhGnGKTxqQ64D7F5AZn1l5CUgR"
        @"/BHHfKONCbOcMmHmj4drqdubIAliQEVxPpu6zxwM2H9rRtRq8fZb432hro5+iiw1nYTE5CSmoXV6dSPWrOIzd/eRqJArKHGbxd25FzdRhO4+yHdC/g/Q0qfQ"
        @"rmdCHCLNnZjmfaTRmWw4ucaF62Ps+DBhUoNcjNu9A+tTCEMwFhWT5ePWQpBtMcBadLYmQ9a4gXNPK9y3++jV5j+Qdph/T/gK1/sPf+f2VbUgeBrrN4ikzujC"
        @"LOJTIgOBVcJWUR7aTJIUhAYXCMX776JcCCjXpyhrjdOfuRStTWfaMwGkF4kG0LgHNUU8FjrX0xzNU731YeL2gDjwmBD++a52ptwS1toLmPQJSESQFunvVpYv"
        @"MdQXgTbN+s2tqd8xrgbNLB0igNpDKXNblIVDAbXAktQErYGvKziLRH9I2vE57Fv+BMut+Ee2wbBB9kzjpyJY2QPBGMKbQFaDNrPbJ4oRC/olxH+J4xMabRmh"
        @"89OdDRGDJh4xClrE35u16yQGrEdzBn8gYZElJPRRFEE0xUqKJcGQoOp+iuvrFDQWhh+17LnV05hVTCq4OZhZhDTIiPyrTRc5zYS+jgT1RVYFp/PI1HJue7SA"
        @"aSOrjeYT0juOIsVNYDYh8hqMXo7kPwXtVyAsotWf4OLTkW7Dsy6yBPMz5ObGIIzwE2OY8aNQKrTGeCYDsw2gFaHVWgIPQ9NQPetkcsXSs1yWdrhfOqCPXSVf"
        @"+Pb3r2i093WZlau8X6yIr81jxROpEkkrKqOEogR4go52GB6mOLSHUlGJp45ywkkdLD05wFc7kdwZWfGk3ZltV7wc8suguArJXUT1h48hsylBIIQF4cgRyw8P"
        @"9rAuPJuCX0NNG8S0E0rI+jUGqWf7SagLUjdQbY2wk8zj2QRCMpGy8B3H3I8M1ZqlqVkPlyaQOKwPsPFfksTvgz/8bUzPfejtt2Hn88hYEz9j4NTlSHkvuOeB"
        @"fXqmxZMgI8drgPId0P8FMo3XZqt/9kS3iMfbduoVGh7Jx/hpC48sIpGBQJGc4L2FQzApyzCaUlBHSI1IE2Ia5GiQ0yYm62IfLzW9KkTCyKjh0Qfg0G5l6Kgy"
        @"kdC6DDwd5FkinYQakCck1Qbdfj15WcnWe/pxaonynnzZYLbtwFd70agDUYeXBprm0Pwf4HPLkcZOjPVofpALz2yypAx2+ujxPUL62E4o5FEjLSAHj0foIETD"
        @"EMnF1McXTHXFAPR0nPXcN7130+MB9ZeZcmzdqqG1HBqeuCRdvgIttalWFqBRI1SINDMmD0Vb6YYSo/hyCXn0IbpNQldYp7M2w1nPPAGxc3hzNth2xNvMTJEe"
        @"YBCCVZA/Cb8QU7/rUaKyIQw8JoBv3ldiTlcyKGcy4xKMBJDm6etROtuE2YrSDAz1veDrDhNlHGJBSUcdsz9ImfqysLArpCGWpJlFZW2C1FICFxLGn8G5P0L+"
        @"6BWEpx6GH/0AqUT4yQQ35tBzVmAGx9DkckzwTtR7tLXZLFtdsR31fwJMISQtNboez5efGJ0VgaZDXRPyHej2BBlpQrvNbnUxuKOOZNowbZbQg6dD67TpIh26"
        @"SAeLdOkCbdSIvSevnpiUSFNC77A+xYaeijiONh1j6qmQFZGKQ71nhXTRRkAZS04gR5n14Wk8OrmM+/fmsd1AwSKj8/idhxGTgj+CSNRKeZZA/iLET2Kaj5KU"
        @"VtO/tskFp4akk5PYZh2NY9xjjxF4h0ZRlkeblou9DSAIMrOgOEZqTZkygY9PXpd/ZPfuswGu//GPf3mAPuadMJam7RXvzmHVGtBAqC1gfEooSojHkpH5A1Es"
        @"niiy1ARyu3bQVbS0VSfoK1vWnN+ONuaR3OUtl5MlCF0IXWT6/DLGrKRy/w7SsSphZIljYWrM8MMDnQwGG4l1kBpNIkpYiVizwpA2habLiHLJUcv0N2D+zpS5"
        @"2xyT31Emvg7zDwXUE0sdT1L3+IZm072mI9KQfO6baO01pG9/IfYKRW/8FqYWohWHH0vR85dhNy2gjXWY6CMoIUI24s9K9SqqmxFGskJQXasXrU/ganC8kwOg"
        @"iQOrIG3ovTNZIyTf6nwEgh7wxCIsDec5MQhZETRYamsM2jpLTZMBW2eJVfrE0mNCOmxE0Ubkg+yZk5BIIkQiUkKchIBFNBt2dEqZ5bTToQ26NKWpU7QziDLA"
        @"V+5qRy1o7JEA9N5HwCueB7IxvZkA3QHRIBrkobYTjQegmOOy0wxhY4GgMg1RiE5NYGZmoFTM6uUwyHLqIMp0poHNisNAmJzFz526gQQutkbglr5feMgS/OuT"
        @"7msN4F73jg+cWgvDldLbp9qsiiSLxMaTQ7JRNx6rnhCD9QrFMjI6TvvRfbR1eHJHJ1i+oY/ykjppZRUmfxmq+4E+lMWWS1AObA7VEs27tpGLJdPUxnDrjiKT"
        @"6XKeFp9LM7VYY1FXoLMDukpCZR68F9IE1Al+2FLdbzIHfVW8Cs5k7Dl12fcaL9g0JdKQUv4OZPGFJG99FvFvdqHf+wSyGGZawkmHnjtAcFETrVsk/BBKVzZ6"
        @"lLhl39+O+g8BPwLNoyTH5VRZoag/ZaKtYpDUo0mKFGK00o7etxcJMlI9VvGLghl1GO85u/5tPI9iyGc1RhY+SLGt+NqHI8RTICXKjiUxSkxKAaVASkxqCqSm"
        @"QCIRQRBjpUQbFYa8ctjnSXQUq+2sDk7iwUN7OHR0ilVLGrimRfcO4cemkYEfgVsODANDiE3ReACpHcG0CRr2c8FJwywrK/tmJzDdq1B1yNEhZOkyqNcyMLei"
        @"s7ZMtlWEIB+gw/OmsnIFpqfzkp137G5bf/76+eNS+P8ooLe2cr19Q0MXNctdgelocz6p2JxrUDAQiydUR+g9gVGs94TqSQtFoodvp8ct0G4cbY15TrxoA8gE"
        @"mGtAloGOAy7r0RJmFltBN+nRh0n3jVIqBcSxx9WFm3eV6ZcNlPxKJrVKkU68Wgb7wFWzjQmiiktAE8G7bCLlNHPO15RslO4ylXbGT0iJNaQttwM7fyWNl59F"
        @"9Ecnod//IDIbZMdwponb1E/w9BjqYxB8FFidbcckB9pApYTq94EPY4jRltvDsTHK42B+YjGo+KQlEsi1o4945GADwiwXJ1F8CfRN7bhqO37IYEjx6Ry45PgK"
        @"udApJnX4NMU6CNKUKEkz+VSqSDNFU8GrzfYnNi00smegAb6q9DU9m2jnUPgMbvIXMe4aLA1WsT/t55YHD7BqRQNnDTqX4HcNESypo/5rYLpAj6BMQVBAkwbG"
        @"HyUtLKN/ySHOWJVj78ERbNogjSP80CHs+U/GhfFP5dFiDCo2e7/lCDM0LcnyAar9fYPv/uQ/rQIe3rz5Orn+ev7jgGbrVg0Cy8TC4nm6aRMSRYRplbxPyIkn"
        @"EkdISmR8Vhi2XOpdGFDYu5POHLS5ObqKwtIzCqg/hAQXtka+nZkhCS0rLJ+VNM2H7yaogO0WbAF27grYOdfNxnAdiTc4AfEhxThgSTlkcR5cohnnNtuSgE+z"
        @"RZeqgk/BH1uK6SWzHVBP5EM6cgeIF59B7Sn9xO+/FPnJB2FCMy7JbBO/ogv77E7wB8G+A+xleB1F1GZupgSgFdD/mfmEaD4boOjP+tb/C9Jj5xGrYNpw28Zg"
        @"AVgi2U7AdsEuFbS9jmyIsJcW0FxmEUyzgfiW/lB9tsTHk/laq8sU2yb7OzVpzSaMyRh+PkTSEOgkNd24Zhu+1obdeZh1H/sHoqkH+Kp5I4HvoZ1Bbt1e4qWX"
        @"zREEmQOKe3QfXDoIPICwChhFdT4bwboAqY2ihVOgaLjgRMtXt8/hm4ukxV50bDTj6kT5jPMt5glzU8U7hSDC+rq41Hi/fk3use/95Fzg4V+0fRf8q1RREX8k"
        @"SUsbrnrtqdLTjfeJ5JuL5F1C3jhyPiVvHXlx5IGCKoR56vUKbUf3014yFBan6F3SRnl5ikt6seGZKB6l1AJ2JkFSCRHG0Md2kc9DECrEwl17czgG6Je1VHBE"
        @"ksNrnt6OkDiF+apivOD94x2yjJyebUdNW9FZtGV74Tx5AjqiKeLKc6ifqcSffSGy7cOY4QZCiJ9v4rpLmOf3IGYv6BsgeB7oUUQtKhmYRNpQ/SzCQyjFlp9z"
        @"qxT0T3A//RlrzGNrKjQMMpA9PI1aQXMeO2DQNoWaEhxK8IfHUautAvfxPskxOrX+zDzt2JASf2zzlh7nRGXDDYWW4FbzIVG5C/+0TSx0n8DKP97GOW4bt+o1"
        @"DIRL2DXVxp5Do2xckeADgz84hs40kPJRVJtAA2lWsoWkJoTaONIJBGXOWNOkzaTMLExD2wBucZGoskBa6EDr9ZYDmULqUesAwSVR5oY81fC6dKkZmp44zcgv"
        @"boD3LxaFm6+7TgDe9f5PrE4LuX462sDVpaB1ijQo0KQkCWXjaA88nUGTDmlQKhiKc+P0NqbpiBNylQWWblyCCWuoW4dqbyaVp4hQzD5qERN04xdGCUamiIoB"
        @"NgRXgfsOleiTteS0jxpNjGYW4gMdlmZNSVMhdZotdvXaegppCknSWrHnldQr6j05DJ3BPMX6C2muHSL48uuR/Z/C7J0HCdBqgi/lMdcuxRT2oO5pqH0p6idA"
        @"69k+Fl0ASVEeQPjScfWJPMEr7n+3ljgms8qkSCoeciF+poZ7aI4wp5g2j/oEs5hCNUWaLsOfF0JvsN4g3mTC3VSQxCCpQbwg3mR8GGchtVk/3RnEWYwPEB9k"
        @"/1c3SC3A1AzRkSb23qPwuR8Qtw9hTjF0J9uZ0jGKpo8mPdy7pwgW1Bj8VILbO56lCo2jSHMe6rNoUs1IdPUKMIXme1jfn7C0DG52IkuRnIPZaSTKH7/o8Yq6"
        @"FNJmtjKuAZRyMDoprrsf2sunOa/BLzoGD/6t/vP23btPMuVSUUqhz7uK6ZA6BUkpWEfZesqBoyPw9AaOgk+YLkboY/voZpb2UGmXhIFN3RlRxz8LZLLFPOtH"
        @"1WGoZEaBUkJH92LmFXIGk/McPGw5PNvLunA9dTU4VbwGFKOQ3rylPp1RTF3ausX6zNJCfStYapZ2qApGlcALXYHSmb6KeudPMF/6M+z0P8EDY9nIfSHBEcLz"
        @"V2I6D0ByJhK9GfUz2QuKx2Tb3UFrKF/KuKmSy4q9Y/RK8zOF4BNJ/Mc0ekbAp0jZoM/dQOPgBKboj3c4CLQ1qZJs8IJvCVaz8OzUg3MtTrXPlNrHLiaT1Qv4"
        @"rLviDRm91zk0jLM9g+MOqRu8MdgcyHxG4lrEMU2FpdpPF2t58NBeXlmdy147gXTXOOG5g2h1FGwMbhFxCTgPqcO4SdJiB21t+1nbHfDw+CxGXdYLGx9F1p+W"
        @"9d/FPZ6XJQlGLFpz+EIBv++I8at7aZTzJ3zoQ1s7gYlWxvDzAToTv2YR+brrrgO2yu9+aCT40JYtXPiSV51Y6BwgNk1tt5ay1inkPB3W0WmbdAUJ7TblhCjB"
        @"esXkLIztpyef0m2rdOYNbastvrmA2FMRGUPZC0wi0oeyJtPQMY87tBNtgikq5A37jsYk9FA2AywmTYxYxEe0l0Jy3jDX0GzdtgPfKvjUSyu/bNFBaYFZPR1B"
        @"SIf/bZrFryNb3kkQfhW59bFsMU81IU0N+sKVBCuOorVBJHp7a43DfOsKca0TEYM8Cn5bq6PA8eFJ5inuHycf/SywNZsQEoUZDyM4QPyWLnwzIttUdMxqxbQY"
        @"e7ZlK3Wsr21bdsEtgYAeyy98q6uSfS7qW66ruewumDQgvwr3UAn9xxsyymycFdP0QnO/Jdyl7AvXkroCqnlKdoBHJnJMzRp6Ch5nwR2aQZM12TbdtJq9t0Rb"
        @"W2YNpDP4uB9ysGGZ5esHFjHNKqktw8xk1o70jmMZtHpzXGEOAqUAs7iAr/fQ6Ozu/Nb3v9sBTJDh8+cqDIOW9ZICPMHS1H34LW/haS998Ul9RUtAlY5AaTNV"
        @"2rRBR5DSHTTpjxOWSIMN5UUmmu2Q85QaI3S0Q7m+QLktJt9bxzfaMLmlqN6B95/F6ESWd3E6ap6bGawMH8JakDCLYI8NhYR0Emk7CzQJpYjD0pG3+LqQ+sw3"
        @"wzvFudbJ1SxNFD1mtOsxqrQT0iubSeVj+M+8jXjV7egND2WOm7UUX/fI1SdjT5zOSPbR76PaBjINmiLSeIKcKkD1bkSaCNFxACM/Mzz5GTCLPMEXKAhBy6Ab"
        @"0aSEMWWQfMvXuoQSPJ62aAOlCVpBTA2YBcYRqbRg4VsGj62ttWpbNh8FkBRJDkLbIOnuGPnETdhpoLWGQ4pKs1jAfLbKpHbzEOcTimfONwhNkel6gYPjAT1r"
        @"EySypEfn8XMNTCDIYj2TkaWZu5QikCwiheUQhWxYJti0AfVFaOvEzy1kXsDeZxezttQ6PgDvspiRK6B4Eaee3oF44eiBU4A9/AKFYTA7e6iTBl1hqaeWUFhi"
        @"fb1s1Hc2fGPw7X/8O0/q7DLk7LxpN016okXKUqczSugPlYGwzkBcoaezj3B2EQlqtBVmkI4a4eEFyks6CMt1XLUPpIq6T2I4iFJAfAP8jSCP4uUFmOkKQU4g"
        @"UnxD2DuWo0Avonm8NI9Hpu4ooNkA5zNivvPZ89gCTPcE7rGooyQRfeEnkNq7cH/3SuJzdqDfuBlrQrSh+LpDn3Ia9gwPjQUk+CNUl7f89NwxUkg2S9dGBhIO"
        @"tdQXcpzHcWzjw+Pg/hfYdcckVwqCQ80KhDcAp2RDjycWfa2XyZRaE6B7QfcAu1F9lExLpngaGfjVohqgkg2tSHNI4ztQaMM9tgTefQvBsWlkqmA86WAe/aeE"
        @"/DD8c/QmjqZ9YBZZ1Bo5uhB62Dd+iLNPSLI8eqGOm/aYgRw6WckWNTp9XC/YbCKdDuKYVb0NCqIs1BeRrgA/X8E2q1mQSZPjx0psmokinEObESYO0MRp0tZu"
        @"ms10o4h8VX+hLkcanOPThc3J5CMX5IJFSZImNi5gq1WetGSGZt8MqX1MOk2OrsjRGTm6Yk9bLqEtrhKWBpH4dPrNbUTpPIXyDEkjwU8ldK0sI6aG+qUoOxHd"
        @"i2gxq4y9ZnfwcBZtHkEWKmgs2Ajm5mB8IUe76SdVi0PBK7E1lKylXtPWkCQDs/dZyuFFWm14wXpHgYj+8GuEtd+i+a4XET9zEv3ODRgJM+lUI0XPOxVzcS/a"
        @"uBOxbwBORxjPctZsizvKQgYqmUSpt5KLADVZp0aONbh/asuH/stmgZpZ72Z7lb+U+ULLJSjnIrIepTPbs6KTKIdQ9oHuybbJMgbUW0aXNlP3YFE12YJOCTNu"
        @"jOah8X3INfEHu9D33II9mkLOQNNDTvHrcyTfFIo7Gnwv90p2plcjspOmWiwBsXQR0c3QZCZKVgw2AT/WgOU51PmMzqrHLlZBGx5hHg1DBjoatOeU2epidmXW"
        @"6pg0W+GnjRQ5JsVyHrE+43o0m0gxwlUWCeKYmbmFASPgtm79+QHd0TP4/enpfXdrLb627hpvL+Wa6yuT96LNUf+CqzdIUOqVOik2rGGCGmHgCGOQOI8P16D2"
        @"SYgOEpQm6a5MEnXOkATgZoXcyhjPAqqdiBzM8kQX/n/UvXeUXtd13v3b59x73z59BjPoHexdlChSpKhiybJlVcqWXOMmJ05cYzkuCU07jmPHJXFc5C7Hki2T"
        @"bpIsiRR7r2AFCBAA0ctg+szb773n7O+PcwegHbnFdvxluLAGC8AavvPOufvs/eynIN4Hr0PnA2F8ZRF6vYK0oswsxbTSASbiMfreFzHyERVriVTIUsX7sPXT"
        @"gp3pz7kPKaKORBImk4eodT5I/9+8jcp3lNHP/DGShsWJdlP8hZdi3noTZL+DmPeh5u2IXy5gxHmQYyjHC3f9dlEuI1RKWMqopgHGO2fe+Pf/CHdIgvAKqnuA"
        @"3wMdCkOm7xfhQV3Ox5BECBaRuPi9KW4tLfplRWUKdAt0PoPEC+jZIfRnDmGPKtIwxVCp+O0J6RcNtWfa3FP+Cm7P3s2k6WG0VvBQIhIdIGKQY+0EMsFSCHPP"
        @"LoUhGg1RHEVknIqGC8x18HHESN0z1oDD7TbG5/h+H9/vgokgy4sbVIsBueB39LqoscjSMr5SxtUqW3Pn5R8S+xYV3nXLwG81VT/bnJ39sIxs/ZbjL9938cuP"
        @"fDq6/IarmFo/QKMxhgzsROMtqFZRtQhVRAfCMMJV2NJfMrB5BTNzhnxecSMWJcNEg6CnwHk0D7o68YLkOaox2skgA1cskhaXhIw6NRkgEzBYRA2JNVi19M9V"
        @"5nCOgqo45PEZHFYTxkt7GOq8m/TDV1H6j+vQv/x9TLvg5HZT3MZN2Hd8HaKfAN6M2m9AmAN5FZG94A+DLhe9bFRYedlzpoqeGoJDyM9pBM87If39ZhhVLfii"
        @"pUIMsFBgxxJ0lRqjPgnQ1yq32mRhViQqcOhSCBhiDXARdL+AmFn8wiD+F+ewJxQZMGgOxjrchSX69xlqT7V5uHQtf5B9gBoJuY8xVIk0JbybQpUaM62IfhZS"
        @"LDAE+13qocla9QQshjqRgFrksaWSKBMDEW6+Q+QdOMV0eoipQ79wZ8KHr2PD96v9HtZYXKeFHxnGlasDr3kz/15varRqyAgYETkL/HdV/dW7/uTP/+3zp8Z+"
        @"cfcLid8x3zJXrD3NlrHnGRoZwgxdDfH1iK4D4/Heon4DYt+N2VJDJu7ClO6DyQq4QSSaBL8nXC/F0iPgkIUxYK9T8GUDZLW4YoA6hgoODVebF8qxRQpY0/mA"
        @"ZJy77SW0B8YnjMQnWNN5N9nNa0l+/q3IXb+ELJrQ87VT3JpRzHu+A5L7wF+I2ltA70F5BsMMqoUCnVANtfgvLII0WC2QoAwEGblkBRJiAP073/fVgVFEz7c2"
        @"CEgUlo25R50L9NRzPXmRDGJ84IMYW3hKJwEtkjdC9xOgR8ENob+zhD3kQmXOFBMp+UUl0gcMtac6PFW+mt9Kv47EDBDpIEpMhCUXKcZpIZYKaZrQV0Mp9hgL"
        @"vtlDfQOk2MKqFpyWYK1GluFtAgZGqg492Tt3c5peD+oNyPPgeV3cq1rMI/QMTgTtdEWmJuibaJwHPpEEaYbK3weOjl4bO6Gq8su//MuJiPTf+g3fMHNGxjjq"
        @"1ukyNTrOM7cwy47+NOu7XyKZeBEt34K6a1BdRjgRKowMotUbkYvGsckEyAxEY6HPK02iWS9kj3k957FMN1jMShz0dAstiydBJSbVHCtRAK0kcDV8gbOe28yF"
        @"kBUijRiKFtjQey/5JR3sb3wYeeTXMbMZahPoOtxgDfu+f4vUn0ezRbzdivG/AxzFqEWlhFBC1YUFCFn4oVHIP1YtCIo/08IOVwppVJCQvGay+6sddIFEFOXm"
        @"XO0p4MY0DStrr0WhNoVpclj3yapLqSuQDckRNiN8A+o+jcSLkA7j/ngecySHEaAXYB93YUJ2v6H2WIcXKhfzW+nXU5G1lHWcvsKwqSFA158s/i9CyVTppmW6"
        @"zjJQ1YAktvqB2ggYp+cWy6xW7NwF9EOEsUET+mIN70ve70NDIc/O11tDsCy2Bu138EkJcR6JDFkipf/+wNHy7bffnt3yoUCQ+ActVkREueWWXFXljR/+6OgJ"
        @"qXJWB8COkruUnnd0bUK21GCzzJFMPgTRRoz/EmIW0fk96Okv4hdO4RcFe/NNSN2FQcXUIVqD2iUk7oR2o52HPjC1iCkKjjH0+sXxUMGpw2JD2LFo4Grk5+ug"
        @"L+AFg6EepWzOPoJsOgCf+h7Mvt9Fjy6hcYLpO7LEY977fTB6FJ/uxpg6ovcj1qDawBfu+eHdLhfEKVNgGAUuTISQFH8XnetfAxpyBLIT4e+K1uHcViIwLl6T"
        @"cPuatrCfhzWw0/PTv3KeG2IKwpmEmyqs9jNgDSrvBL8X7DBku/CPPI05myMThQ+JUfyOEv27LPWHW+wtXcLvpN9IpJNUZIIcS5mE9bKeV/1hDLa4baAsFZou"
        @"oZcXwl0rxevMEOdRZ89nwqzOEqkLr9fBaCPg6+JSNBF8Gmi16jNEo9Xhp8BZJYy4NiLXTBwpSYXRw2fao99/24eW7r///kjfrP7v6qejL0NKworoFR/66Ka0"
        @"UqPnSxzNy0S+gnM53hiMQLTUY2MySzL+An7lBbp2I+1jKb1XBL88gJ/usP4NL2PyZaSxBUmfhV4T8Un4wYgPdrXqgZQiLhuM0suk6AvP0zBNAXet/tDPdZWh"
        @"f6FqYjbm/wYZ+BL66Y+RzP8Z7JvGmwTtOPJGjPngDyNrRxF9FSm9JfxAtISmEq5LF2idmjqMEzQzSO7AZWiaBVQmB59ZNI9DNolGuDxHvSXe8mbMtr2Ifw4k"
        @"CdmDZMAIQrfAX+U8yT934QDkrijXwcKX18B/SuGSalbDiShyMkZAboTsk0iUoPoh/NmHMaYLm2M4I2By/NoS6Rci6g80OVi6gE9kX08sG6nJBJkajETsMBcw"
        @"RBUVj9VgGiRYYiI8Ss8X7ZxVnOaQ+tcssc7bMuB94BxoMLwcKBdLpixFkjSsuSOLSpHGqzlGPbENEgkLOJPgdUWqrbOMR8vRt3/rOz/xy7/xMz8nEn8u3Aa3"
        @"GvgJ/qaD/b8f6JtuEn3wQc7MLHTYsRHv0IXMcCZPICsTS47FY/0Ig60+w/ZZTsw3mKuPMX00hqN1knaP/sk2a1odahLjqjNor4PpESqZDyiFeIfUM8SmSBw8"
        @"5UggU8FjSCQmwhTkIodzvjAh1wDRhfRISiZmO7dSt79L9lvfSpx+Hp7aj0mScFhK4OM6+sA9SG8GTR3adZg0Q7IsHOK+DyaC/Rzfz9G82IAV/tG4wOSTQiIo"
        @"riguJgxM3oLbYODWW7CT6yE7FeTD8tVhu6h3hIdUAuOPLAsPjg8iAb+qB9DzZiyyyiySYjPoTXhAojqYG2DmTqgcR5Od+Olfxq79ZmToGLr7t8LbvLNKdrul"
        @"ducKZ0q7+GL2r6jLBipM0aUECJtkC2MyROp9gSXFoI5YpIAXXXiYrCAWrA0V2bhwPZ5jzK12TzmQG+hBNXKvab08kvYQGwfYEU+Mo0JORZXEGhLj8VIiSbpM"
        @"NU+xc9yXx8uzN3QXj1zf7878V5Xy/xIZ2A+3oRp81f56Jkv0ZcygfWQNlUplrfeKSVPJFRZzS+wSymmVyHtEDZvbS5xs9ni5O0o/GubkQgM5VaPebdNoLQZ7"
        @"2Qz8xArWa+GUH3pnQQoOQB7g0zjY4xIJNlodgYoULS32fqt4s5fQfqAYidlkP0Gj95PkH/8aShtfQO/eg1biEC7kBBYh2j+H78xhonND+WvywIvexRV4qxOM"
        @"N2heeDarOVeNQu8rmETPIU7SEKIypCMWU6miuh7YgnAtcCHoxwvpdQI+R/v9Yl38V9f151iBet6IZrVr0UIkq6UI5HXowUcw6RF0Yhx9+gBmyMGWG9DyD8LW"
        @"x8gHTpDfHlG9d5752nYe7H4LddlFgwlaWBwRE2Yta5gg9Q5DuPITLDkuWINojhGPjeQcyCNRKCRauIp6Vnkjqzvm8OATKN6Q++IPCmal9WA9JQNVzamRUzeO"
        @"moWByBMbaCTL7IqU12121OSky47dYSvb3vUjmTS+N22euMO55KdE5NXw3N8fwazCLV5E9MuRk9QYQxxHU6ogqQOxdGzMYj/CaBxMBXsRe5oZ0+kgh12JvF1j"
        @"pTeIXalQa1dZ2wW6St5SxPXCwOBCKM7qM+UdkPUhcoG0VrQdSRSCj5XwbwXBipA5pZ8XpKMCTltrH2Cq9+30fvKNlN54BrlzN2YgtBm6KCFmIhPEWKQWKqGx"
        @"RX/rtehJw/HxLsCJ4bVpaCk8oUqtHjQJ+SreFESianDY9+Uc8+YdyOAayC7Ay67iKT0F+krBSc6hOMwUm05ZdTnwRS+qhGG06MFVgu8dLkMrFuJr8C++gFk6"
        @"BmMN/H1LmLkcdinM/hQy/GHc5HVkX1Tip/fSHr6QVxb+NVXZTJUJ+pRxWAYZY4w19DQnEhN6YA155aqrk4OjZJSoosGaLAr54LIaPFD0frrKJjzXB1roQRIJ"
        @"EQouRY1Bohi8I9aMemQYEMegSRmNckbjjLE4ZzjpMDWywqXVZS7YkDKwZaftH/xfdA+mzg5fXE0mLvpmiQben3VnfzEqj/2siHT/LradeFVNc1XxCpkDieib"
        @"iEW1IS86C5WltNJglgrz3tLuxmivxGBWpd2JoBWkRLKcQ5aGw5y7AiAoKp4Dsh5UBErBMIXYUK4rlgwhw2qCLRx32i6jl3mMGBRDw6ywof9R0g9vovyBBL3z"
        @"McRGMO+Q+UJVvWpfhYQYNvVhWjerw8gqma5Iu8q0GH4oDLspemvBp0WhCa03VBTTMEgd/Lhir3oL6DZU1iMMI9JA9QFgJnA3+t1zh1kK2HH1ZuA1vm96DgbR"
        @"wtnfIxXBl67GP3MIM3cMGa7gH+hjjucwZWHOoMcewJcz3FODVI7upe8u5MSr30dZLmQNg7Q0QrRCzTYYtCN0co8r/rc9yXA+JRJBscHTw2fUYk+lsCZTC1Ir"
        @"F1u+cEsHbvgqP3t1uLHQDQUsNqt/7tHIIj6jqhkDYhkpOcYkZa3pMRl3WBs32VoWtk6cYd3wNKUNF5HX3kG8/Rk4cafNpx/VdH6Xt4NXN+z4zlvz5tn39ueP"
        @"f8EnlXvL9bGnRWTly9JH1Xv63W5G7iDLit7OkKphiRi8waohzWDZVkkFsryE0yppXqbuEkwT8hbYjuKyoLPTLKARgdoZqq+mGVQcWi6izRLPwBAIfXLpEkkj"
        @"wO+ieM3peEdNhNxYxvLPEm8/gvuh64iefATNE9xZhdQE6mQc5hRRxWcBdVMsvqCVkhc2BmlIvVKnaF/JcnDYYhsJxhoa40JtzOOdR6omREXEHmpAw8GlEzBy"
        @"Leq2I2YcqBTLh6fCVi/PiiG4IPNoYK+rKwgb5yioBRKiYQhEFRLwtZ24xw5iT55ERsv4B3PY75AJE6zO2ik+WUPvzxapHH4QnbuWzlP/AaNTVOwIkdbxvkyj"
        @"FDM2VGM5A98CzQVVw4rvIzjiggsXIzjfp1LOqFR8IAAawi2hLhzq4mEwqz2c17DtdUEmlvZC1AZRDD4jkoxEUsasY0OUsq3cZXuyxLZKhw01z2RFGRmcoFze"
        @"galOkNnLED+CDPwXdOejRM2XRNvzNu+9qOnpl32pNHJ5lIxejmz7kc70xOHu0vR3fdmWw1pLKY4qmrvQ5Be7fJyQiWURUBxNKdP3hjS25LaMMzWy1JJ7S6kn"
        @"5MvBuYh+FuiKTs4t1EI/KoHcXSuh1RjJU0gsw+OK0MNrD4shV1d4TuS0fErNRHiBWPdjq47sZ55j+mmlk0OWKnkhvfIeXJHvIT6oW6RQjER6Xt2gYd9XfFfQ"
        @"RUjxOJRe8EWiInDVOyKGb/b42YLQn0gwVBz1yMXXo+xAZDtCGaWC+AdR9oNLkNwFRU1eDFOFwfNqMWaVDioFL2J1R5OA1jejDx4nOjKHjpZxDzl43mPHTBGA"
        @"lOPX1si+AOXnXiRrXUn/vv+My7cQRYN4STBaYWJYWDtu8Hjy3JB5QZs+qHvoExfmc4qQCDia1CoppaoLt1MMDMdFQM15JYyySnH0kES4LIbc0+1axEqIvysW"
        @"/VWj1MrCUAxTkWNT1bK2IoyXKwzWypSiBGMS1DqMZEVG5Qrafxk39zisdBCzVsRMGqmshfIm+mn9GbGV/1Ye1Me+bMsR2jjto4RtnnMBNvVhOEkRlojoCeRG"
        @"yLzBe4NEFRZ7EGeGat/QaRZ2V50+tmzO8x1esy6llyFRBEMVaPbBCsNTENGmp4s0dCupuML1PmdFU6ZMHXXKjLyZ9Ud+hmS6SXfG0CEDE251JxrkdEgoHAZi"
        @"ESKjhVo9dBarsHO4/UP/WFFh1YBJENoiVFOlNwv+gmFYXIBY0Bgkdsj6MjLxlajbiprBwrbAAJ8N7kK+jHp3HpJzYUAWv2p8voo/63lehJcwLA+swT8wg9k/"
        @"h6wp4x/1yG6HDK1SZh1+e5nsnpjk6Wkc19B9+qfpmu24wTVYW6bkoFH1TG6WgM6MCwOnlX4ukBm0B7nmBaIulMQSSU6fFQYHckqVQsqWgBkqEyrVa3yuVymC"
        @"VpGkjG/V0Qza7TC7eDEYMfQqA7R8hNoagrDSq3DMpUz2Omzs9tme5qwrzzJ69nOMDh7GbLkGGfif+MUfwL/yR5jlnTBwI370RlcauchqZc1LudR+t1Qd+jUR"
        @"Sf9GxYpI2InjPcY76LvzfN5CNZEZGw4BJiitU08Ul+j4iA5lmpml3Y7BdNBmFjK0c85v2oqdgWYuOL5MDiPZMljLyFoYkC6ZWyCWVUK4Q8SxQpfcB/+82eht"
        @"PJv+FsP6UwwPzjKqJjgiFVXGr66iNByUgK8avBpyDH0x5BKgNKeOvvOk6ml7ZcU75jRnBscF4pmih7lmC1qrITIHSXBZpZKhW68EcymitWJOMsAxlPsQZxHn"
        @"ilTaYmfhA+wXYEc9Lw6gWLp40MjDcB3/4BzmuRXMRAn3lCJP50g92ACrOHRriezuiPLuRVx0Pa39P0Favgg3MEZUiqhFYOue8hqQqIBLLxWqTim3BRrQyzxp"
        @"3qeMJcdgSPAyj2OZDeMeqQVeGSVBB0pIrx2WJ/YcvzWw5VAoDcKyw3tY6eT4VXjEGEy9hubQMhWaVohMTBynJNUalYalPFCiUy+x/2iby2eVda0XKV37DHr0"
        @"CUz2leimd+Pq2/LS+suivOUfjmpTb7ci/TB63G5FPuS+bIXO0px2s3PMDoJ3DpPmgaa4er34QoRqCAE/KD7NkHINbxL6UYV2ZllazmFIYLGPbi3gKSkc+gGj"
        @"BnGKZgaGJ2DuKGoNA+thdKhNb3GJOA6VzOMxmtGhTVcyEpPgcZx038rL+VexbPbQZZG29vFIoIgW+KhhFS+NMBrhsTgxZBqGogxPpn26NOlpB0ePPgt0OEuH"
        @"Jbb7B5iMelTefTl68kFMEkQIEgl+zMDaq4NTosTnDib+z0GPoj4KMiVfpEu5gG6cv63CK/NKoFZ6H4Sxow3cQy3M7jYyGpPvFngqDZXZgsQetz0hvzui/FST"
        @"XvU6WtO34esXkQ6PUSkZGiVPPAasF4gk3LaNkKJbOu0pH1HyiiFNcjSFsonpap8Y6OkSCcts2pRBxaCtIG5g0CC9PkQGb85zvI0RfOTR0k5YOY0xMNf2+ChG"
        @"TfDicLUyZELXllmxQhR7pFQlqUYkVUt1sEEW1zjQGaa/vJErF8+ybf3d6GIZP/FOpbbNl0e3RnlHH81s+Rtjkb7qMzFcnUtBS/wyB/omgQepVuKQ+exUSdPQ"
        @"7ENBLgpPpvgwuKgopDmuNgBxiVwrtIhYWO7CoJAtKYnEYShaJfnoaxJU24vIwCVQSfDGUlsTs35jzr7FWaykxJTINUfFkmqfBWkzSQnnwWjKqF3DoFnDguvh"
        @"dY4lbdGlh+ICll1U5lWAySAhx0UUq4qKw2lKTA0vTTK6iCbklBgxcH3epPqmzZiNEbwwFwxSjA/Y1ea1SG1r6HOMKb76EqqfBu+CONWfR1PwFMNhkR+u59SG"
        @"4e+NIhN13KMd5NE2Mhnj9ln0sT62EYZdrEN3lnEPWyoPtVisXc/smR8jKm1DRscZHLAMlD0yAbpRkFIYGlQFtgObQUeCWVCvrPRFKBHhAStKmYgmswzQZdPm"
        @"0MZJBL5cRioR2sqQ2IRvt7jRvUiAF81GdHEfWQazywpJGRWLKSVQraFLPbSU0IoNUWIw9ZilekxtqMKW+hArfXhaJqhkHdLjCaNH9lIpv0XtyFVU1u6webP/"
        @"y1Fj8gdiEVcwRbO/Q/X9oCJQK8Udul1wTrTXL7wUCktyLXDIQimChuHONBrY6hApJZpS4uS8BRXcTHZ+SwavWVAUcQedRaiuh8FQ4c1gjS0Xg7BIbpaxBWET"
        @"9XhJmdZ5cnWogLcRfcnJXcYQCbvMOq6ItnKx2cSUGaNmkqL5yCiCHIL7feGAHwqmx5GvSlEL7Z+ADnBtfJb1to9//7XIzF5MWugHnaCJR7ZuLTyhy6ALRT/8"
        @"J6AvIHkpcH/zVQz+PHa7yjo0xZVtNODuuqaMf7ILDzeRkRj3skEfSIkq4UbAevSCEukjhvK9LWaTN7Jn5Xvpmk1oaR2xFeolh9kEcrFBRhRGgXUCuxxcBowp"
        @"ZkioliFRyFNPbILtT6KWmsSQLzJc6TC5OSscnRyMjiGlCJEMiQWNFB8FJJfIobUBfCro7Em6LmK+o5hKDa8GU6kEg3vnkTghK1Xo12v0q3X6g8OU6iOsp0Ks"
        @"hufsKM/KKC8sVHW5O+Z08h1iBjb6flN/LB7Y+L0SDrOR/11e/2UO9E03Bfg57Z0m6wcadrdf4FeFQsF7NNDezi9M0gwqVaQ+QI6hZyscn3OglnwmxecCkTnX"
        @"bqwyzcREkC0ipgZDm6FkoFRmwzUxhjk6OkOCOf8EqWORZVqmiwRPIZwKqVh6KH0cojFDDLNNNnGxXMCFdifr7DoaMoCVUoFwRzgNEJ7TVWpvVMziMYaEqsS8"
        @"yR/CT1SRN44grx5AokBhpe/x6wZgfBR1MSoeZRH0GPhPBvf8XM+xCtVxnvugUsCWUvhnmICPT5bwz2XIA23saIw/YNAHcmwc8Hlih14U03/UUHmwzYnyG3i6"
        @"+91gNiMyQW6EsoAZBt0i+CGPTIFsENigyHUGu90gY4LEhlIlpBt4l2MkfPcVKVGyGX0/y9oNPQbXudAOWZCpKcS0A/cqKVTpCQHtSTzUx/CLK9iVDm1XYqHv"
        @"MfV6cIoaauBKpTAyRAm+VKVXqdNu1KnVq2w2EReKsuiVZlrmmUU43q/KwLavsWZ4VzfNo68tD0z+F9VbTVGZ/55cjolgkDeQ2JdMp0uu3pp2G3F5SPc659xz"
        @"HnsMLKscLyCNQXxu0WqDE/On0MziljN822DKFu3lSGwLHwstJEw52p1GRq7CtE9AqkxdHlGKW/Ty0wzLVbQ1w4tDNdTaUyywVes4VgNp9BzV0qOoCZivEWhQ"
        @"o06dSbOGNj2avk2LDm069GiTaQ5CwRuJiIjwvsam+Ajbegfov/U6bPkwMpMGtUY/1Hhz6QQqLixNZAEYAB5B3PNIXgaXn+Pln/M+9/oazkaIsPC+OMwvZsjd"
        @"LcxwifwQ+AcyolLR/1oHFyT0n7RUH++wv/RGnsi+i3GzjVjW4SR4XpQHFbPG4LxiKgbWBnNXpkDGBLVFSm4r4MqdXritApfQERPRl5OknGbn5SnxEOTdsPiS"
        @"NRPgng1m57bA8s1qXUyR6lryE2dJMjjUh7meRSr10OZNjOFMoVovJUiS0ClVKNcT1tuIzapMGeFouwOtVJdamRxbkmMD66461u6Znx4bW/Olv4m/8bdX6DtC"
        @"rFYsdkb6/RRUfKup2ssQH4Y4Key1xJ8fbiT3aJrC0DAei6kNcWQRml0lzpV8LkPqCWIkRFCschRswYvvHoHaRVDy+JU+YxsdG7fn9NwpvOmAKo4cR2BqndFp"
        @"OqaLLbJKfEHHWP21uqQIMldPSk6ujpImjDPKZlnPdrOFLWYTY2aMMqXCeNJRk2BKc7l9mSHj8F+9E3NsT0EQ8pB5dH0dNjcgbxRCgEVUzqLujyBNiyHQFWqE"
        @"1x5mfY2bc2H/NVnCvezhi21sLcK9Kuh9OVFJQjxy5GFnQuepcJj3lF7HX2bfSkm2U2GKXBOUhMq4Ek8IPvNIW6GvwSViC7A2tHjYoO6yGfT6wnJm8BQhRJqS"
        @"AC3/KnVm2XJl8EoUo2hjEEYqiGmFmIlSDOXVyAaLxglqN5C+ehQBji04ms6i5QHEJrBhKmgOrUGiEiRVtFRi2Bi2AOuKd+VIOwMvXjA0fbKvXJt8bzjMt1sR"
        @"cX/bYf4beujbwoFOO6fV9VdEAgFfev0QH1BUaC0cXUTCOk2dx3f7MDYafICrVY42I842hZKF7GgfGtXCZ6BoOyMJw5VN0P4rIatEa7huhzj2XHB9RpMzLJtj"
        @"RBLjcHgTqmNH25yQs9gC1OOcI3NBOl0dVl9jaxtue09ORiYZFmWIGltlPZeanVxgNrPODNJQYYPxXNN/ivziNUSXJvDqaTQ2gT7ac+glE0hcQvwESB8hRfzD"
        @"0H8JfBwUJ+41g+D5bfZ57NY5mIjwhz1yZxszmuDOxOi9KVECUiqu8l0xrWcN1ac6PJNcy59k305DtlPRNWQa4V2JyohQnzLkWSD1BxU26IJHl/Wcy4JSbEfb"
        @"MNtUmpkj1ZSMfvAwoUeaHWZ0pMnUxVlwWzIZjG5AqoJGgpbLUI6hqLRSiqE2ivZiskNHkcRwYMGTJxV8XAJrkHVr0F6OiROwwUrXlA1TEUyIMi6GNnBkqV1U"
        @"JUWdeU5EFr/zO78zFvnQ38vR/2/0h77nnj9fKeHOkKVopqrNVpAw6Wt1ZMV2yBVLg04HGRvBlEqYpMKsK3NwAZKSof9qD41KaDXCqy9IN4WfShRBfhbyA2DW"
        @"IXkXljtcdLNDzDzz+SFiMSgeR0ZKjmA46U/TkS5gXqNRXWWq/dUHWUWLCIeAbphz4TspTrsIGaNa5VLZxKWyjSviGTa6I2Rfcw1RZ19Io1UDfcWNJJhLKuCr"
        @"IOOoNFEWIL8TyfMCc/aBI7K6AXScM6UUkWC8Nxnjjyv6mSambnEnLO7OFBu2QJB4dHtE6wVDfXeXp0vX8Cn3zdTlAsqsowf0tEx5oExlzJD2Vu0dDPSLxK9F"
        @"LVq7grmIoI96uvuFMy3o5n169MhIqUoFtWdo+6NsvKLFwJSQOxMWSJO7wHqIR0IiVqmMlCpQLgXab3UKd/oEfq5LliTsnfNQreOIMNUyjIyh3T4aBQhPI0sc"
        @"wbgIDaAhcMIr03Mr2NQhzRYVlx1RVfnNV175eyuQzd8kSC4lcVbBz/tuB3WqstwMbusq567OVcm1aECo6XZhYAAZHgaNSeMaz51WTMmSnUlxi2AmG4ELUI9C"
        @"jgiFUkUUTfeg1e1I3sUtZay/sMfWnS0W8yOoXcKg5D7FkxZVustRPREYYqJ/JZtHCqycc8vJULGVVYhm9XNh86WB82i1yZhW2OKfhppD3rEJf+x5sAXw13PI"
        @"pWMwEKP5GlQyhD7oM5DuBx8HElYeFil+deJ8bZxb7mGihD9j8Z9pEVUM7rQh/2w/eGzHoJHC1ojl5y3l3V2eSq7mU/k3MCi7qDJBT5W+lhmIKtTLwaskTwO/"
        @"3rswtOqCojUwdcG3fMgP3Jcjn/KcnYGljtJ3KX3t49RRlYRF2YMwz66vSBEbBf5GdQDGt4drVdaBGQczhNoBfNTARwMga3EHjhLnsOgMB5Y80hgi9wYzOY6v"
        @"D6CpK1z8I9QKsYFSsGKhZmBPNyVbaGO8F7u0qANx6bSI6C0TE/+oAx3kYs4xUIoPmqyHiS26uFJIlVaf+MJyqlCpKkCe4YzBrFuPEsHAKM+e9eSxRfqQHclg"
        @"ZBQGC12cDQZKGoNJypAfhMYISgltd7D0uPSmNj1OscwrxCRkZKFfNhmR8RzTUyywRKy2gNyC/ZfVYN1iNMiWguLJFKCDFqhEqNKWHKsh0qGsMGDmmEofwl2/"
        @"A7NxEZldRkoRmnt8JUauqYWH0oyBNFHmIH80UG3dKkQXcPrzll0E1U3mYSxCFwz+L1aIIoObtbi7MmLjMTWDxIpstazssdSe7/JU6Qp+130TDbmchq4hB3Ip"
        @"M2aHGI3K5N4HwCmHPFWyDKRr8KkimwRtC9IFl3v4A2XxiOFYS+j0erT8Cj16RMSImaHrXmb9+mU2X69oPwr8gLFtmPpG8KOIbAXZgLIWZSz4iJitkCrpnuOU"
        @"EsPhFTjTs/jGMOQgO7fg88LovQCvpUiWNcUK3YrhhW4Kiy213baxS/Ody7ZPHQS46B8Ql/w3HOhbcF6xPn/CdJshEXRxqXDcic6LRlcJ+68JrtFeB7ZsRcs1"
        @"7OgEz81YpptQstDZuxRMzqcGoB4Xq1KLxAYfJ2CWkWQGraxHej1YzLjmzStMlBaZyw5QMnkwM5ccp6stQ5/9ehAVR6SBfxspf+WzRYqEqlXjQ1+EFuWF7YEj"
        @"wlEio4xlvTlEVU/iP3AjUf8IRgiylJ5HLxhE1qZIXi/YHh3Ql5DeiTAD+FXei5zr7UWC9s5lDkZi/IrF/2mTyBt0ISL/vMNmYGoRRB7daVnZFyrzk8ll/Fb+"
        @"zQyaSxlgkj7giFlnRhiVCql6vAvU1jwLTqyaC9ry6CZFKoLO+9DC3JfT+0vLK0uGpZmcdr9JT7ooOSMkmMrzRBznoneuUBm3OJegZUEm3wayDuEGlOtALwbZ"
        @"hrARo5OI3YGeOU52PKM8ErNnztOLq2SVAUhi7K4duKV2KH6+4MT7YIvX8qGlnweeObMEra7qygql5sqxX/mFnzlRWNT94w70LbeEzxft2ro/7rdRg/UrTWi3"
        @"IUlCG71aeQqcVaRYa7fbyOQ4MjCCrQxwrF9m9xmlXo/o7WvjFyKkNAQjMYzX0cESWouhUcZUGggHYHI76pV8RZncmHLpDUss+SN07FGqUsJpHy3WIZEaFnWJ"
        @"YxyjJoZEoYJQwVBWJdEg9LeqqzLV1/jQnccbIpSEnCqeWn4v+VSEfdsGpHkMhmLUeLwVzOuGQovBeGERtoD096BZwU9ZJRwV20FZNWzOFBmJ8b0Yf0cT60BX"
        @"DPkXMmyu2ErYALItYvFlS7y7y2Oly/n1/JsZkosZ0HH6mgElNpo1jFPDF8IDHGiu+FzQXDAtxQ2B2WZgsag9C57uryh7l4WZBU+r16ZDi5yMCM+gXaRln2V4"
        @"YIHt79EgXE4UhtYiQ+8AvwPMVyPmPSBfgXAlKttQLkBkkPTFw0hbyI3wxHGHHxykb8rYiWF0/Tp0sRnec+fCLJMHmu4CSkeVowoHTi4hmVdtNqmh+5PIdosz"
        @"+o870LfffrsH+L4PfmhfkvaOq8/RtO9lYREpReck11psuwKMV+hwuj18uYzdvAXKDXxjlIePKqVqhFtQ+i+3EbMuYLQlC40K0mgglSpEVfDzyPgAVIeRbg7N"
        @"nJvfs0xN5lnMX2FAolB9V3F18VSwHPUnmWeRIbUMibLGwagxNEQoa+jTrAoGc07iJCLnDrTFkaAM2jkSdz/69ouwWxze9vGNBMkcun4Qs03BVQsHoyXEHYLe"
        @"Qkj1cgW3xXNutvBo6JkHLepL+D9ZwXZB2xH5Fxy2B6YcNoBsjpjfZ4me7fJk6TJ+M/smRszlNFhDXzOEhG1mLSPU6QcB2jm1yyqnupxDFCn2IkGcQXsKVUPr"
        @"V1L2PxZxsqWsdDsssUiPHjktRsUS1V/ApUfYcfMywxdbNIuQcg5jb4JoB+haoAI6Drwe+ArQq8HchLancc+uUK0YjiwIe2Y9MrIG5yz2gh34qIKstMJA7hyS"
        @"50gWKKmnPMwZ4bF2yvKxs8SiyMIso0lyf+483HLLP8jB33x5tl2gl7/lPTctRnn/KWm3EIxyeqYYDP+KM+E5Fp6qDzZf/R5m5068LSPja7n3qHKmHZJm28+f"
        @"AQZQ2yhUzrZgpwWPNnBIMotOXQpdj1uw7Low5fpr5+jkR1B7klEZRNQR6aq6XkgwHNAz5JKxdUK44GbH1nHHeEWpmLD7i8RgZZWqdB5KWz3QJY0Zlpcx1TPI"
        @"By8CGUImLwv5QKlHrlwHcRv8CGq6YObQ3qsFx9kXRjqcNy8ssrxpRBCV8X++jF3KoWlJP5sjLTAVgxiPbjbMvWIwL3R5MrmI38i/niFzOQM6TqZKRJ3tZgND"
        @"1OirK4hXer7rQymJUMNjdxISaduKGYpo39XjwK9HnOgKKytdFiUcZkdKVctsb+TktacYrMyx7SMhSlkjg6/WkIGvCgoUqRdk7sKUQzYi3IjYDfjDT+LOQnXY"
        @"8uQpWKREPjAKcYK5+kryhQ6a52iehWiKLIN+hnTgdAr7reX+M0tw7LSS57a0MNu7dO3ggwrc+g/on/+OnMKbTOY8k/XybtNehCRRPz2DcRLw6NeYEgb0oEAO"
        @"rEGby+i6KRgYIhoc4VC/we5TnqHhiN6+JtnZJSTeUIzj4UDr6s1iq0h+DLNpM75UQfsOmo6v+MA8DXOKafcEA+KJNC4qdTioJYnI8ezVRbzxNH5TGPmfymAZ"
        @"4liLWGHO2biez28oPMiBshjK2SNk28DecCWGb0AGLkL6GQwPIBcWixXKqC5BfixoBItQouAiFPpEUcXnwcBd4zL5Z5YxZx30E/p3O6IWmFqhH9xsWTgckbzU"
        @"49nkEn7dfSMNuZwBHaGnKYlUuMCsZ5gKmQQjF//X7PSsEWoo8aSggwbtKFITsvmM/T9nOJZFLLseTVmhKx1ySfHq2Foaoj/0MAtLB5l6c4fhS8u4tgHTRoZf"
        @"jyQbQKNicVC8byJB/mOGwD2Jf+YVjDP0jeXBIzkMD9MzJezkBGzfij+zGOarLMdnKfRTtN9HujndrvCSh5f3HIVmW0lTyp320d/7me84/A/tn//WA33LLQEq"
        @"2bJ+6oloeTYzsTW+04VOB01K5/OqCy67mKLWGUG6PVxisJdchCkP0R+Z4osHlKhsYRl6TxwOhudaKpKwwko0iFCjUO4bM7D1Cujm5IvClp19brr5OC4/TGb3"
        @"s1aG8JqH3rhg/8XkLJPx5GlP+794Sh1DMrraWsg5KvY59GE16UUNRhKq0SIxDyDvXEM0/FbwE2jrBH4+xW/fiKm3wA+BpIiegPYCpIK64OuhhQkMhcMTicBQ"
        @"Db2zRXTMQxqT3uOIVoLvjkSK2WFZOGaxL/R4pnQBv+o+wihXMaKTpOqpSZ0LZCM1LZMWXnB6PvYwPIxGqHil3gBZU1h/WUOe5Tz3H1NePR2zEHdYcEs0WSHT"
        @"Lrl2GZUK441jnMofg3iObV/fR5tdxOdQriKD7ykMbQYLiFbO2aIpFjEd9OQfkb3iqQ4YDi4KB5aUZDy4xsaXX4hzMWZpJUC7WR7US/0+9Ltou4/pwImVnJUX"
        @"DxNFomZ+jnreeyRed2X7H9o//60H+o6QbcFffPrjj5f7nZfJ+gYVr2dnMdVq2My9xu5Kzz254aD75gr22ivwA8PYibV88YRweMlQbxi6T07jWwrRpuA4T1zw"
        @"rQsyvq0h/jhy4Ua0UkcyjzaVd3zTMhuHjjGbPUPFnGWUOqIpUWHSqKok9Dijfe75HVj4QcFngn+NeUugk5oA52l4mCIMkQ5Tl1ewo2cw77kUKOP9/0JP3Eve"
        @"q8CuBqKtQH8xs5CtQPf8WnvVv00J+LPGgozUcXe1MYf7oBHZ3Q4757E1CeHy2yKWjkVEz/d4MrmQ/5l/mCEuZ5AJUhw1M8CFdgs1SqTizx3k1f5/9TCXDQzX"
        @"hGgsSM9MSfA1z5P/PWf/vpiFpMOSb9KSFl3fw5FR8hFbo5gT5m5WphfY8aE2g1ty/JJD83loXAfRIKJZQHOMe01eXeCgqN6H3/sEtmuIBgz3v+ro2jK+NgxJ"
        @"GXvt1eSn54M6IM/DZjTP0SwLNIluF0mhdegs+YmzmCgWOXmIwch9Nvf6D+6f/65oZAVsHEf9yUb1SW23VEoV74+fxiQ22J4igf5p7DlDFERC5l67hV87gblw"
        @"B6Y2zBkzwpde9QyOxmTTOekzL2PsVtSXAqy1ath3TilqMAOn4PLL0NThOsLgQMpbv2GaqjtIP3qKXbbCEGVKOOpeGcMwgMfJInuiRe5YWuHoaQ+ZxRVEKCOC"
        @"xSASYSTGaowhpio1BtP7yS8Q7OUVfPZrcOa/waEOZs0Uds1SaCFYAW2ibVfk0q8umc7NqCAOGavjH+xg93bBxaT3eWRGsXWDMR7ZGrNwzMKzXZ4qXcDH3UcY"
        @"5g0Ms5a+5lSlwQWyhZImZOIx50aVgtOtgXkdoYyWoT4GzgZTRl9X7v9kzt4XElaSLst+iTZNetolJ8OrY6PZwII8x6vzB4g3n+LCjyzjFnuIdqA8BiM3g9uD"
        @"kgNzoJ2QZkAQvorpoTO/g77cpjRgWEwjnj7pqE6M0XEWs2UDfs16/JmZcGtneQACnAuU2ixD0z7iMtwz+9Bu16vPTTx35vj3vPvdDxfohP+nPNBwyy3kuaMe"
        @"613R/AmRSmzc3CKy0oFyEtTbUsiBC12IGMLuXhRtLdF463W4gTVEW7bxlweVZTWUy4buQ4fRngO7PfRjhaxYJCqyJcrgljGXbMFNroUsJ5+Fa9/R5YY3nqLe"
        @"30M0+CRXRoNsloyLKhlTJiejR1M6ZGaRw/4sd/aPMEuLMvZ8VDHBltcSmHVGGzTsWUr+HvzbxzE6DUcfQPYcgukY2bEGI4vB4pYUOin0gn1XaFmKBAEXaKE6"
        @"MYx7KoXn20BM/26PnFSieqjMbLXMHxHY3eXpeAu/mn2QQbmGUcbJ1DFoBrlQNpNgSc85dJ6POJNVbF2V4UgYbijOKnFiyMvKFz6d8uIzQitZYckv0dYmXd8q"
        @"gpqESaYQc5zj/lE0n+a67zlD4jvQzlC/gm74CBLNoL5ZZMwshJBNVgLuLhbh8+gLd6PzFlMXHjmqLDmLHZugby3xm99EPt8KHCBV1LkgRcuLX2mKeEe0tIC+"
        @"uB9TKSuz01pPOw985w99x1I4UKL/tAe6eEL+4Df+wz3l5bMHsWpExOuxE5haIdM3ppBmcY4MJKJIYvAz00xcsInqNZdiRzewLx/k7kOekQmLO+VIn30WE+3C"
        @"u8q5oBwtDBFDdxuDPY55wxvQKBwGSZU3/0CbLdtexpQ+zwUXPcHbLytRTjrMuQ6L2qFPn9SnqPZY0iUe8gc4bmepYM+txI0YIrUYNcSmxKB7GOpnsG8eRI6f"
        @"Rg4cQQ/0yO04sqUPrhuUturRpkOKnEv1q6wRg/c5rBnF7/WYJ5cwSUJ2v2JPKLYGIh7Zblg8HdqM55Pt/Ir7ZgbNGxnRCXqaMmqGuNBsJSIMuVbO2+me51oF"
        @"+kG1BENDircQl2Eldvz553L2HlDSeJmWX6FPj5S0cEiFMSYYN4Yj8nnm+6e57MOvsuXKPm4h2Br70eswY+OQP4aYHsIplHmEJWAO1R6Yk7gT/xV9qU1cha5E"
        @"PHIwR4ZH6ZsKbN2Kufpq3OGTgbfiXNjKehfs31ardGzQV4/gpmeRWk3s6cOyth79aZbn/0ftxt99oMMTYi/Y9YaVUfR2M3caaVTUHTuFTWI0Sc5vDYsBUYtY"
        @"CIwgPqfcXOGGd91Ir96gtHY9XzqgpElEXBV6D+7HdWfBXlH0ZqXiMMcIMSo1yDvYDRa9+rqgilChOrbM629r8ab3HmP4yi/Rz5ZptiaZo08uSkZKSkamWbDr"
        @"IuXZ7BAvcAhjHLXg4EYwzo1oCIzkf46+TpDBFfzLp9FTKXpakIsmMKXp4KlHhq70kb6eN4opPEtwKUwMw/EY88hsUGXcrcgRj2kECqbZYlk8EWGe7vJ8soX/"
        @"4T7MkLmOEV1LXzPGZIKtZktQ+Zzz1wqD5qqVulHBeKjFSq0ueCPEFeFo1/Ppu3OOnPFo0qKrHfraI9VecPXUiAEdYtIM8Kp8gZX+cdZf/hI3fssybsYjWYYv"
        @"DSMXvhfc3ah0QadRjgEHgNOoziFmBfo/h3/sGfxihBk1PHlUONM2RBOB/WfecjP9pkNXmkXeXsgP0eArgfoM9Q5rPPrS/kCyzzqmsjR/+GP/9psfKYY4/09/"
        @"oAFuvVW9IlvXDn42OvyS2nJifDtVWWhhGsFOYLV31tUvV/wcSqWEmbl5tu3azKbrryaaWscJP8Sjx5ShqQgz53FP3I9EU6iOF5dpDJIEf2g1YOpoPo25/Ap0"
        @"12b8uCNffx1D73499esMx55s8dzsXahtMWrWkZOFa7+Y1FbppCKOI/4ET/As82aWASIaGGoasUaPUOFBeOsAcmoZPQ1yxuNLDexVAnkzcD+6KbKcY85bnxYm"
        @"Mh10ZC1+eRf+wVOIicjuV8zBnKhuEKvYLZaF0xZ5psuz8UZ+wX2QQd7IkI7R1x5rzBRbzSZQIX+Nbfpq5Jk5p4eEmoVaLMQi2JLwyFyf259yzK+ASzqkmhYy"
        @"M4dRgyVmWEbZYic5yBdYzl5mYHQPH/ixGeIsh74EMfSV34gp70H90VDLZBE4i+oJVPejMoPKX+Bf+QTsj4gbStvH3P9Cih0dwlWGaG/ZSn7N6/F7D2EiU6y5"
        @"CzamLxiPPkeSGDu7gD96CjM0qHLmKOOR+9xHPvx1CwXspf88B/q22/ztt99u7rnnM0/pmWP3k7ZFBhve7TtIVI7x1oSYh/MYUpC0i6DWkOQpxxcW+ZoPfjW1"
        @"XZupb1zHl/Z4etWE+pRF9h5HF/ZD/DrUxwXGW8Q0mHLw0SNBzDzmin+HueoHMQOjZM88TbLmNPnOVzg2fZij5osMGWWNrMWrC7aw54S4gVWXiNCiyZP+RZ6V"
        @"l1HbZlMsrMm/gB+bw1xWQg73MS2Lzih68QRmaAnpeTRXdCEvnFMLpqFEqPbQwSkwN6JPPo814J5QZJ/D1A1qPWazYX46Qp7t8WKykV/yH6LBm2gwRF9T1tp1"
        @"bJYN52iuZhVBKmqFec0SqCJQFqhawwo5nz4zx10n2jhxYD3OBxMHK4YKZSpSZUxHuchOcooHaPoXMfYl3v+TxxmbzMjbBu2n6CXvQdbW0f6DhYi5BbQRXUA4"
        @"C5xEOIDO/y7+0RakYIYsj74AZ9sW1qwndTH+7e8kXcowi0vhPJxLRS0ONYTqXCqjL76M9npqktjYowf62ybHP5k7D7fe+n90mCmehL8rPkEuueQS771OzM3P"
        @"3/LoM3s3JVt3ijt1RuzWDfhyEmxorSlUvxYp+LwSGyZjIe8v8/YdOxmMM+TsXhrNZYaSLhsusMF+y8wgG96K6iBG2iG7hWphp1VGuASRd0G0GfX70N2fwCz1"
        @"kFSZuLLL0QM9Zk8MsBQ1GZJNDLCejqaF0FUx4gu30jBgRQiLfoHT/jTlKGJH9gvITUeIrhHkcIZ2lLwbw4c2YRtnoFcoQJp6Hr82EWJytN6AwW9B93wGu7SA"
        @"PmrQZz22UhhDrhOWzkbYZ3u8nKzjF9yHGJK3MFqss7eYzWyQdWHLKiGnxMh57xazimgoVFWoY3DG84Kf497mWWb7KSXriSiRkAR+igqJRiRUGNdBttkBDvIQ"
        @"SzyD5E/x1T+6hyve1iU/65B+H7f5SuzVXw3dP0TIOP8CirwX6SFUoPc8/pGn0Zci4mHPXD/h9gf69KfWslRbx+LUFqbf9420nno53IxFlJ0xhXZSQNRCtUzc"
        @"7ZM9+ARSr3jTWjQDJw/e9fLTd/6891548MH/4wNt/vZu41YjInrk0HPvmz/+1CPf+bU33Dy5fNjkMydE4jL66mmi0dFQTWxhlGwNaoOxSGTCfD7sO0yf2csH"
        @"rn8rF1xzIVdfO8VKU+lGEG1MkOYKOvsAEr8OZQeq61FdFyLW5LvAfBvKLJr/NFI+ha5/B7QduqJEyzkf+P45Ji94hqX+ixzlbgZMkx1mI7HWiaUcsAw1xc9I"
        @"C3f6iFQ9+7Mv4M1j2BtrMN3D9wSZ87BtkmhzF5o9yBRdca9JoghmhVoSZOij6Mpj2OQMfl+C3+cxgwKxx24Vluci/LM9Xkw28D/cNzEkb2FQh8nI2WF2sI61"
        @"5P58jIMUWLwUO231QqRQx2JE2S+z/Knby329o3TpEhtFNcL6iCoRQ1JnQAep+QG2M8SVUZVj+gRLvIRkz/CV33+AN35dHiRxrocbX0d07dei6Z8h+QrnDAE1"
        @"LSKg22GTm6/g9z5M/jhIkiN1yxeedCzYMp3RDfQkQT/wEdonFzGtFmrNOXsGLVT0KoJXjy1X0b0HoNNFYmvk0B62rBn9tSzLgVsM/4gP+7dUZnPzzTf706dP"
        @"X92Q6XsbMjuaDG7lxInpM8+8eKARX3gF2YnTxNs34ksxuAziCLE2VOfIUIqEYetYl3gmOcu1I1V2jE0w4h9kbQNKNEm21ZD6MGqamMYVIG8AHQS5ETFfFTyF"
        @"/SdAPo/QhPQIMn4ReWcAc/QI6iJKJmfX9T0O7J1ncbZG27ZpyACbZQsrPqMvfYz6cztJixKLJ6bKG91d7Nr8OPr1FcyrPaRv8MugH9xONHUKltPAJ+5rUUGL"
        @"dX/cRyb+NWosJtqNf7SP7O5iYgO5IpOG5kxM/HSPvfFafta/nyHexrBMkKNsk51MMk5OiHAwr1VXFL57JbHUEZzJOKKzPM1hXtbTZGSUibFiibXCWkbYGSfU"
        @"gIo3DKjlonLEWnG85J+jKXvQ7EFu/N6XuPHfOfLpDtLr4Gsj2Ot/EOJHMP2XEKmdw5lXPXMFE4JITz5G9/Nz0LRU1govnIj5wu4Mt3ErC3YUe/WbWL7xXZx9"
        @"6ClIkgAxyqoLikFtUaFrFaJ2D/fYM1Aue+ksmsqrL730x1/85I//5i/+Yg4v6z/mQEd/x2KFish8N639TM+Ori0NTtx/wxXXP/qH9z93T9ZZ3ohz6p7ZY6K3"
        @"v5H8TBo86uR8+LqxijWesmQMqtKaf5LL1l9Pn3dh5/4SFsE3Gsj4MBIPobQRLkTsG1GJUfclVG9HOBoAf98Nws/WvUTX3EDevIxo74s4n9CIu3z0P8zwu7/0"
        @"AIf29nFJzkbT4yK5hIO5YYEZEhG8NyApEZZG5NnlnsbdWAruRh2QtsNNjmEvM7CyDN0Y6Z4XBIZLtAvjb0X7i5jGs+T7BGaamM0xnFLMuKH5Uox9vMvBZAO/"
        @"6b6ZMXMdDV9FFS60FzPoG2QaKnPhR4XVQKKKi166bVY46Gc57mZp0yPGUsISYcNSiJiKb3DdRWUu2QQnvujIE1gzaZlv9Xh05WVa+jxJ/gBv/JE9XPtDEe7V"
        @"LtLv4GsNzDX/HkoHIduDxCMBhfD+PC0Yh7frkLmX6D9wDH8mojbpaVLhC0/28SPDtGpTZMkA5j1fx5nnXiZRT8+a4LOtwXRSVxX5RogbdfShZ3CtFtG6KTXP"
        @"7Wbz+NAfXLNuXQdusXCH+2c50Kvq2uGpqaPAj77277Zc+PpPnDzwwq32wtdrfuQEpYUVZGgY7bTRxCKRIlawJqdkPFVx1CWn7Jq4bC/J+u/Ej/WQ9AgqEdSv"
        @"BHkdoheCTIC0UXcXqvcishyuP9eFLA0JSXkPnf8S9qY347wS7XkJV05oJCkf/dhZ/uC3HmbvI44jkWNRzrIlej2jfjOndRonbSIUIWK9f5Wx+CD+ugbRyUXU"
        @"R/hmCjevx1bO4E97pBuMwFdbArIU1m+C5Q7MfYq8V0Pseuz7r8ff9SjUS/QftTQe6/Bcspb/5r+BQXkbdV/Fo2xhBw3XwBlHHAIHw9An4MXRYpk5meeMn2PZ"
        @"NUk1/LuSlMKgS0AtSiRUaTBmGzANvZZjw/WCrQgHnmvybPMwxu+hZO7m2l85zCXfXsOd7EBnGRoDmEu/H2pnIX0SkaGAE0uITGbVmMduguVZsidfor8notzw"
        @"2KGYLz6UczaNcBu30MqU4fe+n2O+hDt2nKhSL1ypTDC/XHXDFEUG6pizC2SvvIppVL3OnzXJzIlX7tm9++Pj4yLo7f5/Tw/7p6vQ54ZCuMPccQcsLi6aj370"
        @"o+6b3vXOX/vFz939jf3tl2yRKPHu8WdN9P63kzofslIiT2Q8lQjqVqiTU6ZL1XQRfRnP66D879HyQUSqeL8O/BhiFPgs3p9GZAK0DboE2g2UwyyDPITvkKeY"
        @"ufuQm99ObiLM88/hXUzie3zHv5nls1MPctcdizhp4qI2G81VXOg3MONn6MosQpWt2eOULumQj1eQpzykSlZpYK+ro3P7YCUq2ITFgXMOWVNFex59+gmkXUJX"
        @"mkTf+N1I/YPwutfT/bVp6n/R4Wi8jd/1/4YhrmZA69QYZLPdSuKDna1XxZs+TW2zpE0WdJkmTbr0yDUt1toxZYkwRKEqY4gpUdIyVakywghTGlFf8JQvMOj1"
        @"wsHfzznUPIJkj1IZ/iI3/t40G95Twp3swuJpdHAIc8GPovEcZC+AHQfthQ2oyUBNGAyjzdCLcfsepve4IU6UyhrL7kOGFw73KW/bwlJUpbLzSswN72D2rvso"
        @"JTGp9xixRXtWtC5YfGSI4wS3+2k062MHRpC9T8qG8cbPj49LE26xr4nN/ec70KsZhucTNLA/9Us/NbPzsht/4dVDe3/VXvA6dYdPYY+exF6wAze/CLEnNilV"
        @"C3XJGaTHsOlTt32wMeg8+AvBjCKy6qx/EPWfhNadSLuLTr4flQtDolTeBdcDnwbhnHMhTi3LYOaLmDe/HVepwBOPYdTi5jK+5j3zTK59hs/+XpOllRV68Sxj"
        @"sosLomvwfpAVptnGg7i3jGHbPXxqoOngso3YNUvo3j6Sl85tP9UrMiBgLHrXaWQmRg/mRK8XyBbIshfp36/Ub+9zIF7Df9P3EcsllLGssETZVDjgXiGX4JS8"
        @"ok06vkVHe+TSx6DEarASqm94701gAqrFFDhGhSpVaVCnzoSLuaSibNgunFrMmfmFJbLKCSrpA9SuuZcrf6vJ0BVV3FIPmofRkV2YTT+GMg1uP8h44Ghgw5ZW"
        @"IkT7eDMO/UH0yJfIH3aUjFCZFE62Yr70eJ/ShmGag5Mk8QCjH/lOntz/CjbrY5IakRMsQbly3iVdsINDyIFj5EeOIPWq15njprI8/eCe4y98UkQE/s8WKf9g"
        @"2O5vqtq3/tgPHr7vC/e800+sW0O5pjo9K/G1F5AldSJNGbQp4zZlq7TYGTXZVWmzttbGlNcgclUR6VuQxdkNCz+LtB5HlpbRU6fxzT3ImosQHYD0BSQXxGdo"
        @"nhUO8iFRFXXQPoDZdRE6tBUOHUJyj+9YNmxJufi6eQ6fPMnMdAj3bJuz1BnmCmZZU/44+m+3Ep08jukIrh3BLVdjKy8hJ/NzzAlxYS6QsQp6dxtzwOCecmF8"
        @"GrX4sVfpfebPafzPExxeHOVWdz1HtEZXF5jTedq0OatzzOgMS34FLwlBY95BxJNgir54NbonVDerEUZtUZUr1KVBjWEaWme7VHhd3VIecOydbTM9e5Y0eZx+"
        @"/3bWftuzXPWHZaqbYvJWG2kdhdpXYNf/9xAo6vYhplJQBFeraBRW6mYMsjp68h7cvS3MoqG0Ruk1Ej73xYx+vYJu2EHLRQze8t0sjWxibu/zSKVKpoITgxOD"
        @"WoOzEd5GUKkRZw5336OQp2oSizz/sF6yfuy7vvPbv+mV0Du//C93oOEWe+edP9++eNuObHZx+T2yZZfPz86byEL0ul2UWsuM2YwNtLnIrHBhqcnOygKNRgcf"
        @"X4eRXYgxqLdBxpR/Cjn4CPmhE5i4DUtd5Ogymu9D1t8UJE+9l8BFhGwJPY+VRuEqZukgsm4c3XoF/vg0ZrmD71sGShnX3tghqs7w6oFZFtImy1GXDfmnmbx2"
        @"Gr25hNk3g3YUt+YiovcOwZGXkH5ctH4mMNwmS+hjKWYPuIc9piNIFfxaS+/hDo3fXuDI3BA/2rmGGbZSkzE8ZSIqRJSJNKZEhZJUqMsYVRpkdAGHkSANM1gM"
        @"FitREDBoQokydeo0pEFFB5jQOldFCZuSnFO6xMvNs6RuP6X089TX/SUX/MoyW390PAiPO6cwWQupfzcy/J9RX0FohQD5EApZ2KglIfvQjCJZFWa/hH94BXPG"
        @"EI0AayIefhAW2kpp+0byco3kTe+l+8YPcPq5B3FGcF5xasjV4KwlNxG5jdEowtYa8Pjz+OPHkaFhL0f32+T4K394+ODun7/tttvMP9Vh/nu1HF++RN/uVcQ8"
        @"98z9fzS25coPNk8dfGe8ZoNLd79sG5dvYXC8ypqlNpttk21Rlx3JLKONLr78XtBr8WYB4UxwXbLb0BULvYilV3r4wx0mN1tc1yAPz6D29zCXfxuatZCVuwlG"
        @"E0W8ug2CAm8M4ivIqccwg7vQr30H+f3PYF88jMsspp/zjjcvcMG2Dnf8+SnO7j/OlD6LvnU9duYkOBuYfzdcjOk8FdKzopC74smRDRX8bod5OiN7yGCXgjUF"
        @"44buc5bGHV0OxSPclt3AnNlAhQG8lLFUMFoKXG8xiFoiSUgoU2WEnrboiUfJQ13WoE63GhFrTEyFMmXqDDBOjS22zJDNaDLP424e6xep5M9TKt/L1LedYttP"
        @"jFNaP07ebyL5fmA9NH4YsTeF9FcpAZciOorKvsJfz6I6DzIGeR+d+yT+sSXkpGDGFbMpZu/jwvJ0j9FdEyyWa4xvuYTmV34rzT0PM2Z6uKiEBzIj9HKLKdoX"
        @"D8hgA3tkmmzfQaiUlV5LzJGX5r/2g2/7uX/sAPhPd6ClEDKJdL76ne/7T/fse+pGXTtVibzTyhfulW1f/zZ2xB0upcvlyVE2Dltk6LtABpHsz5DOy+B6qHYw"
        @"8ZX46CqWV+5irrqJs8++SmvZs32DkLct+R2nMO4TRFd9I15jaH0RQ71Y4Kzq9vJgTWYryPwBSM4SvfUN+PVr0Id2I82UvBuxaajD9//rjH33zTP4oIVrKpjn"
        @"mxigPziJvdTAsWPByisPG3MzUcLv88hjffoPCHZakeGAM7dOxjS+0OHlqMZ/zK5hWTdSNoN4qogGJ1NTUFQtCUlxmCtUGKBGn2GMBjco8Bi1iNqAYkiVAa0z"
        @"IQ3WmhJl6bDEEY74RYw0KfcPU+IxJt96gB0/njHy5jE8CXn3KIYWxLdA/FHQCbxPg1m5KkqCyEaEOmgV5TDYTZAdgIU/xj+5gBwXGFPsJsvZV4TW4Yz1Vw2R"
        @"jk1Qq4wh7/thjs2+yFT3BHG5gWYOYy2pE9rWYjQK2HOpSskr+ZPPoT7FVoe9Pvuw3TRS+a+/8zu/8+LvvDYE/Z/o4x/7iFhrjJvafPF/Wdh2yY+MXHa5n1o5"
        @"bq5402Vc9YbtXNu9j0vWbyUZeS+aPo9f+Ty9VpN+OkDflck9WLfI8JpLOXNsgT33fYbmQpfTu/fzzjckXDqe0jypeO+ofP0G4qu/Fdd8Gen8BWJHQoFxWTB4"
        @"KSKGxUlI1soUXXspKmvxD72E2XMc8YIZjpHPp7SqF5J8t2Lv24+uQPbGryL5ilPw4vOILYFTZNDgVgQezOnfq/hjntIgRFsN7X5M/ECX/fEQP+6voeW3UpNh"
        @"PHVMUZkjqYVRTsrEVEmoUNJhptjIGjPAnE9p6hIdlvCixBpRlyojDDBkKkSa0mOejszRkQXUNam54zTYw/o37GPX97VZ+8EaYiv4bh/1cxBdhET/BuSyoqOs"
        @"oWqKYijnzo9gUZ0JBKTsLnThv+IfmYMjihkGu97QXLKk+zLcoNKfmIKhLWSv/1lmywkrRx9mMasy07eczSKm85iTrsRMXmZJy8xpmXRsAu58jOyZF7GDA54z"
        @"R4x97sEHDr304NPlxJeyVvO/TG677Gxhj6v/chX63Gocve02Lz/1X//jL//Ej/zQB9dPuB2bN0z5y+eeNDe1TrBj5+uJSpvpnv19mksvs9AeYaG/kaZaUrU4"
        @"Nagbor44TbL5Oo5vhdkTdzI3tJ1f/stDfN9XlLl4qMvMTET2+yep9z5O6frvwMX/GrJPQhbsb8VngaeshfLc2PCdHX8Oasexb9uJ3zWI3vMqcrZH7wWL+Q8l"
        @"zPGDSAZ5VMNeuwY5dT+ax8HVqSa4psLDGdmDgh7xlBpCtFZYbloqj3V5ORrkx/0b6ekWaqaKUiXWKpYysZQxVIhISLRCRJUSNUo6RMNXuMjBYROzYsdxvooF"
        @"qrZESTJ6LDKnrzBnzpJpm3rWI+IwVbOHDTcd55JvdWx6d4wdquFXUjQ7icbDSPW7IXoT6lcQOqDrzmWl85rEL1EXBmozhKafQs/+PP7hRcxxhSHFrrPMnIhY"
        @"2t1l3U01yhdvxfUE2fHjpAM1yqe/wGKtTqXXJZYIkRKpGNrGk1voOsUNjyJ7jpC9uB8pJV76HTj4XPPmN17+/WvXbzxx9viLdxDLR4GfvOOOO8xrkLR/uQod"
        @"MGqk1mj4//yx73js8S/96XVvfMvF7qtv3G63v/7d9PsLHD/xEDOdYabzYeYzS9MJnVxIXTAW9FjUQxxZ5na+nqW/+CP06cfpzk1TPXOE//iuEtvqPWbnDDbP"
        @"GPrAAJV3fg/OlZDWr0GnhWQWyfpB+FKYjAf7upCy5XMHE5PoxDjuN2fJfn6R+OOjRM9O4+c8+fY3EH+4ijx/H0IJ4pAlzm5P9iVwexzJIMQbLUtdS/REj33x"
        @"Gj7OR+joGGVNyDVGKBNJHYixJMRUialR0RolqoyYMSZMg50DcOFNyvwBw7FXU45n85zVeTqyQlOmyf0S5D08c9SYZWzNQba95TRXfLDPhuuSEN3RTNH+EpRq"
        @"wQim9jXBksxPY+zXo0wWqnoK7edqFIhHJEKlD/3b8Kd+E/9wB3MqhUEh2mQ4fiLmyH1dJi5PWLurQf2qa2DLf0akgvTuwnXbrPQNy11lIY04kdU4mlY57moc"
        @"y+ocbKzj1IKj+akvoosr2ErZud0P2als8afOHNvzn/I8vK6ZmZmpiYmJM//yPXTx8cADD9ibb74576pubx9+bNe62c/rG26YMhuvfjOHH7yD3Yt9Tm+5iZWV"
        @"lAVnWcmEvrchpcF71ENOyD70qaP/7MssvvnrqJxeod6GlWHPj3zmGLe9q8xF431m5iwLdzQZXPx56u99N77xHeA+DdnB4BthXFi7eSkqtgbDQR/B0bNIf5ne"
        @"szFcO4DJW0hT0b5Frt6KnL0L6RmkEvLEedmRPyi4PY6oDvF6Q6dniJ9KeTqp8HM6heMUo5LTpUpZRihTIxahQo2aDBFphVJAjimpoRb1qNgO0wbOHIxZPNHk"
        @"1fRVFuUsJu+RsULODCXOMDJ2mk3XzHL5WxbY/vqMgclAGvInl/Hag2odGX8zMvoeiFqQ/yKip1DzXcHVSc9Hmp0nCblgkKMz+N5PwuHb4cE2djGDQbDrDPsP"
        @"ROy5t8Pgzio6ORVMcAa+ETGbUTeNJtsx5hmG4x4VG1PulTB9izcR/bzBXLVGxUbIPfchy/MwMOj9wZdsdeH4A7/9pV//2Xdc8Q5z//33mzfP/prKP/Fh/kdV"
        @"6Ntvv91+6EMfcktd3RYt7vuMnL3rolJ93k3v3SPP75uWx5c2mFdbQ3RvehudwTq9s0v0icgJSwp1QcHgEZwIfW9waUpvYIh882bGfv9XqR85iF86TuPMMX7m"
        @"a8pcPdnn9KwiHaV+uWPww9diJm7CLz2KWX4C0gTJg4e15EV2d6aQBxqp70Dv6x32h9eR2DOwPyMfXIv59q2YvY+Aj5DYoK8q+b2QPuWJq0q8Qeh0Lfmzjmci"
        @"w4/nZVqMUWOAGhMkDBBJnVgqRKZKWQYpUw3keokpUSIhxjlFvWWUYQYxLHOUFkfJmaFSX6a66QwbLptn19VNtl3UY3hN4XXSdOTdNLTEjTWw7kbMmjdAsoSm"
        @"D2L886gtgWwAnUTlDYj5IHBBcZMrFEk16HNo/tP4lx5FH1pEujlSB7s25tHdEU8/2mZg5zAD6yfZsLbMurd/jMbW62mk96JmGGNvwvuXUP8ANu2Qd2OWehWO"
        @"9ofY79fweGkbL/7lE5x96iXORIM+W5gXefzu9s1XXHzjnXd+9rmC4en5Z/qI/g9bDSMirt/Xy9ziwT8sdZ+5uCXTrurq0fT8EJ/40n4WNu7QOWdl7t69+Hfe"
        @"HDgC/RxXCCZxOeqKJFIRMoRcyshiE2dn6H/Dd1P5vV9lIPf0xwz/7o6j/OS7Srx1W8rMomflJUv/7FOMfO1JSle8DZ9MIXP3ovkKSDlArK7woabAjJ8UtFLC"
        @"rm/DsznaA33LOKb1Mtoj5IIfV7JHlPwpJSkp8VpLq2NYeS7DbjTUd1r+3UrG4ZXTzJpZesszpCt12v0yeVZD8ioZFRyGmIQqMTkh7Ci2jrFKxsSAo76mzbq1"
        @"i9S3t1izM2fNxg6jIxlR5MOAu+xwh3ywlK6WkTUXw4brkNExsCfQ3u8jywdDf2wGgp+JDWaYok+immLkW4CtgRjku6j8Bdr9dfTxl+DpFiKeaNCgQ5a/uMvw"
        @"+O4OtQunyBpT9NKI+A0/RL71JtYt30vJ5sTJcVQewph3oLIOV3oEG51hJPYY61kujVF78AlGX9lNr1bR5U6LlRceltFIvudLX/rcc7fccou9/fbbmT782Lda"
        @"n19dW3vNT9dqtdP/okOhBo60V9WhxUMP/ckAr+xwklAefLttxmufuvpbt93T/eRNV7703Mtf2b/8Lb59csFEdz+LfOX15GdnC28GRXwUtn2FxzSFgYqQwPQM"
        @"nVxxX/9v6X/qN2hkQrYh4gc/9yo/dFPEN1zjWDQ5remIM/9zmpGv+jSD77oJt+FDMPMwLB6A3IK1IT3LKVQs7mGPvdRgui2kA36ojN3Zh+NLGBPDLGSPQPaw"
        @"kiRKst7QasPSSxlmsyG/BLaScs06Q7wpgkZKxy/QTudZcoZuZklToZcLDiGKLTYWkpKnNACVAWFgyFMeUJIBJRmqFBW4C4td/GlH3gvbfUoVGFuHrN+JrJ9C"
        @"Gj3IDyGdz0M2WyxFKsE83CuaBxEupovSQfxJ1EyDbAG/DzWfQE9+Fr33BHKkB4kQjQhtW+K3/six+2hOddc2WskoA3aY7kd+hOauS9h64hEqcUSS1BhViEun"
        @"cfIQVm7CmPej5hDYI4yWYcPBvWw+dC+dcpW0Z7W570lT8+2PHz99/Pe81+iOO+7IgTLNV35kfBfbZw4vHwX+2wMP/IR9zdr4/96BXk0fUtV689gTXxxOTuxY"
        @"atUx9Qv/NJm44Ld3l8v33CySq2plavvFn+ocP/U+M7HJ5fsP2mR4mOiqC+mfOoMxJpix6KoI9LwbqMcHW/8zZ+n3HPJN38vin/4+vd2PMbw14acfOsixBcMP"
        @"3JSQSJ/5ZWHuzxzpoXsYeu9Gom1X4WrrYWY30llApIJaxS0I2bOQ/CuLnOqgfUWvrGLcDCwr2gL3BGT3eiLriddZlluGhb05jasj2O5pLzp8HfyIx/d6+DYk"
        @"MVQrwnjFwEi2qvENv6ICOVv9fZG2qj2Pd0qedsGCthyaJjC4Blm3FsansBPjSCMFPYX27oaFs+Dy8MAXa2tPSPpVUxj0eI8Yh9JBGQVGEfM06O3oC3+B3nsc"
        @"WXRQhmhUOLxS4tf/POXVlQrRrl20NELKU8x/10/h165lav9TJJElriRBB+gSRlWwlRN48xzGXA16OSqbULmPdYuf46JaTiaJbz/9pGkuvfrQz37y0MduuGHc"
        @"3Hrrrf4nfgIjIr2Z/V/4tXxZPxaVBlYA3vzmi/VfpuX4iZ8QVTXLp/f8ciJ5rZnv+HFZs+vpwbGhL63+k9/4jd+IRaT7vT/04z/ym39w+zW5NxtMY8SnTz9r"
        @"yiMjRFNjuJm5cxHAUkRNoL6Yw4sDHsWwOEfvoCf52m+jMzhKdv/nGdte4nf3HWLPmRb/+asrbFrTY3oRFl+wtA4eY/Qrpqm//QJky+vxCzPo7D4k6eIfr4Q0"
        @"36kc9oJXC5s8cqaNNCPcHsju8cSREm+0tFaElVdyGq+LaHylIGVD/bIhoiEDCyl+QfErHl3JcXmOdD10/DkdkETBXoA40FakZII1WDnG1yvYoXFkfAs6sBWR"
        @"CIkzpJqBXUb0GPSeheW5gK1rjIYvct6dSf7qViKIUHNUV8BfgcTfDqaMzv8G+tQfYl6cxXeFqAYMx9z5YsRv39WnWR9Fduwgzwy9S66g9T0/TN/ETL74HFFc"
        @"cPx6fayPMS4ENo2aHFs+geoEsAlhCLWD1CZa7FxjmXn6Wd/OlsxX/eC/v/uGG8abt956U3Tbbbflt91WBK1d8FW/dOSs/6PN25gNc+uH3P/1oXC1z2kvnb7G"
        @"9bpXNNZs/f3XpHiKBvQ+BFDddFPEgw/mr3vDjR956ejs//KXv1V8FAtRIqWvvJl+KUEXF0Mikp6zLj0fLqsFydxaxDt8qUp8yaVELzyO/+PfZyBdwp89xbrO"
        @"WX70rTFftTNncSGj1RGi3FDdnDPwzgbVay7B+zWgh0i/4yDMCvE7cuRFRzYZY2422EMZfp+QftZjep7Stoj2IqwccNRvjIku9qRdT2WHId5q8fUIGYzwjbiw"
        @"AC6hPgsOnXmpMHMEkSIcxyYQJ5CUkSSGUgxJHZLhYHaoVdC9wD4km4b+SrFFtcGi96/9uERXyfKrqpKglVeboNFaKL0dMR+B/nH8vp9FnnsMZgXNDVFVaGrC"
        @"b9/n+cxzHl2/ge7gBno59N7/Pua+5TvJT59l5PgRBmPDaARrEs+GJGNzlLIx7rGu5pksw0ilT5RsQOz6oi5uguYv4B66jec/13LD7/whu/Wd3/dpW1n7YVW1"
        @"8k9ADf1nQTle++JUb7fcAfKhL/uEmTiJ/aaNF33fUa3/ornoeu97bSuDQ8Rf/XbSrA+tThG5HMxpzln0FmLhQo0KPsd7Jbr8MpKZE2Sf+C1q86epdBcxx1/l"
        @"gxd4vvdmw1iUMruo9JvBVWjoKhj6ijHMpkvpvWE38Vs62DhHzyr6hgQ76NBnlf5nFbOoJLssnXloHvIMviemtDOntxgqdjwFmq4mdHrUFJFpNYGygXKEViKk"
        @"atBSiDozZQNRsO0QW9BQoyINoCRoNIDoLkTaIGcCRTZ1iO+jvl/Y8moRRW3P241JwWGRPDhURaNQuQgTXQmZx+99BL/3YcwcaJ4QkUMc88SxiF+/O+VAt4Zs"
        @"3Mq0DtGvD5F/17ezcuPbSF94mWRlgWqlRB3PkHGMxjAVezZEKRsSx1RZmCxlbBysMR5ZorlPI+4MDL4RGfo29PgvkD79a2p2fAxd+zXY8tp3xI2xu1dRsb9e"
        @"IP9/AdtpMHLWv+MFFZpUZXLjxX+yUF//Prvz8ty12xFT64jfcRP9Xhf6GSayq2Fs5x1NvaLehWWtL5zf+ymybSulagn/Z58k2v04A3kLd+wIO0stvv/mhLds"
        @"y+ks57S6gu0L8VBGg5jki4b4XwmyP8VXDOYqgZNK+ucghx3JxRHpErSOeirfklDdkuFmFB01RNtMyEbxco7sHyytFTW+cEJTiEKroavpqiWBcvH7hGDwXkqQ"
        @"chUqEd6OANcU89B+8EtIlhcHuhcWI6qF21ORTeI9KkXfnAwitY0YO4r223SfOkL++GFKc0ApIiqDbcBMs8QnHsn57Iue/vh6uhMbmW0p5sqr0O//HpYaY2RP"
        @"v4T1KZpYYhFqVhgwyoD1DEaeiShnXQJrE2VsoMzm6gBr9vwxpZknqEvKQOkQZnCc6HW/jmRPku6+3Ze3/YjpD1/9Qop9W6OxduHvcWb+ZWC7vymW9n8HRG4V"
        @"EdEf+IEf+97f/oNPb+vWBi6TdVu9O3Pa5Pc9Suk9b6Xf6gYP6MieyzD0RSoAeV647bgitD2Cw0foDQxRuuXbkG3bWfzsHzO6Eabbi3z/585w8xb4vjeVuGhN"
        @"xuKKo+0i/F8qbBBM1wUHpKrANORfAnPUE18Ukc96+jNQ/09lSmv7+GlFNkoI3fGrqbnnE2sxhJxFa4rMRQ2HNgKNTZExGOKDiYEEJLYQlyCyxSAXgQwRTv0p"
        @"RFohmKmYKZBgbaqSA72QmBBV0dIUtl5HsOSLiyw/c4CVhxbwxxwklkrVMFnyZC7ms08Kf/BUj+M6jN+2mWmt0tcGa7/tA6y89xZOH5+FZ5/GxjFqY0gdmYW2"
        @"F8QEW+DMC5mW6LqcZrnMjK9z4nN/wcTJvYxUBxiSFnJgiR3rm6z3X4ff8T1E299leq/+viu/bsfluOFfEZGv09tvt/9UK+5/LnLS39cqwb/1q75q6+NPH/xi"
        @"vv11Oxmbcr7btfaiiym9/600F7sYr5jE4ldhvNwXsqs0VK0sK7BrhV4PdUp0wU5Kbhn5s09Rf+4p6r5Le2aWybzJN14Z8b4rYYQM9wkleZclaeRoRzCTkD0r"
        @"6KOOeJcln3P02hXiX6hRHl1EjzsYtrA2htRDR8NKfVUrK6vycQFbiAIjXyAcJgS7l8LviTTg24kUQZVltGTxURllLUbeHXSU3IX6V0B7iO+D6yC+g3cZaAWJ"
        @"NkJ1EGP7qPboHV1k+eF5Fh9rk84AJaHSEEbqShTHPHUK/mi346XlMm7tRhYHJjjbF0avvpLN3/ltHBvdwMln9xEvNyEuApxE8atJvyYoiUpGaVioWUutnjBR"
        @"L1O/7x6Sl59ksATDpuXzvV/SC7dt54Pf/u0apafwy0+LnbpIqA8iSwaZenePoV1vS6qjj+vtt9u/oUX9f+ZAs6rm/cAHvvZNn390zxfchW+o25E13vVSk1x2"
        @"Oes+9FYOdz25UyJj8c5B3kf6vWCO3e1Cr4+kWTD5yx2SZ7h+H5mcorJxivIzDxJ/9o8Znj9NpH2603NU4x7/fkvCh6dz3PsEM59hhsFNR+gXM6LNFreQ0y8N"
        @"YX/3CsqXHcUfOoPmFWTDINqdx5ztQwfICsN0ETCKWg0Humg9Cs/2ULVLRVWOTBE6HyyGScqQRGgpQswQymaE94NciOpfBOWOTiOaoZqgdgwTNYKahA7pmSO0"
        @"d59m+ZkWrUOOrA2SCKWaMlyzWGvZPQ1/8qLjkdmIfHwKN7ae6TxiZM0Ul37jh5h5y9s4eHiO9suHKFnBGxt852T1YZXiQQ0Pq7WWRJSkUaVcKdP4/BcZfHU/"
        @"lWpMla6aF++U11+4nY/97MdJhoZDWGLahukn6HePk/tTWeynIjd1y/OVtZe9EX4ihZ/4Z2s9/i8d6PMfN7/tPR954pXjv+8uemMkIxM+SzHj11zF6z/yZh7C"
        @"spRa4gxcp4v0mtBtISvtkK7VSyHrQxY2jUYU10tRsditm6nEfQYf+EsaD9xJqXmW2W6Pfzfd5WNXCdk1Dtv1eLG4P3PYcSFdcuQ7NhD/YI1yfhSPoFtALrwJ"
        @"GboYsmfQ9jRmYQFd6aKtFDJ/3uBciiptLBIXh7yo0lgtemcNedhRHD6XItQmwFqQ14N8EOQKxL+AyjHELIIsAYtodhx3+ij9AydYeW6Bpb05/UVBSwZTgnoF"
        @"BkuGrrc8fhI+vcfx2HyCTqxFJ9exkCdUBwd403veyZqvfhdPacK+Zw9iWj1sxLn4jEBgMue+KTGCGgkJsRgYqFJOYrL7H6e6bw9DkaNqc1/Z/4gZaM186lOf"
        @"vz+eWDO1qdduHrHWioiOizHbtDm9vpQdsunySyTDl9OpX/eLtZENP1hsmv3/0wf69OnT43/0R4+0PvaxD3eveN2bv/mlYzO/oVe9JZHx9ZqqmA03vJ6v/fAb"
        @"uNsqLzQt8ZLil1vQXkCabXRlBel00DRFsgyjecEHUcgd2uujw8NUtq1n4vSrVD7zB5T2Ps5vL7S58noln0wxEpPf5bFW8D5Db9yJ/VcV5NiLSBYEnb6Rweuv"
        @"xHVzmGkiw3XMWAVTc5hysTjJ29DrBn1jlkGe4Vn1u5OiMkcQJcWvBmKHUVsFO4aY9SDbEW5E/cVBUWZA9Sm09Qfoqftwrx6nt69F5wh0m4ZuJjgD5QrUy4KN"
        @"LadbhnsOef5kv/J8q4IfX4edWEOfmPLAEFe+5QZ2feCrODAwxuMvHkXPzBLHNjjE5i5Eeaw+nWqCR4iEmUBshCNHhgcpOSG/8yHciWNEJavWdV1j/yPReG/h"
        @"D1965di3iJjsr/P0VbUO6VbXbF2bN4991OaHryGapDdw+WWNRuOlv456/L90oAXQhYXTm4aHp86KSCbgtl9wzfuPtdztXPM2Kxu2+H5SM+uvu4Yf+cpdfK7k"
        @"ufOsIZ5L8Svz0FxBlpvQ6UCvH/pqnwcUIPeoD4JVnOLyHDM0wpp1Da575ov8ym/8EhPvUHQAsnsctCzxuKV9yQaemnRsX3OCDZsjTJTjE4WpQWTXN+Af/Ti6"
        @"r08+A82+oZOUMSN1zGgVOxZTmYwoDdcwdYettTAlkDhHrAtVWypAA2UQ1RqaJ0ETWQRjokNINACVLUWF/hx68g/RF48gR5TeWUNrxeBUMRHE1mCNYbknPHVK"
        @"ueuQ595TlqM6BGvWYhqDeBLK4xNccuPrWPs176A1PsVTrxyndXSaSCwmsnjvUOeDv8lqdlKRmqAa5Gym8NOQoQbRYpv8wadxp08iJVHxmTd7HrZj2vrlRw8d"
        @"/OEtIr1iB+q96ipw7l/bUqhq3FtYeKtJj/6P3NTE+8Eb6lOTswHU+qdtPaL/CwdaAUZG1h47/wdXx68e2P1nF1/9pm86/MJDv54aO1DadqE7+ewe+x8yx7e/"
        @"ZQfNIcOji4KVwvxxNSmg8EwOxUWKmAlzLk3AxgksznM676AMMF5zuIpBn8zJasPISJ/lasLDlT4H7znO4TURV1+obNoeMXhJF3vRuxGtYEspOlSCfo6dV7Kl"
        @"Hr2TXbqtEBgZRSDWYEqCrUSYksGWLCRKVFJMJIj1lOKQVGu9oxIF5M5WQNYA6wxs3giTX4mfvw85fhTbipHIUR2EUhnyPGKuJew+CY8dU+4/4XmxU6M7NI7Z"
        @"NIYp1fC2zui6KTa+5fWMvP3NtAeGuPvQNN2XngEVkkq5iE7OC3tbxRR2proaAaJFVrrzeGuIBhrYV6dJH9mNtpcw1YpKc070pSdswzX/x6kzh/+9iOS33nqr"
        @"ue2223yhyXN/nStfSPUy4M7TK3rDYH78Y85lmwSZ0WBDo/9PthxfBki3xoi79tqbbnru1NKn/ZVvn5StF7q0VLYMjvDO67ezsnMDTxxbQRbmkSLJVvs9pB/8"
        @"OSR3hUdHaD1W9zIWT79e4189/nl+96HfYeWiKq7XoDGUcKI/yqcngdMvsX1TwtohYetkzsBIRnL1EPaqT+Be/E+0n38Rv1ymlilJV8nbnlZbWGl7Oj0lK0zo"
        @"nVOcKs5xbtsphSg9ioRS2RBZqJaFSkmpJIbqsGLXgEzEsL4CO7bhT5/CHptFl4TOWcvJE8pLR5XnTnqenbW83CozXxqiPziClAdCZEetwcaLdzD0FTczfM3l"
        @"zBGz9/BZsrMLYAxJKbi7kuZoP2ScrLYZurrRLIAoVYPzipQT4loFefEg2XN70ayDlCvONGesvvh4b7Jmfu7MsZdvzXMn/D01gaoqd9xxh/nQPyO68X+zQr/W"
        @"sOb/a+/Mgy27rvL+W3ufc+785h6een49yi1ZgyVbskw0WC6rCrAcgSRL2HRCUQgLRLkgqdhVqsgqhExhQgkMOCQBGwriQhTghJTtkh3ULWtoTdbQUqsndbd6"
        @"eN1v6Dfcd6dzzh7yxz631bjkhAQUJNOn6v3z3vvj3HPXWXutb33r+869rHM+2r17564f+cjHbn9pz67/0l5a3JxceLl1S039ra+dYM2VW1nx/i3M9Er4M/OB"
        @"Odd/fk7edLR9c1WuILML5JaDYxfQmYKBuiEvdfmfagN77v151gwnDB5/kRUzu9lQnWZ0rUdNONyqXwA3jrJHaB3WvPZqzommYroLjXLEeANWNCLGap4qBLP5"
        @"QiE0CO0X0BcBMlc62N1FylMpCVpLgNurwZc7n/OQ9VCdo9iTHU7s8Rw66nn5uHBgMeKErbKQDDI9NsDcaJVUykitQbxuHdEHrqTywfexYuVKji92eP6109Du"
        @"oSoV4rFleJPj0hRMhtiCuFRwCwqDi8BClEDhdc6hBqokVnCPv0x+8HUQi65VnT/yinb7X+heuGH13fv2PvNVY6wuOM3+/+K7t957YedOzXXX2R8alOMHvFRm"
        @"x113rf9v33jiy62V226KLvmQdR6VZUhp5TLiay4iSxTm5DSkAZfG5Chr8NYELoN709lWlAq20jH8q+/9LTft28NT772c5278ABfpOT461uWKCc/YMCQ6w0cG"
        @"qptBPgHqaeSNz9DcdZyX93qeeV3z3YOWw7OObs+g8UTeBJmzxDJcgsFEM1y11BMoR1CKIEmC7mbArj3GC5lRaBVU7L0TRsqKVQ3Lhe/R5FnCc0dL7OuUOZlW"
        @"OeOqnLE1TqgapypDmJVrSN57EerKy1Cr15I6yCZnMdNLkMREI8uhUsMbi7Tb+M4idDvhNMuDFbF4R98RRrwLfHRHkOkaHEBNz2Gefgk/Mwul2OtIOXfgBR0f"
        @"3fPsj37kg7/x8MNf+8u3e9L3wxDQZ3Hqrz/+9cY9P/uF/zilGney7QMwsNy51qIiKRNfuR2/ZiXZ3AIsNoPAYd8mrFi3CgnjnA1n7cgrMSo2DGvPettmS7nH"
        @"FYNtPrp8iq1bQJbdClwI1FHEOHkemf9Nui9M8uJLbR57LeWFo5bTLcWZPGLORMz3HGkvC0OXPA12Za7vImvPUmFFQyUWKokQK6FR1ozWI2qJYrCiWTskrB3w"
        @"XLFBY9C8cBKOtmsc88OcGlnD9PotzG/chpnYAsMj2NxjZhexZ+aR3CHDY6g14/ihKr4n0EqhswTtFrSX8L0OKi1we2sDL6TQT/XO44xDahXipIR/5TDmldcg"
        @"60Kl7FR7XtmXn2AwXfzWQ1/+4o6fuf226cnjB74YKRovLZ/4xevCGDM4kbyDruidcRt/YbnvPvXxD318yXu/Y2L7Nc9PPvutB93W95f0itXWts7o7Nu70Ksu"
        @"oHzFxeTLx7BTM8ERVnTwCuyvgfabHecR60k6KSoOBjXdRNHymkWXcKxTY+Xk6wzX/xxf+TeIHwTlEH8JDN1KtHU3omLaK2s0J3Nai5apqSadmUVYbBJ3O4ix"
        @"iPFQbMacpQuKP1sG5cpjxaO0kJUishgGIkdeibC1iGykxOBAhW61zovrJjiybBOvj21goTEatuKbKe7UEv7QVPASL5fQgyMwvAw/MISrKEgdvpsjaRfJusF6"
        @"2FjEFHuVRXPRz87OObyOiGp19EIL8+zzmBPHUOUYqZUtp97Q/tXd3WG6f/hbf/Zrn/3pj/5EG1CR5r97y69curBQl2EWQuMn5zP0/wniiyLNFR+64Zq9h2e/"
        @"1BlddxmrNjlUhOt2lKoPkFx6MaxeQdbp4hZbqIIeIC6Udf7cUzEWVOSpKcdoZJgoZWyvdbhypMnVozOsnZhHRj8F/iYgx6sjYPZD8wCnj77B/zixjEfyTexX"
        @"IxxJNabnUCZH5Rn0etjUhEBKe0iW43Ib8GkBiSMkUgESqdfwQ0Egp1yrMFAvU08849WE9aqFyQ17/RinjWahl9PrmQKVEIhjfLkUSE3VOr46CJVywLgJbETy"
        @"DNIO0u0gvRSfppClQYSnMOwRa3AiqFqdOM0w+w5jDx3BdZdQ5TKx7WH2P0vp9NGX1q9Y9gv797/4RLGh/bbuAf4QZui/A/GJMVbt3vntJ77x2GMf/fmf+3e/"
        @"enrf3F1+3Xai+pC17aZOv/s4enwVySXbcStHsQtLuE6v2HA+t/kunJecYJTCEpE6Q8sIi3nEUp5gOinRcBsRj+NPYOEJ7NQ8x+fGONIdx/mY4eYUldYiUTeh"
        @"7RJ0HKOiMj4ZhGqM9DvAgqMsZ0WfVfH7MCJ3KmhNL3lLu9ej1u7Smm4y5zrUlDCPoyOaTCJcVELiUjBk0lHgXaskfL688EExedj6MSYYWeYpZDk+twVTr3Am"
        @"8yY82HqDRAkcmSTduw+Zn6ZSiymPxLjTB3zzhSd6yyuVb9z2yVvueeihh04VjBXXD+b77rtPfR6Q++9/xwa3vHPftVBXl0oJE9uuuu34maV/n46u3i4XTHgf"
        @"V7zrNJWohGhiA2rLJly1jFlsBu5Hn3MhxXeRQBwJI9qyOu6xsZJy6UCLq4bmueyC/dQ2fRZPE5n5HZamBzg6v5w97RH2tmq81qpwrBczayKmbURmJJQ6tjDd"
        @"dEWDFZxHi20SFbSRsYjS+EgXwpLBqsPHqvAZ9ZSUp66hpBVNSeiIwhbytqIivFJIFBdLAiUkCQsDXseFU5Yr7IbzwKPIDWIM3uYh0J1D4pgoKiHTc5hX92FP"
        @"TdKIUpaXFcvtPL1Xv+tkcVp94mfuPvErn3vgEhGZu/baa6Ndu3YZ3mWXvLNv7yz72H3pS18ave8Lv//gUlT9Ob92O2pklfV5V3y7o6RaQ2/ditqwDhNrbKcD"
        @"WRowV+VxEWjtGdSOC2LDhkqPixsd3l+b4oOrphm56NOYE7/P3CnHofYY+1oDHOg0ONStcLIbczqPmDERPadQtk+363O2KbZGCnOcopYP2TrAdl7rMFKOdMGT"
        @"cMGqQYckrsWjRLAS4XQIZpQONtFK4WONihJ8XEIiHbzUlQ4VsfPBMs0avMkDNm9M8CiMY7SOULNN3N4jmONHcS5jeUNxITNc0nyS8cVXUHGFH7n9LnfV7Z9T"
        @"C4v2w8PLxh/tb/a/2wI6eoe/b0XdcKu+5557zkRRdNfmbZd/8+ShZz7fHV59CRdsQjcGnGu3JX/uGVGHDqHXT6An1uBGhnHdLj7tgvNYgVRB6oWu17RMRCc1"
        @"UN6CnXmUo0dTDnYnONROONKucKSbcNIkzJmIOavJLIV7bPGKBd0xlJezLk/9yY5QIB5K8LZoynRUSGSocIDrYM8c1OR9YL2p4E3iVRA6l4J47b3g+s5YzoXM"
        @"KwFX9v2+wRp8Hiw7VbVEjKBOnsEdOIGZmcHmbXySMJJYts4+z1XtJ/nEj13ChmtuoTb9CO0o86azQDkZXPuPPb07H9BvhYKAGGPktVee+fpXvvKVnffe/8W7"
        @"mgdn7+4NjK/1K9ahKkPWt1sqf/l7og7uQ61ZS7RxAkZHMCbHdlp0c0M30rRcTDPLyBOhXq7z+qE9PD2/kePZAG+0Yo73IqZNiUUXMe8UPSt428+G5woe/m8O"
        @"OO9CxaOlsE62IQCVD56Oogq75aLnkvB/3gfFe1ygcHoHyvli6cHhbVg0QGxR5tigPRJrdCVBt3twZAZ/5ATZ9GzI2qWSi6plX5ncQ23/t9g8NK9/6lOaiz79"
        @"aYh+gnzfZtSBp4myWfKkdgvwVfj8uzKo5V14zxqwSgkPPviFtV/+g/969+l2/ktm5caKLFuFRCVL1lU+y4VyHbVyHL36Alg5gqsKQypnFW02ugVuH5/huvUR"
        @"f33Asy8d5GQaM50mnDGaRatZtIq2FZwVsGFzRQoT+WIC9ncmb96fGwPBSBMR0Brnw8DHS0E3jVQoJwrDUq8Lr0eKMWO/9BDBRwJRhNLnlBqiINFISaOtReaW"
        @"4NgU9shJ7NxCcJioVL3YzLvJg7p6/HtcVJrn5huu4GOXid9cfxImuqIuegS6+zFP/qzX6/5AzNg106VoZLsMDMy+XXt/5wP6re9bAyaOI9539XUXHz82efd8"
        @"ru5IB8YHWb4aXRuyLk/F99pKRCPDy1CrV1BbVuWCsRLbGsLd6yY5tmh5bGGMM5liKtcsuJiWE5pG0bEEGTErb5pueoLvdt9Y/ixfwb3FyDck36D0qYL5JApX"
        @"uO2K1nhdBLpWhSuBCqiJVnjReOWDoLsOtbMqlZAoCvfQ7MLUHP7YJHZqFp9mwSNSKSdZR/n5KeTYPhpLJw6N6uyPf+8//W7vhg9edlNn9siH7fGdlOb/1CUb"
        @"O0q95zuYvZ/DzTdc6dL7VJrFHyuPrP6b/5/b2v/cA5o+jHR/EHtwSRJz553/+vJHH3/uM2e65uNpbbThRlYSNYaci2PvnFXe5tKIDSuGyly7tcH1W8v85ewY"
        @"Z+rLWNQlFrqWpdzSzixZFsoLcW8isL5vi1xkZHf2AfaHF9/HCZZAlpe+b5sqsrIU6EXx45XgogLeKxpKiWJ8oqGkkaSEihKUsfilNjK1gDs9g5tdgG4Xrzyi"
        @"tRO89522YvqYyOQ+qq3Z59YtG/mre++99yt3/tS/PG3yoDrRWZq+g3zhq5X20STd9+tGj7citeGXyZ96yJQufiDKSlt+uzS09jPnA/qf7uobsfYD++Lv7Hz8"
        @"llbq7+wktS12dDUyNIKq1Ww5FoZcW13dWBAflziQDtGpD7E0vJyl2iC23sCXSzgfZH69yQoBdVs0eAVc5z1azraAZ725vRStbH8mLBQWZ2ELJGRhHeyG+9k5"
        @"0fgkRqIISWJUKUHiBDEOul2k2cFNzePOzOOWWqH5U4Jo5UR5L2mq/fwMfuooydwJ6j57ZmJ87Nd27/7bb2qtcxeYdfrhh28FbuW2226zrbmjnyqX4/+g20eW"
        @"dZ/5t06tWSOqusnF3brurrjlO9Xl2z5yvuT4p8/ZCkLG1lrx0ksvj3z6lz57294Dh388df5fpPWRulq1jmUjNdZFHTvd1bKky9JJjWQGjMQQ14LJTX0AGaoj"
        @"9QF8tYRPEiSOwxKpdXhjz/KLg65IGKadFcvpT4mkIEtFOiyjRhq0QumCXS8aUQWCYYB2D7/Uwi8u4RcXcV2DzzJwOUor76LYC8qRp0qWZpU/M4meO0Ulax8d"
        @"ieWvJtaN/fW3v/3N3SLSx5C19/5cwr30Ibl2e3a19r3fKGVzd5jX/5y8nua6mUZm5OZmddOHt4vIybdzXep8QP/9axHF/fcLxcp8ksTccceOSx978tlbFjvp"
        @"lUlVX6XL5aH5aBA7uhpbqjpRiceLeGPFZbmoAgJDgvSAVGrQaEC1hi6XIEnwcYxEGpUkSBJhlRT1spwtoqXI0KpAqG1e6ItkKdJLsb0M0rw4BTJ8muGtRSmB"
        @"RDy67FE4bCZkmfbNRVicRjdniJbmjw6X5bHVY8Nf+91f/exTH7jppkVr7bmnlv9BENy529dZe/YXle89qE8/0mjNPU3cuNapjXdcnSTyjPcP639Mqa7zAf0P"
        @"GcuEI7P/xTqlBK00n7z9U+956eDBnzw1M/vh+XZ+iS0PDfraAL4+jNSHkbjsUVHYUfJGME6cM3jjRZx7E7RTCqXisFAqEqaCot5ENyRMBAvt/CAj7As/7QL9"
        @"QGtEKy+FppfoyPs4BufFZ11F2oHWLKo5j+4spHFv6cVqJK9d9p5tj37yzpv/ZseOn57vK+KHRvlWChPLvw/xXhVojUuXTl0kefdzvVO7bm4M6VpHX/XL1RWb"
        @"Hwp/Pp+h36kNZB9EdiJQKpW58cYb1x5+48z7W83mjV3jr2tmdiVxZdCV61AdwNYGUKUqXkeI0h6lvKgIlPYg4kOACsibXib+bBPo0VrCoMTjQ1vpQy2tUEGp"
        @"Ulye47NuoKJmPVTeQXVbxFnbqDzdn9js8XWrVr46HKnvPPbUI68ZY3Ce/6cg/kGB3Q/aXnP+J1X3e1/OU91gzbWbaiIn3k1lxz+bgH6LJvJsSQKgtcYYU7r5"
        @"5jtGZ2fnti40ly6fX1h6r0EuzaxbZUQGjSpFPi7h4nIgC+ko8CpEo6I4QGuF7pwoHfYcvQ9TPmuKYYtFXBhPi01ReY/I+zwWOxd5Ozlcrx62afupVcuXHV6/"
        @"fPmBP/7afz6gleTOfz8W/w8L4rfM1jt3Krn+etOemXlfpBd25S7+9frY+gceffTR6PrrrzfnA/rd8fkFbhX4C84N8JBgFcbY5IEHfnN8z55Xxo9Pnlo5O9cc"
        @"RNS2brezSms93Ep7pSQpjxtHbLxYj6/qKG50eumsVuSlOG7EceyUop122pNax1NKZG54oGEG6smrKsunN2/eOHPDDVef3LFjx1S5lJgsy78/SjVcK3Cdg/s9"
        @"b+Nouh+8S7OnPyKYNfWx1X/0bsrQ/wusEjtKwCM+DgAAAABJRU5ErkJggg==";
        NSData *data = [[NSData alloc] initWithBase64EncodedString:encoded options:0];
        img = data ? [UIImage imageWithData:data] : nil;
    });
    return img;
}

static UIImage *ZLegacyZc83f0d7b42(void) {
    static UIImage *img = nil;
    if (img) return img;

    CGSize size = CGSizeMake(48.0, 48.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextClearRect(ctx, CGRectMake(0.0, 0.0, size.width, size.height));

    CGPoint c = CGPointMake(24.0, 24.0);

    UIColor *glowOuter = [RGB(95, 240, 255) colorWithAlphaComponent:0.42];
    [glowOuter setStroke];
    UIBezierPath *glowRing = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(4.0, 4.0, 40.0, 40.0)];
    glowRing.lineWidth = 4.0;
    [glowRing stroke];

    UIColor *glowInner = [RGB(170, 255, 255) colorWithAlphaComponent:0.24];
    [glowInner setFill];
    UIBezierPath *halo = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(7.0, 7.0, 34.0, 34.0)];
    [halo fill];

    UIBezierPath *outer = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(8.0, 8.0, 32.0, 32.0)];
    [RGB(255, 221, 58) setFill];
    [outer fill];

    UIBezierPath *rimShade = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10.1, 10.1, 27.8, 27.8)];
    [RGB(255, 147, 33) setFill];
    [rimShade fill];

    UIBezierPath *rim = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(11.6, 11.6, 24.8, 24.8)];
    [RGB(119, 43, 197) setFill];
    [rim fill];

    UIBezierPath *body = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(13.5, 13.5, 21.0, 21.0)];
    [RGB(196, 61, 255) setFill];
    [body fill];

    UIBezierPath *highlight = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(16.0, 14.0, 8.6, 6.4)];
    [[UIColor colorWithWhite:1.0 alpha:0.44] setFill];
    [highlight fill];

    UIBezierPath *bolt = [UIBezierPath bezierPath];
    [bolt moveToPoint:CGPointMake(26.2, 11.0)];
    [bolt addLineToPoint:CGPointMake(16.3, 24.3)];
    [bolt addLineToPoint:CGPointMake(22.0, 24.3)];
    [bolt addLineToPoint:CGPointMake(18.7, 37.0)];
    [bolt addLineToPoint:CGPointMake(31.8, 20.8)];
    [bolt addLineToPoint:CGPointMake(25.1, 20.8)];
    [bolt closePath];
    [RGB(255, 246, 73) setFill];
    [bolt fill];
    [RGB(255, 116, 23) setStroke];
    bolt.lineWidth = 1.35;
    [bolt stroke];

    CGContextSetLineCap(ctx, kCGLineCapRound);
    CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithWhite:1.0 alpha:0.70].CGColor);
    CGContextSetLineWidth(ctx, 1.7);
    CGContextAddArc(ctx, c.x, c.y, 14.5, 1.05 * M_PI, 1.40 * M_PI, 0);
    CGContextStrokePath(ctx);

    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}
static UIImage *ZLegacyZ71a4c9e2d6(void) {
    static UIImage *img = nil;
    static CGFloat lastR = -1.0;
    static CGFloat lastG = -1.0;
    static CGFloat lastB = -1.0;
    static CGFloat lastA = -1.0;
    ZThemeLoad();
    if (img && fabs(lastR - g_themeR) < 0.0001 && fabs(lastG - g_themeG) < 0.0001 && fabs(lastB - g_themeB) < 0.0001 && fabs(lastA - g_themeA) < 0.0001) return img;
    lastR = g_themeR;
    lastG = g_themeG;
    lastB = g_themeB;
    lastA = g_themeA;

    CGSize size = CGSizeMake(48.0, 48.0);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextClearRect(ctx, CGRectMake(0.0, 0.0, size.width, size.height));

    UIColor *themeGlow = [ZThemeBorder() colorWithAlphaComponent:0.28];
    UIColor *themeAura = [ZThemeButtonOff() colorWithAlphaComponent:0.22];
    UIColor *outline = RGB(122, 66, 14);
    UIColor *sideShade = RGB(219, 146, 18);
    UIColor *mainFill = RGB(255, 238, 78);
    UIColor *mainFill2 = RGB(255, 224, 53);
    UIColor *shadow = [UIColor colorWithWhite:0.0 alpha:0.14];

    UIBezierPath *shadowPath = [UIBezierPath bezierPath];
    [shadowPath moveToPoint:CGPointMake(17.0, 8.5)];
    [shadowPath addQuadCurveToPoint:CGPointMake(25.3, 10.8) controlPoint:CGPointMake(22.0, 7.8)];
    [shadowPath addLineToPoint:CGPointMake(33.9, 14.5)];
    [shadowPath addLineToPoint:CGPointMake(34.2, 23.0)];
    [shadowPath addQuadCurveToPoint:CGPointMake(31.5, 26.6) controlPoint:CGPointMake(34.2, 25.4)];
    [shadowPath addLineToPoint:CGPointMake(39.0, 31.6)];
    [shadowPath addQuadCurveToPoint:CGPointMake(39.2, 35.3) controlPoint:CGPointMake(40.4, 33.6)];
    [shadowPath addLineToPoint:CGPointMake(22.8, 46.4)];
    [shadowPath addQuadCurveToPoint:CGPointMake(18.3, 45.2) controlPoint:CGPointMake(20.1, 47.6)];
    [shadowPath addLineToPoint:CGPointMake(12.4, 40.2)];
    [shadowPath addQuadCurveToPoint:CGPointMake(11.7, 35.9) controlPoint:CGPointMake(10.9, 38.6)];
    [shadowPath addLineToPoint:CGPointMake(17.5, 28.1)];
    [shadowPath addLineToPoint:CGPointMake(14.1, 24.8)];
    [shadowPath addQuadCurveToPoint:CGPointMake(13.2, 20.2) controlPoint:CGPointMake(12.7, 23.0)];
    [shadowPath addLineToPoint:CGPointMake(13.0, 11.8)];
    [shadowPath closePath];
    CGContextSaveGState(ctx);
    CGContextTranslateCTM(ctx, 1.0, 1.2);
    [shadow setFill];
    [shadowPath fill];
    CGContextRestoreGState(ctx);

    UIBezierPath *aura = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(7.0, 5.0, 33.0, 38.0) cornerRadius:12.0];
    [themeAura setFill];
    [aura fill];

    UIBezierPath *glow = [UIBezierPath bezierPath];
    [glow moveToPoint:CGPointMake(15.8, 7.4)];
    [glow addLineToPoint:CGPointMake(24.9, 10.1)];
    [glow addLineToPoint:CGPointMake(33.0, 13.8)];
    [glow addLineToPoint:CGPointMake(32.5, 22.2)];
    [glow addLineToPoint:CGPointMake(29.6, 25.4)];
    [glow addLineToPoint:CGPointMake(36.5, 30.4)];
    [glow addLineToPoint:CGPointMake(21.7, 43.7)];
    [glow addLineToPoint:CGPointMake(14.0, 38.7)];
    [glow addLineToPoint:CGPointMake(19.6, 28.2)];
    [glow addLineToPoint:CGPointMake(15.3, 24.3)];
    [glow addLineToPoint:CGPointMake(15.0, 12.8)];
    [glow closePath];
    [themeGlow setStroke];
    glow.lineWidth = 5.0;
    glow.lineJoinStyle = kCGLineJoinRound;
    [glow stroke];

    UIBezierPath *body = [UIBezierPath bezierPath];
    [body moveToPoint:CGPointMake(14.8, 6.8)];
    [body addQuadCurveToPoint:CGPointMake(25.2, 9.5) controlPoint:CGPointMake(21.1, 6.1)];
    [body addLineToPoint:CGPointMake(33.5, 13.4)];
    [body addQuadCurveToPoint:CGPointMake(34.0, 22.3) controlPoint:CGPointMake(34.4, 16.0)];
    [body addQuadCurveToPoint:CGPointMake(30.8, 25.8) controlPoint:CGPointMake(34.0, 24.9)];
    [body addLineToPoint:CGPointMake(39.0, 31.6)];
    [body addQuadCurveToPoint:CGPointMake(38.8, 35.4) controlPoint:CGPointMake(40.4, 33.7)];
    [body addLineToPoint:CGPointMake(22.3, 46.2)];
    [body addQuadCurveToPoint:CGPointMake(18.0, 45.1) controlPoint:CGPointMake(19.6, 47.0)];
    [body addLineToPoint:CGPointMake(12.0, 40.0)];
    [body addQuadCurveToPoint:CGPointMake(11.3, 35.8) controlPoint:CGPointMake(10.5, 38.4)];
    [body addLineToPoint:CGPointMake(17.8, 28.0)];
    [body addLineToPoint:CGPointMake(14.0, 24.4)];
    [body addQuadCurveToPoint:CGPointMake(13.2, 20.0) controlPoint:CGPointMake(12.4, 22.7)];
    [body addLineToPoint:CGPointMake(13.0, 11.5)];
    [body addQuadCurveToPoint:CGPointMake(14.8, 6.8) controlPoint:CGPointMake(13.0, 8.8)];
    [body closePath];
    [mainFill setFill];
    [body fill];
    [outline setStroke];
    body.lineWidth = 1.8;
    body.lineJoinStyle = kCGLineJoinRound;
    [body stroke];

    UIBezierPath *side = [UIBezierPath bezierPath];
    [side moveToPoint:CGPointMake(24.9, 10.0)];
    [side addLineToPoint:CGPointMake(33.3, 13.6)];
    [side addQuadCurveToPoint:CGPointMake(33.8, 22.0) controlPoint:CGPointMake(34.1, 15.9)];
    [side addQuadCurveToPoint:CGPointMake(30.9, 25.3) controlPoint:CGPointMake(33.8, 24.5)];
    [side addLineToPoint:CGPointMake(38.7, 31.3)];
    [side addQuadCurveToPoint:CGPointMake(38.3, 34.9) controlPoint:CGPointMake(39.9, 33.6)];
    [side addLineToPoint:CGPointMake(22.1, 46.0)];
    [side addLineToPoint:CGPointMake(20.0, 38.5)];
    [side addLineToPoint:CGPointMake(25.0, 29.1)];
    [side addLineToPoint:CGPointMake(22.5, 24.9)];
    [side addLineToPoint:CGPointMake(24.4, 19.0)];
    [side closePath];
    [sideShade setFill];
    [side fill];

    UIBezierPath *inner = [UIBezierPath bezierPath];
    [inner moveToPoint:CGPointMake(17.8, 10.0)];
    [inner addQuadCurveToPoint:CGPointMake(24.3, 10.8) controlPoint:CGPointMake(21.2, 9.0)];
    [inner addLineToPoint:CGPointMake(28.7, 12.7)];
    [inner addQuadCurveToPoint:CGPointMake(29.0, 18.6) controlPoint:CGPointMake(29.4, 14.3)];
    [inner addQuadCurveToPoint:CGPointMake(27.1, 20.9) controlPoint:CGPointMake(29.0, 20.1)];
    [inner addLineToPoint:CGPointMake(31.2, 24.4)];
    [inner addLineToPoint:CGPointMake(20.7, 37.5)];
    [inner addLineToPoint:CGPointMake(19.2, 31.5)];
    [inner addLineToPoint:CGPointMake(22.4, 26.8)];
    [inner addLineToPoint:CGPointMake(19.0, 23.6)];
    [inner addQuadCurveToPoint:CGPointMake(17.5, 20.3) controlPoint:CGPointMake(17.9, 22.6)];
    [inner addLineToPoint:CGPointMake(17.4, 12.6)];
    [inner closePath];
    [mainFill2 setFill];
    [inner fill];

    UIBezierPath *shine = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(17.0, 8.8, 12.5, 3.8) cornerRadius:2.0];
    [[UIColor colorWithWhite:1.0 alpha:0.42] setFill];
    [shine fill];

    UIBezierPath *shine2 = [UIBezierPath bezierPath];
    [shine2 moveToPoint:CGPointMake(24.6, 21.9)];
    [shine2 addQuadCurveToPoint:CGPointMake(28.9, 24.2) controlPoint:CGPointMake(27.2, 22.2)];
    shine2.lineWidth = 2.0;
    shine2.lineCapStyle = kCGLineCapRound;
    [[UIColor colorWithWhite:1.0 alpha:0.30] setStroke];
    [shine2 stroke];

    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}
static UIImage *ZShieldUserIcon(BOOL legacy) {
    static UIImage *normal = nil;
    static UIImage *bright = nil;
    UIImage *cached = legacy ? normal : bright;
    if (cached) return cached;
    NSString *encoded = legacy ? (NSString *)(        @"iVBORw0KGgoAAAANSUhEUgAAAJAAAACOCAYAAADemoFTAABPfElEQVR42u39eZRlyXXeh/52xDnnDjnXPHZ19TyPQANoAAQIAiIJEoAhk6JEPt"
        @"KSKJMmZdKUKUrPWhIlyqakZ5N+8luSJWuZov1ki16kLNKcQXMABIIEATTQ89xVXV1zZlYOdz7nRMR+f0Sce2/Ba3nZ66GBajADSFQhKzOrMs++"
        @"O7797W9/G/bO3tk7e2fv7J29s3f2zt7ZO3tn7+ydvbN39s7e2Tt7Z+/snb2zd/bO3tk7e2fv7J2985U9svcj+D+ed0Jnsri4aHPX6bjQBgggGa"
        @"1Q27qituOi2x29f2Nj9FMQ9gLoT+l5H7SHS8UpddxtlHtVwx1Bw81eOaSqK1ZoC+QKBEUQ1CBOYKIiQ0G3RMxFMfKateY1QZ73wbz0+dHoyl4A"
        @"fZ2eR1utW60N79ag73chPKaqNxvDQjvL6bZbLHTaLC90WFnosNgqaOc5WWZVjBEfFOcc47KiPynZHozoj8aMJyVlVVM6ryHoVSu8asV+QXP5TM"
        @"uZP/n0ZHJ+L4DewufhTueYCe7Dqv7PhaCP5VZWFtptju5f5dSRg5w+ejAcP7DG/uUFVpa6dDsdiiLH2AwFjDFYa0EMGhT1Nd45KucYjSfs7A5Y"
        @"397l/Oa2vHF5U85dWefq1i6DssLDpjXmc9bYX/FBfvsLX2fB9HUdQI8ttt8bnPs+78O3i+HIwZUlbj92mPtPnwi3nzjCkf2rLC4vY9ttvAiVV4"
        @"ZlSb8/otcfUZUV1WRCXdeICNZabF7QyjMWlrosLS+x1G3RaRW0sowMTzUe0dvtc3Vji1fOXeLps5fMmctX2djt43zYNMb8ZpbZ//GPh+Un+TrA"
        @"T193AfSdYM92im8LPvyIV//+hVae3XnyGI/ddUu45+YTHDm0j87CArUKW/0xly+tc+niZa5tbNLv9ShHI1zt8N4jApmR6VMWBK+KACJCZg1ZkV"
        @"N0uqysrXLgwAGOHj/M0RNH2be0SEsCk16f9fVtXnzjAp9/6Yx59ux5tkaTkFn7qVzM/+fEuPq1XwK/F0A3Ar5ZaH1Ivf9bIYT3ry10efudp/Vd"
        @"99yqp48fZmllhQrh6rVdXn/ldS68fo7t7d2UXcBYgxjB+UDtFVXFOc/EK63M4AWqoLSNkFtDYQ3WGEz6IQYNaFAMis1yVldXOX7zCU6ePsXxww"
        @"dY7hSUoyFnX7/Mp599WT7/4qtyebsHyL/LMvuP/mRU/dZeAH2trqqiuMdL+Du1+u/Yv9DN3nvvnfru++/UE0cP0lrqsrE15OWXX+Xca2fY2dpB"
        @"UIyxOFWGpWNQVgyqmn7tCRY63ZzFxYLl5TbdVs5zz11Gho77DqwRrKUMgV5ds+s9tQYyIyzkluUiZzG3dPOMTATnHF6V7tIiN918M3fcdRunTh"
        @"zGesf5Ny7zyadelE89/YKs9wbeiPklk8l/8flh/dxeAH21Mg50aRc/HkL917pFvvaOu27Tb3roHj190zHswgKvv3GJZ595nssXLuLrmizPmLjA"
        @"teGEa6OSyihr+zqcPnWAu24/xOnjSxw/sMD+1Q4LORRWYGfIf/4vP8v5P7rMvzx5iHphgQpwxjLMc7ZFuFw7Xi8nvDAccWY0YaSebpGxv9tif7"
        @"vAClS1B4SDhw9yz/13c+cdN9MKyuuvX+Q3n3iGP37+ZTOc1NuZzf6hn1T/+Amo9wLoTTxvb2fvqnz4WYO+656TR/jw2x4M99xyimKxy7nLGzz5"
        @"5NOsX72KUaUOyuZgwrWyprXa5s47jvDYIzfxwN3HOL5/gUWpCaMhYTyAusJPJmiIyGewM+F3vrTB7/7KGf6BgZaAD2CBPBOy3ELeYtLp0FnqUi"
        @"4ucEbhC8MxX9jtcX48xuSWY0sd9nUKgg9UzrO6tso999zFfXffivGBZ185y7/9w8+bFy9eRYRft+Q/+rmyPLsXQG8CSH6tyP5aUP93V7vtxW95"
        @"5L7wrrtvZXX/Pq7tDnjiS09x4eJlEBjVnov9MXap4O2P3sL73nsn9992mLW8hv4WfneXqt9n1Ovja0/eymi1W6gCItjCUo49T7zS5+f/x+f4SV"
        @"X2G0FVgRhERiAobHtYsLBgwOQFdmUZt2+VKzbnM6Mxv7e1zcW64sBim6MLHYwGnPccOnSABx+8j1MnDrO7ucvvPfkcv/fk86Y3Ls/bIv+hJ0bV"
        @"b+wF0FfovGNh4XBdjf+JCt9xz4kjfPSxB8Ntp45RhsAXn3qB1868jiWwNXZcGpecvOMI3/5tj/KeR29mXzvA5mXK9cv40Qg0IMagCKNRifqAtY"
        @"Z2p0DE4LwnKwoAXjzb47/8uef4ibHjdCaEAEisxqyAKPQDYGBJQAN4hbHCajujvbpCubrCU175xa0dvjgec3Spzc0rC3gf8CFw+tRJHnr4frpZ"
        @"xjOvnuWXPvOEubS1W1pr/tYTE/df36jPxL5Vguf+bv5IVZa/3Crs+z9w/53hO979qB49coCzFy7zh3/0eTbW11kflLywPeDmu4/xn/z1j/FXvu"
        @"sd3L0/YC68wuTsy9Rbm2idoIUYRARVqEsXCUKFvJUhRvBeY2UmMB7U/PGLO9w9rDmUGU2V/PTlZwAlgpaWgEh8Z4kgIeCGY+rNbQ6PJ3x4bZl3"
        @"7l/j7O6Qz1/rYTLLWqdge3uHM6+/QZYX3H7qJHcePqjXdnv5xk7vm49k9uA+r7+7cQOW+2+JALq/sB9V539hbal9y3e+81H/jQ/cK17gC196lh"
        @"dffIX+cMzZ3TEHbj/ED37/e7hzxfCeBw9SvfwU1aU3COUEDSAmFt2qYESmSbiuHMEHjBGKIgMgqGKMYESYjB1ffHWX4zslxwwYREK6xpD0QxSo"
        @"gCLFlQjUSCzzJTKGVe0IvT4n6gkP2YxnemPwgeeHE5baBV0jXLx0mf5wxMnjR7n3xDEdlyUXtrYfM9bcfsjrb1+9wcD1DR9A97WyHww+/MvTB1"
        @"dWv+fxt4f7bjklV3d3+ewXvsi1zS3O746YLLX4S3/1W/jRH/735LaVIM9++ou0/IglShSDIISgiBGMkZgvxCApCznnCS5gRChaFhGIvVMwYvC1"
        @"56lzPRaujjkqIm1rCKoQ/xt5JBFKhVxiRkJiulCFTEDTGwK+crSriguqvH3fGo+tLPGJq9v0vefQYodev8/65jX27d/HXSeOoyHoxc2t+yWT+w"
        @"8tLv/W1bKc7AXQ/4XzYGb+pmr42buOH8y+850P69ED+3ntwgWeevpZev0Rrw/GvPND9/B3/vZ38+A9NxHOPIm58ArDwZg3duDWox28VxDB+wAa"
        @"+1qimhJSCqA6EJwHlLydg8xlKitoUF6+MMS9MeCECN3M4ENIgRYDxorgVFBiwEj6w0rjtabpmvMagXduhQmGPygrfrjb4v2H9/Ol3oindvqstF"
        @"u4uuLKxgbLS8vccewYmUHPb27dpXX9wOnV8Gvnx1R7AfR/ch4psr8bNPwX9544LB992/1heaErz7/yGmfPneNKb0S/W/Bj/+m38d3f9xGK3UuM"
        @"vvBJTH8LFUO7k/GFFza5+7b9SHAJ68TqyRqDqkoIAWstAtTO42oHCHmRYayBlD3ExEx0bn3M+iu73CywmGVoiEAopAxkJQaPA4oGBxEDqBCmHx"
        @"umAQYdY/hk7TkZHHf3dvngkUP0rOX3r16jk2e0jOXy5iaddpvbDh/BgJ6/du2OciK3PxT0V1+9ATDRDRlAD+T2pxH9Ow+dOqbf8sA9WuRWnn/p"
        @"VS6vb3Bme8RND53kp3/qe7j37lNMnv8s+sYLuLIiKwoU6LQznnlhg7XD+1lrKal7hfchAWOJV5aJT9LXnrr0IIJYIctszBiq8ZozhvWtMa+9sM"
        @"OtqnSNoQBiHovXXSYRE5XMMo4ApV5f7gPp74UFa3nZQz/PuC/U+O1dvmFliUMrq/z6lU1qEbp5xub2Dp1WwemDh1DQSzu79w6NHLrk9Td+ai+A"
        @"rj8PF9nfhPBTD950LHzwvjuBwIuvnmFrt8dru0O+5WMP8//8m3+BZS2pnvk09cYVbJ6jKDazEXNkhq2tEdfGhluPtAk+oKrXBVB8wPF6CyFQVz"
        @"5hIyFv5SkDKYKqiEhvUPPM81vcWgdaxrBgLM77GIxE7CNRaUYxV6G5hJPy9P8bHBR/+MJIDM8GeHuRIbWj7g24L7PccfQwv7m+xUSVlVaLzd1d"
        @"Wq2CWw4eoqxrruz23vYvcju+7MJn9gKoCZ5W9h9D+Jl7TxzRb7r3TkB55exZru0OODsY81d+4Bv5vr/4YXT9PJPn/ggJPgZFbglesXmsoETiy/"
        @"2Lr2zx4J0H0dQwDUEREcwc+yXGEILiKkfRyvHeU7TyuY83ImIYjh1ffG6LWyaeXGAly3DBAeARMokVV60k8B3jBZBKYlaKwDpiK5v+dDHP+KPK"
        @"cbqVc9DXeIHJaMKREHj7kcP81rVthqos5i22B32Wuh1O7TvAznjM5mD4vqNF/vwV51/4Wj0zc+NkHvtR1fAztx7cL++94zacq3nptTNs7A64UE"
        @"748R//Vj7+nR9k9PwTuFe+kABKeirpVd78TwjKoQNdhjsDNkeavklJ2CY+4YZQTgGlipK1omDMhzD92qqgIbDQMmQLGWOgUsUbISCE9Hd7FE2v"
        @"yAaYRLwjKgiuCVjVpjpTj7JflCWU58RgjEUj1qe31eP+jXV+5uRx+oMRFwYDVA1nLl+l9jXvuPlmPby8VKj3//RtRXHnn+oAeriTvS2o/tzxta"
        @"XW47fdHKwo5y5eYLM34FJZ8p/9xLfxgW95D5Nn/5jq9RcQkyFNpSTx7hBAg4JXVR90odtiMRfOXhljMxM/JmEPEQExEnmhCEok4SSTWVztU7si"
        @"yjoU6OSGomsZAU6VqiF7BBS97qqqdVp1iaDY5n06+569RHG1DYFbreGFsqbM8ik/KQb6/SH3XLnKPzpwiJ3+gGvjEbVXXru6TivPeNfp036pVR"
        @"zx+P/hcVj6U3mFPdrtHvWu/pWDi51T7739tF9qt+XS1Sts7fY5P57wE3/tW3jPN76DyVOfRrcuExCyLI/4xAjee7Lcxqoolj6CESkyy9bWiPPb"
        @"FfffskLwHhFD0BBLeWYBhUA1qaN0Nc9wlYtAWjUBaUE18NzZPvnlMasChTG0059rKtmz9PCbyksVVGJ4T9Kfp4QZPzBdd3mR8Uel4/5Oi8WqQl"
        @"PABSBUNacInD50kF/d3KRVFDGLBc+R1TXJrISru72bKiv5Za//+5+qDPQ+yLyf/NPFdn73o6eOh9VOWzaubbDT63OuN+Sv/sD75Rs+9C7Z/dzv"
        @"4a5ewJgsvbRj8DSMcmjKm/RAvfN4VU4eW+bCpR1KyZD08pf00GZdQEHEYETwzmNM0j1/2ZuIYd9Ki0Eq1YfpY5uv6UlVls7Ac3ONpViZXmOkj9"
        @"WImfSIgbYqr4vBJgohl0Q5GxgMh3zDcMAPru7j5Y1NnA/s9AfsDPrcvP+A3Hxgvwryn7y92/rmP1UBtFtkfz0z5uP3Hj0UjiwvsdPvsdsf8NrO"
        @"kO/8rkf51o+9j+q5z2lYv4wpingNSQIv0/tA0EQSNl1yX9V4Hzh4oIsbjrk2nBF7SGygTm8TjZyzyUwKlPh1QggxIBMmMgJLizlb6dPGqqi1U7"
        @"mr1/gWe6ozzOMTLstSqyMkfqkhHZ2qdAOcMsLLtYc8j1gqtT9cCr6dzR3+fV/z4cVFXt3aAoRL2zvUrua+Y0d1tdvJnXc/8+AKq38qAuiRdvZe"
        @"1fCTp/at6C371xiXE3Z3dzm/M+Qd7znN9/3Fb6d+7WkNmxegyBGRpCSMD7pJ/xCrJVJjNIQQWxMhsLhQsFDAxc0xNstS0MiUBIyBoqgGTGZTJp"
        @"tehfHrOQ8KVgLLhWeYGQJCrUoJBARFpyShpgqswTxNwGQpGMI0SUVsFRSCD9yaZ5wrSwY2m35vNvFIPl6FjLZ2+NFOmyPAG70+wSubvR6dIueu"
        @"I4dCbsx92cT+xNd9AD26yAHvwn97YLHTufvIQVUNbO9ss94bsXy0y3/6ox/HX34Dd+kMYjOMEVwdaxtrTbwzGqZYhODDlPkVBPUxc+RWOLKvw7"
        @"lLfcjiNSZTeAveeVxVR4bayvQKlMQNqQYUxVeOT15d5cn2w1QCtSq1KmMfUqUWv2qYu7ICQkg4yM817yttemezas15z03GMHKey9ZOH0rLyBSc"
        @"K1AGpbWxyV9fWmaj32dQVwzHJdvDIcdXVjm5tqqq/MjDC/kDX9cB5Cv7n7dze9/dRw6EhTyj1+8zKis2guOv/7WPsOBG1GefBhMZYWvt9EEbEa"
        @"T5oUbl1zRjMCXpFA2RPDxxqMvFS9s4sfGxTqun+HmudAlTmZgxfEB9ILhAqANGlacueyYf/4es/NA/Y/vWR6bX0yiV+5par55mTic+8pg5ZJp5"
        @"LBHXNJmwwUl1UFYk4qCzAYyxhMQVWYlUQYPberXj3n6P/8fiEq/ubKPAVn+A8zW3HjigC61iSZz+Xb5KWq+vegA90rIfMMJfumnfctjXaTOaTB"
        @"iXE97YGfG93/1O7rr9BMMXvoBP3XMAk1l87Ql+JqGYpiDindGU5KoB7wMhKMF7PXygqztbfXpl83Rn1xMKtYtSjkgOGVwdEkmU+J2q4vXVh+nc"
        @"/nbKyhH+zF/gYgqCSQj4xPtIExw6a2P4FEt1ogKmYFojb9R8rgOKoBywhjN1TciyyAdppADcXMnsReiPxny3FW7FcHkwIATYGo5Yauec2r8WEP"
        @"nooy37vq+7ALoNWkH1p1c6rdaplWU1COPxmO1hycm7DvIdH3sX9UtPUI5LRhPXJJOYdRBc5dB5DKGzIJti4gDB+5iBvLK20kbLkmujqO/REGKW"
        @"CSEGiG8E7/ErBx9SeyNeM5sDx+D2D9IfBzqhon3Po7xy9Ca8QtmQgunvrptrq7mamHFEIeEYad4/JSDT1ec9J43lSl0zsjEDeQWLTr9mHB/SGK"
        @"g7u/xQp8t6r08dApPKUTnPydUVVtpFhsp/9tWgab6qAbSYmb+cGXnnrWsrfiHPmYxHWtY128HxIz/0LcjGBdz2BlhLb1jP5WDFFgbn/JRHUU2i"
        @"r6kwTGcci0pTSkunU8hiIVxc72MyO009IeiUj6lKR0LT6n2Eud571DlenyzRuv0dVOMSS8AWbXoPv5fNdIXWU+QVg2Vazl8HmGN2Chrh2/z7my"
        @"rLhcAxI/Rrz5Yxc99LqvDm8FWtMHGeuycjPthu80avhyr0xhNameWmtdUgRr7p4VbrQ183AfTAAofE8DcOLnbY323jvMO5WtZ7Iz74wXu46/gK"
        @"wzMvoWLJM8NuryIEphWXzXJ8CKhG3obE/yiKkRkeij9ziW+q5LnlwEqL85d7SOqVNS0KRLA2Bqb3AbGCD4p6xbtANS45372DevEQPiSOqK4JD7"
        @"2XC+nKLDViHadKSPofP5dhNJX1ZcpCyAxwy1wA1SFw0Foy4Eqky2PWSvjHp69nG47JwHA05ruznHo0ZuJq9bVX55weXVrSlXbLWgk/9mY/469a"
        @"ANnK/set3N58fGUpWGulcpUMK4frWv7Cd7yb6szzaIg4xwKjUUVZxYwTki5nyt/oLANdFxDMspOoKj6oaNCDa12uXB1Qm3yarWL7KwadrwN17c"
        @"XYiMJjae3ZHgV6p99Dv4oVXZGZKBu56Q6uHj1FrTDSObUhUOtsFHpesVinxKh8OcEo0+ptQQNLIlwMATGRY/LpITUVXaS2IwCvg3JgMODDecHF"
        @"/kC8IsNJTWEMR5eXgoh84G3t7J1v+QC6t81JFf3Bfd22rrRaBPV477jaH/HRjz7KARnidjZjJSRgjVA7z06/xiZBl0lyVO/DFABPgXXDRqeI0u"
        @"mbEpznwGqLYW/I2CWgHVTVewhBNYBPGUe0Kd8VUeWNYYGcfhuuqjEiZDZWXEV7gdGDj7PRNFbnMoRHY/ssVvcJI+kU78wrwMIc2PYK4j2HjeGK"
        @"82hu52iBKflASLmt0vjwelXFtxlDGE+YBE/lPJX3cmCxSze3OfCX3/IBVHj7/e3MHDrSbQcjoq4qdVI5in0dPvpN91KeeymRxKmlaYTFbotLm+"
        @"OIcVLpbYxEgDylnRsWOuamWLrTSE1FxYhXZP9al3I0YWfoMdbiVaT2IXY1JBKJvvZoQEKq4Lx3nMtPYg/eTEZAxJBnNgL64Kkf+gbOpBasn7uK"
        @"UtYQp3HwJxWOahCq5mN01soAqBKP5H3gpBWuOUdpLczhJdWYhUIS3FZzLZO18YRvsJYrwyFeVUaupl1Y9i0soMq3P97pHHvLBtCjixwQw19c7b"
        @"To5jkavDjv5HJvzIc//DCrbhc3Hs866qqo87q6lHP52hgVG1/KGvmgWN7Oldk+mho015toCqe5K21poQDv2dgtp3yPd7MHGDXTmrJbrMT6w5Ly"
        @"9OM420LE0M6joQIorixpnbqDa8dOUanGFkUSllUgLt40GiJDrY1OOmqFdC5DzkaC4vUXOKRKFQIDa6f//pA+x6VL1yYRv0u/H1QVH8IwGo4IST"
        @"iHCocXF3xh7eEy1B97ywaQ1tl3WSun9nc7PssyCcFRO0WXCj707luZXHwdjGWKGCMoleWlgvWtIRPnp7R/ZJ3jJaCplR7SCDJBwRgJTQUVhTyo"
        @"Kp2OYV/XcHljAMZMuSKd6oh06q4RNRjK5YHgb30XwXtym7GQW/KkeAxeabUXmDz0ODvAQGMmCKkH5lIF6GPWEA9iE8z3U1wksweQ+l5BYSkoEp"
        @"RryJRd98w01TrHCVWA0fjribriDq/064oQlNIHVls5i60CF/iON4tYfFMD6H3QDhq+f6nIWMgyBCV4z9ZwwrvffSeH/C71aDRtIcS+VnzoC92C"
        @"uqy5NqhTqa6IRKwSwqwRFsvuGTPdDAhOyURVrDXsX2np5Ss9VAwSvPrg1PvICaFK8DrNDcaVXM2O4I/cSfDKQqugnQmtdoETixqoq4rq/vfwIu"
        @"A1fq5Lj7ee43emPI/O8E5IWaX5d5MqNwRaKB2Ua0Gn3f6gMiMqEpi2iXfSNEZU1zXfCGyNRqgG6qpGjLDa7ag18va3F8Xtb7kA6rXsu0V4cLXV"
        @"CrkRJHhFlQHKN7/7NPX6ZTCxiRkQJNnIhaBk1rDcybm0WcXRmiRwN5mJWSgFhnM6LY8jlYNYE4XysbkaH+7+lbZsbA4ofcxavvbiKwchckI+KK"
        @"IBrUv+5Hzg/F0fZ3ntICudNqsLRXypd1d4xyP3cNttt3Dw0EGW7n+c8Y//I569/2Eu6iy71A3vk7BKiAEiNmUonZNzzJfzIWYUPYiw5RwqJn1v"
        @"Oq3sNH09M/d5sdOv3OMDZjzBh6Dqg068ykqn0E5ulhzh29+MZ5y9qQhd+J5OnpulIveZMRh19EvH8dsOc/uaUJ0bIdbGGasmOadsgyr7V9ucvd"
        @"jjbbctx/oGMHmGr30yhGKqGBSdQ5uN1DRlFhHhwL4uvdfWGU4chUc0QJ2Y7RCU4Cqe33G8cOib6fzAD3P7rQ+QqSM3yqT2vH6toqwdeavFSrvD"
        @"qhhOGUv2tgcZfc+P8Nwf/DLn/rt/yL0vP8cC4GRGFDpmA4elCnnq3ktKP0aEKqEjRWW/wBXn8QlXGWJPrSEhbfpm89R/y9PnLnvP7WK4WFZyuN"
        @"PWEDydPKOd54xq/0Hgv37LBNA9sE+VDy0VOa0sdpgDcG1c8Wcfu5m8txkn49I1YxLxp86jNmahI/s7vPTsNapwMn4cCTzOIWRNcgyaK6xRECam"
        @"WROKXVluU1c1vYlyIFX8vnJRd1ON+ezoBLvf+pOcePzDdDKYTEquDmtGpU8GCEoInjpE+zvvAxIc3Txj3+oKJ7/9e9h5/MN89p//fe76V/8Np0"
        @"JsQTRZwsyqwznLvDmsmJSNqnAAeCUEfGamPLdXMInptjSkojKZ61c4lIcVni9LDnU6ErwnzyyL7Rbbo8mjj3Y5+sSIy2+JK6wo7DdlxhxfzK2P"
        @"EwsBH1TKIuNtt60w2e3FykliEIQQpg3EhiTct1zooDfS3bFLgDLhhmnpnsRZdUjBorNJVJdAcQNOOzmFwFZvMgXroOz2hvzv2bsofvR/5e4PfB"
        @"jjK15f7/PaZsmwBEyGzXLyPCfPC9p5i3ZRREAtwu54wmsXLvLaK6+SmZxDf+P/zSv/4Od5eXF5inscUdIREt3gYNpDkzlxf9NgXU0BNRGTgHOD"
        @"z7iugoMk7E9/Wqlyqw/kZYUSCD7e32vtIlgjh9TZR98yGEjgY+3MSCezGCMSNMiwdBw9tY8TLU9duylVG6bCrkbEHoNoaamF1cCVnRpjLY0pRi"
        @"T/oj2LmGiOMH0aqQ3gE6utQfGlo51bFgrD1a0hYg3WCP3dIZ9ovZ/lH/yXrBw5zvq1AWc3RkycUOQ5RZGT5xlZHoPIZBnGWjKTkWcZWZaTZRnG"
        @"ZAyGY147+wo7ly+x9u3/AS//w3/Fy8sroOCYb19IHO1p5B8KzehjjeBQWoBVZZhK9SbYpoF4HRDXmQpShBUN7CtrJt6n0SKlm1ltRaHae94SAX"
        @"QPLAr6jlZmMcaIlViS7k5qHrn7EMVkgIq5Tlrhw0zo1QRSq8hkdTHn/NV+Kr+1UaXinUclAmnvPGFaycUOfVOBNY3RLBPWFnM2t0ZIZqkmE/4g"
        @"fycHv/+fsLK4xPn1LS5sjzE2oygy8tyS54ZWHgnE+BaDxtgMa2IwibWINZgsBviFyxfZfON1Drzno7z8t/85Z4tWFMEnIKxzALuOQSEqEntcc7"
        @"qhrio7GgiSwHkjmdVZd9+nwKlTFmraHie8p1/XBBHxIcKDIs9Q5JG3RAC1suwuY+RU25qQGdHIEsNE4KFb1qgn42ng6BzYjdyymV5pIsqhtY5c"
        @"vLRLMDNlgiSFoq89WJJEI35OLMejMCw4PwXJRpTV5RZXNof4yZjfv3YQvutnWVxZ5tLmBluDklZe0ClyuoXlwILhocOGg10hs5BnkGeGLLPYlH"
        @"Uym2FtDCRjLCLx16sbV9k8f5a1D/w5nvn+v8U2UIfrM4mTWcCEORa76eSvomz6MMtUqZcmMmWk8ck+xqM0nZwauFlhWFYp4GIbqJMZRLj9MVi+"
        @"4QPI2PD23EheGKOG6IZR+8DSSpfTq426MExlo4SoPdaUNaaBFZSjh5ZY3+gxdIkYdD4C6gRkSdYtIfgEaxL/EzTKYENkZr3z7F9pUQ5Lnl8XNj"
        @"7wt9l34iYuXd1kvTcmz1u0ioJWYbhlTfj3bhEePwLL7Uj3GpvKqDQAaK3FGktmLWIMJr3F31uubV1ltHmZ9nf/KE+985uYNBlGNBGNSpXK+joR"
        @"kaqKS1fUPoSdkJq9c5iHqSANajTiH41YiNQuOUEcLKhDzOwKtPJMxchRn+enbnwMpPKuzBpyI4hE4DiuHYcOL9KthtTe4/xMOShACCS5RkjBEH"
        @"2a9+/rMOxP2BqmYEhEI6oxA4WY3erKTzmSBiA75+MrNSjOBZa7ObtbAz7dei+HHv8Ig90+V7b7arNMjbUUuWGhJTx6UOjk8PQ1le1SuWcN3nVE"
        @"ePyIcHpFyDKDsQaTPIZMkpeQhG+NXPbq+iXEK/0f+Ele6ywk2UeDYZrMEq+fkJBQA6SXgUHQKQ3QNF+9NkSlUKdrLWal+HOugDWgWzvc3IuxZa"
        @"1mIi0k3HlDB9CjkItwb2YMSJwBDSDDynHy2BJajeM35aJiMCSyL8xdY8E3wDqwtNAiQ9nYqWLLgwYo22nvCiPUlSe42MeKikRNzmM+OqPWjsWW"
        @"YZAvY7/pP0IIXNrcJICIGDFWFCM69vCHV5RPXIgP+yMnjbz3kMj9a8jDB0Q+etpw/36JBlUmBo8xFjExE5GyEGLwrqZ37SrLdz3KG9/8nXGqNX"
        @"E6TsBLc5U1waTTjNQCSg2MGmZbEvXQkJHp85qM5XTGfGcISz7gQphSBi0rao0hILfc0AEUOhwETmRp5jwTwYdAFZRTB7u4cbSba1KrpipEw6zs"
        @"9ikIvFPyzLC6kHF1YxArsSTcMlmScIiqtSYFShznaQYN6zqZL4iCqynCmH3v/XaWbnmAzWtbTKqaIrNqrNEAlC7QHwfO9JTDLeWRfdCySW6RjD"
        @"MxhptW4py9mb+6RNJSlvh7EcFYy6C/ix8PcR//S5y1GV4VQ6BKvaypLjpVkA6hRqcz9r30a5W68Y1Bg1OdAvGgcxlN4q/7faD0Hk0vYCMGI2DQ"
        @"m2/sAKqzEyrsy42EpmUoCN4aDi9b6ombddCDx9duOtPlE2hUhOBi09JaYXGxzcX1IViL+oAmvCOAppmZqB+LuCokYhHnGff6XL424lNXWvxO5x"
        @"s5/p0/jgmOnV4vZY9YIWoITCa1lC5wqCPcv0+mQd7ADwEIXs7skmbyzXSqVZKw30gTTJLGgzzjfo+lWx7k/A/+BC/eeisXNY7o+BDHg5zM+md+"
        @"rmzvALuJ46mJGdEncdk080gDyjUGj8b37VNl4nwyvhJUkNwaVOTEDc1Eq4RbDJJlYryN04CoCraVsZZ73EgxEtKMur3OxCB4H8Fqqpwa0ufwvi"
        @"7PXxlQh1m3QptqK8R3eq+EAJk1VIMhG9sTXqtW2LnpXdjHvxVueQy7dJxFmzEc7uJdTZbn6hXJfCCIjzNnqvjU2bQZ8amQrkmPfmFdeWk7jvs0"
        @"0tUQZ1uTaUOaEAlxfs0YQzkZsk8Psvwf/j0Wv//H2Hn2c6z/3v9G9qnfYe3cGxzRmHE0GT94jdXVCnBJ4WQiXBveqCay0g0msszMSiyKV2EV8C"
        @"7yY1ZREZHMGEAPNyLHGzKAjHDCRh9CchEVEOcD7U5GV0KssnyYsqfeh8hGq06NK5ugMNbgK8fBfR2Gr+4w9kKeCMeQmGjnfKyIRBn1elyuOrxQ"
        @"PMj4vR9h4YEPYJdP4IMQ6ppQOpZWhI3RsGlmSmxszgT21sCVYeC331Du229oWcUpujlWzg2Uq6O4UEX0y+w2UsaJdjEGjEWSH2JVVSwW0Ymj5x"
        @"bg3g/RevCbaf3VTYZPfoqXf/1/ofjU73Oo12dRNV1nsAhcYX4KhSmZmggPSoVBug4HqoyAEUofaAefSFkhQ9RGZnH1Aeg8DcMbMwOpHsmaijc1"
        @"/XwIdFo5eQKJZq6P5Z3H5NEDJQQkJDMD7z25xHHk1eUWrqrplcr+abYKcVw5BKrJmBd7Hc4c+RD2Pd+LOfkANuSUvsaNykRSGw4vWQ4sKs9UVZ"
        @"R1TKunxrE1unZYEc72DZfGSmaNWhuvG4NQWKFUxQQwXsF4rLUa1IqELKkim6I6ZkXnHMuF4/CBJV7drBnXnlA7nFml9a7vpPOe7yDfeIULv/EL"
        @"+F/4H7jjwnmMCIsKXpJGPBC1Ryg9YB3YBMoig4U2xVKbbHmBfLHF8uoiG5t9hq9cYiZhi1JhVRbyeDsOb9QMdEBSV90kxagPQTqFRUKYthoaTX"
        @"sIingjqkrtPdaYqakBSV23tNAil8BWr2J/N93pAfBRN/3Zxfcg3/sTrNx0D7sTyHzJau7pLOa0spxuLnQLw1oHLu3WjJ3QbudkWaEms5LZLFnf"
        @"KRpqjNRQObRWgii1BgxKHcAFxQeonVK7GCBBA+JD0m4byHLUeMQaCIHCZoyCcvN+w1onY1hZSheonFL6Ks7O33QH3R/9+8j3/QBP/ND3svyHn6"
        @"QE3lD4N9YwWFsgP7KP/UdXOXpslUcO72Nt3wJrK+24ZTFztKzBqqdYWGB9d8wP/vj/HF9ouRVVn3om0p606TC5UTGQsiIJzIVIi6iSBOk+OqE2"
        @"lZRoMwhI8voJU0FZI8dQoFUYFgvD5taIO5YLqDw+KLk4vjjYz8J/9DN4WzDZuEShkVkJ6tn1nsoFyrJmOHFMas+VnTJiBfXUVSW+cgRX4lyNK2"
        @"u8qwnO4xNQ10bBNSd/1WaeQmJmMyCxKrPTa0xMdPwwxtBqF3xmfYN/9wcjjGoK1Ij5BKIXUVBsq420u+zsO8S3fO97uOP4QeSzTxJw/I0f/hi2"
        @"Dshoh7rfI0z6VINN8lGgfr1iGBzDEFAMVVmhnQXaVrAiaiKmFI2torytrSLagd6Yco6OTiuJNLcuTHdLaErrSTw1nZNCZy4b0YrF41yswvLcsH"
        @"+5xfagouiu4Moap4Gi1eZYMeC//9mfxp16LBKGdRV7Y8FP58iiSUKcJyuMsry2FoPU1agG1RBENcQOvkaAryZFjYoYsfHFa2bxJGqT5ZAniKJB"
        @"COJTaRiu440nBtyklrIOiM1T6yNWb1mekbVaBFcj60+z8Orv8hdv3uG9bztNbhwL15Y4f2GL1pVzXHnljfi9pCrPB6XbyVNiSYI8jYvxbFDy5L"
        @"SvigQNafyRzKu2bmA9kCxMX6txOE68xsGUGBiCmGTObcAUdvqKDc5Hl4yGPdaAepj0xiwttjh/ZZezk8NsXBjS75fAhMHYse/pf8or8sss3Pce"
        @"lu99B2HlYMQedY16l3TT8clbw9SF1VVCcE4wkRUniyy4iKiqbwCrQkjleSOEVzCqEmv5+J8m86BTbCXpo21moa7U5DmStbCSSV4UtDo51dY621"
        @"/4XZYvfI4PHh3w/ofWWF1Z4trrF+gutFjstBgMKqpJiYpibEaDAsJU/zRbr6ChURBF2WJQxTb/NgGjWK+a37hlPGpn1El8AAJkzotoQI1QitAb"
        @"THAu0BsHdoeO8bhmOHDsjgODidKuA+0Ak0mg65VLpsIPhedeeZYWsJJntCrPwXHJ27Ium+NLfPZ3/iee+NS/YXDiNrI7HqZzywPI6lHIWwSv+L"
        @"pCQuRGxEa7F2/AV55Y4YY41iHNYNdMIRkLgiSET09MTCzzJQngp+EkM7FYrBDjzHy72yUrWuigx+jFz7H90h9zuPcyf/bmgne//ygH1k7GdoaR"
        @"iJ9sxGr9SR1Bf8KHEB08jIlZM8vMdIBRJFIZwbtY1RqmftgprIJSuxtakZhurEjoqaWVGc680eNf/HJJNwimDOhE6QZo18qCyTiS53SqmpYPtL"
        @"OMJZuReY/UgTIEfn5Y8ra1Nd4/rhiUE9BA6QKBQA4cB75Z4KFywlOvPcuZ155l01oGB44ip+6iOH0f2ZFbKZYPos6RtVqg8WqiiEyexBVQ2oj2"
        @"dU7sH7+xWInFcTIRMSimyUGKsRptoNWISATUWWYIdS0WYfTCZ/Fnn6C4+hLHiwEPnF7jsXffxOGDy6gKZemwuSEzaUK2VtpZzB51avM0L0xjwI"
        @"SZOD/4EHvzKeDr2mGSM781RhUkif8lkJuv1M6WNyOAxtPhgYAoihqQ3Yp3Xqs41MrJg2LTDz3TQIlSe6WVnN8rVSY6lTcTFA4Cu+WEnapi7KJY"
        @"qiHfVGIvSIDbBG4V2ABe9J7nr15g4+oFtj/3u+wuLLP/L/99zNoRMmMwWR4nJSRKvAKKuCBIZCmb6dbpfM1UlqqIqMZso2oktgoyE5pspcZkIp"
        @"nF2kyqqsJdfBnzu/+MOw5ZHrzvAA/dfhOHDiyhKLujQDtNvQYfszQS+bB2VmCtUNVhygYldwCslblckqS9EgG583E0Nvk04IPiYwRW3tTjGxkD"
        @"jRqgrJrGR5FYnoeanbGfrkTKo1KCSdpyk6f31yJI8sYRgUyEtaBcdrE0tt4nninNoWv0gs4ijYAKdAM8IvAIwkWUP1Y4P+yx+YXfYfmb/xJalx"
        @"SdbtOaTboaUPFqfdwmGCmH9MpXI2JiPpqOGRF1RiZZ+YpGosVmllanDUZwkwkheMrn/oCPPLjGY3cf4cDqAkUrp64cxgpViNmjZdIyu+bvULBG"
        @"ya2hmtSIqMY2TWqd+ChbibZ/IRoChDjmGvuANN2k5LelRpQJFYMbthcmKoOQOsNOVYwIuRFcZqjmVh6lLD0l7ixTemgqiJ8XnR8Q2A2BSsx1pI"
        @"EkdzCblHw2XZ8NV98S5SjwAPAOIDz5KerN84TJiNwa8iynsDbugLcGm2ViTS65ySUXK7kVMomqSosVG3lmchEKMeQiZBLXFliBPM/pLnYp8oxO"
        @"kVFPSobnnufg7ot8w0MnOXJgEed8M5kNEjQTZeTSMEAzm5ac0AWllVvKskbESmMypMwMQRXFZDHOY+DDsHSElIFUQ5T4xgw0XITRDRtAqmHHp0"
        @"7xdLkIQGbp6Zc1YFL9biW5koZZWvzyMcoDsUFGT67zTEqOdTqrQlIAFUx9wLEIOXBa4ObxkOGn/o0oSrm7xUKnFQPJGnJryW1GnmcUedQ7Z2Il"
        @"vl+wEiuaDBGLFStWbHysGIGilbO8skC7ldNutxjv9qgnI/znfpl33LLE/tUuLpBkKYkPAtpFzvbQRa1unImOoD6ZZ7XbOS7ZCvswdSxGLGrEEF"
        @"LbWgGX5p93xzGrZdIYSob0PHTrczdyAHmRS80UQe1DHNcByAwDaaQHM9sTSU0ebWxSNAYTUw/wWNUsikSdcGK4deYRjkZv8aTKiyefi9FCoC1C"
        @"G3iHQPfZP9LtL30SV1X40Q6LSwsUKUgyayjynLzIKFpxEiPLovIws5bcCJkx8WNNvJoza+h02ywtLdDOM7rtFqOdLcrJhOEXf5Pj9es8ds+xyH"
        @"ZPHcYFEQvBSmGEcemRLJ8y9CazkaQ0wlIno6rqiJEan8iohxaRiG+CisyPOO1OAiZBfgWqECQqFbjG9ZbVNxYGksBrIbUhah8F4FYgK3I2Rbhl"
        @"Tvx9vaspZGl+jqR3yWfsNhY4iLLhPafTbFgzdxU1ZddvELREHKUSv8lWwlq3ATcpPPeJ/4ny0DFG4WYkOBaX9zEaDPFTGzwhmIBaM521l2ZGSM"
        @"M0R+ZFRnehS1EUcWVmnrGztcVgMGL7+T9i9ZVP8I57D3HT0eX48K3B+IAYVOOyH2wGVV0zKB3dxMhnhcWY+HNcKLK0cSi+ArM8BlZImSpWi2ny"
        @"I706N/o13WRG4UMQH5Q6pqqLN7ak1ZgzXvFeg9TB40KE0i1rWTezkRTHvF/O9Ta5zInMVWP1EFQ5AlwJzbbl+EEmVUpN5pqSaqhmc4ZOLYQ6aW"
        @"weRjg6HtL/xf+G/qXX2N3cYrRxiZXVJRYWuuRZvMbyLArnizynleez9+c5RStnYWmB1bVVFhe6dFoFC+2CrfWrbF7bpvfql7B/8q+560ibx+89"
        @"Fq+jhmWPZlnR4yrEvJmLcmVrmDyQdGYoShTzly5gjUmbgGa5N/o+Nk1rxWt0Z7i0U9HOMwIqlffqVDWV8Wdu6AAyzp0n6I7TYJz3uKASgNwatq"
        @"2JVm9zoy1zk5qNb5Q206VMzSVjgB0gOsRPov2vxms/Mi/ND3Y+APPp36F008cqcKsotwPdnS02f+EfMzz3HOWk4trrZxGtWFpdot3txFmwPCcr"
        @"CvL01mq1WFxaZN++NdZWlum0Clp5hq9LLp4/z/ZgxPZzn6H4zM9xxz7lGx65iX1rHeraT9lqUibTpCEJHvYtFFzrVTNDheTVqD7QaWURAEfyMm"
        @"nI40/GyHR6Vb2POvBx6WV74MmyDBHRiffUQXE+EJTXbmhBWQbrCme96n6vaOmDtDJLYWCryOiXji6NDlgTFow/Aw9qZrKQqTlyM5e5BNjg6VvL"
        @"SoOjpkoemY0RM/MTTDPo2k7Kw6BKBtwvwg5KPuwx+KV/wvq7P8zy2/4Mk3MlnYU2y4cP0zm4nOQYHvVx3UFmo0+QNfGKHI3GrF/eYHc4oi5H9D"
        @"73ayy++klOrBgev+c499y0Slm6xCKHSCjP2mUpgAIr3ZynXt9F7UGUGhecFtbiFWm3MyalpgGE69UMzZxc8Coh7VrYHjmqWihakYaofKD2QWoN"
        @"NYSXbugAegLqB1Wf9MrbQBjVntV2pqJBQivnUn/CAZqxlOl100wdSCu6eWmNSnShmDYUNAdZU2VDYBkk+Uph0mRDYz4w28ucAlAQq5FPCmntwD"
        @"LKYwifF+Wqc+x+6le5/PKTrL73o5jbH+LquYsYo3SWFmktLpJ3F1lcXGQyHrHV7zPY3aUcDKmDEoKj/8oXcV/8dU74Kxw40OI99x3jkTsOTxew"
        @"BBcIVmaB09jZJFC80C0YDidMgmJFIxuOQQzayo3IpI6cT9plHwI4HzdNm1SBaYj9xfM7FaIZmRFcCJTO40Mwweu5sePVGzqAiMLuP/TKX1GBSe"
        @"1UtY1BdLFVyBkr3Nvc2UwnMTXMfDmumwMPU+/5+OeHVNkMgVPGYkNotlrMfJRTFpK5O9qj5BroiJ26XeTAAvAuhC8KnFOlc/kNhr/4T7h06jba"
        @"j3wTS3c9Rr21pWxvIcWC3Hz/fbzy6jmGO1uxMVvkVK89gT73SVZ6Z9jfFfatLfD+B49z78376E0CeZ4jJu4gsxqZq+YlE/VQ8R9UtKKqcntYcT"
        @"BHvMYgsiaae5qmOmvwHzGAMisgQTWINGakZ6/VLLfacQNRgNpHZQLw8qtRp39jB5CV8HkXZOxCaNdIqL3SzmCplbFeZPTHNd2EV6LpkoqdBUDS"
        @"MSYWmOlqDAA9CHIpBIaZZbGOElmJHxpBdJpgsBLHWzJmxpbdNDdl5/a7d1DeibAqwkvpeqvPvcr2+TN0T99HZ/8hEe8Vm6sNKr6qKdodbF5Qbl"
        @"+l/Zn/L8e7jmw55/SRJd7/0AmOHlygrgOVb2QWor5UicpkENHpEK76yOsIyko358q1IYePdaidx9dBJItkYJ4mcI2d6ZPSshg1xogm84ayCryx"
        @"7TjcKlCU0vkkgvOI8oWvOOZ9MwJopeLloPqM0yBoYFBWeBXJRPCdFhfnMkUE1HJ95dW8qVDrbFGJB1kSKDRqfusUhHUzbJdEam46zRnbDFXycS"
        @"6Ic1UmlfbN/p428BjwAYEjxJmstRCQy6+QdZcwRYesaNPKbSzDbYZptRm/8RwrueOum/bx0Xed5uPvuYXDqx1c5RGE2oWpe1lQjU5jRjTMw/9k"
        @"zxGcZ22pxZXNATaLG3sSjsZatFUYRVRj1dX06MA5jcRi+nsu7lS4MiO3Ubw0ck5cCFI6r4r5zFsigD4FTr38tgsBj9Cv3LR8WF5o83ImeFWqNF"
        @"nQlPTzQRX7xjp1QG0CKwNWVBkEZdzsxyAN3gnXuaZG1eOMIsiZyoKQFCgmvVUoxxQ+KPANErv7wxe+CHkL02qJtAoxtiH3bKyK3niKjzx2jO/6"
        @"0N3cfmIV1ei8IXbG04RUQwpefePvqIqK6vzmQg3KgZUu17aGaGZ16qafrF/ylHmMNdNpFA1pujdN+BICL10Zs5h38MHjvGdc19TBmzroZu39k2"
        @"+JAEpCvt+sg1ZeVUrnKZMKcbHIuNou2CGN506DKAnJuN5X0CUh/pTpBpaTk+m1uZHiZtRXkpbE6byRk+AlLrw1ieIWIJ9rtTS7LFoCp4DHgaUz"
        @"z0M1Im+3kSzHp+vSWAujPieri9x30xrBB+rU35rOsKdSq5quqbLT3WREtIKGZv94HJJcXMjZ6U8YuXjXRes/BTXSaeXScJmq8w2hkAywAqOJ47"
        @"X1itVOC1RxPujEeXXeY9AnXoxDHm+NABo596QGfcqpNy4gu+MKq4YCtFjq8HJqCJbJYcKhaXmbXOdYMW9M2WSSZZRMlS0FLyY+WGZTmqZZNyBE"
        @"FR86Xcc9j4myVMEJM/zUeDN3gDt7W9QXX0Na7agqbH5orRb15Ve5a7mi3W5Rh9mwTeNVHbGgUtYhyVetNDP/aSJIZjKM6K+x0M4JzrPdr5GEaR"
        @"r3Eps4IE2j2o2haFRvRi35hZ2Ssu7EVpCKDqua2jsmzhFUPsGcs/ENH0CvxuHLf10FjwoMJlWzQIeVdotXWzmlQrOFKfoBajQEmGX2WG3M4yKJ"
        @"jdI4qRkYGhu1QHNB1EyFuKkhpUzd4IkDgSrTaix2vO1cHy122+EoMH7+c9hWh6woyGy0dhGb4V9/klsPd6cG6dMV4XP+1FbQUakgVhrz0KmJVl"
        @"DExn+0c0rwKnlmyDPD+vYEESshXVHTiEtX3RyATtgnyne/eGHCWncJHwJeYbuc4HwwtQvDYMIn3ozn/Ka6tE5c+MXSh6seL3UI7E6iZW/bGvxS"
        @"l5dTQVulAblmnVcTMP8Hq9wGKCf84jSwZaKconlRT1cD6JzzaWPUjWLTldjgoKKpHFWnJb5JX2M/0H7+C6iryPI8aritwY2GdK+9yOljq9H8Kc"
        @"wvoUqDAh6sMTKeuLSWKn6zwSMa5mj2xAlFoX5gsZNzdWsYsU7ypE5NUDJrZhiq8RRQJXjH5m7JpW3DYmHxqox9LZPaMa6dBNXPP1fx0lsugF6C"
        @"S8Hzi6V3ElTZLisUgwE9tNTl2VbGQGfWbtWcsMszb2si6q/vlekSilHlqhii60Tj2jVjhuq53tq8c0WzIFOQqYDbzDTc0/5aDhy/eJbxldexrX"
        @"YMFptTbV7g1laP5aUOPqQth00/b2oaoRSZYTSuUJ+YH21+SUEWjDT7zgJRu3xgtcv6tcGUofbBTc0nRDSRiHEgM3rhxwD+4vkBC8Uyqh4jwm5Z"
        @"4pPBQkB+ia/QKPNXNYAAvNV/PnGhXxNM5QK90hMw0rYGs7bEM9O+mFCmDKJf1itzIG5mBKyeWMovKGyFgBOLSyx/oDEEvt4BzMwRjLapxubmLh"
        @"p6T+awlxE47Grc839C3lmgrAKSFZiLz/HQsSKtHA/Jnq/BQBpHhQTNrGU4ruK/ITRiVJmuEp9WYHM/r/0rLXZ3R9QhmhUHbaw5m6svTEe741Cj"
        @"sDMoefaKcrDbIXiP00CvnGgVnHE+XHEu/Mqb9Xzf9AB6vuL5EPR/K70Tj8rmeAKIhhA4tNjl1YU220l2UTHbKTqrxmLPrJ5lJXEgOUJblV0fF5"
        @"M0vE+Y4iC5zpBy5kEYX8Xe2FkvSWbbBANzq1eBY0D2J39A5QK2yMmN0rn8FLccWcFNDR40zWtFtscHT/QAFbxzMcDS5sVpEMT1dBoa/YXGce61"
        @"pRajccWonurA0rDlbNBSNTLUYgx17XjijRELxT7wtSro1mSMc4FR5SSo/tpLcOktG0CxpNd/PPF+4tRTOS/bk1pELIXAyv4VnjRCldy4JnPguT"
        @"FdUmZeOvPVWVuEWgM7CVI0AeK/7NoKX6Y/QqE2Fk9igafgd0ZaNmK2BeDAa89Rr58l7y4xWL/CyXCFpcWFtFE57RcLU35nBpJjicSkcpEGkybQ"
        @"Ypsi+LhFpvGgDt6z2ClwztOf+FnAzdkSN/9pJnh3BhOevKwcWugyriu8KrujMWPnZOJ8Cfov3sxn+1UJoGdqnlCv/8vEOxNQ3RmXkSNW2N9psb"
        @"m2zCvpYVdzppJ+7nFOl5jMBUJXIFPlMnG7sZ+Tcui0QSuJzIvvaED1WEDTyEIjxNcvq3IlVYen64rh7/0bXKtL79lP8eDxFibP0lUVvT1CaoxO"
        @"N1EFDwn8DiZ+ltVS8GhqlqrKdL+HBqXbshQWtvtlnOdSjb0uCTrNQqkFX1eOP3ytz77OIdRVWCPsjMdMnNexc0aV33nW8cRbPoAiING/X9V+vQ"
        @"rO1D7oxmiCYHDec3T/Ks+1C/oaF5bUM+wTr5TGRAm5TohmFBYUrmogpHJer9cYzRbPJQDdtE0mIeCmzq/SgKLp0qDmcyvgkAgr//bn+cyPfISD"
        @"L/4WD9x+jNoFQhBRRxzwMSludDYdqqKaW2E4rqdzcs4jPkShciNNbTRCIe2677Qsmzsjgor45LrmvUrDTDcGoheujXh1q8WRxTajuqYOKruTCc"
        @"57KWtXecx/9WZwP1+TAHoaznrlZ0dVLbUGdkZjHddeDUIhsHzkEE+biFtGDW/TEIw693tmJtsGWBG4GgI6tyJyDtJe11uzqNaNpDZ4xknw4a/z"
        @"gp+33tVpMD5alTz+pc9wajFjeW0pKgYTNomtBJFm5ERT1z0EkXZhGYxdNIjSoNEHcn67fJrdT7Yw1sBCO2f92iCqMb1KcFHvPHW1RRkNJ/zuKw"
        @"OOrRxhMB5gBXYmYyrvZVhVxgf91Rec+/Sb/Vy/qlubxYV/Wjv97KguLQobwzFeYxba3ynYOriPV5PXsUsguGlxhISPmoqtqUwWgIH3VNPVSFz3"
        @"cObXUUbJiKgHzVXZbczOdcpRTjsRM99zTQEmHAA6KUBEZlBbk9BLgwjBSAgi0aRBabcyhpMI612NNBWYJuuamGFmLm2osrLUZjf5Gs0w0Fxbpv"
        @"Y8eb7P2O1ntYDKOSbeszOZMKqdjGs/9pL9g6/GM/2qBtDTMETCj01qPxgHZya1k63JBGsttas5cWAfzywvclWV8dw11lxDPgWEY9YRWkBwGthO"
        @"bmCNCXeSSSeWO1Zv6f3iEHKFXQ2EWMGJb3SxsyHU6e+bkj4ujNNmuUXTeGPWkpihp4afKTJhMKpjWyI0JUHaBpIqr8ZgVCRuBjuw3GEwrChdmA"
        @"VW4o58UC5sjvj0OeHW/fvpjUZYY7k2HFG6wLCqJKA//0Jdf+nrLoAAnnb8iVP+y2FdiSOwMyoZVpGhCXXJiWOHeardopcyUU2zsmDWVa9TMAWE"
        @"VtILbSRruTAXNEwZ6Hm7GajSvsM6OCYmm25c9rMhZubi57rfa9q/Md0u1BhxqszttG9WTil5ZhlOXMpoXhuxfGOG3mSjeJUZCd6zslAwKT3jKk"
        @"7gTtsfCju7Y377xQGnD93MeDwAha3xhN1JybCszLj2Z02tP/XVep5f9QACWHThZ2of/mBQ18aHwJXdYRI9BXIcized4I+tZVc1ubvPuCE3w0bi"
        @"kx1uG7imATUmubgLfjqfoYlLki8D1kIrKNsyJwmZYp8mGOS6npxA3JjownWZatpWSJVYmOt35dZQ1Q4XBB8Q71wDiGUaRAhiVDGq3nsWOjnOB3"
        @"bHbhrSKpHV/tRL23h7jCUbKF1FrYH1wZBx7RiUJQo/+XR0wPv6DaDPwlhFf2hUuSsDV5naeTaGY6zJqJxnOVOxp07whAgjnV5Zs/JeZ4FkidLU"
        @"jRAIYlO1Nr8eSab6a53inNhRWEBZ1zDNXF++PknnZPtN89WllZvN4t8mm0xDLDU5g49istwa8IHa+yQSSwYKzQJeDdMdrrHa8trK43617UGVbB"
        @"SEsqx59o1dXt1d5ba1Za7t7oAYLvcGTGrPoCxNHfR/fbYO//qr+Sy/JgEE8EzFS6rhBwdVVU3UyaCs2BxPMCZnVNV6dLGNO32TPE2cw52Ri4IX"
        @"uW4FQBfYDh6X+kpev2yByRRLzUKiBukmfTVpk3OYq/J0rq2ic+QlLoLeOJs22x4921gfoXwgXXUm8k610yngZm6dQ9rVoN55CTVS10FyC0Vh2O"
        @"5XGCOUlefVy7t8+pzlweMn2dzeVEVYHwzplaUO6tIMa3dm4vTH3qye1w0XQADPeH7Vef0Hu2UpZQhcG07YrWsymzGajDm+tszWqRPy1HS1EXM4"
        @"aAaoO0AVAqXMidKUuZJ/tl8imdDhgZYI4+CpbDZ3jWmiEPQ6TknTdRmdX+a64una8smaeNr9TdjGmmi6MC5n5UCzPC/up4/TJ7E6j+OG7cKy2M"
        @"nZ2p0QnOfiZp/feMlx59Hb2dzewCvSryquDccM61oGVe1R8xOvwoWv9jP8mgYQwMHAT1e1/sL2eGQq73W9P2ToPEYs271dvWn/qm7edIIvKUkC"
        @"O3eVJWJxQWI3fze5xKtcL5OVuc9psst0YlUDuwlIT/9cZ9luHjNZABdw3tF00ae8z7SlEdK6KiXQcDuaAoi5ACJdX9EAs1nC60O8ZVe7BbuDiu"
        @"3ehE+8VHL7kbsZD7aZVDVjH7jciyvRB2VpfAj/1XPe/9uvxfP7mgfQp8C1VX+ocuEzu9XYOuf1cm+QgkgY9PvcevgAGzffxOc1zrdrAtZNUCyk"
        @"jLOVWhrzWqCGU0rXmMzakTFOFlW5omG6ITlMO/Vzch1my2/r0lM5H9sMc+W79zqdUW/qv7i+CrLMMCkdRuarOpmjO2d4SlWREDi8XDAcVfzi00"
        @"OOH7wbWw8Zjsc4VS7u9ph4p73JxJS1/42y1r/3tXp+X/MAAngCdn3B94wr/9xONbGV81zqDZh4RcWwub3F6QOr1LfdwhNER3anM46oEcdfDj5i"
        @"E4lzzw3D7ObK+XD9my4AF71DxHxZlppWWcknKwWVC7hANMxCY/Uk0bJX5xjtJjxCCOR5xqSeIaqG/2H+mmyWyBjDeFJijHJmkHH80D1Qjdge9F"
        @"ERLvX6jKuK3nhsJ1X9pC/0P3z1K+XZ+1YNIIAXJpyzRr9rWNXndsqJcd5zpT+k9AErRq/t7nB8dQl7z118LpX49ZzzfQfY9h5JFVUjBWGuhJ9f"
        @"aNIE1JIIwxDwaWBP57BT83HZHDtkXPRmJM13oQErXoMGRCI52IzxaIhi91YmjCf1TI6a2hJTLVAq/Y0RRpOa1y71+OPzQf7M296JrUZs9Xt4hU"
        @"u9HoOy1F5ZmlFZv4HRP//iV3gL81s2gACeqnlORP/9YVVf3CknpnaeS70+Qx/EmoxrvR3W2hlHHnlI/qTb4arOXnr7gZEGxnPXV9M7A64jFMMc"
        @"WO4CEw0Mk/PFvA5JmVVmjcmD1IHhuE6BkAC5F4lluJmuatBp4zOQZ4bRxNHMbzXkUqNpbiiC/rDkxQs7/NZrwt03P0Q16nOtv4sHLvf79MtS+2"
        @"Vlh2V9TbDf/cybJFN9ywZQI/2whD87KKs3tsuRcSFwpT+gX9cYsez2+5h6rHc+9ABPH9jP06qUqhwS6KsySPPvYS4I5onCpvz3UaMuFjAhsJlM"
        @"CxKY1jALnsb8LEo/fGA4qZN7iCEkqWQIIclMPRpiBx2Jt1+nlVFWLk5PpJYEyc6uaZH0+hM+8+Imn7+6wrvueJjRzobuDPrUChd3dhmUJb2ytP"
        @"1JdS0E+a6nnPvMjfC8brgAAnjK8Tkv+rHBpD6zNRqa2jmu7PbZLisya+kNh+zubPHA3XfQu/1W/sQaKoVxUK4lw80G4/g5HVCYAWppqi5NWehK"
        @"CFN7mJipmqljuY4LskB/7KKPc1N5JebZh2Zfa/rVx6nGIoFo72d77UnuY6OR48rGgN96sc9Fd5oHTtzK+UvnGMTOOhd2egyrSndGE9MfV1c1yJ"
        @"97xvvf+/+np/2VfFaWG/RsBK4cUH7Tqb6z1nAiN1YntcMDS0WBD8rOYMDJ/ftonzzB0/0B25MJh1FWZxMS0szaT3th8ZtuFoQjINeAa0a4XYQy"
        @"CdXD9YEjjfS1p2BOrnDnzWuMh+Ppegaflq004LoRfyXukXNXhtx8qAPEbYfeB3Z3Rzx5bod/dz7j5JH7OdTOOX/1EgrsliXnd3qMasfueGL7ZX"
        @"3OYz7+rPefuZGe0w0bQAAbsHVI+TWP3lEFd1dmLLULOvJOOnlOYTN2R0PwjttPn6ZY6HJhe4euD9O9ogbBphbFPKPsZzIRKRHeEOE2Y6m8R2Vm"
        @"8ND0wZsM1gfGhxZ44Jb9lOMyric3EmUZqmlVw4xg1LRo98zlPnceWyAo9EYV59YH/P5rE7blFA/ddDuD7XU2tq+BCBvDEZd3BzqunfTHYzOq3F"
        @"PBhI8/V4enbrRndEMHEMA6DPcH/m3wmo+8e1wMVlR0UFWIEbpZRl07dgcDTqwuc/z0aV4xhvP9PjbMZBAziSvRHjxKOEjj85xR5aRYRH0TZJI2"
        @"nkkDugPCGNhdbvHoXQcoJ3F0Jmag2JowwnUstWjcIHjuco9jKzlXtgZ88syIM8OD3Hrsbtas4cLVC1S1o/LKhd0+26MJY1eb3nhiytr/aqvQP/"
        @"/khNdvxOdzwwdQykR+HX7vAPpS6f37PGHRitFJVVN6R6fIKTJLfzRiPB5z89EjrJ6+mXMiXBoOqHxSAEpjdtB84yrNtXYGZdUY2nPz7fpl3fuG"
        @"CljvZLz93sNUVUXwPs6hu8gDWWuQ5PHsfcDVjp3ehC++scvZXXh9fIibTj7A0e4C6+uX6A96aICtsuRyf8i4quiXpdmZTIIL4f9VOP3hL9RfWU"
        @"+fP3UBNA0k5blDgU+UGu6sgr/FSmRiBlVFEKVdFKgqu/0+oZxw6sghDt12K5uLC5wfT+iV5WxTcmKyJRmEnyFqpg9OiUC5DnXO98Uu5oZH7j0U"
        @"95MmY283HZxQqsox6I9Z3x7y3KUhX1w3yPItnD5+D4e6i2xeucjm1jUA+nXNlV6frdGEcVXL9nhkhpPqNQ36/c84/tvLX+Xm6Nd1AKUr7Wo38I"
        @"sZVJVzDzt8JxOjlXPaLysxxtDJc0II7PR6jIcjjqyucOr22+D4MTaLgitlyUZVT+fyxxrXR46AkwLjBiPJ9eL+ZifHqyI8ct9BOhIYjSYMhxPq"
        @"smI4HHP+2oBnL494dkO4WB+gu3Indxy/nf2Z5dKlC2xsXcOHuEBmfThkfTBkVNX0ytJsj8a+dOHncq//wVNvghnUm3GEt/B5MOdeVP6eMfJnu0"
        @"VhlooiZGI0y6ysdjosFwXZdI+EsLK4yNrqKpIXDF3N9s4uO+sb9Ld3Kccjaue5e65c78xdYdCMHcFzwMe+7TRdrbi4PWa3hLEW1HaRVnuVQ8v7"
        @"WSlauMmInZ1teoNhmhmDQV3Rm5T0JyVV9O8x/bKkqv1nA/pTz3t++630DN7SAdSc+ywfF+Qn88w8tJDndGIgkVvDUqvFcrtFJ4u25ZVzWGNZ7H"
        @"RYXFyku9Alb3fiCE81YWO3TzWZUFcl5aSc2u164hyZyXM6nTaLywtkRcFyZ4HldotcLL6q6Pd69Ho9esMBwXvyPKMKgX5VM6wqhmWlVe0ovbOD"
        @"qqSsw3M+8M+GIfzcOb5Sm0z3Auj/9nkUumPD9xgjP9rKzH3drKCdZWrFqLHxWltsFXTynJbNkv9TRDaZNeR5Tp7ltFpFNBZvt+K+jLwAY8isjW"
        @"s703778WjMaDRmUpZUVUVVV5S1i116Y6hDYOwcg6piVFVUzuN8MKWrGJQ1tQ9PK/yz2oX/+aXIDrwlz9dNADXnHljEmO/IRP+yycw729bm7Swj"
        @"t5laYzS3BmstrSyjm+d085zCmmjYPedN5HXOrkVnP6yZQijtiE/u+5X3abzGMaodtfO4EKi8M5VzlK5mUvuhD+GTEuRfEcKvf6V2t+8F0Jv0vd"
        @"2b8S5U/rwV+Yi1cnM7y2jZjNxarDGhcY63Epes5JklT0tVssZlOq5z0pC8Vf20ZRHf6qCU3lOn8RyngRCCqb1n4hyl8yOv+qQqvxlc+JUXIoT6"
        @"+vkh86fg3AP7jLXvgvCtAu+01tzVyuxCbg3WxN2JNm5RVhvdxjQ53Ke+p0zXC6jolCRSgtRJPO9CDCLntdIQLnjVL4Wgv28sn36m5jlu8HJ8L4"
        @"D+L573QbYFt5rcPKjo20DuE+U0wn4RWbIibZPWZTerpqCZVG0M0hUfmISgu0HDBvBGUF4UI1/yhOdCzatvZVyzF0D/N887obMDqwoHjOWQgVVV"
        @"lhTaFhZCVND2LVRBbN/gd9Ww4Ws2Ktj+WioC987e2Tt7Z+/snb2zd/bO3tk7e2fv7J29s3f2zt7ZO3tn7+ydvbN39s7e2Tt7Z+/snb2zd/bO3t"
        @"k7e+crdf5/F/EFZTqtyOoAAAAASUVORK5CYII=") : (NSString *)(
        @"iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAEAAElEQVR42uz9eZRk133fCX7u8tbYMiOXylqyNlRhqwJAoAiBACRKhCSacNsesu2W"
        @"2ONpU+3xocfyEbt72pwzM6Z6zhnztGyrRz1NaSSTbrlFtWxBskRSMheJEkESxA4U1qoCCpW1ZlXlErnE/ra7zB+RBYKy3N4bgoR7zsuMqoh8L+LF"
        @"vb/7W77f708sHD7Gu+NtGsJhvQfjqanWokc2u264LEP6SRwv5sP+ciQdHoEVIQ6B8iC9RNog8gIQReGlBS9vnPRfc1H/5rUn/5T/Xu/fCQc4pNff"
        @"cz7h1VteuHMt4b/7GIcX4IXCeoOUEuccVeWbjaBZBKWa986sl0FZVEGBFSC8pp41jyBcL4v6HSurprJRX/77fIY/4+PdO/c2jzAMCQJFWY2WjS1O"
        @"15P6ovCS0WDQUxLwCuE1eIH0oLxFYPHCF5PjT+o0cn/EWPg/5m8kzoGWEd4LlFJMTTXn82pYOFEuoz1eADvGRXpAmGVwfbwEr/rvzqB/v6Hq0/Pv"
        @"3oW3zQPwjLOsqbUoGvXwRG/Y1VIlPYG0mnwc6xBnA/ARQngUBu0rBBajBE54EA6Bf8vOL/6Nr/1v9fo//iSIN3/yvecTYnIN4f/IJcT3HNpHmMpR"
        @"mSoyVVWzNh+FIUVph8dEqFYqFI4AITzag3ZYJ7BGgRMa6QXi3Zn0rgF4pxqAei2hKrO2ceW60kGnqNxYSWFD6anyvClFWiBEhHBWeof2ponwkZGy"
        @"sBKkdzsL4O0wAH/czi7+FY//uD9VeCNIouRIkqTzSH9VKoN35XuEcm0r2HKEhRcKhUN5j/ACL8BKgRce6XnXALwbArxj1z/ZsD8fR0HHOlF4pWlM"
        @"JYtlNYq00FGk077EAba44VILL4vJAzM5/tgY3/9b/P+/5/Dye48/ck0nbhzsHAInxJvGIdbB3KjXj4bD4WmHxxofCSFyrfWylLIPDoFB+EnOwAiN"
        @"FRpwKG/fnUTvGoB38nAEAl594QUPoLSgO9jKVUBRlrZwlQVRIUQFeLyQWKEKvOrj5b+8+f6Jsm7uu4nG/42pZ0zZqTeTJbQjDMPIVXZe+WBJWLVe"
        @"jLMPSCwSO8kXoLBSYqVDYFHeIXHvTqN3DcA71wOIdJDbouTsq6/k2WD7Q3EcdnQUg9SESTwnRNZEZk0rwQiFEQFWhCinUU4i/9id9607/r9i5/9X"
        @"/t2/7WcQCC++190XjkltgJ2f7l+6tkPiBThlKXxRWGnpj/rzU0m7RyaLk0+c7DWj+jcVFQIDPsD7ECMdVlaTxe/dn2wj+K4BeHf8626/Mb7TqKd0"
        @"rp1mtu5jX1VRVTqsCqJRVXSsdC0vXGun2IaV4JksOuXUn5Ap9G9agvyj/g8QCUbl8Egcx82a1su+6BXnXjnplfX40iP8JPs/KfWJyAuDF5OFr9y7"
        @"0/ddA/AOHl5IdFCfu/nIoY8wvsipp3/3i4lxzVjWj+TORD6JMUIvV072lNJ4LGBRoUB4jTMCHDjnCMMQYwwei5AeIT3WVd91xf+1Lvl/oKBGTAzV"
        @"mxNMSoQQODe5tjcWiSNQAqkFmS9RSbRkhqafWN8MypWvrlx8lmYaImUY4SPwGoFBURXS+x0zI/HfY3zeHe8agHeaAQByYzrO5w/UxBYb55+mQf/j"
        @"ZL0lKennzs3lhrm0NtWq8gotwNh8bjzuH1FKRUlcO6a1RkpJWZYopXDOoZTCGEMYhv+75DH4Y+PwydQaj8dzcRzPCSEIpCKOI5w1mLIgy8dNJ2hq"
        @"LUkxTOn8k3/wpf/5wXJ0iTuO3/JQXlZ4FCBQ3qKdJXCTnd8LiZXvTt93DcA7eDgBlXQEIeyeVgyvvsDzX//VT9f8+t+rx0GzLPzxOJ4q+r1sPQ4j"
        @"NFBLwk4YyB7SF/3hYLk0Fd5P8ABKC4IgwFpLFEXkef7vkJz7d0hkiLfmGsT3TK9mc6qzsbE1n8ZhNM6GTWtKlIBaGs0lge5rRL/sb/+1Jtsff+HZ"
        @"L39q/coz7Nml8bI8ruOosDvVA+UN2rlIu0noY1EYIXg3BfDvN/S7t+DtHSKUmDx7yA671NyA60t/wGy89akrg+BcM1n4VWUtyoPwnrLK0c7MGWP2"
        @"a2k7aS3se+FwzlJWOUophBB476mqiiRJMMa8HZ/qTR/HWksaxaezLKOWxIWtDN5Wc+NhgZDuSCJFUUvK48l4+5PLJ79AGhgajRaFq46Y0OMwKDcx"
        @"JsLLSDkKt5O/dEIicEj/rhl41wN4Z/oAGFcQhvpKOTYEoqQmL/HlX/+/MxesfT7JV/8ao84DrSScK/IRKojQQdoJo/RkXozwGIoix3tPHMc45wiC"
        @"AKXUBF5c5v8bLvp/7BBgYghsaQiCgCgI8dYRKNAK4kj3Y1kej4fXHt8ltz/527/y1xHmdaKwgUgWIYhOokoQRRNhcD7CExUTj6PCCd7d/d81AH8K"
        @"vgDn8RaS2V1IYZiqD7jw2r/g2a//EtN+7fO7EveBvL9xfHq6dcR5GOUWZIyUYG1BFAcA5Hn+pvsfBAFZlh3R+m108HbKjFJqnLV46zBlvliV+bE4"
        @"1C1viyOB7X/83Gvf2P8rP/sTmN7LJMGIqZl93Hf/Bx8xqPW8yo9IXEt6sBKsoHCAFw6wO6HMu2bgXQPwTr75lUChl804Y6O/RZRU3LyoWXrh13jx"
        @"m7+IHF7/dCsU0WA0XCq8mCt9cKy0kiAIkMKTj7NICEGSJFRVBTjyfMzLL798Tin1b7hT/0dY/DtTSwiBd0zyFEC9XqeqisjZ8vjZ1599+Op3fhnZ"
        @"e46DN7VZvX6VtL2bbiFPehUsxUG8pGy0LLzGyYpKl1RKTJCAwiAo/vf7TO8agD/pwbTZ2RHeSjYBwb9cBnPie6NVwQSiaiW4GxTXNxNl6s1z3XjO"
        @"7Twn3pLM+54E2x93wFvgsJNz4SWBCnHGx7pew3oHSUpzpkZYXeWNZ/4pz339/8uZZ//51+p+/e+luuwkSp9WXkbegneCKEwLISRFVlJLUqrCEGlJ"
        @"1V+GbPXvCKrmjfsgHUgnkVa9+clvwHJvAHreeuf+6H0UmMn95Aak98Zu7Ca1eidQboLZ82IC3S2dRUYTz6SRRJEbr304LpdPXXnhi49cevqfUQxP"
        @"sXePBl9QS+qEtRlGpV6WUi+bsmqCxAqJE2AFODQ3qgIS2+St34mYvA/txJscgRv3+8b7e/Mz77z+u5/SvXl8b8LUvOVwfyTH8a4BePvXvRdUZR7p"
        @"wFOZ8RElo0iKuGlKO/lC/eS4sQO6nYl5Y9EGTqCcwDoYV9UxEYLQlsIUTa0DJNGcdwGFqXBYjHI7UFSHlpPJ5BE753OAQVDtHAYw33PdycKYHE44"
        @"LApEcA4PKogYDoD2XloNwVS4zPrpf0Jx/ldZevmRT115/su+6bK5IDMoNFLFVEZijSJUIa6oEE5Rk9UHosEZnv7aZ382lNlDzpko8C5qBMEDfmBP"
        @"hC5uRjpdLCqLkCHWB3ijCUUUaS/AeUDiRQByEkYoX6GFiZQ3WFPivMBJicGjw4DAClThmjWlj2ArZCAofDXnA0VhDUEQQdk/Xqs2P/36Y7/E5pN/"
        @"H3P5EdLZCn14L2Q55cigwimCqPkl4XShlOqXylApB16hXIh0KlJOojyoHe/fC4eXE75AaEUUGbkYWhEJJ3BS4PBETjYDI/AiitABpS2jQINyjlAI"
        @"MEVTSTuZLzjKoiAKNIKqKUSxKKiak+9T7Cwb8afCEMh3+uLXMiBJagVIgihaGmS9ppe+SJP6nNhByt2w7O6P0FKFFyilm2VZRiLQ1JqNflVZXGGa"
        @"Eapv8hJbVp04jk8kSYQMNB5JVfq5KAijYW94TL7p7oodAIzEI3aOG7dY7mSxv3vL33wrzqA1UA5BGErnIQ6YPboAcgPl3qB/5fdZfeZXKJYfZcqe"
        @"f34q7P24qYZz1jviOD4i8Ug14Q1oVTWr0crfY/A6xfpzRPnKF6dCczzPtj81GPWK5nQ7MoioNNVyEASYsiLSqhmEKvJUhbUV1jtqjcYHKmsYDPNj"
        @"UZTOmUqAlYWUkigKiKKAsrJzBhUN8wIZRk2ldVGW5VIc6igfbZ1Ig6II7cYHGm7t7zSq81899/wjX/zqr/23LL/4CKb3NIt7KhpzMUy32F5bQyIg"
        @"qSGFbhbj7JgzZu6G3oH0EulEJPA7xCiB8LI/gRVrrJigJIWXkfBEXvjCS4vDg5RY5/pBEByp8qJwlaPZmJofDgcPKD88YbL1j7/60lO91159yU8A"
        @"S5JmqxWNsreWUeWffP7Fv8N455cBK4/HM7YGmSrSto7zcbdf2UaHShCG8l+KE4UX3FCRyY3vB2kjGrkycqMiD70mFmG/GSU/nmXZo0bYTpUPTo7d"
        @"aM4rWTQbc4vjYnTaVJ6pqenlorI7a3qCb3d/pMYudyaM8kzq5f577a4TRSRF9pAtumBHVN5BVIeao7HYhk4fO+6yeukPyLeWefJ3f3p/dPCHPr94"
        @"z4c/Xcnkp23eX8KVkQurI5UbP1xPw1NLLzz+4JWnPkO5ucYLX/4lHvxP/tbzpjnzqSJIrlzrd1tRmBZaWLwtkd5TFVnf+eqICvRy3KhHo8GYcrj1"
        @"pJPMNdpTFBXzjlYRx9GJ/qDzTePHi2HKcqB1x+tojkjE28VwPY5VIYxG27KYS0VOvvLVc6889SBqG84/xtXH/t+Me+dptix6DopmQPPoEVjdBgyz"
        @"7Qb3HrsZx8E4icPTVimck0inkBPiT2Gl3Qk79CTJiMIiMULNeeE6Rsi+V6YodEmlPEpE5FmxqONkuTLlUk0D3tHrj5bTerQeVde/sfTq8w+efPUk"
        @"/8VP/NRx7xXGCUxRFSpM8K7qC0dfeMlEnUTueB3fDS3eNQBv4/DCUZW2WWtNYVXFONua10G4jnXU6o0Hyqr3JG/ZRRyKG5Z8QkYRGOELU5kjoZJL"
        @"rShdHG1uR3lmnsT72AcKP0le9cdZVmSD/ulQhGRZ0fSB70sxgeN6AZLvklwmhuYGhXfn8c4Tk18KhEVTHhd+9LAwW7TqDlt1YdSA2UPQc4QtjVBj"
        @"DgSCrf45lk/1iLqr1IOtT2UE55IoWS7LfF4IkL7/8diWR7ONFxhuneHQfIv1s7/PS9/5PEd+5GOfHpau1Wge+Nn+YLhYr4VLVZXPN5P6sjWeII7X"
        @"B9n4eDHuX1FR3PHek8ZJUWbZaZOZuSRM6I/H3/Ra0kib6+OywmOpKhNrrXPhfeFtQeQ9frz66+eWvvnR/vUX6bzya5SdMwTjczRll7k5Sc+XqJn9"
        @"NA8ehrRFPl7GmpIwNjx38nEO3PNjxypj5yE6qdA7SkgAFi/KiSfnQyQK4TRSgvCuADDKYPFFJScLVEtJPU2Xs6KIpPNFEqRzpsw6jbBsknc+e/Kp"
        @"33nw+ce/wi3v+XOURbaow5nTzgWIQDbLqugHPphc20uk500JtIk3+c53B+Q7e/F7vIa4EfUrU/R7W9tHY5WepJSFtRWjov/kBJ+2gxv3EmmjSLkg"
        @"mngFFiMdTjqSMFiKhSTvb61PNcLFONEPoMijNDlSWks2LookCFHVeDEOXLPRaLSQYSQAtZNnEDt5hht5B/k9OYgb71nimXDavYAgsHOvvPRtVi6/"
        @"jDabaDvC5xLiEyTN76OIZhkKQdBMmK5DS68g+y/w0h/+/0jLtc/7/NKjr7/46CMvf+vRR3ZLs3j6mV/j6qnfZjodkUwb5pI1zj/3m7z61BdoJ+Vx"
        @"mfdIFafzYtCMa0mvNBX9wegD/VHRStL6FS8hDFSUqICqP+rHwjLd0p0wyfuV7EcylnSLMbmt5uI4bkbeLUdl1UkrqFfFkVm//T9dPvnbH/WrX2H9"
        @"7D9mvP4Iunqchr5Gs1YidUF7YT9VejPM3AWZpdfdJIwU/UEPGjWiKFy2+MiLycLXDpQjkoCTtmnlDuJwx5Brb4hc0ZcUGF1QaIORuukImqYoGfS6"
        @"R9rNxpEoiiil71g7+EA6vtB74gv/40dPfuuLtJuKP/dDP/R54VRnNMzndBSdKKoSpHjz+/qu7qB7E/n41lzSux7A2zTGeUa91Yiy3rDZatZPKqUi"
        @"aavCiDIKdVw4B97ryRclxHd5a36S5RVSYGzVbEUpxaDXD6Rr5lV26tE//Pr67PwCh265Y399epqsGOOdIY708njUO4KyS3hNoHdq0QIQ9nssqrjx"
        @"4y07vxc7pkeAoiKyW58u19+gXauw44KwXsMbh6imoHUr2l7Fyx4mywlajrnZkI3ORa688Os899W/SxAvYDefJPUpz/z+L8ajU19ED18nmQkhkqR7"
        @"WrTXc9YvfoNTj//yw++966PrSWPmZ1czRzEIlsKg9bnZ+V2nhvmok5eWQGqyQf9YTTdOR0Lhy5K8chhRHQmTZMk6hSAsarHqDDdXPjSbhqdVNfpw"
        @"qux87Lp/54mvfD7uLX2Z7bVvMze1TSmuMbcrwfYKxqYk3X2Uvq0zd+B+EHMMN04xPRWjspBh7mEwJM+LozqufamoXDMUri+8QngZee8KvOy/qTrm"
        @"J4EX3iGsREpHJW8Ye4X09LWG2lR9qbe5MRcIv+gYP7y3Nf7Qlz779+gvP8F8q8Wh/UfpdUcPRPVdn2vEzbi0UFXF0TgOT7JTRXJCIv2NxW/wQv6p"
        @"yKO/ww2AIE7rjMdZ0ZhKizzPmrKAWAlOvfxUftcd9zyo1dSTlhCrHVY4hC4K5SG0HpxE4xHe9kf9zrF6lJwWOuxXxeD4D//FH3roC//8tx5ttaJ8"
        @"POrO1RrNotffXpRxfDqIwiUkCOEx7nuVbt8qUHGDrealfLNS4PluGVH70Ydff/brJ1Zf/jWqq6fZvZAjlESGAnwIzWnKPETFDezAUmz0qLkhMy2F"
        @"3T5FfnGTkWySDQsaUhPJHFtcZ76mcGEN6nPQnKNhrtIdP83Ga6/yzG/9F4TxLZ+MjnyQ2+784GcyUS1ubW0061Mz/eFwGNUi3Q8DdTryes4LVxCE"
        @"VLi+J1qyLqAYubl2Y/p4MVx9cjH1rVOnfv8KxQqoAebcE4yv/jrjzXPMpA5lLSquMbAF8WxKWp+lEE2acyegdidF/ypVNkTk24y6HVqtI6ACBME5"
        @"4zUqDvq+zHcMpy4cGk8AfmJ0J2VJj3QCQQQ+IvBuoiCM7iMMQpSMR8MTsU5OpqL/4221/tlHPvO3kb0/ZC6ts+V28f4f/s9ORcn8zw+NOFWJql+4"
        @"fF0p5qNQzZk864CEnVLkZPFPyof+T4Ej/aciCagQ5FXRd8ItxkmyXA77HwgwnH7hySfuPfH+95YyOuV8UEzq1h7Pd+v40nm8s1GcpKfLqorGxfh4"
        @"s5VeGY62Prr/8CKPP/qF9e9//wf+ZjaoTmkdnpJBRIXFmRIpJ1UBJyTyRo18B/DibxBVvHxLvOh2hD1tU4jyeOo7n+2ce5TRtedZnAkReoSINWOT"
        @"k1oLpCQzRxgPhnhToKcTyAuEL9g1oynydYpqi0hZlBmCyWk2NUwtMEx2wdRxCA+g3S7a3RF2dB23vUa3uIQcCJ7/1u9/oqof+cTdD/651ijPikgG"
        @"hfIarMXYvCOkxxpH6e0cQdoJpUDLqkP/YrQ77H715Ld/46GrT/4jFpol48FVOtdfZb5tmGplRGEdEYb4tMYY0DPTZKKNjo9D+xhQ4e2AUJc4O2C6"
        @"XWej16dmLUroZUdAUdnFRLDspMH6oHgr/VfuJFU9Diskwu1oBliJEDfwSA5j8mNpaOdaov/xV5776mcvPPO/UG6e5OChhOXLGxy45wQbo+gkOnzU"
        @"CdkXONIkjJxguRgN0Wri2XmhdkqjNxa8QyDf8XX0d3gZEAKvIo2mrMyiSiIKbxFard93970P99eu8txjv/58TVz7dVlufljZCiUU1nosFqV8ZMti"
        @"TqIK5zVWhoWuJyf7RVUI1f75u4+d+FjeO82ZZ3/rs4kYPxyroD8oLLlX6CBBCIEVAiEVlfV4JgJWxgtQCcZrMi+bVmocFlcNTyRi+OGa73y2Xlx9"
        @"4tmv/KP54tq32FPfRMscGaeYMIZ6ndwPAYlUNxFFdxBEe5FpG+IpqLUhTggbMUmsqNcUYVPAFHTrhkGjRrTvfkjuh+B+2Pswrf0/QvvgvbQW5wno"
        @"kg+WCV3Be+9+YH82AuEEWipc6XHOEybyiGXw4ZfPPullWJwQvkBXveaMvv7Zs9/5ha89+4VPPDR4/RdQ/a+yvfq7+OoFdu3OULUhogWu7vEpuNgT"
        @"TzWwcYugdZSg8SDIW4FNyvxVXLFKGjmybBvnC5AWX+UP4DVCxrkPAirhoooKr8F6cHYHsCQ8lRaY0GH1CKkKtJRNKkfoHJEXBFr2tet+8pXnf+Oz"
        @"y9/+Rcz2K9x8yz66KwNkuJ97H/rxvIjmf6KQwZIVDiEslHlfVJZQqjcXyA4UGYd+U+9A+nc+CvEdbwCEt0UgFUrodWtZz7LyWJQ0lyoXLP2lv/QX"
        @"Pn3h/LN88+u//JF2tPkPZ5LRh4KyvxhLiOIgGhbZYr02hfeKLCvwXkzcyKgZeR8RRPGTrVrC6Re+xflXvvGpGls/VQs8SguGw2HTe4FwFabKicMQ"
        @"IRRah1ivKYyg8rqpgwitBAGGqag8VrPrv3Lu9KMffe1bv0p+7QmaXCVWXaR2OB1iVICRGqMAAgSHCNSthMlB4tp+aOyFxgyuWcfXQoKmQqYWEUtU"
        @"MyadbVCfnyFoNUFGeDQQQxQxWL1KvnKNIhtSiyXBbBPjy9x414+CkEAItCjRov/AyWe/di4MRx9OVEXE+GFddT4bl5fWvvPln/342pnfYPO1L1Bc"
        @"e4ymvE6qNwiDLXTUR9QqqINsgmxKdCNGJE1EchCV3g7xbcAU0CUON6ink14HyXSDstimunqG6YQHXZ6hRTif5eUREepCxxKhPEIIhPM0avUTRVFE"
        @"pa8Ym3yukmZuWA6OKeWJtIhMMVqMRf+Bur3+jfMv/s5Dq0/9Uwbrz3PzoTrEAStbAXuPPcxYtH86lzGVAqvMjgn3KCeQTiOcYiK8LncSggpQ/Glp"
        @"RvLOrgJIj6VCCtcMXVCELikiNX16u2uaLmr2OqPxwweO7uX8ucf4yq//d0dfffSXvjblVr+Y2tGJLBs3o/r0Uj/zHcsE2KIRyDxZZBjGpS2bBh/9"
        @"6A//5XMJCeee+y3OPPkrn9Hj5S8E5Zj29DTeGkJvojdeftaLKsfkebMsLHFt+gEv4iNap0eFF5HNBlFc9X4qKdY+/+qTX2hx4ZuYy98iGb5GoLoQ"
        @"VpBGyDRBRTEiUDs5hBDYjZA3ofRRiA5CugCNNnmrST4V4loW13CQJqi4hQ6mEc7C6DUYfQvBi2BPYtYeQ+aX8blFUp/g6X2BDcYPO51RVRXCllEg"
        @"O3/vped++4ms9zJPfeOffsxurXHp9VOfWIh6H//OV/5hvHnh14mL52n7LrOtJpFQaK0JQoFOJDLWkIJLClxSQBqjogVkdBcifi/ovRNX2vbQsqAY"
        @"DfHOYfM+Wpe4/AovPPU7n5oK3Fxg7XqkoiVTWYbZ4Nio6C0GoYyMMXOD/vBkGCdFHCrCRBdWB53a1PT6aNwvcBmthjrhR5efeOPxXzz6xqM/x2D7"
        @"FLfffRgO7+LCmfOkC+/nxA/9zSsjNfU/lEo2K+nwwjYnHAOH8BLpAvAB+BBHgPPBpEmJ1wgvEX8KjMA7/BM4Kgocth/KADc0pEH6gTipF0NLp76w"
        @"75M/8MN/hVZrmmz7dVbOfoXHvvhzJ1pcezx0w4+6MkP4iiRSIAy2KqnL+IEQvSgERWZdq/TtTy8sHIbRZbbPf52LZ/7wIy23/isqW3mgLgcfqrmN"
        @"z4TjFc6e/Jafit1iJB3FYOtJX46XpctOJn7UaTL42IVzT3/mlcd+k+LSU4wvP8F45Vnc4DyoMS4RUIsQaYqOYwKdIIhxJEAL2A3+FvDHQN6Ci2+G"
        @"9BCitZ+iNo2rNxFJHU9MPrQMVtcYXH6O7QvfgPFJGL+M2V5CFwOKrEDIGlkVkvULgiBYigOPtBmy3P7xl5/4yqfE4DLlxmXylfPUiy3MpWd54sv/"
        @"H9h+Dl28QeRX0WEJ2QChJOgAGSlUFCDDCBUFEClcGINu4aLD+OAu4CgQYhlgTR98RhRFiDBB6hBFwdb1l6G4REP2PuZHm0WIR6GYmpoqoihctmVV"
        @"1NKk4xAI4cmHgw8oaynH+bGyKDqBNM1YDx44/exvffHZP/gFzj31K4TuIvtumoFbDuIvnGWUlew6+j6Gwe7/tJQBXrhoUp2R/Z2d5S2CqTcqChJQ"
        @"EYjorctGvAsEejtxAKBSzWg0bqay1U/QVNn4m1EtPLKdFfPZdl7sihY+eujgDzxy4YVXaNX7rF+9xO/95t+NH/6r/+CnNnK1roRad6VedvioljSX"
        @"zfbWqTCJl2nGzaryT3aH5uT0riOfN9c8ovcaZ37/F3jtif/lY/d831/+2AuvPE3euU7VOYVozKHH176qRONXW3Hrc0L6qMz7xy+8+tQXVVJQLX2b"
        @"tXPfZnd9wGjrFO20YmxHkEqqNEQkChlJlEzwNJC0EK4OsgayMfmtDoBeR4o1UtEB1qG2Dtkq9LdgPCQ0BVVVItwQS4nrfAfpIC4zqnxCzw2iKeq7"
        @"byeZPUrZ95EgOzIVVsdPv/zNz49XTzFevUQriGi2pyC/yPaFpxkNX0XLdWKfIaWGJAQR4iOJiDxea4QUaBkhZABBCMEUldiLjI4j1J04FoDVyWH7"
        @"OFMhkJiRwRWeKBRk3Teg8wIvvfCVn73j7r+4PpbR1zYG4/2myntxHFMVZRSkYRGnyVyRDzqplv0a4mhMcEqWpilDH8vy2qO9c49w9fUv0ZrNmdu7"
        @"i+iW26HbZ7i9SSTr6JlZtjw5OLSjo7zcAYpJpBDfw93YESN5k3sgcSD+ZYTpOzKMfic3B3XCIQNHVVTNqKz1G2njge5o+2QV+MInIbHWc7Lf68/J"
        @"6994/IuffLB7/dvsPTDLK69cQdTu444f/Kvc+94ffnSzVOuZrv+GUrUvheOgGUTx0ZWyu66ieL3m4mKqeO35r/zCj544MF+w0VOsbzp27zuKqQSR"
        @"1DhVQ6QLtE78IIw1TkRIqbnrtkO9l1/4VovuEmunHyUorzBdG9HdfIMkKojna5SJxNdjZFJDxG1UugjBMZx+ABXdjqOBJJlkocQQWAF5BfwV8Ncg"
        @"v4wZXMFvXcePBlg7UQgSrsRiqYSnve8w5bllqgFkecDswQ/AzT/Gifd8hJzGI81mozXuXH/45af/Od1rZ3GjLtP1KcR8A7pLrF95lqq8QKsBaRxh"
        @"XYGxGcnsFCiF1x4fVHgl8SpChykkCUS7qILbCeIH8Hw/1mmUfAPhXsCOHseP38D3t3HbfcLC01sbo3wTE97C9O3/Oczcz+G7PvgR1Zg/Na6yJaVD"
        @"nJXkeYHQCkzebEVmsep3PlvXsn/6wqmHGa0wuv4k11/9FWamCoL5eRoHjkB9jt6p02yffZXdN/0Id/4fP88gvlXYyiC9RLjozR6E4PCyelPefOIF"
        @"BG/G/ZPyo33TOPh3PYC3EQg0zo41660l62BQDZ+UsSRUYJ2nGmWd2Ckyk3yzduThB0+/8gJpfZs7f+hmlr7zGGe/vsR3/vnff+gDP/5f5xfRy30D"
        @"80njZFEOTjaTBpX3OCwiCs5NzS+c6G4/z+y+m+gtP0X/9WeJdEIu50lnj5KEFZx9nFy3UUkLOT3Fy89+qcX6SYrll2DrFGHcY6uzTmNWETYaDMoR"
        @"aTSDjBrYuIlI9yGCO0EfQ6g9eFKcFwhhEcqDG4PfBHMNZ99A2ivY0Spy3EGYbZyosELvUHw1AmhEmvL6FcJmnVAr0jKlHHYIt1/l5LOfh9r8RxkP"
        @"odqgWnkWXWxSFD1Eow4bA7Y3zhHKbaZbEUU5pChLopamkhVjtU2aNhFa4gKNlyFCJjhdQ+oGlZiGYO9OGNNDmAIh1sBsQLWFdxnWG7wMECqiUdMM"
        @"VtexStK79DStZC8NbRbXt7qnolaLXnc0lyRJJwgCfKgIItdXZXb03GtPPyjKC6w9/Q/RwyUG3ddYWABfnyfd8/0wexNceBTX7xAli4T1o4Ry+tNm"
        @"YEm1n5RqXXLEEhxx0hdO5k96mRWIqim87MMNevENarTnT4sOwTvaAEigFTdOj4cZYVDDwqSM5C2+hCiI0SqMqrL2pTtue/9f+/I/++n966tfYHoq"
        @"48h9h+icvs6V17/Mb37u/xbvft9f/OQtd//wSTcuvuZs+jVXRk8qFUe4vPCyOhrXmlx+Y5Op+RluOnGI3mtP4rJtynEPs5VT2m1EfxniXZQiJpia"
        @"oupeZ/v6q9Rkj9SuQNanNQ1GlvStQbYamDBChQk6aUE6DWEL0EhyoI8WtclkcxW22sCYa1h3BW+uIqoV1KhLZDwETZRUJIWGClASlIDKgLHQN/hC"
        @"srbexwnF8suPUJveS2k1pioI3IhAGGpBhFKWYqsgigy1pCJOmoAiqLWgHUG+RZo0QJrJtUSAigNIYtA1UC2QCyi5iPOzgMLZNXDbIC+BuY6rhijv"
        @"JiVTIRmNMsLK0KxpRsWA5aXv4KM2Lz/zu5+554GPfLqXbTzRCsLTkchOODtetPnow5Ef/virj/9BbDtPsX7lD7GD04T+OrvnAmxzH+m+u2H3cWzn"
        @"MvnGVbobK3h9J2L3PRhbezTWCcLn0fdu4a7vhS+c+C6UU3m5I0t+g88lsULtAL3e2apE72wD4EAaQyoDcq92ePoCBYRS460jwxYyiE5aWj/fPnTr"
        @"z65chY1L15m99xbmjjdwr7/KaOPLbHznEme/+HMn7vvRnzwxFMmjlaofqQzEWiLL/IR0HoRic22NmXtuIR3upbdylVpUEbirFCuXKUuNVm0sCQMv"
        @"UKGlViuQbkCiDDLyWJHhtUQ2pxHTs5DW0fWpSX3fl5Cdmbj5YgHn9iDVYdBt8BVKbFO6FULZQwSgghbQgEEOvQy2xhQrQzaub7O9NaQsHP1+Oalj"
        @"lzDOYVxAxjKlAivPYDyESqC8xxsIPYTBBIPvKogjqMVQr0G9Lqg1E6Zm6kzPthDTTZgKYC4BOWlfhqsgSHDVIjK5HalmcMUYITJkuIKvXsXai2gM"
        @"widoYfFKoCOHtA5RSRQF7XibzfN/wFRrihee+bVP2bzO/d//o4+4bPDR51/4Fmy/Qd49z9pT/xAtO6TRNrrRR+kSV99DuO8/gd13AhuMB2cZdq+A"
        @"jpg58n3c/d6HyczRb1oVzqmA/igfFSooloQwy1JWhfMV3nhUVO+XFU0hRV+ZEUkYHDPZMPY6PZW5pBBRdELa0clJ67J3DcDb5gdM0HhgBU0lXP9N"
        @"Hr4XE+14FTEq4yfv/8CPceq3fpKLp76CuHCBmXvuYFdwM53XzmK2XuZy5yrf/uLPUN/3vkdvufvPPxHI+m9okz/wyiuPMnzps9SVoRpvQa9LcOf3"
        @"E7jncBvXUCYnsZbQg/QliBArA5AOYXLiREIYgpSoRJPUahhdoyyByDHod5HbBUoF6ACEriF0Byl62KpERXsgDsFukYgxjHLytQ2uXbnMyqXrbF8f"
        @"0L0C2SaIcrJo45Ykqc/Q2r1AnNSpJy3iNCWq1YnrNYJGHak1UuqJbJfxVEWJLQ3WGMo8x+QjulvrlHmP0XCDld4GWacHS2PCYB0VQtyC9j7B9P4W"
        @"MwfnCWbqSCOR8SzoJgiPlNtU1TqmWkZyHSmHgMCVAukmYqHuhrKvUoSBJ3EjnL3O1sVHaY46dPMpnv32P/4ogw02XvxniPwyLr/KVDREhSN8YnCJ"
        @"QtcPErRPwNSdwDTV5jOUvXPUowBhZ2jtfS8jP/MpghhrTac/HkeNVpNRmSOEKJQ3BEKiZEiVO5QO+85VqFhTmHzdeXdcC4HSsmm9XX83BHhbk4CS"
        @"UoERAqNM0ws3cee8nNRthYoqW0VhGBeB1k9SjX7W6qOflPEB7KgD15bgwANM376b0fnHmDJbrCz9MlnvO5z+1n/1oE73Pki4AOPXketnCAfLTO2e"
        @"Jb9+jXjve4n2KEbmcbJ8E6klxJaqqpCiQIsKvEVLhfUO6zKsciiVEsomeqxRw4xiPEQlEVpbRKDx3iFkMWkIKiuUqiBfBjUN59/g8snHWHntNfKV"
        @"AaM+2GjidR/eO8vsPXupzy8Qz+8mmt+Nmp5Fz+6bvECmQAQuABGAUGDZUf9RIBVaBiCDnRKLB1+x22fgR2B6MFqH7jK9tYtsrl8m761RjTr0Bmtc"
        @"f6FLfK7L9J4aM3sC9hwbQ6MP2XVQQ4KgBDfC5IaqmoBoAx1hBiXahSAcXggEBikdoTJYO0AO32BUdpAmBV4h629QDa4jogFpwxEog0ol42aITfeR"
        @"tN4P0/dANAN2DbP9BnK0QtmtiJPd/OD9f+WKl4d+Y2j6R9Jmaz0qav18nGOUidJasph1iyXtPDUVR/UgODISo9OVKBhRnHD4qNmc/mbloCp7hda6"
        @"j5DvaFbwO9wATCghVk4yt8r7jnZu0jlmghtvhqHuVFWFLD2VT7+mFh/8ZG3tDOPOOforguYeh144Sst1GV15hd27C7a3n+Xaa6dwvkW7dog6hrx3"
        @"kemGxhY99NQMDHPiW++BokO5dYlK9QiSClkahDMT3rqZJI68FIgIgjik8jDq9olUhU5ixNgQ+xgZBUAKUkAuGK13WNu4wvWrTzKV7OL40Vvx3QH5"
        @"RoeWTjh69DDTU7NQj5GNOrSmYWoK0nRytFpQb4AIJ8GsN2Ad+Io3MbXWTiS/jJnUvVU4+bfQICUEO3kEBEg1MSLJLlozCa2j+6HMoL89+Z33ycsR"
        @"Y5eR+wRGOXSucX7pMYTo04pSZqZTdBKiRQtKgx2P0CqEwIBxiNJAmCBlQCxzhKgoqg1s0aVeb1FtXifLuky3I0qdkdYVyjuoNaC1G9W4C9l4H0QH"
        @"wFzDbJ0hKDZRQtAZShYWbqLTo99XrEfTaTEY9RZbQbvvjEfFshjno2UdQi1Io3LbNLNxiawLrHDNIInO+VBG29vDI2EYLtUb0eJ4OMoDGXfeJQO9"
        @"zUZgwgmnH3hHZD3Cu8hgCiNdp7IjrKsWazJddj5avuv4Dz7xzJd/5sGg+wTBYJveG0/QOvZ+2PMB4nyGcvQcU7El3+wR2hGut0pvnKMTQ648YU0z"
        @"yjYQ11+muTBDvPceIGWsXsa5DXTuEaXDycl6czLAVJbIVwRWoqMApwW5ziikpxbNQzgP5RT+So/zb5zj4sXLrG9P4vW9B2ZoH5qGfRIxv4vdR4/Q"
        @"bEyBaIFRECWTBew89IYwGH03FvcOV000CeVEmhcvwCpBLgzWGaQpcabEeoUOIlQQI4OYMJigEtHhDd7tJLEo7A76xYFVIPdAoqCliRNBXFeT5Fk0"
        @"C1trTDu49tp5Lr9xjRiY39Vi98E9pHsXUM0GZX4VIUuUEKAEUgXgFUJLlMtRlISpwoclTglU5NFNQRBFGF+gkwhq88jW3QSt+0DfClSQncMOXsFu"
        @"r6ErTW1qP6p9ENFs/bwTQV9FwQPk1ckiy0jjiNyXlK48Eqe6GBaDZZ00OvVk1yeG2fhrkUyXs/7mehz6/nSt0alsyWg0yoMw6DjzzkbTvbOTgP6P"
        @"SQp6mhO/wBUCRxBKZKXWG3H6gXE3P2ll7Uvx/M0Pdl6APVqQ+BH26huoQ0dRhx8guF4i8gQdnEONepOdLBY4mSKVwitDLQrpj6/C6jnY+wBxBU6v"
        @"Y0fZpCq8gykXSFAK6TSygsJ6wjJC1qdIkhBjNNuXDRdeeYnXXt5ke22SfJuZhoMHZthz2z527TlI2KhBrmCqhjCa7c6QfrdHrzumHBXYssKWBZgC"
        @"LT1xIIhCRagFzVpMpCDQAhVMOhH5UIByeF8SSYGrSpwDKdUOoVlToEGGFIXBOompPEVlqaqJzp7wEiEi2tN7qU/vIlzYBTU9CS2m66AMpIr2rj20"
        @"dQjTA9YvXuHCudd4/fltwvppkjm444FbSBsJMqlDZMANsHYIkUCnEYGMGfR7COUJ6hFRkOBDj9eOqDkPqoWv3Ypq3IvSx4E6mAtQXCYw14hCBybm"
        @"8mafqSghd8Mft6Lx+eFQPRnIACknpT1jHHGSLufl4ERVuONT0dTXNjZXP5dE9aapiuWpWjMqxiO8FIRBQuWqoqqquVCozrs5gLcLxeQF4cT/3xH8"
        @"8BhJH8Bi8WIycZUMiq3N7qk4UH0fNz5PY+5nmwtHKMevkAwGKLnG+OJJ0kP3o/f8KNnGLGWYQ1JRSxpUvZyk2WDQ71NlJe1mk4YqMaPraC+hfZBU"
        @"rlBQovwqOlB4m+Gcw9h8IkOWhMTJAuhFii04/ewF3jh1maWXHdrBdENz9NAie3bP0miGpDVNlEZUuae7uYa7uMy+vQusvb7MyvIaNpM4IxC2JI4j"
        @"4jQiCAVCewIckWYCUsrHmFASSAVe4fE7CrsCv0P9VUbvVAE80nu8Nwi7o3BsBN4KTAVBZSiKiqI02MrhrWN7eZkNKfFpHdlK2HNsN7Xbj4LxUJaT"
        @"7TFqwK5p5qf3MH/TTfSuXmX57BKXXh7yL547S3sebjq6m8M37yLY20DVFJXdYlwNwVhquxpkuYFQEdQ0VhvCVkrlUnT9Hmz6fYjwfTjaSNYR5UUo"
        @"V5F2Ajce9AbMtm+lGlynHmUPZdXgY942PycIJnwSAcbpprSqX+ay365PnWI4LmZrEc89+81T973v3uO9fq9fb7Tz8UBhCkOt0eg4UWAN7wKB3u4Q"
        @"YOIJTKCbBrXTU37C3fZ+wuQK07TjvaPyhlFWoOIm2ZYlHg/wgURPr4BdAW4nmX0/+aiH0zG571BveLY3V0imA+rtNuNshAojpLYw7kJtLzRuRY4z"
        @"DBZhFRQBLquISKAxDzpicKnP4489zivPF2Q9aMRwx9EDTDfnmJmaI4oilKywZsS1q5v0+30G/Qycp56GhLmCnkP2LbEMqbKSKEqRziMLh3ceQo8V"
        @"nkpZvC+II4UwmkKCFH5CbnFg1KT+Xhg3kbu3Hu/cjvjm5B4K56nyCm8FrgRnLKICbTzCerAOZUuMNwihQFeY6x6EYWnpElu9nLg2TXt6N/OzBwnD"
        @"GtQlrSPTtHYd4fjxIcuXOpx54yzf+uoKzzy9wrF7E247cZB0zwJBfQaXbeOlodZIya2FtEaQJlTCE0zdjpV3IeM7gEUsI4xZRplLSNsFOwaXE2jH"
        @"9vYyun+VFx77XY7e+9EPE848Mi5EXwUBpXMIS5ECtVDkYrjxcEyw9NUv/eYTgcgx1Xi5Xk+j7d4grtcXToRCRMV49TeC0E/yJe8agP9440ara+89"
        @"WmustXjvkVLilMC6CUVUCoczJYFOwHh8aaIojsiFKVCKfmHn6qHqKO9aofQMypz6dIPSd1H0kdVZXK+GrN8EapGk9jBjsUCoX8Bm50nnawg/xrsM"
        @"nSqMTKi0xJUdomQW0uMEszXKQYapDKltExQJDBqY8z2efuxpXnjak2ewaz5l/1172L1nFzqIKI0jG/a4fq1Lb3uLLB+DNYBEEZEkCZaQjetDtJB4"
        @"78nyPmE0WQjeSqywSOFAOhSWQHgiNFY4lDPMNOZxgULHCSIIkUphvcUH5Y5gqUdai6sMVVnhK4M3lqKoMKXFlg5nwe2EA86CFAKTC6KoTjE0RFLR"
        @"imbZOrVMdW2I2yoYWMum7XLGXyBqJuzaV2ff4hz1qSnY32ZxZhe7D+9laWWZpQvnefHxPmeefo07j9e55e79xMf2QzqEJEdrhRMtfDRHkOzBi6Oo"
        @"4C7weyfGza3jq7M4cx5fDSdGzBTEcUBIH9u7jO9d59zLzz58270/tli54LST0TFbZacbQhR6sPmBht782Ree/faJpXOX2DVtee97jj/kZVLk1vaD"
        @"ekTuR8vCO3SocH8K0IB/4g1AnufEcYzYkXlxzuGco16vH+l0t9ZFGBdKUWDFjsEwfPvRr/s//4EfeCgvu/P1JHl0XFTF/NTC0ay71o9Ye6TcfANh"
        @"umTDbURaoa0hKDcQ+TUIr0I4R8AhkjREkaMUyKoGdMEPwHmEiBHSkxVrRGYfhLdA4kjZh1AKNseMz3d47ivPcO01gzDwvvfsZWHuDlRQp3JjxsWI"
        @"5dVrbG732OpsUxaOUAcTT0BEYD1BmFCVnu1iSKA1jboGHWNMRlkavBc4qVAiJIwDkjQmqgWkaUQUK9rt6UmHYCUpKsNo4LHeI5ygcoLKCqwFvEML"
        @"SawTwqCOFgIRQD2UGOMo84o8KyizisyXFFWJKUswEj8eESUR8/UWw+tbrCytMeo66uEU29slpjLkzjPcHnPl0kWeCx17F/dx6OA+Dh06hN61m1sX"
        @"93HL8bu5eu4iS6fOcP7VNd549Qy33q+4/f03oY7vQmuBEW1EfBCrjyLlUdAHJ9UThmi3irVXKPPLSNMnkpBbh3YWYXJEtknZOUvaOEK+deVTrdbh"
        @"vznItk7XVXFkRo8+FrDxqW///m/y+ovfojl/hO974P4nStWmlKKwEiwT70Z596bb78U7Ggj4ziAD3Wh3LYQgTVOGwyFhGOK1ZFQVx5qNVt9nbrnK"
        @"e1EQ9T/+7GO/85netbMcu/UYh299YD2J9nysKoKlyG1/7NTLv/ap7I3fYXjhazTTAXkKshGQtlJUcy8074HavRDdB9SgOgXVObAXgBWs28L6PmBx"
        @"qkYldlGrvQcp7t0ptz0LZ5/k4reeZfXUGomLaDVnmd+9iI6m6G5pNrdyVjsbXLl2laLIEFKjRABITOWw1hJqSRiGBFqihMDYnCQKiOMAIQRxFBHu"
        @"ZOsr68itp/SWvPIMi4wsKyjKkm63T16VDEflZKLudLmK5CRZX6lJRRAHWk4694ZqJ+EvIU0lcRxSqzVIazWSeo2kVicMQ5Q0uKqPrwZEomDfrln6"
        @"m9uMBiXjkaA0CoSiNDDODHlRTVCQYUDlHVk5ZHquyS23HuS2Ww8SzTRBCmx/wMqFy6xefIP1y+vM7IbD97eZ+4H3wcG7qNiD4Rbi5KYd5mQB5hIU"
        @"L4L9DlTnsNsbFFt9EmpsLm/RUi22tgNG7OPwPX8Fdr2f4/f8yCNJLe2X47WPv/Sdf8Tq8mn6/ZL67G38hY/9vz63bRqfz1T8pJFih/s/0QgQHpDF"
        @"TnVFv4U6/K4B+A//Bnf63adpOpfnecc5h1JqArgJJDpUza2t7tFmMnUy0BbD+k81ovHDj37pnzy8ceUCB3YfYGrXIX7g2P1858XHYPn32Tr3dYLy"
        @"PDIa4aZrkGgazRRabajvgfgeCP4CRIeBPphrUC1h3DLeb4DoIhnhpcfrGFvOEaf3wbDk4snfZPPci+yqYuZkizhqQ9yE0ZirVze5tjLk6kqXXi9D"
        @"qYiqNFjrwWu0DhFC4JxDStCBpCzHxElAGGpqzQbN1jQg6fZHDAYj1lY3GY7GbI8KBmMo3aQi6J3AepA6wAooq5IkCgix+MwRu8lCzz3IQKO1Rgi/"
        @"42EZPH5Ci/dvihrDjgy21hDHkMaKhfk6B/dNs3+uSSPWrF5eQRCR5ZL+MMP4Cmst2iuUjDCVZ1SUECiiekxpcpzPmGlpDt+0yMFbjtCYmQEVTEqZ"
        @"V87y6qkn2CgMc7dPsef+h2ifeBjSO8BPUZkUpYdId3piAPLnIb+MHfWxg4KyL3BDixpalK9TminKYJHZuz8Ms4dh1GflwrNsrT1DkkRU+iD/p5/8"
        @"n9n0c58YqNmfd4HDStdUTvYnIiE3uk3ZHQFY+a4B+I85giCg1+vNBUHQieOYLMtI0xSlFGU2JMQ0g1DNj3LTI9KdUtimK7qfbKv+x3/3V//+vFt/"
        @"in1NYCyZaqQwXqO7+hpxLcfHBaYuIRI00mQCpGk2IboNwr8I0d2TshIFVOtg10CuAoNJgslvg96CLKN3xdBb3yaQfRIpiE1MrKZhEMBmxoVXz3Lm"
        @"9SXyyoOMKEuBswpvFN4F3Ggp5tzE1dSBIIwVU+0GMlDktqCz3WOrN2SrN2a758hLqORkwTsvdpqeBDgrqUpPWTkyW/UI1LoRdl5JH+nKxZWBEIgn"
        @"0xc7qZxjdh6/VfBaqQm1v1YLSJMQ4SuqskSLCbrZGmjVYK6uaSYR9ajOTHuOOGmgtGAw3CQbbFOMRwRoAhlTToRGEUKg0WjlwY7xvmBubo7bjt/G"
        @"4u23wK46yAGMV8jXzrK2vozTKbvvuJf4nh+C+WPAfpzvUZbPIc1pZHEZhtdxoy6qrKgGDtsv0KMSMygRtkaYLGDSvQwrzzjbxsiCw3fdzNmrBfM3"
        @"/+e894d/8gnqt35kO/cdqYudO/MmuAzhBZHRSD/pE+nFu2Sg/6g5gHa73S+KAiklSZKQZRlKKbxxKO+jKFQtRIlAdrRM+07Lnw6ixqO7d9/06HDw"
        @"GI2gQ6e3zGCoCPHESUFmh2ihiXSAV+CVR4gSxBgrBki/ifB9KtFEMINWNZBToNrAFpRdXKUoNq/T31iGgaaRaOrxNEF7BoyES1usn7/K8uvX6W32"
        @"qNdbyKxgNK6IZYjSESWCUWEw1hPGNZrNaXQYU5qKUTnm1fPX2R5ss9mD/miiSaNCwbiAyk4OB1jrMYXBefNm+8qdXsktaW0rCKCfwZyGw82YfbVp"
        @"Zls1Gi1wvsJ4gfWKwlp6o5yt7pD+aEhpIMthnFX0qbCTc5KKCUEojqHINJs+4MLVEd6MkHKNZjOiPdNkvt1kuj5HWp9h1OsyGOVIodFBhLeOSIZ4"
        @"awjCJlpJulsZTz1+kvPXV9h/6yKH71iEhf3EjRoH6jOMBz3Wls7gB5vsu3MFPX8PMpXE4TbWDXDeEgQxVoYU2XjSVUhZopokUgGjzQFV6ehmW9Tb"
        @"c0TNgsZdd7J1eZXSzTO97w50sve/2uhXHRXGzcAWfQRY9EQUVLodUrDeCQve2YnAP/EegFKK0WgUNRqNot/vN5Mk6QNoPWkT7b2YGATpiZOE0SCL"
        @"Qq2KOHBRw7zR/fYjH4/F8Dmmji4wPvsSw+01okDRaE1TGkuc1HCxwzY9rhVhanXQh0n4IWTwHvLgKDBL5DTCl6DWgHWMvYopLpN3XycJHJGeBp1C"
        @"PoaL5xmcepXe1S16q4LxWFJQkVeebOhRNkCVkn5vTBVr4qkWca1J7hXbvTHXOj1W17fZ7GWTBS5AhxHWCSovKUpHd5wT7OxNDaCVQBpOsDiNEKZS"
        @"iCJJ2mwggpCscjz79CZzEm5faHNTY4GZNOC999+CL7bJ8xzjLEEQEMYxMgpBBxSmZFAUXN/a5upGh+VOh9WtMZ1t6OaQASUQBWBDiJspYayxxRhT"
        @"GGQB89Mx+/fMMz83RaA8WT6mzAuUh8g4pJR4LUFJdOBQ2iFljqXg4KF93H7PcWo3H4FUQblFf+0i650LeO9p1XYxf2QvHNUge1SjLcx4SDgaIfIx"
        @"1WCAycYoY5FWokjIbESVLBDU29RvvxWurvPS65c4cvdf5gc+9N+f6toD7x2Wej6tNyJZ9ZcRDuuTwkgogwxwhHZiALx4FwfwHwTQs/NgJ7M60XoH"
        @"x0vPPeUffN89+8147UQrUOtehU8aq6jKEo+gFCKK640mxnbKzBCqpAiVpCiKItGNX53edfzjl1dfoLlxnfSWfcSrCUVe0S/6hFHI2BYoryAEHwiQ"
        @"IVKESCrwBQEOg8J4wIUI0UTICuEzvBsyNXcbkE3qwd0+5uwS22fPYtc7hIWjEaTEjYBuYQGLTBTDXgm+xt5DR2G6Rmc05NzVFc5dus7q9iQpJ7TG"
        @"BjFOeUbDAjsqqNzkCwuBtoRd7YB9czXqsSfQFu1KIlEx14hYmGsyNdWichYdxAxHBRee3kQ7EIMe5bZhMx/x9MWXJ9IBk25XE1i1hjgFFStqU9PU"
        @"29PcOTfLnXfcMQmTooiiP+Da+havnLnIy29c5ErP0algZTQm1BAEk/OEUrLaLbnWuYLgCgu7Ym6+6QDzMzNIVzEedHHW4HcSkE5NIJ1aK9KgQefq"
        @"Jk9uPsNNnTGH7zkGu+Zo3j5FszfH6hsv0bt+msHaS7Sutpk9dpBgukFAQW4KYulRShGmKa7MKAtDpSCZmqe+63bYdxNcu8Tly1cJkwXqrYPkVi97"
        @"dFGr1XJrqmUJ0Vv1AaXXE4CUdyg/CZkmhCCxkyvx302YfDeN/Wb7+O92ptppMvpn3QAI/90MK96AsFjpKJScU5hOKHt8+Z/+3JUjc9Pc//0/fG51"
        @"XH3aqdavJmEUFc4UQUQxLnsEJqIW1Y45C0WZnw6UQqnGE7Tf+/FAP8nq9W+zp7ELuXg/SbdH2TtFpYaTqK4uMZRgHKlP8SbCWY+sBygkxnqsFxMZ"
        @"OF9DGEfoQ5L6NLAC/jqsvMFo6VWyi+dR4yFahhhlUYGBsiJxGaYsieMGu3cfoDBtrm8VnHzuVZaubzHIdiLNMMCJkM3eaFLmcxABDQUHGrCnBbua"
        @"IfOthKlWTGM6QEcOa3JqaYve+jq33XITaS3EOINDMRoWHN6/l9dPnOfxk5CHCcpKakJjBpakERB7sGVFKAXSQVl4rLSYzQ02lzbw/hxhJEinpkja"
        @"Ldr79nJ47x4Of2g/H/7g9zPY3uCFN87y5Okl3liBFQObQIwjCCFOQ2IdsNzJuH79LHvbmn37Zjl6+0GKfIAd9MCOCAkmqEURU1lPGsYo71h/9TXK"
        @"9RVuvvcO5D23wJ5jLLRmmV8+zfWzr3LxictsnVnl5h+4C/bGxIkkH48IdYgZe7yTRI0GYyRVo446/H1QjRlfXcKPt1HNI6DnsEH8RGUstso7QRDg"
        @"kEVhCoy3SBXjbYh2mti7OSXcvPF+ufK+7wmpvEOnAmMqbG5Ik3qzcmXfS09lcqIoQDo7YV1WgqoyiODtlRT7E+ABTNwo5dyO0TTf8+xdd73nUy98"
        @"83c+vXT6WX7vC798dOaWuz9/23sefNC56KSxsldmomjU2o9SSsbD4bJSuh8Euukp+oOsjO+79X18+df+G6phRP/qOs3b74PDB2gNaox653H5OiL0"
        @"KBmADcBqVBhPmHC6AsaEKseS4gCFRtHakYvO8fmAfOsy44unoLNMUwmEDsiFR0Yx1joG2RgdT3Nwz25yJEtXNnnulUu8fqXLGKgchEkEpWWrUzH2"
        @"FSGwUJvIAOybDzm8Z4q97YRdjZB2ophONPV6gBEGFUx2F4Hnmuvjqy7epxPshFVEoUO4MQu7axSMyJ3BWoESExV8ZxVCKkIp0YBwjlg4PJ5IaJSE"
        @"QIASCtMd01/bZv21S5BAY2GaxuwUzb1z/OBdt/GDd93D9c0hT5+7xAsXLvHK9THjEgZlSUZJmoSoRHF1kHHxlVWev7DKnbft4r03HyV2Fd3OCr40"
        @"RInEuRJhHZHSJMIj85xLp87QKnrM3HsXzC4gtWBfcw/14BxXzp/hua89y7H79pLelBCHLcaDIVEcIkqPDCKsMdTbbdi6wvj6Gr67jspL5hZ340yM"
        @"JToZ1hvN7vYQHct+aSqiWoRCYb3ElZNEbVyLH9zaXDsXxEnfS4XQMpLCF8YUhFpitMCbvK/DkGGeRQQSQ1Voa+ZGg+HxJG5+M0rjqKjK4s90DsCh"
        @"kDgCOwFZWGkxEqyY8NIbOors8NrHLzz3u585dfIrBH6TxnSb3bc+yN3v+4u9qmz/tJXTX+rnppck9X4tjD80zMa/V6qSmhp+6PxLX/1aef4rdC/8"
        @"Jq22pV/bxdw9PzIpgI+vUXSfhGoVKRKC+iy+1qaQ8wTBLajgZpxpIdQ+jF+gMinaS0JtQW2APQeDxyiuPovtbhENC+zaAAYWmym63RwTpNRnDlCa"
        @"aV48dZEnn3+B5ZWCwkhKH2JkwLA/IDOQADMaZuuwZ14y3VLs39tm9+4WM7P1CbFFVCAMWkEUhJjMoBDEcYSSks3VdbIsY25hDi8gLxxKBmgZcK1T"
        @"8TOfOcXhmuCuKmZBajI7IgoE9TAklhLMBOiiJCg8Uky6H2vnkAqElFTOYRWoNGBsKio/wRBECdTbCzT3LMLULIWC5eEWz5x9jcdP97lsoL9TcZB1"
        @"1UvTsJWaiiAz7Ipj7jt+O3fdsg+Td9jePo/WJY1mirUVrUYDtMAnoFohzd1tdt97Lxy7D0YFdAdsvPwE22e/QbfT4eDxKeZu2wf1Mdlgk8QnjLcz"
        @"0sM3gQ/pX9smtR6xfpX+sIk6+FdoPviT3HznXz6+UaVLaS04UprBaeXyyDnXzCuFVFE/qUeMxv1mPZQdJSTWSCoPIpHNcTaYD72PlLXzjTg95Zzs"
        @"jwpV6DRtVrLsB8rMMdx+MFbBORc2Tg9HBYGO/uwmASd8foXAEroSgcdI8Wa5xaEoSxnFMivawbVvfPWfffqhsPsc9TqcWc1pL9zJ0dt+kBN3PoTT"
        @"6aNZBd76SIbBUq58dPbUkx8Nyyu4q0+w9toXiZIh1dwss4fvRM3eA9lVis6jRKIHogHhFCRTUNuFsbMMhk2S5Cbi+CCwgHUxyknQFs8AUZ7Brf8L"
        @"ZPcMo9UtfL8iGGlszyJtjbi1B6/qfOOpM3zjsQssrwyQkSaKU8aZY3tzSLeCuRBmGrA4W2OuLplJ4dabFti70KDZ1IQJeFmRmYzcVpSmAClJwpTA"
        @"RVTjnDgJCZSmynJWV1cnBkAqSuPRKsYbiwjm+e9+5hvUMrhHxuwLY4pyiPCGWqRIowhhHcpOQgFhLWkYoPF4Z1BCTjAYvsI4jwgl6EmLLqwnzyEv"
        @"QCUQTtWoYsnCLQfR7WnWDTx1dplvn77EGz3P1k7ysB3DVFoncZqs22WhpfngD93DbUfaDPqX6G5eZc/uWSpTEKcBtakaTpSkrYQ8rdO+5weJbzsB"
        @"YR2yHtVzX+PCC9+ic/UKew/HHHrvPkg9pijQtSYMCsr+mFBJ/HBEudJlVE2hj3yU5vv+Bgfv+rFWj3ohQ1tIKmIl8NYTJe1jo6w4bWQO0mCq4lio"
        @"wtNSJKBVNCqHi3GollMUoirAV0fG4/zBJJr6XGXKxSAqj1Vm/PDXv/71T7Sm5njg/Q+LopQoxJ9tA2CFQmIJfNaceARRH6/QzuMQVEEyF+iqI0eX"
        @"/qfl17/8iYtf/Rn2tQuCuTZLV6/T7w+YmT7IfPs2kvb+SUImSWF6Bttdoey8xuDqC9SqK+TlCunuWVSzhdU1ktkGuA6UI4haUJsDU8OOBSNSKrmP"
        @"Zvt9BGpxJ/U2CQlAgmuCuY5d/yJm82X0oMJul9heRVLbBVXC0uurfOX3n+PKdeiOahC1GGQdOpsVAdAOYXcb9i0I5qYbLO5pMzsVE+mKXbM1WlMx"
        @"zhVYX1E5+yYoKi8qJJI0rROGMYPBAK0lWoBCcfnyZZqtFnFao7J+kpAykrS1yGf+8Ve5egruiwP2B3W0G2OLgiCANInRCAJvCb1HGEMgQEuBkB6p"
        @"xYSPgZvwMxCgFUIIlPR4aynNJOFVSBgZUClETc2ufYdIdh9iaEKeOXeex197jdM9uL4T9CURNJt1lLUUo4w7j0zzF370BAfnJdcuvUgcWhp1TRRF"
        @"pGmEkBY1PU23UWP6lnuoHX0QVBNUyOCZP2D9md9m+/IbhA247YHbCY428GWPar2LLiuqvCAKY9xql86gTnLbh2ne/1+SiSPcdPcPCScnlOdIBQy6"
        @"4zmlap0wCRjk24tJGi4rociLCit0Uwdhv8zyxVqYLntrsaZAhTaqB24+rkYPR1X37zzzzd85evrSEu277uPE+/8PHzH96GSkG8sTJpv/s2oAdnZ7"
        @"YVFMQiHnY6SXaDehWuQIhHbUxXiuUV5cf/XJf8TZr/0it9wxB7sbDFeusdEZYocRYdDACYdu1InSFlUxpu7GhK7HaOsNgqggnW1SakHUnELOTk98"
        @"VzzIEKqQbNPQHSiSuZuYOngCOAAoKLvYYpvSZQSqiY4Pgnaw/U2y66+SX1ujVmlCGgxWhjz+5CmefraLddAbCPqDhF5/TOahoeHwfti/K+LArpgD"
        @"e9vMzkzRakQILKPBFkJWJI2YIFAYZ3dAURHOeEa9Id5CrVFHBpqiKFB6wt4Ldci1qysopZhf2EVeGUzlkF4RJbv4vcfe4A9/Z5l7QjgUNJnWDpeN"
        @"cHiiSBOFmkgIQudQVUk9jpEKKltixASF6cWECuyRBHFMWZYT8pCfpHG80lTeMiw8KoYsA1NCo61YvPU4weJetvMhpzY6/MGZ87y0WrI+ucvoCOJQ"
        @"MxVBguFDDx7gh99/DFOsMuheZ2amjpaWQEuidh073WArTJFzNzN/xw9AsBtcAU/9Hlefe4yLZ16FKOeuD91KcyEEl1FsbqAMkFsYVVRyjqx1gvjQ"
        @"D5Le9H5KPcPBI8e+GMXtn87GUKvNrOcVHRmpphN5Py9Gc5GMOs5BkMTNYX9UzDXbR0aD/mnI5+KgPI7f/lTkxg89/jufp3PlAv3ekAN33stdH/mr"
        @"vULv+mhYTv9eohvHCjM8/XYCiVR9ev7tsz4I5I7muhV+x/WfNF+c3BNPFEuKcf+Y1vElDOaffe6fP/RTP/lxLp55itl2g/Dme2nG09QjAX4bHWwj"
        @"7BqjzhnkcJlGVRD5HGsGpM2QwpWoMCCozTLqVwQiRdTmoFfRef0qg75gftdd1HbdD2oO/BoMTpF3X8QOz+Oybaj6aJlBVIEWVIOCZquNClu8+u1X"
        @"+eoXXuLK5ZwkiVjftmxsQjmsmAnh2ALcewzuPjbL0UNN7r17kd27Emqxx9kxlnKnDApx2kDF8USmSwVIFaCkwjmHEBAEGh1oVCCRwuOZMCYrUzEY"
        @"9JmabmP9xHgoofBovE558elrtIDpMKSOJHAW4x3eO4JAESgIHIRCUOUFEgsSZCBRUYAKJi24JZ5AKQIg0oJYSzQKLTVeBDvfb4AWghSJG1s6V9fY"
        @"vHqeKCy5/dAC9+xdYH/iqTYG9HaATViHwlGPQs6/vsVWZ5PFAwfZe3ARKytEAEEsCaMQlcRYOySp9SnyZYLAIOI2LNyBcjNk2z3UuOD0E5fZ044J"
        @"ZxsMbI4vJdoHuKIizwVSt0jjFFd0GW6t8KlP/T9v+6Wf+/m7anH75f6ovBQ2k2hr1FtEio5HjkOhCbyELC9qglqVDfuRHHy4EXZ++exrX/nk3/5L"
        @"Rw595P42zXwJb0akB+/n+z/8f3lExO2fdib5pqbZHo+rLRlQvJ0ewNtaBZh0951UAZyYlEPUDmPFSYnwUI7HNGv100VuqVTr54daL9cOv//z9fVT"
        @"rF28yky0gr7lGFG9gVgPKbJVitEaBw40sIMRgTVU4xH16ZSSMWkjhSih3xvQnF+cCGZe3ubaxcuUlWLx1lvQ+26dQIAHffKVlyiGF/CmQxKHKNWi"
        @"Ypv+eINkOEOwcIh0ag+DUyd54RtPcumZjYm0NnDmdMG4gmYCew9LDu5NuWlvjf0HpmjOpqBKgqBAikn5D6GQOqCoArZ7PYqqRKcxeIGzFi9ABJoo"
        @"iSlERmFLlAgQwmOqakKTDiRps8bGxsak7ixBCInyCuMt87MtdACFg1JC5R1SScwOhyBwlhC1Q7mGJAnRgaCSlsobvL0xXSdJQak9qEno4W90JbKe"
        @"QEQ4GTDIK7SOSQONkwZdDMm7jrXXr9O5cp1jx27j/Xt3c2h2nmcuXuXxpQ2W7USHdGAMU/UGp5e2ubr6KA89dIQf/fMnQHbpba8gtUS4ikY9wPs+"
        @"prQUWzFx1IDoDmr33cft43Ve+L0V6mqTx798mdvyggP3HCbLrqEih9ESBSSRRZWbXHnlHHF7P8YVPPu1//XB2szxr73n+//cR7uj1eW6hkAGc7jy"
        @"eFhVR0NvFlNVHvPF6CMvXDhD3llidf0Uz/yL/4FZvcVNe+cZbufU5w/zfT/219eraP/fdEYUwqhCh2rearfE2ywp/raGAMILlJtALEtt8MKiqBBe"
        @"4H2E8nJC5cQhpMZSYV3ZrLvrj5577HMnll9+hHRujel9e5ALD4Fs4lZeI9t+nZgr2HwL4WMC4fC2i5AVhAmVCCGZIgjacHmb1069gZ+e4vbv/xGY"
        @"PQayDlubbJ89jemt04g8oTJIJTBeUmoFcy10MkWY7IbS8/oXfpONsyt0L0vOnM5Y2YJ8Ry/u6NFp7jje5MDBlMM3zeCYqAVVVYU1jka9ji3tm8xH"
        @"KSW9wQDrDa3pKWSg8d5jrSGQCu8c+TjDFCVJPUEJgcRjjEFqhbWe65euMz8/j4w0xlhSlVLaEBfO8Is/9xXGl+DWRsIBrQltQYGjNIZQwp6pOnpc"
        @"0NSKxDNRCAolTnkKawgjTag04yrHxwFCSrRSiNISWI8pHEXpEEHC+iAnCmtQWoS1KG+oqMiDSZ7AS0GrXacxFdC641bWN3v89lOneWZ90kVQC8n0"
        @"VMJ83RG4jHvunubHfuLPQ9swLtYggTCRSOWRQYgP6ohoFlqHQdTBBKx941tceu5ZNi8uYQr4wIdupnF3CzNaxhY546EHv4swmEWokNwEFGKK+QPv"
        @"wdcOoQ/dwR2334FVqnfm9TMtTD5hAw5XoHMWqg7XL59hbfsaaqrO/O4ZFvbtYnVpiyq9mw/+Z3+XbVqfI5z9hLJBIYxE7Og6OPX2goHe9hDgBvXE"
        @"SgfSIrFNIXwEusDLidqNUFSmovIWkaaFtWXzv/3E3/5gma2S915B+jFKtpHpHGJ6D2GtjdAKE4bIWsLAjklaDag1MLknqO9CqSYrL53j9LcuMNNq"
        @"c+Te90N7P7iU/tmzrL3yNGrYoeYMsXGYrMJZR1WWpPU6QavN6OJ1Xv3GM+yJmszWU157/CxXlwxVDmEMx4+3ES6j1YIf+eBx9hxMsHKMCCFIY/Ks"
        @"xHs/6ZArJM5OmmtIyQTE4x1SQ6Alkgk1T4pJ2ISd0IZ1qJFaTDrWCIeXE7JKPsrx3tOYamJMha8s3oOOYq5eucjqFU8rkiTekeiA3JQgJvAHiSPV"
        @"IYF3eGPRSqCTCBXqSdNMJRCBwimPCQXJdIPCWoqqJFR6kpDUCqkVw6qcnBQH3r4pTuoQeC+RTpAqTf96n2hwnam5We646SAz7Sa9zQ26pafIK0Ln"
        @"aTdThv0+5954nQP7FmgeOUgQekb5GK0DpA4nm8d4wOjaZcrOGmFWUF/YR7U5pOxb6j7k1ZeuMD3laR7aQ1n2UOEkrJKuxOQ9KAekgaXMNkliB1WH"
        @"n/wb/yl//aMfjHVxha0LT1OtvMjKqd8j23iR9eVnCKIe0zOaw/fcRH33bpaeP0OuDvGXfuIfkoWL79W11hNZlh9SQi1LL5FSUVmLUG9vFeBtNQCI"
        @"t0CAhZn0wMNHeNm/0dvOO48KA0pbkdbjyGGsxzT/ya/8sv4b/+WPH7edMzRcF1Fto6SF5mEID+OTvfj6ApWsiJs1xkajRB1d3wuiTeebp3n96RX2"
        @"Li5y8Pj3Q3IAsoDtZ59iePENkjxHDMZEwjEc9cmFw0UhjYUFcAFb336RK0+eoVrLyVY3aYVw/tx1Nlbg1qMB99yzi1tv2YOOPWvbPY6daJPO1ajK"
        @"HOM9ToYTuXBTEgUSoSW2ylBqp6wmPcZWO+QWjQ4mPHRpPQKN9gKMRUiJ1GIiUiIFk7bZEldaxqMRU3PTEwNgLEpqZBiQ547TL/VohVA3jlYcTRKJ"
        @"AkKlcLmlXU8RzpBGAR6PExOlYx8pZC2CWoSLBWEtmDQHDQMaU1NIpamKEiE8hSvJhKXSBisr7OT7xU0KvxONwsowXW+QjTO2tz1BNULbnAOzNY7t"
        @"n0d0N/EjT7f0uKpidqZFMRpz7fXz7K3VSe+4hUiD1BrrLFiLy0vK9S6yP6ZY3SDsj5huL1BWgs72mKwacflij+nU075lL/3RCrWmxtg+gbJISlzV"
        @"BbvJeHCR/upLDDqn2Fx+Ejc4BdlZiu0zRHKDOB4RTSdM3XwXzVtuB5ezfeY8/dFeDt7+Ef7BL/zep3Wy+1/0eusfTWLZU9JHxtO3MrVOhpHHW8Gf"
        @"0STgm5Bp4RDCIr1HeFlMmntNnpRa4fCoQNPr9/dEWvWdK4/k3u756f/HJ+6zK6cIqw6wiWOMUE1EOo+Qu1F6ljBpUckAHbQJwzkoYl76p19m5fVN"
        @"bj54hIWDt6Dqs1CEnHv0O+RrK6jRAF1a2s0WVZkRJgkyDGnu2o3tFrz0jedZPbVO2XEMtzNeer5Laa5z94mjtGcF7YUa+29qM3+wTWM64uK1VRpT"
        @"JbvmplF60lPOTDQOcPl4Ir6hBN4atFZYa5ACPJ6qNERhiAoDxITozyTlL/CmonQlWmkEHqUV1nukmCTjut0uzVZj0i7NSaTSWGFRMubZp1ZJpKft"
        @"BQ0dIrwHbwmEwBeeZhqi8VhbIZUkrAWoWoiNFCaW+HqEaCe4hsI1Ykyjho1C8A5rDFhDHIcUzk4wA/K7auISTeVC8BrlLVIopI7Ji4Kyquh2RpB3"
        @"WGjVufv4bcRBxaA7ZGsMw2FBEsNUUuPMK0uIUY+FO49DqpF5jskK8u0hTRfRu7LOcHWb9eUNTB4Qx21yAyII2drc4MLFIe0Zx+6bF8m6KzSbIVI4"
        @"hKrQkUXIMVL1SGsFSmzTnnYo2cPaLjMzDdJGg2BqjvrR4+jF22HY5+oLJ+n2Qm794H/NXSd+7BHdvOmfDPLqklK2SOLo5dEweygMkxc8Gu+FVX8E"
        @"+fpnzgBM+rD7nY6raqdFs2QHpIrxFZV1SBmSxLWiHA3bU426zcps8ZP/zd98yK6/wWj7Ei4eIOuWUowJlQc5A2IW6+ZRepFAN4CUy7/5h5x76hIH"
        @"Dh9m8ehtqKiGHYx4/TuPQ3+EHRg0AVJAVmTopIYH6vv2k5+9xpNfepLhNcNmt8755THXV2BuHtrzkj0Hd7H31r1M769jaxU+rmhOJax1roKzHNh/"
        @"0ySbLgWB0gjn8VRUrkTLidGTUuEKgxIKjcSXjkApVBCAsBO6r3agLMYXlJVBK41WEqEUxlo8EIuYbnebKA0IwwBhJz1HjLdE8RQvvnAZM4A9QUDN"
        @"QRRobFGi3KQWEyoIgwAhmNClA4FMAkQjwdQCqkZEORUi9k/TOHaY6PAiA+Wx0hNoic8yAhlA5bGFRQmFcGICZBQRpQvwaEIVUBkDkWJrVKAjQb0W"
        @"Mtq2DLtdoqDk6H23c+st81y4do1+BqMMnKtQKmDj+jrbFy9y6PhRqEUMLl5DZNBfGUEekG2XDDZKOldz8kxQazbpdLvYIGRcDLhybsTxxRbJfA2f"
        @"byGTEJQlqAUQWUyYk7Q1RhfYwJHMTiFr0+SqTrL3TtThD0KyFzrn6J0/xXAcsOfIQ7z3/r91Zaua/4ntyq5bja5H8SVfisL76GUpQuy4v1hPFNbZ"
        @"grcRDPQ2hwBu0mNdeMTOwr+RGVC+2mlIEeJlSFn5pvCMA2HHSoDzcukf/4//4BP/1//zh9lePY0MBzSmNJYC7yzK1EG2kX4eqRogS1555De4/M3n"
        @"+eB9DyCSGmG9iTfw9LeewnTHuFFFrBK8BSEtBkOrNU26az+Xn3qV5779OnqccP1qwatLOZmBW26Gg0ca7Dk4i0g9ycFprC7YqsbU5tro9jSb15dZ"
        @"u1Zw8003IVWFcyUq1JRlhlSSylR4D4HeMQrWTcqjQuC8xfnJ7i70pFLiFQglsV7gjNtpsxWABOMmsX4gQkaDPmiopzGudJPdWRjiZJqLFzdYuVqw"
        @"L1KE1pNGCbbMJ+SjAJy1RJFG4nDeYr1BxJpwdorwwB7iu28n/YH7id57N9x8M+KOu0nndjHa3qIYDEiNww/HSAKKcYmSk9KuNw4hJKVTCCGRrsL4"
        @"iqRZozsYU+TQbtaJnEV7R3djROS7TL/nVt5/4gidtSX6XdhcB2EcrUadra0uvatX2N+YJq23yda6FP2KbFiRjz3DnsGaiO5mn1GeoaKYcWGp11vY"
        @"wTbnX9/i9lvnEHMtCCbEThMqZD1ENwNkLUTVWuj6Aj7aR9Q6QrTnTpg5CiKBfEj39cfpd7YR8U3M3faX+Llf+sZHTLRrSddDK7UsylFu8ZokbjRt"
        @"WRZIEykltq0X/Bk2AH6ipuIlnhCPRGARokRiFoWXfWs0WtePSR3t97h173Jrq2qmoVszUTlc/Ft//c8dzTZfR8kRcQBg8VLghENF4aRDjSlY+/r/"
        @"yoXHvs4duw5RjStm9+9na22LJx59ClkFDLYMtaSFFoqi6KMDw8GD+9DtWV79w2e48NqI8aDG5ZWc5TVHlMJ7vy9g8WDK4pFpdt+2F0JD4fu4Wko0"
        @"s4hM2+jF/fjBmCuvr7Jvfp54PkH6MSiFUBKHx5lJgiwMNNYYhJR44XHCgxJkpsIpQRClGKGwaJDRpIprPM4YAq3xHiZylQJNQJkXZNWYVquJrxzW"
        @"GoQCpRv0Bwmvn1plPvCECMKdSoN3Ez3C0njCYIICjMKAMFBU3jAoxmTFiDQNYWEvnPhB2HMrTO+C+QX89hZrVy7TtI6gsggD42FJIAXSO7wBKS3G"
        @"GpAOa3NKYwmjkFBLiqyiJgMSpVHGEErPcDPHb14lvv8B5gdDNi5vMRvDxjb0ypL27CzXX9/i2qtL3Dy3hzSqcXl5hU5vSHdkcTJh1M/AC7Y3hkQ6"
        @"IdQBxbCkle6h29ti+doGt9x3x6Sha6qQjSY2SXD1BFebxUf70LU7UPF9iNoJaN45aYIyepGN01+GasCobHDo1r/Cne/5MVy45+dLH64M8+GMlmpL"
        @"CI0UmjIvChVqdJrY7jhrKx2OxZ/ZEEB4BBaPxAu9wwz8bkjgEYXUCXledrQSucD2tXQEQvZF5fVrL33nF6v15zHDi4RqjPfZJGuepBil0DKGcUzv"
        @"sW9z8tHf4Nbdu6j7Bkk4xXAw5vHHn8YZAT6gFrcoiwJsQZoEzO+aJp6e5cVvPMP5c1sMBimrq2OWLpfMLMD997fYtz/l8O17SGZiTOAIZ1uMopBk"
        @"4RDJgbvR7UOg6rTCKa6deoPYG9oH2+BzsqLCS41kosfvnEVrjSkrgkADHussUgcTmXCpiOME7yXOC5QMkUJAWVHl5SR5J0AohRIaicKYgt6gy8zM"
        @"LFiJ2UHveRFTVTEvP3OZVuCpyZBAQCg81hmUFlTGowJIwxBblVSmQscBUSuhdBVbW9t0VtawlaR28y3gLWhHWE+w599gvLJKaAWu8uT9glAphPMT"
        @"BWIFufd46dCBfFPaXeuI7XGOshXTtSauKJDSEUjItgyN9as0du1hcP0a02mNJJWsbllW18c0Ikk28Jw+fZE4TZjZvZ/t7og8E5hKkmUF47xE6pje"
        @"YEQQRQgCyrFk/v9P3H8He3rl533g54Q3/eLNnSMaOcwgDIeDGYYZiuQMRVLDMr20ZZmUTFss7UraXdvaKm/Ztdq1SvJallem1rUWSyoVZQVSokyu"
        @"JGqYJg8mYADMDDLQDXRON//Sm07aP857LwCKEmWDWv5xC91ooLvvve97zjc8z+dZP8bW1m1m23c5/eHHIEsQvRG2WILecZw+Q778IYK+Dzl6BLKN"
        @"GJa6/yrNtd9GNXeZTAL98SP0z/0Yf/N/+ud/YeHzf2IQTidyStfeCiEIPrIOFk3tiqJXCnc4CIvemO75D9J1R3lXFQcRa2Ppu3g2/kAqh/ctBBK/"
        @"DxIp/H7JaSIgg8Wh8EIfHgROyqnEIilRaUB4t4X3MZ5LeFxS10EvaMopGsd8PmdtmCCCpJmXIB3IwOSf/j2e+9w3WD/bx6mESQ19pfnm888iRI5J"
        @"oTV1lNEKSwCOHT/HsN/ni//fZ9jasUzLnItv7TEv4dFH4OGHVzl2POPEuTXkOCUMU9wgoxqMGGycJj16D+hj2Eqh81U4coIL577O/tUXwB3Ba4EO"
        @"Bd5JlJR4YUDqKNlVCdZ6ZBAooXHGMsx7VK3BVQ1JkRMa06n7JEprLIK9vQmjlWWU1rSmRcpA2s9xWwFjHIlOsLVFklEvGk6eWGG8DLsTWBvmtM2U"
        @"Ua4xHhrjUblgWnmWMkkm0vg1bwO2XKBSwSopflozfe5LwA4cPxJbtpVljnzv09T7M+688AYjKVE9iascKsQKr7EgtKTtVplCCYLxyDQqDGchUBlL"
        @"kmXUzpJ6WAlQvrFFr7fBhpLMg+HpTzyN/NIX+Po1eOOGZ7AGPZVx+7Ov8V3fpTh15BzNzk1m+wtqG2ilorIVMtOUuzscXT2CEy2LWcvJ0XmufOdt"
        @"xr/+Eo/+iR8E0aB6a3h9msYexekPonUP2Adu4GdfJExfRtU3mOwskOohxisPg0movHxZJslICaY+hIhsEx6PRCUx26KPhMZAyHBC4mTUwYDHSwf4"
        @"EUFNbSPIdJHpAEK4xieW1pmRFNnUGhttc1ISvOiEYBrv/b/ycDiI0zvYPPyh8wCkjyQVRez5fUgAjQyRS+1DnYlgTymlL0VTi8Ha+Sd7Qz/G7zDo"
        @"C7Zvzlk9MqZp9khkj3w4Bnrc/MznefF/eY6HTp/BqT6LqSFH8y8++3nyJCPrFSg0QlusrRBYTt5zD1k25DO/8Qz7U8+0lFx6q8YHePxJzYULS5w8"
        @"P+bMPWuUvkIMh5RFTrF+jOLMg9A/Sd3keLNEr38EKGC1z+qps2zfeJ7FbJ/+0XXCPCW4qHpM05TGe2xjSJVGShHde50QxgeP8hBMC0qjD45VKUBK"
        @"tI7luzWGJE3jAyE8KpFkWYa1UeJLkDgrIlY8sWwcgVt7UAuJDwF8QGtB60O8bUTAOEiVjreSMyjjIzXItihdolLLrX9xleXjR5jXDVs729x35h7y"
        @"5Q2OrE9oru0gRNfa+Q4zLKI6UQiPC6CFwNkYrZ71UqaLliY4gvcIneCtQZj46XJzm6HQ7O23VNt3+OM/9incP/0M37wOd+7AkhK4UvCFZ17h8Qfu"
        @"4f4TJ9i68woqLSItOYF5axhnBbu7u6yOV/DNgvnUsT46yqvP3WL17CWO/9iPotscsodI87Ms3AihLMrvwOIl7PwVZHUFFhMSk0IypLWKrOiBFk3T"
        @"VFkyXMpa55qDFy8OvDvhT6eCtSJSl+OsxROk715SGdF3uUYY37ggaNs282290R8V1xdVm2VZ1rg2YtzKRczPCCHQWktR9CjLkiRJ/m23AOL3+fjX"
        @"C4GUV6gQkMKMZPBN6iWJVyROZsoLlyjlnHc2SweNdwHaZjRIzL2vv/CZX5nffoHq7rcJ9jbO7eJo6Q1XEekG+1+7zlf/0bd5YG2DfrrE1k6NVH2e"
        @"+cZzyKygGCxRLyxYibSQas8DD1yg3x/w67/1FW7vCCZNzptvV6gEnnoUHn5wzIn71lk7tYLPA/nRDezyUQYXPog+9Qjo0+BOobN7SfRRrM+RDEB6"
        @"8vomVy9/i0zWjI5uxGw/kSAwcTXoDKZt0FKgpST4uDM/wKVZF4EpUnbpuyKAs93ANNA0bZz+5zkC8C6glKYqK3CePO/hXMBYh1SaPC/Y2dzijbda"
        @"1rKUgXfkUiCUojXusHZLQpwBBDwutCSa2Mu7+OuiNSS1w2xNsFtTioWjvLZFffEGY5EhJjWi9gjjCV7gQyAeL5ExHnxUPjoXCEKS9/rsLCr6WpAk"
        @"CkVAWIfu6Nu1c+hewds3ayz7HLv/LPcfW2fv1g12Sphby27jsc6ztb1DngfOnT3F1p0dvBeQ5EghaWclWgSC8jHKPRjyXNLTLVubU+45+zQc/wg0"
        @"K5AskUqPdJeh+ipt+R1CeQe7t0M6Dyz2HPnwHMPVeyFb52/8zf/55bS/dHt/Ue4qrV0QcbAtRIjaFiFibqUSGEWUSAeDwsbhr1con5I4BaFBKI8N"
        @"jvHSyg8ql15qFwYhQpOmcXPkrY2XAD5+30XcCEWpjTi8+cXvemvhDzvZuENZBxIIcqqCH6ng0N5nysuR8irzTpGn4+lkusjatiVN4I03X/jVZv8q"
        @"qt2kmd6KTkIFvWKMyDZwl6d89h+9zDjAcLTB9n5Dwphvf/MSqAIjBdZaRAjkQZMFyYXzZ8mKgt/83FfYL2FSSl5+Yw4KPvLRde5/aIkT94w4fn4N"
        @"25OE5VXC6kny+78LVu+H5BxenCVwCuwahGUUyziXAzmcvsDg5AWmew1UoSMRO0JwEDyqY/MbY3DBo7pbPZZzEYIa9+jRiddUNeV8AcYi0pQ0TTHG"
        @"0LZtfCh8VNxpIZlOZnhv0YlEBAfB4l3DkePrOKByDRawLsZzhwDOQfCSunUdEq2zALceYSWYALXBbs3oLwKjaWC4a1hbaJamAXl3xuLqnZhZGAIO"
        @"gZEBLxVBCIgdWowFhygyCoFcJ+TAtG6wKnoSBOAEBKVoq4ZcZ+Qatm9Ztp97gbyq+LEPfYCnj2pcBbqBupXslvDVb11hv3IcPXEcby3SAyaQq9gu"
        @"7u3t4QRkvT51bTm2cho5k7z8O9+ASQNJn3Z6F7gK5bdxzau4+irK1ITKQgvLvWV83WLriv3tTZT248pW13UmGy+i3VeGgPLvlOBOcBBmBYSOJygg"
        @"pAifxIvRCxI0zWL+pNaKre27XzXOT5Osn+VFn6qq1r11sYJsmkx0L7kQgmq++H1v/z+QA8AL8Xt+/Bu+/3ihsULjREYgmcZBiG2CcFteQNOIrDZ6"
        @"PeuNR2me0Cvcp6g2me9co9y+TuZm9JJAXgxJV89iLk74jf/5OUIDJ88/yOu3d5mKnItv79C2BU1IQSRU+/uMtES6iofuP0u/n/Mbv/MMUwM7pefi"
        @"1YZ+D7778SEnjmjufeo+ls5tYNOW0bF10uP3I+/5CIzuowqnmLenQd+L0MfA9fCtQpDFl99lcPQcy+c+SDUrYC+Q9jVBl3hhsaZBKoXOUlpnuygv"
        @"dchMAk+ioiff+4j+tq3BGUNTLyCEw/Kvrhu8D0gkwYNWCU1dY42J0eXBE1yDsTWrG8tkOcxMjUNhbHdjyAgmDVJhfcA40R0o4EwgGJDWo9pA1grs"
        @"1hy/VZJOLPb2PunUsqKH6FrQ1gYTAo0M1DJglIhpvMETvI84GOdAxXFwaC3jXDE10OAJQSBR1A4q5/E2QOM5tpKiWti/vs3Nl14ja/b5wcfu47v7"
        @"kFuYzDwLmbJXwm9+8dt4rTl94QSmnpGEwKg3BCeRKqc1AikUadLnzs2SjcER5m9/i+rrvwpyhzTfgd3fhOZrKH8LX+3hpjMKrzGLBa5pcbWhmdcM"
        @"iz6LcvbTKgtZ0GYUZDVCNAhsDF71omsHApJA5jypEzgSGlkQfJ4Rsuzg9XSNZnV4LBNty/JSv6mkyRbSTJ0QCJFsZUnKdLL3dL/IGylBSpAK0jSh"
        @"rSpkiIfPu6dyUWIWf/SHWgF4ET0ATkgcCieiMchJh1MtTrpmMBp+yjmzhSu30jB7+IVnf/OXJttvoMUc0+4i0xalA1mxCrOEz/7qK+xehfsunGVr"
        @"2mKSARfv7LI5r3EyJ7gcb2DQz3Fuxumz66ysjfnqs88xb+D2Hrz6JvR68PSHN7jv3mXO37uCHkr06gi/skZYPYl68LthcB5jxmTZadL0NK3NI+ZG"
        @"gkwUbYd78yIHtcrS8XsR5NQ7u5BLvGgJMmAO/f4JSqkYgOqicueghBNCHGoEhA+ILizVGINvKrTWJEmCadpY3Yj4oPWKIvaFdRN7ahFw1uBMxXjc"
        @"Z/lovOgaoLZRaK21ImhJkHHl2JoYzkqA1gRcGxA24CuD8BLlFcGAIiUjw84amv0FwUHTGowP1AKaEDAyYEXAeX9Y4XRFDh5HXVYMih4NMK/j7EUo"
        @"jVUSJyRSpFTTklHeRxiY7UDqE26+cpV8ts+Pf/ABHs8iqmG609KEgtt7hi9980WSfMCJE8fQ0lGXC7IsYdArqBYljQkk6RDnEnwLvWC48q0v0D73"
        @"GUi3wL4N4iY0d9FmQajmSGtJU0XTLlhZXSXXCiU8ly9dOl3V0z+dFGrDS3sqSHvqIElIEqK8pfuMdTDozrIdkHgBXobGSjDSY4Sktu55ZGB37+6n"
        @"Bj1IZUU5uf6fjwt3wbtq9Pyz33zmG1/7WsAHnLFdd2gZjUbr/9YrgN+vMvh9agCctN0HWCGwElrtabXB6orZ4u6vZXrBSl5+8tXnf+PlrStfZ1zM"
        @"WTreY+XYEDFW2DwFucGLv/Uaty7CYw+epSwld3dLbm7NuDspMVlO6T256pN4TW0mrJwace6B4/z2V77AbhlLxtcvwXgEn/zeIcfW5tzz4BL9jRw5"
        @"kJRpSn7PU8iHPwGsYduCJD2KDH0kmrRji0Rv7Zw0605emQFDhkfPMFwbsLlzDUwVHwYh3nnpBRT9AiTUTYVS8rCcP2BGiBAPAXwgURqlFFVVAZBl"
        @"Gc45TGMRPmYmJDpDCY1tWry3KCXw3mJMi84VR04uRU6fFFRB0DoLKh7OLR6PoDYWbwNCKBoXqI0nGIFpLNOyoUTgtaZuW3YnNS0S3esxqRqaEGiF"
        @"wIbYNRxoPkM4iH0Th5aQA4ekTDRawP7c4oSkRSJ0hlQJwgvaRYvqGLKTBdg2oWjh7iu32LD7/PgTp3k8hYGH6aLG9ca8ebXiq8++yrHjRxgONTLx"
        @"pIkgkw15ErBO0BjJ+vo6i8UMjMLt7vPab/4dePVfQNpCsIR6QRYahK8wfkHrKkQaMNUe1WKLZraLyhSZlNP5ZPp0p34mCD+K4FZ/ONuJEpjqYeTi"
        @"4cQbdLAEVTetbmiVo04Crh/YMZNTcqhPDYbpy2G28/E1ufip9XT7r375N//OxV/9R393srq6wmOPPfKIkCH6SPBkWcLe7va/dPP//+0A+DcfIToQ"
        @"JrrEgNBxAZx0IKqH83T6U302/+Yrz/zKZ/LqMuy/DmoLVgNSLyhdS3byXrZe3uRrv7PFudNrTPY9WzsNxiRMpzXOBhbVPA5h2pYUz/qxFe576AJf"
        @"f/5bXL5RsrnvuXQF+gV8+EN9smLO40+cZLyeky73kMsbjO5/Enn6MTwrtIzQ+TrYDJxCuPBOrpYClCTgkNqALMFPYLXP8tFlduYLqGpynSAR6DTB"
        @"OYf3Hl0UCCGo6xqkxBE6AEjnAqSbA1iHDJCnGaazEuc6IwQRqwIfS6yDntC5btfe9dXWRg36eG1EC5RpwlxLquBBxpWS9Y42BGpju129wnmJdYLg"
        @"40bBhrisnSwqahcohjm18exO56hEY33MKYzlXtw0HI6IO8SZlpGrLwI4bOeQjEixoDUt8X9tjadqW7xzJGjGvYgT25s2iBb6Bm6/cYdhW/KTH36M"
        @"k4CwgfmkROQFb1zb5OXXL/Lgww+R91NsKAm+YWNlCSkEbWupGoMUCW3lSY3E373Dxc/8OpQtobIIH/8yBwe2lwKdCPb2r1JPb1LuXmbnzW/xyvPP"
        @"/fxSf/zLwmevELLrATU92PPLANJrQOGknDoBMkiUBy9iemsQHoFFMx8N89nTurn1nyfN1YvXX/3tz3z5N//uL/3aL/8t9rbv8NijD/PA/fefzvP8"
        @"FW8sUkpsG9fEvV5v69+6EMh3J7dSCiklMgRM00R/+O9rBoyfpAg2U3inhIwWUaFpmvLhYeHHl1/6wmd+5sc/9GQ+ewO2XsRNLqLKK7id19nfv8H6"
        @"yhpsBv7B3/gax8dDVDJid1oTQo87d3Zp2oaiyNBBkApHSks/D3zoux7i1dcv8uobm8hsmRdeWeAcPP1Ej+NHUh567BSrp8ZY7dCr6yT3PAHHHsHL"
        @"VUrXQ4gBWvZBpOAjvERKQNoouQ0pSIEXeyixBe2rUF+jFxrefulFkkQyOnYcM5kTAkgi9EP5gwG/wxtLohOkEEQXbbeeC3GA0tQNSarROqGqa7Is"
        @"JzjPfLpg2B/Eb7DUONPSNA1ZURC8wDpL2xpkOqB2BS+9fIuqiS1CD8+wyGnaKE9GKpQQpMKTyNgWeOvBOrTOCErifTgUrDjvcT5GlQUkSihMbdBC"
        @"4VtPIjXCBmSQ3e8vsN18QWuFNQ6Lpxj0mC1adDCkWYqWUdmYincUj0EnbFWGPMvZSArqaUMbYFaWrC6lHF8ecXNzytR5auHJl3rcuXKXYxur3PfQ"
        @"ObZ3bjHMM9qqoih6hGDxztDv9+LnZDxHB6tcu3yLrBcYnt6AckZb1ngnCF6BBWejmMt4R5IW5INVPvzdP/K52vR+xYV+k2bjJ5u2vi0IpFmG9QFC"
        @"74LzcqGydNd5tdU2OsvzwQMes+W8yZKgXOaqC0vs/pWs3P2LF5/9lQ//7E98hMuv/zblYpvj5z/M933yp3/u5//ff+u/EDK5FA4OVERcA3dsid9v"
        @"E/e+KwAtBP1+byR8oJrPR957BoNB7Fn/DYaBeZpkwtlTRVKMVFD4Ot6kx1bXxt/88uee2bn2MmJ+lcnVb3Dzld+haK9j9t+iKW+SSY+scv7J3/kc"
        @"AwWJGLJoLJWH3UmNkin9VCHqGQPlGKeCftbw1JP3c/P6Td566w7Gj3jh23uM+vDhJ1fp9zz3P3SG1eOrlEKSHT2JOvsArF3As0zjhyRqCa0GGKdw"
        @"RoFIEBocDTa0OG2RiUWIKZob2PbbmP3XodmC9VV64xU2b2xDA1mXkSelPOyJlVIkSYK19vD2913PzOE3Fqy1tI2NnL4QaOoarVO01iwWi9gqhICU"
        @"mra1UYpqHc4LdFowmc5Z2TiKyeC7Pv0p7JE1dgLUaLwH1bUBjfA0XmBdZ+v3YIKk9QLnBMGBdzIODL3EIrCHBWd3OPqYPiT8AU8o4EKXmCNkt+GI"
        @"Y+woSfZkAmZNwEmF6SoQpIoVk7FkOiHRgu39Oc4rRuMhCJjuwPTydY7j+OSpk6wDbe3Zm5V4pfjtL3yNSVVx4cF7mS1mDPoFwraMeznW1QQZ6PcG"
        @"WCMoJ4Yjww1e//Kb+IvbkCzhSFBZH+MFUqUM+kWs8OxtRHOVXm9On/ITq7n8032ZZNW0fDlRCUmesSinF8DibHWp0Okj5X69XuiCQa4bV25dyszO"
        @"Tx9J5z81aN9+aU1cvfiN3/off+Y3fun/yubrX2T/1kVSnXDfA4/z3R/90b/UuMEvedJXQveSe/HOcP3fWIfzvjd5IbC3s3UqTTSjYX+qJJSLGcHb"
        @"31clCLC7s/epfn+0OZu2DTZh0Bs96at2vZ3uvzzWoOspYr5FZnYYJFMStlBhgi33GQ/XuPTlt5i8BSeOnKUJgrKpKduG3ekMpRQD5RgEQ882ZL7i"
        @"gXvXsGaPty/dxDZ9rlybsXBw3wk4sVby6JPnWDq5gl4a4XpLcOoROPowFEfxro9qM1LfQ4U0qrhkjtdZx/GLQz0pLZ67WF5j1n6Zev5NmF+D2zdA"
        @"SjZOnmP3TgV354ikT9vazgHZrb2kJE1TnHNY6xFCdYOyqPjyjsN/1zQGKTVKKJq6jtl+acp8Po/T9RDjseKB4SEIpEi7zMGUt67f5o//3H/Ij/31"
        @"v84T/+6/w10hqVRG0R/SNAETPFUIlMHROA8uhmMaJLULhK65d8Zjjcf6EDcIQhJErA5CIIqQfByPWARGSqyUuO7GkgesAwneW4T19HuSmYPWR8Wg"
        @"lBJLACWxxqAQDNIcAyw81EpRE2Es5S74rRkfObLEDww1R4F2GthvHHMPn//SNzh2/BwnT5+Ks5a2JROBoh+YLG4zHGiC8mxXM4RMULfh8pffhFYT"
        @"ZIZM+igd85Vt2zDoCdbHUE8ucf2FX+fZb/wqbvfSX03b3QsFpkmlRHhHwFyA+sKgZ0ah2Xl+Nc3JmvbJxG1+vK9uffa4uPuLr33pF37x5d/6i4/8"
        @"07/9H7K4+WscXdkmzS3Z0hnOP/Efce/jP/tzldn4r7QcTAlJ9xofxJS/8/F7qnCFf8/H+1YCKgkrS+NXmqpCqKhKy7IMKWWETKjkX4s7WFlZ+bXF"
        @"vGHUXzo135+MMmk3Vwp7r53f/Jup2WIgK8pmFyEWjIaKIOdkqSJfPs78yj5f+vW3OL2xgXeaqllQWUPbWsbDAYV2jBJB1k9xXnLsxAbHj4155hvf"
        @"4s4W7M8V2/uBx873WF0pOX9uwJkLS8i+ZyFh+cIDcOw05APwDi09SE2wJg7YkpwGgfEGGSxCWLSsEUyw9ip19Rpt+SJZs4MoNfVuTS5Tjp88wStf"
        @"fJ6tW3usry7HF7XTwwcvQIDqNgLGGDKdHG4CQogtl9Y6vhA2rg211pjWEUIcDs6NxRhDohRSaLK0YD6rGIyXcHjKyZx0PGBzvs+f+NmfhMax8ugH"
        @"MRvHeGtrm/uLFKXAEuLK30GjBEkICAEGgUcivEVLQQg+xpTju7yHbmDZVQKeQCd0JYg48PXhHbmY7OYBUgpsN+js5wVbiwXTqiJLCwQK61uEDYTg"
        @"sU1LT6dUVCxsg1NxiDzsZVSThsXmnCxc4/vvv4e3X36DaQ31AqocLr21z1e+8gI/8gNP8o0vfpa80DhbkmaOIOH25i2Wx2P29ysW84ZTy0e488Zd"
        @"ll+9zsojG9hyRlIoUpHjFnPSROF8Ra+nqMpr+M1neem134DkzMsPffB7//z+vH5a58ml5QKEmP1MNbv67630x78Q5u3D+OqjL771OSabF7n1xhu8"
        @"+pVfZnk04eSRAjlY4e7tGtKz/PC/858xC3/tUyE/9VWsGDVtPdWJJPKz5eHNH/5X3Ov6/Q3wfNxH25DhQSdZ01RlliRJY60hTTWuuzF+918qbggk"
        @"ZdPGhBtTXX/zlefDKFsg7BbU12D2JmlSoXqCaVVS2ZLhIEHoHvgVPvPLv4m3IHXB1vYUh6CuDN61rK4O0a5mqSeRSpD0hlx46DRvX3yV2Rxuz+HS"
        @"FcfZFTh7UnHi/ApnHzxGf9BQp57lC4/C+fsgTcFOwc4hWQWpEPS7p7Yh0BK8QrsEpSyEK7j2Iu3sdUx5jSzswWQOi5wEAeUEsbJEr5dz88Ym649e"
        @"IEsLnAtxNB4CzgZUklDkfebTRawCUAg6ye5BRn2SUZYl1aIiL/oopeK6r7v1m6Yh01kUEamUujXkPtKBs3zIrb059334+3ArJ/nGyxepRMbJj36c"
        @"13/lH3M0wFKRI1uHDx4jJTWBAo8SAYfEhUAqZDflPgjK7KbeiChzDQIrJV5K2sOOVHRI+ANhTNQ4hM7aLLpWKNU6tgFzx/paPCqCDfFgSzRN25Ap"
        @"RYagNAuK5RWEzZguLNpDogR7e1PyTPMj959m/p1rvOrg7iacP5rz+c9+mw88eIyHP/ggL37zJfIsR/rYNzfB0HrHeLhEu5ihREGmE9785i2++56j"
        @"aC0IqYVUMy9rxqMlaDzaBnqU3L7+RdbCnGz1IV595R/8PNkQkDx073fx6lufx883CeXOn1aLHZryGq9+5T+jcY6l5Q9w+sGzqKPgr93ijTcaTj3w"
        @"ST70A//x57bN2md6o9Hn5/O9TIt8mvd7o9ZU0yDk7yrm39sSRCVg+JeAvO97CCgIpEqQaK3jAKfVRV5kddOgtXZt04yk0s17xYcHfUr8eaIEyhsw"
        @"k0/+3E//6J8o3DVEeodw83nC3huIdotmcYPG75AWgjwvENkab/7OK3znmQXnT65gGk0gYTpbEKRmNMxZWQpceOgY9zz+AL31IcdOrFDVJd9+4S12"
        @"pvDmdcgz+MB9gmNHJQ8/cR49EOi+YnDiKNz/cHxQp3dpFpv4ZhfcjODaSKNNcoyzCGnRokGHGsIdqF/G7b+Cn18ja/ZI6jm6tsjKg3HYZo5aWsLf"
        @"2efiG7e498LR6KBrGoKLdlxvozNQKk1bNVHuK/VhBXCwk0+ShKqqaNsWnaQAtK3peuj4omRJBkqxWJSEoAhC49GkaZ9Xru3w2Kf+BFfKlHztJC+/"
        @"8Tbry2u88vyz5IsJhTOkQaF86JyGxLkLMbotBBkLTRmVbD7u9t41gKLzc3iEVDStQ0jxXhxciJoG1W2qAiKizQLR2CIs8zYwThWpUgRnEcKTJgnW"
        @"moMVG4sWer2U4BRt1UZOohIEEZjOK84eP0qSeS7t17TEeYRSnq3Ny3zvx76Lpq0oF1N6SY4zjqzo0dQNg6xACjDO0RsV7O7NSMOE4blVROIwdUlv"
        @"PKQJFlmkqDyh18/oFYKd7auU0+vMt15n/+6rVPsX+Y9/+mkWmy+yde0b7N19kenuJRblNc6eGXHi3tMsnzyN7A+5++obXLpWcs8jn+bDP/Cnnt/n"
        @"6E80aul3jLOuN+hnVV1m4KYxsVYcLvp+r5f/PW+fCO/5+ftuAZqmOSUFPP/889eyPOfhhx/Z6OV545FkWTZ14V83gPDQtpkSi0/3ssmfc4vvcOnt"
        @"Z7j3hKa59iKZXLC32KWmQo41SX8ZIQYsLk956fObPLiREAwYZ3A2YTE3jJbGDIeSwdqcez52Cv3R72Fpf0b4zkt87Z89w34NFy9HR+Wj9/c5cbTh"
        @"4QfWGPQSQp7hB2M49yBM7oIrKasZjZ2TZgpl+1h5m1wtovRW5OQkiDCH9i4srhGqt9HlFknlwGpc7bo9v6GuK4y3pLOC0xdO8s1vvsXly29zz5OP"
        @"4v0kKuOEigw+45FSxT+naUjStBsERj9A0zT0037sQa2lrlvSNH2nNesqgNZZtEgIQcQy3Et0qtndm7K0fozxmfv4+ou3efDYw+yXnmNHT3L8iafY"
        @"/sJnODfsoWYWnMBIaAk0nXwseA8erHCozpsQsWIiRo27jvUg5XseQumi9l+EWCm4AM65aDg66FxlDEMxpqGX5UzmJVVTkyvVrTKjAEpKCLSoJAaP"
        @"zCeGYZJBmtAmjqmxYGE8Knjr5be58MB9PDFe8NykZbKwJGnG1csNv/mZr/ODP/QU39y5S9UGhv11FpO9qKYrHUmeYVSFVIqVYsi1l2Ycf2ABp3ok"
        @"vT7lZA/dHxKkRMuUdjZHmoq1scS6GV5kmJAx22lppaDIUoa+IV3aoOqdZrR0iqQ/hkEC11/m9o3XKe1pHv+Bf5cLD35ic87SLzXej7NeOjVt2kzm"
        @"TTYc9afWNODU77pcY0X2Tkq5f8+BIN+zv/sDOAASlV4f9PKPf+ADH/jod77zrWe+8MXPbkpv+OFPfOzPpzJkEj/2yIkje94L0bz7j9eheTIT858a"
        @"6uqjz371H7Lz1tcozBvcfuU2IzWlFTVFrugPC8oMKluTD07x1c99FdXA0tIau9bhkpTNO1Okyqkrw2xiOHI8YF2Flg2s9rl56y637s6YVAmbU8Oj"
        @"FzJWB56zp5dZPVIg80AoUor7HwDTUu/fAtHQyyTOzsiSBC00c7OHa7egv0MqiyivbbdoJ5do966g223y4KHNoDIo0giqbAwS0N5T3blJsXKGpQ24"
        @"euUW9zz+RCTm4tAyx4uOq0fn9Cprso4bACr2wsaDF2ghI6q8bdE6Ramk2xy4w11+sAqhU9rK0JOCNOnxxo3bPPLJH+Pmbkk6XKUJ0OqEfRc4+8RT"
        @"fOWzn+HarOKUykhDt4FwDisgcRBCHCia4JBKIEOUuCjftQBBREmylIdPY/Bx7SdC7PlF6LiHPiLHkPGQUt2veWNJsxwNLJrAsPAkgBKaWWPIim5l"
        @"2sY/03ofjTAu4IQlSUBrKBcVPZVR393mY+fvZftbr/BtYDptGK4mfOOFS3zg8fOcOXuKy6/fBLNgVIxo6wVWeTTxAHWtp5+MUdTcffMuR47dB4lA"
        @"La1AkqDTAkzAt5a0H8C2JL4leMMiLNhYWSaIHqaVDPtnIV1mdOz+iK9zFvfaG9y5e5d0eJp7nvr3uee+H3imlOv/ncyWfk0ZSV2ZkZApOkm26mq2"
        @"nmo5DUI1BPUexF78YsvDl/9fPf9/v0PAoEh0MZrsz57v94vm8ace+ZlU6+tf+Z1/+rl//Lf+7z9/ei1lZZSh1o7z+IM/gCiSa1VtTusEsr6aPPul"
        @"Xx/L8jJu91X2n/8f8bM7LKmEbBgfYCsCPtXIfooXNSvra2w+e4mbb8GjJ1dYVIE2G3Dp+iZNI+glGYkQCGup9+DqNy9zvyyoKsvF566xv5fw8muG"
        @"o+twej3lzHHJuXuO4pISmXmKU8tQbVJu7SI0JKlAVJ6+T/FzhfQpRdbH1Q20O+g0A3sX5ndImwmz3VsMBgW2qrGmJUsSvAEVFSOkJFgXqMuKYs1z"
        @"6txxnv3yLcKOIe8VuMU+7aIiUWlsNdIUkh5p1TCZz1gejTGtx1uHEJ1kVedY39K0nkYbkiSLZbYUIANNa0iynDbkeB/A1MzmFbvyCKef+BGeu1Mi"
        @"pWLRLjDCceX2TZ48fZ7i7INcu3aZXpoyxDHWAaooahRJ90qr6Dq0XqC7mDfTrS1F94CFELcWwXt0qmgax3iY09YNUspoBlLRnKVU1Bw459DxfKGZ"
        @"z1lZTrizZ1gKMbTENpYkVdgQQappplDeMbM1I5eR6QzTtmgkzseWJU1hurfJqMj4ofvPsfXGZe442KsNPoFf/8xv8yf//Z/gbm8PX7c4bw5fqNls"
        @"zrHVNZpmQjYM5MUSeze2OLIDPHQMSUXrPGl/CVyBDsP4XHS9uZApmR5i5DJOnkDrk1DcA/koshTqy4Rbb3Lr5ib58lOsP/SjnH3gU7/QpKd+zvtA"
        @"MBLp80xJmQXZTBENhQ+5sC63wl9/93xNhnddsSH8Kxd/3ejl/VcA07KiXxRTK0oG49Hny7q88LHv/75fvfadz/7E1Re/xN1Lb9HvaX7rH//X6CI7"
        @"nWeSvf276FSO77z+j6n3XqfPNj23TZEasmQJUo3TApXkSF3gtWRlaQNqxZd+6w2WBlBWgay3xN2dfeZtoN8fYVuLVPEhu3NrxtEjS7Q3J3z5C89y"
        @"/Sa88kZU+t17dp1Bb8Zjjz6ISg2qyEmXB2AqmFZ4W+GNR4sMoVOk80g0WIlzLTrxoGpo9wjTK/j5Dqq2pN5B1aBlgvUVxnq8c/FJNlEF5ytLKhKY"
        @"Tzhx6gTW3OLa2zc588F17GQbrVLonHy2bdFZSprmLBYLWmfxLlppg4sW4FymBBQISdt4kgS8dcjOetphZkikpPIgVcFbt3Y49+RPMFFLLNoScokL"
        @"PqoXpWTSOs4++WG+feUaKx60FhTWkXfFZkDhQrzS5eGEP470JTHpIoi4BBZdOGl4lybEHagNu51/F2rQzRBilaBc/DIoLXExfIi6bejLPN7GIQrN"
        @"UpVHi7FwWA9z09BXilQohIs3YGsB39JTEre3x+rGGt99ZMBn784pF7EOvr0V+PZ33uDIxjrX33qLTPVARyWmzhKcMwgFKEtWpKzoZSY3p4zvvY9k"
        @"sBJ1/MkYmY7AroNbBupYmogeIVlFZ0fJi1NINoA+MIfpVSZ3XmN25xYyO8H6+U/w6Ac+/ZcqVv+qDQmaqO0nyJHgYLsCIsjJgcX39977/xugxoN8"
        @"fweAkwE1UNMai2vsqYVxGyLLnnfZyn91z4c+/XcHfvLnvvEbf+8TN978ItXeCyS7d9nfv06/J6hCIBvkZGlFkkEqEzKZRBecjGW9TDRCp6TJGPIV"
        @"Ln72eeY7cO/aSQo3pHYpO9szhNSUdUWhEsra0sskRmiSfMyL37rG1StwYxt29uGB0zBKK+554CSikKATdAKkGWFRUQqHzJMoyXSA9DE0QgV8sHgH"
        @"Gguuot7bwk73EPWC1AZUgMVkQX9pCeHiS+rbiDwTXiAdBOPRaUq1P2F49ByjMbz66quceeKHIHQWYGfBC6xzaOVJ0xThA6Y2KKHirSIEVWPQ4z5W"
        @"p+CgaRryIiV4SyEEqYs3INKigkPgmNuEmzPBD3z4e7g5WzC3gUymyKBjvJdI2CkrHvzQU3zzX/wz9po5G72MyrRIoJbdjj+IDtsWP+/wrj40HKz/"
        @"QlzXHRAADgpS535XHJaIqsDQrUKFkAQdKwEpNMYb+gksFrA0Et2mIaC8RONJpCCXYAWUriXVOVmS4UxFUPGRCiaQJIJFVZKUNfeurPPm3TkvObCz"
        @"lH3d8o1vvcmP/tBHKZZ6zGcNvTQF7whCsOf3yAqPkJZUScbLI3bmhvEsg/4pknSA1QOCWML1DbKtOvelBDkmTY5BugxkwAzaN2H+Oru3v8liVlEM"
        @"H2Htvh/ngXv+2MumOPnzkkCm6gzMBdDXnRRbMkTVqSLBoacBT9wAvA8gz/utAEywyERmiUqv57L3vPDZ1ITeKzM//rXNeviLT/3wH3/+wlMfZ+Fa"
        @"lpcl5+4bsHG04cxxx/ryguVVyMaS0EuxRQ6jFFYGqKUxYWkF11uBtdOwaXj9G3e5cHqd5dUjrB09wp2tzYivkhmNNdjgMc5iAxw9dprJPPDCC3eo"
        @"Ddy8A0eOwNoITmyk3PfgaYy0iERGzn7VUpdNfFCEIlMZ3jp8p7OPAzhDxPW1MN2h2t8G0yKMi7FYQVDPFmA6Sa/1SOsJxkYVnJBIBMFYTN1ACNx/"
        @"32mu33CwOyfLl2jaNkJNEYSgqKsm3uBJRtu2h4pBrXVU3gVPSJLDvtvaNnIGHSg03kKwAY0nzXJuTB3L93yA/Ogprmzt0EqNzjK00OAkQibsVzV6"
        @"ZY0j99/HrnMshKCWikrA3ELlPV5IBKq7jX0HI33nNjrYAhz8mn+XBdxaG29/ESuFA8Wo6xBhB1sCr+JMQHhBL4ueAIvHqs474EOUJNtAX2dkKRjh"
        @"aRXIVIOSeA9JAsFGulKRaJrJhHxe8vjRoywhsabFhYybW4Yr165y5Og6XrR4EYNRna1p7AKhHVLFZ0FmiuHSGDtvgBFCXcCG+7Gcx6cP4pPHIf0w"
        @"JB+G3lOQPgCsxpe/voTbe57F9rPI+jZm3qD79/PIIz9ei/H5P1/aZEsGSPEjgR8j/FhiEKJFBYn0KSEkOKHec/D+oRwAwZFJJxpRm/XcqdFIji5o"
        @"38OKArVy8jN3/fJfeuQT/8FnHvy+n+Ht/T53tsrYRGYKNSzQvRTd6yN7K4jRBn5pFbe8ihuu4XpHSVbuBTa48+1bLCvF8WPHGC4VlHafO7u3SfOU"
        @"tnGMB8s4DyKVyDSjyEe8+sp1pqbHm5ehLuH4Ws54CI8+doLWT+gNNSLVSJ1iGoMUgkRIQm1IvSK08YE8mOIHZ0gSoJnR7N1FNQu0sSQelPUkSLCx"
        @"DVAuRM98IEbedumbOghs1ZCgYWePB+47jzFw6eJ1KFbiwyXp+mZoW0uwISbXWo+WKpb4MlYBjWmRicSG+Pds2zYOAh0omYPIUCojUxKhEy5PHPc8"
        @"/UPsNJ5FEDilEEmOFGmU9aqUKghuzKc88JGPMFcJu8ZRSU0tYO6h9j5ahUN87YN/R6ocwsHh9V7Z8uHhIMG4QBAxxCTSDgQ+CJwHbwPegRMSL2PO"
        @"YXCeVMZitfYBpwRBCggH9mhHoSS5VpgApTdYAqLbLNiOoamDIEs0um3IpyUPjUY8UvTpAVXZ0Fq4dOkywTSMxwnWztDSdB4SEG2gJ/sUyQCPZLg+"
        @"wMgJaAHyNEI8gOcCgXsJyYMg7wd1L4g1oMHyOo39Ak3z29j6m4jyGkndsrF0hqUT38VMHP2JXSc/b7VGCTUNLSiXf1X45Dp4JAdeEZE5KXHi/RP9"
        @"3vcBkOZ5s1hUo17ez70NU1O2l1xtshBcNq+qxiSjz22b4S+eevR/x6lHf4yFOsrOIoDOIctIxwOy1WXS9WOo5ROEwSlsehafP4juP4Qc3IedBm5c"
        @"3+Kes+c4f+4keSF48/KbeBVZ+t45BIosyzDecOzkMXZ3S27frdiZCa7twfmTCbmwnD+/Tn+c0LRTEBbrDYHoxEukQnlwTdtBQhMUKmK6D0vzFltN"
        @"cbMJmXeIuom3vHWAINcJzWwevfvGol18AoNz0JoO1+VIhaKaTkjGI9ZW4LVXr0ALSZYfquacl527z0Ul3IEnANeJfQSuKUk1SC2QicRbh0LivCAk"
        @"aWxBVYKSKfulp+mtMT73KLd3F+S9AV4lMVQzRBViQEKScWN/xrGHHqJ3/AR3moZZEDRKYgTUNsS/Y9ffO6K/34VOBfiul16I2P8f/DspZScVjhXL"
        @"wSHhRZQG+ADGOwwe37kSJQoZJBlQmRYjRKReAEoJlAhoH0hi0U3VGGrTghAkWYqLKe6I4LBNTSZgaA3ZZMIHV8ecAqYLqBvY3YZLF68yGAxQIoCP"
        @"gay51PjGkqiUYjDEpBKfpcjeCNQQWEH6je6WH4NYxos+6Az8AmMv0lTfIVTfhuY1qLcQtYEqJ1MnuHDf9xB6K1/db+tPk8XhYSLSHJ9BSA8He13/"
        @"PwqHQJ0/xAMgIGhaP0r7w2nt7XWd61PWG/KcZqnnR5pynCZqWtvic8nShY0nP/Fn6R39MKU4wu7WAto2fnhA54RsDZHeh0o+hM6+D519N7DB5s4O"
        @"xdqQY4+eg2MjdnZusL1bkhcFwgd6WYptDVoJlkYFRZFx9cY2i0bx5tsLRimc2VhifaQ5d/4EtVkw6PejA89bGtugJEjvkD6W8hiHPDSpCLRUaEF8"
        @"SqqaxBlU2yCNQxiHbyxYT57kzPanYAPSRTaAcMR5gPNEvo3ENQZvLLiWe+9Z4+ZVmN6dUPT7NE2DFNGQI0XceYcgSHXM8NNaY62Nt3pbkeGi6lJG"
        @"j4BzAaMSfJIQutuyFQU391vOPP49zGWf/XlNkmQkSUbeH8RMQRVNNzLNKJ2lThLOP/UEe8AkeFqh8AisiQUNQhGE6lZ+HJJp3713/pcMYYcHQGwd"
        @"XIgVQBdYgBASYz2N851zXh4mIvcSSdmCFZ1sugOjeu8RzpIJQU/HAXhtLBaBlJpEd4eLdQTrSEIgweN3dzgjAh8YxSqgXEDVwKW3dqgW0CuGmI5b"
        @"kKEpVIJMAr4QME4x/T5qfA/I4xByNApNZCZK0SDEHojr4F5B1N9C1y+h5lcRsyl+prDlEm11lCS/l7Q3+sXa22k+0s80vjolpcZZvUnICCH5XS+s"
        @"nyJ8nFO9z1zB910BJImatm07ItMsbHtdF4rWNISm2UpDyETtyGRvazYLU6GWfn44vkCen6TfW4aqxRmDcy0+8YheH5mfQecPgHwIOA3A3t42J+6/"
        @"AE89AbMJly9dRqvIrBPBMygyslRi6pp7zpzm7t273N7dY3O/xAMP3buBcFPOn16LKyOlaOYVWkSKjvcu3qbGIJxHdzFZmFh+Yx06yZA6I7QW6RwJ"
        @"IKoa7QPSEysAG8vwuqwgRLWZMzYSfLpeV0oZIR6LOq5smoqTJ48zm8HdOzuQ9Wlai9RJnBlIibeR9KK1pm3b7u8c+fIyxAGfSlVceUlJaz1BS1Cg"
        @"pMULaPSArTrlge/6fnZrgfEKawJpmlIURfzvtcI6j1cKn2RszeacefQxyixnFgQl4IXCxoVG3Bp0t7Y7sOiGbiNwMLHuPm/PwS0vDrdT7pAIFCcE"
        @"UimCPICHeFw4AKYk4OIwtOnAInTAGUvAdk7CXGqGOiMRYPBYCa419LKcqFsKpKlGyIDAkqtAVs94YGXMSRVHO20L+wvY3q3I+ytYkWBRBCHpDfq4"
        @"XFFKjx6vkyyfQffPgVoDom1beY1yoGgRco9g3gT7BtpfIrO3UM0UsWhQDWiGKH0UYwc8961Xf8a5gLX2dCLVdesgyKQJiOydKX+sAOL03yJxf7gt"
        @"gCAQXI3Wfmp83KdWokWmCbSa3PY2l0TxpJyVFwbKj1LMvYNinUyOmO+VuNZE3DUtddijslN87YA1cBvxn03JqJ+y9OhjIHMuv3IVbTOU7KFkTpYo"
        @"cDVaGVaXeqjgufr2VRokt3bg+BhGScvp02POXzgGziJDwtXLN3Bt1MxLBd4aJD6q2VwUlHgb0dTBQef3JRiHaD00BmkdoTJgA1opTN0QnKNIM+a7"
        @"E9B5bCFCdGqZ1uER6DSP7jjjmW5vsrG+wckT8NJLr4POKYo+bWOjMehA2ulBC40xEZ+dZPFW6OUFpm7QUtLv93ECvPRkhQbZkGmLSuDF61scefi7"
        @"GR49y9Z+iUoGKJUhUAyHGTZ4vBLoLMUaj1Ypu9MF4+MnWT17jpmQ1DJh0VpAMFuU+CCwLhCUjpRbH+LBEMShH+Hg5T6oDJIkiXAP6+KL3fEfgjzg"
        @"DsrD/69q6kPkeXAgpaZIYT6vSPIC6xxWgszjMjLxgeUsp68kdRtogyNLU3xjERE9c9g6GeEJ2oFdsJx67ltOSYGygbmDq7f3aMhR/RG1lLgsZ6EF"
        @"7TCHlXXyjQeRowehdx5YASzYEmkkSciBiuBuI+RV4DK422AmyNLj5w5bldi2IV9eIzl+hkcfeeLnhFEsJaubwegID1PgVNN42cSUqPfs+0Nnx/J/"
        @"eAeAxKOCRwV7SPQhSAgKHzLwGfP5YrK6tvxkW1efeP65b32KZAi+YD5r8E7hrIh+eGVwvowPimnR2kCY4qZTlpaWYbAEN3eZ7NXgk7ijFwLvDIqW"
        @"0M45fmSFzbu71C3s7keJ6ol1xfoINjYKAjVaBRKpMA1s3tlBCo0MEJx95yvibDeMkygUuIAvS9xsjm9cbAscMYveOkJrcB2NRXQ3fNs00Jq4+z94"
        @"CWR8YQ7oPLhuduAtJ0+ssb0Ns1ub9IpxzISR8pAHEMI7+LDompN44UmLIt6ErQHhSXKNSCU+GIJrWV7uUZqGy/sN55/6Xm5uz0DlZP0lst7oXbZO"
        @"gUwTdJqAVFgHTii26prHv+/7udu0zILA6wIjFFWAhWmjWOvA28+BAEm8gzIT4j0HgCe6CUMIhz2s95E4bLuNweEK0XG4+ZBadVVPXBnOFwtEqjEy"
        @"YIgDSBmgQDFQKTqJ2wYO1IhKRhxZiBJlpwRBQ1U56r1dHhyvcB9Qz6JuYGd3ymQ2ZTDqI3JgAOlqxvDYkKX7z8KxU9AfQr0NzRXw14G7kNRxv++3"
        @"sPYWtr2Gs7fA7YErwUWSU4pASUiXliHr4T0UKqOaVNczmY+stYQkRD6m9O9sV4QH4RqBf5fo5w+rBehuNhkk2kNqJYlLkD5bdyJZb5Sc2jy9tFsv"
        @"fjlfXvnc4099+K+ichYLx+rqKdpWY30CTpCFgHINXtQQNkG+BrvPsr1zl+HqKZA9rr95hf29BQgdTUTCkuoAvmF1kNLPE67f3WFeQ7WAoyuwMnSs"
        @"LgU21vsgWqQSpGlKnvTY2Z7Gvz/v3FTgCd7gQzwQ5tMp5bxisT9ntjejmVbYWY1flIfrPt8YQhsfNoIkT+OtTNMigux0PXEE7lyccmuh49NvAu2i"
        @"4szpE9QlXH37JrIYx/9OeHAugjy7nXiis7jtUOBEiBqApEeepBSJxkti2rAKLI/6mLpmZ1rSP3Uvxx9+isncIGVK4zQGzWhpTL8PJIqgom7Au3jb"
        @"qLSgdHDq4UcIgyV2HUyCYBICjVA0UnTwD4HvXIEuvCP79f69m4AD4Ekc9gkI8vBw890Q0XaIbCEESkBTtYeHsXOOTGoUMJmXkGps11r47vfXAvpJ"
        @"Qq4k4SB5SHQx8x2N2AsIWuKkJO2nyDpwrNE8mMRBo+42MJub1xj0DEvLgRMPrHHs+x4if+QYpA1cex3e/hpsfYZ6+1dx5Rex7nkQlyG5C/I2IWzh"
        @"whwfagw1LrQYotAsNBWubtmZzrFNS572LvrKkqFIiLPDRTvPnOxgoXRyX2Hix8HrG97fK/y+9ghe0O0iZVQsASKoLCDHXppLTlq8CjTOjExlGtNW"
        @"n0B4VlZHTG7OWVpN8F7EErm1KOlAeUhKqC6zc+M71AEYX4DbW0yuX8W2NSF0sVjBkmmBay1nThzl9p077ExL9ktIApw+CkUG4xVFXiiE8HgfkdvD"
        @"pTG3tm5jqxadJzhxMFIV75BVnMO2hn5aIHSK9QbpYwKPdI40SUDIuOrrAhoUkGcZ+85HE0/eR3aGl7gmC0ghSHVC3TZxYFWWLA0HLK/A5bdv8ciT"
        @"TyFQeN+CN0ilY6WQKrROcd4SZMBJH19CHS2xWglcLznsqysrSXorXL50h0f/2A9SklO1Bi8DSb8gyVOKgijESjV5ntM4kKnFG2idYdY4TG/Euccf"
        @"58YzX2Ety0itQPiWULdk/QxFJHSKbgXoDzj3IRxWA/gY/OFDiGtO7wnyXcO896Di485eSoGxlkVdUaSx4kuEIO2ElU4AUsOB1sBbnLMoCblWNCZW"
        @"FolOozFJKIKwkUAUyxASFR2UcnebJ46f5Prda7x2BzaWIMslq8sDehfOwVjA3iabb94AqSjkEmkvIYwqmlzh2wlqOAcr0cMN4A6wixQLPBXeN+Bq"
        @"hDMEb8EYarNAKI3uL7Eo6w2VjkiUoLXlNEhDkqjGoDr1n4xtRqyzDu284Q+zAnBCYGS63shk3cqOQBLkyAt73egFNpmeanR5wWm/IVI9HQ6Hv0ja"
        @"srN1iSw1eFeihEMLCaUjcZEriGhh+xUmd15iuLQMugdvvobYvYkKJa1rwEclmDc1aytj0rzH1et3KS3sTWC5D+NcsbaRsroxxtkWJSTWO5Ce8fKA"
        @"ul4w2Z6A1yiZ4TrufECCEDRNQ5FmJGmGznLyJCVVEd5ojKEpKzBRMShR+M6rjlKkImE+XYBScZ7gOjjmATdUaISP0WixfbCcOV1w8waU+xW93gDr"
        @"DCF04SHCH4JAwkGIpAIjQWWaJA1IEam/Wd6jGK2QLp/g2qLgdjvg2PkPMKkcKsvi4K+XIqRjMB6h3o0ZcwF0gsoKRNpnd1ZTS83pDz7BtpCT2wT2"
        @"i5SqVyCGA4yI2wBkl/oTwuHneXC7h/BO/3rYvhwM/gII2ZXpIq4UoyFIkicpiRLUxmE7qbK0nlxqpCJqIGScIURakKe2NS44UinIuu+3wRNUbE0C"
        @"cbUqHejgCaZldQyFqknMPmfGkvPL8PjDZ3j44YdxrSHcvsvrv/MMrzzzEtOrc8orM9z1XeTNCepWS75tEHdvovYu0Wx/DcIrEG4h/Q7e7ePMnLYp"
        @"I64d0EogpMGHmrZ1fPDRJzdVmlxSicjaMEPqJiPYU4lM4gowZFkUQ8tOT+n/V6O//u3MAAIgLALfiINSRPgpwjXEoMOR8KJJRXJJmUA9n/5pyglS"
        @"OdI8Dt+EiEy54DxCeJSoodmm2rxMJmBl4wTsN9x94xJyuiCxAdux76MfteXkiWNs7k/Zrw2Nifr0tSVBphTHjh1hOCxoTYUL9vBBGywVeAF37mwS"
        @"WkCkBK8OS9jorW8jTqtpYVERup4+7p7BmBZTVthONxBnCRGbpZViMZ3FNaBSkY7zrlI4dPAPvECKgLclR49usJjDtau3yYbDw62BD5Hzb4NHKo2S"
        @"CRDQqUamEpUKdOpIMkeRZ6g0o3QJW43mW7dq7v/oj6OH6yzKlqzIGa0MwdUkIt7GZQtN2UTJsVagE7xKaYWkN1zh9t6UI+fv5Xt+4tPjWS/nWr2g"
        @"7RXcnMypXLf/75j21vsY8PG7/ejdNuBgOBjlwu7wa3L4691MQLqupy+KTswTJ97SBVKposuvMXHIegAkCYHGWYw3JAEyJfEhlv3WR9msEHEoq7wk"
        @"9YJMRKqV7kFaeL7/qcf41Mceoiotn/3C8/z9f/g8r79yCxaadtNitgJiohD7ltm1LfzdGrndwu0d5NZN7PYrsPsihD00Jbg5wdVI6xEmoG38s4WI"
        @"dKSiKJBSTpq2fbh1baNTiQv2lFJqs60NBLUOcvTeV7bbvvwBULnfVwugcOSu2ZIBtNed7rlpEAHlFYnrv9ITvaytSvqJP3Xxxe88Qu8tlpaWqWZX"
        @"GGYDCDENV/U8MIWwSX23ZntnxomT90Expnz1NSbX9rC7BtmkiNbEVVPwLPcLijTj0p077FtJNXVsjGE4GrC82md5eTnK6mTAeoMgwzhPMkroDQR3"
        @"b+9x/pyhyNLYa4UQc+9U1z8SQxaUl+/kqSUJuRQ4UWMXDcFFJ5tE4LzA1YY8Sdlp2jhWzpLDPlcL3QmK4o9tEJjWIKRjZWnIYACvv/YWDzx6jjxP"
        @"EW3EmiulMC4CPmXicLQkqSRRMvphXYPMMrK0hzQ5u41k0w544o/+Ue77nh8HtcwkTPC9JbJhn6puyPOM/dmC6bQXYZP33MdkUTNbLGgWFXZRkoeW"
        @"drKFHvf4L/6ffwV368/wj/+Hv86L//yfc67fo2pLWi3JlD7oUjuDz+91AHTAKik7nPS7KMciMgwEDmGiezDY6MVPlcA4gxQhmnyERGiJN9E05W30"
        @"w3klMCKggycJCuEFjRJYEdA+oglC15IkLvpPtAqIXJKsjWmLlP3JNi9fvsEzdyA/AkeX4MrbhlPHckTTUs8CbVhgtKdXSPBz9ExBL6CNR48lRpck"
        @"vcfA1yhbI5yLGZSNRjaSYNwhEFUSqBbtvWmePe+LItuf3H162C8+HxpBnvRYBNehvbsD0Gdx3qEaguhgYO9jDvB7HgDiX1dbiPCevkPFdcRIwtQL"
        @"+d5M0CChDc1Smj0s6uuf9uV17NWv0NZbJAdgx1TQWkM/SSFU4PeYbe8yKzPksUeh8uxdukw9aagXYF2GQx6ScVaWligXLdv7FdO5Y1HBuaM5Reo5"
        @"uj6gl2q8rSiKqKVX3lHXJcl4SN7vcfvagqZyFCagdDSxGu8IJi64D5J4kNED622DDAo6y6tEYUwTOf1C4Z3HtT7SeYWmWiwo1BCsR3Vqt9BJYJUS"
        @"OAtNXZGmCcVgwPqq4ua1ChpPL+vTOoezBhIfDw4ZY7/Ao5Wk9TV5v0CLHm0jmExSbLbOySc+xKkP/AD0TrO746ibOWneZ+Yd850JWMet67cwKCpz"
        @"l/m0xHmoncA4QdYbMih62Nk+K+NzTPdv848+81nu31jiT/3l/5bbP/yj/PJf+2+5dfkiSmtWpCDz8VCWIQ49g5SHD24QMQfQBo8SGk8Th30ytkYC"
        @"EWGoQmCsR3iPsy2p1ySpomm6/j5JQQWUF1H41G1ZInwk5iB40VnhQ4xUc0SQigiy658jqETKmJ4si4Q7+7vMdh2BjCUy0tCwuQlaKa7cKjm2tkS1"
        @"mOKcY2kwwDUNlYlrYlk2JEOFTuYkQjA3M5ZPn4yrwGaBcBbpEqQHYS3BB5CaVHva/Wu89tJvceGJn/qZeZn9XwbDlc83bUsvy6nrBplkxPqqEwOL"
        @"d2Ae4g9AyKP6q+sR2UTHdvfgTKdYkwrvBEpqpJAd3bEjuoi4mxY6oarKR7Keuu1oHpY63apNc0qmauq8yQi4TMw23nzl138lTL7Jrbf/GaN0k572"
        @"WNPgEhCpQKcakRYwa7jynSv0Vj7M8oWPwp0bbH35i+xduYVxObcraEMa12um5cy5c3zn9be4vt2wu+8ZF3D6eJ+jY8fD96yR6IYQaoo8w7oWj0Um"
        @"gnzUp6ksd65N6CUJq2eOI9pFh/jqPncTE1ySJMGYGu9jemt8YFNs40iSFNdanHHQGXBsa0lEwqKsaKqG4coKWIe3PsIjrcX5OIzyJsaiGxp8UCg1"
        @"4uIbeywPJBvnz1PvbYOyqNxDEvBd+Z8nniQVOBmQxRI7dZ9bzSrLD36Ste//acSJJ5iXGRdv7GLSAiszpmXLYm6YTiqmOyV14ymto7YW6yV146jq"
        @"hqpqqcqKqirxzuNx9Hp9dJqyuTvl4uVrFCfO8Mf+k/+EGvj6899kpcjpB0dio3S2MhadZZ0YKFZW3hEdh97jtaBxlixNupWhi4nIIZAIgVLiwBlM"
        @"mmjwFmdBqYBKYm8vfMA7R6/XwxqHShKcdaggEQq8i/Zw4eNoUiuBkoKARyiJSlMa45gtykgYMoK0zJCyz/W6ZNsCSTQljYaCNNMsyhZnQDSa4BW1"
        @"i+xAj8e6huFQs2imFLlGLKVIMyNYh2kF3gpEU+NNDd5EbUhZkaH5e3//dz6qs+UvzZrkSuX0k/1+Zsu6dP0sc23bEALoVLMw85EuZBOcI5U66i7e"
        @"hyFI1ot61M/7mXeR0qK1pigyer183TlzGDXkcXi6NBR8/IYKqCvHePnItbJqnjTOj5uqHS31xxPX1A+P8pAtF9OPU115mfZltu88w8a6oFjJmDUT"
        @"dC8lyMiKbRoTh5x3buHnFetHz0Powetv025uUbWBvdZTtoLKgrEenWVMK8P+wmCMQwJLywlKGdaXc7LEQYgSYdF9biIewyAEy8urpBJm0yqu7OjS"
        @"d6xHOoF0cc/vnQPXJbp0yjyMR8uEKEMjzjFM6EIvojRW6zSm9Tamc3HFcvVAE+BxeOEPe/wQAoN+wWgQSUGYFJ0N0HmP0tR45RHK01/qYbzDiYR0"
        @"dIybM8kiOc0DP/QfMfroT1E3Y96+UXJ1r2XjzFmyfk5SJBSjHjLRSJWS9kYk+ZC2+1p6QCUpWdGnKPqoJMELiZGCnemczf0pRheka8eYyIKvvX2D"
        @"X/7S1/jon/xT/Jn//v/FJQ/baYHNBzQW8iJKmg9MQvGC7mg/73IAhvCOxkEIgT6IGAkdWlQE8FHToQTYYLHeo4VEx0E+jTUIJd8ToRZCIMi4a1cS"
        @"tIz/P97hnKNxltpbWmMiKh2JaAVJKyiMZCMRFEDVBCa149bODJkXNM5Tm8Ci8swWgbKRNK3CVNDOLGFuSZvA/o2rUJcIW9M286iXES5eMDqmPRcK"
        @"CrfD9sUv841//tfJZm99bom9p4+Nk83pZHc6GPWzven+hSxLyYsMYxryPJ22bUuiUqrKvO81oBz1V2gq0wQnSHRKWS2YlPunFu10yyuDUTWtrGhF"
        @"Q6NaGmUxymN1ICiFUhn13G1l2fLzqV7+aj9b33BzNx050bB15e5rz/2Dz337i3+ZO6/9MoPkDkoL6I0ZnT/JniiReQyyECLuNPcubzKUOYNTx2Ex"
        @"4fbLrzPbmrNwmqmJ6zTXNhjvKEbL3Nmds73XMF8ElI78t1QLVleWY9nkPVIlcbKcJoeGGoxltLJKr5exu79HPZuDSuIa0EfqTgiRd9/xrA81r6Zp"
        @"KOeLTiXoUEIfilYO1n3ORZxX0xjqqomhFkHgO2kwEDcSumPdh0gPGgwLNo6lXLoyw1YtIh2xqANCFEiZIKTFB4MlQ/ZP8todiVx9gnM//CfhyCNM"
        @"Lm2yu1syGoy59+wZloqE1VHGkdUhG0eGqFzSSEepPDPfkvVSijzvgknF4c5cJSlSpzgPOi8wQXBrc4vNnX1kVlCMlqlFwj/4rd+mPX6Sv/CLv0x5"
        @"9gHenBtMMcAGSyLjQBQXXZEqxOgrL3zUjoR39BfvPhSEOChuRSzXu7AUrWNsuXMOLRWJ0jGwtDGH+YpSvpOnePBj2ZX77xw68dedcxjXdoSN6G40"
        @"GPANx/KcZcA3gbLx3N1cADHtqXYNC+9YOE9Ve5paYBaCduKp9loyo9l7Yxt29yN80pWkoUSHGomJBGTnkT4wTBS6us3tl36Jr/zy/5lLX//bz8g7"
        @"z19bUubCYlZOByujzVYaqnaWCWyWhISeHNJUktFg/Wnerx3YOTdtG5ulaUpjWpI0ZWllpZaJRiayo6tG/NOBjj3uUOXhjagESGuhnjwsqitPr6V3"
        @"/+vLL/6Ti9/5yt/Krz3/j9i+8Q1suwNJn3TlcVj/MJU+Rr5xDidTnAtkKoHdkhuX7nBi9QRkgXD9LW5cuc1kz1AbSWkCIUisjYnCutfn5taUaR1n"
        @"bf0CMuUZ9hLGg34XpaWQUmMD7/zdnaetKih6jFZGlKVld3cfpCLYgOpAm6Kj8ggXSXy4ADZg65ZyOqOelXgbV1YHoAtrY7ZdRFfHzL+qqg5yw3DW"
        @"d0AP1RFvMnRS4Gz8vJQKHDm2xrSGyzdukq8skfb6KJkihcYFKI2gv34PL19pOP7QD3P6j/4ciHWuv3KDEs3K0eOsnTxBWmQoBIXKY5DmpGJe1YhU"
        @"kY0K0mFGkiiyLKHIE5JUHZjsUEqR5hk6TfAybgZkWrAwjs39KbPGkS2voo4c55+98CLP3Nnh3/uLf4WNj30/Nzq+oCVghY+CJt8Rkbo1XwzHFIcH"
        @"7e9Oknq3gvDgZdZavUdheNCKug40+u7f5+DH73YhisPq4zCaFi8C1vsoTBISrwL4miM64SjgDFgnmM1hb1KRFQXGWRoZaKWidZK6CthaYivBYr8h"
        @"FwV2C7i1FQ1OoSsRrcF6E/U7IQJPqnJCL7O0i03u3HiDvctv8J0XvsFwMPioUoKqquKcwftRImTjjD38fObl7KvvewvgvKHoZY3H0VRxMjydzre8"
        @"t6P+cDC1rT0UcsiO1hIHLwEfPFkiePHbzwZtJyT+DmHxCrPtF9i59D+wmNyk6GXoYY+l9acR2QlY+wjYhlyfoNn/DtK+hTDbEDR7l66zfROSj56A"
        @"O1e48eqLbG8umE4lC2FoTUAGTWUtOpM0PnBrZ07TaeXHI4USFRurx8hSjaTFd9AE6yxJliB1/O63ZU2KZ3l5zNtvbXF3a5Pj54/iXIRt+LZBSU1t"
        @"DuSkGmtiQqxwHlu1VK0nGQ5ItIxwzi6eWUqNN13El0qpFjXLyx3oskO2xhAQSUCTJkPauorCKlrG60P6S/Cd11/k3g8cAdGQJhKtUlyQqP5RXr8R"
        @"uO9DP0n2sR9l98aE2aKF0QorJ06SjYcYUxKsIM0KjIetHcPdrQXeaXSaUNOCMDhfo0PcYKRaEwqF0oG2tbRtjUhShPcEHXX8CEm9KDGLmjpY1tY3"
        @"GN074OL2gsXbt/jYn/3z/Npf/ovceuNFzvUGNO2is7CGA9LZIdFIKYULbaz+ftfGgE4NeFAhJFJGzJiMcwIR4uQ/+gZc9/uKd2kMDlj5rnvpu+1B"
        @"5ySMc/WAVPJQzoxWBOcQbWDZaU4k8IIBawQmhVt39njg3g329/cJsgtpCYrQWJxOSGTCYrqAkDMCZle2GN6/TpAF3gics3gZg1pC0g0v04ppnbJ6"
        @"/uMsXfgRPvB9P7v5wqXJxp1J+RmR5PSkmKYyoXZuK0t7WRPaZnu29fT6kY3ri0V1XXRS9v/t0X7SY30sXQeDPo5AQkKWDZrJZLLey9Mt7y0xTkKg"
        @"BJlUfoQIKMxp6ctPfs8jg82ethvffPlfwP63qebPotnj9FoOmYfVdRj0IT8KTQLZEiI5zVKvgskMSsBpNi9uxoImJPD6K9x9/XWmk4pFo6iwWC+Q"
        @"SuOFJikKdqcVO9OW0oBOYdDX5EnL+kofKfzhNz6E+EDZ4LuYLE9wBlrD8vISKoHtrX3qeUOaRYmu6uYBwoKrLTpLkF14hw6xirDeYJsWJZIuvVce"
        @"3kbOtSiZkOc9yrImdPLad2i50RjsDCiZIKXBE7DOkRUFR49nXL5Ssbd5gyKVuNYhdYIq1vj2m3t85Mf/D3DvR7n1xh5zkWFFwumzZ9D9jP1yTp7n"
        @"aKmZlrFf3dtr8DahSDUNLdrXFH1FkvdxTaCsLSE4hFBorTrdgUUHh9IFrhHUVQUossEY4TyNb3j7xjbHVlcRueTmfMpXbm/xI//pf8pn/5v/Bxff"
        @"fo0juUI6jwOE7TBAImoxghb4NnRxaOJf4gjEG/yd3MRYmcjD8v2gtFcqKv4OSv536y1+r3zKg8rAOYfWCabTIwgpcM7HdWPrOJr16ZsFiyYgBxm7"
        @"exVKpuR5TtsGbGdYNiEKqILQtK2AVrE2LLh+p2LoUtLhCkI0Xa5iwDgb05Vpca7B+AU93YBuKRK7cf/5tWdWR+sXZuXex5XU10MrmsTLiQrZ1LbN"
        @"5Mj6+suzejFFyfctBtBxohoHNa2zVFW1Ph6Pp+Vs3oz7+ZYKLnOhuSBs+Skt2ke0bx+RoX1Yep9nAZ7/wt9GsEe9f42dr/9PKHsHbffx5ZzdHUO2"
        @"UpC024Slq2TL+9ArgBGwB9VWTNPVGdxuuXPRsby6hrt5i707+0yv3mVWVjQixZs8ijpEzKJPe0Ou3LhD6SXz2rM6hkR6lsc5w14C3iK06LYVHqHE"
        @"IW0nDu081CVLK2PyIvLm9vcnHD2+hq1LpFaxT0NhyhYdIvqaELUBsnO9tXWLFAIpFFrIbiAVOBCo51nB/t4E08apP150dheBlgmm8qiY3YEJDhcU"
        @"SiecOHaMy29dYX97k+ULp5i3Fp+MePaV2zz9Iz8L938Pd9/eY06Oz3ocOX6EGsnetGI4GlACk/2KZu6oy0AwmkHRR6UBkaUUwwFFP6EtPU0dmM5K"
        @"dicV89oiXKQxh5DS6njje6ko+n1M07KYzQhdOCfGs7M5Y2XYh9GQ2/M9Xq5aPvRn/vd85r//KxSTbbSz3Y0ukS5unk0SYkyYJ4I8hIyEH+8RMi69"
        @"hBCI0CUiHSgHu8PggNREpyysmpYsSw9lyJFY+E6H/I7X49DxEbFp8p2QEu8t1gcyLRCVYak34JhouVwbsCmmDVSLlqX+mN22jJLm0CAzSeMtPZkg"
        @"VY6pA8n4CNMbVzCtJllfIsh9yKK4qS3nJEnMQUxVwbKWuMlz3PnmDb749/+PZOsf+Cijez73xEf+yLXSiyYphr9ojdqqFu1kmC5/rpq3WyEosiLH"
        @"+fZ9CYK18SZ+MWWC1pI0zbbKsqTf6/HlL/1OkN5im31CvY93E4RZ4MyUYCt6fpett5/BlVcJekKvb/B+h36uyIo+xjZYKqpyhtF7NDIwYh2yVard"
        @"12mqy9DeZSmkmLfmbL4NJ44NuPb2ZcyOZbE9Z1EZUDk+RMqNcYEgJSLJuLs7A9Wj7iLDEulYW1oiS0W0qIjYIwaildS5JlJego83clNDf0SWKeYL"
        @"x2xacfRkRlNP6fUTnHGkUmEaQ6o0SolDwm+0p0Yev9KSIlE4ovFHoA51mmkaNwEH2OsDa6+UIcIvafFBIZUlNC1aZ4gg2RgtsZzDy9++wblHPkjS"
        @"H/D8m5vc99QfJXnij3D5lavUegWXJayubrBooaoNWa/g9p5hOt3HGU8mMwiCleWClSVIEoFOIjmntiWDXo/Qg1F/SJqmbO7MmJbRgOMzjSsdveEA"
        @"0yhmkynOWXqDAd462rIiy3Iwlsl8hlrKSfpDrtUTQp7xxJ/4aV78//wNFJZecGQB9AEzIARccLz7gj7gBMp33dIHvf4Bpvvga/juaiF+Hxx5HiuG"
        @"d9/y/l0/j//sqoKuZXBOILVGYjqnJug8WpALpTjW73FzPsFWhtDXzPbmnDw6YuqnCBnpyGmmsXWJU4EiEzS2IhmsYoDZLGNFnsRnI4KYosQM3CY6"
        @"DUhRQxIQ2uOrGVnQlHefY29rk7m6yK/+w184rZePEPKlv+Rdj/7oKIQRH/yuj4kiUetlXW0l+g9ACRhPUrq0lZg0YozhIx/5iND4TIv66cSXn/rm"
        @"s5/7C4u9u0gEu1sLjDEMs4w0H5Mtp8hBTfROtlBbEjISp8mVYSFK2sUNZvXXGfbXqbcvYs2UIg2Qr/DKt19BOEhDxpVLV+mJNWaTFm9i6bxwPrIE"
        @"vWc0GLE9mbNoYVG3SAm9PEE4w9IwJ9VgTUzE8T6gU4V3Dp3EkIrQ5c6ZRUkycBw5ss7e7h1uXLvFvRfOkiU5pmnQKpp2mnmFT1KUSMC5iIhKcpra"
        @"EPCR/KvfWW9VVUWSplgfPe9pmjOdTllZWTl8GK2NmgIhLUFWaOVIXawaXNmwnKWs9+HONai2E97arcmOPcqxT/4H3L28w4SENgQ2lsY0zrNoJVZk"
        @"7M0t87omzXKCN8jQcvzIKutjSETU5UjvkbIlUVFZXrXQz+DIakZZNSyqilRrhAqHg00rBHmeY4XEtgYfBEmaIozD+ganWvanNUdHyxif852d2zx5"
        @"5gKnv/+HufRPf42H+gOCb6IVWkYJsnNxt13Vln5fxUpKKeqmocg66InSh0M/0THDtFSHg1ahFEJJkgSqqmE87FOWJVmSdL6D+DJba9AasiKPv56l"
        @"GONojafQGdKbSPNJiVkKOsMTONbPyecTXGUQIcq7x+eOsCej3NuS4RtLngmQc1TqqWzFoL/CcH1MORmx0v8elJyg8jmwzSDbhDBFDSZQ15EZKROY"
        @"SopmwNbMY0yJ1habatLRMmmyxpMf+nhelb5RMkNgtpR070sFCKBleDdS4F0pLt3PjbUjJ0VjnJx86CN/5L/ElZ/C1R/tpWrzhec+t8H+29jqKlc2"
        @"X6K+O0eEBcPMMJSWTFnyTCO8JQkNUs7Isk2muzcJdk4/T0hCAnPDnRtzUq2Ybpe0VeTeTRcWGQpskBgRS0ZtY0783nRKbaPnO9WQykCeQJoIAgal"
        @"ozY9tpsxfFKEeDsL2fnUvQPvyPKEEGA2NZSLljQVBO+x1qGkJNUZi1lJv0hJck1wBomIEBBnut6+C+2ki/bqHHmhy/CL3oV3BlshRNh9NkjZ2dth"
        @"OBwy6GeU+xVYyWCUsjLuc/nmgi9+4yrz0TI/+XP/J+5c2ePKrkEN1umNV/BaM53PKdsEGxwmxMFi27b0MsHR9RXGPUXSqeOEa5DCx1YmiCisEd0A"
        @"TUCeaPpFQW0BY8mSmEnonMMlUQ/xjrffY6whpHGiX1Y1u26P8bBA9pd4e2/Bh3/gU2y+dZW7r7/G0aAoErC2xRiJkCqanWTcoAitcT729h6JUJHL"
        @"L3+feHrCAWOgWxF2EJF3VwqHDIKOqOw6jiQhzm2UiH9OjF2UkSYUDAMvOAlsBg71CFp7lsZJF4ceswwT7ZAirjsTHaAIDJYHpF7Fe7YYQNNAq8D4"
        @"CB1oWnxVMd2fIRpB2wxY1Dn5yj08+JFP8dAHP0mT9z7n1NJfDaH31f2pOdVLx5eEVqNZNR3neXbdO/8+h4BBvucLfGCFjf/UqFRtCdXbkoy+Oqvr"
        @"kVZL/5319dOO4vqZx37yE1pVH5eh/JQ1bvzis/8L+9e/ReGuU955jjyZgW/ANWQ9hbMVorfFaLRM2QbyRCN1j+bunOtXLefWNti6O8faSJ6ZNwFJ"
        @"Ehl00hEIaJWQpT3279wEBc7CylJCrgLDQpJ0ZJno//ZoKZAdlx4fH1QtE4TvcEqhZWVlhSK7znwO+7sTjmyMuv1z3HZkOmM+iWKOJB12JbzuTO8H"
        @"ZiY6CcvBnvlg4u/Jipy6jdLXg3219x6VaFoZSPq9uIJyjnFfEyxkuuHIsTXC5ZYvvXSX//Jv/hVmZc7b+3NKUVA4zdpgib3FjJ3JjCD7eG8QOiFN"
        @"Fan2bIx7bIw0Cd2t7yO4FJHEiDFBxIgdqjzjAaUTSSIExocub7DFaolzEpkkh1shLxy18EivyJsYFjqtFhS5ZpwOqKZzrmaSk9//Q3zntYusFhmp"
        @"rWkbj04SmqZFJwlIR+s8SkVgipJdOpBQeG8JQrzjMzh0F3fy3q6lOjgAjDERDts08bA9WAd27cWBPqOqKhKdQPdnBRXQkohR9wKjwPqacZ5xbhgD"
        @"nnUwSGlAVIyWFPu7U/o660RmkgSFdg7lNAjDeOy5ef15Nu4cgRVJU95BV3uExT6qLAlVg68rCqPZ3A0M185y9MTHyM9+Lw88/kd/dSE2fmM+q5/u"
        @"9cDPZ58+Ntq4tL9vJ6ZQW3rQbyrfXsg8l97XAUA4cFP5Q9SQ7/TGQUBQCbvT6ZODXv95E/Q0ESkq631+agNpPrg0880vCCx5Fvjg9/7cn9OLrZ9/"
        @"4+XfwvVOsvf2s8ynt+kFTd42qNR3YW5zMgXtpCRfX+L6W1eZ7oM6MmRn+wZZf8BsATbkXXacxQuBFyFy8BLFdB65e8HByjAnFQ3Lwz4+RKMFwaNk"
        @"p2EQARUE1vvY7wnZZdk4aGqWl8f0+0Omkxlbd7ZZXxsexioF60BqsiTHO0tbVd1K6dAaFG9HFw77ejrK8EHpmmUZi8UM5yxaqcPy1xEIUqHzAtta"
        @"RlmO9o6t/S2cXmHp+AlmcsInf+pP03vso3zla89R6RySHoPxBtt7JbuLGZV1JJlHJtESnKrA8kCzsZzFl98ZxEG8r5ZdCm/3/SWglehenvgCCR8O"
        @"g0ldaA+n7VJKggbpDm5p0Tn/IqW3KIa05YTZbEExGJL3l7m0u80T99xP774HePPlb3FPIREeEhF1+Ac3vnW++45ECrD1FmTEzskuQ/B3T/Qd8fsa"
        @"ONABeIxx9HqKNoT3bA/eDR5J0xTv3z1fsDF9SHRZA53V2vmGoVKcXu7z+nxBpqDfA5mX9McZs8ZRJAHpok1bioAKMmoempJeEphcv4u99Bz6wVXa"
        @"8ja+XsB8gVsEdCNwZWBeKdaPPkF+4QchfQhG97NVpa+kw6VfGGfyF2zdrA+KbGwqM0m13rIhgFMEJ6/H2O//7SeAPKD6iPf0Eh6ER2CxrmRldXBN"
        @"pB6VS9rQZo0wOB1Y2AaCQsiUuXHr+774nFt/7PSpJ37mJx779F97Zu3j/zdWP/JnsSe+n4k6SUjWqBcKs7C4qiIXEhrB5devowXUjWC/bKltwu5U"
        @"YOhjFDQyUnGFFyQ5lGbBovQ0dcQ9j4uEBMvyaIhp2qiyIxB0fCjwUSZ8cFNLqQ/L9qacIRJNplKEh+27e9ED4APedgk9xtDv92MU2nyGO7DlJmlH"
        @"vgFn40T7YP984Np2ISC7krNtW5AhHkp0LQIShMJ0nncrHMOjq2TrG7y6ucPqfQ/xvT/7c7z5yluIYpmkGJIXQ4Qo2NpaMKs8IcmxeJAOoWqkXDDo"
        @"K7T0KOJDKULn1uxcyDbISLztlD+1gbqu40Oh02hm0rH8F0qjVNJ9RKiq7OLK41sqMR03MUkK6sawX85RRUY+XOLmYsG9n/phrmcJE5WQDvtUdX14"
        @"SLogsD4qI4UQ7wpiCZ1xKryHNvR7tQHx7yMPlYLiXbHZscFRHWTlQEQUqcRBOhwuChZDZDcoEWGqUnoSUbPUkywlMMxhaQPytcDS6SH9kz2K1UA2"
        @"cqQFqMRHlV8IhLJEiUBWQnntOpQT0mZBaGaEtkJULbLR2HaJwepT+PHHYPkjlKMHOHrfE59S/f6vKRGgUYQ6bepaXXJBbylN1lfigt6pHhlVqkne"
        @"JxdUvjtCWIR3HEYyRJuhlgnVot4ytTkon5ooCPFd6ZNSl+1IoLf6/eXN2zvNhitOfG4rnPzYmcd/8ice++E/e2348KdJz3wPu5ygVRtMZoGmspDl"
        @"UHpuX4XBUDGvW4xJaEzKohY4qWnwWPxhgkwxyCnrOUGCtZBryDTkWrA06HfOPQVSohIZB050qbGdGIUuNBI8bVuDtaRpihQwnxvqOoZrRBx3wBrX"
        @"vQyKpjGH/XySJIfCE+dczLz7PfbNSguSRGNdGz1dUqK0iKgvW9MrMpQSNLZBFCmhN+LtnZYX3t7ix3/mZ3GVYa9sMCHeWL3hkNvb25ggCCpDqIzW"
        @"CLyLcAyhorrvcM7xrilPCJ2yWUJQcRvQtDBb1FSNQeqELMu7abtA6gSt9eGHUgpU7M+1TMjIyESGCgmNCUido5KchTHMbEMrLPttRXH+DBtPPMml"
        @"eU2T95FpRl23h8rAEMA4FzX9B0N6+U6cWPg9Xn7RRYS9exsgxDscwXcfEO+uHg7aAO8tQgWEEpEw1Am+UimR0sWZEpaVnuLkOoz7sHY0Y3BUMzg9"
        @"ZHRmRLGRki4FdOFQSYiTVimoFyVYKAzsv70D+y2ysvjK4mpLqCy2kSzKHkn/HnpHHyeII9z32EcfqVxySarsedP6rGodg6X1p0NSjBokdXBN3Swu"
        @"DXpp3UvVx9+vG1AGaQjCEYQ7DGmUTkX7okugVsg2oaf6DGSfsLC4RctAFwTjMI2ln/en4yRfF7PF1noun6eZT5Mip0pGv7aXnT1z4eN/8ufV+R/E"
        @"bnyYMj9PLVcJIYOFgf2W/S3I8oSyrgi+T2symuAwIuBQ0QwpPEEaer0YlJmkGdZGfVEiLaNej16eonWCs+Hw4Y5rn0CiInrMu8jtO7hZgvP41rC6"
        @"skKiwTawv7OLlOo9TLmmbg/to03TUDY1wYvDtZQL79xY7l3wD6FBJZrecECQ4lABl6YpWSLJc1CqYTTO6C/3cUWfm6XnVjPmg5/4Kc5+5OPc3NtF"
        @"ax2Tj53h/8fcnwZret7pfdjv3p7tXc/ap3cAbHABuGNGMinOqsWeJC57son64MiVD0qVFSuVqkRfPNlKjlUVpfIhqjgVxx8yiksjyhmNZMfiWKMR"
        @"Z4ZDcIZDgMRGEkCjAfTe5/RZ3vVZ7i0f7uc93RhpSpJp1QRVhw10HzYa5zzPff+X6/pdzXrBol6mhB40XSdRcoAUA2CAECM6pxAILAEvPcgWhCWI"
        @"SFSBKBNQZdVa6tZiXUw3uM6RyqTKRKYXXiiDMjlaZf1Nm1ogHRWjWFK2GqN6V1+UqLxiTWTmGjrpUCPD0brm2hdf4p7U3Fo3kGtGpUr+A5kk594/"
        @"gYU87QsIG1QY8byy2nwtnzzJ4jxwdN04hJIfgZM+vQp0zpHnOc55ovJEHXAIfEhSd60ERkCZgVYwnVbcuD5iewLbBxmDyxVc32L7xh6jKwMGBznD"
        @"XcNwu2AwLTFVTtc6WAuGEZZ3gZnGdAOULxEhhyDxwaAGBwQ9pTmdQ92Q21iM9eBm1wpEPmxDmXPcLX99Yevca002Gu4tRHd1lddvncTTV5z68UoA"
        @"vckTTxPQDfRCfuRUzfNyb71eHhljKPMCFzz1ek1hMqQ2eb1atVKFIxVjjrOtUZJVa4nGMLNcLeTOX/3Ul//85Nb3/uu/yOMf8fgdiZ3PIRuwuu9Z"
        @"zmFcKdZth48a61LmXUfESJMm6yLJP7XWLJcrYlDUFoaFQOMYDAukUSif1kYZup8OC6QQvRY/PMEV9EM+QiCGjq3tCq1hVcPjowXXn9knBoXziSXf"
        @"tGvyXDHMhxyfniFiB4VGqhRrFfsDYAOnVEL0Q8hUMlfDAVIlSS09ys6rDPKSMxepJhPmjYN8mxs//6e4sftFOHiBuPS0cUFmClyAfDjkndsPiHqL"
        @"ddtSGoNvO0aTIVppfD9kWyxadoYlyCwNQXsOX+jdoy5GnGuxtQNp0rRfCboo6ZqEIDNG0TmRhmNC4jbmmrgpH1PsedekiO6gFZ2zSCJdCFjnKccl"
        @"q+MjBsMJ0499it2XvsQPX/8DVssln9waUniB6mwaDTnXb0lc/zz6pzzvqaQPbNaB4sn38Wn1oBK0bT+XiB8lE6XyHLy3GFMSYl/tSolzHk9MIqTe"
        @"36I0OAN6CnvZgJlfYPbHcOkaXP0cZX4Bb17HZKCXArGKgCIGm6CwdUYeSuqzOqldpUQ4CQ34zqfWcm+MnuywriNf+vxP/rKSW43ygkLkOBuxhLHQ"
        @"qpVFNo9Kjk9m88lgOLrpZDtuvbuaC/PWjwUE+cP/59jbf5+eB3TOHelMEQm4/osqlSLGgLdtm2UaJzw+ilaF1P8aKQkhUpj8jrMWJyZ/87nP/blc"
        @"t4uvfuNXf4n27HvsyJI7945REpwrmK9WTEaaNq6Yt0uKwTRRcfvUmXIwwXvBurb4YNDAdFDg6jXlYILMBSZKYnBkoYTWp4BJI7C+oxwUzBYrxlSo"
        @"oMAlj3hbz6mqiuEwpcPcu7fgM58TSJEjRYltPQiHDQ7nIkU5wnrJ6eyEnWGJFJ7gEyJMa4MyKb9PhAT9IER0noG0ONGRV5ogBLXXHMstzIXrlAcf"
        @"4+LlG7DzLBTbECbQSs7aFdIMyKTER0nTwGoNMYtElSGio1CC4Jap/FYpeqxpFQ9OYGsMrr/RkCrZf9uEPVdSMB6ViVIEtBHWNqULueBZ1Gt0r5pL"
        @"CsikpBQiImKyMUcCWZXhXUuQEUyqiEZU0NUoK5iM98CUrIG/8L/5P9AdP+C7X/97vPybv85ztuWS0AzKAtM11HVNbhL12dZdWqvlKbqs9cnZKZD9"
        @"uk0Re24iUdI0TQJ8SMvhWc3eVpmAIzGijcR7i/ch/RwOY6CzCRqamwR1XTjJoNQUuaXTkbAN4cBz8Zkd7h8dEg8uwce+AvoL8KxF7Q5RD16HD47h"
        @"0ZJuGahnDdQpTt6oMUePa+zxMWY8ILOCaFNn1rYr1scfsLdzn/HFLxLV6M1oIwq/l4dsrpVqvWbuiHtC+TaEOK/MYC5ah1NxrnX2Fv5fARU4in+5"
        @"qWIQ/Ukr5JOxQn9TNMtVXlVF23TuTaOGXxtM81fWYvo3WqtAlty/P8d7CDEnsEaaNDBDp4dQx038tCTTBts5Qoi0zqIklMZQmpqyMigjMEEhvEMT"
        @"UXLz+EaciP1o0BOD68tBjXcu5eqpyHBScf/umjoG5gvLcDCgq/tLRva+dmGQQqNIwphV3VDmGVWVVnnOuV6mKtOaKXpsbFMM12BCKyRnrcUMBuT7"
        @"13n+2S/Bzsdg6xKoCbbWnD0OdLYhBoltY8qA6bP7jk5mWOuJypFneXoJYzqMRXQordAqDTlXyxbvddpPi4iSgUwpslxT5ulmNwlzhJYpSDMqaC0o"
        @"GTCqb5VC+lwbE4FHirQ5UEbTRUfwKdshtT8OGROxR8YES80yQ20jixDIGsv+lev8mb/8V/h3/vK/x2tf+8/54Jvf4v13fsSOUlwoRnRtTWw6Si3x"
        @"vs8M8BFUega0lHRNS71ao3XaaGSmJC8MQqme0eCTu1Kki8jZtO7MM3AuYNuG4CEvMnRWsF7OiR4GowwfWvw6Mr0EYs+gLwzh09d5aaHhhU9BPkjW"
        @"4Bjg+AR39Jj26DH14xV2LfErS16nCB+tCnyExWLBtivwTYdwiVtgdGA+u485vM3O1cC6a5HVVrFetQzLwadr519R6UI7CjKOER6JQsSAjP0amj9G"
        @"LPgmHUj2uJB/Fme0HFQtQpCXVRt9+NZ8sfzzly89x+MH+0DF/XuPkT1dKAbQJse1q2SlDeF8khvx5LmhaWucA9t2SQCkITOKssiQImKUpGnTwFKb"
        @"J/vfc2EIJIJL3zOGLsM7gfKS7Z19EB9SN4HHj5cMh/tYt0KrhDcLziFVyrVTMVAUBdFk+BhZr+o0A1AZJjcIIwnSYeioygynFQsXqfMLDJ/7FJNn"
        @"Pwf7z0K5DZ2gO/HM2zVdKAmqxAeJsx7vBAGDJ1Bbx/HxUbJlxQYpDEiDzDRCyWR2CqLf1Qd8SLmEUkaUTJl4uYRCS3S/8ooxgTxF/63b0LxFSAIh"
        @"bzuiF+dAD6InuATVCM711OInKzWCRog0NNXCYH2HKUdYleLVThvH2Z2HjE3kTq74/P/8f8kz/6O/wLvf/h3e+Ad/j+Pvv8bzSrM3LqGpcVpSWwca"
        @"MgV+PcN6MBmMJzk+WJoOPC2dD4SuS74CoKkdu9s7dChc2wCRLDdpVSoyxoOMu0drtvcysqLA25asV5VWGvKhhjyDwRRqz/HND7DtIw7+tTk8U4Pr"
        @"qB99SPvwjPZoTnvSYRuITYojX6/XwADv4fj4hG32cL5DCI+QHikEowJmZ/cY10eYCh43ixv5aO+V5bo5EjJDBdFvleo5wo9Tb6TmImaA6tux+Md3"
        @"APyRCi2RYp6Ch6apc6Vja5ScG5G/UpZbX83zLerHM85Ou14p51MiqslpuhmZzmid6AUnaSVX5CYZUUg76zRAE+lW05roLFoKYvQ4Z8mi6o03Ad9v"
        @"LaImebJFEu4IkdjzTWuZTqfkgwc0Zy2Hj8+4dHkPj0fJmDIFeqeYkClkMjEUXMqqVxptDDLPiVLgpUdIhS5HPG4tNo7Zvv4i289/BfY/BWKH0ApO"
        @"H50S0dig6KLGSYPQEqEMUuf4aGltTecD8+WCVb0mHwyROGyzTKGUCtCJj5uoO2C0xGhJ8A4jBUpKjEplcy6TCMgFh1IaKdV5vl/TQtsfoN6Hc7vt"
        @"RtmkYkTLJNh3CnSf++cCKC3wHnAOFRyybxuU9FjfMBgNEfmA6AuIllPf8l+88jqTKuezP/fn+NKf/QXm3/4W3/vVX+WNV1+h6DxbwwKCpxACKSM6"
        @"E+h+CLFetulADj1WTiuCjGiTI0RH03hW9TIRoVRSuQaV/oytD6A0KoPOO7JBgcgUC9dSVBn5sKCtVzRLx+rbr2BfgWUGcTZnuv0+edsgqhx7fEz3"
        @"uMHOPG4Jtk3at+hhIRu0ybAOHh/B8zJLQ86knkhS8K5jOs1RMoCOudWiXTWrF7cHWze7lWuVFImPKP044q6CvhOfmsP8uMkA/woOgCdlSRAQraOq"
        @"hmMUuHZ+JGT5Ddtp2i7DZFOWCyjIcG06CIxOGm207IXJaXEd8Wgtabt6I0QjN+mBzvJk1Ikkh1ieZf3kN/WpKXIuJpCnktiQPk9Gnyg7NhB8TVEW"
        @"VAPB6QxOzma0ziOVJ8TeRNSvTCWSGDokkp1Cs64tyyiJUhKjpbM+TaDLMYd+wsVPvcTep/8UTJ+DJmd24jhZtjROEJ2hLEuyPq0YT7I9S9JKTErW"
        @"XYq6Pp7NcK7DOItREu9bilyhHeggMBQoQhowBZAm4d20lqjen+SDoHOgDaB0yssTqWperGBRdzRt/zXzARHAtQ3Nek29WuNtyj+U0WHwdN0agkPZ"
        @"DuEt2oMQgdx4cikoRMvWREFeUE2HBDPC2oDxHWEB48zglw2vvvoebxvJxz7+Ej/zN36ek7ff5OY3foNbv/4PmfpTVOzQ0WJjxATIBeQSlMxwfSiJ"
        @"dzYBNFVEG8+8gY41w3GaHYlNTJgwSJNgJwbHzLbQBXSm8d5ydmK5cwwN0MwCpxFGY8i3IJzChb15QpIdTLH319QPHfY4YJdppRpd+nqK6CiKgPVw"
        @"dAh4hdJFateUR3pNNdzj7nHNtixYrta/YMY7fxM5mKxr22a5QHoHWIhh4tF3QqzmMkoE9vxdi8j/fzoAPvqH0VrjYph3667NpEKrqsnyEdPpAbe+"
        @"/zKrFeRVxHtHUVREqYhho5cXT6dKo2UK2KQXFJpMAIFMK4SMBGeJSmOMwjlLCFk6QjZTayFQQj7Ri4ckdpIi3fJSWwYjDQLmc0vXeqqBTCaplAeM"
        @"CBrVawJEiDS2w8WINDlWaazIsEVOsbVPsfsMVz77UzC6RuhK3n97yfH8BKnHmHyMi5E8L1kGT5it0uGV55RVhckzglR0c0fjPFmRp0BO57H1mlxE"
        @"cq3Rdo0MAkSHEBValKn8xqCFpF7WOKMoioIs13gp6fo9eyT1+8hkjJytWurGpfAMoVAK1usFzlpwLVp4pAQVfFJn2ppCdkTfEKJNqUshooWj0o7K"
        @"eMal4MJEk1eKzlgw0ClFISpk9LimxscML3OOO8vdDw957XjJjYvP8fm/9L/gCz/7Z3n1//MrvPvb/4iR8+xNDLGzhMZTGEVwm4gshcwkmYroqiBW"
        @"GsWSmYKsTFH2nXXMFivmNayaBT2iAVmmCDLfdVQDGIzhwhi2L+aE3ZLPXr/E9qVn+f4//m3efnvJ3sUZ020FixXdYcv6yOHmAltHmi7Zno1M680U"
        @"egqnx0CjULKgEw1KGpSpaOvA1mgMdo2O9vlmvXpJDqo3O++uKinvKNLAVUQ5k8i5Jw1sdUyXUfzjngEQxZPm8Q9tD1IVEFBK5SG4XOVmbp29+fnP"
        @"/8Thb/yn/97+am2xHZhREp2YTJ2LbKJ/6j9OCnJhEAKs9XiXLthcm/O0nM2+1zuHEpLWdgTnU/gIIHzSAyh6J16WqgsZPFqkUBKBZXen5Ha+ZL1O"
        @"fvrpVk7b9sEXQeKiROkcGT2dl+ii7KsUsMLQDC8zuPoi+5/6MtnVF1gdrnhwa8bp2RleFohsxNqDXy2QWtFGQ1loBsOCIssoMo0pDCbTRAXzOrUs"
        @"sYXlckloW4T31LZjVGZ07Rnb0wk7VUk10EgpcPh+gNhRDMdEJG1UqVeuoW7tuepOxIjzHU3dsV6vsT3TMPmkbDoonUcBJpMpPDRKvFXgBe26TvyD"
        @"RIlLKcvRUknLQHQMZGQoF+SjEaHQZFsTmk5C5zkRHesCll3aTkRfUVhDGyJv3p/z6vIDnr+0w2d+6X/HZ/7df4fv/t2/zfu/9Q12ZMPFrRzftpQk"
        @"/YFTApEpls5x0qyZtw0nNaw93GLG2qeQnU5AuQ/DLRhP4MrFkv3LFxhfvEqxNSaflshKJYXZtICL41Ru2gL/2u9y9Co8vrfi0u2c6YUx9kTRnBnc"
        @"SuBcOgCkVCm0NKrErxCwWkBscsRgQIzrpGKSGk9A6cDs4U3ee/f1/Wuf/4U786Ztizw7snWb1shRQ2SeLldHFOnWF1H3g/c/9hZAPBVWKJ4El4lA"
        @"jJ62dfNyUEBI66fvv/b6/uPv/j+Zz+e9ok4RSA9Z27bnkXKKXv9PMqhIJN4lHT0RtExmEaX1OegjBIcxWbK9RplilGPaKcuQfk6E2OfJ9C9ASL8m"
        @"omdre0Q1OGJ2BienS559fpJYBFEQfSL6ZEamIR0CbQYsfMTrip3rn+b6534G9j/J4+PI2y+/n3gGUWGQKBOJsUVmOaNRxWA4ZjAaUpQZgyI9c5tv"
        @"p49p6m5Uz46rE4gUZ5E+Y+06MpuzvzPk+sE2H3vuYwhTcHhyxoPDYw6P58zXDfPa0biAiwphcqJUBCFROqMoMhSO9XrFarXCth3WWmzb4boGZ1ts"
        @"UxN9h/AdmRRUmWZYmAQS1ZFhFjCkuK4y1+RlSaEzhpljmHtK03AwVjCu8NkAtTshdopoA1vDjMP5EjlfINtADJpu7akXLa0PuLLgO/fv8fbje3z+"
        @"whY//e//FeKf+bN881f+M175vd9ngmWIp65hYcFrsAoaAcUEzAV45uqQ7YtbTC9MuPr8NQbbFWyNYJhDqVLDfnSYyoBhRWgWzLsTsgb8w4b1/TWZ"
        @"FEyKPU7rOUczOD4N3L51jI4FzUJSryTeGrxTNN3GY9EhGsuWSurTrgPvc7QuUw5l/86U4ym1jgzyJdS30fXJX6tM9he6JlJkJViLF8nhmUpf31e1"
        @"CdTZK0/+uA6Ap6MJ4j9zHhCjI8szOteg8Rjp9yGeu+K0Ti+tEoHROOd01Z4TfEQMKKWJzpGbjGAdEoOS/cZAa6SMVINBv3qLaJ0hYqTMiz6HTWG7"
        @"hizTiSMXk8FHhEgMaU1lZIbtOlQm2NvZoSw/REnP46MZ3l1FYFAyQxSGdtXRdoGiHHJiLcedZHT9Mzzz2Z9FXHqR06OWt1/+EERGXgxQVUVWVumQ"
        @"C45MK3SWE1HUqxmz+SltW9OszmhXC7p6TdPVtF2g9ZEHhzOyasTuzgWa1RphLULVDIyiDi1L1fLhe46j+w85ni358O4jHp3OabwkqJxoSmQ+xBQj"
        @"VDnAlANMZiBIFl2HjDap0mSBEylaq21bXNMSbUNXr8HXSGchdjg8c9cm2m/syHUkVzDMMqbVkHFVsTXKUEPIqsBkS0OlwASUtECD0AVCwLQyVNU+"
        @"F7b3adcNXeNZrRsWwzWrrsH6DCkrZGhZNEvePG547sZ1fvp//7/lxddf4//2H/0HUNfsX4atHbhwbZsL1y+wfWHKhesHcGknyflMr3N3bXpcu8RD"
        @"ZGcfXvuAu995nXresrd/QMglVlicCFjbIDNH7S3Dcc3F8S7z9RH3Tz2DWcbWOqNzgmW9gqixDmw0OG8RRuNcg2k6HKnFikGD1piqwOQ5biXpZEa1"
        @"NWGxuol5VDKJi68aO/mbdRi/HIUae2HnSguarstVplpjyLvWtiFWezLKCaK+uQlf+eOdAcSnq4DwpCjoE3klKVMPF8ZNvWK9XqY1iQCpUtUgFedy"
        @"TkI8D5tE9CGScZMI9LTWPpz7Es4pMjKhwHxnyfIsVQAhTeWVTJZcJQVRSLQ2uORkoa5rpqMpe/sT7t854exshpCS0XTC2fEpMhqyvESZBKfElLz4"
        @"lf8evPgVqEve/N4HnC48Qg/pOsvJvdss6hXrrqXt1rRtTdusWa8brAt4DPOmTWaW4NJgracvBxROalQ2oBo0qKiZn83AtsxdS+Y90PKhSKu4FM+t"
        @"8cIQZQ6mBGNQRvbqt0h0ntgmrDhdUr5F30HwhOhwncU2DbbrCF0LtkXhwDsMlkwGdAx44YmxQ+ITPoyI7WDp59j1nHoWWVeReeFZncJkWrEMh3xw"
        @"NGflhrROQ+dYrjpmTcAHQWgcTdOk+DOtwAiECAyrDELL7taQTksefLDgk1euc/VTH+fP/U/+h+T+ba5dNuw8e7W/2XXqc9oFtHepj2YgAr5radsW"
        @"VNI7aK2ZLk5BJDhM8GvytkPqAh8FMigIhtCFJBHGojuJ8CQjWi2pV9A4qF1qEV1I6T1OpPWcA5rg0pDVpeGuyTMiCte0NNpRTTSr8JBFsyA8WPHK"
        @"N/9T5OQnvvXpz/9bX5214e+r0mC9pSrHbRCB2ezxlweD4Tc63xzluizij8sE5F/xX4oUgIGIKCkh+v22rem6jma97pVlAik8MbqP2Dc1SWYrn8ZE"
        @"BwU+nS9KSoRI5hqpRDpIgk9uNhOxTc1IF/1QyxNlSvwRXhKFw4tI01mEgnyQ0wUPw4zdgwnCnLCs4eT0Mfv7A4oyGWwW8wW2SyKg+48XnLx1yOKH"
        @"32S1WLFadzw8rbl9NGftJDHLUUrS2oYYPXmeI7IM75ItFeEoREFEoKRDEFHCExFopdFSE4IkOE+zWtKtV4S2RroOLwJES1GW6QH0EaklKEUUEiUk"
        @"Rpn00tMRQ43s8/ZCzyZID2xMu/zgiLbFt3XapbsGGVqy6AihxURHmadRqA8Rj03Zdr1DUMqIj4HO+QSAwaOiRwbP7GzF0brj1vsPOF4JrBXQObrO"
        @"4aXGhojoknw6+gQMQTi09FjpGZSKxWnOeG+Pnbzig1e+zW/98B2a43f5H/+bz6HcIZxKwpHFiYgPAR9dmvWIDR7cI7xFqZBibkQgeIMcbiMHinDa"
        @"Uds5Rex1RM5jhCQ0GhEFrbeYqMkAvwSz9rj5CusFtbc40gsuSAGzMnqst5SxIyhoHbTOU5Ym0Z+DIwjLTH6AVwk7Nyo17775/+LZjx8xNff+rz5c"
        @"OFzbwTeULlnMu1xr2W6Pdr/R2GWel6Jt29VMi/y//WzAf4lr/8ngrzcS/bMIrGqjwfM2T9HYAqN12v0/leQSvE9o7SjIhESqZFndCI6I/pyyIwAj"
        @"BVoGjFLnf5/CJxNqqml80iOkWD90ltaAmdaQpcNDZYI2dNTeoTIDZeTysxcpRu+zbuH45Iyrz11kXc97UGViEp7Mznj7h/d55/f+cy7d+BJlJlF5"
        @"xsHeZQaDEY/mNRbJcjFjUBpiVFjnaJuAlBq9icN2Pm09fMAHl3IJBSA9QTkG4xwZIt16jWvX+K5FEzBaIKRh0dpzMZBHYl3Edw0mKAItQnmiCyjj"
        @"Ud4SfYvW2XnOSejxWtFbgm2ItkV0DcpaVLBo0RGCxQhPJVNcd2c9rn/mLCnIsw/fox+0pOl3FLgI8+WS4+MVbd0hfbYZ25Hlgiak2YISHhUjSkay"
        @"XDAYDKgGOTFaLuxvI4Ll+ME93nj/fc4e3mf24BFX9hQq7jN7fJ8yF6jMkClJ65NuIVMK31mkFBhtiH2MuPeetmtoF2vK8Rgz1ogiUrslMlZJHGVb"
        @"hCwILg3b1l2DEAXSJOu0C4K6dbRCsfapAnNBovstvwgBF5JJTKiUIr9uA9M8xwWFJEOTEVTJzvQyu+U1mvuP2Bo+4vD2P+Y3/sH/eZ/q8/9E736G"
        @"T37x5/ajzo50Zq62y9kdkYk2xG5sQ/dprc3LxD/ONeC5bDg8NZFMkuANyEFKiYoCgmgl6lCrjMIU2MbiuxSTFkKaPMcgngA3xMbwkYZ4+A2SKv3B"
        @"tQIlBVpFpPApRip6hEyzA2mg8y2qSC2BKJJDTGaKoCGq5AnP8wLhHHleQiXIxvuUY03z0PGjtx/w+T/7p5l2HcfHR1TDCVJmKNHyhY/vMP/WQ06+"
        @"9/vE4ZRib58P7x2SjUZcuHwZkxvYvkTTdsyXa1Z1QxciQacDsbMdKoTU2ohIkOCE6q2wkiAkzbomKwIieiS9KCp6XBD4GHHSEBEpe9D7JEjK045b"
        @"EPC2Q0SPDx3Bt5hg8Fo/NcPp03mcI7oG4S3Sd6jQoWNHFh0RRyYiRgWMCGnpo1Kajgx9km+0oGLiC4jkomysI1eC+azh7HRFt3aE2Cf0uBYhImWW"
        @"YW2DUY6hFpQxoAMMc8NwOGa4c4UP7nzAe+/+iIe332H18B4jBc9chD/905+jGmlOZpLGWwohcdGCCkiV1IIhun7eo/EuGd5Ags3wUoDvUAODqjTt"
        @"okUHhxQGh8fGgBMGhKJxii6rsHkq+2dSUQSwQmCDwCPwUTzJIxAeH6G1IS0RHHRBQT7AeYPJJEoMGZhnENd+GupLFBcfUYx+k7NHH7I4/CZysKDI"
        @"JD/4/m8dPnvjJyeB6k6hTd750EI5HxaDl70Nf9wtQOh5An8o3CHKcwTThs9PYrzPRQ8gWS07nAXvRX+BRKTMkaLt4Q6eoFS/ohN9r59mBUKAkCn7"
        @"L9OSDZ9GaQG4lLiTa2y0ZEWRVidZTCsyGXEigTw7HKbIsF1A5SoRRi5cYO/yZe7c+ZB7DwE7RHzyT7D76B7dgzMe3HvM/QczTo4dZZDM1gve+/AO"
        @"XT5g+8pVtg/2ObY1USh2dvcpipLxpMSPSs5WC44XCxofyUyBj44gNFHI1O5E0XPmPS54jFZomSjHWd/P4yH0XvnYpzNBwnvFEAjB42xL1zUYkyOC"
        @"QkRNjA7nW0LP/Y+xT0MMgRg8yneo6FB4pEhlvPRdEvbI2P+awIuIFiBln6YTAjJGjIooHchUz2AMAbzCdz5FeYc0l6mK1Brha1zbMhmWadbQNext"
        @"jbl26TLOax4+OuF3/8kbrNdrTo7uc3LvHiMBL9woeOFjO+xMBMF3ZHmJkKkCC65DKYVzHU27xsjkDlX0q0qfMhm0kPgQ6RYrjFTkWUnjPbYRFLnB"
        @"CN0rSAUOleTEUqWBXoCVh6VL4rLOCYJSxKBQok8CkgaioWvD5t4iigFUY0QcIqRHhApTjZ7IWqlg7ZgMIsF0qGlLG26jw5TpMH656fzL3rdtWVZX"
        @"H53M88FkcvPHTgb68W7/5NDeWIrPD4Eoz1VK8inQoEIhfMitdXgXUyiG4FwyHHwk+ITVklGeKwCJaUinZNiwPpL9G4+IHqMT4UUpgTEKpSVCR/LS"
        @"YEVDNsjS/MGkh13lJikDtcCrAnTOpNzH7F6A0Q7ofQbjPZruQ+oZ/MbXfputieD46IijhzPaRjKfdzw8CswbWDlYAuvFgruPf8Ao/yEff+FT7B3s"
        @"8eDsBKUj5aBie2eHS1u7XN7aY7lqOVs1LLJIFx02ClyUEBKoMqb6HKVSpQM+iZ2CSxgt0q7U2QYtIkZnyCwBLglJOaiUIoaO5EGOxB577bw4PzQy"
        @"oZAhIIJPLz4x/RgtKnTI6JDSo4RMM4Qe0YVSaVUbApHUr2u1gYx6jEhx6KPBgGADrvNUWQ4xUmWKwmh0MJRG47qO0XTIpSvPI7Tk1vsf8PYPbnFy"
        @"NGN9uuLx/QdMc8mN8YCDXcGnn73I889sQ0wiqEwammVHNRgTLOnPiiFTOV1bp+dPJzakF66nEifoqz3xDKoRZRgxby0hGowsEHTYYPH4BAsRMb3E"
        @"Ph3AzkWCVyA0MWiiMPig8SHZ0CWa4NNzFkMatCo9gGqKERNyJfCuY+VuMaCF5gPs/Ix2fovueMZY7kE2Y929wdb2kDdf/82vf/KFn/u065pPy6jf"
        @"nG6N31o2TZ5p0/6YPICn6SD/8qJfRNp7nvfy4qPjAKnUOd5JiUgMjtDUCO8wArIMpDQ4J3EuJezKEJE6IEVA+hTtnEi+STQh5Ea+6hDSo01yr2kl"
        @"yHKV7KpZOixs6xB5htYFmISFUtUwsfFMTrG9DZ0HUcJxw8Pvv8vRvVd59bWbNL2u+3t/8CFrt+boKL2MpYJQJzXWBQ3DbUPTRKyQBDPg0WLJ7e/9"
        @"gPcFXLp+gYNrFxgYxeGd29y/c5vt7V0ODi5x4dIuZ13HygbWXcOyc6y9ZR2S4tB7gfA+DUOVwRSgui6V8xGii+RZhvOOzicQqkBuMknQMk8tkReg"
        @"Ej0zbUmS730TwaX79l3FpPUXwSKCJYZkXFHSo2SvzIyp0tIifW5ucoQRGKlROnEREYFMKoyQbO/usl43+K5lOBmQK4sxHUVck8vApCi4sHeFICUf"
        @"vH+H9+/cZTabcXpywunDhywe1lzeLRmIyERafuJTn+DKpUFa6YmIVAopJa21UJbkItC5Bt9ZVFGgpCFE37MbO5zbVKSRTCrWiwb0GCWSKUwERyhT"
        @"apPzDkfKFkjdZcCmc7k/VDURBcIQpE65lTEgfH8xWtBFgfWSIFYEMQX9LOiAzCJOnOH8CbPZGZ1fEtYrRpWhdCPiesn86HW6KuP4/QU71wxv/v7X"
        @"3syqA5795Bd/SRW7b+VSt/KpF/gcmPp0W/6HNbr9vED0n6zjZl8n4kc+fQMLF/EPbfme+q2jAN/fJCqmaWkibvUaZRFQOvHyXBB5kZlW2rMva7+i"
        @"qiRZj6oOHroWYicpkBRREGOLkpEcTXARqQLSeKTsQKQyzMZAkCBVS2YqpLAYI2ixiEwyvHyZ+vYHMBzB7hVYd6iQQxfh1OGOlxwevsV7t+7ywcMZ"
        @"h/OaD+5FlIFLFwbEoBCN4dHJmsHVEV/6736CSwf7XNve5Xo1IT56iDx6xOLREfcezThctDxYWsZBMATOItz74BG3P3zEZH/C/tVL7O7uMp8vadfv"
        @"YVTGuBxzcW8HVWhORMORbzhuPdFlKDVFBkOpKo68g8wgZNNLmJOfPzqPUpsorcTnk6rnEvoUUBpDH3AqIlqpXr3hezhoYmupKNEhyXxVSEapJ8aV"
        @"BGUVUhBdixaBUhsypQkiOSRVFOQK8jzdjkJIiqKkmAy4c/gAlSmGuSDIDi2XXLtcMa5KlB7z9g8/4NY7d5ifNqzO1pw9foRrjplm8LFnS7IYKDKJ"
        @"azu2JgGh1mkOZAydbRiMB9THx7Cap7lRSNZhIRMIRsTk+080JkOwm8NMQFDELtARkIWmXS8JbkBAI1XKgRAxoLwneo9TsHZQFAUieJzydCJtQKSW"
        @"2K5OLVD0qR2zER8NrYDhhReBLyKrTxLCAp2dUXJMjCukXeCLY7zXGHmGUycotca0lu7eh9y+/S6XnvlZ3OBTTIrVL57a7C0lp39fRYO1HpPney7Y"
        @"Iy8DzlvyQTZer5eUZd4ul8sbo8HgLRElXd2R6zIlVYfwpAKQfFTE9y86/1Nh0/u7PpJJJ5ZcDxt11mNDHGdZNl+tjn9up3DPz8/uoM/uM9nW2OhS"
        @"HxzTEEwiEYSkASBilMGJjo0hTYVArqAwkOcDTHbGYDRme+8AfAsFZKMSZMAf1szvOx6+9xar9esczxbMF577dyGsIItQAuMt2L/8HJ//zAs8+/HP"
        @"MPzkDdgu4XjF3/rLf50f/PAWX/zMF/m3/+P/C6yX8PYP4Bu/w53Xv0+4cxu7aGnXoDyMnaR16YDMEFRKMROB00czHj6aMdnKuX79OhcuXGCQRxbr"
        @"E07u3kUax/hgys7eNoNqxMrm1F1OoOS0bai2JszX6wTrVB34eD4gTeGl9FuK9MBvvpGyl/xK0ngj/XNEhtATcPpNTZDJ6Rfo5ykOQTKiCJHiuJWM"
        @"ZFphoiAXIlUHeIosQznHaJSjpKVuPEIKnnv2IovFDIhsT0aIUHNhp+CZKxfRsubtt9/m1q2HdGvB2fGah+8fMjtcUCjPxQuK/a0MI2F/e4utyZh3"
        @"b77DfHHMaLqLFAYbIkH1rCAZz6ubVJiGfsUZn/hKwsahJoiuXz+HBGSNUqGMpvEt1raJGOSTziQ4j3RpA+V6ZkKMKf7NkVoDv/lWhJDSIfpwU2cD"
        @"aIPIFMJMQV+G0CLVGmEaVL4AluR+SeyOCd0jYnOEl/chO0UtZmStINoZd+9+k+HOnH/4tb/+0t61L/za53/yX3/TMfrlIqu+3li/LyKUxfAbMVM0"
        @"7Xqea4NrHbnO36rX7VgJPc90jnMOoxLuTcu+dt+8+E/aAPlRfV/8aG7A5nO1UwRpsaZ+0cswUb58WfkM7WWfAqspy+H+YnnSbpcxf/X13/ylB9/5"
        @"VfRAsXAOr8GrllbZdHOrDK8EUZg+1VchRUmGIgslGZrcW3LAxIrBwLBca05PYTZr+ODeXeazJb5xLB93rB9DrFPZpgZw6ePwMz+5x3PPX2d7/wAO"
        @"rsNwF7IROA0yh24Jqxk88ywvPL/DrR/c4vBH34d//Bs8+K/+Sx794E3C4QxjwTbgfJLuApRasqcVJnrGER62DhUhBxoNi9OW75++Q6HfZbK9xZWr"
        @"B0xGFZNiyMOjOesHJ5SjKcPxAQKL3B2BBikDRa7xNic0a6TOUnrv+awlZR+kH3mCQ/Pp5tMyfb+UkH1uXkT5gI7JT6ZERBESDbeXl0qR5g5Kpv1/"
        @"RiSTklwoDB4RAsOyBN8wrBTDMkFhSq0ZbY/Y3c65f/ceykEIK7a3KrrVnO999zaLsxXBeZaPlzy884Cjh0t0FFy+MGY6VBT5CilrLh7scfXKAXvb"
        @"Ozw+eZ+zsxmXr18kIM/BLlI8xRIMT0FEfTgHlWxWx2nl2WvV+k/uug6iJMsy5n5O0zQoM8B7h48eaz3Kx16/kXIcN3BZaxMwJRDSYeFzAhIvW6II"
        @"WBydTxWC9xZ8nb52MQNZkK6gPVAgSocqLYyW6DCHcEZZH0HW0Z0dcXz4kGb5I3z9Og8O/xHf/Nr/9NPVpZf+Rj69/je+8BN/ltaCYPzLZ7OYl8XO"
        @"X0WZO46MKCUmN7lzDiEiztagNG27+vGGgCKm0lEEhY36jghhnsjCqUQlgnUeIe3NSW6v3nz9t74ejr/D/ORHXLxY4ETqqaUKRAktLUVWIVRAaING"
        @"EbxIqyYHGsEg0wwy0HNYHdfcW5xy9s4Rvk4vo/cwKOHyluGqHHHp+oRLO7sMd4aQedgrIPfExYLZ7TdZHn6TroVlNFhhGORT6rpGFYLP/MSf4NrA"
        @"sKvg+N0ZP/rbv0L58CGDR+nlr9f9zE6bBBv1qVQsZGRKxIhAVsC2gFmAmYfSKKooOHOOO4cn3Dk8oarg8uVLPHPtOruTXbq14979mzyqG575177M"
        @"9sElHi4XVNWIdS3QSmJUxLa2R5xzfsMLIqKXhsr+9lMyvfRSJFT4RjGJCJiQdvASh5ABKbr0e4hE/slUT8mNAeUjpREUOmJE2nkXWXqbrlye4nxN"
        @"21nGWxOuPHOJk5Ml7bJhMpogQk0uBb/78vd6WXfk/XffZXFco4HtCRzs71EaSdedkeuOra2C/YtDhmOFKQPT3Qmnp48RGKxrUYZzoY9ROlF+herj"
        @"yHuhAxtbc3IrySjStsQnYZiIyWEqM4MxOSBYtx3VMOJDhB77LtBYnxR9WUGqWCPYLhBDEl/5mOLHPZGuR9HrTLHqWjoXabtD8PeRwqW9YJBpDC/S"
        @"tiRZNDd6/36TMNmD9gHZwQ4XtzTUy5Re8vgYu37I/Tu/D4/v8Xf/33+danSF7Z1P/EVd7PPJF7/8y12nDpGyDUha644615IXBuc9Q6PGbRta/U/f"
        @"/H+U0eefFgFFAVaGlCBkt1ol4h3ZS0SjbAlIBuVgvJrd+/lCP/oV0b7Ho5vfoOIBxCkXDwx3hcWI5H8PwqEyD9oi+7Vhlme4taVt1sgwYDoIrIdw"
        @"7wgWh6dsKXjuSsnWdoaJsDWumFYVmRSI1mJsQJ2eEY4ecXT6mC7ahLyKID1sV6kyHGhN5yXDyoJQzMOSs9PfY6fa4kAm6fijH77P5wYVJ7NE+9UK"
        @"umiQ5GlaHpKs19BHSAGlhGmmmUTF4boD61FoymzEthEcrpMh6rV37/P9d+9zYzDh2sXLZJOKndEAsThjdHCBMw3OtUiVJNXOtSgp0hwgin4r0qvp"
        @"ok8U/NSFpZc7iiS06UNNowApAhkCGR1IhxCutxUn64kUgiwKSmkSb0BFBiaQG9AqkJlA59dcvLzN/rWK2aJBrCVXr14myyYcHz5kazSmyDKisyxn"
        @"S+7fnjE/nnF2tKIy8LFLMCwVRZYjwxmZFFy8OuDiwQHTrYquXSPUms4JplsVd+9C26U33PSDTCUiuVEQUksjxUfBrzFGYogo8SSePcZNOSvxPvVs"
        @"Shm0zmhri+1L/uCTZ0RIg/WBroNqKHurusTajhgkQeZpTqbWKWvAuVR1aINrl6gMTH4PwpDIjOjOkK7rUViu3xPaJIrxNXR12ubU6z6vTNLUHa1T"
        @"LGuPR1KMriH1gKYOxKg4eXRK1zykGCl++7d+6+u62KEoxrz0J7+8P1+v5sPBYGxDdzQajTg+Pdkfj8c3f6wKIIj0FokIIphxwkZxBOCFROAI3ePJ"
        @"/mj9C2/87t8tZu/9OqJ+l61hA3FNnmkKLAUJWqlFoMglmXJpcBVBBEuWeUoEZSZojCPvUWDKw06uuLH9DBMtWR4+wN8/4WH9ANek6bbxKdChqDSm"
        @"81QmJzhPESU6etzKkw8gljnL2iJnC7QxiAxCe4q6kDMKcBc4fjin3ZNkEoKUqTrxyaighMRIlVaTaiODjgyzjNNlh3aOncxQDguOGsdJV+O6wESC"
        @"FZJBRiOCOqxX7bXfv/kDNPC5l77AhbYhHh9xcHDAnbMlJjPEMmN5tqIoirQ6Dekm1E81bkqE9IL0w9zEDNy4IBONJmXZpR9DD9xON3+iGZsYqZRk"
        @"oCUmQqYiVQ5CdgjpMANNNRhz7cVn8GJNWW2xbSqyg+ucvPk+Z2dzMlnSrGuuX73M733z29y/c5/tasCNSznTSjLQjtHQMCgNJlcMx4LdgwGTaYnW"
        @"EWs7pMqIomE0rmg7ODubs3NhSBAWRRKGKaWIfpP3/dFIcBEE55r5fuicXupUL6VZVUAEickKVssZTdeC1KnUj5qAobEd1pIk3ULgo8JZweYrH2L6"
        @"3keSC1ameEWcj5QlVOUa2new/gHSHSNDC23qH2NMKk3bNti2xbaO6BTB5dS1IjACvYXId9i+9AxmtI3OthFiB1nt8sXP/hQh6sOO6uvLFZhq53/d"
        @"OjDZaN563w5HBavV/CgKCEGxs713uFzN0fKPYPn90Tf/078e8Sq9qBrbv/jp5ScasugYqZO/9tbLf+svHr79NcLyLaSbYUwJg30u7u4zkh8yFoaV"
        @"SBPoUjgKYVN0thB4bMJxS81wqOkaKPJk8so7Rbfw3H//PseuhaZhUPT+f51KYuVIyr9oqFtP9AodM1RUWN9hTUPtBfWywQhDSYZtAs5FXOto8xUH"
        @"+zm3H7QsOzhtPGWWs+w81kcyIiK0CTEtYhqfBXGOCK/POoZVRlkYTuuGuK45yDNGpuTENixEZB4lZ9YVXQzXpMoZ+4KZaHjnvZtc295n3XomW2Mm"
        @"GdQxoEuDXGmU1Mg+uJPYr7cS4Z4+kjJx/Hqm4sYwJTfjfxGSqEJsRJyiD8YQFEpQRBhoxTBTZASMSVkuQYAqDKP9LQ4+cYPywjbz5Ywy1xSTXTie"
        @"c//RA6TxlHmqdu7dX/AH3/0BeQEXd2EcFNsDQ54bIg1FCQeXJuxdqCgGOmUQKEHnJBFLQFAOSrIMjg4fc/HyGB98bwYTKCFwwafNTf+fJkQSpPno"
        @"CCHh4eMmtNWnCidEEMJgXVo/Z1mB92fUrSUvDTGKnpuY0PAuQplnIBXOp4xPFwQhWpzwvWO/H4WLdLh0LYgMJDWsHhHcbaRfYDuL9BpvA6FrcXVL"
        @"2zisK8DsQH4ZP7jK1nOfJh99DFkc8IWXfu5bnVOHMcp5DOowBMiz6mUXL88aFybalN8qdwfXTs9m++Ot6fz0bF4MRsM762ZOXmUUWXl1NpvdaRs5"
        @"Nyr7bwEK2kMJo7Sp++wVVDrWFPH0f/XWN7/2F9t7v407fYNMPmI0rYjRwSBjsjtlWHzIQAsygGDJsJTRJwSXkQidHgAZHEY7JuOSZWMps0C7TCsw"
        @"hOvtvvK8dxUiBYdqBXXnQdpzfz3e08XkC2gCCUPWNIAnjx5vU3KsDB67WDApCzwtRx4arVFSUtcrqrwkD4mfF2NSjQmhk2oxpty6qojYLuDcihwY"
        @"SUnjWpRQZJmmChIdYaEdC5/+W4RON9bibMHpo0fkgxXZg232r1/lzmIFGApT0DWWLEs2YxnTJFz1rJ9NIrKMfZSGSDhv2RuokgYgKfo2Sk4hQQuV"
        @"tixCUKpAqQO5thgZMJkgH2bELKOcDNi+fpXxJz6DbyzjwUXIBBh4/zuvMlsu2JqOaJdrhKz40Y9+yGpxyriEcdFyIcswcY0yksGk5NLVXS5emkLW"
        @"UK/neO/JywFVVVHXNRHJaJgzHObMZovz3h75hPi0GfhtZhwx9OPOkGLlUhAM5y91DOnvEZLQpRBSrTUhRjrnyfq5QQwRj6Bx6VA3RvWZggmxFgBH"
        @"wMck+0006gZJyoX0HrwlDZfbI5Q7RjmHW3VYG/EddK2gbjN83McMrzI9+CzF/gsw/QQf+9hXEMXOL3kx+lvL1UGTZ+MjLXTuomulTrBYlRm6aOmC"
        @"RLTxKOYlZ+s1+bCgsXUujWy9t8yX3Z08z/vZRuB8BhD/iJvf90GQm4hrEQLGmPP4JRkyAknN5iTjLMvn0i/y0j76lR996+/+YvP+b+HPvs9YdmSj"
        @"CjnOiNkQKsH29YuMdl5jYgxbUbLoAgWe/cmIbhlQxhClIytLZPDkOjLcm7CoG0bDBpOGmYSsRusCKQQm0u/HQ8p6b9LU1mSCtYtEtcLo1HpJnyQL"
        @"vu0oSJ5N75K7UIT08sTVisFwxE4pWNSRe/NTro3HmFwjQkfwXbpJAGUMq8Yi8hzv0kAn+lRuG6WIwfflORjpMSEl6yptsCrw0FqitlgfGZiMpu34"
        @"3huv85WvfIUHb7/DJ3e3ubw14b37x2Q6p0s8LLLcoHtXnwybuOzQx5ClflnEjVbgSSWwketuwjGM1GgpyEWgMpGhEZQ6UOaRLNfEXOLznHxrwv5z"
        @"N5jc+CQhlKjxlDBfIpVg/fbLHD24T24UITp2Lmxz99Ztbt16FUXNlb2Cg+0cuZgxGMD2lQtcvHqRspLErEVojykM3mo669GmoG5mbE9HBBe5fPES"
        @"r776Pl2TgKBPsv4k1jqyLE/2cVQ/AxBooam7liKvsDGipMJ5m9Z/CBrn0KrAWk+Ikcn2Fo9Pl+TlEELEWk8+HXN0/AGaRKEWSiO0ofUrglCEKLEB"
        @"MqEh+v57HvF+TeegnECWOcJyTrAtXW2ITU4eWk7nljruI8cvEAefZPvGV/gTP/0/uL2wxcteFi8HffnN6EVLhCLTRwGHDaKNUmFFJBpFS+glo0mF"
        @"G7VBRE0XHFLKNvRRakopfHQpyVr+C0iBi6LAe896vUYpidapFBqNRnuL2fJolI/Gy9WcclrNbVjNQ3Pv3x+b+V966+Vf+XR973fwJ9+jEIeYgUBO"
        @"Ktwwo9NDTHWB/ADK3SHaRgZB0847hG8pZEQqwaDUBGXJqkhRlQwmgdH2gFlTcPVqw0zCroDSBFRoMVkgFwrpI65n0ut8I0rqE3B9Knd9Tx1K2vpw"
        @"zg50wqdSPoKMDuUjOgRKnVZ5sxacVpgIuk+Y9WJTCoX+FhYEGRItmDSgi32nGNkMplInHkNKKt4RgTX0wFJJE9NKrY6BOw/uce3Za9x+8w2e/6mf"
        @"YWI081VHpjTr1ZytrTHRW2zXMKrKvqdtyTKN7VoUMbkpRVIAph11cmUWuWIjstAR8iAoVGCgI2UWGVUCmUXyoUYORmSTffaeucHg0nXQQwQD6EBW"
        @"E7h7k/de+yG6DoyKUSq5needH77J/PERF7fgwrQAO2O6DZcub7F3/SJ6VBLsCh/b1LIYgYwqxYhrQ54NsNYjhWc8HuIc1IuW8TTHhpDktlH0qULJ"
        @"oxBjTIlSmyikmAZ3McQeQS/wPiBVsiDb4LGdQ/aHiZQa6x2lzghNpG4s69oiRKoA0gGaTFzJ55YmrmnommB2shcltS2MDGSZpmssvpPEekCV73L3"
        @"/Q+Z7L5AObjB4OAnKK58mRde+oWvnqwvvSLz8c303+FRwfXXtOyJQ+BlkuGn1Kyeo0H4pxmd8WkBX5LZb35Knyv8/ogtwHK5ZDAYkBnd56l1FJlh"
        @"MTtrq2LAydnZ1b2dabtaP94v1Mlf++DWb3919s5v0t39L6mP3qLUDdkExMTAMMPlQ7y8TBh8GnmpoLr6m/jDI0plGLiOLIuYTLPuWsrckg9AV57B"
        @"nqSYOvafu0CX11jTcS+sGc9grGBbaYogkC7QNancz5SkXfn0ZYuageyQXlJESe7SmqgT4dxYE0SkU4mjH2VM60efTEqTylAsOuYW2iAYAMYHOqNw"
        @"4kkZqhCI4DEx7YalTIw9FcH36EQhNqEZYCLk3rFdaNatp3HgS8XcJ719HSOv3XyP3b0p4yLnrd/5HT775Z/lh8vHLL1F5IbZ6TGT8ZDpdEqzWiYg"
        @"cVnS1Esyo1Ei9vFg6cHUyYmMERG6hgzIs6zn4QuMcVTGojNHVkREqQhZYLi3xZVPfg62ruJDBaFAKQ2qheOb3Hn1nzBuQOltzmYzLl064LXX3uD2"
        @"zVsMgcvTAZNMkEnNpWe3Ge+U6HEGJvTx9H2Yq5CJE+A7sqAoyyHNukYrz87WGCXg8PCYre3nsMGm9svFc5WfznRCwimJCyH5Kkg+iSQMivgI3vXz"
        @"kZB0ETEKQtzYsRM7UpgSIQLrLjJb1WgNWWaIQtB517+AATB9OI4D4VABdMgRscLaM3b2geE24bRCoLB+jJPPcelz/zpydB25/xwff/6nkaP9/9m8"
        @"y2+acnIzRInwqUJTMfE1vZB4AU4mE56Kvg8Kkf3W8+lU5B7U+JH5niDw5Of+uRVAVVXEmNJZhIg41+V5pltBmITg5rvb03lXz+7ceuvlaGdvcPfl"
        @"X0bX71DGh4wGFsoCMRkTq4xYbpGXByh1laA/iRwLrn7qExzVxxRSkM0h15bpoML4jqK0jLYVVI58N1Dul/Dx61zZmcAwwy7f5sIcxp0isw7agOsi"
        @"wkDmBDJIJsWIYAFhECEmSASy18WntMCU7ScJMeA3fvb+yyQ8KBfYKiqGquORh3nj2O0l0FGkoQ8iTBY00QAAw8hJREFUSStVH0euEPjgz78PQfYi"
        @"lZ5sJJMPDxUDup8NTEj0KiU1wiXbbUCy9p4f/egHfO5zX8Bj+OD1N3j2+Rf48Ogxp4uOQgtc29GERDtWUuC8R2iTsu42xikCSgSkAK3TYC9XhlwK"
        @"KmMock1pfPpc0RLCmqgN+WDA9U9+HPPMJ4Bk7lFFlR4ut4SzOzx49bdgfUIRNK6x3Lh8jbfffps3f+81WHRc3ynYHxVkomZ3b8zu5T2caKn9IiUZ"
        @"KY+Ssu/j0y1sVPqaZjpnHVapHR0qBgO4e+cxn3jhBYjr/gUXKGnwXXJ5Bp8CRMMG/YtMEe59/08/HPS+1w4IjRCW2K8NkYLOWoLxKGlAGOaLwGCQ"
        @"DlClFHXbEPBPfk/hUzUlNpmGms7mdC1cuvZx0LtEJgThUdkVfPYJso/9GzSrgs+++Kd+mdHVvzmr5SwbbN1sGwd92PDTeZ0bBfPmYVK95iG1ePIj"
        @"l/km4SuJ98RTRj0NUeQfOQCC+KPigwNd15HnBqUEUqi2Xa9fGo1GtxeL5YtehLfGhfvyl1+8zDf/q79OvnyNUj+iHGhiMcRWF/CTZ5D6IrJ6Bsx1"
        @"jNzGY0Cdcu0TN1h98D2cCNQFSGkZDEFISTWQVFMJ4xwOcsqru3D5Olz6GJdHI5zviB/cp+wEqg10c0+3hgzDUI7IXAFNAfMOX1tqW9O0Fq170R8C"
        @"71XSg0cBwaXdhkynqA/9cKeJTKYZQwmHHk7XFj/IwNZsdHOCVO6p5IFG97HhQqXh0+bmF/S8A57EbKnoURiGfQGXRYGPoJB0IWUJHp3WvP766/zJ"
        @"P/ElTu68T6YVVy5fIricJnrqtmVRr8iyjPF4RJ6XONsSQwqhiPRMhJiqFNOvCQstUcETg8W5Fk/AFFBUClMMKLcKLj13HTMcwGIG4wnSSLA1aA+H"
        @"r/Hg7Vfw6zm+bXAeJpMh88NH/OiV11jcfcxeMWRvqNgaSqRUbO+N0VWRymYVEUYSQxLX+BAR3mNUIMsVrm2RssBIhQieGFp29g0337G4TiNl1pt9"
        @"xDkirs8wSXbyfhWY8HIegUkCn75NcNb2GsqA96lVElohlKJpGjpdotQY7wVnC5hOUyGdZRmzxTJpBYRF0CJI0V0yZqgQkKIguBwv4MbH/wxMPkVp"
        @"jzg7mzPcfgm98xJwmedfeukXB4Orhz6oWfTNYWwFOpqe2pxuei+evKMihgQV7kV4IqpUAYiPErkRT/l64iZc9fzNHv8LVQDe+3MLbtusx0bK+db2"
        @"hLOT009Ph9mhax//B0U8/g9//5/83zn+8Ddx9R3G+xmtMVQHV9Hbz0J2GbgIXAa/A2LQs2RAjnJEBqNhTpgKZIjkmUMoMFWkHGv0wYh4dYfy+g0Y"
        @"PQNmitA7PJNN6C69hZmdIBYeOtLvHSp43MDtU9zpGd3K4dpA6x21g6Jvi9RTrsUYen98SAhxL2QyKkUFNlBay8RAZmG2bunGCq1iKv98ktr6ABrZ"
        @"476eyKvDubi2l+ciUEGg+9xCJcG4SKU1C+eQwTOOAiMiVkoeN46phscnS77/2qt89osv8ejWD6lKxTMXr3Dr4REOgcwylssV1qaUowRHzZJTkn7n"
        @"Hx1ShP4Z8TifmIJSCnQUCC3JCs1oPKAYa0a7Q84WS0phGO4NILYgGlgtOb39DvbxW6wOP6DSU7rg2b9wQLtY8V9//R9ydu+ILRW4tjNkWlqkbBhN"
        @"DdODKaJIKjypJVIGfJe+VkaYpC8JFmIguEBQKfglBEfbrti7sM/rr93j5GTNzl6G7dapbeudbs4ltNzmxu8bL5zbuBqTWcmFxEp0vksHQYxkRqCN"
        @"xpjAYrFMRhstmC9XrGu4fFkjCOjMkAo8eZ4MneoMlUp2AUZFztoGUxiee+ETsL0NcY9u4aC6BJMbvPDFr/yC0+NfP1o04+FgMkenZCmtzY3ONjfP"
        @"r3jCeY+fbB8JuINIh3v4Q+v8KJ84ApM7Nx0CkkDAIeEoCND/PJ5IclDpzWk68THm6+XqdlVkdOuHv/bua7/2px5/+Fvc/+C/wHDClRdehL1dmF4+"
        @"/8JDDdyHsMQ1HyL1NlGWYFrA4myDQjApDd51lIXACE0wAVVlFNu7cOk5uPACsfgMMWwhJ8/Bs5fInvs4rB7D4zW89xBeexf/3gc0D2d0xw31saOr"
        @"N6IPjQ1QCI20SR0WMoGLSeud4JzJZaf6W1hEDd4h1kt2ckPeRJbBsRYdpQHhYjLRoEkW/YQxkxiIkdAPhmKfkdADdZCpDiUIMEhkK8h1TodDENhG"
        @"UTnwuWFtWzAZPnTcfHCMfPsNPnP1Kg9++CY7KmNcVeAd67ZjPBgyWy64f/ce+/v7ZFom66eSicxESkTSG8CK0Sil0VqQa4lQCXDZuEhsI+3JitH2"
        @"iCov0x98fUb48AMe3DvErmaY9phhVjBrGqaXL3L3dMHr3/4Os9MFzazmk5cEB9OaYiAxlWR6cYzaypKKq7F0XaQoivNnTRoD3hJcl+bZviMGjVYp"
        @"68GHjvF4jNL3uHvvmN0LF/EuILRMEl8hsT4dcDb4nnsQzy8zgeojz1J74X1S0W1CSEMALTOU0X0sWnq5Hx09JgDDYYXWKuHunU2r55huYfoYOYnF"
        @"aIfOWhazY2Jl0ZNjEIame0QtHJ0pwAYWbdsWg2GucjNfNXN0XtCJjrZZHqpMn0t0BSF5OWIye+meuRGkw6vUVqZbPn5U2ftU1bCpDJJS0qZW8CM2"
        @"37hBcG0IO+kkljFgZPdiZtqXjPD7MbYvvfIH3/7q2dHbvPv6b7BbnXLtYIrY2gcvsMcNzcmHeCWQwqZADpmjiyGNM5SDCwg5gKChdAQ8rmnBdSgJ"
        @"WWHQwyG1CLjBFF9NUVv7UGwj2KYWJZWMMJjAw5r1G2+xePV9uvcPEQ9mmEVALsGeOkw0uGDxfYad9xB8PxU+T2lLiC6B7zMEYj8UelI02cZSDioy"
        @"2RJCsiNnkt5M80STnmozQRRPDVs2uQRxQ1FMhCMZY4rsQoB1GJknV2ZwyfxEZEflNLLjrO0YZ5rGOt67+YCBtTz7/Md5543XOPjYx9mZThHBc7Ze"
        @"MxwOiEJwMjuj9RWF0VTGUGaKTEpUEtEjtMfhESKgkbi+KnJeYL1Ee8NksMVwMESEjMfv3OLR/Qe4pqbMciolKQjEIPjYlWs8ejznO7/9Mo/eex8x"
        @"n3FlX7KzJdF6SVENGO6N2L64DaIl+oDUgugcUktESNh3fMRZj4wx3bJhfS5iShNxTZbl5DkcH58ixBVcSIdwCKFn/kVkVGmlaxKEM0aPd7EPok0t"
        @"WQipapNaI3XEW0vXWnKhUdqkHX50+ABnp0tyDaO8pNCK1lla24Esks8ARaL3O/K+qlM6IHVHVUIXHmAfnXB4+JCseoZq5wAnK2SWv7JolrmUujV5"
        @"fk54UrmcC8lTN/vTXn6JColqHc5l+eEjNK6nXb5/GOIjnvpRe5HEEMH5cVkO2vViPc60PCqyPLf1os1VdzXX7UuhO/lrr7/6O5+en33A8dFtPvzh"
        @"1zBYJoOKer3mzuMzBncXnJ4dok2kGmco6agGEpRDFwaXG1AKr6cgFTrfBuMRWlCva7YzOJ7BrGsZb19ED4aMPvYpuHYRtjWwBu5TiUmqKGbvMv+D"
        @"b3L67Vco73qmZ4HVcYtfQ7tQxC4jya01zjt8DJRS0DVJMqoyhXe+L5R8OhljagesCimUJEaMVKy8QKiMYd6xcHD0uGPrYIdQHzPIDNYFnARjNI2t"
        @"yVXW48ni+WnsIrh+COdID6IW4J1HaYkLjh0jmXcBVQq8hVGIXJAZKrQsvcdozWPreO/uY45ax0uf+0kOf/AWy71t9q49Q1QFR6sVThnEsGAd4Wy2"
        @"JJOKTApGRcne1hRUTpSWzHSYHAqjKbSgwDOoMjItUChODle8d/MudbvC2Zoq10yHJaFeEwtDMSwZbO1y50e3ePO7b9C8d5vw4DG7JRxsj6nGEScW"
        @"yFFk+9IIMp+cc1IjhcZoj12vUCpPzioUShmalUUbjcwNnUu8hyg01imMrrhwMOHu3ces6qZHeaf5jfdJWhuiIgaNCyk9p3M1Oi9wPuVYy5giw5U2"
        @"yRadRQbZgMVZy3rlGQ5zSpPRti0Bz4e3jxkY2CkGKBE4rRtCZsCF/lCPBNuxvVWSNQ7ZCLQ0rDs4uAJbpeX07j201+zvX8O1EjmqcDFMOuf3R9Xo"
        @"FXykrTuyTFPIFF3nnnqFxWaAHBQymDyI2AqZrM9Pr/0+6uuRf4jn8Yei+2II5HmeN7ZpFbHNjT7KjaZZr9oyU7zx2hu368VDZsd3OH18Qr2u2d3e"
        @"ZTq+jNYaYYaQl3D2CGjZmR+BaFie3MHXh6xnDwj+hOlWTqYylBC085Ok4OlmUF0hZILOghkVPLc7ZnDlInzieaqySGmLH7xPd29FLLaQgxaztQ/Z"
        @"AnfvDVYfvk9z5xj9UMFC4FbQrgEroVOk5EhPlK6vjpKyyynRy409HxFDiT7kE99/ek+4DRJCitc2QOOhdpICTXCe0EdAeZFCPX0vUInOghRpNiA2"
        @"/VjqQZVItYAWghADkkhJpNv4yqUgNA0jrQnGoENAh4gFHgc4PT3jD779Mp/73Odol0veeet1rnzyk1y9dJH7j09oQ+Lf5XmZ1mImY9E4mqMzlDIo"
        @"6RiWgiqH7SpjkElMsMSHR9iuTqQlnSqyzECuFZPMEJsVW4OMrckAJTVvf/f7vPfWTe6+8z7Ht9ccbMFzV/Zw7owoNMOtIeOdITKX/RSyH0j1qj36"
        @"wBZPmnRtjDbBJ6yZtbZXNEqC10ShqKqCtp0xm68ZjQt8t0qEIL/Z80cCOvn++yorxBRrHgN4+oohQSxw0SOFRJkM7yzeur5K1NSN5ewULl6s8F3H"
        @"cFDxaL2k6VqMSiEnUgqUgUwIpE8ajaZZc3gEn/n5Cdkgoh/PCW3G4tEh08trPvH8pV+Wxe4sL4s71lrwkdFotNc17ZH3NuUwio9u9tP+HwKx3bzZ"
        @"8l8kH/CPIAfrKgq6+TKfDAfz1XKO1jql5GjB733n96MNinJ8la/89H/nJ2yzvJor0QjcNd91LxaT4c25a1l161+YVtXXXVP/XJGV3xCu+bL0i69+"
        @"//d/ldXRy8zvfRtmRxTrGdVoiIyRbLqdlEsmcPFTzxBkzt72ZVAV88M78MNXebyaUZVbeG8xA0E+HKOH9zFb27BT0r33Gid3H3D4CMpjT1mDdhAa"
        @"yCPgfU8ZBi/Srjf0/5vuZvERtsHGIHYujeipxht/ufCBUqVE2RZY2ZZCyTRcUjrFYUfQOrnElFL4TQy0EOkB8xG/WUz1q0QpRWL5IciVxliL6yxV"
        @"XmBFStmtosbGjiAEnVLY4FlaOGlXfOs7L3PjU59mtL/Hu2+8yXBnj4Nr12kdLNepZbE+YCqDHlRkVYk2OcYY2qah3JkyHA9wixN8O0NqgVYZw1LS"
        @"2SWFkeRZUgdqt+RgZ8Bofxt7dMJrb9zi9HjJhzdv8fhezcEOHFzYQkjH7t4EodZsb0/Z2Zmknql/aDeCKEkP6PB969VLeJ9WoTobkm1cStrWIXFs"
        @"TSY0zSOODk/Z2r5Gt14lzFkM52xJqQVd16U8w/5QdT70/XLkycXZK8NEwJgc13qstSAVQhacni1pAlw82MP5Dp3l1N0pyM0hlmTWuVJpbScVk3HF"
        @"cX2CMTCeDMCtWZzcJ5MjlLoP8x/x9vf/0V+89IX//t9R1fTX27jO89y0j2fHk92t7Xa1svMYOJ/SpWdT9twJDyr5DkT8l0f5feQAkFYwqab7y8V8"
        @"Ph4M9lZNfWRMsrN94Se+UChpWqUU66XbK/PtV6QyV7vGfiPLi/2HZ8tGjraP9Ej88v3F4upkdPWXT1YNKvq/Wej2r774M//u/+lHb/yDr463d3j0"
        @"xv8XWT+iko5iUCRJHinjebq/y5u/+zaz99e4JnJ0OufgUwYzUBzePqEwGdPtASFvcWVNff9Dyot7xAfHLI9XnMxBzmHQwY7JEKFDQQ/WTH1h7Int"
        @"XvRMN2IKcPhnJB08PRYJgdQnBwE2MlQZJTVnwKJr2CsyYucS0KGfH0gpE0vfmPMeLeH3Erw09AMZ1VuelYQucO5rz7GE/uelyRK63EfGyvSGlvRw"
        @"5lpQi8BRE3jztTe58tw19q9cpT455b3TOeOdAyZbu0SjkGVJ7T3CZJDldFpCkXP1uU/xJ7/4E1zbG/P6d36Hx3fewy8VsZ2xaldMhkNyZQn1ggv7"
        @"++zvDsEuOXrjTU6OTnj04Rm/+81bSJs6tWGuyfLIaJwjdEc1LBhNhlAWSSTTH37eJ/FKjGnV5YNPgS3hiZ4/aTaeDOKklHjrsNEyHo+JER4+POLj"
        @"n7iBjwrhUzpx6PUeucqSfkUl23AMm0FgIgLHjXAmRIJL4i8lk5HM1p4sz5Gq4PaddykkTKYlWE/jPE3TkJmi59UmLLru13ZGSQaDAQ/mh9gIn/7s"
        @"p6BbcOXyDqcPlmh3yuzO75G1cP/mK1+//MmfEoXwY40/mg6Lm8vlgrKscC6JnDZrehk3KL4UKuMB7fU/q9P/Fz8AjBjf6Nb2ZplvX3W2uyOlTlFS"
        @"dDj8vvUuF+g75XRw1DaeLvo7uijHay8aU43p1kuUlfNJNXmrblsC7qopzLwl3rF28Pc/8YV/i+b+4qsfvvofsXzvG/hwH+UtIba45WOyANZabt1a"
        @"Uc0FlSioLdRHgkm+RX16SBCC+WlHEA3VOCmtLhy1NCcWO1cs147FDKZCkpFTBIGOEW87lDDp1AyCKBS+36kmEUU4v/03L/351vx8ZdLjrZFE6yjz"
        @"jErBsYdl1xEHFUrrpwwp/vxmF+dOvA2BP8k15UaY3W+gk4ijPwCEJJdpyCjTiZIGYlJSyOR6U2Qo1yE7RwfsVYr52vPee7c5PTzh8rPPocshh7fv"
        @"sDydM71wkWeuXuXu0dH57CFEKMoBCxfR4ynlzoBZF5h3LUpAoQ3CG7rWUVWGKxevU5+dcOfRETQLDu/c4ea7t/j2dyy7O3D5akaVC7YmBeNxRufm"
        @"lJlksruHKUz/otHrKxKhONJP4Rw95zB59UWMKKH7ZJ+El4s2QU+97xDRURQlgwEcHdY0tU1CLi/68JjEJZTSpkm/dehM9ZVc2kx556HPKBA+sfui"
        @"8FDENMANAYGhcxm3PqyZTlPgpykzFnVD23nySuNV6HddntwIZLBIEbExcLyE6UW4dOMK5I8INrB7MIV1zeroB0z29mD2Bm+//Pfin/jyT/0nzuev"
        @"tLb41jAf3Wzqtk3LG7kR8D6RAQvwMgJhnNA4P0YFIEz26eXp4qoJ6mWhIybP6OyKKGJeDIpZRFLX9bgL/iioNEW1wc077/JSmXZnOvi5k5PHN2OM"
        @"dzKjGI3G1LbD+ZiLbOtrZ42+s7fv9zFXf95lB6xWj6lkS+vWFNsGlGM0rjBa0bYKJXKsbTm837G7lVOfCRrnwYOPjtVU0fmG9ZGnyMcEV2L9gkcr"
        @"8JlmJCQiGnRo0k5f9fvhkL6xm7hmuSkxhTwXkYQQEtsthvOyXYgkCDJS0flAFgRDkyN8y7yDLkS0TBHaMsp0s4nEhNvkGn5kpRohiCTmjiLBNIUA"
        @"Jft+2HtKobEkh1/0DiMVCsGqtSlEtSgpVYlq1kQVOV17RiRa8Xyx5LXXX2d3e4/LN27QtSkYtaoqdJ7jN8NI56lbRzaIzNc1j+eGO48e0C2WGL/G"
        @"xZaBjEhtiEFw8njOe2+9ydXdCe++8X1uvX0EFp67DG0L7aJjZ1QyHWUo0VEONQdX9phsDVBGJ1ST6rMdQ0yKPyHAJ7qx9ym7Ef/E4OOcQ0iDEArn"
        @"UjbBxtosRWR7Gx4dwmLeUpYFPtrzqk4If76ndy4dHmkjkySz3kWEUP0qMCJCshNj/PlEPUTFbGk5PYMbzyucryknOzw4Ok6/T0goe60CRsKkyCiF"
        @"S1ARH5m3cOFTivJghzo8QGUC39U09YooGh7d+TajUDK8/jMUdvaX2jj5T4Kqvr5cNciiQOt0CKY1o36yzpMBFcP4iejnx6gA5t3x3x/s5Ugp88a2"
        @"LNsliDDOi2y+WK5vhBCL8Xj8bls3eVEULJfLcZUXR9lAt66d5/PlelLkej8S72AFru3uEDxFWeWua1sXq5fXofl6m+/8fK23ydSY5WpFmWtUI3CP"
        @"76LNJUajAe+9NWeok1Bl5WExl7gwYrVaIzAgK+ZnitYKzlaeyxcLIg5Uzal1aCU46QKlUmQukKmeAxkDOImXaSYYARV6Q5BKvXn6nqfBUIgRrVK+"
        @"XsA/SSt2nswHKq1RpmVlYWUtpdLYzpHw/cmcoXR6oIRW571tkpwms1Ds97oJLikxshfrhkCmJMandaDqQZ6KgMGhY6pctM4QJiPTklI01N6zigIt"
        @"IqVUzE+Om5vfOSpuPP8ptrvLPDo6TC7HmNxxMgqidSzPTlnMTqiHAmdbTGEwnSJ2KaatXrdcmOxzeu8u3/rd7yK6QDODSQXbQ8ilQgnPdCTZGg9w"
        @"3QJVBvb298grgdARFywpVU+mKLT4xChDH4sWXEToDYYriaWii0QNUija1qFVQAuJkInis7ezxa1bp5ydrqjKacqNPA+m7eXrMg0RlZdp2i8Uwacw"
        @"GiHkuWIwcfwd0TmiFCAUPkpu3z8kCtjemaC0J0jFfN0itCG4FMSCCCgchQHpHbosmXcJAfezP/UluHwBNX8fX89Zz5eMtnOi6WjqR3z4o19l++yI"
        @"V7/7TT7z4r/ZqGqwXwyqZiVWR+uwHktVzkUwufbFl2UMcyHqV/pV3zyKzSHw3/wvGXSHl5bT5ek4ikBeFpismLsgUaZ6qyrHr/iOedvaG9HFtsqL"
        @"I++63NkapWTrEE1WDWYhOKSETKq8MEWugshFMGhV0lF+QwyuUuy/SLn3Odq4T7fW2NMF7XoBA83WhQmLDpoY8aZktoDbd2cUwx0WdeBk6Thdw9EZ"
        @"HC8F909bHp01RFUQVU4NrATMbKAOgiakXj8QCVHgQ/oIvW7bB/qoKPFEY91z3jblPLKfRvf9OSEkpaLU5MlvwtpZXO8NT+lHqYTdVBRCxn4Fk6qQ"
        @"jW5b9h+6J/fKnmOgvMf0eYoiBJSWRO/QESZlxSjPkd5C21B4x9B5dkTGOAjKEKmAPHoyEYudzNy+/f7N28vlgrOzE8qySPLn1iJ8QHQR27RYa2kb"
        @"y2w2o14lJSEkgKgxhkxr3njtNe7eCQQPly5pRiPY2powqYaMSoEOERlatA4MBxnbuyOqQYbzbd/Lxp7Gm05eLXp+Q+wJ0r1Pnx6mQhTnSj4pNc6m"
        @"m1pKlVJ9vGc4HFLXac3pvMA5sNbjffpzdp3rK7ikVdgYY2JMHoHYH7ibSgES1x+RAj98lNy9e4jOYDAoMUaz7jpmy/q8AhBCJoy6c+A7OrvEhY7Z"
        @"umHZwYsvvQiZIxsWlFsjplf3UKUkryR50bE/renOXufBD77OGze/+Vcks7HrFkcQENq0QYRxFLH10t1Js1GVJyyxQkQ1/3Fu/zSA1tC6FlOYI0/E"
        @"+pjghj5DxYLocoI3DPLpW8FqolMoilZGQ4gZ3uz++mmnb9pM0smaTjatx7Y+hLkQIhdR0nbZmx/77J/7xa1n/wzV1T9Na57HUdG0lqazsJxz4zM3"
        @"qDWcuchJ7eiU4v37J7RS0opIJxXH8zVtMKysoA5w+8EjlClASYoJHNUtTYysYoA8Z91BG3wKyhAyZbhbj3WgpMElbimtDwQh06ne68iJEmstnXWY"
        @"PCkhiyKja2uMlFRao4HHS0tQJuGhiRilkxd8M+FXqXzdRKRFH843BSIGZPBkUlJoReja8329BoL3QEj2UwLe9sGgIiCDpURSusAoRi4UFRfzgqmE"
        @"kYShEejo91Vw144e3mO9mpFpiYqBUmoGOgcXCZ3k8aMzlrMV3iUTjRIpi8HZllFVUq+W/PAHb/LsNcnWRJMZmG6VaBOYTiuGA0ORC4wWXLq4x4WD"
        @"bbSGEGzi9Av5BMMlVOInOJ+Si/vgJ4nA2xQ9pqKk6xzG5Gk7EnVS7IX0wjZNg/eW0WjEYAgP7h9BTABZY3LaxvbVluol3pGu65KaVSSTkDK65wMG"
        @"8jw/r9Kk1Hgf6YLidF7z4QPHlcvjfkOQcbZcEaWh6yyZ0ueDzNJkRG+RyuNVx/t3DykmsLVXQHOYdsfBgrSwXWF2pox2p+zsjRkUZ7Ttt3l062+j"
        @"5N1/kpuTv5TFiAqqlbGbE2e5loubsHgFIDoDMYeQ8+MEg/ZL8WQkePKhkHFzOkuIIt8w/s9P0N7rlKwTOn2IQBR+HGRIXnjhW0lsfdswHm2Pl13x"
        @"rasf/6mfX+tn2X7up2H4HMuuQooJq7MVk4sT9p+BpYOVVbQ+43QZOZ7XFOMt1hYwFXUXscFQe8Wqi7Q2MpxOmGwP6IC5r5m5lmVwYEixTjGkWVMk"
        @"SXOjOHdwtd6nlNz+Q/bWYBcCcZOyE3vPd79RUCJSCEHeOxqW3iHz/CnDZfxIzPn5R3zqvO5dZ4nN18uJ48ZLLjCbFc9TrD4lNl/t5BIzIpATKXyk"
        @"CGkOMJGKqVJMpWIiYpGFyNnDB41fr3DrNdV5aKgl9vJX2zoWi1XSssXeMRkDwXbsTCbcevuH2BUMjGRUaHa3BlQ5jCqFpGM4zNAqsLszZHt7wmg8"
        @"QBiFKYpzBd8Gw0WICL/xXKSNlvcR50I6nDt3XnFJqZO5TiR//uZrGqPvX0jDYACz5Zq2tb25J5zf5qm/T0vXruvOe2Vx7vlPX93W2XMgr2sdbeMo"
        @"RxNu3b6HAC5fuUgMgsFwzNlsDdL01niHUgYRJVVe4JzDBehcx9rBpSuC4RTqw/eo73/I6ugR8fQx/uF9mDc9JaRg+9pldncLZvMP+JX/7K/z6u//"
        @"+v9Dhfm/LZqzl6Y5e251+kulJhfBISJkWfGSkgnz/c9H9/1zZgDalR9dg/1TjqLQbv45bpIoROi34wEdPQiHjH78xFUYkThkgNII2vXqSMoCUY7f"
        @"/PhP/hu/MBGP/s4r//A/noT7Ga55m+gXDC5mXLxa8cPX14wzlci3Ldx7eMq1y5fovEWIksYFUBrX5fjYcjRfMBhPGE5W6GzFcRfZ1oG5jeRaoYXH"
        @"b4ZxQhL71VuUCqGSblwaieun8UgN3tI5jzYyHQj9FsDFQG7SCzSUmhGWJTBvU+BldB764R0xrZQ2Ay0RnrQWm+REIc8fSVQAszkoSEOlBDVJ0M4o"
        @"IlLoc/inEGmoaYlpF70xhkiJlrKnA0c6HPOHD4vu9IR2MWOyf4l21aSyPDcpa9BbZrPTtBmREm87wFNlBoPlrVf+gIGCSaEZl4qRTlHuwzyhzwfV"
        @"kIePluhckRcG6PCtRcksSW43PRdJox8JaZjle1lrb5SKoZdJi6SLSL16QGuJFOlmTpzItBnJMs3WVsEHdxrW6zVFrnDO9iOAeG7wUsrQNE2aSfSt"
        @"XpQJ4ilFqjakzhEubQOEzIky5+335mxPYTgsiL6js5HFskFlA+jTmegt2HmeUy9OMaVgtexoOvjcZy+DnJHVJ6yXDylUimFvFh3VYIsHb91Lcl4V"
        @"ieYaZXkFhOHt73+L73/r134tqAGf/8KXfu3iaO//WC+7ttLDsY+0bbt+RWWBrMj6A+7H2QJsSggRzqeM52QREc85IUH80xNHCSnVNUZAzT0aL9Q5"
        @"mVYSMELtWR+P8qzM57NVm+eDX7f6wleLnS9+3a2XzD64QyXXEOZcfW4PHz9Mscw2LcnuP1qyfwF0UVGvPD7KRHDBIGPg8cmSajRlMDBsbcPhQ1gr"
        @"wdJHqiCoelhn3KTD9k782Pc/XdehdUh7ZBJUYmMjjaQBYQyOqATBe4JMttIRkoGCUw9nbc2FwYAoBdJvQjnSxsSH8ERIFNLaL26AI/1OJyX1eHTv"
        @"1w1CoqUiOI/ul4ii//prUusQSdsMEQMi9D116IeKBITQqZfNBHVnWR4eEp5dYWREySSICtJj0Ag6mromhDrl++GQeC7t7XD//Vsc3T/l2YOccakZ"
        @"ZQLsimFhGJaa3d1tJtMhjTtK7EYJ1kWEJhmsQu+W22hZz5HcEe8cvvVpNrAZiJI2BZuXP/QU34Tgdkid9VWFRxrB1tYWb/7wAfPlgqqc0LUOLUUv"
        @"8klpy9I80RJsKohN+S/l5kB48u8vyyG37hxxtIA/+cVdmmbO7t4Wd+8/ApmjdYFbzxnkeUo7HlSE4FK2paw4PF4hDHzm85dh/YD65C6jPKc5W3I2"
        @"XyHVlNkSZPUJxvvPEPUu1eDjiN0bvPTCn6ITgt/61jfJTOSHr//gFz3VL37+cz8tQmAedKQozHjRzOZpJWx+vANAio5zi0r/kCVP/Ef1xf1P9kGg"
        @"6lxeqKIjoAmxyL3UVyNhFvBHmjZps2088l28KoK/MylG4/X68Z6L+s6NF37+79x86+tfDY++i5vfJ84e8MJnrzLZ/ZDVWY1OZjnaFRyenDIcTzhb"
        @"HqHUAOs8URpAsGhrlrVle3vMcrHi8OGKk6ZjXJbUgIquf2GSE8yGxM2zwSNJmgC7ofOI5JbTQuNEhyfhvjcVUBDgVFpjlVEwkskDfNZ5mugYbvr+"
        @"nrrbg3b7tNqNSCgZhhJ0YoMGSw+qkRLbf16uZDoA+sohioiQAhWSo9DxxNuvZSJcJteoT1ZRk+KunBRMsKwePcIv5kjXkavEPLB4FC0irAjWEd0K"
        @"nUkyGchEYHtc8vVff4VSw+5kxFBHdGwpq4LpZMB0a8D2bslkq+JgtUPnmjQ49TLBOVyPqgpP2ihI1YB3yeq7XnUooc/9+eelv5CgJMFGOh9wvcCn"
        @"NOL8QA3RM54MATg7O+HSha3zX4uxH8oikf08IG0FkglbiJhIQj1Y1AWb8v1ChpIFr77xXbIc9i5Mic5TFkNOZx9iskT0kVIgcfjYMBxMaJZLfJRY"
        @"X/Ho8Yqtq3D9YyPs49uUwrN+dIpiQOgKfHbA/rWfQE0/yae/9Jcpp6O/s1zoO5H8FamuHroQ+NLP/Hmcj7lU1VtBFDOrJI6UDG1bm2elSroJmwRV"
        @"/823AMITxCbiOxBl6F/++BQnLJzLDUV8YvIVUSTBTBQEIccROXnSPqRTPypNORqPAWzXHe1Md55vrTq0Zus//OLnv8L44Aa2g5PFKfnlbS4+qzhb"
        @"J639Rlv/6OgUYSImS1HUKX8tga+DNJwtl4yHBZPpkMkWPAywcLCKgk6kPt0R8SIJe3xMuXi+F1VYH3HBp4du8woLeX57Q5ojRBnpQvLP5z4wUgbV"
        @"W5SWTYtQ8g/RkkGLxFHciIN0/+8IMUmCw8bJJUIv+kgPsJbpbFeh3xj0BCETRcqkjYkyoJVI03oSszCPkSIEyggjIci9YyqgmZ8xe3zIejEnVzJJ"
        @"a4NFuAbR1cRmibAdOjpyI5hWBWfHx7x/8yZ72wbhE3lIK8fFi9vs743Y3h3gqWnDkunuhM61yV0n04vnuySoSgnvPZzDp6y96JM7z2idPCU93txa"
        @"S+ptQYq0+7ad6yuD+JFb3DlHMSgZDuHk5JQQXa/4e3KYbKo5Ywxt2/6huUx8ojAkeRSU0pwcz7l9Hy5fLwDHzu6I1bImBE3wSZ+QG4PtaopColWg"
        @"a2uEKJgvBYsWnv80ZANL287wrSU2kmaVsb31GfYufRk5+jzi0k/hx5d+4b2jwd+v9cW/2uq9ry3t8BtdnHzDhsnLqzZ/ZV5zp3Fx3gWHzjXKKPI8"
        @"P4o+zSt+7DWgk5A+JO5cMquJGCKJLCr6oaCKEhVJCTMxjQDlxoMs2iPU4hUhl0dSrkBYvHKsfM2K5q1okpbxbLF82Ut91Jn8ra4ov4WsiGqIV/8/"
        @"9v482tLrPO8Df3v6hjPesW7NE6pQKAzERBIkIQ4iLYmkZFtjS7JjSZ22pXbLluJ4WEmWM9lKey0ry+7Y3cuJY8WR7LbF2IrktmxqiEiJIiFSBEgA"
        @"xFxVQM3Dnc/4TXvoP/Z3bxUky06aWoGV9sU666Iu7r2oc8737f3u932e3xNllg++511YDbMm5gsopRiNLbP5LgvDlNDUpKgWIx6QKmFSlhTlnOFC"
        @"l7WjB/HAVlVS2NBOACJAMYioxHOEfZabUILa+jgJCIJ9ipeS0Tq8R5TxHpSk8jEE1TjoSINSUAHTWYHQ5h7RT/uytA0nEWv4/Ytvrx/Q3BPKqkW8"
        @"EEOr/IvWYL8fcRVJPrJdBGLPQksVF4PgUQSMECRSkCDQ3pNJRScxBOe5ff0a4+0tjADlXPwe55CVhbImFe3PCMmw1+X5574EFpaHfaRyaBNYWOwy"
        @"XMrpDhNU6iGxFHZGf9iJC2RdI1WMShPI2InfbwLGxuP+6M0L8qxLlnVIkiRKtoPYb97FyYmKn1WM/PF7fg4BzjVkWcLCEmxuxoy/vdd372NvfLi3"
        @"AIQ2xtMLdzfCXkaUvVRRcHPhjbfQBk6cOo1Ujm4n5daddYIwEe7iYwVBaOh3NXWxE9Hs0rC+WWI68Pj7TuLlhKap2NmeUVUJSXqM3dkS6sD7kUtP"
        @"cOz00z+7VUGyOPiUGiQPzd08rUXAKUNRqyrNl6u008MFi85EFOg1NbLy5C4np4vy6utbAPakhUG0ndP2cW/XH+TvUhvdpd3sfaGJkAEsoi33ApB0"
        @"cwpbDkJbZklJjKyW8FtffvbpjY0tks6AYX+J+WSHJ959lsEKzGqoncCphHkF49GMXqdPqApS3fL98QSlcR7GW1us9HscWBmyPFDsEpgKQYGiBGpi"
        @"UGMTLDZAHUIcA4oY8GBDrA6a9liwd5N6H8/koS23vW0dfTiMEmQyJu9OrcMqjW07y2KPOOwjq3+PrxCkbEdhbZaf520Lg9z7GXHX4yX25Mp739OS"
        @"fU0bP6ZCqxkI8RhjhGydg46e1nSVIgO2b99itrONCq4dP8a4MBkaQlOR6biYKALDLOPVF15guS/odxMWOhmpDqyuDDFaoBOBdTVJktA0zb5qbTwe"
        @"0zQNRVG1iK04TQoOfBuuKdpILmidf0IhpY4ddeKMO3i5b9bZm77EBeJuFeCCRxvo9TXjKTRWRCF/u6h64XE48AGtIi9QWN+mT8cEy70FxxNiYKaH"
        @"S29OWOzB8nDAoNfDe8vO9i7OBVJjMDpmMaSpIc8S5vN5/D1SsDUdk/Xh3P2HCXYGjaApU2ZVHzk4w9LZb6BgjVIdIiQHv18nC79U+5DujkfrItFV"
        @"0kkjq0FqGufHZVli0jSKmRCkJomjx/rrK/33F4C9cd+94pR73UXh93qIewCFRFKJ8hLhNQSDDwZPgncBI9U4uBpnq0GvkzyEKweimn18vH6HyWRG"
        @"ZjImNzZhvMNwYc7jj8f3sW5vXCvhxs2SRPRZHvQQzRTrCnQSibxSSsrxFFWVnD7Y4/ixPha4Xc8ZqZRRkHitmdmKUgUqBU5k1CEmwqgkmkOmTY1L"
        @"FF5rGnsXLhF8PNMGJ+gIjbQepwQo6IfAArADbFrHTEp8YggyBog4a8HXJDI216q6JghJbiTCtrHsjihWcg1GShIZVXlpamL1ICWyXVG8iA0rIaNS"
        @"UPr2uCAMau8fD8ZDhqQrIHcxgkwUBVs3bjAf7bK6uIBrKpwvUNrjXIWSAdvUHFxZ5pWvvYideQ4tDzGuIhMN3USQG0meGEKrF6BW5LqLrQQHlg+y"
        @"szPav5mbpqEpG1TQYAWhkQinqUpPMbconaF0SmUtVQ2IFJP2mJcW0O0kIJbyWmuapsER4mItZMxA1JY8N5QWbtwuSfMBNnis9gQd1YU+WKQzZCIn"
        @"zOZ0taa0Dit1u2AIUAKnBK9ducVoBk88dD9MZxxePcibl67gERhjMAKasiDvpOjEYJ1gOnVk2QK70wkTC0++r88gczCeom0GYo1jD3+canCe6fI5"
        @"zn/Td//gyfNPncVn0AiSoCsjsw0ZJNZaXLCgGhA1Witc7TB7kugIi8QbjxXNPvjz/3ch0L/ipv9f83HvdGCfPnJPxRBaGn3MrYs7V54m4+l0st5U"
        @"5Qdeev6rn06TjCOnH2Rj5Ej0gHpeg9/lgx98kKwDXjpK1yCTCI28ef0ma8sL5KkgNZrKNmhBmwwrGI1GDLuag6s91g6lbAXYbTwu6VK20A2vZbTy"
        @"VhU+yD3XP1bEKqByNtKBxF4qTLtLtB71PcefJeBxDLQmb0v53brBKUXtA65dGTMTfQLWWbSWqCSNZ93a7w1aYj5AezQRPuzHSu0RhvZK2hg3Fqsr"
        @"IQK69RzoVktw70MRMCFgnKOvJEMtSQPMNtaZb+/gqgolfSQShYa6mpOoQFdLQlXwwpe+yKGVlG6iyTR0Ek0nT0iM2k8W1spEpkITK5k86+2jtq21"
        @"+7P70Fpvm8ZhrW/ju+JOPy/rdtYfQSBKReNQU9v9PL99m3DLDdg/TrXZDd1OhgDGk6ZN6t37GRfTep0jOB/xV40D5/cDUp1vVY8qp64FL76yzspB"
        @"GPRyDiwNKWYls7klyzKsrZHCM+zHvMNOp8N8WtDpdGmkZFRVqA489b6T4EqKcYFWS6wdeQR6J+msnufsox8ZkS2/LNPBRSFjismeBueuqCf8jh4c"
        @"91Tkextw+Lpvfvg6dYRtCNXbfPV7DUCxF0YRIhdfa41OohlFJ+lz73v6G85+8KOf+Ltm+SRm9X4qs8ak0hSTGWfPHWdlJU6xauuRQpOlkp3tTYRu"
        @"SDqKxlZ0TBrPrVKB6bA5mlEXJSePHuH4sTUA7tQljRBR9uugaXzb+HP73vPQjgVr56kbiw2eIGO/oMHTBL//2SGwrbiocY5emmOinoWt2RgpVDzn"
        @"EiIunFj+2laIFPaEKCImFu2/lvvipLeLiFS7++/FXe9LiYlHAS1BS0kiJIboFjRtYq4SDuUsXSUYKEUXqHZ2KEY7uLogT1NyozFSgKuQ1rK20Gf7"
        @"xlVuX9vm8OoiuYE0kaRdQ6eXIrXEERN0hLrHROUc3W4XgLqy9zThWt6+iwYcZ8P+0aqua7a3t5nMphRFQdOCOfcWkPgaxIait+6e2bVEIeJh1VpW"
        @"BgukBnZ3R4TgYkXkwTiNElHFGWiQyuOdI9g4ZdF4QrAxxsN3uXJ1iztjeOChs2Q9TW9xwO2NHRoHKjFxRCocRoGWgo5JcfM5BM92NWNzDmfOwkOP"
        @"rEFR4lyXQi5gzr2XUZHQhC7DbOk/nW5MwAfmZVHxDn/I369fFH5PpZHGVjFGbDQaHev2BpUy6cbuaHZmVstRkxxk9fQH6B96lGThFBtbY2Q34WPf"
        @"fJTRCIwG4aMxRwhY39pksNBHBEsv13RMTBZOuz0sgps3b7I87HHs8CLHjxqmwHY5Q5iMxgrKGtACIVVUBhJisEer56+aGus8XqpWBdiyBIPAtt9r"
        @"RYi7vIsQiETGBXDsAl6qVgYVzUDOOZIkQSeK2rvYiZaizZfb8xvQcuvu3vy/F6B1X8nWJs9IEdDSo4VDC4cKNtZfMjZqEylIEfSQLCuQxZxia4Nq"
        @"MiLVcYqQaU0qJMbV9KTgjRe/yok1TTeRJDrEgM9uik51PFcHSxBhv0EK0dKdJAlZljEajZBCx4XBttl8Ym/WHxe7pnHMy5qyrijLktlsxnw+b9V1"
        @"al/gsveaOOf2Fz+l1D5dGduwNBjQ68BoNKLxNcYoVIiSY6l0NHULh0na9B4XDVeqzYBwQVBVkue/eoezJ2D14BK9QYfG1axvbJNmPUJw9DopItTU"
        @"1YylYS9WUe1CPJpNmdTw/g9m0KvxviQISeVh+8oN8sWjJL1DOCtHvSx/TiLI04w/8AvAvX2Au5YKv/9wdU2v16WqarRJr42ns7F1oNL8s/nw0Kce"
        @"ff+3f/SxD30/2dkPIoenELJHuXWbx544xIFVyADlM6rKYtKEnd053W6XY4cXUXZMLi25ChglyfOc2WxGMR9x6tgK588dJc/gduOohcbJhKDBhagK"
        @"aALtDbvnsY5gjjq4/RGkbb3dNnhsiJqBJsRqwLaaAqNjyNqcaA9GJvgQTUiRqqxQaYI0SawqmqYthdtmo3y7nHNfNOTD/vEsFs13HxLRJsLEmY0i"
        @"ZhnuzXAUAYUnE5B5xxDBijKkzjO5eZPxxq0INcWDrciV4ODCgNtXLnHr0lucXFsiDVUMCs01eceAFjQhIs5QktrFagklqWyDDZ7ecMjW7i5C6zhe"
        @"DfHhIC6ifm/sGj0XvV4PY6L4qqoqXN3EDIAQIluhff7C3w39jA1SgRYSbxs6acKg16UsYTqbYUzsnUhip9WrgJc10ni8imNgLaO02iQKj+DSWzfY"
        @"3oV3PfYQAcvigQXubN6hsg6lDCF4EgMaR24Ug07GbLQbzVJpxnQaWFyEx997DsQOIrc0zJmXWwgdSBZWOf3QEz9tkWOAROuBszW/D1X8O10B3NOr"
        @"Fv6euYBvz1aKqqooy3LQ7fbSbmdAUVqStFttjoqrm7PkpRkHfpDuKZYOP4QQXUJTc+jkAu95CnwNKQLnYgJPY2F3e4cTh1fIdY2hbrMBC7opLHQy"
        @"tjdus7BgOH5ymaPHUybAjfmYmZToVNI0YH1ASB0ZAaGNNBetV9659qKNZN8gokDHtje+DwJHvBhdY0mlxpjoIRhVJc6oyLdrdTmzqqZyHpVm6DSJ"
        @"aCobUEr+rsrp3vPuXhl971gr7vrtwiJEq8kI7TQgJsWovT5AO+5LnacvBItKswAUG3cotjZIhCc1CttUdI1kedDh1eefIxeQCEeeCLodTZbqGIaq"
        @"BdZHQZSUKk5I9km88Qbu9/sURRER2y192TuwzV3Nv7VRUap1Qp5393UA1lrKsryr03+bei/aqGVoE81byzUiIJVncdgFDzu724hEx+9R8SF1AOWR"
        @"iQIjsMQEHwmkeZ9ZUfPFL97kwXMd+r2c1dVFhBDcurNOmnVwriExHkJJogMHFnv4oqCpSxCK3cmIaQHv+/AiB86tEcQEm1jSrkSJKa6ZMi4qkt7y"
        @"T6ik9+m6cqlzdiz3mf9/gBcAf08j0N/zVdHqvZ2tMVrT6/XGZVlW02JO2ulgvUCnvY2ku1zNXfcXTp9578/WchkfuszGM2hGfOJbHuPAIiRqhjGC"
        @"urF08i7jrRHaVZw8uEg39XRST0eXdHXNUtcQ6gmT2W2OHBvwyEPHObwE14F1b3FCx1JSqXgzywj88CEeyh1QuxDtwm1KkEXg2rGRJ2rR3Z7NuLGk"
        @"JsEoiQA2y4pKxe6ylobaWeaVY1JUFLbe72hLFX/vXoNxr+UjhHybwWNftLInvvKunflHAZBoYaKK1kwkYjqyah2FmoCxno6HAZJVqTDzmmJ7k3Jn"
        @"hzxRcfHAs3nzOlu3rnLkQBcTGjIt6XZSTCJASoTSIFXr7BP7jWPvY+hEMa9ITIZAMZsWLXCD/cden8PZqASUQu2bdfaaf2VZRV4Aap/dJ1t/hJAR"
        @"5K5E66OQAZ0IhLQsDjOMga2dHaRWhESACSjtSFKFNKASgcwVXsWcRCUUtla8+eYNgoMnn3iQPBUcPrTGjRt3IovQSIR0JAZEKBlkmoUspZzs0k0y"
        @"rIPbOxXLR+Dj3/l+WJTMk4BPJFlX0pEzMqYMhkOmtVgvKl2hsqoJBV5Ub8N5/4FbAPa6/+HfkC5c1zVVVZEkCYnJol1TSirrBmUVqqw7HEuVPZN3"
        @"F0mUJjEC10w4+PAxTj8AQdWR224diws9EimYb29x4tAqgy508oaVgaSvLamqGXQ1m3cuc+hgn/MPHeXcu9aYAzu+YhY8Xguk0dS2iT2AVhmIiMeB"
        @"vTI1nv/lfqPThXYyIOT+QuAJJFqStTFLO0ChYuNKtXp8r4iAzllJbSMrEG2oGrcv/Ln37P+2HV/K31UdxDdu7yiwd+wS+3izfQgpkCpN4gOJdWSN"
        @"Z8mkJEC1ucXW9avkUmGEB1fxxqsvoX1gadih10nxriJLzP7fJ/5d2vn8noc+yP2/054QR+uE+bxspwAC7wQCiRQG0Y73okU67Pv90zRFqSjXdW2D"
        @"9m6Pwd8LuCbIgBAOFOhEIaSj34VcQ1XYqJMwIE2EiKRaYJRAJRKZRkiJIpAIw+7OjFdfrXnvUx0WFjSHDiwivefW1asMegNcU5NnKRpHJjz9DIKd"
        @"4aqSXqcfG8fAmSc6HHv/eayw+CxBdTK8twxyg7YVWIuReixVihcaaTRBuNX/wzQB/3XRYntnsj11V5JEF5NSaqyNSJt6Rib8wM12mM+3SdIAyoLf"
        @"4WPf+TgMoNe+wbbcYXkhZ2djk0wpjp88QDe3LHSgnzny3LO4nLK23GP9zlucOH+Qd73/AY6dgE0LMyWpkox5U6F0W2ZLhXeh1Yq3FtHfoSoLrbjJ"
        @"tQ1B1+7cjbME58m9JFMwAm7NxiRZh7qoYj9BgjCCoOKct6yqeAQxJk4gQrhbVdwzVt07YmipSLVBIfYnAXIvjnxfHBQTfqRQ0QTjW8uri8eCHEUa"
        @"oCcVK0IxuXWHrStXEcWcR8+fZ+vWTb721edYWsyRwpGlim43RxlJkqaUZd1qOgzORdNU8LFsDz429ZQyVFXD8vIqm5vbGB11ICHEaYBrkd3xvpZU"
        @"VRPtvy4CQPq9Ac4GJuMZWZbFaYptSLTBe0eSanyo0QakCkgVCMqjtGVtOePAEEQF3jpMDknmyIylawKJkKQmIUsUti4YdHsEG/jys5fQGXzww+9l"
        @"ZTnl+JEVXn7hWXpZSqoES8MFaBqEcywvdFkYaLY3rtLLOoQgmM/n5EP41h/4PljoMhUp6cIapQuYtItvNKGMu6Syzar3HpWkx5ogcUJt/IFeAPb9"
        @"Af+a7ynLMk3TdLB38ysdFWQRy2MRoRknoXhSFVs/UY/e4tChFKdniMRCajnxgQc49QRkPTh8AOaTmiyDhWGXm7evcPTIIv2hZNBXdHuS1aNdusNA"
        @"p6vIOxrTDRw6PeRj3/woi0O4Pq4plKIRjsrauAPfo4YUSrXWqDiCdCFWBC5E/pvzd3fsGAgj8cHSURrt4s/tWItDILSKMdRCELSGdi7unKMJAYv8"
        @"Pbv+9/YB/D2k3LctSO0OeW/FsD8laEeHwfnIERAixoADPSnIapjfvk29s82V117m8muvkAjopJo0UySpYmFp4W0VyB5NBxdaRaTcB2LEc7yiLGs6"
        @"eZemtlRV00p5Wxwaan8qYBvfOv5Cq9cnsvukxDuHa+zd5yqi7gDpQAWkBp2KNsTUkOWChaFkeRi5G3Y2IesIVGrJU0eWBIyOQI5ObsgSRVNWbG3t"
        @"8OY1+CPf/iRJGjh8eInpaAuagm4WR6OuLujnHbppQi9PaJoRwXuyLGM2L6jxPPLUE9z/7g8zrxborjxC7dfQnTVkPiDvdJmON2DnMh01+jEpa8bz"
        @"WWqtx8js6wZ6vOMVgOQeBeG9F0rbPOv1h9Xm1taw1+uldV0jfIhEncysJgqkq8jC+Idf+K2fJkxfYDR/g3Shga5j5qdwcIVP/MB301+CLIE0hel4"
        @"m8FiRmXHeD/mkcfOQEexfGKN/mpKZ9mwuDrA5IKNyU2OnFnh8ceO8aEPH2UKbNmKkCnQsWvftN19JwJeCoSS7QLQxKZXixB3IerYnY84qRCiocg3"
        @"ll5r3pEyio+mrkFoQ7MXQNo60lwI1MFT+3jECFLuxzffuxb4Pc9Cu0Ddm978O48C9wJMhbg7KdDEEakKIvYICKTes6AThoBb3+LWq6/z4uc/z/rl"
        @"y6z0M7qpppsnKCPRaXTpOVqthN87wwus9W2/Ih4JlDIQBMW8pNPp4T2MRhOk1DS12//Z+HOqzUGI2oCmcS2bL5AkWYvzqlvmQbz5pfQI6VE6oA0k"
        @"uSLpatK+IulJeisphw8rugqq6ZjuwJB0AtpYsjSQ5Yp+t4P2nmGvz2Qy4X/59du8+wMZpx86xbFTh+n1Um7feJNuJkhkQ8cEusaQaUW/02V5OGBr"
        @"Y4RJoWoqZnVNvrzEJ7/nB2HpSaR5HMWTZPm7Ed0z+M4KNpUk2Yxi41lefvVX/7Jj5wfyfnqxn3XTZt6842NA1Vs88PuoBNhL1Qh3T2wepJRj57zr"
        @"dPLo5nM1VTXvSledSsP86Usv//JPbr/6Twn1SwyWGxrTEDo9zOIpCg6x+sDTiBubzDe3SU3DeAQry4rl5S5lvcnCu85hpEQNMoR2dBc6qGEPkRmS"
        @"riId9OgO+6gyMBpPuXhtRq/tnMfmmmqJQCF2l4jBoQFQUt1j4Nl7jq0lMoAL0W2Wmoy5a5goSekCq1KRG0lhY5hHaIOYpY8iGhe7WK0Eac++Kv4V"
        @"C6zY39F9m5EniFhjIeJnFRGad19/2fIORDQLBWdRQuLwOCEQRuNDg3Wend1tNm9eIwslp48uM+jA6nKXLBUI4fcdjj4IjDIoYuiJFDEGrXZuf/GK"
        @"u7ij2+2zublFVTYsLixRljVSqv3qZ28ylCQpjW3wzqOEJuBJWkaDlAJjNIG21JcWlQiUiaIknUqSTEECIgnIrsKVc6ZbFXkPVh5cpmGCkQGTJMg0"
        @"RUhJN++iMXzmmYtsFvD9P/LtoBwLpw5x58JrrN+8QbeFu6RpipYJ3jsOrS4zGm9y69aYhQXJeOrZrmoe+cYP8d4/+SehSVDpCsF20KaHNgnOlkg/"
        @"pW7mNE3AqJSf+p9+aTyauWu5Sq6pIN42Qv8DuQCIvUBRsbdztbtj2zyz3pNog2z17W07Le2khlxVZzvN7Z//wT/yiK62PottLqEHGvoLmIUT1MlJ"
        @"TPfdKA5z+Nj9ZFVNNd8kuILgKw4eGpJngUQ68iceoRaOzCiyxT62b8iXemSDHuzsQN6hIxTG52xdv86dMaQJpEJFJaEA5100Ygj2FwApJVK1GO/g"
        @"W6PPHhYttI6/6Pm3QrPhPNZ7ut4z7OZxVOQjimyP9hOEwLb2oCQSKe6W8nvyX+66Eu/+OSpphAyIOAtrO+T3BpzEr9HqMRSx9xJLaNkSb2MwqQRm"
        @"s4qdcc2RRcGZE2vkxrK4mJFnBoRr24zxTBTjxATOWQIBbVS0TEsVR6fWI1U8CjTWcWd9g4OHDtE0Ft+CQCLhx1BUBSZJqKo6in9kdFKmJqFpagge"
        @"YzRIjxAeqQI6Vcg0kOYanUhELqAr8GlAdxXeWmbbE1QGqw+vIrvtkaGb4YzGEdDDg1x66Q2+8GrB9/zw0ywfP8jy0RWYT3j9+a/QT1JcXZOadjTp"
        @"HYvDPp1OxosvvkynC0IbtiY1YZDx3T/6w3TOnIEqIGQXmazibIrsLuFcSRCbpLmlmI1Aaf78f/ZfP/bf/Z3/cV00DRJxywvpghB/gBcAxF376955"
        @"7W2dgRifJIGmrlLv6lN5qjeaev6ktlt/89Wv/M/Hd978ZTQXSXs1ur8I3SOY4aPU8gx5/ghUPVhYY+HAAnp8lXpyjfEudHM4dmyFrXJE9/gh0lPH"
        @"0VJCr4MZZshMxaDA6YzprXV6iwfIXXTSvXl5m1kFfSVIVYKQMbBCEm2noaXrqBZqqaS6C++QMW7ch6ilF8SxmDMJ63UMn0yCZ7HXxTcVwcVU4hh8"
        @"KXAi8gYJIboa75l375/z3/bnmFIc2u6EuIdrt5dBDHd1AxBpRKIN2Qi+NRBp2f69Q2Tyec/ycp9iXrGQBU6dWCbPQwR8pqCUIHgf/f1toIZWEu8d"
        @"NjRo04auQCzzQ2wO1nVNlnW4du0WK8vL+zP+cE+C77yYY0z8XmvbXD6lUe1o0FkbYagyUtqECagEdCIxucRkGpkr5FICfYXsJiitaXZnBG1ZPreA"
        @"PNBDqBiiEVJDurzG7ktv8au/dpPHPn6aJ7/5I5hBijiwwO2vPU85GdM1CaFqICis93S6GSsHlnjzwkWmsxn9wSIbOzNu7cDj3/ggT/7Qd4EvIIk9"
        @"HlSG1F3wKSrJUKahrKdIHDtb2zS14Od/7l98yNvkglf5SxY1fycXAPn13fzc1fz/Di3g3uhMSL0/QjJKVouDQeqa+gzOHrvw2pefHF/6ZezoqwwW"
        @"FNnwAFYs0ll+kmn9ML3eR6FZguwgNF04cZ61M8dQecyXvH1rynha0B0OuHz9TVjuw32n4NAadDNwc2w9pvQF890Rk8uXGPYaDh3p8NC7j1IAo9pT"
        @"uQYnJF5Fue8+BJToGXDBt0CRva/Ldjwoufe9M1KRyXgRT4GxjZCQeE6PRiK397vbmKe9Bp9r8wj2m38tNMR79zZBDHB3dOhtuwD4Fs8mkMG3WfLx"
        @"QXAYExct8EgRSISnA3Sd52ivz/lVg59A6iyDLCX4huBszExoRTkSCLblK6q7VtsQwn7Ixj5Rt7akSYaSsLMz2vf07z0Pa+3duC/RTmAaTwjsS4Hv"
        @"2oAjrk6qiFKTJvZZSCTkIIYGfWQIR4foMwdZOrVCumiYigoOLSBWu6i1HmHFYJnx4utvcviU5EPf/UcpOxJx8gB++yalm7G0NECqQK/XwRhDr5Ny"
        @"cG2ByfgON+7cYXnlAKNxYHsXeovwwY8/Cek6c/EWhEugrzF3l/DMCXUK+jz0P0bn0CfJFu+nk8P86q/xS//wPyGRxUfLxv/B9gKE36EFFtDCKVqP"
        @"OrELrbWmbGJI43y+M0yYfu/1N37zZ2+++ivMJ6/Q6dcUskuTHKZ/8v2QH2WweBzCDPQEuA1mG8QOMzGjUaAM7GzDjZtbdLI+ys5xdy7D2iqsHIDS"
        @"wrymns6ZbI3wM8u1i1e4cfNNjp9c4cEHjnL+gQV2gLFtqILHEcNDYvpqbATa/Zv0npdLRcVNkO1YK8SxlJKBvlEkCBpgXu3hqUVkCaoQNQQugjH3"
        @"8gld+/vvvdH3hD9RkeT3AzODiF33SDgWb+8ii3jz7xGDlIgjw8QolIgBHCoEMgGdeP8gJmNOLC3TzGMvpJelpG0EWRRMxRtOItr5fPTvB/92WIqS"
        @"7M/xg4+tFK01o9Fkv8EXn19rEIohd2hpkJi7eYDOIXWk9SDCfpNzTwUoWjs0JkAm42OpBwdW4MgBOkcWcEPDLAToLcDCKuLICdJen+deeIEil3zL"
        @"j/5pfH9AdvIENHNu3XyLTq4xCaR5gskMg2HOwmKXXk9z8cIbZB1JaT3rm7uUAc69p8fqu1eoxq9i5A1s+TUonsXIl7D+K4jsDjAGBmAOYdYeZuXQ"
        @"/awu9RndeZXf+OX/4aN9s/WTSsweEliEqBHYVk0rWmmW2k+d9tLeffw+ioc0X+cBwN/DwQu+QUtwLS7ZukATLDrvprOqHmDrjaEKaVps/QQbv8H8"
        @"6qfpDjYQC4uY5cfIjz0EcgmowH+Npp6jbE3TNJgsRZqExfNH2P3nUYiSpXDh1ZrDZ3ZYOREYX36JxaP3QSmpdxvUSMJGjdgoaUaaugrcunGdIyLl"
        @"cCfjPQ+u4edjLl31HG08Q5OBn5AoSaih055HY5qwoWkKernAeUuJQyuBCQEFmMwhjGXgBfMypgdP5pZjS4uMZpvUJmASQ6gcShhksDhvaQJkSdpK"
        @"Z11sZkqJb+zbxqxpklDV0VTlFczKhoVujnW2ParspRC3ODfRyoZlzMFTCHIt95VnEkffgJ1OWD6xSjCwMZ5xIhkiqgkiGAgSJ6oYf01ME2qCwAWF"
        @"azw0sXnnceAsKlGx0pGBspxz8NAab721wYmTKUnmKas5KmikUmitIQSCjUlF3luqpiLLEjyWNE+QwUXOgfcIG3eV4DxOerR0BBmjtowXMUwxydGn"
        @"lpDVBoXoQXoEjvTg9lVmt65TTBo++O99Lzx4DkQCmWH7xc+z0AnYqUXmhtrLCIC1gQOrqzz3W18i1JDkA159czO+tB34pu9/DMwFwrxBNCk6E9jJ"
        @"HOW61D6H5DjIFTAHiCXrcTh5mLx3hbx8md0rv8RXfuWv//C7PvZnv1Fnx949q2afSEz2DHSuzQuL0r1BQA6lbq45PyeE8ow2chQ3DzlGJJUQKqYr"
        @"vXM9ABHPSk2MEw/eIZWMXmUpCEJi0jwtq6LKdJgvpuUHkvn1z73wuf+et776T+ll2yytdeiduR9z4CEQmmLzOrPRdaa7bxLK2xTz2+T5nMn4NTK/"
        @"DksdhrXjK8/cpmcMtvLcujHiwXcdpJiP2bp8k8Gxk3B7m+mtbeT2hGa7YGtjRu00o8py89ptzh46hm8c6eIiu6MtRmPXWkSJWX8tDmwPua0UJIkh"
        @"+JqqgTRTGBX5wocO9dBaUdQNZQNl43AYKiyrSYZ3NYX0oATGa6T3oHwsp4NAah3JuS3iS4jW+ntPL0BpE23KbZOwtg6TGFopAkLI2LXfB2LuFWZi"
        @"X2IshYg7tWgHtSKmI3UWM65Np8iu5+yJFWwzj6AMrfCiBhlQjcA68NrEboSto2lHxF5GwIIQOBdbklLFht/Vq1usrByIZbyQ+/PMgCe4sC8HdsLF"
        @"BUTv4dQcOEeiVJv1F5l9QgdEAiKVOBUIRmKrCi1zSFLQAqkEu01g5eARSCTV1pSrr1znkcc/Qv7wB6mtQK8sM7n8NfRsnaSYEIoCrWRUaFrL2tFT"
        @"rF++wYtfuUaWGzZGllHhsBo++u1HeegPHaKpr5AKSz2+gZ/exJgpbnwdVW/jy03K8W3qySaJK2IvyjWw0KW/ktG3t7h18w1++Ef/g+X/4e//9H/c"
        @"z/TNclp+IMv6LwfMWJnkmJN+u/GWNE+7KpFWSFnh2MGi+93h0nR30tVGz9+xBUAEQa7SVYWcIyxBeBofIDEUyg0aJQdF7Y5JV22siOnH8+n1z7z4"
        @"2Z/g2uu/iMmmHHnkLPr4aSgquPUq7tbzTG6/ANPb9ExOt3eAPB0w27mNErcw4RZidJn+yjI3r9zh8ps13TBgulUxGW9x/Oghtm9fI9vdJD18nMnF"
        @"y7j1XYrdOaVzjAvLdCxwZcr29i5rhw6hjGbQ73H56jajyrLSW8FWcfSktYxEGhXhH0luKT1oDYtZSioc3Y5kcWWJ8WzGZN7gSZg3gUooSiwLUpEk"
        @"ktJFsGXaBlaI1pVIAKn2BL3tnRvhYbExGSILHyXbBSBGnjXOo5VsvfEh5hu2vYDwtj7s3mQhVhaRLyCRogX4esgXu8ylZXda8shDR/GhxgqBTg1e"
        @"xFl1sJGRiDII6fHtREepBFrr8374pm8nFcpw5fIGvV6HvJMgRBRTee9RWsSKRplWLRnP+croqPl30buvpWnlvwLZHqOUErHZKwQuSKSX6MbBaATW"
        @"kq4eQA47FLYgDRVbt7c5cPgx8vs+CMkp1OIKbDxLtfUKSTFG1zWpUuhEs1uXrK4dRZYdnvm1Z/GNo24kG5s1Jgd9AP7En/kYQt7Cze/g5+uEcpc0"
        @"0bitMWLa0OzMSCpHmO/ixzfwxVWK3deodl4ltbdAzZAdWFjqsHHzeX7we7+N/88//uxTqUhfKOfiNYe6JZJmuxFlZYU7XFs7LGbNcd/IUS/tz30R"
        @"tLGGbtLtuWDHX88o8etbAGKc09yHBksg7/eOlU09RqsY4ODsgZ7m9aWkeDKf3fjcb/6Lv8bNN3+NQ0dylh54CF8Kbr+xztbVHbZu7VLMKpTQVBX0"
        @"BodRx85BPsBMNpltv0lH1+AtBM3hlTM8+8XLMEnoZQOuXpuzNAws9TJuX7vMotX0OktsXbpBU8J4bqkbQ13nBJ+yubWNMgkH1w5SNRVrRxbZ2tpi"
        @"c2dGKjR5R+F8g5FJBHRKh0lBGOj3MhLRoKXnyPGjzIuK9a0JlQUhUwoLY+9weLLg6OYZRVNDgExofHvOjRVGnCjcBYXe3cERsWPviWO/iMKKm6iN"
        @"h2gyFcNC9tquYW9AuRf30AaiRC1+CxdBRB6hABsCaT9DDXpcvz3l4XetIUzABdCpxsmYmoOPKT1oiZICb2uCc2idxPfaN3gfQGi8Dzg8SZKysb6J"
        @"9561gwcoyyoGgXqP1oLKNkilcMERQtTwa6NiFoPzOGdjhSFom4Cxt6BkNELJ0I5jvSeUU5QMlDsjRqNdlo8cI186RDXR9Pr3kx56GrJjBCcRasb0"
        @"zhdQzW20dYgGZNLBNZ60N8T0Vnjxs8+xeX2bxeEhbq3vMvMw1/AdP3iWteOSanedNAR8WeNKj53AeBQQfojwi2xuWbzrMpp4ylowLTy704qNjREb"
        @"N7eZjy2ShKXBEDuv+Z7v+j/xl/7z//uTP/Xf/9QFk5q0rItlR7DGmFtS6O1hb2Egg7ocak8iU+0q2xVSbDvh3NezAHxdPYAgHUE7sqyTzspQjSf1"
        @"NZlonK1JSKtFpdfl7OZ/8/qLv/hj11/7J4zGX+bEA2eYVg1vfm2LwndYXnqM/soq1TyQKMVgwRDEmHm9Tf/WDjLTjG5N6ak1qutbaApUH/qHc57+"
        @"8BE+849ukCQdEgVf/twO7/uGRWQwvPD553niiffTGx7k1asX8SKjmkeBknOOtNPnyo1bSJWxsrZC0pvyxPtO8sXPXGYaZhgPy50uqhYkKIyBJPdI"
        @"LNqUNBbW1pYYrixy4846NoBqk4YSrbG+xgXYdY6BjLu4cCGWraIl3agoCmpcIJiAVILGu5hFIOLUwEflLWEv47BdeL0U1M7jTNh/E/ehG5I2hjx+"
        @"rxChlRe0YSRtvSFETCSq5zOWlobIBqbjKf3VHGcLvLctfDAQlCSogG59+E1ro46hyvF1tS6mIe11+rNUMRwO2djYvhv3LWQUQrWAH+cbAs2+tNlb"
        @"h9CmxajqfYoSAbQH0QR8TbT3ioBuF8IRI5ZyyLBMr29T9g6SPfgY2eAspGfwRYpMQHSv0Oy+jEimCO+BhKbxqFKh9QJ67QS3vvgVbly5yOGDa1x7"
        @"awcvNZuh4cEn4eFvOITbvEDadKEYIEUfERSmdwAcTOUyTi2SHTvE0vHzyDsjkk4foSR1XeJ8gXc1ZTVla1TiZzWDwYCy3uHVF36Oz3zm7/3kh7/5"
        @"+7/QVwd+PJOdKgSd7kxGB2ZF+XKWdaiqZqDzXmp6uqrqovqdLIn/nZuA4FVgWs2qLB+ks9mscs6RCjcw1ehsV1ZPfvGzn/qxt776qyg1R2WLXLit"
        @"WDn6MOfPneddD38TRQNa51/QDP7udDr/RN6FICbf9/yLv8p8dgsz2wV1kt31GlnNGGSg3Bzr3+SpTz7BxRc3efOFO6wNDLPdhmef2+G++7qEBr7y"
        @"hRc5deo8urvKeGtMWTiscqBiJJZUhotvXkUaSX9RM1gMfPw7H+Mz/+J5RgUMs5pOFt1zaaowaeT4yQSWjnc5de4M1165xWRWYQzUjcDWNSrJMUpR"
        @"e8/Ew8y5fetuaLd3G6IkNu6V4W5clYu0Yyll3M1Da0uO9JA2vTgq9PZm74EIC5Uty1C2/w/dahj2pgdyL5Y7xGUkhqFAMy9ZEILFDLY3d1g4MkQ2"
        @"xdugL1LJeAf60A5BNCE0++TegMS5GkKDFzKGi1pLt9vlrbe2mc1mbR9CE0TT5g9Ge7Py7YJkPTQxJ0GGuyYpIQSu7Vt4D67xeKVQ0uFri9KGvGMI"
        @"0wIRcuQ2XH9lhzMHcjh0Ht8sI9I+iF18U+OFQ6cdCF1q6xG5omo06dET8PoN3vrqq6wMOsxHY3bGBXdqWDwF3/79T8PoOspZ7NQyKyQ2W4XOCtKt"
        @"kK0coXfwPEEtI1ZOQyF56uOP/bTR+WeECFnj5h9H1A+bBLyvz/oCFnI1+q0vPzNMdy4xq2fc2rjFP/qHP/X00eNPPfvEuz/yboscrfQHVdHUaAF6"
        @"kI3LcopuXabinZwCeCRSpfhQM52vP5znyUvSiSr11ZM9tf4//pOf/hvHN976DVxTkK0+zOKR83zrN3/Xz44Kfa0pwORHf6EUIEPykrTJWHfWPjWh"
        @"qSzVj5x4/P/8MG76vZ1q98fefO5XKd0XqLefR+sbFLPbJP0E9Bbf/P3v4v919cvsWotOMl65UmJ6noUsZ2tjzLi+ycnjZ9na+CpJogmkzIoKlUhQ"
        @"mkxKrl65zkk54MyJA9ze3OajnzzOc792FScb0lzRNxojLVkWjSj5csbR82eYe8eVzZtYok/FWof3UZabaMW8aZgDY+s4IA2KGhfi1S7atGApZdz1"
        @"g9pPD4oavoAPsXEWhMOF2HNxRGstgcjm2wsi3aMzv23H36sAWqagICoAW/y4J9BJYNxAHjwHB7C9sc396n6EihODvQvM7YWkOofQKpqEhIiBKSHs"
        @"Z+413qF1ZCHWjSPvdkDC5sY2a2tr+9HjhBbz5h0qiHbMGRAyBqEiIw1pb8rsW7ck3iEbcNLGWCwtqEcleapgCrOLm1y9Zll6/znoPQS1RiQa4SNp"
        @"uLY5jhW6ndMUdSCoGaonSNMuFHMuPvss/coCHV69ukmTJYSk5g9/5wmGKwK3KainGukllcyhfxa9cD+Lxx+CwTHqIueBxz74F5vQ+bQN+poWB8ZY"
        @"P9AmpEJ3Pl025Qd8GVKZmIvp0Fy4Xc4/cebdfwRv7TEp/DDRIX3mmc//2M7ObV54/tef/YZv+Pj3jSaTZzqDwZnt8QjdTS46Ewg6vobS/m8H+v6+"
        @"LQAyCIQ3eNuQZeaCojkTGnvsNz/7y5+e3nmVtT4MB0egs8iTj3/LhbEb/N1CHfjbIu1WIXdUAoQx1I0jFUlau1BVzpH2Fqvdalrl6fDHK5b/UpM/"
        @"UGZHHEo4Nq9vkWcdXFWg7A1WHz7Dhz/Z4xf/8ZR+5rEann+94PwJg0oHvPz6TYTucvzc/Vx87RJN3ZAnKaWfx0m/MPTyjFvXbtDtBM6cPsDO1pTj"
        @"3/sYX/vSS/iiJB/kqNDQ72vyXp+lQ2t0Tq/xpV/9PKVzJJmgmsTdSSXR8benh2iAIjiQGRIXMWJKICwozdvdfSh8q+tXIbLnhVJ7uSCxieZjMCat"
        @"Yemua5D9NBKJQIV41pd7EwL2sgXaMeA+a0wxLx2JtSx2Mm6OSoTfS/SNDi8RZEyMItJ1CaZFmd0N/VBKRe9/xL62wR2ONDMkCezs7HD06NG3pfNI"
        @"qQhNaK3NbXS69QjdZjnuScpiDNXbHJA0Ei89ptMl2JJq3bO9M+Ol5zfoH32A4x/+njhSNhnOV+iWVqXMKlniKXYnZJ3jVGGT1Ddgurz5T38JX+6y"
        @"Ouzz/Et3EAnsljXv/dgKDz15lMmdS/T7J3HTilL3yZbPMXjoj8DwDO964MlPT2t9zSeLP2HNgWtCpqjIQkytLcfBuZgJafJPoSS1lEzL8lgqhj+j"
        @"EQilEcHjQzV46PEPr3e75mJdlB94/itv/Ox73//hh2fz+cvGmLZnEpkJhNAmZL1DC4AIEjtz6aC7eKa2uy/bpjz2pd/8tU9jG86e+xCPPPjIjwWV"
        @"XrNCX2vEiQtey7EU4Nwca4pvDKh1XPdljUGGppI4jK5pmiLtGr/uQjOwOhkfe/C933H7jed+XtqGTjMjFC9hywskWUXYuMg3fvxRXnnlC7z2tZpe"
        @"BvUMXr4+5vjBJXRieO65C3zgG86zcuww1y5uofB4G8g6CcLHMJN+v8+dm7c4sCg5e+YE2xsTvvGPvofXv/Y1pttTVvvQX1KYvE/nsYfYvXiR0c4c"
        @"qaFqQgw8kZLpvMYl0DOacVWDhJ3CcrLXlr8tUTdRKubxqZZv6+/eSM43BNugtcG1UtxI3m2VOUh849HAvGjoDjrYsiBNNcpH15/AoyB6DWjHiTKG"
        @"fsjWf9Dg0BKMhHq8y+HlIS+/VuIaTydLqUKBREQdv49cB+oGaxtManDFjMpVpGn6NhlywGNUjOROjCZLYXe3is9PhDbkU77NvhxFzm+3PisJtq7I"
        @"8g5lOaOTaTJjaIo5SI1wEIqSpoLNDcfnnl9n6aFDvO/P/YewsBTVYgJ8M2tTWBKMXsM1grx/ilBp0k6OECXVb/0abvcqnV7GnWt3qAPIHI7eB9/0"
        @"xx6D+i18WVE7h+/cj1p6gsG5j3H+oU/+YCX7v2DlobFLIQg/CKJGhKaNRdNVEgRe6Cj2CqHlS9qBSGTpnaQJcSojgsKHzlik+X81azxo/6mHnvrA"
        @"jwMEEzUWoZEooVB7kJTAO9kD8KRpltq6ftnWDF577eKnVZjx7ice+2jwybWQrVWFT9cD+pjAp5IGERpk2EM8++Ee6TUQ5aUSN1DBHotHXjlyTtDp"
        @"rv7C0TPv+ej11z//GV1tsvXWbYqdCwyzBq0KFg9V/PF//yP89b/260w3oNtJ2NyucXaHk6s9fGj44rOv8u4nHmFhuc/GnXWGgy4Ei5KWVEt63Q7a"
        @"QDHbpi4ylo6vgFY8cugh3rrwOiYUlF5y8L1PQGl569JrLHYV1VRSGIetArbdMUNwKCfJlGBEoPEROZ4qjfVljMP+HRwA3/bSAuEu/z3cBWEGKdrU"
        @"4XusvzGbNKbaiLtIcbEvVvQxSqqV8wriQiVVTCUkBISKYrpQzOipAamC2XhKZ1VTNR4RVBs1LmKsund435KIJHt0j3ZHj/N9KdsSXymk8gwGGdNp"
        @"SVnNo5cgiP0KoPZNm5gcMySsCKStqlG2sBZX1WgE1azCJAqjE0IjUElOU8Mrr13hpdfmLJ47zbf++J+DwQKYBkxJVd5B72Wthy6kx1FmGe+PR3iK"
        @"uoq99Cyj29dYTjSzUcOdLdCLoBV88/feD2YHihpnOzT9kxTmPGrxcc4+8UefLtXKM44UJyxBNnhhxwg3iCBXxtEJptoRKS3IFVRgHELcROX+FSDb"
        @"Zbsdd2BBxBDbeE2oWPbj7+FvynduAQgiIE09do1HCFM98cSHhtbNxugupaiPCVNfc1YiAteMkwPpVSqh8l6grPmsk+3cWjhqFQmOknQsg3pZW0iC"
        @"pHYabxUqWf3s0fve8xdff+6f/mS28jDST5luvsIwcRQbIxbWDD/yI+f563/1VbZHNd08Y3enZF3MWVnoUVRzvvbiG7znyXeRZp7dnU1SA8NuJOCk"
        @"xjNcGZDlU6Z2l6VBH4ZdOukCZ+97Lzt3JqwtrMLqMluf/nUWexk7mzNGpaMRAqVVNOt5i20R1rlJEbbCEpg1ln6a4Yq4bO9Ze8KevJcoDJLsxare"
        @"i1uOppx41G/TGISM8VHeUvuAVjr+vI+oLCVAtZkJqtX0C7lHEYoe+wAYBXkKrvDkWtIzsH17k+Vjx5k1HhliwIsKkWJscXF0GRRKtceU4GN6URsi"
        @"rYQjCINS0Y+wsjTg+pWS8c4uB1aXsE3MjfA+TjO8FO0CGBcRJ6OcGRHwdYVShiRNUDrF1g0hGHSnw3gML7x2hecvz1k4d4xv/yt/FZZ70E2ACjv+"
        @"MrXfjGInOQRzGOgSWKaRp0llDvYtNtbfoJ8YtOqwfmeH5WV4bQYf+Z6jLD58kLC7wXys0J3TqCMfxnQf4sk/9L0/OPFJlaiagN2nSgdkDJkVtGNX"
        @"GcVX3u9jzY2TGCffvvwLu+e3IqDZIz0SUnwQKchB3PH9GOErEeIiEIT/uqAiX58SUHjqpsEH6GT9B8qquV55j1OSMtQHvBRKCDEXeKcC8+gv3dv5"
        @"DCKoVqvisW0QB+2cOnoJNMZkg7Kq0zTvPozwP/dn/uz/7b8Yrh0gURn9/grN3FIVE4TdZvXQCoO+5OWXx/jaYpRhtGNZXuijhGE0mtH4Cffff5xq"
        @"tkVmPGkO/WFCp2voLAj6qyliIKAn0Qs5YXEIS6sM7nsUTp3BXXiBqxdexm0VhBmMJhCcJjhFY6EKPjYFhSIozdh56hDIvaTfzanreVTitc/Tt2Ox"
        @"sMcZ2Gcstrs6rTX5d2YGtL2Dxnu0hESr/YDQRAoSpSIaPGqIUDJ66oP0CBUIe8TcNtvQO+gu5GxXM+ai5Oy77mNW7LTnTEHwMYKcxkWPvlEEGXB1"
        @"jdIK0Y6jhHRtSa9aRXJEwF2/toMQFYcOrlI3JRKJ9Q1BybZqCq33X6JVVBKqEEgThSTg6hi+qU2GDYqN7SkvvPoWX3294bGPvZc/+p/9Z5AZWOwC"
        @"BbMbLxDK68AtaLZIhAOpqRuB0BlapAjmhOlFwvQGZrrLdHMbnGHbWs59yxInP/YQzLawlaeqOmQrj5E98O3c9/i3/eVkePjleR2ekwIn9t+rfUtW"
        @"JZAVbYCrEHe9HSqA9rFHE0EttCG7/q6pbr/5Gl0QoJbu3vyuijZtf1fk9XXMAr7OKYACk1OV5cDo5iLGYXSCTvWxelaNjJcbJjRIbwnC4ZXEtuo0"
        @"7e4SkYMA1R4L9kIdKx1jn4KbjJOOpKo2n8uNPvbEB775aVvtfuKFr/7mX5aDs0jbY37DocrL5MWYD37yMV597Rpf+GVYW0zQWnHp2hanDvVY7Cds"
        @"bk546ZWX+dB77me8c5vRfJfOQofhQkZIa9wQsrUBodul7vbRC4fR/cOgVkA6Km2ReWBnDq6GtGsovaaYNRTOYgVoLRE+NsESoShxTGiYijblligA"
        @"QomIGtuHq8ZEH7FHWw4t868V+NAGrobWfyBURJwXzpGlCapt1tF6ABQqJgQpgdKx8gh79tpWcutsm00SoJpNWe51ubwzAxHQKkZ8KwHBRVuxkHdj"
        @"zfdceyE4BAq1r/QNUe5MlPRmScpwALNpg1Ei+h2ExHsRVX/R+xInFnvJzXsBoHVDkmZYGWicpPCK9Z0RFy/f5qU34RN//L08/ad/FLIuZA7Kq0xu"
        @"voobb5KqmjTx6FxDvU4z84R+DyUS4DqEOaK7xmDtUXZvvIFbdAQ55ODZRe779iehXgelqGtP01+iyQY8cu7dpTBn/qvJyOGtXkWzAaC8RIW90FPf"
        @"bmZun5B91x2vAYn0ahCgcoIqCkPa40F7NIv3l4NQEwQbiBDfW6IYjGDaHsDXmQ34ddsJpT6WZB1qX1ZFMR04WzPdHa33TG9DNgHZjneCiE6mGNMd"
        @"WlOKhyD22XJ3rcS6LaUgyRTzavqkEIGiadY3dqrUZ4d/8uH3f1f28Dd839+VBx5n8eRTVGHI5tYO9e4lfvhHP8Gj74+JQCSWJBNsbkzpdfsYA5Nx"
        @"wa2r1zl0aJWT9x9BDhr0MNA/1CVZzdDLPczBg4SFw4T+aaw5BOkKFGM6K4uceeQh8gMppYJZ01A0Fmc0IjX4EFmCcc4fSKRBI5nhGTU1aEUIkczj"
        @"RMwjcEJiRUSO7WHAHETYRhscEqT43cSgNtSkaAKWvWyDuwm6QgYSo9AmBpmiopJRpBASEIkgSTTGSLIUqvmcfqeLLcDOol9fthZiFWLTUShFaG9Q"
        @"3YqL9o4Ve7z+vT8rJQgh4k6Hw4yqgqKYYxKFVJEtkIQ2w5DYp1MSFHdZCMakFFVNknXZmVZcurnBb3zlNs+/CX/iz38HT//onwJdgSlATJm89izT"
        @"t16iX8+Qk13EaALjKbPRNkLOSPtzGL3I/PIvwu5zkFhYXGXhzMPkpx5Cnr6P+77nO0B65qEC4eku9pmVBb3FFUSSPeODgkawkPWzvXN5vI6jG1Z7"
        @"0D4g/d3+VuxxyfY9By/8OAiqIGIatUPhhIYQw3UJUbcRd/sYFIpo2kWlzZNE8vUqAb5OKTDUdTHWigocw0F3IJtm3jVJ15dNZVQaL24ZbbZBtKPD"
        @"dkS17ycSsWcdRPvkkft2YttUA22SyybtE6RxSuWXJ5P5IDNJZRvL3/vpf/CBP/fnf3y4deN1Elky6EvQjofe+y5efO0isy1PriA1sL1TcOJon0xa"
        @"pttzFpdzDp1bIhkGREeSr/VJDvRRwyFy6Ri2e4o6nCHLT4K/DNUdEDWyhIMrJxntlEy2KqajhsaCkDEq2zYQVMBLjcXQuMAMh5KexSR20r0Ay54Y"
        @"KM789/oBe/ViCAGp1F5gwD5cJURUEFJL6mBpPHQztc/9UyFgaINC24ZRkAGhBTpT6NygM4k2JsJQfFyMSw/J4hI3dsYsnUjoDjNsZTFSx2OqoM1R"
        @"iJWMlBJnHVpKhFRIKUA0sXCVKUYnQIR7+ga2N2f0eoGF4QDX7C0sDh32ehbsH1mkiAVwcJ4k63D11jpv3t7k818pyA7AX/ir/xGH3v0k3njEgoHd"
        @"S4xf+SJmtEE2LzGuQTlLCJa5c9hOh86wB8U6xZu/TXnnKyT1bWS5A/0uLJ3B6yMsn38KloaUYYsQ5hhb46oGGXJ6g9P85N/95VMiWfkvtRXYqh4H"
        @"pVrFZWhTI0K7CAa83FvcNVZqnFDxyNdWSl46vBDRfi5UnBSg8ULj91iRsmn7NXulfjw6722V/3oo//8OSsDMGKytMJlhNpluaATKy0qGvR3rLrMG"
        @"/H4M+V65v8+ya40k4u4hODZMdDq23jGezdLEdKrUJKup9xu1DRjT/YUgRSkH9336+P0f5M7rY8r5BrjbDI4M+L/+hQ/yt/7z36TaiMCWGCA54cHT"
        @"K2ShZv3mVZbPOjqPn4I6UEhJPliB3goM7sdwlEw/AGGKnW9hJ9fI6gaGQ9id8dg3PIGvvsrO+DqbY0uqLEJLfCJQaIKTpCJOahtg5ixOpfvzbe9j"
        @"qs2eRTc6D+OFI7yLmDIiGFN62V4Ie53+GD4alKS2rk0rjguIDZYqgESSKIHQIroXewlimMJCiu9LghBMb46xssZVUNfQ06Al7O5MWDq2jJRVHBtK"
        @"G1O0UUgnoT2zGqXaBqO9y0rEo6TH6IDWkSPQ62qSBGbTXRJzmHJeYVS0KgsZWsf/vkgZQvTDuxC4eOkWb14veOUqPPnhFb73T/4wenUNUoXsKsYX"
        @"XmZ24xXMfIQJMb7cT8tICRKSVEl6vQHMJmy9/BXEdIOlvmR8ZYNRvs6qT8iOfJT87FMQPEV5Fa+OIXQBaSAUU4yyzCfrJAlUokmNMikwDq3yYf8a"
        @"Jr6ffg+V0S7LHgaxqrFjTwSc7lPeWtn3HmzmbmMwvod3I3f2EoLF247P7zgUVApF8B4hFQiJR7qgBE7chVvI0MY6/R4dS9HuVJK9Bke464oTEi21"
        @"i51jO98Lz3HCU7vqyZ/5e/+t+tE/9SPn6+0NVNii028o9S5LR5c5/+BxvvbyFXwFK0MdpTbNnOMHNGtrmtJu0RsO4MxDmIP3M++cJPQeQCXnkOIo"
        @"hAVotnHhNerqGmEyRdv26NLMWFjp0llIWd/c5vptqENkw4lao0kQWtBQU+IIAjomJtumSELt9xtxUehyNxHYA42N52wpFUjVHhFiWlGQAovFKbBN"
        @"IFWehJgQjI/WWu89UscdW+JopCU5NIRPfADxvR9Fvv9Bkn6Olw2jcoQzcSuuRMWOqDh9/jy+rnE0eLNXscTdvnExu174aF8WpkYl0eUopCDLEnp9"
        @"g1E13Y6mns+p5nOchUOHluI5VwVkYnHBtk3EiF1Lkh7Oau7cmXDpyhZfeLZgt4bv+uMf4Fu+64+ieilID2lg98u/yeTS65jZnK7QiGDxLuY7OBdo"
        @"rCBdXoWm4uZv/Sas32FZG6a3d2lqcElKtngaM3gKzFlgERHy+F5lBpgjXcV8WlD7AX/pv/wp/sbf/tmftV5d1ybDBRuXLJ8iQoyaiw9/T2NQIgOV"
        @"xFaKONaLQrG7m6TcG33i2OMw32VtyrsL4z2VM78PJLHfRyqwuAsJ+x2BoXf/i/hXThL25iOiHf3s61b/Tc9UBEySvtxU1cP/wZ/50Q+papu6uIQ2"
        @"u5BbKlexfPxBHnn4IV594SV0gH4WIR4LecPJswfoHcgZ+5IwXEQfP4/o3I/VJzEcgzAEr3DlLYS8RKamMC2Y316H6RSVGIR3JEnG4SOHsZRcu11Q"
        @"VjVpWxILI3CJZLepmTnoS4n2klA2dNOUugVsBi/asNBWGOOjzFaIuKjGk7W/O/NvSyUlBa7xmACpUlHtF+KiGUTAaA3O0zEKRODm9oTJ7g2G/RQO"
        @"H4Ssg0kyhmnOYpKRoyiqOTvOc+b8fTTlhBBKvHKE4CL+yFqcqzFKILxE4FCqQuqYd6iVIs0lWS6QxtLYOZ1ORlWN2N6Gw4e66ExTlGPAkWU5Wmf4"
        @"IPEhZzSpuXx1gwtXt3jmuYaT5yQ/8CPfy4PvfQIfGmQvwxcj3vjSF3Drd+g0NbrxKB9o6oYQBEmnR2UtnWPHYGuL21/6bZKiJGsss60xTekg6yJW"
        @"D7J433tg8CT4JXyVopI+QsBsuk3itwjNDnmWsrPZMFx7kv/273zqNe+T3y4a2zIhRVu9ivZIG8lPe116gUeIvUi3lum43zCUb7vS/3X31e/LHf/7"
        @"fQT4+mni/xv7kOLeBELNdNak/WT4t8gX/jJLK4R5jzpI8jRF6C4Yw8pTj/Pn/4tj/J2/+jfJjWIlFwRRc+vmJodWlskHCY2MEAfdfR+CE5ShSyI1"
        @"UhaojoYmhyqg5lNkPaecNRSzMUOzyuLSCqKa8fh7ztFZuMWXf+sy6xsFiSjodDrMvEBmOWJWMJ57lvqLqGZMUVUxb68dAUagR/T7hnty94QQaMl+"
        @"N0ng96A/5CFFYGks2CTmDUoEVRPhLLO5JQ1QhUCXhIPGM7805fY/+A3MP/sSOtSI6Rw1trgK5hVIA0UNTAoyHGVoYsnvPWEP+eUt2kXfgaNGhIAJ"
        @"KmLUjSDJA6YboL+MX9/ACE1/NUPdKmn8jH4PTGMxoQsuoawdjUvYncKrr9/i5Qslkwq+64ce5ekPPUXtSqbbN+kdPcruG69x8dKrZFpgpGBUFfSz"
        @"BF8pkk4PdMJkHhiePgm3rvPS5z7Hss4RSrE5n9FIWDncYav0nDz3BCwciqIbN0OqIdDBi8Mk2WmayWvgPKoYk8nA7MbLLIjp9257c0GnS5+tgquC"
        @"8PGsvr/rydjMAxA1QjQgmkEc75hxbPSJu+fcP6hMwHccaBigk/cqafTGuYcfGM18hdUBkSd4HKaXQG7B3UI+sMSP/id/CrMsUUPB4PCAxjTM7QzT"
        @"lvGlK3BIAj180HFO77dBzcAXhPEudjYlJRDKhu2bG1x6+SLrF66wsDBgYaXLsbMH+MPf934e/YYVmg7cmswpQk3pPCNggsNKReFAZZ32/6fe9vCt"
        @"8V0J3YZqRoNQVADebZDIQLTnAiVQi73IMrAuUHrwOkF0Ugob2NqpqEtHp9F0blX41zYRV8eIDYvYBTkCVcAwTWmmMNmeorQmCI/zvjX+uLbjH92N"
        @"Wtdo1Xr5deTq6cwhOw7f8bCSkJ9YQC4phof7LB8Ca6coVdHvZWRpn+AyJpPAa2/c5Fc++wbPvlRy/IEFfvw/+m7uf+Qco/kuw6Or5Am8+Gu/xMUX"
        @"X0TPatTcUezOSHQOTuMbyXh7jiJjeOAYo1cv86VP/ya561Bu1oyuT6mn8UR9bWvO2fe8C3PwAD7MYfY6+GuQ7IIskOSk6VGUOUoyOEktFHk3IOsb"
        @"fPkL//PTRtYPV8083YPHRlFOmzKFhCDSu+RMB9hj4Id3exz6nrL+nfv4fTwCfP1HB/4NR4S3r5axZ+BthSs2/pteWnz4h77/KXZvP8fa0Q6yA6QB"
        @"LwqaZgflZnB0mXOnD3P91gU63RnLBxP0UBO6CergQcziOWrO4VkkEyDYBvsWYfYKbvI6fnobNxrhtufYXYcqUnyVcOP6Fldu3GRh7QDJMGdnNmJ5"
        @"acjxU4coXcGF63Mq6xjmXYJt6CYpSSqxrsa1Y984CWkZy62NVwiBC65FeclWKRDupgWHGNNdO8cYyFJFJhTaR3qvwzP3FjQEIwkJWCMomgZhA70s"
        @"oyosoQI3g7KGygG9IZd2CrprOavHFpg0M8pAywMEtMFJgxcekTZ44cDk6Nwguw2h6wh9g1swmIMZrOQI4dEC7GSHXqJZOHGCPOlTTxWX3tri81+8"
        @"wfMvNfSX4Vu/83089aF3YylZXllkcXnIq199lpef/wq+mEPZYOqEZlZjjMJZCxjKumHt6Br5yoDLX36Bl3/7RXLfx84Es+0506lHGhgHePCbzmAe"
        @"Pw1NhZA1hB1C2AHjEGikSKL1W0WrZ+O2qZoZs50pvcEB/tY/+KVZnS7+jPd3wz1CK4CKwS3OISxC2OjORG2IoMb7ZX/YOyL4f7cA/BscR78nk1gG"
        @"RxrmH1/tlU9/5bf+4cMb177I6YMCkVQQLHU1Y1KNMZlCKIGsHZw8z7Hjp9ne2YZMYxZyfH+IGx5D9+5HcyrOu91bYC8izB3E/C2ayTX8ZBu/M8Pt"
        @"1LjdQDORjLZLnE/Ynha8eulNTKfHufMP4axnPJ2xsLjCgUOLmDTl1u0tJkBHOaQJNN4ipQalCaptoO7LYuPox4aYpLPn6At3KX/7Y8NGSCbekypB"
        @"XyTIJi4ULoDKDV4IbG1pbKAmUDfgKgi1xXoBweAajfWKuQ+4JGe7KZA9w/Gzy8zKXWwQ+6KfmAOoI6nIRBScTDUmV5hOg+yCWMhgIUevLcJCL5KE"
        @"lMLtThEWOjrnwstX+Nwz13jm2SnSwMc+/iBPPf0k+TDDZIK1g8vs7uzy5S9+idHmNtJ5QuXo6i7ap2ihCTK6K+vacfzkSbJBl5e++CUufO0NZKXR"
        @"Nmfj9g7TaUD3YTfAU584S/6RB2G+HtN7dAVylxB2qENB0E20GgsDakhVFKR5g5QVYT5iY2OX//Cv/O3zf+P/+TNvCZm+IILan8+DIoiAwIGwbQdf"
        @"ReHFfhZV2zf4XZvav1sAfncl8LteIL8/J0xC8YF+s/m3XnjuFz96+9KvYOwVsrBNs7OJLSxp2iUfDJhVNd4MUINjlMUy5vCTLJ16L2WTEHJLd+UY"
        @"Pn+EoI6idAb+LZrxZ5CzZxHNbSg30dUYuzvFbpX4caDZcYw355SNZlZD4SRO5Fy6coe3Lt9ibeUQ9506Q1VVCCU4dOQgJ04dxoSC9a0Jk8pShwAi"
        @"BpR6GT0jTgRsq/bye6NCGVFeocWF7akGvRDUUtNoxcxaNJIV2UHVDi0TrPWUtcWohJw09hekRkmNtFDZQOmgdJK6ljReUwdHKSRWpRR2wtmH16iq"
        @"HRQyosJ9E+f+wkTlojJgJNo0JLkjTT2qo1ALKWppiB8sI/sL0XHkG9yo4M7NbS5d2OaFlxtCBu/94Hne+/TDdIcZMoHV5UWCtVx67Q0uvvIqtmyg"
        @"8mS6DzZhNqpAKGpboowAHTh57hRFXfDFz/wmVy+so4MiN32uXtpiYTjEJw0jHfjgnzhL732HCNOb1MyRssE324h6A+9H1GFEWW+jfIEyPfDL6Pww"
        @"3k5o5pvkfotivoPuHOZnP/UvqZvupzxpFOpIOwBVxZ6gbadZIIJB+CwVIQ5FhfCtqu+d/9D8Af4QhPRrr7zw8BvP/nM6Cz2GS/exc3NGLgf0U0Uz"
        @"LWnYpbN8gGD6zOuMtHsaOA4LkpXHV5jf/hyVqun0jkDWh9krNOMLGPcazG4z363ppF3Qisxq6pmh2KmxhUeahHriKGuYl1Bj6GRrjHenPPPM85w+"
        @"fowHzt/P8lrgxp1NymbOk+97F6fu3+X65avceHOT+RxyLB1jSY1u5+oR1WWE3D8C0IZ8ilaCLURUDHpCVBUCpbU0xreRZopGSGSSUtUOYRuMioYb"
        @"IQOpaycFKvYZCDqafZShKhtEnrN5x0YXnXckJsULqEQALEpEGInRcRc2ymNaH0AMJdSIJAHTBbMC1jAudpmnOSOjmGfw3m+5n8XhYZyNz6rT6UEw"
        @"XL78Fm9dvEJZWrIkResYtjIb1aQmIe32qUKFDJZBknPy1AluXL3Kc19+kVBCP+tQzxuu3tlm7UCPnWqEXICPfM95ho8sUc+vI4VD4amrUQxpExaZ"
        @"5qS+RIgZri7x1iJzCXIR1T1PV9RMJ7dIO3NGt57j5S//wnecfvAHvzGI7LMhnvEHXtiXY5MvCnlk2BME6GPxom0u0oqpY/kv39GE4H/rjwA+OKSU"
        @"JEnCdDo91ut1K+ec897z8ksvvLW9fp3lwyf5yB/+v6z/1D/67e5f/Mt/hWJjG8mYJK/RA0VQHZQ4TpacQ3E/hLVoDU0WMIODCDNAZh6KN6jvfAk1"
        @"fh25ewfKGrc7ZnzrDnZ9nVR0SYslRrcKxuM5Re2pqkBtFZVLqJsE2yRIchrr2djY4sbNG/T7XU6ePs1wccjOZEJtGxaXF7nv7HEWFzvMqwkbE8es"
        @"8S0h14GUNCF+rn2cayuj9oM/PTHKTBCz8narCO/sa4FSgjLU1NJSi4CXkRvohKcWHidjxqAXMAuBGkWDwipNISylCJBn3NwpOP1IRjrQ1E1MKXKu"
        @"jMcpqdBGIXxDoqCjJFrLGN/cyaIjr9dh6kAmS8jkPqp5n063y/Gzpzn18Hl6SwOgYWHYpdczbG5t8erXXuPGtXVCnWBCBxkyfCNxjUDrBKkllZuT"
        @"5IIDh5c4dd9pnvvSV3jhty+AjfmF40lFMfF0+5qteYlYhm/94XMMz+eEaptQTxHNGO1rfFGSeIesCkRlqcc1CQo32yFU22i3HW9UcxzEEjoRWG8p"
        @"Nq6RI/l7P/0rTzrR+ztpElLr7CmCuqyEoWnA6Dzi3WNVuy0Is7YjCCIGfOzZgf5dBfB7rVCt4aSua9I0vVaWJSEEXnjhhVA0BR/6Q9/2F1ViLu6U"
        @"hy8kTH4Qcfovdhbvx85uEpoao7qgOki5BGEV/BLIYTyWCUNQK+h+AH+BenwVXd3AbV9hfH2TJBjybMhka44tLdvbrzPU93Hk8Fmsu8TmtVt4m1LX"
        @"FttoQpAEr9qkoAyTZnjl+dJXX6D7+pvcd+Ycp86cZTabcev6DUY7I4aHV3j8yEGK2ZxbV29y/fJNNqaQyYZMQidRcdbcWojx0TGuZaTzhqokNNGb"
        @"3ziYBYuQquX+ERFkQEFk+VkEykWapwiRqx8CeOexwlGLhkYKlLOUDdxa3+TsocNMZ2MSndDvDKldHXc1B4PhIt5ZgquglOAd88mY7c3bTG9v0b//"
        @"SdKVw6CeYHDkPLg3obwBow2y3pxscYGdFy/x+iuX2NksqGcKbAJe4b3Guyg57vRSPBXTcsTy6oBDR5bAB37h5/4FxbgiNQlGKkaTgqKA5SXJVmFZ"
        @"OQ3f+sfPkJ8y2OoGoQn4ck6aSux4hpIZtatJFeAtecewe/0W2aCHtA2+nsF0hBwGWD6FXHqIrrfUm9vMR5d49aVfffihp77/27dH1Zkgs2dUoqLk"
        @"XcoYc9ZqNkT0iFYgW40AIPyAwPjfHQF+R3PvbfWBEPuUmCSJWnulJE8//fTxqpxd02QfmMyg0YsXU53/JQaH/mIdNF5rRKqxwiBUH5JV0MvAEEtO"
        @"LZpowxRTUkZgp4y2NqmvXmexqcgrzc6tCRvlhKXFA4x350w2C+7svkWe7nDg6FGOH+9z8dU3CTZEJ5fwEBpq63EqoFD42qN1n93dii888zwLq9c4"
        @"d+4c58+dR2vNlavX2R7t4hvBkftPcv/DDzIfT7h66TKbN+9wfeJIgB41/Tzy8HUbK25qz1AqlFekqWMyD4xdg9Ea2UCmDa5pcO2IUCpwQkSrVYjp"
        @"WtTghcVhqfFYE7ACvKvxwK31MY8MH0PvOITzKJOQoEnSDKkSbtyYUtYVs+kO4+mccQ0sweH3DDj88DlWjrwPkz4BnIUUEMOYlLO7BcWY13/jK8xu"
        @"zyl2gTohOBMHmyYaYnxQqFSzNdnAJJ5z50/Q73e4cOESF1+9SuIkw8EqO/MdqqpmmBuWluDOpOHQI/BtP/gguldTbd2mmG5jAnT7ixRXtsiXViCY"
        @"aLcWsDsZ48WYRkmEK/Gyod9xBD3H2XWMPA+LT6L751g6NuKNCxcYvfWrSHfj5xfTU59Arw12ywkYyDs6Laqy8qh9U0/AQ0hTgqze4enfH5wKQAhB"
        @"0zRkWcZ8Pk8Hg0FaFMV4NBqNvLcPGa3Wu0urNBN9RgpePnvofl545q+ysb3D6jDDM0TJVYxaA7mCJ8Ph8UwQrJOwQVFdIjdjVk+sMN4ZsvXGHbKx"
        @"o6Nzmqbm4kvrSAFKdLFNw/XNO1xfH7N26ChHjp/h9sYuo40Z82aGUT06ecosWCrXkCQJRdmgVYdBP2U8Kvjcb3yBlYUBR48d5twjD3H6gfvZ3R7x"
        @"xuuvs765TSo1Zx9+kEefeJxqNmfz1m1uX7/B9vqMwjk0jo6gHVVG11iVJczrirGWpMagKofzEmGSiORuUWBWOKT3NNFWgvAhhnwmCqsltQk0IcaK"
        @"ixQu3IQP1T107wiuKNjYHbG1scn25mV2pzApYVbEUebKYbjv4fs4+q6TLD3aJT1+FLqrgKZpLMZ0oK5ga4uNCxfZvfQaorBol2CCoPaAl7igCN5h"
        @"nUVoxWxacvDQIidPHGJ3Z4Mvf+m32d0J9FLJoLPA1tYOc2vpLgp033JtN/ChTyY8/q2P4d0dZvMxOQnz0pDmPeZ3LIk6TDHKGNsU0+0TXI3Jj+Cc"
        @"JU0N6zszdG6YzCs6eUPHjXH1hKxQcPh+1NpxTgnDyxde4Zf+2d/km/7QTzzZlP1PZVk6qEI9nhfjVCgBQVReRIqPCAoI1V2xUBi/4/fXwdMP/Vu9"
        @"ADjn6Ha7aVEUFUBjq1RKWWmtSfJktXTlxnxuz3TTg8fSZuOzV17+f4fq9i+yvfurDFcUoXMck7+LJPsGkGeAHtbNCFxBcAXpLyHDbXzYQUoHO3Pm"
        @"X32VG19+jeKOZ3nQ4/bNKaNdKEtIlMCYIXe252zv1Cyv9lk9dAzSPjdub7O7sQtJgss0hXUEoUl1jmwMVekISpLlGh0sZTnDa8nS2iqnjp/i5PET"
        @"pCbhxrVrXH7zLYrpjPlkyrDbYXEwBB/Y2dpga2OT0XiHYloz3/ZUAkYSRhZWgOO9jJ6T9HSKrcp4lGrDOmPQJyQIEqHR0lA1NY32VNJR4pgWJVoo"
        @"xo1l1ofH33+Y6Z0dRlsF03aSbRLodODAYcGRE4ucPDVkYW2IWVxGrfboHh3C4cPQOwgcAI6CSvA7X6K48QLyymtU17eY3YJbl3fZ2ZnjSGl8yqwG"
        @"JxQ6UegscOjwATKjefPiW1y5eAstYZB3cE1FOXdIBcurXWozY5bBH/m+Uxw+14Nqm3Jnl0R3mE8d1mZIvYAxC1iXUvgBYeE03dVD5KZhNt5g0O8w"
        @"LxsmpJhOwubGa5j6Fr1qnV7WIDJJduwRWPsAVIErF56hrhb5E//ez7y0sXvgx/TCynjmqudU16eTcvqkVvkzwuvWA6MQPgqrkFVE4IV3tgn4b/0C"
        @"sOeBn81mq4uLixsIn47H43QwGFQ7o9EgJCLLs+416iTN7M1PXHn1Z35++8KnsP4VBitLiIUn0OmjKPNoNPaEKbjbBH8R4d8Cew3UiPlsA9E05KYH"
        @"lcI/f5nnP/cSm1dhuS+YbgWmIyjmkaST9Fe4ubnNaOYJGlbWjnLkyAlk5bh6/To7tiAb9hlPa4xKMaGLd5K6TdvVweJcgzIa6xxN05BnGUePHuXk"
        @"8eMMh0OMUox3d1i/fZNbN24yHu+ilWQ47NPtdpFB4p1hVlXcme5y584d7GiGLhrsTkR36bbrpH6H7qwlzOGAqv26bf9cA93234s+DFegr2FlYcig"
        @"N6TbTcl7isWlHlo7ul1Pv1fTW+rQWzuEWhpADt7AtKxQ/VW6Bx6CA2swfY3Ry7+NfPMqxeVdxuuSYiyZlgWzyrEzsdReknWH5IMe/UHK5uYGF19/"
        @"i/EurC4k5DqhmM+QBFZXE2TSsDENrD0An/iB95EtzqDepN7dJaNLuVkyKQzZ8ARTFlk58gily+mu3o88+ChPPPm+dVvbAy9+7XPYnR10b8ij7/0I"
        @"IYVnv/yLuN03UXfe4NbFZ8i624g8Z3D0I2SnzkDY4Guf/Son7vtjfOhjf/ozpTr0n868eWbSTD/QWxy8VNfNmCARwSCDRPgIbfEtLEQG+f/nFcDv"
        @"pYRqXxhrLVmWxUZWUSClJMsymqaJ83FFi0iWJM2lz19+5q89Pb39ayT5mGT5Plj+OF6fR7ICbgLN67ER5d4i+NuIMKGZb2GFIzUCO52ReB0RbDcK"
        @"vvQvnuX2a9B3ii5DysJyezTm5hS6BzpMasdoUjEeQS/TvOvkOY4eO8zmbIeL16+A1tgGlMuRSUZjEmrv0MFipMI1Md1Xa40Ugvl8jnMNS0uLLK8s"
        @"cvDgAXq9DsN+D2tr1rfW2dxaZzweU06nNLOCbpZjspR+p0uuE6QPuMpSVgWjYkbTVITGIq2F2mJtjdUCbURsMmpPvpgitaDbG5KrnAUyvBKUXcW8"
        @"qfCzEhEkeaeHFw1JJ1qMF3oLLPY69FOHrUt25pZpNUVkM3qDwOJSB9/v4ZaOkN13GlLJ+IUX4I2rNLem7GwGpuPA7mjKtGwIOqG3sEySD2gsfO3F"
        @"17h6dYJSsLacURUl1QwWBoLV5Q6JmrFRwVPfvcwT3/dhqG4ym9xC7Y5I5hVi4hG+izeH2A0rpMfeQ3LgEXzvGOnSaU7d//7vKK0f5Kkcu9odyOXi"
        @"S9baa1bOn7Si+EYfio8u9PQ1RrNPvPiFf8J440vcuvZl+r0yRog/8ASUipdfvs4Dj38nDzz2Q58uOfJJkoVjM1tfkzouVMKn+6lMcJcC9fUSff6P"
        @"UQG8bRG4630WLWnFe48yGt+ShGzdoFEoqaNjDocM5bHVzvVnf/0f/fsH3OQFltfWYPVRWPhmPMeQ1NBcgep5sBfA3SDYHVxZoKVgVkzRMmC8xxUV"
        @"Ju2DGEDd483/5SVe+MwdZAkLvQXK2nFrZ8Klm0AOIjH4ICnGFWEOg0GHY2eOs3b8ELc3bjOfzKnmDoTBJglOSIRto62ExluHUiYCNpxDSvDBMp/P"
        @"0FpiEkW/32dpaYnl5QVWDyzT62VI4bHTMa4q2drepJjNmY0nTMcTpJQUtkalCS5YTAh0EkOuNcYodC8l6WgSHUgzTTbMqW1DlvbIkCRFSTGfM2pK"
        @"ev0hGQlYTW9hibKp8bJiMp8xGk2oJhPc7gjpLGnaJ8sN3UXHcFHSySvSlR7lwoDOuTNw5CjjZ5+nfOkqcqtma6tha6vANpLe8ABpf4Gt8ZyXX3uT"
        @"1y6MkQIWFnKwDZOxpZvD6kqG0V0aP+HoScO3/sDTmCf7FMWbhDBDzmbIzRIzbWDWYJsudXaG9Mh70ec+hstPce7Jj/3YqEpeUqr/WZ3kzOcTenkf"
        @"W2ZPigDKzJ9rwgyTGorZ9MmuUut5mPzAS7/98z+h1DVG1z/H9be+yoHFNVbPnMKHkude3eXJ9/95zj36PQ8XfvnlOgjQBQjL3WPA3lWu2qvc8/VC"
        @"Pf5ALwB7K6EKkUoTZDsm9QoRNMqlBAG1sljVEGSD9ILUJhAUZCadTjePHciaM69/6e9/+vbr/w+W+iXZyqOw/DjBPIggA67gd19E2gvgb9C4O4Sm"
        @"hGnryzcW1TSoIs7eQyqpgbQzAHOAnRc2+PyvvcjWZRgm0HM5d9YLrm3CbgXOQNLrURSBjZ0ZKFheXuD+M8dZGvQwBLa3dtkazfDCRKIuEdsVUc86"
        @"puP4GL8llUcpibc+Bm64OFZyrsEkguFCxuJCh0OriywvDTiwtkKnkxOcZ15MmUwmFEVBVVUxBg2PVpAqj9KgE4FIA51Bl8HyIt2lg9AZxDm+8jDf"
        @"gskOjHZotueM7pSMNku2diu2RhPGxZTCVTgJmRD0haAnNV2d0ckMuq/Rac2wD+mSxC8p5KE+w/c8TvHGVUbPvokcBzY356RmgNEDNrcbXnpjnQtX"
        @"7jC2IJOI26rKBmlhdUmwuJAwLSqGCyd4z0ffz3t/6CMwvA3mZcrZmzDaRE0bxLbA79aIyjKv++RHP0jy0Ldx9n1/jCY/ftaH/GJVg1R6n2MIAun3"
        @"XHwRyR1CIEsMZTEbpCqkqSqfds3uX7j4xleeHt14jvEb/xJfXObkUw+wvmEp7Lv45Hf+x1dn7tAnrRi+7JVAKKhdhTZxgdcqIzStx1/U7+gC8G+B"
        @"HVi1q+C/7ntECrISQbY4rJYpKGAynh07uNpJ9e6rn7bzKwjpIF2EzlkwxxDMgesUW18h99ehvEI9uYZIGkJlCdOERBjK6STO2AsgMZQBRE/j7Qgp"
        @"YPH9Z/jD73qcV37zCm899xZia8rioqHT73J1Y8yVjRl3JlPINemwS1k3XLu9y61bu6wtpzx09hzHj9/Hgcpz5do1tse7qES2XD1FCBohFEInCO/w"
        @"oaZuLEZrXBNfnyRJUKQEHLNxxWwy4crlaygdUC3yW2lBJ03I8xyjNUZptJCkiSJPFU0qSVJB5kA5STAVxfYEOwfLHWrbUJa7THduUYy2GN1cx84C"
        @"dqpoKoMNCVZovAGt83b8GaXJtQNpLdbHjKO0iQt7gyXYCkHB8NYt8sTQdIcoFP2FE7z55m2+8KWvcOktKB1YpbFSIIVkOqnopNDvSbzyXN+pOP3g"
        @"Mb7vh/4CC9/0EfB3wEAT3iIojRIC6UN0VOqUspAUesjw4MOwfJ6pOfSJ0vavpQ4SJHb/2os7kZe2Lc3jtRm8o6hq8rw/LooZNd1f0MngFw6d+9ZB"
        @"7m79y1c/+3ee3rn+DM99/iXOP/wotrrNc5//x8ff9+Ef+fZRnVysfF5ZLxBK0DTVIFF6LIJjUpRner3BOv6d1QG8wxWAQHjdMusaIvJC7jepYvNE"
        @"tdZJkQbhKq+K2J4SvuWky3Ff7v6FN77493/y2sv/HNPZ5uB9j0L+NCRdvP0yxexVxOwOcnqHzO1CMYYkh9JTb82j191UmCSFIlDagF/p0ChLLzWo"
        @"bEjTOYzpPgzqfbDpuPaZn+PXPvU/IQqJCB22C8/1jQnrk4A1kGZJ3OUrh68Crgn0On1OnjzOsVNHUWlgWuyyfvMqIPA2xQWDFCYed3yDdXOUDPhQ"
        @"I3zM9BNeR0KS0AQZ035QLop6vN3/XuE8wXlCbVFSkkuF0aCVR0tPkkCmBan05Kkk7SWYXKMMeG9pGkddBYI1+FpRNxrroHI+qgx9zPjTQsfQShmT"
        @"fAwSqQUyFSS6YaUrSbMa3a0xqx2OP/kw4tBxxl+8wORWxZe/fIkLF8aMxmA6MK8Mo6KhaZkwCx1FJ1UEX1MG+MC3vYfv/OE/CyefAtmLx0f/Gt79"
        @"Kr78CnL3On53Bzvy+LnBlT26h59G3vednHn/n/hb6/7Afy10r1z0YUP4Jq1kqNw9M/m75/S7u3KSaubzOeBTJUEpWYUQyIxbpdz6yaEc/+Cv/7P/"
        @"jo1rz9LrTZjWOWce/VOce/J7PjpWw8+KJANKmmr6kJFqHaE3guq1EuzmHe0DvKMVgGiTUfZebr8fbB8z5oKMgAzpPdIrVIigBac8lQIV7LHEh0yV"
        @"mz/p5q8S1A4LKw9AfipCAO11mLyO234FZUtsUTCf1yjboSoDqe5Thxxbz6mnNZ2kQQWJyg07o20W15apqwalPEl/CfoHoV6C44sc++RH+Kja5Od+"
        @"6lcoxjUBOHxkjd48cPn6OpP1miQDrRKkyBFasDMt2XjxJV596yKHj69x8OAKDz/0JEVRsLM9ZndnStVYpA9oFVBKUzcFSglMEh2B3gZs4yldBQ6k"
        @"UggfhUFi7+0MroWHeDp5D43AiJa6KzxKeFKpyJUgE5bE1+i6QVMhKo/3AeUSUp9ibUZtBbZx1Lahdv/f9t4syI7rvPP8nXNyu3m32rEWSJAFboAo"
        @"kaBIiZREkZaszXZT3tpye0aecbc9PR7L/dBSxISXl9bDxMgvTcU8mBMz09LM9Egddou2bFPyQoXtECxRhChSAEUJBRJEEVsVgKqb997MPJlnmYe8"
        @"VQBISnaYkmGJyIgMFGq5Vffec77zff/v//3/FUJM1IdkgHACa2pyr1GqURkOZCPtpeuKqAzYkbbZNrWDMI2o1ipil/HNp47w7DdGFAX0ZqZAjTmz"
        @"WjMua7SHMIGZ+RhjNCvrlp274d/8+k9w8/vf1QgXxgO0hjicB7YjWQR5Ch+cx4bgQk8dCEbOE0c9oukbKVzvkTDpriKCxfFgPUujSP9D1ukwG9Pp"
        @"pgjhta0NVV3OJ0mylo3rfiu97pdXx+cffcf7fvO3n37qTw6+9Ox/pZ2GLH/7CWJ18T+0iD6Yjes1GXja7e5KtrF+b9qJvjAaD3vtTl+7Cn019+BV"
        @"nQUQExNLL8BPFFIn6mh40XDV3WQaMHTKBo5Yedv2wutKKg0umbb5T3zryf/64ydW/oip7T1aU/ci24vgnsKc/WvE2knUcIikZv1Cjra7mJq/k7xs"
        @"Q7qbcbwDNbMH42KUaLwCg8hiooIg8cRBQtieozIpUm5DtG5uGmfiOP0bJbe8sc1qcYJvPANnzo3pRoJtU3N0ouZwqirBxrAgtxVRv0XUjxjWOWfO"
        @"XeSllTOceP40tvIsLGxjcfd2ZqZTlNLockiZj4iDCG88VeUxprEIEyG40IFsZMeVpXEOqi3eNrbbgQqJwghT1Y3voG+MRa2zuIkclRNghEWLukl9"
        @"NyXbnUDQQpEiRNRMD07UegM8gYfQCKRpApKQChkIjK+obYEIoNPvMjc7x/TUDHVhOfviGY4/9xKnT55lKmxTDkoGGyOMV5xdLcgzR6oCeq0OC9N9"
        @"RFTw4jlDGcPP/Mpufv1/+RBzd/RBnIaWxuicQIUI2YYgbjQ26iGlX8H4Ab4S1FWAU9NM7b6LN931oWOFn/1dI73VdbEjbbXOWG8n9f9En+9V1uim"
        @"rZp1Bu8dxlparTQfD8eLaat9oq49Udx5zsj0c//x4f+r/18+9+WDH/6Vj/Diyaf59//uf9jzB//5T5C0XrAqulhJoWthdRAHREJldaGtUle3DfjP"
        @"gAnoLrX9RIOI+smbsqmu4iYTaAJiCX3hgkw4RSiKXpsLn1g/ewQtLNHUNKo/A/VZinNfoWVX8blH1n0ujgpqv41d178d7XpEOwzt6Tk603P4coRY"
        @"3GB4/Enc+rfZGCwT9BS2KFDdlDLXyN4cojUH7iwmXyNwJzHVi0zfMsUv/buf5eCdKzz6f3+Vbz4xohOOmJlq0e52sJGHdkxWjriQZQQxtFqKOGhR"
        @"F5bVQcG589/iqaPfYvu2Hnuv38XunQts2zYPSM6euUBdWfKiZlyOKcoCJywydAQInJdEXhFIAVLhnMfYGl2VVB7iMJqIUwqcbKYBnXd4C3VlSaUj"
        @"UY0arduyHQPhajyNLr6QIIMaSY2i0Qa0tcCYCicjrBWEScRMf4Zev4PznrX1Ac+dOcPamQ0iDy0L7RZM54aLJzcQFQzOw+qGJQyh3W2BDBiVOS9e"
        @"yGjNw9veD7/wr3+C+QPboH6JejQmnOlQjM/j5AXabYHzEZIFUAvI8DpcvQMXrhPIYaOtGCbQmaPQ4XLQaiPQhMotF3UeC+d1qL73FijLkn6/3xtk"
        @"6zpNU+29oCgKoihZkTJAOsvGYLTU7feWRTf5tdKXn3j7B/7Nw889/fn3ff2Jr/L5R//go+/5qf/uSC2S5ayoiFrxSlWZOLTE3VYrLo1//WIAm6o2"
        @"m90AJy7zO6MxuvATqmtsHKED6YKeE2FWKBWnnL33ha/9b49/86ufZebAXnbtWQK/wXjlm6TVCS6eWkVwPWM9x/SOA3RuvQe9XhPP7OLGG/YPgrj7"
        @"KePUqtHVgchWB44tHz7Ai1/m4rc/z8zCWaxfQbQlPr0J1f8XsO1W4CQb557AjY/TVw6VgysNMg5BJ/zd37zAH/x/3+Ho000VMr/QQoUhqEYg5Py6"
        @"Z1xAGEArDUjTboPSO4c1JV5bogBmp1Jm+lPcdssbSMIWUkRUVcmoHFJUG9RmhLAWMyrBNnW7VI0BiBB+S0ewLCdMQNFYbgWCRo9fCRIJLelIQ08S"
        @"e5LQEQUNH0KphrE0KkpqZ9HWYZ1EqYgoTAlUC0gQcReLotAVg4sDLpxb58LFASPdmJXIWDDdSehhSKhRHrbvUNx0240cfe4FhsOQ9aFldaQ5Owbd"
        @"hgNvgff/yzu57b4boFqnzM6TJE13opIVpDF1mFCrnQTRm0mD/Uh2QH0erb+EG3yN+NRzlBuGLLiN7bf+N7zx7b/7kZcG6aFwRh4OW3K/HuXLajKc"
        @"86rKeJPSNAxDxuMxrVaLqqqa0eRAUFcWW9XMpFMHS6sP66AmN6OD3lX7Z9LWl8R4/NBzX//6w+fOnGJ6bgc33/7OfenMvN4o1lesqxdne1NltjEg"
        @"jNM1/3rNAPwV/X/VMNuEaQCtxmNtE5vFqYkJJ2TSO2JndCI2Pnru2CG2zQYs7FkCLKOzR9k4d4yxdiCvJ5l6M4tLD+LyHjftve8xGydfLn2wUsvr"
        @"HlUuzpzxtDtpr8x1tm/fex449uSfPt5euMB48BhBFEPkCGUIaRdMxvjCV6E8znQoKNYGJCZCCtB6FeMj3vrAzdzxlnv5yy8u88ePfpnlYwWdTkG3"
        @"A3ErYXsYoEtDUWiK0nC+WEcoaCcR3VYX1bLUumBjmDPKC547dpp2HNDrzjEzM8Pc/BTTM7PErelGjdeALgryPEebCmMmRB9TUVmDCgO8dVjXlAdO"
        @"gBIeLwJqD2kQgmpkrA0VgYoIWiFpOyYIJPOtBbwKsATUVlCWjlFes7E+JhtucObcCqNxycXMo0sIofmdMsZKSeUdF0eWwbCmLWCmA6V29Bfm6Vy8"
        @"wOmLF1gbwVjCwQcS3v4Td3HTwe2o1jr5+e+grCHwDjMoUCHI2KHtAN+KEGFFbRRVVJNECsI2MTdTiQGSk0iyxpDBKfJCr/ZmFucv6rV54zkqjV0M"
        @"lVwxfG9tfa01YRhO3IybVqyUEQBJK6XQ9eHaVRhRx+1uWlaVPLRR1EvdcPsnbz347kekzx74sy984bGVU88f2339LSKJE1TUXhllY+K4xdWWBbm6"
        @"XYCJgUKjqx5OeAC6Sfl9DAisNYSxpKqL+TiM1rwOiL0h9ud/68jXPvPxlWc/zQ0HFyHsUa6dYnTxefKxoT91kLh3gDvu/0U0cx81JIeMSA4ZoXAE"
        @"SJfEynvtXUkQBZS1pOUdUy77b795+LOfGj33CIF4jjrO6G6/AXa9Hc6dY7D+VWS1TldMQ+nBaEbDdYIownjB+sjT6+9BhjvwTPPE147zxS/+Hc98"
        @"/Ry2gDRqHIk7cQtdFYyrgtKAnjQ3ggDSVkgrDYjDZhCqrjyV9tS1b0hRAaRtaCWKmalZOmlKu90mShKiKCKYWJQ7a8DUxKoBCTFNR6CdxLTjBCUd"
        @"7VZEFDqSFNptSbulCAOPMYaqLDHaM8gKzpy7yKmzFzh/vmIwbtSDjYFuDLWHWgkMAlN7dE2jH+AVxljmuinbk5C21OyYC9ByxNSNHYZ+xLHn4eCb"
        @"U+65/y7mb5zHV+fIywtIBMIJkrBDWeQkHYGXOUOzTme2S2k9IkqxMkaGu0ln3gHRPlC78GefQpz7f/GjMxTlTaTX/ww3P/Cxj26Ee36vliKWwumk"
        @"KgiliyuUdt+rDP+uVN2JtJeXW/wVJ2oQ1X6QGT5ewQcIbwlDxV//zeP+rXffJ5TvolQwb+rhWhhKjBD412sAcKLJAoSXKBsiJgHAC5oA4AOkMhir"
        @"kS0V53m+ELpgpafGDz3/7Oc/99xXP8PizpL23nm4MOLkt4+jK8v1N9/Hfe/+GFnd+VzOzO/Uon208eCbqOn5gMCG88pB5UZrrW4aj7XTkQjmA12s"
        @"zaiV33/mr3/3V1df+DxJu6K3dB3UCasnjiPNOokPCMoeVQGVqbFeMBgXbF+8EadaZLknac+xsHc/TO3g1KEnWDt9lr/40y9y7OgJzr4I1M2sTDMg"
        @"FuBMiKklRleN43Kj/E2aggogCloI1cI6ga5LdJVjnSfPm6ChZOMpoBSEoSRQjR59GkZN209JkiAgCRRREJJEAWEgMdUYIQ1O6oZRKZqA7GtwdTMg"
        @"4M1kvQeT2QEn8SohUDGj9TGVNeTWkdsmKCAgihRJktDudymydbrCIo0hlhD1YfEgPPhT70ApxdTMNISCkR6izRDvLSaHqvSEvsX0VJtxeZrelMSL"
        @"ESpsLLErr0lnY2qXMNbbmLrh/ZDcCXYE5/6Qi8tfY7QasefAz3PD/f8zduZNYuQE3numQtHLs/VYxcnaawkAW2aomC3za48AHzVsPymorI6T1MeR"
        @"ihbKzC8Lo2gncr6syjUfSF63JcAmJVJeUYM1rSVcPN9Msfk1h6IqjA6kHMxOtQ+GxenfOL38p/Q752jveyP2hRO8+K3v0OrcwOzSg9z+tg8N8mDu"
        @"45XvfDYgXhFMAMaJ7bLylsibNQiIks58Nspx2H7Ubq8UdUAeRUfYPsfgWEUniKAekb/0DDbPiaNdjMcB1VgSxfPIzjba/e3M9ubQJHR7u5kKeuSZ"
        @"5uL5ddzKSzg35LrrS379f7qLqriN4996kb/686McfQYG56AdGfptx3TaodXtIIVBigIpDNmYxna8LCirgtqFGBEiRYqQnvmZxglYSIVzUFsxOb1r"
        @"jK0YeI0zEAqIQ00gmg0tgFhBFG4GGFAhJBG0Y+hEEWkY0O3ECG9xvkbbirxymNIxznMGdY6QCm0dwsJ0FJL0EkIl8FRUjFm7MKYWUMVwy23w1ju3"
        @"ccPNs8ws9WC2DYOAtVMZorUb17oe32mhWi36aYeNtQvE0jPIN6jrFlKXBC6jGJ6lFzniRDIYrJFO9ehGBn3888TzA9h+E0ztRu7SJPoYZ09+lefP"
        @"Psfi9e/eL4L0qBMiHmqXtXptTGXZIpi9Gj1duJcFAvEyLr/ECYtVehEvB8qlmXBxrJzsgcuIa22E7mV5eZ+KwmNeBEtp3Fo2Tq1JJPYq77+rHAAu"
        @"uaMgXOM/v+WYslmD1QSxRHlJK1bZYO34b7149E8ffPGZ/52bblugOP4iJ06ss/eGd5DsuZd9+x76lE1v+ci4zOMkba9R+S2wsbFftj0FIMIMPL62"
        @"a2mskIFaK+oCp6Je6cyiGzfgbNqdpnxpncGwxUh3ibu3k3bmmQrbIPvE87cAHZAt3vyW+397MPY6jvuHx8O83wntwtcP/dHvR21FvvEkVXWOdqI5"
        @"+NZdHHzgjVxYvsDXnzrN88fWOPbsWS6ezyZTd9BtSUIJe3amVAby3JGNHVkuyTWMxoY8rxiOPROrPjyggoAgiBAqIQ6TBlS1FQKDVAopJHjbICxK"
        @"IKVHKosQEy/CGmoHpbagLMO1nFYEQQhOQhTBtmmoTUhW1AyNJQ1BygDnLGU5pCwbzoFM4Nb9cMP+bRy4cz+7d24j9IZReZFvn15lZzAHRcz8jbfD"
        @"wl0QzKJlxF333Tcoc9v/9rNP4sqcILAwWiVfX8GNz7MwV2HG51hfP0nQ2s7Zc2eY7hVE6XnsxpOodgHdJZIZjT1/nMHqGebOHSMmf5+M0qO1lNp5"
        @"S14XcSgi/dqEeTddruUAZOYIUF72Gtkpl9naoJRam+rMHinrYoUEwFDmNVGQwFUOAVc9A9gckPCTBbjJCvLSrgkPcZL0qmqUJbFHVRu/MdceffDc"
        @"ya+zb+8eTLbBseXzLOx6C3e8699TBTvfV6V7v6Cto58m88X44nujsP0FfNCEGQcB1QHhwUh1SDhDWFfzSshsXNkFEQYrcRxmvhg/VJw/y1zcgjrm"
        @"hZOKG97w37Nj9lZIFxgOK+LpOW7cff2AqPdI5dUqMjqiks7hMtQHc0ri2f5jmbb6prf9q890o/x9R7/6h58ZnDnEuRf+kmxwjp1T68zuSXj3m+8E"
        @"rcjOjzh74hxnjq9y/tQF6kGFqDzSG1rekfYquqVjoYqp6oBi1CIrasa1pqgNY23RFejKUOYG48A4kAFsKlBJYQlVUyZsjgYrP8kOFLSDxhWIEGRo"
        @"UQJ2bIduF3o9QStVIARV5RiPazINGwbGDvLaYBTMTsHiHti/tIM9u2fpTPfwQYIRfc6vl/T7N9Ld+yA3z23n+Reep92H7uKtvOHNP324VNMfHxm7"
        @"UJqp+XacHLrxTQ/p0AgtTbVfqXrfkWcO/7aQhjfeuo+nv/U15swFxue/Tbj6Tc6e/QbTdUlbHKd88QLtvRHJzBzjToQoPdaOEGb0C8LEh70IVipX"
        @"3pvEnc/6ukEBt5be3xMN3NbXG5H2TeqwcGnGJh6g9JqBNeHB24BQhpTn85UgllpGtme9XrBhsGJFjXJyyyz3dcwDcCDMpD6XWw6zXkiKymT9TrqY"
        @"b6w8lEQX/8PjX/g/8cUL1FXAseNDbrvjJ7n7/g9TxnsXxnV/zViIA0Ge5/2p7pQel7axZN58i310xOP6m+ldKwn2GGdPKhWshGFCroe9buD6xUbG"
        @"bGcnp07Brff/j+y79Weo4h0frAlWgjg5TF0vytZ1g1oFmZs4vRSlJm71v1TXOh5WVRyIWAdxT6+X0WdvufvnBs89+2ePFcUFzPqT5O48otzAZwUy"
        @"bdO7cZrerUvcZO+CUQs2WvixxOY16+fP8Pyxb7D87SMMzgypao1tOouEQTN3L2JoE2JdgnGKytBw8ietQSUmrj64SwvOGrqdiNBbYgltKeiEllbi"
        @"6bQgbjniBLpzPa67cQ/btm+nsobV1VUGgwFT0rAn9qhUMj03y7bd07R2dCCsYbQB44JS55xbKxH97cwv3UVrx11g++x701u+/MTXv3Lf+plnIVkk"
        @"M71Hxqb1OFGUJa1ocXAxi/ut7rK1Hu/MYU8d73nDuz4eRnFcyxv1TXd+aCnPTj/cb5f3fuPv/jjpz91Cfv5pTq8eptOvcSdfoHvjXmb3Xs+F9ecZ"
        @"XDhOPykP5iGxrnzcCrufNtrHSmy2Ad1rP8i8nIh92klnQSK8IFat+bQT9cfjbBmcdohShBEOgRRXdRbo6gYA6X3T+8c2AgnC9aRTmZjwhB2KsNXm"
        @"4sXzvZ39aPXrX/6r/tkX/oypFpw8btl/xy+xdNcHyot66pHu1PSaNSW9yGPrYrES0fKwDpZr1XAJHBIvAowIM+VdFjqL8oaRqQYGiZMdRAVpILPv"
        @"fPMbC+Ojn2b5hbPsuf3D7Lv15x+X8zd9bDyqTwY+WhM+QvsqlkBVm54gzCIlSWRKuV7ESSvNkqBB8L0otVCO2qeHr7/u7mMnjv3FvvPPSwajr9BK"
        @"HKErCVwNrgJfNd7cc9tg+x2IYC9B1WLe1syPjnPg1Dc4d/LrvPTCUU586zleOlmysQpZBaMRlGWN9/WkFGiER5RrHlZJiCb+gp7m18QhVKO6UQmK"
        @"QcVNxqASUDMg+5K5fUtM7dzL9M0HifbsI4oiOroAN4Qoh/YQ7HnQQygvQvESdbaBHYGpeqyOp4h33UP3hge4450f+kQ5Tg6poP3lKppfuP2u+3/1"
        @"b//k0x8xY4+sw2OtuJ3p2hEG0SCWcaZQOF8hY4FVPi5Mva+04WEVpAyzfGVh9paP5Hp99caDv/TbndgsPnv0bz4YnTjE6vN/i8ueJ85PEt1xO1Pd"
        @"GUYXvsOTX/8zlu78Vw86u/CxJJo5CPUx74zekue+dEy8Yk86cZlF92UlrCeYuKI3rr5+07FqAnAjPFaKtY218/ft3rH74CjXn/XWrRmV9KTwWnit"
        @"X9fTgNI3LpeXx1+PRHiLFBZfjei2fVLps79/6tR3UEKxPpYs3f+LHLjhbZ+zrb0fiuJUD8Zlr9tJsipfO6iUKMM4QRsQanPzN29eEww2Z7AlMkqW"
        @"pRUIEfQC4bUeZR8eZppTa5Lb7v8wbzz4Kx/Jgz2fdFVAjZiPozbj8YgwDpellCRhQllWCC8wRR330i5CiPnBYD1J++2V2lbU3sZKJGut7uIHl266"
        @"/8jyycdZOXKeoa6ZUyNErXGuBFVhIodXCk+MtCmCWcIYSCztvuWGW9vc4G/hHaMLMMgYrGZsnB9z5tQG506vc35tyODCiOFwTKUNdd3I8HnfAH1i"
        @"MirQCqHbhm4CnbZiZmqGmdku/ZmYmfkOMztnCOfnYXY3zC5Bax+NxX0IFMAp8MehfBGq0zDewI8vYvUGdWGo6y5jO8XeOz/IgQd+kyz8Tx/W7Py0"
        @"DwJsbej1e1RD++iuvbd/ZDzKkUF6xNWNy0+R51matNClJpAC4xxeCi1kdAQRUFlPkk7pjaw6ikiIoh2/uW5rdt7wnt/oR+OHvvXcFx889Te/z7mz"
        @"zzPzzAkWbthHduoZVo8dohWYRY2kGOvDiHBJKpc1Wkj/OEpu4/Lrr2S1Xr6+Q4k2mqmZ/qPZeERdEUet7oKp65XGQFheVRzg6guCOFCBpKZEa72/"
        @"25k9Wo4LIiSBMgRi9F5nz33mySc+3z/+naeYmprhJ3/q3yLEdfeVdedQHYBpzNWR3k/kl8FPbJjcy0gefqv2nRhuO0MUNZz5QDiEGz/053/2h5+b"
        @"aQsefNd7HxmZ/sNato9WUuGRKN+MuIrJm+Yn1bTwcgIyNo9rpcNKEDKgri2dOKXON3rtYPjhwK09fPgr/w8vPfcY26MT9Hpj6l6M7U3jWnsguJlI"
        @"3g3+egI7B7YAfxIvnkfwAogzYDagHoIroTTg2jDUYFTzBOsCrAfXgIa4FogAXeaowNFOLMqPm7n3dhuCpGkJdAQkLRApJPMQzoBcBG4CFqBqAesg"
        @"nqDWT4B+BpmfRY0lVA4/XCcvQy7qebqLD/K2D/6vDMS2D2umPu18i9A7hG9o3oiawJZLTz755LF77n1AFNoQJ8mW8lMcRRhjtmjhbkIYuxw7ktLj"
        @"vKGudS9Oo8w6PS/NxkdnxPpH//aPP8npb/0X9u+bgrjNd56vuOm+j7Hvzn+5r/L95coqUHayAV97Lr71CBN+C5flDA10ILdYR17IiSYgV7UGuOru"
        @"wFI4tC5IwpRuZ/boMMt77bS/JEWAsDYORHXgmae+0n/qqcNs273E+x/6t9Ry/iNZ1TlkgqkHHCHSX5JW8s24yqVcwl95q8m/frJ5gyimLMs4VBAq"
        @"O3/kG09/TsqUex78+bvOl53PaBUftQIup4y6K/4vXhHR3ITO7IHaeoSKyCtL7YPMitbjlvTxINnL9OxtUEfY2uG8Ae+aSUAfIElQPsS5AusuUtvT"
        @"1PY0Jeep3AbWruP8AK1X8XLAYP0YXq2jqxc589ITFMVxhuUJXjjzLKuDMwxqzfm8xMRtBsZxYv08p8cZG9lFdHaKIj9J5VcYjp9HFy+CO89o7Tl8"
        @"dQ5jLlL7EdbW4KImsJgM7wYoN8RXIyhzKCy2amNYoL/zrUzd9OOM6X2qYurT+BjlQTg52Qy+ycyi7rJKpxlrjQwERTkmaTVMu1LrrfcJr5BeTd7r"
        @"S9hR7SxCKVAyMxaGWu0R6XWfGPgb+u986KOHb7jtJzh52kAFU92IC6eOoMy5zxTFxXuDWFx2ar/2Tegv4w7Iy258k3n6CcjYAI12smavriTY1S0B"
        @"hENKRxwoyqKmtoI4bmd5nmet2FGOBr/hffHg8vJJbr/9Qd5yz32gep8Kk96hYVHHAcWXGgPGf/xV6Jq0lWhTN6VYNhrznvd94EFd1wfbnanHcuO/"
        @"R5x0l33tyhqxqQsl3jiiNIz1uNb9bq9X5/Wqku1H77rnwYUnH//9A+MNibEF3o8QVhDrHUDcCJiKLl5leHEWaZ7Hu+fxZg1vsmaASRvs0FHLkNC0"
        @"Ea0u2pTUqkPmUjYyQyUXCKM9zO96K+35fZiNEUWZsZ6tUJl1lBozrlZI7HnUxkWiEOrhANEZ0lnYRVW8AAlgWggFBAp8hjXreJdRlhWRFTijqUuo"
        @"3Cw2vpnOwtu59cAHjhjmPiW9Q/ga4RT4OPYCjRiD8NS14bbbbhNhGOKcIwoTilwTBAFxHFPX9cu215W6es434jDSu14sRSZRh8sLg/l+N+HcIDx2"
        @"z0/81uJXH//0wsnjjzHTTzl36hmeO/JXB3fu/+klr+QRZ8mk53V7XWUMwGF93TO160fR9Irz4KxHSo/1Zdyf7X3pi3/y55/IRxlvu++hj9RmZiGO"
        @"Zh8ZjtxqmCgtlcHa1/butdvtWBdjLb2Pn/zGU6sYTWXMYpykjxW6atAxsbn0XgUpFgaHRG2ld5d4DJJGils4EUdRFG9sZLobRZmx4bHChseibUsH"
        @"ipUO1oGwhsBMHj8KJqlujpMn8P47SHccZU4jXI6vctBDnPYENkKPwNNhdQhO7KI7fwDtFZ1Oigi2MTd3G3ff/RDe9T5lDASRWjV2+OGjx59ZYHyK"
        @"0fo3OX/mz1F1xva+RMkK6Suq1ReR7ZnmpA4mvcOwB+T4eoCrR4RCkQ8NqeugbZv1ao7+9jfx5gd/+fGRn/8dQ+sQBE3Z5CUer93kJJSYReNEmSSd"
        @"taqqCMMQU1tarRbWWoqiIAi+9xJtTGMkKgqyosiXetH0ICHKKm311PyNn1zdOPvonQ/+61/95l//Hw+uvvgkprrIuRNP0Y7N4nqRZaEMeT1fVx8E"
        @"lDJj0pYLw3CxMvVKmIQ4M1r487/8iydD77n/He/9NV+lj7fbswtl7VZUBDUllcmbQZ3XIK1cFKWua9ub7rZ1ECW86c47FuK019SeUq1dGhS5dNpf"
        @"OjHcJXTYX16fii1lI+8dVamzMIx77bSLrQparZm1Mvefhv4HVTRHrRPCSuLjCRQfBCCGINcx5itgn0WW56DKG1uvusTV42YWH4lQHYJgD71tt0By"
        @"PcORYHr7IrUV+KDFXfe889fGYoHKhceSVnel8G5VBgufvG7fjx1sBWbxW0//6cM2sKyf+lsurL9IzJAwz2lPtREyw1tLFY+plSGK5hBIlCgp8xF2"
        @"OCakx8WNFoQ3MH3d3fT2vI0q3vnxXIeHAhlPNr9GYrCoBm33Ai/koNVKs6qqcRYMDqUURVEQxzFRFOGc+y6JtkB66MYtxkXWU4nQIgxWSm10O+oe"
        @"LPPxsdW1YqU9s+NQVkVH3nj/r/721x7/z7+Q27/m7LkXiBh/MHbpF7wUh/0Pt0fuDzMG0NTRUZysVFVFqYuVpBUu6omZxdTMAvfc+8CD1iVf7k3t"
        @"Pjgai2Oo9N6qBhWGBJF6Td1bJwRShUzPzC4Mx7m+5dYDwhOsDYaj+5xXa875+FK3ornFq6i4ejHRLhDNXD0TNWO8IFIBQSDRusiqqtIqTihrcViq"
        @"/mO37n0DKp6mdjHOBngb4WSv0caSGdgTSPMcQXUcoc83pgTDEoYVVWnRJsQHC0StGxDJTRDeCp27ePADH3tk780P3XfbXR/at+/2Dyy8eM71Ktl/"
        @"JOguHMpquVyKJBu6cMWGs49qph+5cf97PtHf+QDX3fzTmPBmVGsfne51UEVQAuMhvjyNK09Q1SvAABE0cmOuhNEoIpl+E3M3vJsy3sfSne95+Ny6"
        @"zqSMwKsY3+AyTgDCgvANFuDCLM/LZsRWKaSUWx9D4wf5vUE3jzCOUISZMT5OWp2etsRZXhwLo4hubyoe5nWvonN0LLZ96I4HfvEzi/vfQUWHP3v0"
        @"cwenW35JeXstA7iaV101yjZhGE0UdPIVcNQGbrvtzsT5hE5navH8Rva4kFGGcwMk1LbxC3ytEcw5x/r6YDWNEuqqJO6mS16KR611hFGia/tqkuWX"
        @"b37/KoGFrb7ypq2Z982irq2hKqt4utNb8HX7MZlMvc8R4n2BkzF1ME9MB/wqrvg2kTkD5QZuLPGFRJQOYyxl1HyvGe9kx/X348UumLmNxZ1vussG"
        @"3cMy6sWltVoFnt50+/eccxS61Gm3FY/zXMsInHc457V16WM33fazn7Ll6c8dP/aX+y4e+yLnsqdRVclsJ6SWY/Aa69cx7iTxnJs8vZBQ9rHBPL2l"
        @"93P7HT9XPvHts0mtpn6vk0Yr1tR4p7RHxEYqjXAIbyZy7yHCS9JEkBcFSZJsbXjnHEKI75IBXJkJ5Hne63a7sa3N2jgHkhAhVWxdndkqz9phhBOW"
        @"3EEdTP3eTW/+JX38yOEPn3j2WZ788uOfueXNP37IEK9cywCuxuUlSoVEUUJZa6TyOG8JgoAgaq1Yp7Qn0uOiWg6SWKtIxJUrj6I2XYPla34KSinC"
        @"MMxQijBKWN/IBkKGIBSVsVup/KsDgJug1CQvEGzxDTaBwEBJ6rrCuoogFHhvCaNE55Vdeebod94XhClexAihgAgnekAE7jROP4/JLlANasZDRT6O"
        @"0XlCrnsUbjclS8zv+XFMcBMmuZ7r9r7xPtmdPSzS7lKJ006qOC8rPApnBdJL6rrW1tWx9QYnPLWxvag1czivukcLdt23//aHPp7ueCeu9UaC3kE2"
        @"igXGwymqIsWOalz2ElSr4MHUMRsDRX/2Nm5/w89QBItvuPHA20Rp4pVK6yXpmhkERCO8aYVs5hYu66KY2rIJACqlcM4RBAHe+0kL8HtfSTvJstE4"
        @"Uz6ZD0S8KBRUosgKN4pVJBoNhNoiVYh20RGS6375un1v/4VtO5c48cKLOOTg9ZwBXPU2oKcRWQiCoFkEQjbS+FYhiBAyBClwosqsLDMRGbysqa2d"
        @"bJrXngEIIbC20YAPo3Sttg0NedOW7NI2v9LJxYvNdF9+b6KDMKjAY2yJlw6vLFbCbfvf8HFB094yDpwIaMVzgGB08ZtUw2WqoabKu+R6lpHbwVDs"
        @"prP9XtL5B5jb837Gch+33f3BA3sP3HdAq+hIFZRoLi47lcVODHQcgTeGwCsUId4IojDRQjTkIEQr8z6mMFUcdntr56vOZ26+++cenrruJ4nm3oOa"
        @"/jGmd7+XPN+NKxLqCydgsAwyprJTlG4O2duHS6YeHulkGdnrVdrHkVCrAT6WWAQGJxxWgCVolJ7ElRmVn7yum6+5cw4p5d/bdtPeIluRli7Yo4yI"
        @"pa9AFj0SH2sqhBAI65HWkIYtnRcCq6Y/e/Bt7zvQ23YDf/eVrw2cc0RRtCX+EQQBWusr3v9rJcAPOBO41N0RW59zNK6qfqIVuCkZ1kSu1376S3/Z"
        @"EhQTTMD7Kze0+IfGUMl3Y4QJ3wziuM3H87J5Th6kDMGG1DqkH/QgcvjRMl6vYeoCW/UI5A6S6eto964jCLrQ3kY/nkfXXe5604P7Nkro9KdXh8P1"
        @"xcCKZe/tQhQEK8JPHIj8RFnJc8Xr3GAWgsqarNVrkZVlHKUzR7VJf/OmO35yeeX5px9m5xDKl9g+tYti7Wk2zj2FvbCOSmcotEV1d0F/D6WJjoZx"
        @"Jx6XVdZOu7Ewo0xXejGQrIjJa70pv+3FJTUo/xr2mBMN4Uo6BbiBwA0aVl8DKnshMxWA8gpnPE4I6tr2uv2pfcNhdeRtP/aB/pef+PpAKcVoNGJq"
        @"aqo3GAwy7z29Xu/vxSCuBYDvExeg2YyTlN7LrTf3EspuL7MPcxPl4MkGek3miv6SKYm/BAy+EnF+pYdbQ065Mj44wWTCW7wsMGwGLddzkDVBQDTe"
        @"BlKgRzW9zi6ESKH8DvXGafKNdfKho5UsEnQO0N9zD4QL3HbrWx4uTbjsbHREBMmhYVm+r93rP1bqse62O0e9F5RFtSIJccYSTBiRjWrNhFE3ASul"
        @"hyD0VNUYjMRJ0RuW9b4kSA6F8cwn9+y9c1WK8t5+V+h6vP7RZ5/5AnUuOb3yDRa3F3TaivNlys23v4cwWDxmTUUaKMqi0GEYErSSFa8btD7wFryb"
        @"/O5GvERuEan+ESy8rXXTAIsuKJYvfSlcQTSTjroezSun1lwVzccy1u1YZ1m+frjd7rOeZbzpjoNCKUWapmxsbGTtdhspJVmWEUXRj3wW8M+2/yG3"
        @"goB/efPnZa24116EfPdj/h+yMDd/1m79129hAJNB/cv43k04cA2C7V2fqmRqagovIuhNgznLxuoyw1HEjsW30p67C+Qi+25++5GR637KhnO/BwlY"
        @"Q4Ck000e3RhsPBAG0RElWStG+XyapmtKBGjnaMbNmtPXX3Y3ZisOZyxRFFA43YviZC0QLV3n1WKQdFaJw0eFso+dG248GEe777v5jT/1n7797GP7"
        @"1r+8TvHSOtYKrOggQjWochsryYKu9UrSiqmcRZc1iWjFynstJhTqS9Rs+f1ZI5NDwUq9hSs0LryN755SwVocJ/PErWSUl2th0igCZaM87k3NLHhb"
        @"r2hdorUmTVOMacxa0zRtTGevZQA/4ATAX37Yuq222qVPuiuANfzl3OrXTqQUm48y8SfYSv8vP2G4RAK6ZBzTnF5yK2OxV3LAfaN0tJl6C+fw8mU2"
        @"UMLHBLAx3KCbzoGw6LPfYjAo2HX9h7jnHR+hUv1HZLLwmbHdsezDZEXErbiqDGmcaKs1popIk5kvtZJ4Xhc5aRSuSWepqgoVBlix+dzkZRNtE3tw"
        @"JzGmppd2FvOiQEmPqUY6DsOVfFSAdT0RBZkLpx8tQ4cR9mNLN/3Y55af+iOK1b9A1AVTvV2YWmjvhDZOr8g4Iq9LZBShWq3Ya689DuldM/exFSAb"
        @"X4JLgfy7zeG9+sm/BbI68NJRqaZEFC5GOUngLMpJrHcMiiKLUrvmYyhNSDueWqrq4XJVbKzUtmEfRpO5g7quUUq9Lur/fxYg4CVFID+568mgjb/y"
        @"6xO3YOnlZPBmcr/GzS8mwymbEUX+PYvuVfELNl1e7RXlihObQ0mSRupMNU5Hvkm/vXB9IijqnN5UF4Yjlo9fZH7HXbzz3R+hlnvv0/K6XzuzrlaC"
        @"eG4gZEKWZfcqiW6kvxXGCkwN6xczrXVNFEW9qioXozhABgpPMyxlxabqfzPBplzzbxgkFIVeSaJ4pRiO9oUWHSOJooiknWZOhhC2YiOjWMv2ozrc"
        @"9eDtb/3Zk8NqO/m4iy0TEtV+NIjCVR8qZBggwgBjbVzVeexlhZP1pYDqwokA7PfnUi5o7OW2godHeFCuAVfjqDOftFJduZqkG+931IzzwXLom6mR"
        @"OIyoqmrrtI/jmCAIMMZ8jxbktQDw/Tr/G1VML5qNSIWg5hK/X4APJ/fLx/rU5X231wQESn9ZJvK9YaeXfZ/ciluTQNFDuN4mMWgy/RXjg4n65ys7"
        @"Bs5UhN0I0Qt5cfk08zvfRXvmXayOpx7O6R8aOUF/fnaxMnVmq4Jt3eRLosyWAuebtplwxGnca3fTLE0TqqrKhFCrYStdHI7yXi0FVoKVjZqNoBmI"
        @"Cq0gcJKq9sRJe1EPx/dOR+3DXdedZyR742LUq5TBB448Hy1R19pZAcnclwb1zO8s3PwehNrHVLyDelTtJ1CMbRWPnaH2Yh7viUKZOZX3nBovWln3"
        @"IECa9lJgWkuNB9+rWWOLVy/JLgOAL18Dnhh8jPQC6V1P+cYJGR/gCOOLG9keFUa9yonFUZEfDVNL2oE0ig9SK7xtNr0QjQ39Zutxsx15LQD8UzUC"
        @"Xr6Xhbuizhf+ssm7rW987X++E5vqxJdKDsR3mxCTV5z6l753s1yQ2WZqKrj0eY+Im3ahajKBrczF9cbliJn5BTbOjbByOwvXv5e77v3lT8jWrt+p"
        @"RNATYRCP9fBLCEcSxZTD0VI7Spada6zClRLk5TgrinyiUOwRSumiKFZanXb2ckDz5cEuSZL54Xi0kqbtQzhBrWudJMm+JG1lZV3G3lu6nfQo3qNQ"
        @"jLXFqN6nb93/45+Ip/dTmg5KpY9Z71ZlKLX3jiQMMuW9ls4Cru+E63khM8/3P612l60P6WW2ydRsXKWg1+8cKbTOgiBcEYA3da8qiyWt9eFAhfEm"
        @"56CqKuI4vrTeJgHhGgbwg932Wy2+zTR5a6l6yabc8hYLf3PkV/jL8AL/Gn47W4J5/nJ8378yzfff5RGstLBJF/IC5dVEG85uQgsaoDaGMGjceYwx"
        @"OGsIQp/Ueowwkrye5Yab3sOt+//FY1ru+LiP231TVivSO4SwCNFo/KkwXa5to6EoAol3NYGSWz1zoSahxQuwDvUqOKYXYJQH7/C+WAsCiXW+6V/E"
        @"Liv8+LD3jkiE2juHKUsCqRryVW1wKGyy41PJjv0fvbi6ShUkh6wXWtTVUqcdL4/HI61onIXwrRWEw3nZ2Igrvdwo5vhX7bb8faXWlc/Dg6w2g2/z"
        @"OzYhWVkBUuOa16CZwJUgwkyqMKudBJzeFFMNgoC6rpFSbnFDrmEA/0RB4MqN9vI02b/q3PSluerX/tv99+2llBNL88mCEx5PjVSQtCJkoBgOh/Nh"
        @"oIiUxFo7X1ZQ6Ije9K3sP/A+CHd8oqaTDUbj1TgN5xEWMJf9vQonJF5MuAQvy5T8RPXo5SXOpTn6S8+5ef2ae/PnnLQ4abd+NhCSOAhRCITzuLom"
        @"ilusbpQrB+56h2hNLVCJcFkIpQMhB66u6CRxYxUuQ0A1JRyqybZk3QCm3ydPnK11cNns/aXP263nKCctY+mCpjzYzPx4fV+Sa9f352X0l8BKP9mg"
        @"TdLi8N6gdY7zmk43XsuLjSVrx0txHB9GzVHUs3T61yPCzufG2ixbPEk7YVRkOGG26l+PmDyumJh5ytc0CfkPuay1WGspyxLnHHEcU1UVMzMzONco"
        @"HgVBNBiPxw+0Wi2cc1sEmqqqrgg8VwSka4vvWgD40bguA638lcvaTzaQkB6pIFAea4v5JBK6342X/uqvvvTBl05r9u57O3fe/V4M6RfiVi/2QBCp"
        @"BY9JmgzAc+VIkrw0ffgDzlStbWYzOp0O1tqtdtna2toCwN133yNq47Kp6dmVbDzuOwtKhQRhfG1pXMMAXgcRdJMn4MVl6NpEGVBA2k3j8XisowDq"
        @"2sxj9EEnzZ6iGMeD4Zje3C0cuOtnMEx/wqre5y5mo37Y7lLm2WqSRNp53ZuAoplDXTrxtwhGP9ir3W5v8eK99+R5TrvdJgzD5TCQ1FWN9z4ejEar"
        @"raS9JoSirGqCUKJUsMXxfzmu8v3icVy7rmUA/3wuv0Ur2jqZx+NCCyEIw6b33Urjw0kYnLRGHzS1pzN1IzaY+2jpOp+tXLyWdqeWk7S1X0qpmWj4"
        @"i+8Cgv1TXEVRbKHknU4nllIyGo0wxpCXBSqIUEGkwyBe07UBqQiCgOFwtPj3DfNcu64FgB+BAqDprW8if36rJGjuMIqJ4xZFoWNr7YKtzR5n7YJC"
        @"6Djp8bYHfvLDTk0/6lXvsDYCi4iHw+EyzmHrutc4zapsS2ByUgRwWSfkB331+/39SinyPNdKNaafcRwjUNTWMcqLRRk0af84b/wCZ2dnB5dTabd4"
        @"XoC4tmyuBYAf/WygAeis9ZS6Ik07Wqlw2RjXw8vs6aeP/GoYpzjZfjSvg2VtPUnaXjLG6DAMdRzHKBFkwiukDxBeIC6zkWoYjPzAbaWa03x4VEq5"
        @"RZGt65q6rgnDEIGi151aKcpqwqFvk+c5VVVlrwcu/bUA8Lq/3Mvul7UrvScMY/KxxrtAh2HnS9ap1UGmmZvfiRUqc0KiwgBt9LJSDSvS1hblwwnV"
        @"VSF8sHWSyq0egPveNOXvRxy7bE7fe4+1FinlFlHGCYE2hiAI8R7quiaO4y2Bj8tboohrFf+1APCjWfa//LNbY8ZJ1JrXRRWnnd6ic1DXDmRyqJX2"
        @"2b//zsRPhmKcuBREJGzV/sKJCQtykjqLZpLwUvC5dl27XkMJe9WdgX7oX8FXin9sugU5GnWjzdMzDhUKh600YUBsnNXNoI6cbHKJ9GLroNxyk7ki"
        @"4GzW/xMHJCGvGkAIl7chmw/kFX/7pQ+unf3XMoAf0QJAvuIcFpN5f4kjiYIttdvxeBwXpcZLhXVS69r23GWtPDn5OYS/LFueuAxN7leAf/7aW3jt"
        @"uhYArtrp1xBy5BXioU2522zmqioxVUkQyF7a6WiHRwQKIzxJJ802z86XvxFe+ku38Hhpm3tr0jDgnxONY9N6bYto/F1q/k0KrvsnIDFdu64FgH8S"
        @"EMBtNrcub9Mx0RnwjjgOGI0zPc6Hvd701FKuSwye4biIrxAV9a9M970wOGlwYnJPvs9vjlL/kDbVvg+T3Neu78N1jQn42gAA3FYNbl4RWR0OpSAI"
        @"Jalq6doavZFtZCqURHEcI4W+tPl5Za2/ZTTqAddwAnCNnp8LJljD1RaudJdDAN8D6JdXbP7LpJWuLaNrGcAPcwawOU4sX7kxhMPbxv24asoAUCAC"
        @"xagYNSNzW7vnlRQZd0mjoOdEM1fffObloqM/PCXTteuf1/X/AxNqxsWWEulBAAAAAElFTkSuQmCC");
    NSData *data = [[NSData alloc] initWithBase64EncodedString:encoded options:0];
    UIImage *result = data ? [UIImage imageWithData:data] : nil;
    if (result) {
        CGSize size = result.size;
        UIGraphicsBeginImageContextWithOptions(size, NO, result.scale);
        CGFloat scale = 1.14;
        CGRect rect = CGRectMake((size.width - size.width * scale) * 0.5, (size.height - size.height * scale) * 0.5, size.width * scale, size.height * scale);
        [result drawInRect:rect];
        UIImage *enlarged = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        if (enlarged) result = enlarged;
    }
    if (legacy) normal = result; else bright = result;
    return result;
}

static BOOL ZLegacyCounterSelected(void) { return [[NSUserDefaults standardUserDefaults] boolForKey:OX_NS("counter_legacy_icons")]; }
static UIImage *ZLegacyCounterIcon(NSInteger index) {
 if (index == Zshield5e2026) return ZShieldUserIcon(YES);
 NSInteger slot = index == Z700020a485 ? 0 : index == Z124338f2d8 ? 1 : index == Z94881eb8d3 ? 2 : index == Z646dcbe562 ? 3 : index == Z2f0c1a9d77 ? 4 : index == Z87f6d0c11d ? 5 : index == Z5d92a7e4c1 ? 6 : -1;
 if (slot < 0) return nil;
 static NSMutableDictionary *cache = nil; static dispatch_once_t once; dispatch_once(&once, ^{ cache = [NSMutableDictionary dictionary]; });
 UIImage *img = cache[@(slot)]; if (img) return img;
 NSString *encoded = nil;
 switch (slot) {
 case 0: encoded =
 @"iVBORw0KGgoAAAANSUhEUgAAAHAAAABwCAYAAADG4PRLAAABWGlDQ1BJQ0MgUHJvZmlsZQAAeJx9kLFLw1AQxr9WpaB1EB0cHDKJQ5SSCro4tBVEcQhVweqUvqapkMZHkiIFN/+Bgv+BCs5uFoc6OjgIopPo5uSk"
 @"4KLleS+JpCJ6j+N+fO+74zggOW5wbvcDqDu+W1zKK5ulLSX1jAS9IAzm8Zyur0r+rj/j/T703k7LWb///43Biukxqp+UGcZdH0ioxPqezyXvE4+5tBRxS7IV8onkcsjngWe9WCC+JlZYzagQvxCr5R7d6uG63WDR"
 @"DnL7tOlsrMk5lBNYxA48cNgw0IQCHdk//LOBv4BdcjfhUp+FGnzqyZEiJ5jEy3DAMAOVWEOGUpN3ju53F91PjbWDJ2ChI4S4iLWVDnA2Rydrx9rUPDAyBFy1ueEagdRHmaxWgddTYLgEjN5Qz7ZXzWrh9uk8MPAo"
 @"xNskkDoEui0hPo6E6B5T8wNw6XwBA6diE8HYWhMAAEKKSURBVHja1b15jGX5dd/3Ob/fvffttVd1V/f0NkvPSnI4JEVSlDSULIkULSG2pAQmktiWAklB5CCBIgeI/5EZwEkQRP4jsOANsGzACZ0YIhBbsVZaHFLU"
 @"kOLMkDOc4cx0z9L7Wsurt913l9/v5I9731ZVvVRPD+UU8Hp59d59795zz/Y933OORBICoCgeUFVGPyqT/4vIzO9Gz7HrPeU7y8fsa/e+7s4/MnXEg75Hyn/p1Ltl/NvbH9sAIsrur1yeMqoyfsKrlkcbHdEf/DxF"
 @"xkfwgIrHAFYFEcHgEQUjgiBYK1gMwbTwdv/MCPMWF/9uhXIvwnsvP7OCkv2/Uymo3UIcP3egr6y7botbvUr3/Z6qiuy+9aV8vZbPSfm3Kt4rImAFM6Np3PUdrwfUiwPejeWtLveosXKX75S7fU6Kh05dXRHB3MGy"
 @"jAQmyB7h7RakzFzRqfPX8rN3v0PAipg9X8CXHz26iNPm8iAi3v3evce48+tlfGq3ft3oRM0tLsqdHruFt/s5I/v8XkDQ8acIoCK3vC6z5yD73jUG8Ltsh5HJ542f1eKOEhXs7oujMi0cvSeB3S8tnDHhtxP0+AJN"
 @"BG6Qwo9RXOg7ClAmF5G7EbpMXMPIf42e1qkX6t1ePRl9Sy20tRSciJm1d+WdOjo3K1P3re6x0fp9Fdi06eSuPAq7BHhrLZoOQPY3uXv/ltt8vswcU8vLPq0E9+K3zR6ze0tPa4pXBLcW3vf/594DndsLfeS7bnf4"
 @"6YBGbuU2ZHcIoHjd/8a4V0vDVCw6fVt4ATOlzsVblEBl+uLdKTB5b6Hynb/87T9Z9xGOjv6Uwjfs59PQidmb/rhR2OBKe2QcBOV7XOnjDIIqeKOoKS2YgvrJ91EFFd0Th44+69bp1u5z8bcMFUWn4gj1iAc1lGmE"
 @"6v+vNG7GtMjoouq+t9r0LTe6CL60NoWfDBHvUDy2EFcZwCliiuPKSFiuDCCAvAwL/Uhseu+m805px8z5lufpBSxMTOh/CD9yj78XnRWrlBfVjkMbnY3sysvigUxGV97ijMejWFFCLV5nRDB2lIsJHkHFYHBjqfnR"
 @"8UtZetmrRfIebmIdR7t7s81gf0P1/gYr+33xkUbsp2lS/n4/Py1TZqowoZOI0zAyg1OCLSNDpyDiS80r0ndVjylyKyKxRGKXnWFTxEfO56loEeZ7mWijEZ2Y0X2untxXbdx7PLvXM9853rtfEer+eVghtgIy0j3R"
 @"oe6BvIpkeuT/TCkwWwrCGMEKGFM8Z6Q4NihGCy2FEDBjuMp7UO8RXExkMVFgA2sWAlgwkArqZJcJl32i0OngRg94k8/muHsjbCOFnQnuFaO8V22T26QBu0N4nf7yMglIdCbULm7/MicaC9OIFsIaCdTQtLCMQu71"
 @"qjWSZk5xCLkRxOesWk6cWKyfW15qEdWbdOM+5zc3/9bWIP4tgyUy4WmMI8nzVzMjmyML4EY308jH6kTTRwiMKf++mys9xp9vo4U6RofEvm9R6N0IcGwmp8Dc2QRZZkyo11lTaspjWBQrgjUQyMh/QQDLAbIeCOtG"
 @"aIHiVDZzx9VM9VyMpglwKDDP/MxDR158ZrnBkcU55o+uo+uHOT/Mef6t87zwylkuXrz2aK7+CoGgmabO+VSB3BXBjNfi+2Vj7ZPCU6qOBakHuF63ggVHN6Uxe0zo3VpihSmcY6Lyt059J37JjE/CAhZbPFe+QMZm"
 @"TwnEEBjBmKBEJRQvZuzlzHTCKyFqwFiwBkIhCkUeqIg8FRpORkYerlj7eCjmmDGmJRAZNS0Hl/DKX3lw+cqPL7SobfZY6A+ZH3ZYDwNOnzrBxz/6DD/8g5+ktdT6r89fvdbcvtn9N0FgasbaSJxLrYIrDb43E9/s"
 @"S1xF74Qk3SmRlLGdHkcFIoX7kFkE8SAAtbmNpu1TTpqOAUVLHyQEWATFmSIjtiYoMiLn8T4v7jQEE0SoCclw5HleGoBSgFYIjCEQCAUiI0SwbsS3IvzpOu7ZirG/HhhBvJKrkjn320NvX9xK+a2HGkZ/9amHaW1s"
 @"ERrLwlyVlQcWaD36IGIqbN7o0FxapfrQKd7Mc/7lH/4hv/vVb664odk0PmimmvRSUdSB8YYMxZVZnb8NiH237mvGH+oIQtPS8txznHQ7oPs2rx4BB2IwYks99sUXMoZUIVND1Jzn8AOn/t6R4w9+uT43Hw1zXh4k"
 @"eazqsRQPATABGEU0xTiw3hAaS2j0ZBD4tcBwpCrh/1oJAqqmEG5gDEbkw6nna+rd4LPHD/3KoxLhk5haXai3QhaPHqFy5DBsdQmuXkcvX6Tz9lnmyPnhH/oYzdWF//7NN97e2En919UKxpfJ9chsjh9yV4K5awGO"
 @"MFAjI7dzOw2Uew5WbqmBYyjfYkQIvMegiBFSLKvHTv3qMx//1D944umPsrZ+jGqtQa/b5dzZs3zv5Rd549UXf3n76oV/alyKQ8kBCSrUq3WiqLquTlM37G9GbkArdM82K8FPV03l12tGqeExCqkaEjVs9+PfWK/q"
 @"F37+keMsdWIiIyy0DCuHljly+gm0EpC8c5Gg1yXwjjT1XEsyNhoN5j/xDL/3ynf5h3/wjdYwC3o155dj/GbfCFJUxnH3UQNHrzNSJFu2rFvcQYDmNof196Svdgzlh1hVrHgQSy4VPvHpH9Nf/K9+lUef/DA7iefa"
 @"Zpd2L8YjVIIQsoRr58/w9S//Ht967sufHg7j54+eOpE8+fTHOX7ycWoLcwzzlEvvvMnZF/+UrXferATDzvpKxG8s18NfaIgnKAW4k0MyGPDjR5d5slYhihOWoirVecvy6ZMsP/wQ/tomeuUGdhCTZSnDTNkYeM52"
 @"+8Q1x9qTJ/gnL73O1890pEIl6tlhOhSwrsgLPeBFxkXZOwnwbiA3KUtMtkRovm9IzHRKLghGpbiLDAy88KFPPKuf/6X/lpOPPkW1uUjsu9RrVeLUsd3ts9MdUgkqHD39YX7m0AnCxuGvVCoVfvDTP8Lc0iFs1CAX"
 @"8KKcfvoT/MAP/QSXzryeXHj1W2ydfYnuxlUCTbDWE1qBJCUA0hRuJjkr1QoShUSNBpWVZVLNCLo7aJ6R5MogV24kCRfaMe3EMxz0CM+eZ8UEWCARn+YCoZMyqT94anYv6dwdfKDcIRo9SMI+QtUL12vFEBglF2Xx"
 @"6Km/8flf/rW/0lo9RrvTJbQWnw6Zq4esLc6xONegGgiaDcmHMeffvcDmVpdDR09w/JEnyVXxboimGaQ5OKXeaHHk4Yd59MMf55EPfIK5pTXiwZBut093kNDPHJ3M/63r/cHnOgn0TYrUPIePrLP8wGHY2Sbb3CRP"
 @"ctwgYRCnXOj3uDDo03UeqVTBhvzZ5S2uJPqFUAoYDg3LdKFMd+TgPnC/stoM0CHT6dNthCJiblmnu60Ap1KC6VBYyvKyEbBGcTYgtU0++/N/4zsff/YzbO7EDDPl+mabqze3uHazzWa7B2JYmJ/jxLF1rl25zPN/"
 @"+nXaN7fxKhx/8CSVSkQ1EI4fXuLwcp1aqKh60kyRoMLc8grHHvsADzz5NOHyGlu9ATeu3/h8kGWHDtejH59vVkAThtkQMYbQe6QzwMYZWZIyGAy5mSScjQfccDlGoVWpcnbo+MZG5yO5ylWDJxHwKlOwH/txIW4b"
 @"vNzJL5oRvltm88HtBLEfC+2u1Hwffo+MqQCmQEhMQOwNJx77kD77l36aJIMkzQnCEGMsmCqZV+JBxsbONVq1kBPHDnPm7Fk62228N7SaDWrVCCsxDz9wiMNrK3iXw+oCcZLRHcTs9Lr0koQ4MYSHHuaDnz3FQ0//"
 @"EK/9+Z988cI3v8rKtQucaBiORp75QDDDnFe//QZhELJer9OwIS4LuNaL2RjkOIWqtThjOLuxxcDxkoiQjyXmJxdA7nfdc+/P++oDR2jKNAZkEEQNjoBKbW7503/pp5hfXOP8ta1SyK4sWBaVADEWI4YgqvDmG2/x"
 @"+mtvoghJGjO32MS7lEMrdZoN4cyZsyQJ1BsNFhZaLC/VWVmtkQw9250hN7dj2jsJsrDO0z/1eU5/7Efpv/Ythm88T/vKGzRtxkJjjrA2x7mrN3h76xr1qMpS2KSXWtI0QI0nq1W4Nky51B/+b2DwUETDuo8VGxU7"
 @"9P0pFdhpROX2dJ/b+8BbUiJGQHP5vMETBCFJLpz+4EcHf+Wv/QJDF9Du9gitKdF9GYO1WpqkMAx558xbvPvW26RJig1DTj/xGKtri6wfPszFq5tsdBJiDegMHTuDmO4gBQ9z1Soriy0W50JCm5MmMYM4hWiOheOP"
 @"sP7Yk1QOHWLLw81un0E8wOU57Vx5u9/hbL/LNXEMgVAEW4v43s6At+LsR70xzpcF4OmromNQe8JvuauS2R1yQ5kyoQLvJZE/SBAjJVFHsaZkXlUa/Mx/8tf/7mMf+jgXr23gvR9XCXQscMGrJwoj0njIKy99m057"
 @"mzgesH78OA8/8iDHHjiCOsP2TgwmGCfRYFAXEA8zdvpdhklGGEUsNJvMt5rUKgHqM1KnSGOOxvHHWTj9Ycz6ca7mKec2btLfGRCLYccr7wwH/3hzmH101QYEQcgL293f2EL/vSkhtLwsV+1OxBTZEwu8t2h+IkAj"
 @"+yAx05q0+3EvApzhihkhsJYk95x67EP6H/21X6SXWTa2OlgxiPezpB4pyjqVSpWbV6/yxquvkg4GiDE8+oGnOP7QKdZWltna2EBVSvObgc8RLQBfLzBEGSTCzk7CTifGY2jNN1lcalKrW7wqwxQ0bNFcO8nhR56m"
 @"/sCD7GDY7CSk7ZSdNP23ae5/d63V+sz1bMgb/eTHnDXgC0jQC+Qolt1MtF1Q9G0iTABjzG2t2qwG7pMH3i8HK7tqyIpiMag31GotPv1jn6XaWOCtK21yJ1jvkaDAD0dlGVXFGoNLEy5cOEcyHJDGMUeOH2ft8CEW"
 @"llbo92NSl6JhCGpQZ8oqOSSaEThH6AMkyHECeZ4zSAZstQ2NRpXFVoPV+XkGcZ/2zpBOZ0huWyw88SN8+NQHOX7lbS6/8E3ib37lC/mVywwl5Myg/RtJWCBJ6h2iHoPBWSFwe0u6IlpgwDqVHYrsy7JS1bEM7kYW"
 @"d2lCDyZUgxkb6YKhWZysCZTMC4984GP6M5//L9gZWrY2OuAVNVqC3KDGlH5DiIKQzvYOb7z8Ct32Jl6ERz/wAY4/9BBLy4v0ujtFXUWCwl+qmZgpKQADweHVlRBz8bxTIUkSBnGMU09rrsXi8jyNVhWvKd04pk8d"
 @"u3SII09+iJNPfpjWymF6Hs5vbn6hF8fnRTzGQo4lUzMxoDJ1E4tgRtxOobAMM1WF2cd+yMxuhTAlI1wOFoXqgURY/BQeyZQ5peIIqnV+4Ef+EtX5Nd5+8zIudwRGyEzBU0EDvEjBZzEFqnH+3XO0N7cYxkMOPXCc"
 @"9WPHWFxcJE0SkjynWqmALxJcNYr3BQtJvEEt5CUxqRCmloVQj7UWNdDtJQwHN6nVIubnmpx8YJ2VpZjrNztsbO3QHaRUV4/zwb98ksef/SlOvf7dr/zZV36f1197odLr3EyFohHF+MKCTJvR0qHjpyoJIwLUwbkN"
 @"useyvU9phC8+RkeidBgJyBwcf+S0PvXhT9DuDOgPhpjywuOKgqizbnxioTF02m0unr/AMBligpATp06xtLxMrV6jN+gS2KC8SH4SI+jEl3pviuDIlL5VCnZa8bsyBg8MXpTeIKHbj7FByFyzwbHVeQ4ttrjZ7nDt"
 @"5hbdJCNqLPPYD/0UJ5/+OG++8mLyred+n9df+prEvS2sgFODlJ1FjCA178eJ8JhqOAOPTgdud3JN5vuTBxbW0CB4AinYXEFY5+mPPUtr6ShvXbhO7hSrlK+xOC0QlEAoWCfWc/HcOXa2NkjSlMPrhzly9CgL8ws4"
 @"73CZoxIGt/Thxb89TstCshT+SEWL/6tHVXBewRiMDVCvDFNP92aba0Zo1RvMLy6ysLRAZ6fL9naHON7GVCM+9IlP89jjz/Ctr/87/d3f+Wcf2Llx5dVALGg2aU8b5cM6sUnvwTvNUvrfLzB7xGUcwz7W4NWwdvjE"
 @"3/vQx36YXuLZaffLu9AXVIS86JVyWjDFQhPS2W5z8dy7ZEmMDQKOnjjJ4soy9Wad/nAIYkbKVhSByxugCARGd7RijBRpijEzpKMxZqkG78F5X1bQDWINiVeGOx12um3mG1VWFxY4sjTH9vYWN7Y26cSONGry1A/9"
 @"NFc2N777J//P/ykmizESluRbD+rxwsSETtlN2VXT2cPUu1WQM5WNmPcJg5mKwApKWKaGJz708b+zdvQU129s4VwRvak6VB3e5XjnCjOaOdR5rly8SHt7k3Q4YGlxgbX1dRaWllEgT1ICYwvhe3BOcbknzzwuV7wr"
 @"Hs4ruffj6E5LlMejRVtdKWSvDlUPWjxv1FMVRyUozqHbjzl/9RobnT7zSys8/sgpjh1dpdPvsdFNOXH6Y1TnDv1a4hWxAYENsdZgjcGKTFgR9xmKua8CnERTI36mYMSSO09zbvHEBz/8ceLU0+32Cp6/evzo4ZQ8"
 @"d2RZjjFCZ6fD5UuXSIZDrDGcPHWSldU1qrU6g8EA7z3qPargnCfPHXnucM7PPNR7vFec+uI9qmV3bWkfxKNGQQo2NuJLyq8vfanBmRCN6jhTYbPT552Ll0lzQ71Ro9O+yWCnx2LzEKceeuo3o+ZCFIQVnPeIFHmv"
 @"tQXvZ/r+nsa4R9bqoDqiqrcHs29rqPcB9grsk6lCh4Lx5Llw+qEnzx1/5AmubW6TJCmBgPHFXa8ITim0xoMGETevXaXX3iRLYg4dWufwA8doLczhvGM4TDDGkuYOIwVa40tBjbpYpPR3Rk1xcURQI6Xp0nGIP754"
 @"U1GhwZf4pS0jVsV5V0SaNiDPPXGW89Y7V9ja7FGrzlOr13j2s3+VH//sjydZf4sz3/0O33vpzz+9ff3SczYwUPJxxjCF7mKMi4BOqvd6J4JveQME9+xN9dbBi0jhR4wUzdthdZ5nPvYsptKivXOp6CkozZWU//aq"
 @"OFUCG5D0+9y4fIlk0EEEjp48RWthkUq1Qr/fx7si+PBlE6qqx3mHd4po2RRZoryqWjSiCOM8cxyGq5bMttkcbESw05JXOjKripJ7JQwCRIS33zrHzk6MBA16G9dYX5njU5/4NMM85RM/+jnOv/7KV37v3/xrXvjG"
 @"c+LSIdZY8PktrpveNYVFJ9kJ5u7B6wNU3UULlrMIuVoWVg7/2olHHqfdG5IkacFDGyuL4D2leROsUTauXaKzdY0kjllcWmb10Dq1Zos8y0nTtOBeugznCoZanufkWWFCM5eTO1f405FWjks8OkPXH93Fuh8hXkBM"
 @"kQcV3FmDNRafJ7QaVa5e3eDs2XfIhn0GnS02r19idalFEve4sbXDQCqcevpT/NLf/h/5q3/zV7W6sHoiVWbbfd9DMDpKMYO91Xd9D8IbVR9K4qlApkK1tfybW92EWjgsAgifl1oq48YN7z0mEJJBn5tXLjDs7SDA"
 @"+tHj1FoLRFGVJE7wqvgRYqO+fK+b8m+KlwKnLy78LLxcmNaiUI1MNUjvS9z0JWW41FnnsAaq1Qp/+vKfc+P6Jitr62xev8yJE4f56EeewZBhawN2ujEb3ZggrPLZn//PEPHn/u/f/kfikz7GKup1T2T5Fx7EzHpp"
 @"wCtiAprzS1y6fJ1Bf0CtEuJL3zcS/ch0BUbY3rhBZ3uD4TBmYWmVxdXDVOtNnFeSNMNpEXHmzhd/566IQJ2S54UP9Vo0r4ys0pjRZaQMVihtT9lN4aUIbNRMHgVXbtzWbBDU57QaTTo7XV757vcQYxjGfdI05qmn"
 @"nmC7vcO161tUxbG+PMfRQ2t49QySjB/9zE/z4OMf0tw7RnMJxo+7VJv9OnbN/vzpe9S+UhhaArWiDmst1XqT9vY2Z177Lj4d0qhWsMbgvZbaU7wuT4e0b15lOOihWA4fP0VtfokgjBgMYjI/EpzHlRFnXj5caS6L"
 @"gsaoD1DHflJmGgXLBhcpqgj7PgAlmPStl02Czfo8r73yJjdublKtVtna2uDI0cM0mi3eePs8Z89f5Xtn3ubdc+dJhjEPrB+hUqnSWlzlY5/6NEFURdWXs194z23Zwd5wcrq1RO9aeLMKON2Xp6gvoKXNqxcZdLc4"
 @"evwkC8urRNWoTAMcYRRy9fwVujvbJMOExdVDLKwdpdpYwOWOJB0SRhG5d+NPnSTiWvo6CMTsQwKaPMxImLdhD4wQmuL/HpEiyq3V6sS9IS+/9ApRVCXLMkTgscdOs93pEKdgwgYZnkE3Z7NzkaXFFofXV6lGAQ89"
 @"9hTN1lzU27qZ3mnsyD1RKsYN+3obJS6jNZkKd2e6isrIQEd3sVOs8xjJkUjoD2LeeO11mvMXWFxaZq61QKPRpNftsH39KlmaoEGVwyceoTW/RK1WY5jERT+6y5l1VzIWXtmpgxid6jkwhdmcqmDP1td8gYvKJChg"
 @"xAJQBe8KBrkBzTOazSrf/c4bXL3WptVsst1tc/LBE8wtrnFzs43aEJPnYC2hFP0cN7c7pLnj9CMnmJ+fw1i7LHDVllfQz0CP02Zyv3ETuquHC4K946T0rnRu990zhs3K+FbFFUL0nmFvh0MVw3ZsCIgAR7+9Ta+9"
 @"hTURoY1AFSsZaZqxtHaEtSPHaDQaqOYM05RqFOCdAyNTbC8dx9QiZipZVowxGFOUssQwk+dN8lgpW6RlxheP04kSjHYOqjbEDVO+/Z1XMLZS3JjG8sijj9KPM5JMSoObYrD4EfU/iGj3EtrtDlaUsrHmagF8l9dK"
 @"b5FY75f/7fq3Ablrjv7d5iiCx2qZk2nOlctv/1wet1moNlGXICYnrFQIohpiLJlL8eQkaYpTwwPHTlCt1qk1GgyTBEzRb5CrkHvBecG5EfapExNpCuq5MRM65CjSZJTMj3PD4v2+1OBRFOu8x43+Ls1zmqTUGy3e"
 @"fvc8Fy9dpVqr0Y/7HDmyzsrKCr1eF2sLczs6VnFccL44fp47BvEA7/IrIjK+96aih3tCvcx0Bfi+SlEN4gvybmf74pe++9Jz/5hhm1Y9xIsndwpqMTagUq0QRgHtTo+VtSPUW/O0d7oEgcW5HOeysal05cPr3okT"
 @"IiBmlCbs5ZGMuucnplJnHuNUxBdWyXkldw4jhixTXvrOa6V59Tj1PPTwwyRJTu4dMpVRqxYQntMiIhZjsAYunT/HcNDvBdaWvUuFHxTRe87CD5xGTN/xu8PbiX22KEFxeO+xmnL1wuv/5csvfvm/27xxntB4KtYW"
 @"/YHiCI0ni/sYG7B2+AGy1HHl8hU67R1Wl5awKFk6JHeuxDb9ZO6LFDwSMSPhMfGHUwFLAXr7GWFNa5/3vsRLRzdKmZ4kKa16g3ffvcDb716kUqmQxD0OHVpleWWVOB4ihrLNxqNe8F7LMlWB0VoR0kGfl1/4Bmk8"
 @"LAKtsov3Vino7So902be7CbO3BVv91aTC6dcbRGGuzGUZSRn89qZv/+9F/+9nH3lGwx3rtAKh0i6wcW3vs32lXc4cvgQUa1JrzcgT4Z8+8+/QfvGdY4fOsRCvQnOkaUZPi8EOfJlKrpvFqQoXj0OX5jMUljOuzId"
 @"cWPheV8A6sVzDvUFSC5acHleeuE7DIcJ3jvSpM+DD50EocBjjS2Ep37sz7wWg3p8nlOrhly+8DZnXn35l4NSQ2V0HXVviWJC6pKDRaH3StodFRdHH+rxiBQ9q0YLmgROMdah2TZbl7rSuXaO+YW5Z9WnZ3qdztUo"
 @"bC0fPvboRhH8OWrVKoNOh6/80R9x4vhxTj70IAtLS6S50o+H5LkrNS/AiE4YtFMahteiGiKuGIrjZQwaiyn7Z0X2AAqUPQ157plvNrl84SJn3jxLGFXp9zrMz9VYWVliEMeFdntfMAJUCtxV3XgQngfEe771/NfZ"
 @"vHbln1aNwef5hLmmt2e+34kNH8wK4k6OczLi6VZY3kQHi4TeqYxnrGjJ2LKS4/M27Y2t50IDtSBC0vZm3L0O4rFYxCuNSo1hOuDMmTd5652zrB85yoMPP8rS6iGwhiRLyfIECSy2nLFUQJ+uAHpdwdc03oB1iC3Q"
 @"FjWjXHXEkdkNJAseh8UTBSEvvvgSyWBAJYoYpENOnnocL5ZhkiA2GA+GKdrIPEYFNZ40y6lX62xcvchLzz+H+KSsPfp98+jpwQ7TUb4ZD5Xde9WDu6oTzZjOvUNghckwGlQLQpKaggMCqLjiC2hBcXIIRpQAKZjO"
 @"ClYy+ttXIO1jjJBqgUUGATTrDeJhn3fPvMaFt89y5IETPPLE4xw5cQyJLHGcoFkRNRqKeSLqi1lUxhfzswwGp4BR1JapRllqKgTox7xMEYu6jGajyrXrNzjzxts0KhWSQZdmq8Xy+gP04qyghOAnTUAoSA7OjjAg"
 @"6lHEC3/2Ta5deFNCI6jL8btStxElf+/gY50aaLlLKjKuB94fLug0TjdCSCYjj2crFZRg9zh0Vo8RiXauXfxI99o7LzYPnaQ9TBAU6yH0HqzBNCukSca7b7/O5csXeODECZ546gMcO3ECrQm9QY8sS3FOsDYohh6o"
 @"4MXjPQTW4NSV6c3om5nyCo5qmR5rihkyjVqD57/7DeLBgLm5OXa2e5w6/TiIJR4UNI9R3XF6YIExgnOGalQhT3p89zt/RjbsE9iAketWZkeGzFox3Q1s3dI62vs2S2jXzMxxj84uR2xMOSZDyzYzBGsEI1iXDy71"
 @"e1sbzdbC56r1BdQVFQDnhkVe5gVjLNVKDSPQ3tzm8oVLbF6/CSjzc3PUazWc92S5KzQOmcr3dVzJns4HVWfNl3eOVqPOsDfgq3/yHHghSVOCKOLhxx4v8lHnx4DBHj9lIM+Vpbk53nrtmzz/J18SsgFGi2DH73E9"
 @"kzx1X2LKPvzQe+qNuBPlXm+Rks5ikZOSmNUJ0ccILrB+eTjoPrdx48q/JUt+pVWpEFVCUtGibzMvKrWqBrEBUaUKHra2tjh/7m2uXb2K4Jmbn6dRq+OdJ03TotPJmPG0QilZaaOkUFVByi4HKczc6tIKr3znZc6c"
 @"eYswrNJudzhy/DjLq4eJ03xc5Zfd2KoouXdUwxqBT/njf/cvufbuK1+IAFWzz0RCGQdNs9ZM7tCqMCXAaT7+gUsQOisknTxRAscyHui9e7LtiF1sxxmwja2RZp62z+9svvuFztaVf+tc9ithtUEUVhB1qFdEAsQE"
 @"RcBipegpFNjZ2eLcu+9w5dJF1OUsLS4w12yCKGmaoH7EarbliK1SQ0eRM4J3Oc16HSvCn/z758iGOS4rcsaHH30UbyyZK49jZAoQKLmwBrxXWvUG77z5Il/5vf9DbD4o5+NMeGg6pX27LdXtBgKNBGhKhX1fxk2O"
 @"J6vLbIoj7J6hKePBcwW93mPU90Q8gXri7csvdbc3pTb/5lML68e/21w6TBTNk3uLEpbTkVw5pclSr1TJ84TN65e5cfUyb7z2XR5/6kOcOP0wS/NzDNOUJMvw3iNhRGDtmPZX9J4qOMfC/Byvv/Y6129sMdeYY6Nz"
 @"k8Prh2k06nSHKdgQ9QWHZ0xiLsED7yAIKvg85aVvfZU87lCVoKg5ipti3hc3tx8HKhN2wEGksUuAek+aKMi++yUmUeo+0xemsEBfkqFEfcF8NbbgZgpUNSHbufjqpf5VqdYXOHbopDYWT5EFixDVSMpkGe/KKrdQ"
 @"rVZQ72hvXufrX/lj3nz9VR5+7HFOPXya+YU5jChplpM7P2Ztg5IOM+YadbIk49svfhuRwvepKEceOFpUPcqr5Mjx3mKxBOrHKwLUCSuNKpfffY3zZ77zc1WjGFeQthC/q6dlbwKvt1I73d+o7iI16YHUbDL/S29b"
 @"I9SZOFR3xapMsbSKMY4IpIHHqMd4UGuKYGN7g/kooZJu0zaLyMIhqq1VMhOSe4fTAqERzRFRojAEhZ0bV/nmzQ3e/N6bPPr4aR57/BHW1lZxYujHMWmaYlAa1YiV5WXeefMsVy5eptacY2dnm6XVRZpzLfrDpBhW"
 @"rYoXX1YSivw2ECVVsEEF0ZRXX/wKyfaVL1XV4zxj2oZOpQDTCyJGbmZf0ereueCjS3rPUegI6T9ItX7aB+79fekdSnPmKSYfFaw1g/PCSs38xCMrlf88SLfJ403S3hZZvw8ebBBiRHDO450vTUOAWEsQWWwYMhzG"
 @"XLl4kfPvvE2n3aPeaLK4MEer0SAKQrIk59zb7/L888+TDBOMQH8Q8/CjTxBWG6SZ3zOdc+T/vBZlp4WFeTYvvslXfv9Lf9MNNl+26sbwmjI9ZXC6XeXurqPsCnFKEZh708B9Qtxb+VJhdnirzHTaTJq8vRT5mZSs"
 @"aVQYdcBWcTxzpK4PNKHfj8lthTiH3tDQofWPk8bKZjC//ndoLKM2Qp3D+LJxJQwIggqBCRHNybOUNPNUGg0OH1lhdXUN55X25jY7223SYUIUBSTDAaba4OmPfYrUQe4cdjQwW2wJThS+3itUw4j11UX+6Ev/iBee"
 @"+3+lLgnic7yXEsDQEmYcDQKS2+DJd1AELRCk+5YH3nZ0xq5kf/cc0Ol8aJrMkRuDM0V72PEmv/YDx+c+U1UlMFUCWyHUjIgM79KPDuPOH/d2Nn49H3bPhMJnqmGIDaNylloFJESMJTCWIDCElQpeHdsbm1y9co1k"
 @"mOCynCxN0TynEoX0ujusHznG4vIacZojxpS9fUUpTIqKYTHF1zkW5+rsXD/P1/7g//p03t8+H4ob926ozKqIPyClYneP7kgD71tzy+2WZO1HWfVlFV914p2NlmZGtKQ6GMR6Iq88dGT+Nw/N19GOYupVMoVe4rne"
 @"T+mqp6H5F2zaXh5ubb2U7Fz4uWzuSKu69vA/r86vYSND6iH3nkwgtAHgCWxAWG9hbUCj1sRlKb1hTLUSkQz79HodjDgC44lESfMUbwvgQSn8s2iBbYbWEGrCV7/+++xsXHmuYop6IlBGuVoixPuXbvUARV2dMrz2"
 @"/k51vrspCzOOWorxkyqjGZtl+kFQVNddzolm8KvPPnrkc8uSUzcZC3NVluYrtOoFlOUcpHmKOv9xQa4bXM0P+zu+s/HHJh98zoSGRqNFVG3iMbg8L4KjYnovUVSjUqkSxwOyJMalA65fv4QNLf1e0UW1tLREtRqB"
 @"FH0WruTMoIYgqrK8NM+lt7/Dn/7hvxbNBxjsOGjxIwDhNsK71W9375GSqXFl+2igHIxHfytNvAUerrdC4EcnipSjuAoWm3ghAj54dO4fHK8H0O1Rb9SotgKq9ZA1Z6kJaKa4NMDlSmJsFHhzpIb/Qst2SHdS3tm6"
 @"sRItXN5YeuAxGgtrSFglS3LSPAdTzKARKYBv41OuX7uChJZqtU6e57x95nW2Nm9y5PiDLKwdol6vlxGzICYiczmb1y7y8re+RtrfwtqCbDwas+x1mjihtwhPDjKvfPJccGfh3QP5+0AlZp2iPAQFlxQwUlTPl5ry"
 @"E0+dmCd0O2SBJazWWKhDY75CzYPGjpsNYadfkJ/yLPsF74tJv/P1GluxY9i5udnubsnNmxdoLR75Z8uHTvxCY2GNSrVKJYqohJ5++wrty2/R2b5JtbWCbS6SO0NkLQalu7XFm50utYVFFpZXaNVaSFChGw9xaZek"
 @"fZHL514/KXiML5eFTM/1LpoNJsVnpktzE/Rqvx7BInqfjAIWRnXPv5C9Ebp3jgpTG0kok2IjVJzj6WPzf3ioFZFvd6nWKzTrOQuNFguLy6TDLoSOZjWgXguoDQOaTohtzkLFUKlUuba1/Tcz9djAkA07tC/3f7F/"
 @"7fwvVhvN043Wwi9FUf3Xkzz57WFv6+9ng+1XVQ2H6nWtVQ7TTzyphygMi8YUaxn2elztx1wxdVSVKAo4vNLgnXfP0m+3zwdlx9P0IgnVybKRu29huYVm6Owx/sIXf4zNqipKMWJZbMErOdzg137gxCKVbEiKpVkx"
 @"tGowt7ZCa/UQNy7uIDhCESpWqQWGujWEVllqhFwZDLiRuH/hrUW9IwAikxNqAp2dM/2dS3+7L8HfFoHQ6nJF3OlcwivbV985ElbqV5rzh0m9kPtiur01QhRawjBCgzq1SsDqXIXzZ1/h/JlXK4EWLWh+1y4kHcMv"
 @"OoNAHWRjgI4ncE/d8PsXdO99XepBBGZ2BTN+QtVEMUTieOrkwm8+uNSgv3mTerXJfACtVpP5049hENxZR5Bb0JzAKxUxhCHMhVWC0HB+Z+dvJQQFP9W5gmJhhNCYdYHIWGmJcZHBtgQTucxvRoGcHsZbL914+wVZ"
 @"XH9U59eOoNUWzhgwBmsN1WpIpWrADXj95W/x1msvtCTbSY3JxgxxZlhw+4Nkd9NSvZfaO0v+DQ5CWrrfgtwDHUkRlVoPhxv87DMPrmKSlMgbWtUKtVrA/NFHWH30A9x863tkgwyXGfI8L1lnSjVQ1hZbvLXd58ZQ"
 @"f0uCIsxXr4QiRCZoWqfL1thlI7REXSRiotzJVafBpvHSikx2Oou3z90894ps37xworp0+FxtYZVaa4FB7rh+cQfvUrpb1/+Hzubl/8X6BCtZyQK4Z3DyAMqj42ba4C/OdGpZD5cp7gdYYwnyjA890Pqdh5fruBtt"
 @"mlGdVlWpLc+z/PiHCSsLDK5dI81SBiXxNnFKZoTlWkAQWc5tDRgqqC81j3KavdfTVdWPVMQ8VfiTIFWjqSPfdMKmGpMalZZVWTY+vTpoXz/fbt8UDSJM2Trt0oxi0YDDSjk22utu4hC6X93tPQtxEuX/BQUxdwiS"
 @"FZYqPPMDp9dokDNQR7NeoVmvMn/8KM2jR+leu8HgylXSLKeTZgzSlEHmMcay1Kpztr3DhW4qSIj4DFGoGENVOFF3+afnguA3I6t4FZw3OBw9/O9mQs+Q9YzaTUu4jDjCAHAZeZ7i8l6ZPBeVEmMA74tRRmJK86mT"
 @"5Vc6myLoAfLmu3Vjwd6D+XHoqvfQ83THD941O3PU/hWM6AnO8cSR2ouPrNaJN/vUbEalqoTNNVpHHkRMzvbb36PXGdCLcwb9nK2hMHSeuYphiOHlq/3f7qrBlvW3KlA3Zrnq848sBPY3F8OCipiUo0lyb0hVzmRA"
 @"WAQLqfUhFoeW22DUF3TEclhXQYwYsRl3kb1G3TI6KhLfqedBb88D3VOp0AkoGexKyXYd9H1ZiDcGrwsBmgm5VZX5UJsff+woobNs9QY0GwWmWV9oMd+o0716ke3LFxj0h2zHjp1BQj/1iMuZbzR5bXvI+W7+i1ZG"
 @"J2poiK7X8c+2hC8uVwPmCtUh02KyUs8KmmWJ94LkUOwN8ePomF0UfmV2j9Ptk6UDgiAHII/tk0a8t+DlbtTesHt3+9TuJK88djTqfvjoAr1rmyUBN8AEAVEjIu11aN84T7p9k0E/ZWcA28OcQeppVkJir3zncveX"
 @"OxQarUBdDA3jfrLm/SdXooCVKKSOghqcV1I15AWgWPGYHupR9Wlm/NXxYq2St2NlarmV3h1+4e+rm7ljh+79AbRv9+Mpiu5upH0lFupQ6gKffHiZlouJd3pUwiJ5NpUqzme0r15icOUy8U6X7sDRjj3dtOzwrVb4"
 @"3o0Bl/r5P/UCWbmfsyF+vSLmqTr8ynIUMm8tLWuZCyzzNqBphUYoRIbTDiUrVzvm+Bm6w6jMZXR3z/1sO6zuKgnJHfDhW00nvF0qIVM1xeAvIlqZIXdLWVjxcHI10McPL9K+sYVBqIQWG1mCSkSexSSdbbobbbZ7"
 @"Ke1eSjfOSDJPtWJpa8DLN5IfTEeggFoCPA0jPxmo/vpCGLIQRjRFqBhTLtIqXjsXeBat+bPruRdXEo39DANMJ72PjPa93yWSKLLH/9+PFGwkd/N9F6DOgrJGIVIK0PrEMgvWsNVNqDRqVENDtVkhqEXoMCZtb9Pr"
 @"5dwY5LTjlHgQ43Ol0WhyYafHtdQ/b0QIFCyOBkoIJyKvzIchc2KoG6VmoREYaoGlZi0LAkejgApFpQHAemZQj5GmjaZvTEfNU3Pqi6rKriL3dMnsfv98XwQ4yyGVcRRq8EUOpcqhZuXZDxxfI97po7ZGrV5hrlWl"
 @"Md+iUqtAnpEPM5LEMUgdvcQVjZfViL5T3tno/WBekgUVqKLMW/vXAjjSCA2tKKQmSt1IAbkFlkYQUjOWeSOcbNRpwWk/ZfZGdD8BrJpJf73cRdlst+bdxybaO5jQ+7tqfLriMDFAblSMRIFE4INHG195IBA67SGN"
 @"VpW5htJcmqO1tEZolb5zZD5A8gybDRkoGAlp1QNe2OpyPeH5kKKL1xml5mHOmC+G5CxYS90IkYGqMTSsIbCGXAVjLQmOI0HI0TB8cyPLxFF0OI6Kr0XztkRWNR2WreOmJPC48aum6Fq7Y4FR2rTPmOWZwE/1jrty"
 @"hGK7Nt9PE6oz/3LjDx4BsocqRB89tUY+GBBYaNVCWnMtmkurtJZWqUTVcqphXvT35UCWs9Cs4sMKF7bin3NT+4qMh4Y1n4yMUBWhGU5Wz1VCSy0KaQQRtQiqoRIRUQstj8/VWIBmKgarhqrKcuhpCh5vfOpNsTA5"
 @"8hMEaaINk776W/Gq5T76v9HD7I6fZh/3v4gkU1v1VAzGww8cbSQPL1RIhjGtesRcPaDaalFbXiNqzeM0x/scXFZU370lxLEy3+D6IGcz4UtGZDzTpQK0rP3ZQB0Na1gIAuoWKlaoWEMtCGhGIc2KpVUR6rZKgPLk"
 @"XJ1Ho7Cr6nFlthqgRyqiT4kpphoaINBZFo8ZL26+Nb3yblrZ73oPwBTA8n0T4G7XW1wDz0rE+g8+fIhaPiCKLK25Os25Fs2VNRrLa4gIg36fLMvIXU7qIM2URhRCYHl3s0dfJ5fLA1WBhpFfD5xnzlpaRmiIULdQ"
 @"Dy31akSjXmOh1mQxiJivCDURlozww6tzHBN+aWiUNJRNb0zXYparKs+EKpEp0xMZdTShBUNs5NdFJ2sW9s3cbpN6idxSErI7lShb2r4/QcyeINRgrSVQ5eljC1ceXpkniwfMzTdoLczTXF2jtX6MaqvFsLtNOuiT"
 @"JI4kcfRTT5pnNBpVNmPHpXbygxjGnQcANTEnamKoGKhbQ81CzQq1wFINLNVKRH2uQWtunsVGi7lqwEIYEHnP460qP7rS/Cdz3i2DxwS0MIZA7ZHImdMGU9I+Zi/e3W5m2Y/rcnecCDNJ5ku/+f0Ds3flP6Epxjyu"
 @"1fjkDz22RJgnuDBiYaFJY36e2uoD1A8dJ4/bJDs3SPsxSewYJEonzkE8lUaFi5cSdnJ9PgrLkc3lHRohpytAZCEKykKsMdRMQCUIqdQq1OZbBEFEWKngNhXNOvRCjzrHp9fXyJCNr97sfj4LOK/Wpk5l02KWLX45"
 @"MbqJn40I3ZSqzIyunGp/fe9xhJnSQHl/g5jZleKjsXJSrM4WxTjPhx9s/tnp5YhhZ4dGo0GjXqPammNubR1bbdDrdEg7O6SDmMEwp9dP6cRDwtCANVza7hf0RM+MyYrEnC60LaBiA4JySXJoDaExBGFIdX6exvoa"
 @"9SOHmFtcZa5aoRlBJQhYzj1/9cQRfvzY6hcbnp8Yev+it9IVo5ExvmnFl72NM3ox5ouZfelHB/eJ+xd0pRyS+75SKgyWotM8o9gNbnyOGC360zPP0+tV/eknjmF2eqgaAguow1aq1OpVXG+DeOMavW5CHHt6g5St"
 @"QcYgy1lqzXFzKFzpDX4OitVvRj2mzAND4WTLBlS9oylQwYzHiAVSDD6g1sSuHCacT6hiybIE2fRkmuKdoxEn/NyhRVZawRf+3eUbX7jczSqoYG2wHMD5gkPncEA6vkGLUZdSDpKdhGsyhtjkNkHL7QSquzBRX6Yc"
 @"748AxeN05O7LqU1SDCBYVOWHn1rWv/yRkzT7MdtdR6VmGQxj7LbH1q+zdbmJyxIGG9dI+gP6g4TeIGM7dgW9vVLj7KUu20P/JWV65WlxUqn4M5XIMOcsoZ0uqRadtZpnGJcTWUvUWKCSeRj00WyIdLZxWTEwvREP"
 @"+dGVFqcfWeHL124kX3/rxuc3trJ/BYY8CItxXi7D4kkIUIWKz8dY7wRJk0nL+T2zHUZTE8u88uCbW26POOzhd5QTKiLcmA25EAo//7ET+pNPHCK9eZWdzpCoVqNShUAgi2M2Lp6j19mmFgVoPGDYjxkMM7qxox1n"
 @"1KMqvczx+s3O/z6gbBbyReXNlqfZU/+71hqWTUC5saIYo6XlmMphQt7ewi8tEVRXqTSbVJYXqQx28NkQ8UNyPENJsRs5p1T41Y9+gM89K1/86hsXv/jCt9/l4pXkyI4zV721JRWyGGqwtx9yZr3HOH+cngVzd6ZU"
 @"9zXJwfsXs4zHnpMboYby0x85rp95cp3ehXfxiWNuvkGtZlmshtSqlULoeU68s02mDnGG7sDTSaA3LOaCNhpNzrc7XOkk/40XW9YOCoKDLR+p06vew1K1RpL3EVVyD0muZMaRDAbEW5tUWnNElQqRDQiqFSqNOnmt"
 @"AsMUdR7RAK+GwfUeg2++wZMfPsXHP/Uk7z66yguvXr/y+y9f5qWrfclEiMr9F1k56G6m26OYaYa+J0BUx7sYp2s775mVtu/rVLAUzGQvAepzPvbEkn7myRX6Fy9hgLkjdSr1ReaiBq0qSFWK5W1JhukL3XaPfj9h"
 @"JxbasdLNHFEAphLx7sVtBg5UfNEoNFmxjBEhV+VGPyZcXsL0UlLnyb1h6JTYeSppxrDbY3DzBi4IodXE5ynWGCIb4I3gMEROSCloFfkg58oLZ2hduopEcFIz/vozRzn81qb+wZubkppyWoX6caw4ntQ9NVJZyin7"
 @"96QYM4Rav3tq/Z35GnfPYZwQfESVE3Py7M9+/BS22yEdZBw6tkBr2VKvz1NvrVNdXEBDQ7Z9nWz7BjarYMKcOMtpD3J2+hndOGFtrkZiQt5pZ58f9RyI2mJWS8lvGOEiZ3uD33h7OPjC6UaTtLtDrsrQe+IM6iYn"
 @"HcQMNzcLnDNZKBLjJCdQgzEBueQ4k0Nux6vxcgl558KAi9t9Uh2ytGT43BOn6eVe/+StbclFyuBFxuWo+1Uul1vUBe3dCO7eq0aGQB2ffWrp3I+dXubKuxssLdZYWWow31yk1YqoHD7E8pOfYun4U2hvk3j7CkmS"
 @"kQxzegNPe5Cx1RmQqXJkZZHXru/wwrXBf1wI0IAGWAo6flHoEAKxJPjnhsP4755oNaioMswdqkWpKUILNhmKdQ6fezTL0XiIjxOSNC3GO2dKZiC1ig8qdFJ4d6PNdg5emmzvDIhMxonjhzhzeSPZyvjT3S1y+y3Y"
 @"VPTA13q6x9JMPWcmJIfJY7TZZPKQAwlZKKYHGnXUBB594BCDm9tollGtWsJAgWL9aZ4m+O4maWeDeNAjTYa4YUoSpwwSR5wpQ0/RKZTnvHpth76Ws8nxGDJyKSv85ZhkR9FG9kqcyx9v9OhRIVGlKxnD3NHLYDtX"
 @"BsOMYTcm227j2lu4QY9hnpBp2YpmFG9yAhSMZTNJGOCphUJkM6pRk6sXO9RyeGyp9j9biilQszTe0U7B4uHLtS37VS6E220zNlMpyeQ3wXvxf7fLA40WGGGrYZ9qVi0bG9tkuZIOhWQYYExO5roMswv0NzdQY8m6"
 @"bfI4IR4M6Q0SenFCL3XEzhMZoZNm9D2/rIz2tU8M9pjZjSt8T4mPvrTVXmlpvnG6XoN0QN8I4oUsL0Bvq0k5VTBFREhzVyzBKlfGGSAQIfeOYT4kigIiY8mdokFAOlT67R7H1+apXhkQex130M4gyro3+jyIW5p2"
 @"T9M0jfcpDxRsuWyxWpePRGR0ejnDWGj3hgShJU9NMb1QtjHWYqUQSpo6eoOU7iCnM/T0U88gK1b42EoFEwQtxuS+SYFYy6YYP4KzKC7iNmx+rd07WQmicydsjZ4mOONQB33xRJJBVlD/CvpgsbdXEKwqOYoEFlds"
 @"J6EZRQQY+jgy7zEIg26P5cPLtKrmk/HAPz/K/RhPhpE9U5cOriTTXUzmVqy0vWMk74XMMR0wq2iCKkkm9JOM7V6fTFO6kSWyBjGGwAZUrUWsMkxzOr2UndjRTT1x7sk8VMVQCQMEjYKpb+RK8EplUvJ0frIk2Ily"
 @"Qzn/9a325ysrS19clgDnMiKEoff0ATUZnqLcVHQNF63TosUwIkMB/1VCg6lYrBNS74tJvQj5MKNhhUogTwHPT1aQHyx60dv6wBnO51SPyS1Sg4kgJ0Ns7t7MFjmRA3a67l/d3ElwVugnKVsdx/XNnCubGVe2M250"
 @"HBt9x81BxlbfsdPPaQ8cnTgnzoqZZ6Ipc7UKHsMwdS8Go/tRFCeF0fTleOPR8BJfak9hCSznnP9XL7Y7DKTI7bLMk+VK7LW4SfK8WFtXHGQcspsyn63YgFoQUA8s1UCwUqYxYlBXIE6B0fVi71mJc+7i/6hwj9q3"
 @"T2dzqZHBXenTLcZM3jpf8eQEGKt0h8r5mwmPL0XkPqcbR/QTTyV0VCqGIFRqFUcUFiiFz6Az9HRTT5p7cCkN45lrNTk/GLI1dH9UTHcyM9Wy6Z21YwtSjnA05ezSc0kqjwyHulALSfKUgbUYD4E3ZM4TSbGNWkoS"
 @"0qjMaDEFf8YaJDBIAGaYFlvNEAITIGY0lmp6p8UERlOZtW73WhAvFEjvjlKx3/TYu85ZyrWrmQpnLm5TaUa05us4IzjJidMyUBkkdDsJ/Z2UnfaQrW5Ct5+RpgV9wgosNauE1Ygz17fpudFq5QI4MyoY7OwE+DKA"
 @"MkBmFW+UisIAuBEnWAJyY+jLiJ1dDlN3fpaRLoLBEIoQiqEahKg6gsBiTLFvwgHGFMPZs1zPFzD2JHKf5X3e/+LPfe2NGJlWLZdOGVfsc/jeRiJfO9vWT5xapXe9jfiA0ERkWUaaOtLUkw89+KK3IXE5xjmqJiQJ"
 @"LScPNdlSx5s30iNWwZlijxGqFIOd8nLcB+OJhKakLAZawFiFkVN66kgDIXS2mOxrp2dXl+OYRYoGFiAwvmhiIaMRGnb6Aza1iDZjHyF5wvpqizf7MVsx/8IQ4MvvM3U3T61cPeB6gX3840guZm9vxG4zKTMBze1G"
 @"iewJhMZjz6Gnhq+9sSVRaPQjxxaw3QE1MdSjOjk5vcTR6Xn6wxzymMAovlolGCrrrTkWVtf4o2+/xVacXx2lEJS7jOQWsdrYyZdQmy91tm6VyORYYgIBkbDY8Sserzm5OiwWNVpQ7gODrxrUQaARtbBJnAyJJGEx"
 @"GLD48BLJQp2vvHSJroOInHQPm+89zKI7iAbeWqvuvm5FWQec9lBeLG3n+aNXN6SbxPojTxxmMRCq6ZCKVFherBJnjp1eRtypM0g8vThmYS7nsSfX+YN3tnj+XCwq4ESKTqFdYznkljQ8ykWUECoshTUirZBqRqZa"
 @"7nZQTBQSRgFRIISBwYhBA6ASkonQz2Fbcm4kji0qpETML3muWPi9F87w+lYqmGLgz3TwPip3cV82Je09v30S+dLxjmp43h88wS9rf5RDwL0ImRjazvPl1/tysX3pn/3kM0d/4UMPLNK0OUHqqSawEFiGzSr91BP5"
 @"Ks3lFt/Y2OZ3XrnQajPaaCfj2STTYhxfHt1nlEf535bI6WOtBqu1gKC1xNy8pRn6QlgKXSckDoZZTjdJaaee7TRmM0lpZ4526thOcrqp/k9KkEQV/cKNND9yMzdXIwzGeVIsHrfL9r1/BDHZHcfIzBgM2ZtE3tVR"
 @"zXiDyQSbKQad+7ILaSmAp0609EOPzHP6UJUHFho0QkhF2BnA9Rs9vnV2iy+/ub2ykbKpKM7bSWpcov4Fv5syXZYxbG9Hn6nF56oq66H92f/0g8d/55GFKrlLiPOEjaGj04tp94Z0Uk8vUQa5p58qfa+/EXueT5Uz"
 @"HnoKiYdehjAc9QmaAE9ArZxI3y1ncMtoA9iuiJT36ANnJ/ZqudpwRruUyT6F2UF4d5+/yEz+P2GMFXNSAlMEGOqhamFtTv7GsbXqP5+fC8gSy3ZHOb/VffRaz5/Rcl2W9550GtuQYu62G5+On8mVpEy+rUpJdYA6"
 @"wmNLVQ1CpT0Y/raL2cwc51QktUaWjdAqNTtywmYMz6eqZxxsjmpDCmkKpALBaNrT1Ay4VHQPbKYzzDJ/oKBQJoZlsq2lzM3NtADLFIpim9nIbNqZ5Px2ApxJ9Mc4oB37xOJESpqFFBCUx4/XqUo56zUoSyQ5oLa4"
 @"A6wvUoZcXUlM8ONby43pUn485WJ00lYYb7kWNVQQajicKcpQDdVPGqNNim6lioiJVDUViFRJc++vZHDeI11VSQsIHvLRNdJiarCTvJwFUwRDskeA996uILO+bTK+ujy/XSb0/kRLs4ZiFsEZ3Z1jGq4oYgQrQWkU"
 @"cowWawImBdHdS9d05l7WcQuYTBkrGc/kFoplHAFCiMcYKSft6jri8dBVSBE7WgeXjjfAlBtJR+MhXfmJHo8S4AocaIqRU56i7g5bDmY+d8ccskuAZtL2ZvYHTO+SC3OQYu8sX3KmdlEiGX5Svdbb8392zx3bu3ul"
 @"nJLPKKmX8a4KQ7ngQykaNmUv18SrFhFvuePPq7J77aUv0yR2AdbT5u69cI3+gxPgrczDdPABdyJu7b/jcry3d9erxj0LOtvebXcJbHYQn4yBgekdGLu/lpuyAOP884DCu9XA3FtF/SO/OApi3tPyq/fCYptF1vWu"
 @"LPcYLJm8dY+B2m+A0EgQjvGuFtxUwUeYLcLKPmNBdJ//7wcciB501t9709T3ZWLv7Waf7C5Z7UXZd71ezIHZXIa9Oxh2b7KegAzFqGe/Sxh+pE2yi6C0R2izUz7v51CDO9kh4X0Y+HpgQQu3RFNEDAf9fpNj6p5j"
 @"TY8GGZtN2efmueNSRtkVWe6mGun7LLyJAP8//gVh1g0EqqoAAAAASUVORK5CYII="; break;
 case 1: encoded =
 @"iVBORw0KGgoAAAANSUhEUgAAAHAAAABwCAYAAADG4PRLAAABWGlDQ1BJQ0MgUHJvZmlsZQAAeJx9kLFLw1AQxr9WpaB1EB0cHDKJQ5SSCro4tBVEcQhVweqUvqapkMZHkiIFN/+Bgv+BCs5uFoc6OjgIopPo5uSk"
 @"4KLleS+JpCJ6j+N+fO+74zggOW5wbvcDqDu+W1zKK5ulLSX1jAS9IAzm8Zyur0r+rj/j/T703k7LWb///43Biukxqp+UGcZdH0ioxPqezyXvE4+5tBRxS7IV8onkcsjngWe9WCC+JlZYzagQvxCr5R7d6uG63WDR"
 @"DnL7tOlsrMk5lBNYxA48cNgw0IQCHdk//LOBv4BdcjfhUp+FGnzqyZEiJ5jEy3DAMAOVWEOGUpN3ju53F91PjbWDJ2ChI4S4iLWVDnA2Rydrx9rUPDAyBFy1ueEagdRHmaxWgddTYLgEjN5Qz7ZXzWrh9uk8MPAo"
 @"xNskkDoEui0hPo6E6B5T8wNw6XwBA6diE8HYWhMAAFtCSURBVHjaxf15kGXXfd8Jfs5yl7flvta+AwWgABAgAYEUzUUUKcmS3ZY0anlmwpTcY1ET46YnYjQT7XGELLkjbM/Y7elRyO2QeqIthReppy11q0nZFihK"
 @"sihxEQmQWAgChSqg9qzc8+13Ocv8ce57+bIqARTV45lEZADIl+/lvfec81u/3+9PKASC8OXF6L/Ae8+7fXn2X9//hPCKu+d3xX3/P/F3xD2/58X4k+//pPf+EtU93Hv97/TzB/rMybsT4f8P+xgBCDG6B3/gPpXw"
 @"E8+2+r1Drt2PXhRgnUcCavQ51WcIsX8/SlR/xlffD7Jg+4sg7lk8EELe90nikMUbXcDki/v3GD7X4//cC/j/zS/xHn9DjL/F+LcPPBcZFmL//Q/wR334KCkmPunezS4E+kFvQiIOf1jeI8T+Jhj9rp9Y9HvfO7ks"
 @"wh+2UTyjW/5uT857/d54l/85F++w18abcuLeRHVzk4slvgsLhw+L905fzoPAhwX0o1V+lw8Vh/4sPG45/ne1ccToD4h3eN/+e72oltnv71z/nvbg8M/0/5FO3ugu3AG3sX9/44XxftI5TLz/PSyFD+/11QEePQNx"
 @"iJu575COToe872w8+E3e6yNGH+XHPuGePyo4YCKdr95XvdmPNkR1k+6QjSUewAId+p53OYGTp/Nesx+Mja8smzhoOu/zBn78g8nXxr7Pj9eMibUHD0KK+649XJOoftcfMMNCCIHw+6fivRbKH+rX3uHBCXHwdX/Q"
 @"l/p73udF2LejByUP+QsP4hffy3/6Bzl14l4XEt7oJBPPq3rwVWAj7/kgcchOG20S7985mOEdowh/4D1C8O4+8MDuqH4gRttn4oJGNzS5EOKg8R9/yOjh+glz49/jQYtDFkfc51f9gf8W77Dohy3uAb8oDv49ORHh"
 @"CQnq3ucj9k/hwcWYiO4PsyDV7/t7D4B/ryDt4L+1qGztfSdMhFBk30R4pAyL5wXYyhZaJOCQ4wvx4+hJjUwFPjyIavE9Alv5yUlbj79n+/pDlldUv+/fOTWBd3/t3v8LgZQ4EFQJ/CiaDwuMR1V36YQbByiieo8U"
 @"IOU9VmW08F5ihRtvannIqghXmejq2Dp/iFu6x9N7X51Acdju8OEClaj+oJQhmhSj0+NxAmT1R+XoZEpw1V0p9lMKMXJ2gN1f53GmZ7lvnSbyQf+uC/Td++39U3hYoCEnX/MgRtGkmDDtolq0arNLQOMQUobb9AIn"
 @"BI5gdsebonrAUkzmjuF6nB8FS2Gh3AOEJPq+qKYKMIT0KEDLKheRamxOvLdI66vgIhxJiQjmVApQEiFBe4HwPvbCFR6wNlyo9NViuuq2fHhoduyHxdjset4l53iPKFS8WzDzDhtC3BMkSDna0CGfQ4DyITVSlRuQ"
 @"QqKUJNLipJSy5b0sjPd3jHO9MjwwYi8R3uPCUiHxaDF6bsRO+cK6sIjCjU6ex3t56F2M832JmDjSfpw4SuFRAiIJWgmUlE0pRMtD4RG5cb5nvcALhfUe7xxYW4XD4XNiKYmkbEZanXJKdI13a8aawhqHtwLnXAha"
 @"qt1mR6euengOWfkEf9/iSXGPabzXeUw6GH/4A+CQqspklUNUpl/L6iHKYG00AulFZTolMopiIUVshe3Z0lT3FjZ4icfiUSb4TxUrlFYoJYiFWJWIlsQ2vbdF6dy10tCzXmCq97v9czvhT/3hQYy8JwGVUqCVQCvm"
 @"Y8WFSMuTSI1xrOVGvFoUZnuYFZTegYBmmjBVq63WaulzSsh5mxfbxWBwOc+yV0vvkFoidYSIPMa7sAC+Mo/VZ4wP5jiv9Ptxd3XpUkz423fMK/x99nG0aw9GcgfP6X2LJwSy8rsSEU4kAiEUUsomQpIVRc8YWzRq"
 @"Oj5+7Hh+7MhxluYXSZMUY0s63Q6b27vcXV//pfWN9b81GGQYATKJ1tI0XU20ugQWaV0LYV/BuHA4JjOSKtCaiAfDfUyeQEmoqoSFk0RKEGkV12L9XCz9BQGxMW4tL82r1ontOKlfmJ1b/PKR5UVOHT3C+VNnObqy"
 @"QlqroaQi7w9Z31zn2t0bXLt2jTevXmVtfWOhcHbba4UXEm8s1rkQVlfVT+v3T8jk4ZqMwOQDusTJG+Ydor0DD6XykKJaPBU8AkIItCRWUsxLqVpC6bg05potyt5Uo/Wj73/f+37rY889x6OXHmd19RiNZhMtJL4s"
 @"yYZ9trod1tbXefPym7z5xmWuXb/G+tYG7X73p0yZ3xHSJ16o3CK2C8vlwvleXho8wVIBOOcQlSUaP5PDFlBphVQCLSVKeCSeSOnVepx8ZG5m+jeOrx7h3JmzPHLxEc6dPcdso8FUkpBEMVJpnJLBySMw1pCbgn6n"
 @"y607t/nSV7/K8//hj3jjxnVhhSSWGusc1jmc8+NFHJ1EcU9SFgIKceAEHlb/HCfkh5bixOEpi98Pl0bBm1YCHdzIvBJiXiu1itLkef5qLUmfe+bx933uL33fJ3n68ceZm59DJgkkCcRReK7WgDG4bIAZZpisJB/m"
 @"dAd9NvZ2efP6NV564zu88dYVbt2581d7WfH5vHQ9g8d4sD7EDKPcUUzUgyofWNnxUXBRPZxEQzNNLszPLfwXKytHf/rUqRNcPH+W8ydPc2JlmYXpaRppihKCMh9ibYmSAhknyHod2WjikyQ44azEDAeUwx6DdpfX"
 @"r1zmd37v3/K7f/AHH+wNyq/IJKYwJc44hA8+w4iRKRX7JTk/CirEftFBHJb8+ip63L9T7/Z9h/Jqokbrq7x03/+6yn0q4UmEIJKiqbU4EunopJbqSGbKF04dO/bKT/zwX+bjz36IqaQOShEtzjK1sEjcaqEiDWWB"
 @"63UwvQ50O9hhhs1KTF7ipcBphYsk7SLnzuYOb719i1fefJM3rr/NW7du/O1Ou/cbRZ5fH2ZDCsArGfyuC8HQgSBGVSnBwtziY5/86EdfObcyx8nlJc6cOsfS8lFmp1IiwOUlLs8wwyG+LMiGGeVwgDEFKpLUGk3i"
 @"6VnixWWSpRXi+SVIalibUeztMFhbI9vdIcv6fPFLX+JX/+V/z1ubd4VKEmxukNZS4sl1cIujREj5sHBKBj80ek3I/TxpVIIb1XX3T6oYpz6hAiKraNLvJ+qCcQRohKeUHiUEKZ5YivkoUidVFM3nvezVZ5966s5/"
 @"/tM/xeNnLpBnBXqqRevYUdLFRYSK8VlB0elg9nYotzfItzfJdrbJej2ssTjrUEqRNuvEtRRdT4hqTaLaHCaJ6LmczfY263e26HT6fPErf8r/+/f+nehZi0YijcNJj5MTQcxos85M1f/GR599P08fPULDFMQS8rVr"
 @"bL/ZIe/1GfZ6ZL0+vXabTrvNcNCnGOR4Fy6q2WowvbDI/PGTLJw6xcy586Snz5IszFJbWiKupbRvKMSG5Uc+8hHm6lP88r/6F/6Va28LLeNwynDIKhsSVdWdKlFWMvg/rw6aV+cPlkbEZBdlXL7yOO8oR321cbIe"
 @"VlB6h7QgXUgRnAiLqbTaltA0w2ztox967s5nP/2fcWZpBZsXzKwuUVtZwqUJtt+h3Osw3Niid3ed3dt32Lj2Fts3bzPY2abIhnhrq+BDktbrtGamqbdq1Kea6MYUjelppmZnODI9xersHP7oSbbabT7/B1+cz4rB"
 @"thDhulyVQwuFQBJyvkgIolhxemHef//Fizw5N4/o9zC2xJiSMi8oixxXGsTIRwlQqBBWVw9XCImqpUwtL7Fy8VEWn3iCubPnaBw/gY5ixKBPcfcOu7euUwwzXn7zCv/0X/5LvvbaZaHSmBKH8xbcKPGtToySaKmQ"
 @"wsceCilU03sK533hqgUaR5huv7wkhESKqsVVLaKofJySLlaIee9dgfdYz7a3Hm+hFAIfSWIpiI1b/f7nnrvzn//UT7M0M4tSmqmVRWpzswipKIY53b1tsvUNspu3ufXat7lx9QqD3Q7OOKTwSClQSuIdWOsoncF6"
 @"0PiwMXVEksQopYmmZnBT07y0vsHvv/Yab62tiRyPq9IjJ8IJFFFlQjQQIZCJRrmSs/Wa/ytPv58LjQbDrS3KqqogXJXMCoVQqtrtoRIhlQi5jofCGnJvoBZz9MJDnHrfs0yffZjWkWOoOIJswHBng+7tG7jS8u23"
 @"r/OP/sU/58/eeluoWKMtGB+cnpAKqWSVo1qcKbHGYytn5asoTUqJEhKlVHDulWnx3mNKQ2mq3T9KmZQkjhSxUqtSixZAKf01a31B4UO5UAlUUfB9Tz3jP/tTn+bE0jxOCFpL86jpZvisTka+02Zvb5P2jRvcfOkl"
 @"dm/dAO+I4hSho3F9WCmFB5zzIfrGI9EI59DeozyoWgO5ssrvvf4q/+6bL3xyx7ovWCEoq2hdeDGuCo0XMEKghUAniqSm5uO8uPDo3OKX//rHP85sWdLf6+IdOGfxVZIZdrgMu1lJpFKoqkLhvaVwhsIMKI1hbvUk"
 @"p558hqnTZ2msrqDSFFtm+N1N+uubCKl5efM2/+V/96t8++pNUdfJfCnldukd1histURKkkaaqXr9J+dm535jujlNo16nnqa0mi1mpqdo1uokSUQUKZACYy3D4ZCtrS26/R7D4ZBhVtIfDtne22Ov0/nkIMv/Q2mL"
 @"wnmHEx6pNBoNDsww47mLj/j/8//uZzh9ZBmpYXp2FhlHWGtxWUa+s8Nwe4ftu3e48q2XGG5tMpXG6CTBRzEohUaipKwWUISou4r6rYhQUlJDILSmefIMX7zyJv/dF373r+5485teaoo8pyztfl44qrNGVZlICYFS"
 @"UJeCWqyfE0rHMs9bf+UD7//cjz77DPmtu9iyBOdxzu63hmS4MKEkKB3KSh5wlsIWmLKgGPbpD4bU5hY48cTjTJ84xfT8ClEUI63BZX3ae1vYWPOtGzf5r//lb/DKtRtC6Ih6vX5hcWHhjWNHj3D2xHFOHzvG0eVl"
 @"VmZnaaUJWkmEdSgglqGGK0eFysr3We8ojcESdrB1UHhHe5Cz3etyd2ebOxsb3Lh9i9s3b3Jz7e6P7HZ7n/e55f3nzvq/9dc+zaWTJ1FakMzOEMdJCOZ6PYr2Lp29TTbvrvH2y99msL3LbKtJvVZDJQkyThBSE0tR"
 @"VWBUuK6qhOh9SJsUEuEc0fISl/OCf/Sb//pX7nS7P6trSTMryp4rDc5aTOW6fFWcEroyJ1KFuueUZzVW6gIhtL98bmb6zv/xx3+cYwKK3U6I9pwDD9ZbpBShuqIVQmuE1CgvwFlKW5IPhuS9PoNeh3avTWtlmZMX"
 @"H2VuYZWp6XlEnCB8gXcZvb02rtbkKzdu8i+++AWOHz3O9z73QU6dPs3y/BzNOEFZSzEYYHtt3HCAyXNwBowF51BKhNqs1Aglx35v1MIKdseDjlD1JnGzCUmKFVCUBdt7ba7cuME3X32Zu9dv8SMf/ghPnz+PNDmz"
 @"c3PopEGBpRwOsbt7ZFvb7O6s851vv8LuzTXmpqaZajVJG03SRoMoTlFKIzQIVS2gVFWpELzzKOcRZYlXEru6yq/+4R/xb/74j0UjTVeF9/HQ2uu2NKE050Oa46o2nhbjppdAeiiFXHPSd50velL65s2tnU++euvu"
 @"82cuXUQNS7wMf1hbgXEOp0FrjYg0QkdIrRFC4q1BFyVSSLwtMUVMqhJ2bqwREaFOl9hOm6jRJIoUwjsoDY4+H7p0kUcvXWRmdp5Ws4VxBldaXHsPkw1x2RCfDZG2JKmgG+gYqRUikiB0SMiVBBfMubcWZ0z4/1FF"
 @"p8gxHRNMptJI51hGsHz8BM+trlAOB9RrtfB84gaDQYnq7yJEiRsOyLe2Ge7scvP1K2y8fYtmrIi1QGtNnMbEzTpxkqJ1RBU4IJRCSI2vgqqQ10ls0YdaxJrxvHZ9He8kpbdr1gdTawWYiVx31PTWTORQDoHxDm99"
 @"D0Br3cpN+eorV9/ik5ceodZoYH2JlAptKyCTAqUUKooRWoGOws+NwUmFtxabJWQ6Aq0xznHzrbdIpSZaseR7PWwaoWaa1OZmqDWaWOuZkzF5r89eWZLGMZHSaCUxMphHH2mc2O+GCKURsQKtECIK6DgRaqzeGry1"
 @"IQexFuklQkpUpJFRhNYRUkiKsoBhQd7rkxdDhIRCaVoL09RnZnEedjc3GWxuIzpdRHfI+u01Ll+9inWOGR1OWxRFxElKkiToNEHpJFyKDAvopUBIHYomQiC8wgws6dwUG7e3uLO1+UGvJIVzoYzmxbg+7DlYZtTj"
 @"woUAi0N5gQjdWgx+DSV549btX7mxs/uZSzNzZIMuMomQVlURYpWbRQloNe5qOkTwR1GEVBFCqnDKpaTfH3Drxg201LQWF5hamCGdm8friGERzHJcEzQadaI0RQFlWWKKHGdM6GJ4D5U/EVIidYxMorCBtEKIsDed"
 @"taFLYksoLd65KpIWeBEap9ZanHR459GRhFqE0mC9QypNnhfIYUZtdoaVc2fopglb37nM1uYOb7z+Jr3hkFq9XiHpQqqgIxU2iNZIrfBaIaUI5lOG9pyQEimDxZDSoaenWfv2FTqDwVcsobTonA+bcAJHM9kq06O+"
 @"Ewisr0L3qupRCvBI1rvdz97d3fvM+5aPosoCHcdIr/BKhBxLirB41a731iKkHMMrnBRVdBoS68JZ1gddTsw0mT51lKhWp8wMOlIk9QaymSCbKSpOUEJgS4M3Jd4a8A4hQ7QmkCAVMtbBp6UJIorDxhJVe9xZhDUI"
 @"E+G1CZVy5yaaySEvxDk8jtJbjHSIWBHJhDhNUWmKQjAcDBClZGp+juShc2zcvs3dnV2scURSjlOd0OsL3RypFEKrsIlV2O1eKpAgpEIpDSIijTQ+qXNnawdjLVpLrDXhGv0hBXg30U4SFaxg9MAtVTTnQnE3xxUD"
 @"Z5FJgspipIqIlMZKOc6n3D4ApOoNGryzWGfHRS4hBFlZEk+3ePy57+HE+QtYYzBFQZTWUIlGJxqZphAnKK0ncJBuXAwVQgezKXV4QHGMiKJQh41jhNJVBOoQ1uKtQZQGdPCBzju8dyh8MK3WgAn3KhHEUoXulgwW"
 @"xQpw0iGtxRvDnukjvOPUoxd5rtPllW98A1sU+FoyRq0JH/p/UsgqoFLBRyuFkyKUUJREa43zChUnlFFCp5/hvCOucsVJqJn39+F+902oqOpPjkmIhEdIgfWOXpHjVLgAEUm8lkgZVTug8jXe46wLEWFpoCggL3Fl"
 @"SeksfVPSWpzn2fc/zdzqEfq9IbHWpM0auh4T1SOieoSMY6SOsSr4UC9AChXMHAIpI4TUCBUhdPBjMk4QUQRRCKRCi9FVJtQgdDiJ3toQMHkHziKtBSNDrdTZCgsUHm4Ux8goQcQJTocigbBQ+IIszymN4cIjF5mf"
 @"meblF18ga7ehNXrCDlxoEKjKzygdVf5G4mXww2iN8BKdJJgoIne2qjK4qgjBAYLBvX0ULSYcoqxgc24CoCQAaz07vR5GCkSskJFCqHAxVR8W4QTeOigttixwWYbNcnyW4/KCrMypLczw8BNP0JiaIW/3aUYJOq3h"
 @"vSDr9uju7aFqdZLZBWZXjxAnKWWRh4esRuWv0K90KoKoOqVRhKgeNlqHByPDQ5TW4I1G6OALRyfOu+rkieCrndYIb7A2nA6XWTbWb5NnOUJr4lpMc3aW1uwstThGRjEoTXvYp9aq8/j7n+TNb75EnmV4ZxGVrx1h"
 @"i1AqdAy0QiqNFYR+qFIBUhJpjJBkZRFcmhTB/VQF+HEz+55F1H4Mb6vM3ATYyFdNTeugOyghidFGI+IYVIpC4lT1MDw4b7GuwJcZJh9ihxlumJP1MnStwaNPv484rZENBkRpTJxGdLs73FnfoDMYBBPYaEB0i5k7"
 @"azz0zLPUGy1y40B7BDoUn5UMPkXHyOrUiThG6DiU91TwMQpCFGzKYBFsSIatEWBD2c8D1lm8lXihiLRmOOhz5fJl2nsdGlPT1Go1uv0Bdze3iJKYlaUl5qenieOIOIrptveoKc2Fx5/g+ivfJhvmWOsQxqCdC25E"
 @"WJSIkCLEDr7qokhR9VDiiG5estfpIB0IpwL2yO93U/wEznIE/dD32tR7gYquaiD2hjkuSdCyGaD4MkY6GV4tHbjwsHwZit4mLyjznN5gQK4k5x+/RNpo0e32qCU16o0G3WGf3cIwe/osD508Tjo3R9SsU1pDe6+N"
 @"15IojbBlHCAIIyyZkEil8ToK6YMOiya0CtGokoyxQKJC01WMIYlHexUK5dKHMF2qYNIqk1wMMmaPHeGJD38vjZlpUBJrHbbXo7+7Q3uvzfbuDnUpiZKURMcMO13SVotTFx/mzrWrFMMcUysRZY4yEcIq0H4fmyYq"
 @"5pGXGGuI45jt9S22drb+doBP7IPM7kUU7END/P3A3sn1G1UupIS7uzu0S8P09BxlPkSpBGl95dgd3pdgHbYssUVBkecM+wM6RcapJy5Rm56m3e1Sq9VJ63U8gsbcPDMPP0qz3gTrKIcldthFxxHLzRnAU/Y6SGdC"
 @"38+POuwKIdREt/0ekG+VIoQOu7yv6yv9Pj7Vj1pVWiOFQihYOLLK8tIyNs/Yu3ETU5YoB0oKkkSzurRAlmX09zoI4dG1OknuMP2c2twUq/I0nZt3qJsQPOm8gEjjlAXt8EiEFyghkGPcoebKlats7e78QxnJAJ94"
 @"VxLPO8AK74XCSx8K1Xd3tj/55t21508eexohQknIlyUy13jKUCkvDT4vsXlJkZfs9fqsnDnJ1Pwcu3t7JPU6OklxShPXEpJanbzTYf3GLVxvgC9KPA4nBSLRqFaLpNUirqfIOIY4AqkRqgLNeA86RKeheVutsgv+"
 @"WQhwJkSO3piQB5oQleIc3psxH09rHTh82RDXH9Dd2aO7tUHRH+CNhcKETn0akTQb1KdaxFpTeB8i4DQh8jDoZ0wtLGDzgnanw2KS4CKNKKNwHc4iXNUA8CHalVHMTqfLV77xAoM8R8dRiCceAC2vD+JHuA+6571D"
 @"K0Wn2/vCV15+hY88973EdYG0JUJ4bBlghbgQkntT4qyl3e/TWJjj+OkzbO20UVKhUXjviNMYoSSbt29RbmwwHPYpioy8yHHWIIQg0hE6aZE0mtRmWiRTU+hWE9looJIUqWOEjiDS4GKkDW0mVASRQWgVqkulxZcG"
 @"ZwowAZ9iXYEYwSCdRXqLK0vy3gC7tU1/c4ve7g7Dzh7ZcEhRGpw1KC+pJTVUPaHXbNCcnqZWrwcgWKJx1hCXjmyYs3T6JGuXr9LvDZiqJUhjwYR8VkiB9AqlQttNNpu8+Mbr/Nm3vvljqGoT+n2mkvP38zWEuPcE"
 @"iopmdgiES1YAky9//Ru/8sanrn3mA2fPYrp7SBkauc6F5NiZEmstgzzDRYozly4xMAZbFDRb0wjnSZMIb0t2766xt7FOtrdF3u/hshxbFJSloTQG5wUqSknSOo2pJrXZGRrzc9QWFkimp9C1BqpWRyUx2BKvI1wZ"
 @"4ZVG6igEMlUlxhuLN0WIPq0BFyoy0hpckWOyAXm7Q+fuJr3tDXo72wx32xSDPqYssC40ePECrTRJLaU1M4Xp9fBzc6T1JlIJXASRkxhj8UJy5NwZbl95izgvaaQuXKeJqgQ8wlhLgWJv0OW3nv897u7u/bauJ2Gj"
 @"eb/PM3kX/ohS4uACIvax+7KC1gsh0Cqi3et+Pu/2f+H9Fy6ivKXMB8iixGRDTD6gHAwohxntXoeVU6dpra5yd3OLutYopUhqKd47NtfusHPjJtn2DuVwiPQCrSOiKCFKaqRJkyRt4CnJBl16e23ybocyy7BliXC2"
 @"svMBjCW8q6LLMpxCY8KpK0psnuOKHJ9n+DKgCVxh8FmOHQwoOm06d++yfe0auzdusH1nje7ODqIoqKcJtVodHYeqUFxLiOsRwnuG3U4wr9YSRxFaS7zwVVsrwjpHc2kBoyDf7VCr1RBx6JAI73FlQT/LKJXmf/yj"
 @"P+Tf/OEfCqtkOETGIvwI2CUOUtPeCVovJgiK4h7acEgtXBxpHX/xT7/00HQtfuMnPvn9zHtLrTsAayhNhjOGYlAQteaYP3eW/s4OUziUCoVnY0v67U127tzBdHokKkKlLe4O+ryxfpe77Q6lsURSMz0zzcpck5Xp"
 @"edJeRtHr0C6HOJOH1MBLah4wdWSaIFSC0KF7L5QOCC6CdfCjgrazIeUxJWKQU/Z7dNo77N2+Re/2GoP2LsLDwuwcZVrj5l6Ht29tsd5p0ytLIqlYaU1xdmWBxXqLQa9PsbZB6Q3zR1dpNKYROKQDH2m6Zc7i8VPc"
 @"3svodPo0IoU3JdI4sDCoNfj8i3/Kv/q93/uR3Bik1jjnxqg4qorYPjfwXRZwgls/PrZiv1WB97bwnqJQXP4fvvD8wu7mxtb/6rlnOZ3WEIMhtsgxpaGbl6w++ii2VmNY5MykaXD0QnH37l2uvvk6SaSZn1+gg+AP"
 @"XnuNP/n269zuD5PMUygRIGfWw0wSPffk4vKXv/fMOY4tLEJ3h3KnzVCkCBmFQGSmRJsaSmVIpRFS4XUMkQzn04eKvnPVIhqDL4a4dp/e7g5b22t0bq2Rbe+i0ojWkVWu7rX54rde4tW7Wz+1Oyx+3bAPItLA4uXk"
 @"04+vLv3ak0ePsKhrRJmlPsjp5DvM1Rq06g2INXlhkbMprZMnuPnNb+KcIUprGCm4W+T82z/5U/7Hb3yz1SmLXqwkxtqKO7GfP0jBO5JcxP0ceTHBrxJjRLsjNBJDeU3ihdj+g69/49T6zRvXPvrkEzy2sMiil2TD"
 @"ArU4w+K5U2yvbxE1Z8i9RZUWURhMP+Pm2gbXd7aoLa3wxp01Xr61nkTTjVOr58/nU1OzoThQ5gwGfXqdzt9+cXvn0uvbX/nIxy5e/OUPr6wghxnZ7h4+UgHy7iwUJT5OQioQRXhdIkoNSoWFc6Fs5o3BFiWm22e4"
 @"u8ve5h26G+v0tnZBaVxzhn9/5Rp//Np3GETxz6RHV586nTZ+LRIqoNTwDG1Bu93+sS/duSNeWbv7N545de5XL3nJt978Gkkj4lMf+z5EHBNrjReefjakdXQJf6XO2nYbq4e8tLnG85e/w0u31oWkqitjDnQbHoQv"
 @"KISoMDGTPxD7NChVeRkhQSgf6oROIaQglsyrPJ+fivRPnl9e/MUnV4+zPDvPB3/4U8wuL9O9sUZdSgpCvTFf3+A7r7zMrW6XP7t9my+/feNpppqcvfjYC2fPX2BuZo5EB4iEswGOPuj02ep2ubF2k/bbb/3jZ+Zm"
 @"f+5jp09S8wU6TmjMLVCfnaYxPUNcq4eaaJKgktDclSoKG9BYcCGYMsOMcrfH3vYG7c07tDc2GWaGvNHi62trvLjT+aXl0+c+e+rECVqNBnEF3HIilAmdcfSdYX13l6tvXP6V3p3bnz/Rqn/uzHSTjz31OI888ghT"
 @"U9NEWuOFZIihubLE669f5l/9xr/h2sYuN7qdT+7Y8gtWKYSTVeo0gs+HrGCU9/qJSsx70su4t98k9rl53lV8OO9wVpAjtuM0ydve/fqL65u//frmzkc+8cEP/vJfPHWK3tYGKvUkQiKFwhQlvfYuw16XYZ6z1ctY"
 @"PHH6hac+8hGOnD5Nq9lkeX6B+fk5hBIYU+Jsievk3Lm7yd3dTTZuXv+56y98jW9urPE9Rxaw2YBBpw0VlBFj0GkN6S0eh/JR6MJX5TRXGlyek/f7ZJ0O/U6bXrdDXhTkSZ2v377DG/0h57/nw589+9BFTi2vsLo4"
 @"RxyFqo6THukEg/aA9a1tlvfanDhy6jOvv/jVz+xef4MjJy6w0JihyAtcpDFRhQ8qHbY3YPbkae4mCS/u7ogoaaC9RJiCUjisuKdiXS3kKP58N0ULfS+fQFQ8v5F6hK8cauD0uaqBGko9pZM9qXXLa1X0vfjCQx94"
 @"ljhOsfmQuJlghEZ6hXCO3Ja05mbZu36bvlR85JOf4tSFh0nqKY9dfJjpVosXX/omL77yErt7u0w1Wjx56RJPPPsEp3c73D1+nCMrS1z+w+dZbw851qgzHPSRkQ5dAgeJ9yhZNWudRVTtKGcdriiww4yi3ycfdBj0"
 @"umSDHJ/UuTHIuZoXnH/uwzz02Pu49NhjnDi2yptvX+brr3yDYX/IfHOasxcucOGpxzhXOi6/cYUbt28wM/NRXvqy5+rduzy1fJRZVPDDcUxpDUppyu6ApdNn+eiHP8ILr79F4S0uQKwo96Vk7hWt2C9QVGWzw3ge"
 @"+t3Y6W4iQnUVFhHhqwZwFSF5gS3L7TOnzm49876nyXa7JE5Q1yk+SsApfDcjSmvYWp0b/T5Pfvz7eOSZZ6ilKefPnaO7u8Ov/rN/xh/8yX+4tN3pvFpmJZFQTM/W5//ij/zQ1l//az/NwsIijdkpfN7n7a98hdkk"
 @"QVhD3u8TC4WRCiVCJ8LLSnPDBvvhncPlBWaYUw6G5P0uZjhEo+l7xZs7uyw/9jiPPvUcTz/5BHNTNf6Hf/3rfP7ffe5Xbq2v/WxWFNREwtzMzKe/58PP/dpP/PhP8NiTj5IuTHPnxk2eEIKXv/DvuNPZ44iUKCdQ"
 @"KIbCIrTA5ha11+aps6eYnU4/fX1n79dVxQP2FafOP4AAw2FOUR4uR3WPNsKIuy1lBZkIf1ri8c4VmbHbjz9ykeVmne7OJrHSKBs62krGeAu61mCtP6B54gTPfvzjzC4vc+nxS3R3t/hH//e/zxf/6Pcf6vf7r3pL"
 @"WAgHezs721/4989/8Hc+9znqM02Onz3P6aeeQZ0+y43eEOUl5XBIMRxSDnJsNsDmOaYw2LLElUXwe3kefN+gT97rUw4zXJGDFGz0urhWi0eefppHnrjE4uoCv/v8/8yNW28z3Uw/Y4oc4zzdsuTO5savf/5//p/E"
 @"f/3/+Cd866UXOP/wOc5deIhzDz3G8XMXubm3hyNAHCMVoVQUWnNSku9ssNpscPzI6q9ZGyq0kRcov1+rdZMEV7H/7F2V1LsKgugnvuV7KD2NKzNC7hMmBQLhJHiNsWzLuM5DZy4gex1s3sNrAZFCaYmUDi8NIk7Y"
 @"yDIufs8zHD9xgtXlFVKt+Nz/9N/z5JMX+bv/5c+/cfahc740JV55clnQnJnmf/8z/4cvf/8nPsled5vZ6QbLx08z/9AldlSNwkicKcnL0HO0ZYG1FuN8gCNYi7UFtswxZUaRDyjzIUVe4q0lw7DlCpbPnOP02fMc"
 @"PbHMi3/6RxxdmOX/9k/+AX/1f/uTJElK4YA4Ihdw8uzD/ns/9FFeeekF7ty4wunTp1g5dYJjly4y1BHGljjlII5JdBL6lwiyQUbdax49cpYUxQgr4bGV7kDFihITxfhJ+ZXq2020+rx4lwW8P7sQYzKWGJHGpaC0"
 @"jtnpqZ88vrrMoN0lVSoQI6VGqggnPUIrnIxIp2a5cOlJmtOznDx+nC/94Rf51gvf4Id+8Af50Ie+lyhKQhmq4jkUxrG0vMLHPvwhtq69xY3Lr7OysszC8WPoVoPMVgTI0uJs9e1d2LGu2rHOY53FlCW2CN9FWWCB"
 @"YWmwMuboqVMcPbrKzvodvvz87/LwiSMcOXIEkBgbmrLYUOOVccTHPvExZpoN/uj536OWxMzOL7By/DjJ9EyggekIVKi6jBQ7vDX4suT8qVOktQQjqjbPPcJBD0JYnUzq9eGKQJWOQ9UBD1FoaPNKKYKCUuVcjXMc"
 @"P7L6G6tzc7h+jwQVeBNS4mVoXKIlpZDMrBylOb9EY2qaMhvwpT/4fbbW1v7xf/ur/6+f2xnkvPTSK0LgMWUJAtqdHv/0n/03tNdv8ua3vsrK8XP85c88RHN5kXh6GtNpVzIhAVzlK8ihVLLCX4ZeoKsATs45nAk4"
 @"HWM9QwM2SmksLFCrpXzzK3/Mze+8yud+8zd5/kt/wu//hy/TG+QIJXDWIAW8+tpr4ud/4ed9S3uEktz8obeYOXKcxtwc0fQMGRLiClhVoeakCM/ElwWnjq6yND/3X7Tv3P6HKI22IoQzIqRtboSBmWjD+3cQyhvL"
 @"jNyvDeAPQNdExYwdLZoUPg7xu0RIUTx09hStJEa0LUorQOErjrcX4KWk8I6o0UDGKfVGkzvXrnD9ymVqkfi5559/PlnvFgUjtrCvemZC8q2XXxLdtbf/xiOL07/qC8/m5gbx9Ay60cD66h2iAvFGGhnFqCgO4CYp"
 @"wBqUNUg5onM6rA+KGLl12DQiaUyRlwU33ryMKgu+/pWv8a31fys6BZiqmkNQ3KAoS77yZ18X55enf35+auYXX3v12zx79DhRWkfoBIuswEuSSMTkUiI16CjCFgWrc7McX136B5fv3P6HKBV6k46QqozUOg5ROBo1"
 @"du/NKOS9UldifAIPisx4IfcFFT2xUnJeQKyV5tTqEWoyULJFFLrbbmSwfaCRGmtRSqOUJIkitjfWKYdDmkmMNbYQQgaw62Rpr6qo9wb9z0vnGLY77LXbyDhGRaGoHJJeGWAVSVIl8ilRLSVKU3RSVWiUQkk1Fq8A"
 @"iXMCH1QmGAyGdHZ3ES7wKLLSg45DlOhH2i0CJSVSC2IlflGYkru3bzEYDhEyQlIxo0YMKbVfmxVJjMPRiDSLMzOhmSslWnq0rORGDolDxkKA7/B9X0PXi3ulnwKsW4qD2mBSiJZzohvHabw4MxO65rpaQKWCI7YO"
 @"4QRKRWilscMhwpVgS/I8J9KKuo7G8pSTKoaj3MgDVohthMY7KEuD8g4tJNI7tNToOII0QdZS4rROktaI6hFKKpwxKDxuOKSoyDdjhQTvcM5SmJIszzGFQwoVXFMlcOCEw47Q31U/0wvQWhIJyLOMvCgDGs9aYinH"
 @"WFawjFQSRL2G7A/RAo4tLFLTOrCNVWVC3b4A0gHYxHuo3sh3Ena9X/DRT5DrRSKEiI0pew+fP5dfOHsKrCVKArDIVVBEa0q8C4Xsqekpsl6XQbtNUeRorUiimFgp0jh6ahL/OJL3ktUJi6LolI4CmMoKQTnM0NYQ"
 @"K0ktTUlrKVESzCZa4YTAiqCUNIroRCWrJKRECh0kRHAob8mHQ4Z5QVKvEUWKJI6ryNCgqxaREB6BA+/RkaDeqBPFCVGaYqyjs7OHHQ5o1lKUc5T5kNKUAXgcRagk/K4EPvbcczx85qw3RUGs1aqSQaVQiAdNBg9Z"
 @"QDmCT0xqE/p9vS9pPU4E/pxCzXtLUW8kT/3YD32S43NzWGeQaa2iUymssJS2wJc5JhsyNVUnNZadt27S7g9Im00a9RpKC2ammj8TVSmmGAUiCITwKASLSfSGljnMNXFRk2xjm7i7i5CODE9uHLm1lF7RjzXDeoyJ"
 @"GpRJkyJtYGsNslrKINW0pWdQGDKTIW1GnOUUvSHdsqC+OE8caWZqKWmsKJXDRwpVyTW5SlJrpqZW55p14rRFfX6B3BZs375OrewyM93CFgbyIdgCpSJ8pImkQtVTcl/wyLFj/MQPfJJaLY6N92tSqnHZRIwfvZjI"
 @"Cz0IV6VyB1dXH0D7+skSzsHajqeq10nwSubG+bUPPflU/tH3P0u+1ybVMTpN8JVInvMBoWaNZdjrkSrFqYU5vn3lMtMXz1GbnWHu+Ak2395ldWXmMzd3dn62bzxWKZwLHjv3lnoEq0dmKFCcOf84ymnuvvk2ZqPH"
 @"dLrI1OmTLJ89yfypozQX5olrdaK0FvqDKnQEhPPYbEDW6bC3vs7G21e5ceV1em/fwGz26Ny5w9TSIkcWTrDVmkZRcHK67ovttrBxTOkl2tqAcBNwcmH6znwUkadTrBw9Sn9vm40rr/HQzDTTSUK30yZpNRFeByKQ"
 @"jBAqRrmSCMjabT7xwQ/yR9/4ev7HX/2aiLS6R+pSjAUZ3qsroR9Atnnco5KVH8iNu96can3khz7+CZrWU2SGaGYK4gShBMJaZBneaREoEdHZvMuRmQZvbm/w5te/xsUPfZgLTz/Lxo03OLk0T5bl/qWrN0TfBJlv"
 @"vEUowUNnVnyjUac1fYILF9/P5vXriGGfJz/8vZw9ukpzbhoRSwqT0VnfCMRLZyilw8vAWVRKoYQkRtGsJcw/cYkLjzxMe7vN69dv8u3tXXo3rzO9sELzxEn662/z1MXTZK9+5+ev9/K/h1JIZ0mc5eSR+f/n4+fO"
 @"0N/tceTSYzQXl7n24gtEGztcevIina1NSiGJp6dQURy6+SoKvJEiI/WebrvD7MwMP/Dhv8A3Xn51fjAcbAetcXeoiO67fSklDiogjaWmxMFV9KIiqAhFYUuevPTYtR///k9S6/RIoxjVrKPrNUgCF26EqhIu5DfD"
 @"QYd80KURx9x6+xadoeHE+Qt0drYZ9jtceuQCs3Nzv+CQzUYSJ0ut2g8/dPrEl1dmpzGF4NJTH2F2aorFpOR9Z04xO53S72+xc+cW7Zs3Ga5vUHY62DxH4ogRpFIHE5PnFHtt+pub7N6+zebtm/S39lDWsjI/w/Ej"
 @"C+hI0csLvHXs3r3D6uI0x1aWPpZG6S/UpV5dnq597smzK7/w3JMXn81VjJs/ypPf90O0d3a59ZWv8vTsHEutlMwUtBbmiaaa6EYDnaboKMFKgXMWZR3SGLJBn8bULN+6fOX/cntj4xelEPu09fsAvO+sV6zvjXEm"
 @"q94HtHT8SAvbIaTi6YceZdoJ6PdQ6VzoETZqoCWZ6eKkwOsgVqfrKdMrK+xs3GHGGy7NzPHCSy/Tbe9x4dKTvPT1DruDAY89/ginH3ro57rtzs/l3Q6Ddp+9vTYnTz/EQ8dPc6aZEA867Fx+AzccUvM5sdDU4ipd"
 @"aNQRzQZRvUlcbxKlSZDvNyV2OKDodck6bWxvF9PP2NvdpbAZOok5vbjCsdVl1ut18s3b3Nl8i+PHjvLhJ1bJrf+MSDxpKtnc6dLxLd739Cfob+yw/srXeaSpODHXohQwu3oEPd1CJMGEC6XRaSi8u6LA+0A/M3t7"
 @"zE7N8dTFi7z0+muVQKDE2YpC4PazsHeTDBuDmiblgcWEVPLoVEo8Wkpya1mYnX3uf/OpH/rPVoVEmSFRI0WldZJGDWcddphBJUdpZYhCYx1RS1OkELSihIXZGXrdXZw1LMzNs7W5yd7mJk2tmW82mG3OMJs2ePjc"
 @"eT7yzAc5OzNDcf0Kg5vXSJygEackOkFFAXfp4gQfheK5jBJcrEGJUA0SlU+ufLtAoIVCVeMAZGEpt9sw6LO4OM/x0ycZljl73S61WkK9WQcpuLO+zW7b8MjD72M2SlEbt7k01+Ch1QXqjZTW0grxdAsfxQgVhWKG"
 @"c2HsgHeYoqDMS7wrsf1+OCCNBn/22qsvtPu9y1qqsXbNqCHrpbivjCYOO4HvWn/zlUamFFgDR5eXv7zUnMJ0+kRpAAq5sqS/1wnAqNwgvUNJTxmIcqQ2QdcUKklw/T7NwnLy+Ap7WUEhNU8dP0u/v4fC0mxOk9Zn"
 @"YTiknmoiAWvf/iZ+2Cet1YkiXQnLihCdecAVCCPw0kFuQRqsiXFRuEVbWgQSpev4RCAKcKlFConAEFMy7LbpvP5t5pdX+cHHnuVubw+vQ35WWsmjqxeppXWmWg2UsLQWj9EUgaUV1epILTG64v85kC4g1YsyI8KC"
 @"CUxb6xyRkmSDAcfmZzm+evRzdzY2hYxC1Ue4fSkKOcHOfcAgZiIfGel2VmW0GI0UliMrSyRlhuu3EWkTWxpklmGcDXmPC6xZIRWRCDvQJxrpFNpJvIzxRQHOsVKvYWWEjRRqZQktIBKKwSAjHxriYcbda9dQWUZS"
 @"r+GURAhBrCUuUlgvkNYjrMf4QB1TeQl+EASJooCNEUJgCWRTnaSBYibCAjrhKOUQXXpEOWSwdhuZNFlttWjNzKMaDYwPvEThLR4TUN3CI1WCTgKIyVXMIOkDYd1RiRWZkKh75xHeIGwZeJjZkFYS89Dxo3zzlVcQ"
 @"UgS1CnwAS4+Vk8W4Tj0ukd4L7H2n2QSMTKgKjcp6lHDu5Alq3iLLAl+6IBlZFGG9tcBLNRa2EV4FUQYZ8krtNFbHAYTkfdBlEYF6JWQoKJmyIOvtUosk27c28HlGrRbjVaUeLAT9Tod2NsCriKWpWZI0InMWYS3a"
 @"K7wygRXhXUU5C6lQFAkoDJ3OHsNuG1daGvUm6VQTMfAMKfHGYfMhWTbEmJzF06ep1Zu4oNOLF3F4LlriK3KNlKNSY4WCYzQ6SCBshfh3DmdLMFXXpCipOcsjZ05TT9Lm0OU9LQXCibE0vvD319a8eJcTuN++3z+E"
 @"UshKpdY3p5uNp08tryKywDmXpgL7aINUCqn8uPANgSCKkFUFROG8R2CRVgf+nBS4ivMnhEd5T787RArIB32ywYBarYHWEoOjdJYrVy9z5fU36A4GeKU4trzMBz7wFFNL83hnxt0HX3EWBRYvBHEcUQyG3Lp8lTdf"
 @"f53rN2/QyzIWFxd45n1PcnRhhsSlFL7AVZD7fnubeLPBwok6Ok0D/76SlUZOdNU94G2QfxceKVXFiDLh9GHw1oUgxQYeifIeURhWFxZpNOqf7O8NfluqCCf2deImg0n/3eaBwo8CmCA77D1FHOsL03GKy3KEdwEo"
 @"WxpEHOz1vkDkqKpeVXSq0haRRsgYRrIfQo43jBAem+UUwyGYgv7uHmkcE0cRzhnwgju31viTr36Fvd02JZLcG95au4XRno9/7GPU0jjkUy40SnGqaoNJlFfsbm/y0muv8ZWvfZ2Nna2QK165yu5em//kkx9lttHC"
 @"OYFxwyDgZxz9nS0aM/M00jp2pIsTKXQU4z0YE7gTOFnJfsnA+5MgvMJKH+QuXdjw3gSIv/IOPxjSnGox1Wr91t2dDSGiSp13NP7GiTGE5bAVlJM9Jy8mKVz7an+qQvwaXBGn8YVUSsjzquLiKp6BRbgQbYUaUKAX"
 @"ixFvwrlw0qKYtNFEJjFeR8HcjpTFPRTZAFNm5L0+3pShvhoF+RKP4srVt9je2aGING0Bd7OMq3s9vnH5Cts7HaRU+0BY75EVW1aGJ017r8OLV9/i6tYWZZxgowC+euvaTa7duB30ZpKEpNFARxGRUtgsY9jeDSoZ"
 @"zlYRrUBEEVEtRWgdbtm6MeDowOEZa9WYiuASFlw4iytzaklEq9lgxJb2Vc31QSox0vl7/tjBoVuV+EFACFvvqNfTn6tVC0ilmzbaXd4FUobwHm99Je8xAta6sXSw1hopNKP+nxrh6MqSvNvF9AeU/X5QDI4UTlUc"
 @"cmvZ3tkJ8l5RhIojChWxa/mxtzZ22W73kEoFQYTRPKLRtflA5tzc3uGN27cxSYJOUpQUREozLEpub2xhAJnGqFYTmQbdF+U9w26bst9F2iDgYG0ZGEtSEmm1P2Ojulfv9ylwPmiZIMpgrbwNPUkvQ6e/psMCVvM6"
 @"Yi/8O46UGSlOjb6lF/ePyxETeaEQITJSyHkhPGkSkwiByAtERc+ikkt2lY0fdb5dxccTrvo9ayiLgn6vR1EUFTElvCa8I8+G9Ltdiv4QUdrQwtISJyUqSSoIh0FFEY1IMYWgphOclt2eMf88KysiqLSVGJzA48Zi"
 @"B957dtttdvY6f1srSSKhoSQ1JRHS07dlkOmPFCQpIq0hVOhcFMMBWXcPiqyq8RZk2ZAsH4bT5B3ejfgX+5sWGyD92Aodbm1oSRFKhQ6LkBBHI70JVxwqHf1uaYSfKL5Nzg4S4zYK4ALJJZYRCoGzJdZE6Ir35myJ"
 @"LEMv0DkfyCWu6vQJVbVnAs3LOVdh/ispExt+XnQ6FHsdfJYH2IYL4CkfCuikrRY6jkmjmERHlLEkLQypEE9rqX5aJEkQ3CvleAeOlPG9DbJgubWUcE17T2xtEMuLBK7UzMzMEzcaFFk+VpAYKWWIsiDvdsinZ9BB"
 @"aBRESWmr2TRmtHjVyaCib1sb/KMpw3cZGM37Gs9BxUKN8DHOxUAxErM7mB3cfzL1ZKteVnmHFyOAb/hvKxxWiG3nHCKkNpTeoK0KfAOXI2yEMAWUIiyUrzh6Tge4VaWTLIwJDNtK8M1W4q4uy8h2dih294ilpKzk"
 @"K1MniBFYZ2kuzdNanKe9vUc9TillQTPXTHn+QateZ2Z+HqEitKh0YirRBumC+fcxRFGKlKIVo0hERKQESkKcNjl77gJpY4o82wzWR4KVIQAzw5ys0yUd9AInUUaAwYtqlIcL7qLS5AxSkpWoUIg+Tbj3KtVhdEKr"
 @"+ROjpq5wPrbeF6ND5CaLoxPzGkenUx+g7Y7mHI0HVIkxyGmETyytw1hPNMprXFgUb0rsWCFpYkZQdZS9mEB8O1uVi0RYPFNSDgbsbW6ys3GX+ZnpypRJmtaSOEWvn5GuLHP64Ye49sZbNHVCgsDGhq5WnDl2hKOr"
 @"i3hvRqTGMSzdVZFi5GGu1WRGq19N04g0SZkREmcNMyvLnH/iMYwpEQ60kBQVrNI6Q6/XReQZjblZ0kYdoSOsDI1jUYnOBu79yAdWwg+jkQpVY9WOA7/gG32QIsa6+wXcxb0BjL9/mNYhHfl9Ypmf4GMH1TzIypKs"
 @"DMM+RtjLwD0oxnJY3gUOuvCuEtUJJyE43rBL3VizxUKWUbTbdDc22N1Ypxj2EWWJyTKcDXRoXxja27u878n3ceT0KQZ5RjOp0Ygi5hpN/sIzz7I0N0dRlsgKzucrIfMqncbkOWeOHeOxUydR3tCsJSRak9TrfM9H"
 @"P8z83Cy9dhslJLYs8ZW2Gt7R7nTYXd+g2NnFDYd4WwSfN7oPFwoamMrPVWZSVPVXFdruuCrRD4IQdgzWLYqyKpnJMa4lMNffvT0vDx2KMbH+YVPtT+LoD4a/NMgLvJQBNuHKUAt1wUyEG64unAA42p+E5vYVjJxD"
 @"OIssS8gK8nYnyE2akn6nGzjlw4wyzymFQUtBtrlDS8X8pR/7yyyfPsnQe6J6jY9+7GM899xzDAbDSq9NjcXsxqxjISiyjIWZaf7KD3yKk4uLSGBqaY6/8Jd+gGc+/EG6a+swzMHagOYuA9alLEo6nXZoMg8GmMEQ"
 @"X5ZBKMiOBISCD3TWVmwoPw5mpBQoqSaK6yGwMUWB857+YEinP6jQ2aInRmPQxEGuxGEzEfWBONUHFo6YABmNQEy2Sq762eALwzz/rJQKU+SBf15drJucuVfNY/MTc/JCSG3H06mF91AUmGxImRfUp6eod2e4vrZG"
 @"Y3qKyAn6/R4+0kgpiQy019aYXZzjL/6lH+HOrdt4ITl28iTeG7LhkFirfYKqrxZxNH2oWoCHTp9i/kd/jF67zerpk6ycOcHexgbDu1vEFZO4KAqyQR+sZXd3l3any9Gjx5CRYphnaONQxoOw1cO1eMv4WeA9Qk2M"
 @"PJCyIqBWB8N5ijxHpSl7nS47u3v/p1FGMKp7HjZ+bySJNjKjmgkmDD7U4cbMJESoVbqRspCgsO5yaS1KqWraisNah/diPJbNC4GrtMDEePZs8AnjmSsu+AEqPWydxszUl/FpxLffvkp88xaPnT/PsNdDKEmz0Qoq"
 @"wVlG+84dorTGiaOrICXDQQdTgapGxDoxGrI0MktVv610OfkgZ35qmqNLy7hIcffNtykGAxIdZK9cnoeTlhdYY3jr7WsIpZhfXqK5MIdVCmsM2phqxFyo6Qorx64DHN4EuahxTih9OIH4yoQaIiXpD4f0Bv3PCzmB"
 @"Q2I83G1/iJ8X4yElo0DmEJ2Y+ydhjmaMSSHIhtnl7b09fKuOA4w1qGoAJCPsqFSV2RT75ES3P/NHVGqB4T4MaE1jYZ4oiVCtBqunz/Cdl15hpjnN6uIig04HKQVJo4FAknqwg5x2ViKVQGiFiqPx7Gy8q+jVQcR2"
 @"PE5CBkiIdFAMh2S9PqWzRB5qSlCKgiILJNB8mFF4z9Wrb7Fxd5PHHnuM+twczcUlyuoBOuuqaDdsUeEY+8wQQJlxKcw6h7UC4Q/6QqljNnd36Q+Gl6WQWOfecw6wnwhkpB9LP4mqCL2fVlTssSAk5A0axSAb8ur1"
 @"tzAqrpysqHZENdVShiUfBS84j7AOYRyidIjSVh2M4PSFB5mkxFOzqOY0rflFHrv0OAuLS3z9Gy9zY30LG2k6/R6DXi8svAAtBXE1Ck5V5kZURBI9gRGRYlRcD7kpUqOECrBGKUgEeO0Ymox8t8tgt82gN6QcOi5f"
 @"vc6rb15laWaJ1dXjqPl5RHMKXW+E8tkIxe4CcCoIB4U4wNrw31iDLwuMKcGAzhUGQaksXnpyr7l88zZ5HkQUCmGxPowgGhcj/GRx+qAIhb4PCX2oLpfHiqCpbZ3j+tYGw0jR0Arn7IGJnOMpzZW/C95hf7zpGPVW"
 @"vUHIwBtQcRyAwUqyevwET33gGb72p3/KH33zBc4NLnLp1CkSkdGzWSVDkuCVChMrfFA9klYQVTqcpbTB7FdgLJxEeh/kGZXCahVyUOHJ+wVFbwi5IXeWO/mQ19+8xtaNG6wuTXHyoRMsHDlCqz4TIPsm9AQPkNqr"
 @"8pmr6p7C2YBO9xWAeKRJ6kIpTRqPjGI6zvDm9Wt4a5FxvE8h8yOlQnHIIOUJSMXBYcbivqG+Y6dJdfy9J0pV9wOPPvKp2dziTE7UqI+FzwMrZ0LHbBxGjQq0bpxbUrVlpI7GyvdSq6CPrTWNSLO2tcMfv/gKG/0+"
 @"UStFSI8pSowN5TvpCJB5pfE6CK+jwwRSMRpD4EdDGyttcJ9TlAOyYQ/T7WH6A7Ks4HZ7j2/duMHvfuNFrt66zaNHj/Lo2RMsnTnB0rFTxI0WTk/wKEduwVZ5nR8l5w5vfBWVmiATXUWd1pYIW2D6A0TSYF1rfvfr"
 @"X/v77V7/D4QM8s++ErtzE7OE/Qjqcg9vQt9Lrz4Uwj3S/fWWRErubm79k+/cvv1fnZ5fxewNApmyyn1cacZ9MulCGcQfGPdcRWZCIqUKJbeqxxaCH4FKEqYXlzl5tuBDhWdtr8vvvvrqqT+5de3TTxw5+osPHVni"
 @"+NwMi/UmrTSmWa8R1RNULcUmKbGOkVIH7dOQxJKXZVCBKkPUO8yHDIcDurtd7u62eW1jnRfXbnNzo3NEOOJPnD997bGHz3NkeZHplWOIVh0rw/BUKcMcVu8cvhyVxdx+HdS6kAu6kFKM/m2LEmtKZFliSoeameLb"
 @"195mfXfn7ygtA4RfikpndFQG3A9m7u0UeQ4ZfrWff0wQ7KueoCRM9BrmlteuXecTJ84iuzqQKxODLMux/LLy4JWrZjfIceMWJQOPXYYOhxeywqWMLlLglSZuNGkdO84F6/ne7Q2+tbX+M1f2+n/nzt5bf+9P3rr6"
 @"2LGp1isnp+c4PTfL8bkW040a9VqNRq1Gkgapf68VxlpsaTBlQV7kZHnOcOi4097jrc0NbmxucXO383fXs/zvtX3A2TzRqvvvefg8J46tMLN0hGhmGR9JrDQIknGELqTEi0pSuirYWxMK+EHWxGFtiS0NriyhDEpS"
 @"RZFjVURZS/nW1bcYZjlxFGOt2VdRrGCifmISqb8H7PuODd1xGuL3h6iP0FGuGkJ15ebtX1oX9rNHGnVcnmGLEqGKqp5a8YW1BiVxsjKpUoUitdy3A3LUShqpzAYRblQUkUxNk5w4xrP2/bx48/b/9e5L3/47WRpz"
 @"txi+ur6xK17f2OWo1P/o3Oz0zy23atS0JomSan5EoJw5F4rtshL6KUzJbm643enzdrv3N9cd/zRHIERCXSq0G/Dcw+d57KELzCzOU5uew6dJEJv3Qa1jZKTGKdGoNFZpatuqjYYJVG9TSXCKakhJlg1oLB7hrTzj"
 @"6u3bf18JFYZZeVe1UuXERHbxrmQJfVjtbR9Es+8ww/CJSppRadZ3d/7WV6+88dn/9OFHKG/expYWtEGFYzVuKUkd+nlIhYrCxTkfCCMhvQgpiBf7+JiRf0xFhJ2ZYfX8OX744x/jpVu3/MvttohExJQwzeNTaffM"
 @"zAwraUyMwfuCsizICsGdbp/tnT1mW3UWW01iD4nURJFkqaaZSxdYmp7/5Vd3dn/5zV5XGBW01p5anvOf+sAHWDp6nGiqTpQmlMoHmLwdcR79gaBvlOeFMQGh4+5MQBzYoqQsCsoyR2cZ2GDK4+kpXnn5ZdY2tv5O"
 @"pCMKX44/01X8SH9o7eXebsQ9JTRR1RAnZwiHHDQMRxRhzAGFLfjGyy/z4YcvMdusk5VDokhRcwJhqklbqkSXIbiQOlDOgoqgqzoWYXKI8wJhQ98RIfE6oMcyJYlcjGo0+cD73s9ffvM6b33h82AMzyzPdx9dnmFG"
 @"RTRUpS8tJN54rBc04oS0sMxMTzM/VUf7klRo4igmVRLpJWes53gtgdvev9ntiwUlvv+H3/80F8+fI5qeRdZr2FF9ybtq3M2II1n5uYp44CsRdWdNSCFMAPK6rMAXObLi8BdFjq5Pcaef86VvvUzhDLGOEKVnhKIY"
 @"D2Z27zgx9gGFfjzjsW6Tu8EJj4wVb9+6deobV9689oPnz5Kv3UGWhlw6kAZXVMM31KggHIXKjArfftwqCbmOVOLgphETfHytiOopn/r4R/nS1Vf99s11nj1yjLk4DO2KtEZHKuiuGIuxhmWVImenSdKUqTgikZqa"
 @"joh1DRGFOq7MM07HdZ6yy3S7b3366XOnf+1DTz9NrdFEN5oYpbDehPaPr1DpvrIW44BlVPf04zpoaGaX+KLAFVlQTMxyhHWUhaF+dI4/ff07vHz1iojjaCwzIu5twI86KvfNAJ5II8Q7ZfsTkO5ArarEi0fFYSWx"
 @"zrb3uu1feOqxx0gtkGV46SgwAYdixLiTESZwjmnZVb9RTpAB91+j+lY+9BANlmzYY7bVopHGuNt3eWhmhlYa02i2mF6Yo9FqESeaVEkSHRL4CMF0mrIwNcXs1BRz0/NMT88EvEs9QitHhKDIcxIl/5Mf/cFPcfrk"
 @"MXS9iUzrQVm+wvSMxlaAqwQVqsWrFIFdGdSgbKWP6soiBHdFjslzvDWUgww1Ncv2VJ1//vvPc3e3/YupCkKxpa8Kjn7U/dlvKrybIdV+cgr0BCBHTDSbXOW5R1MylQxwPRVFXLl1Wzz/wov+x59+lrLTRVCCcQgZ"
 @"hVGncYT2GidFkPYvw+CLsTKDiEGEIEA4h3MizDZyo8ErDudKhLcMOj0+eOlRorvr9N56m+bSEs3FJWYWlkh0gi8KBp0Ow94etc422uzRak6zcuJEKMNFQRfbW0+vv0uhFT2zhywzfvAvPMel06fxHlSahAlhE/5N"
 @"jOq3vrIozlRCsiHCdNbgbNWZL4MihTNF9d+h3VZ4aCwv8/uvvMSbt26LehTjjMVUwcuhJbR3j2H2E/l73yPEQYqvrKIuNSGGN5LdurO1/cr5k6f/09VWi3x3m8QGNLIVUHpXTTCphAgqFXkp93uOQqiQSqgRy7NC"
 @"h1R4El/miLykHAyxpuDosRW6O1sUgyErR44xv3yEZHqGuDFNfWaextQ0jTgm0gmLR49y5Nw5miurJDOz6FoNrSJiKTFZwd3tHVbOnuTR913CZIba9DSqVseJMGmTSuF3lOcFiESJK81Yi9uZcPJcaccCQ96E/qgp"
 @"g4rxMCuprR7ltcGAf/3FL/7YYFh8J3ZgvMMIN8GIFjgxobos3p1odugCynEks081k5XUlhP7DDZJ4L/3+8Pv9Pr9X7j02COIfIjp9YLi7GjEaIXslhV8cFQdCijravFGJrSy+64CQXk7ehgWrGfQ6aKU4uRDF+i2"
 @"e2SbHaZbs8RLs9ipepgmYyFSkqRRY3pxiebyKi5JkVqHqK10tNs7rG/vsnziDI88eYm99i5Kp9RnZvBSBUyr92Hqy0gk3bqgCV7leq4sw79N6GPaShnKlQWuDPmftY68LPGtWThyjF97/gu8dv3GT0aVuKvBj8cW"
 @"TdafQ+dBvOcRVPecuwMw+8nkXgg5HryLHE0QEXgviNDc2dr8RRf5X3jq0Ufob20FaWTvqtMmK9S2CgnquHguqvEBsqrEyMrmV93tssSYgtKWGGvxVhAZQW9nDyNjLj7zLKpe4/qNtym7XabjmCjSDPIM7zxSS3ys"
 @"iaamiJM6oiwp9/bYWbtDJ+9y/OJFTpx5iPXbt8DkTM8tIqJov5Xmgs41rgy4lqok5owJ6oemDCfPmrBYpcUWWaUqHCCWZWmQUtM4/zC/9bU/4/mv/JlQOsYISy4dvgKLjcHdvipmiAewnwej0Hsp1ZMaQhPoKD/q"
 @"E4Kp9KqlEBgl+PxXvyaOzS35D66eonvtCjXbR+PwsUaZEl1EoZ7qDI7QM5SyxEuFswpUGToXlvHgLDcqSVmLsh4pJWm9wd7WBg7D6ccfY/mRR7j9+lVu3drE5DeRwlDXkiSNMc6Q3b4FaW1cipq5cIHTC1MUWc6N"
 @"y1fxZcn8wmrw28YihRlbIO9KnHFVxFkGGESFrHZ2v9ZpTYkrM2RmsVZQAtKGdlLz5Bm+cOVNfvsPv5h4BV6YMd0N6RFO4LwIhJZR0OL3xx/5dxF8Ve+hsLW/hNV4M+lHJnZfo9n50BcrSsfbN26/sLSy/L9eXZwj"
 @"6+yGdk8U4Uej2KpcylMNRBwNiJcTwzpcgCjYSnEeE0Cx3hqc9FBhOfO9NlvrW+ikxsrZ0yyeOUl9ZY763CzJ9BxqZoF4boHG/BIzK6ssnjzN4olT1FpNtjc2uXvtGtIZpmemUWkjTCmrugFjcJKposuyxBXh1Lmy"
 @"rATWTTCbZYEpcsgLXBmCEuEMNiuYOn6KV3oDfvVzv/M3d/v9r6pqrNykdfNCYA/IKz2YWMWkns87LuB+G9+PUVCyIuEHQk5o0ygX8I2FtazMt370r33i+37r/VNz2Dt3SFKFbAU4vdYRiUoCf7wWZvPpNEUmYYSc"
 @"r9Sgxj7H+XExWPjAcQhMIIktSrLeHvmgRxRrmjMLzCytUJ9fRDamUFFUFWU9Psvpt9u0t7bobd4NMpVxRL1WQ8cRJZ7Su+CTlR6TU8Zq+NZUPcwqUbf7vEhThgCG0lD6HFyBzQpaR0/yZuH5b37nc7x+57pQWmPK"
 @"oBNqXUUh84R0hYNKTA+iNPLAC3h4D0pUg6LDzlEOlBfYSJF7w5mZ5qf/xsd/4NeenJ9nuHmbSIaxA2iFqkYMxEmKqteCqkQc5hYJJffHt/l9jIm3dnzqdaQQOg04E5tjhl2KbpeyF3CpIoqhEaNrMU5V/EZrEMaG"
 @"tpJURHENHSVBU8Z7ClsEPh8SJQIGR1TQSVsU+5GmqSgEIxxQaShtWQ0YcTgzwLqS+upxLmcl/+xzn+fq2prQcVAyLE2IOO0IgThSH2QfsfCgMjEPZEIPgGkQBxDcvkot/EjVfYTT0JJhP3/pys2b3dbC7KeOHT2C"
 @"GBTIQQ54ijBFI0y7FvsjDxgnx6OJnXY8UMtXInXOWURF31JKQZxArYGoNVD1GnEjIU6CgJDSEhFpdBSTJHUa9SnqtSZxPVgAKxTGiXAqyhJfjiDwoTDtbOA92jzH5kFj1FazJ7wNcymcrQIaayiLIQ5JvHKMb6xv"
 @"89/+zr/959c3Np6SscA4gzUVTnU03Go0jpw/39d3dQKpAKxUcHs57vJX6UX1hkhINJDIACSabSSf/oH3PfVrHz9/kdksZ9Dbw2lBHMekcYqqpURJGrTPtKrwNKMKkAo3OKo5VsKzWuswq6hWJ44aCHQ1GyJDUAZU"
 @"oYqrmX3B3AoH0giEsxibU5YlRWGwRfBjzpQh35OMfTXOB4GEPMcWeZi1a+0Yrj/CuhpjKMsSldQZtKb4gytv8bt/+pWf2m13fl3FKs5kUTgn8SPdgFHbrFJCHkHIvtvT954SleIQVP4IqiTFQRWvkXysEqCRAVit"
 @"Vay8nE89Tz91/sznPvX4oxyPI+j2g5RlGk6LimKUDooOoiqnSSURo4nYFYXKe4fDIbVC6ZS4XidN6mgVhWGKhGHGI+VCpapeY8UQ8taFpmqeU+Y5RZaNp8H4KpoO824DuHYcpFTlsFG/Toz+qRhPAHGtwbqL+M1v"
 @"vcjvv/KKcLZERWEqOE6OIRKjmVZOjKAT4sBYcf5/sYCMSS8VC7eaF+vDoQmSw1KSCBFrpVeF0InN+ttPnVjZ+vEnn+ZImlYz+SpOexwhoxgh1XiQsK6gFr4CuY5xpd6FvDFS6FpKFKfoOAmFAAJJRKkwzVppFZCF"
 @"Pij4GltQZDlukFNmQ8rBkLLIAz1AhvE/Ko6qibJufPoCyLcIs3hdhUirUpI4qSGkZDvL+dcvvMS/v/KmkDpGC0smLc5DUqoQ4TIhnzxGxx70e5OtvPcqpYkHUWp6p9mtvkLs+krj0o1GjEwggq2gcNjrkRSrWker"
 @"Sdpir9Nje+02y0ePsVKbAZ9R5DlkOaqa6iyVDPgWVQbR1GocKYH8gazkS2zWw0YJUqdhPq0MMo9SB2EDWc2HD+PIDSbPgghdfxgGNBZB2EcIidQaj0IKW80NNtgymE6fh8UrbVnRwiVJXEMlKd0s59bdNXId07Um"
 @"IOYqPgZCoI3HCRt0Ryv86BiG6+9fnfu6Dv7dD5Z+0CPrJx3mfSSLygzIfbKFG12gA4NdU8LNH11aZLbRYLe9w50bN+jW9phbnGa63iRyHp8FvIqXouqqR6iqlygqOz1JbrQDEKJAyH4wl0oGHkKcIFRUBTo6PDhj"
 @"KIuwgCbPsXmBMzYQNCMdBlpWVG8flPgRFf/f5EVII6RA1hukSY0sL9hcu8vdjS2csxw/c54zC0t85drbGOmRNvRP3XikgBsXyA+Aqb87ccLvjiN/X1G8CiIOJPj3YDXcuI0VmLoRgTcea3lhdXaW2SilNrdAxxTs"
 @"dntsXNmm3qiztDjPTHOKNEqhMJgsBzMELVFRglYxTkjMaNZCaXB5KBT7qhUz8p0y0kipUTLUWX11Aq0pKat0wFqH9IIojlE68CmkjChkECvwpYWhgcITJSkyCtCQofHcuH2Xze1tyrIkiRNqUZ2W1JyanqEey3jP"
 @"2yIREpzAVpZjfPLGZa39GUninpN32HyId+7IT6Kc3uUN/j4NZ7+PCanQ2yNehB1DJUOhVnqYaqa/dWJujhknsEqyUIu5dmeN7u01tnZ22eq0idOE+ekZFmfmmW21iCOHNwV5ERBdWgSfppzHYXBuSJZnGOuwlaqR"
 @"qBRzYxnyvXGnzDlMFcjokTy8UgEZJxQWjfFhHmKkY+LZaewM9IqMrZ1N2u0d+rtdhu1+GNqoFK1Gg5nWFNpBTQpOzc+x3Gj80k67+7MjbrxTB6gn9zkj8QAL9W5rpPexL+J+B/oOHzSKmA4LckaWwXmwQqB8mF20"
 @"MjvLUquFznNmlxZwAi6/fQ0tBI1ai7Io2Ntoc22nz9Vkk4F1zK8uc/rECeZbNaYlRM4TmQKVZwyHRcjHSksxHFYNUIWINLGKAsq/mjDjfOBvmBFXz5WBY6/reAy61qQ5N03aaECaMnSet3d3ee3621y/eZOaMdS7"
 @"Q3RW0GjVmWo1w+dYy9zcHI00ZdAfMlWvcX5x6TNXdrs/6yTjdMMJX4nGH+ba7ld5vXcNHnj0zqFR0Lu8Nhn4jvJBf6Cb4TFOIIXmkfPnWZyeJtGS6ZVlLr/yGkWRszQ9Bc6TeWB6jjtlwTdv3+JGr3dEX7uxOvvt"
 @"1//msYW5nz65tMi5lWWOz88yPTVDUhqifh/d6xFHPYphViX+Yb6TUiEfDfWBILoQCwWRJKrXqU9NEbemiaanIa2z5zzrW5u8efcul2/d4traXdZ2dz+YD7JXzk9Nd79n5QSz0w3imqbZnKLeaLDXbjM0hmNHjyI7"
 @"bUpjeP+Zh/natZsXNo25rKvSo7vHz3kxiWjjf9GXPqxheOgiCsY5z727SExc2T74tCpwe8v89NT86fMPoaemcInkzb1tvvn2VXySkEQxnf6AtoLbwx6v3l3nrV5fFLGmjl1b7+58dq29/de/fuUKrTT90cWZ2d9a"
 @"nl/ixNQUR6cazLZaNBcWiJwlBmIdZsFrrVEqULOtD6xi40IVxEQJm8awvdfl7o011vZ2ubmxxdr29t/tDvq/7azrqiiet1Jt+ygp3txrt0qudx9dXmaRhGGcMF9vYpstXl/fIGu1mJmbJVKao6tHWZ5beOPu2h2h"
 @"KqaUO8QdCSHfs130IL5QvJOtfVAnOtm1mCTkKxGo2tJBI0k5c/yYr0cKZw2DQZ98OPjHkZA/J4wnt+bvZ6Z8oVcUn8+sL7wOsayWnkjJWAgZSyFaIZ+z2ziPgvlI6VNJWnssiZPHtFKfTaKIRprSrNep6WiE26E0"
 @"hrwoGAyHZKWhb82vZHn2Qp4NXzVlecfjCyFlrLScV0rOeyico2u8WyuNWwszgiGRcrWm1HNa6VWt1BGEpDTmmtS6VavV/qtUx+TWcntnO2lnWeGqBnhgFoiJfsN+3/WwZ/xeruyBS2nfTYR6b8VbTkxwD4p7flwI"
 @"jytwsKrKVV4ERcDwXak8VAOZg5Z26EBIaCol5733hXV+23mK0lis9dUMif1vN6bqh2J1NZ4BAUQiFBpiLYmVOqmVOOJxuXe2cI6uhW3nXM9WI1yZmEU/Yl1N5nJ21F0Y44nEGFW3P0Rz0mKJMdb2zxO4/MdbwIlF"
 @"FAfY9hKtguJTpcI/poKNsJDWW0yl7uCr8pmqFlxUMxZkddui4iLacefc70MQRw/QiTGmxOMPMHV1dX0KUFLEBI3vYlQPtFUi7tinXQkRRrqOaZB+v7hvXKi4mAngl3VuQiipGinw7vn5f5wFfJDjfJglF2IfduEI"
 @"43qUEBVp1qEqhtIIcWqdD0NIx5D1iYHMvsrxmJAOrqhXoy7ISGk4DH8UKHvQpI9kR7wHlB83puXEtJoQXYsqoh2BiirBvtEcBy/GKh4jAJJzttpIB2uaB1i1D7B4hz3r9woqxYPsAn9As/LBFnAEOhV+Av8y0m2Z"
 @"qKki7Fhi301ACURV2WFCtU+MpUsY40jcSE5hLAnmx0MrxT1A4X2+4z3XcA8n2VW4nMnW2ehRSfbnS3nnq35ehVZwYlzj9Iw67SLUbydN6yEB4p+3HCMe5OQ9cGVgIqURk2pP/h64ot/3BWI0Us1PQBWr1+296lH4"
 @"8VyLkX7byOSNMmVZddjsxGg2cS9pZ3KM3j0JkR+rK46Luvvj2MdAFTHWkPPj0x26tJOf4yoy0BjjcthzPGTYx4MGMe/djXjAE/hO7QspDmsM34t2q5z8mAh1v06NuOe9woe64qi64ZzYhyl6d0BlYxKoPPoTtuKA"
 @"yImxb26kk+rvF/3DU/E2QlI+hgiJ/cXyHLQg+4Xq/QDuvgX8c0xq+a4W8H9pYCPGsgPVLNgJ4saIUOoP1ai5p9Yq9uVLhN/ng7sJktqkKJx4D6sxHiE7SQkX+5C++6PrCVrBZO9OTnBQJrVRD1kR/+cIUt7lkI5/"
 @"pvn/y5e4D87Pod7osPKTv89lHKwOwXuVOO4t+72TD5r8UTDJnknt1XslsJhwDe/Vnj0w3uG7LGAfAGF/N93f7/bLTwDGw66tdMKqiwyci4mOxnve9Hv9rQf/+YEv9wCf6Q+qd+yvIt/VPfx5CiXvZiz/PzX85Nuf"
 @"AbBKAAAAAElFTkSuQmCC"; break;
 case 2: encoded =
 @"iVBORw0KGgoAAAANSUhEUgAAAHAAAABwCAYAAADG4PRLAAABWGlDQ1BJQ0MgUHJvZmlsZQAAeJx9kLFLw1AQxr9WpaB1EB0cHDKJQ5SSCro4tBVEcQhVweqUvqapkMZHkiIFN/+Bgv+BCs5uFoc6OjgIopPo5uSk"
 @"4KLleS+JpCJ6j+N+fO+74zggOW5wbvcDqDu+W1zKK5ulLSX1jAS9IAzm8Zyur0r+rj/j/T703k7LWb///43Biukxqp+UGcZdH0ioxPqezyXvE4+5tBRxS7IV8onkcsjngWe9WCC+JlZYzagQvxCr5R7d6uG63WDR"
 @"DnL7tOlsrMk5lBNYxA48cNgw0IQCHdk//LOBv4BdcjfhUp+FGnzqyZEiJ5jEy3DAMAOVWEOGUpN3ju53F91PjbWDJ2ChI4S4iLWVDnA2Rydrx9rUPDAyBFy1ueEagdRHmaxWgddTYLgEjN5Qz7ZXzWrh9uk8MPAo"
 @"xNskkDoEui0hPo6E6B5T8wNw6XwBA6diE8HYWhMAAEQiSURBVHjazb15lF3Xdd752/ucO7xXE4ACCAIECY7gPImUKNKSZcmSLMmSLcdK5NixLTuD0x0n3W57LS93eiXttXrJSdqrYymy27PlIVLkyHFiuz0otiTK"
 @"1khTFGcSJEGABDEUUIUaXr3h3nvO7j/ufa9eFQoTAdp5WLWAQr26796zz56//R1xk9NYWaExYCbEGDELCGsvs8DGl6oSY+RiXiLSXN/O+p4z/Xz4+xuvMf47Z/v9V/OZ5/5dxUyA83+m8XUQETCtv5f1vyMi9VVF"
 @"EARE8GZG/We0FOdc1HUfdh7vfa1eNv6EbPy3bfJvO+vCsmEN/naeyRAioEhzG+sEWb+puUvDNyLFELBQ37zZOR9kXICvdseOX+Mse/oSLo+c531d7Gdc6AXWb7ZanQIiuva/ZpgNtVUaTQW/UYXNzn+3XgrNW7tG"
 @"c7OyfhHNLlyI4/e10ZTWJu7i7ru+1vj3m6/FelMOZnFTIa8JxtY96/D9Mr4oomuKA/hxjdtw2b8lIyKX/PPHF8dMR/t8/Suetw88/WdyibTazng9AUwEZKiRgBh+TeFqc1Y/XDzr+r0Wvm+4xOe65jqTO+YcDNt0"
 @"4YXa1Njad2NLJI0gbfPrn2dwcyHxwJm0db0Q5cwBD833jXb69Q84vjB20aazvllOX9BNrm6NbR9/DmlWengNOctuHz6HIOuc/rhGy4brjwvUZMN9je7HTttmdQRoa/dmNtpMa89nZ4hQ2RBUrd8E9draOncyFKqI"
 @"QhyLRAV8bVdfq4hq86W203Sv+ZLxBW3WSGTTxYBRtL1+49r4g4+F4KxtkDrybv5/KG3Z3CyarN2hmY3eJuLq37G1zTG8TxuZ6800284j0Bk3pXFtE9raphrel18fdY7vhNfSv63tyJG6NA+oTa4z0r4Nmrl+UXRD"
 @"IMC6/Whn+GgZz6W00Zux0Hy9mR5/fwQ3trgiiNbaJ+P3Yc110LGo8tzR6UbLdrqlW9vKYrUQ/dob1wR5Ib7t/FKIsd0/ZldHiy614ECIUpshEcWAuNH0yZqgDF1bFtnw9waTPQxUzCKoAjrSwtGFzcYMfK1RqmNa"
 @"K9rkYcN917xfxjypxeY6ti6Qr3PWeFpgNXIP57GONrYWw0DGr33K+e2Si9U8GTlHaaIqqYUnuhYiixJHJlVON5MjCUoT+MRNQ/xR5WLMeEvzXhMFqe9B0LFgJ9SXpzGXtZTHzKOs8xGGjYRWR4YVWGj85FC74xnd"
 @"wIXGFTYejpnVGvjavvS0yE5Q0DoZrXe4EEVBPaIK4tYSViQdmUMbC45iLNZ2t472iIgg6mcbEzspIhlAtLiiMcyLxcJE01qD3KyopCY6BW4WiytmsYPEFbO4IhY7MjKGkgo6BTppIplYXAErosUVLBZikWg2UjKz"
 @"WFtns0bo9qoEdlaBS7zUApRz/EQwE0QVU60FhyAqqCSIT0DdrKmbRXSyDvas8KZTYANEMhFJQaciNjCNHTEbWKiOWrSiUQQwnTR0qjazccUszFusOsThDrACFRBZwXRKBNRJ6nxydbOfcGaFEFecWGFmA1M3a/jd"
 @"Jm7WTFLMCmKYFysPEqywaAOx8pCJzteBVIBRrdheVY673rxvSDAEEMUTbc0imV1EHUk2T0DHwnNtzJ+JYuIwcYgqIoo4h7hkLz67XZPsNueSqxFJMZBQL5bF6ki0MF/F2AlV7Fg1eJyq6lBVIIr6dDLNstvzVv66"
 @"Vrv1sSzLSdKEvJWRpinBIJohEgmhpCpKqqKiKCLdXkmvu/qj/V73wRDDPCHMY1bgk70+SfepT/dpkt/jk+yHxDmUDLMSiwNiFYlV+dEqrv53q9x+M91PHICEMaN7uhE9c8KxUUtt3btFmlTJdC2IMV6rbKL2dyOT"
 @"qIqJB/Woc7XwRCclSff5LL9H1e8CvztE/ZGyHIbx9kveudk8S/73PEuZmGixdXoL26e2kU9MkE9OMrV1K7OX7WDb7CzbZrcyPTVB5lNwCaWkdIrISi+Q+ISJtiPRiMSKUFVU/YJed5WlU/MfW1qYZ/nUAt2VRZaX"
 @"V5ifX+bkwilWuz16/QFViIQQKcqKMkaMeiNq4v5FCgR0sgo2iDEcqverNYttdeQ4SgvGQ5JXoTQx1gGdpi3MQp0+BBsLCOJ5q3m9U073dTb0d2PCQxPQoQCTvaibdapTVdQpkNR7v6s9MfWxLdtm2XH5FezcMcvl"
 @"O7ax96o9XLbzMianp5iYmCKfmsHSScoo9MqACeStjDxLcJIgMUCIdAs4vhI5PD9gsVvRbuXMTCpTuZCngpM6sMlSoZU6cgepGF4iSiQUffrdPp1Oh06nQ6/XZ/7kPEcOv8Lc/Enm5k9xcm6Bxfl5Fk+epN9d/FGz"
 @"/tdD0f2yhAqLEaGs13i48E18vVkZ73ws3JpVE0TTNmbNBxn137I+sju/nh6nlYAQ13yjjQAduBRxSYqm+zRJ9yE65Vyy94Zrbvjp62+4kauvv46rrtnLnquuYtvsVtIsJ/EZPkkpDLpFYFBBt6zolgW9fmRQRLw6"
 @"JlueVqKkCokTFEdnAHPLwtGlSHdQ0s4dMxNCO4ukGhECFY5ggpNI7oyWh8xD6gTn6yjVqaKqJM7jnSMxCFVJUfbp91dYODnHyWOv8Luf+n0+/9n/fo93YT6U/UOECrMSrELiMCQaKsq5uj52Rhc1XHc/nosME7Nz"
 @"NVjHbfTae+X09zWaZ02KgHrEecSn+8Sl+1zSur+s4sp73vWen/6pn/gxJqZnWYnCajCqKjAIBYNKsWDEwYAQldKECk+MgprgnRI9eIFUhEyMxNX5WxWMoopUlSAxggnBlBCFaEoVY20NzOEQEgyv4B2kXlCBijot"
 @"iUUkBiNUfQTFO8hUyZwjS3NuuvkWsjvvotXezTPP7H/4+JGDtzvf2hdssB8TiHXUuK4aa6fXPs+3NzksuDhxySiRX19NsosLYqSp3TX5lmqCOI/6dK8m2e1J1ro/BLjpppv/5f/2Ez/JNdfuYRBLXjy6xNJAGZgi"
 @"LsElDpcoiXMkAmqgMSDRKIMQolI1a+A9qDOiU4J4ugGWB8JSHzo9o4xC4h2JF1xTgQnmCU3tN1oANcQJ1hSJbJgeAGGYzwmYB5cYzoQ89cSQ8tnPHWFqapbts5M89NUvf03VbTGzLtgSgG7os8oFrbGcFsWKCLru"
 @"x2O1yHFNO7+mq4y1/nXU36t/6ojqQfwk4mbFt+4X3/qJNM1/4oPf831s330tT790Cp/mXLVzK1NJQp56nGtWMQpq1kT+guGozGHm1jafRKJBQJFoxBCoKqMsI2UFVVRiAAsRi0ZsonyJhoVIGY1oSghKFZSyUspK"
 @"sOarrKAKEIIQAlhQKIXcCztm2+zf32fuVIuXTjjueeN7uf9Nb/p4FeKKT/N7RBXFYZKAKWLDGqwCrvlbNvjEuCH9kBGsYlTYrjeFXWQLTs5gAuqKikmd80mdbM3i83vSbOInBoPiN+7/pjdz/5vfxkKnT4wTHD8R"
 @"2HpZwvatRhbAiUfUoSKo1n7IqdbWGMNJwImRam1C1QyNYFGxoMRKiCVYZVi0kZaFGIhEgkUqC0SLUIXaRAYjlLFODYJRWqQkYmYoihNP6lISVVq02L4l55Enl3hk/ypJNkF31bGwmvId3/WDbN267TOYm1XNblMV"
 @"xCnimqBOx/t7zR85/zxg6Lp0fZvGLl54JuuuKAiqDlU/K5ruc0l+TwyRXZfv/qEPfu8PEDSlDILTFiv9wCvH+2zfkrGlVZtLUXBS55BOINFGYGo4FZzWftC7WtCM/JsQoxKb3T1e9bGmxGYoAYhWN3qrIFRBKAIM"
 @"KqMMUEWHmMM7JfcwkQkTmTLplW3b4Onn+nzxq0tEl1FGwTTjyFzF7M67eNs730cZBk94n91m6uuMUBScNtq01m2xdd2bcWu2pnWbCVFBkGhNyefMpZ61C23SiRv9TEd+ub6xuixmOEz9LvVu1jv3I1Ux+KX3fPt3"
 @"cO2+21npBZw6opaQKounPAsnYXZbQpZUKOCdkIyCC8h8JPHgnCPxSuIgdYp3tXZGAtECJnEYO+Gc4VXwWgcs0vg9sdqMBZRgyiAogyAUFRSVoNGROsdkqky3YEvbmMoDu7c6Flcin/9Kl/5gBi2NQRUppKAoEw4e"
 @"Vr7lHd/LDbfc8qUilIe8n3jHMH1CXB3YjRXcZRNlGAaJQzcxDg8Zvpxz/gxdCDtPDWwuaLJ2IyJoE8DU1ZYkFZ9cnab5XVVR/cVtd7zuJ7/vh/8ZC/16xyYO0AgkqDqWlyuSXJmeVop+hRsKSGzUZ43RICpKrCNH"
 @"MRKNOAmoBBRrfN0awss7IU+VdiakznDSFKFjwGIgxlBDJWMAAomHycSYaSnTGUxn0PYwM+kZDIQ//rNFji74OmKNnuBACFB5FpYHtCemuP6ay/naV//yFEJArGNmdaltDAsothGXIOfppsCpS8DielCeXIgAR4Zy"
 @"g9prU/N0oL7l0vwudcnVeXvyp3/4n/xzpi+/jsOnClySkycCkqAWEQYUIiwuG1smHO2WUBaQOPAqjT8UEqekTmmlwkRLmZ7wbJlybJlKmG4ntLOUxCWoJDg8ThKSRGnnysxkwsREQruVkGeeLHW0UkeWOvLU0c6V"
 @"6UnPtinHZTOwbdIxk8OEVyazBCfwmc8vsv85xScpkQJTj5jgSk+oIqtVxfG5Djdffz1F78QDzz//+C8nqd8VQpiD2BvvAOmwQH9a3jdu5XRTC+iHHQOzOEre1yOuNssL9TToxLDYaSoIDhNfF6zrCGw21XTfoCgP"
 @"vvPdb+HmOx/gxbmI+An6ZWC1qBNw0z5iHjOlHwLPvNzj5j1tdkwAiZCYYgE6BRQ9oA8x1FFkp4h0+4F+L7KyCovLxomFyPwpY6ETWC0CQSJJqrRajiyDLBFy70gTxTnFeSFNhalJYdusotuECfVMppCmMJGAJPDF"
 @"h1Y4cDiST+QURUGFI0YjwSBGqhCwQuivJhw8bLzrO36AJ5/44h+ePDr3oy6ZfG9pnT9yMcwrShAZtaCUoW+20/uoZ8jN/ZkQzReGwJJR4h7HKuWmHhWXpklydVkOnti558o/fN/7v4duKZCkDbq7oigER53rgaek"
 @"IgJLHeX4iQG3X5fx9Yc7HHzR6JeBE/M9Ts4b3YFAjKROSETrQKRUen2l1zc6PaFTQDcYwYHLM3zqMYuEskTKAEVBbUnXNrDzRjsPTM14prd5ZnYELt9qvOXurVx3Vc7csYCTNqoRxdCKuufnlMKMqjJCITjJWFwp"
 @"ufOOa3nvd36QX/35j3R8K7sthmK/hPDleinDJp2K8w8onahfhwNdA+ueub93Wr+vaQnR9PKs6S44yWadpvuc97vLGBe/74d+5EN33PdOTi4VkKREDBUhUUUkginRoLSKKigOYSrzLLxsPP31gs8+uMhzRzyvHDNW"
 @"lj3dMkNo0UpaTOQtJrI2mUvrcF0UUY94RVLIpxJas0I+XSfgiuDM4UhJSEnUkfgElRQlx6yNlTlWwuIgsnX7BAsHSvY/dJJbbtvJy8cr+iVIrKs8dXnMYSixMspSCEHIckerHbjzzuvZ/8w33n/k+NyfJS67JYa4"
 @"aDEerRvIsWkXxZFRPd+E4jQBnhn6JpsIr+lmN8Krc766rycuQbT1hiRJb+wPBk/c+ro3fO37/9E/Z6GbU4knNt12R+3bnNalpkAkkFANIrMzkd6c8Ae//jI3XruTqcuVY0uQZC1aiWcyS5lueaZyJU8iKgHDqCpP"
 @"VUmdSqggLUinlNa2BM2VGKWOU0rBRfARXKwh7U4EL4oTIUuUVAr27trCZT7ny//pAIef7HP3AzvoSsWplVCjCJooMYqvoRMVVKUQgpG3lNaEcMUV27hqz1a+9KUvvdWivTkGezgSjgpVZ7T2dnZs6FmCmCa6Ow2Z"
 @"Pa51sqnwxs1nHa8nqPPg0n3ete4X1amk3X7Th/7pjz2w/YrbWViJiPMEAwuCKiSp4KVuvVRAqFIkllw+lfOF3z/OgW84VAtuv2eazqpyarEkyTw+K8lyyNuRrAWaNQKTqoZGOCATXNvIZhytbR6XNZDKEHHR8FR4"
 @"wJPipTbFXoRUI2Z9Ji9zbGs7Hvr9F+kc6jJYKclbjn13T3P0xComWV3mbFDTFgULTQXHIvmEMj2dolpy5x3XceyVl3jm6ac+nCTpdVWsjkJ1CMI6OOGFvEYCPB0HaGfxezIynWuFa60L1eox9bPOtd6Qpu1vGQwG"
 @"3/jWb/u2/+ft7/teji4o4rLa14T6Qb1TfBpRcY0JTajKyOy08PJjFZ/99Clmt8yiXgi2yq13TTK/PGC1ElqtJmJsKxMtJUsUX6M1UAX1gmSKTgqT21ImtjkkMayMUAkuCB7FKThfdx68KIlTjIKpKWHXtpSnPv8o"
 @"i8+vkGhOaZGFuT73PLCVUozFjkdFSaQ2y2ZSV4GCARV5G6amHN5FJtrC9dfu4eG//vKbF1eWP49YQVU8ytj014X2B8dMaJOb2OkXkI3Byijfa7AtKiAe0wQ0mRSfXuez1htCYcXOK3Z+5Af/px/Dkl30SoeJEKMR"
 @"Yh1BOickSb3oESFGyF1kkow//e1jrB5rs21WmZyaouoFJloDrrtlC8eWFkATpicSZiYC062SVqo47+rym1PUCS6P5DORqdlIe0aIDsrSoIgQ6mJ0ooL6uhjuE0G1ZKJdccXsFC9/6UXmnztFy1HnlKIsn+ozOV1x"
 @"2727ODrfRUTw5nBNDTjEQAj1Gua5NFGvpyj6XLn3cix0+frXvvKHXnSqimHOrJq3BslmMdY59KgmenaTquOyWlNA2wQJZZyGah92jKh7f6IOUTerSXK1iE7FUB1573d+kMv23Mryag2GDVWkbEpVRTCqEImhDl4M"
 @"gapk50zCwW+scmR/yWVbJ8m8gK6Se8ex5ypYLnj7A9vYsmVAkkPSErIJJZ/wtKdgciYyOR2ZmjGmpz1bpxO2Tjmm20orB5/VaYHP6q88dbRSIc+MVgozEyU3XbWV488e5vjzJ8m8J1gJrCJxFaXiC3/2Ar2TBTu3"
 @"eZxGXALOQeIM763WanEQPWUp9PtGZ9Vz8EifN73tPdy476afKQbVUfXZbYIb4WFH4Kx1QpOzaKDzY8KzTadnRlgydU2JrKnj6Vqfry4R+VR8cnWWtN9UFuWBu95wzy//gx/+cU51klE3IBpUwQhNZd87JU3qpD9W"
 @"ymQGWZXwx799FOtMsX3Wk7SUJFOStCJPM5ZP9dl9ecqVV2esdDokeU47T8izQOaalpBEcILPlGwSJmYgyYVeZRT9iPWAYHhqf+fVSNWR+4J9u7Zw4tmTHPrGUTLxdaXGSmIsgArnIounOuATbrl7N8srBd6v9a8t"
 @"QqzqZ60tzBAArHS6FZPTE2ybneBrX3rwEbXiabM4bxaLIX5t2PY9P8zfpm39tcx/pGHNBeNwBkCG4Ng6dDZxiPhdzrlZgmQzW7Z8/Lu/7x8Qky10B6528EAMQlXW1ZWqMMrSGoEGCCWXb8l4/IunOP5iyY6tbXxS"
 @"4X1E8VhMUQlMiOfwo11mzPG6OyZotUpc4kmzSJ4o7VTJc2i1jawVmciN6QwmcyFPjMRB4oWkSdyzzMhzJffK9VdOsvJKhwMPLTBNm1QTEnVNHTUgMgDpkDnPI3/5It0TK+zenpI4I0+FLA2kHrw3vNRuougb/Y7S"
 @"6UC3pzx/YMDNd76VB9765p8uBuVB59J9Jh4RX4O9RmKRc0ajuhbC2hj4yBqUmjSIYllnYteq4wLqoP7wWRE36zXdF0J15B3f9l5uuPk+js2voi4hRggBqhKq0igKKAqoqqbHVpZMtZTVk4Evf2aO6Xwan1egOWhE"
 @"XRdt4kWv0JKUI88sMa2eW67PSLWHkxaaKj4V0tSRJEqWCu1cmMyFiURJndSJv681I0shyzyZj1y9O2NwPPDMl08wIVtIZYJEUlKXkDiPjvLVQJYEOie7fOML+7l8W8ZE5mgljjyFLDGyBFQjFoxyAP0udDtGdyVy"
 @"6qTn4KHIO971PWyb3X2wClaoS/ciTaFbXd2CGwlQN3QoNhPguFA2nSdiDIq+BqpBHeJ8irpZ9em+oqyO7r7iio+9490fYGExI1QOqopYOqrgCSHWjdaKsS/DgjCZpHzuD45y8mVlcnKGgKOSutEqEZwWdZKeKEkW"
 @"8JZw7Lku2zLh+r0pRknpQdRQZ7hE8QmkCUzkykSmpN5IPSQe8gzylpH6kr1X5GRlxf4vzjFRbqXdJPVeErwmOPWo96h6VDyg5C7h8S8do3uqy/YdQpoE8sSTpkaaGE4NCxXFoKLfq+ivGoOllLKb8vxzBVl+G9/6"
 @"7vdhgPfpPsSlom6EYjgNmb4JtEXXC8xgk4lY20SwUajrnKI4Ta5Wl79OEjerFlfe+77vJp/ew6lTFWaeQVlRlEZRRooKYmlQGTEIZQgMisBklnPsQMlX/nyJqWwHIShFkVCGPiF4YmghElFfIl7R1NHKE1LJOfJc"
 @"j7YqV17pCVbXJs0J4iqcj6SZkueOLG9aUy6SJpE8c2SJcd2VLXZ45fkvH2OimGAqyVGpI1nvUhKXk/ocLylO6rRBUJIkZXHOeOSLh9g1m5KmBYl3pInHe8W7ps9YQjEoGXQr+h2ht1pRdDOee7bgjW9+P9ffePPj"
 @"ZRE7WTb5XtVsUlyDTJfTc/C65LeWM+paWjAc0oiI2IbRrKZcNpwPkLpkhssQn8yKy25z6cQ7B1Wx/5573vCZ+7/puzg8Z1TB0+srgyJhUASKIlJWCpVDKmp8ZRGQGJl2jq/96XF6J3KcJnT7FYNBRTVwhFKJFoim"
 @"qAg+qXBJxCVGmkcIyssHVkmBPZd7ejZgIEZwhk+UNFWy1EjSWoC4AZpUqJRcucNxZSvl+c+fRE9mzKSTuCQiCTUmR3O85iSuTeZapC6rkQEuIJLgNOHhz71E91hgy0yK+Fgj17xrBO0JVe3ziwF0B4FeF6qB5/ic"
 @"sdTby7u/43tJWu23qG/d79KJd9YhbR0YmuqGuqaOBDmGs7FzzPWtAVKHO0PrdlFqSet+sol3qsgPbZnc9pm/8z0/wmqc4dRypF9l9AdKb2AMSsEqmsKvAA6zitCDbXnK3IFVHn5wjsxl9Hs9+l1h0I8M+kZRBKqy"
 @"jlyJ4KROvnEBkUCS1j21V15coeVzdu9xmBbgUjR15K3IRBaZ8kbqAuZSghrbd1RcM9visb+YY/HllFY6TXAlJBXijMRlOJfWX5rhfY73GYlv4WQCQcnThKOHCr742QNMtVp1XuYr1EXEG0ZBtJKyCgwGjqJQikIY"
 @"FI4YJnlh/xJ33f0u3vK2b/2ZQVz9jMuy28Qlu5Csbn0I63BKG1tKTtStZXqbdHzHC9tao6jrqot6xKVbLJn6zjSf/gkJJe9993dx7zd/gGcOd4maMygqilARYtG0S5r6jYugDkNo+8iVs23+/BPP8vKTRstPNl1o"
 @"14wyRMRFEl8nw3makaYJeZqQpo4093jvSSQlVsLyco8tsy2yPKFblKRtYcu0Y9u0Yg6OnPKcWlBmnXDrjikOfnaeE484JmQaK40Y63qsWo0rHc4HCg2oCqs3oHlsWAILCScXT3LHPVdCFun2IlWlFKVQVkZVxTr/"
 @"rQJVqDBKzCKCI4TIZDvnttuu4uGHv/j9vUH5uAghhrhIDB2sahq+kdOJJ2RYibH1aaPIpnCKdV12cYhL2kk+/fdE3d1XX7mXH/jBf8HJTs5SLyEGT6hTMpwIqVMyn5FmQpZXOOcRc+zZmXHq4DL//XcOkpqDmNWY"
 @"FS2IQRtslJGkQppBkpf4bECSBbIMkpbhk1AXon1NPtTvBGZ3ZKSTAaNk60yLrZPKwAmHFwpcUXDH7AQvf2GRVx4qaMdpCH1iGWscjSlqhrNYa7sIYvXmU1PUFCxiUkIQVCsWF7rM7pzgmpu3Mb9cYjFBrE7QnTpU"
 @"tUHVKSoB5wQnnjxN6a72ue663WAdnnz8kb/wTrJQDZ4gFB0sICPumNPbeOsEyDkEOCq91Dkf4tLLvMtut6r80vd87w88cPX193P46ADDEytFkRoAm0CeOLLEkaYVmatwAXIf2DWT88e//RhHnuoykTuMQBSIak2u"
 @"6VD1JIknzQWfG3kb2tMws8OY3G4kE4ATgjlMPSbGIHTZti1jZsIzkRjbp5RBNBZW++ze1uLwV1d54a8KWkwiZoR6uI9InRYNG7zOC85pHdSop25ypXXVyWLdzjOjquqiwj1vuYpuKCn6sZ6USAoSb6SZkKeOPEvJ"
 @"c8gyoZV7JtrQatfF/Ftu2s1jjz345sX5hV/2Sqiq7tHhTAXETTrycn7jZSPTOs48UEdAWdFd/uTr7nndw2/71m9lYQVmZ2cIVmM01UkdaCTSdL0F0QQfPZTCzFbHIw++zFNfOUy7NUOIFeJXanyMTRNCh34/o4qe"
 @"aAlFldLpKEuLjlNLyvLA2Bk909uFLFVcLrXvdw7UE8rIZTtSZvLIJEYpcM1lk3ztSwMe+tIqU3GGKgRi6SgroOoTqwIzj6ggEhFiDU1VIUQITY8xiQpqODegKgTv4fjLx3n04UO8/l3XMXekrOl6zBGCEoMQy6bV"
 @"RUNTFhTnKzTxZAhX7N7Ft7/rHfziL/xaOqxzxrNWxxgT4LpW0mb5voxFQ3WkKtEG3kf+zgc+wJV79iInCma2p5RlPcZl0UaKLxapYkmolKKAMgSkDCz1VsF6IBOUWtbhuQkS+pSxpIoCPc9qp838yQlckpJkOdmk"
 @"J9sCU9uFye1Ce5vS3iJMzCRMz3i2bVemtylFJ5C2HdMCSQbPPWb86WdXOX48JVlYIQ4qqqKCXg9CgYaImNVQRg24hr3KLBBDPaSCRbxFghYYJb4CqzJW4ykOH9/F9PNdeitG1kpwrhmrM0ACmiqZetIE8kRIfUqe"
 @"1dHyxIzx7e9+P3/06f/2yRcPvyDOKVqFul01nEUnrMvXfQ2jkAucHq2FHUSnNKb7/vrLD3Plvm/i0UPG8kpGDJ4iQAyh8bueKgSKyiiCQujQ73rEd3nL/Tu45R07efyP5phutzFLiCEF+pj269Q0eEIsa2CXTBG9"
 @"gypDBi3KZWElQGfRIAv43HBTFa1paG+LTF1m7L9CeN2tbeaWhD/682UOv2x0VpS40sNVBXHQRYpVJFYkZjgRVAISGxLAGAmxIMaqGacGFwcE6WKxwlWO1WqFu956HdN7ruS3/vNBvKR4L3g/aFyBB6tq6JBCklgd"
 @"hHnfCDFy790TvPLCF5lfmnufesOqcw/9jaJQzsJbNo44Y9j7E4cl2k19ftczTz/5c36q9aG9t9zHgVcKBqFFFZUQIMZIFY1BpfQLo1f26PcL+gOh14/MzBr33Hctzz60n6ID3rVrY6El9WhJVU/2iDWINIf3KWnq"
 @"8Knhfa0xFkGCUnMUlYhBKDI6fc/xpQFLpjx6QPjqF/p0jzqKxYpY9ZGyi1RdCF3E+qgMUEqMHmZ9zAYYBWZVXUhQa74U1QSnUJQV03s8b/+et/DYc4ssLSVkSRttMKAiHiUFMpxog3hQqugpLWG5qLjiyjYrpx7h"
 @"47/yYTrLc98nCoQKYqzxrUPelQ1m1Ikm52wg1vHLcBxRRwJUcaj3u12a3/Pcs08+deWu9n233nobC6cqMpc3ANpIrAqKQZ9Bt6DqVMSuEcqCJI+keZs9N86ydVLY/8hJvG1FfLfOO2OdK9a4kQbh7VLU5TiX1s1j"
 @"q2upVSGUZSQUDSy+CsRQYQEGhdEtlJdegYOPDohzfeh0oVjFFau4sgexQGOBswqxgFIiVoA1pAVW416GJQ0xRaNgMVIlp/i2D34LK3Ga/c+v0EozJFa4enANL3VhO/VCnkI7TZhIW0y0c9I0cOtNKVsm9vOp3/w/"
 @"mD9ySBJNd1Wh6hDr6NpG84R2Wi64aRR6prrbkHnBqNs/XtItQbKbTVtv0DIsPP/EX3/1+uv2PnDdDTdyfH6ZKAlFFPpVSbfbZ9APWCkE+kQVNI9MXDZJ1Q7cdOtuFo51Ofr8PLlPax/ahOvrEOCaopqApnUnxJoC"
 @"eQGxMqiEMiRUUagsEoKjVwgDS1k8bhx7ehVd7uIGq0ixglZ9NJaoVajVgGA3nN2zWGNmG/oRlTqFELNasNJhtezwxnfdwE333c5fP7qI+YyoPUwHddVCA+IDmoLPI64lJC1PPuHxaYc9e4Rt2TE+8av/ileee0y8"
 @"5ruKqjxKLJGh/x2bIxSxdeDfkQk95/xRUwW34cCmKKb0TKQwi4s+Sa4uQ/ITjz72NW65bQ+7917F8ROnKKOnKAYU/T5UFSYVpoZqJMtTpmc9flJx7cgN11zOCw8doFhsoV4a02UN4aw1H1vjbhAHEokhEMuIlUBQ"
 @"NIDGCtNQY1OjpwhCqdA9qZw6WBEHq1B2kdDDKEBLlIBINRqJNmrTpUREFdUhYNkIzbRtvwpcdnXGd3z/e3ni4CkWeyCaQhhqq0PF49STeE+SpKR5m7w9SZoauy+H3Zet8lu/9q/Y//jXpJ1teUu/Kg9GWSk0DpFq"
 @"NsaPMxwMXQtiHEMN3IQVaCPu01irm6oOuxM2r9hiMCs0yb+3Pxj87HNPff2BO267jta27Rw+toyVKXEQiQJOa7S0d560ldGa8aSTQq+AnbvbbJtJePZrR8ljC2KowU9SYjI0HwkqGQ5X88QEiFFqMBGCiWs6MA2Z"
 @"piYEDEsig46wfLSEQb/xeyVCUUedWvtYsTpiFgFHPRWVSN1hr1k8KyyWRKvQrOQ7P/RmyvYszx3pkaQJVkXMyhpxZ/XwjTqHdzlp2iabUJJWxc7tFVdd1uH3f+dneeSRv7wxz7O9g0H/62ZFT6xqtNyais16KP4I"
 @"DYjgxKXrBg3Xc3qdjoVh2I2XNdokEy1AXLTqL9I0v6uz0vndZ59+9O1333E7rfYMR0/2QDK8GLimhZgovq2kMwmS11O83UGH2++4ksVjK7zy7ClynxDjoLH/YcRRppLUM4dWz/kNCX9qfI6CVzQ1JAN8PbPgJhyh"
 @"gOXjBdLvE4sOEmtf58zQBpSk9cRPE4l6vCaoVojVn1eFHh6h21viDe+4hjvfei+Pv3AKk7weYbMwoqJWtXrjOfBpSppnuDbMbu9zyzXCf/tPH+PBz//J+xLvZsty8ITFQUdj1QwarZXO5DTQ73D9tYFUbJiHX+PX"
 @"3DjEsmGgZY3BKACLYIVZmHNJsmdx/sS/PLb/yX947733UuYTLK+UtHyOeUG9Q1PBtyGZqI1A1JKijASDG27axbOPH6R/KuCoiPVkZp1Yixvhb4huVBgXcairKzaaCC43NBMkccQ00NomWHAsHiuwYkAseyMBCgFt"
 @"grShr3PqcM7j6gIoASPEgMaCQa/DzmumeN8/fDvPHhvQ6Xp8owbRIhJ8nSvrcI87ksThM5iegTtuVD7z6Y/wx3/w6Xdqy++MRe+vLBRz9YxKGKEjrKkO1QWUuGk651DX8HrZJtwkm+DSZAyRrYx4wQyCEefF4nyM"
 @"1eE8Sa4+efz4T758+OD/+ro33otLJumVniRrU3McODSLuBxwVhMBkLG8amzflbB9ywTPPvQSWvl69LmZ369D9wTRpC4kWS1Q55J6wROHTx0uB00FSRXJI9M7E4iehSMFDAooB0gMCEXt56QuVitaA3vV45xr5hVS"
 @"AgNi6NXRrV/hA//47ZRT23jq5T4+TfEN1VYcmj5Cw9yR4jRt8Dmr3HNLi4c/9x/5vU/96gNJCqGsXo7V4DliHf3WUa81VF8Nh0+D3F6vWGM+cPNZbVsHN2RsgnTYO5SxyHSUS2I9tTAXI0HzyXcvnDj2c52FY99/"
 @"3/33E5KUfhVIsxZ4kKTEpbW/IRoWHUZGpz/PDddfzuqpAQeeOUzmEyIBrBagugzVbNQZF0lQl+ISjyaKy6TeGKmgqaLtwJbLHTF65l8eYL0SBgUWCtQGdYGAUGseDie+aSM5VJs5+tBFYo9O0eHub7mZm950J195"
 @"dAnTScQV6AimV4+YmYRaP0hIPKh2uPvuGV587NN8+rd//p9EJ66MxdNalAewMoiFWoANDckaEtBG0Ir1EegFCXCMpO60+qiMmP4YsR4KUWRgQsy93zX30ksf6xcrH3rTO+5npawoQsClDrzhfENaN5x3l0E9ry6R"
 @"W+7cy4tPHmTlWAeXDDvQCaoZLskaoqAaJyMuQRtChDrLqE2oSx3JpLHlioSqUo4fHBBWS+JggFQVEvuIlDUMAyVRjxNX+z5JAaOyVaig7HXZcoXynh/4Nh5/uWBhMSXzVpMfSlKD04eTwFo3c51Ggi1y991b6S38"
 @"FR//lX/341W19JsR64UyzIlVPWo8+mgusWZM3shsePrM/AUJcJxbQYR1whtqJCL1YGVt+AshzomJS7Ps9oMHn/9EiJ0P3Pem17PUK6liQpIquDiaL6hD9wLThN6gYGp7wjWX7+SJr+4nBEjVcLRQbeOSOpmvVblh"
 @"fdIazCsO8IZmDtd2+Clj6y5PVShHDzQC7A2QOMCsTz2IPZzB9zhNceoRSYkRqrCEVRBslff94DfD1u08+UKfLMtQiro3qh5VcOrw6hEf8T4Swwq33bIFF5/lVz76Ux9e7az8Z3HV0VD05iXGoq4a1fXVNajE+hHr"
 @"9Zw96+cGGx94Zn6S9ZSNwqadXlkjIRVZ42+WOiMqovrLkqz9pgP79/9xy1Vvvev193GqOyBYHWLX5rGuOARTIOJUWF7tc+XeWahKXnzqKLm2EckQn+OTFqrZKKipI9AGke0FSRTJFTepuKnAlh2OQU85+nxF2Smx"
 @"/gALq3VztQbIoupwmuBcVpfBMGIVIPbpDpa57S17ueNt9/LIMycJIUE0gGMNgqkN5sYbSWKYdbnh+km2Tc7xm7/8fzF37PD/7ByhGgzmazh9MaryDM/voBn/Xj9gtNmcykgD3Rk18Ewz8RtqbKf3EFXGgFDSE9GW"
 @"iPjEpze+8NQL9+6YSrj19bdybKWPxhyTQJQGyhgjxGHJVehWBTffupuFF09y8nBE2wkqjkxbiMtqaMaIZrLmLcM1aIRM0QklmYTpHZ5+RznyfEHZGRB7Pah6YCWK4UVwmpBohtccFSWEEqt6DAYdpnbDd/7jb+W5"
 @"4yssnAr4xGFaNRu2WQMVNAkkmZGEyJWXt7li1yq//Iv/mgPPPvX3Ey+uHPQeMmuK4g1jk42dgCNGE3Gee05FhlyrZ+sDnk52sPHCcdSdWP9V4yexgMXykIXBExbLg6qB//rJX/nXT3/hj7j5iikqelQNU69J8zDB"
 @"CBVUlbA4iCy4kjf//XvILw91Bct8Te4TWffZVQyEGOsyWoQqRkIwzIRQSY1BreqJ3pqwp24aqzbzFJqgmtdca/UgPqHsE/QU3/Kdd7JMwuGTXdIsH2ncELdpUWqaEhGCGVu3OXbv6vLxX/u3PP3k4z+aZTpVlv2v"
 @"m9XdjRpiEtfn4MMZQbPzJo10qFs39bdWLD0fUu7T2x3K2Bk/a1SLPWDRiIuWyH4MDjz61Nsvv/wydt5wDacWuw3Wps7EIjbiV1NJ6PUDO6+ZYutkyqFH5/A2RdS8HqhpNKBuvdYzilEV8yC5oi2PbxmtGcfqIhx5"
 @"YUC5OoCiD6FfdzwEvKYkvk2qE6h4LJZUVZfl7hFu/+bLufdd9/KNZzpEPF5cXadtjsixWJcWhwCymanINVcN+PSnPsqX/upzP5tn6XVF0X8oVv1HCWEU9dqG4wLkvDnT1mR1Th94LpIDadojp7FWjHzoGMkqNo9Z"
 @"V116XQzxG88+9cQDV++9kquvuZoTp7o1jK6ZaRhC5hyGqWe1Krh+325W5hc58sIirWT7aBghNpCIaDXk0ZxCYiMBupaQTyrdZTj+YkG12oeiX0egBJw4EpeTpZOk2q6p/UNJpzOH377Ed/zTb+fQUsX8fCBTT2AM"
 @"Pjsia68xMlOtyG37PH/6B/+Bz//5n3w08+mPVeXqR2LV/WwMRU+sFh4xDom/h0MLmwaO5yXAEXnaGRP582PoHU8phgSvMka/b0ZwUQqz2Imp21IWxcMHn3rqzbfedA3b91zHqU6P2PjoYVJdk6ZWVGVCKQVX3zDL"
 @"K/sX6J1wJD6tUWRmNZlrrEFQ0Xskc/VwZ+5wLUgnHd0l48ShgtCr+4BKAQS81v27LJsgcROoCUW5wkpxnHf+4OuYvOYKHn+ug5MaGhmdx1ys22USQY2oFVkrcsdNCV/53G/yh7//yR/PfJiriuovQtX9rMXOYYk2"
 @"6uivIwKRzYR3JijFBgGK+BFXv5wHQ+HmApR1fcOhORjOztsY6XU0eoItYlYkqZvtra784QvPPP6eO+66mantO1hcKWs4u0WiKjGkuFiX0bplZGK2zeWXb+fZb7yML1uoeqpQUUggRo9KICZKSJsotKW43EinHL2O"
 @"MP9ygfUGUK0iMeAkkElKnk/hW9N19FkZC8vHuOUts7z+u+/i8WcWqMp2vUEaUnTRerbfAVFBkgF33Zjz5F9/ik9/4hc/5J04q8pDoep9GRvsJ9Qdfhpu1jUm7biJssRNtG+zEXdwOt6RP1MeeF4cXuM1UsZY3jcQ"
 @"L9TwmkKEXoziXOJ3ry53/vCl5/e/5847bqc1vY35zgBJMjRWiFS1x4iKOc+gLLli91ZSjbz05CJOJomxIMZItBIkIboETRWXO3w7weVGMqUMVuHU4YLY60NV10IdQpJ4WvlWsnSG1BWsrCySzFa854dfx5HlPgtL"
 @"gkhGrInX6nP7BERL1HkkFtx5U4sXn/4Tfvd3/t9fslg8baE6GqrygMXBfqzG0oiFDeQ+mwnPLoiTTjf/hfMne13j/DpD5DqisrQmIq0glsSqnLdq8EQsBo9nqZs99sL+v/8Hv/4xdvoOO2c8g6rA1BEIBKjNZFVR"
 @"FI5XOgvc9b5ruP6BLSwXKzXjX2XEKJQW625AXQ0iCASEaFIDhdVG9zuMQJ3PcEmLRBxWQZUu8W0/cCNhxnNiIZLkbcTXXYXRL5tgzlGwyk03TLL4ytf4L7/zkd+wcvmTamE+VoMnzIr9WAmxEV5TrRqSItimwruw"
 @"OXkn6ja0kC6GDl82h2OMGBENWRe5SkdqeHMvSVv3nTx+9LdPHDn0vje88Q1U4ljsh7poHaWO3LRAyDAS1FfcfPMVHDpwiMVjgnMpwWoCV009tBQ3keInHL4lZJNC2YPlo7UGatlHrOZby9JpsrSNl4STS3O8/t3b"
 @"ufVtu9n/yilEMkyb9k6ITd+xhpOEWHDttSn9la/zW7/47+gtL3zEqXXLov81YrmAlXXBfNjfGzUN4hgblo2dQGMXRCxY+0B1I60RbMSgdy6tO38hju34cVypDH2ALWHhsCFZmiRXHz188CP91cXvfeCN99ENwmqv"
 @"IhHfTFxVNT+aZpQRtm5Xrr52hv2Pn6TfrSH7goM0qU3nZEo6meBbkE4IVS/WDd3eAKn6qAmJT2hlM+RJzkpvmWvudrztg3t54WiPIoSafEGs4V6rBzYjRhWXuHq3R/pP8Ylf/zfMnzz2417FVUX3wRjKBbOKtQ7D"
 @"+GlwcZ2yKJuDlc5fgKKNhsQNUejFvjamFLHpCLkxCD9Nx9mCWrkfca00n3r/oef3f8yqwfu/6ZvfwlKnT68w8L6BNkREIi5N6JV99l2/g+1bMr7xtVfwzOBdRPMMN5niJ1N8S3GZkU8I5UBYPlZhqz0o+jXGOklp"
 @"ZxOEwpPN9vi7/2wvJ4s+x+f7pL6u+tSpUA2rjzEwqFbZsydlW36E//gL/ydzr7z03T4TF8qV/2xVOWdN/xKrJ6/E1ooe4yeSXeApEmx2LJ2ry14N4bnZBfk+zloAsA0l06YILjoiOV1LXkdRzhzElSxJ973w3P6/"
 @"mEzt7a97/T0cX+4TS4d4QZOymdETxCur/cgdr9tO6A14/qllXDoJeU4yofiJBJ87SAOu5Qk9ZeXYgNCtgxiHp+W2kKhgSZf3/KMryK6EZ17sol4RWjitg5URk1TVY9s2Y2frCL/7G/+WQweeeWfqJQtF97MxhDkL"
 @"FcOgRYdmU4YeL54XA+H58WcPQU0iF8ALdGZOtQsyq7aOSLj5RmkAUksqkjmf7HnqsW/83sRk+z233XU3c8srRDypesRJLUwRylhP49511xW88tISR48OyGdaaDvH5y00rWujLofQF5aO9wirPbSERDytZCuDYpm3"
 @"fNcU9377DI/uHzAoFeeqhmXf8FKiKgxiZHLS2N7q8Hu/9X/zzBNf/+40cdtD1X3QqvJoXSKrgKo2uaOjZM4WX1wo0a6u6806GiDPRRvM0Rm15yiANztyWMFZGxwdHdzYIzYlAdWp5554/PnLLtty3747b+bkQhdH"
 @"G/UCPqLmMAkUITK5JeGmW3Zy4PlFlpZT8pkM0grxCSaKT5Wyr6wci1h3FQ0lmU5TFoE735zxXf/scl44tsqxEw71RT2R5ATVujNShpLWlLJjesAf/fa/57FHvvjjee62hKL3VzEUB6xBbZuV6JA8N8YNfC92jmhe"
 @"NrD0bnyPO+133IXwNJ9N08Y/9PT32Oa5om0SRNfB1LxgXXW1/3/uiSffc901u7j2xhs5vrSKczlpw9gerWaTj+LYtavF3r3bePbpVUpTkrarYYwm+MxT9YyV4xX0SpLoKQaBK641fugnr6TfMl44FBnECtUKRwuv"
 @"QuIqSvP41LFresCffOpjPPRXf/bhPLVeVfa+HMPgCUIVJNYVIxniSG1oOsM5I/zzOXpu7fTP04KYCzsP90IFvlmeM562jPJI1vxFHZmxZBaX1GW3UZR/8dxjf/1t1163l93XXcfScp9UUqIGYoSiHJ7BlLHnSsee"
 @"PTn7n12lii18GoiAz6EqS1ZPrKL9lKrraM3O8aEfu5bLrk95/mVjpd8jmpEwgR8S9lgBHrZPw5994qN8+c//y08lmd9dFL0vWyietqpaklHAMlbjbEpk0uA5RS4uPRs/7HJ9HvgqyM4vTohrpRlZVwGI64rDVqMF"
 @"eyZxKXGSFt3uR55+8sl/eOttt7Fjz27mllYgyREiVRBKC7Qm6jLYNXtytu7IeP6FU1iYqXt0uWJFQm8hUi1XmB3mB/6Xvdzzlq0cmY8s90o63T6OjEQ8SVo2rOvGzq2Bv/zjj/Pn/+1Tv5SodQeh/3AI/Yetqg4T"
 @"AhYi2qC4x4W3phgXm1ufOXVzqroOJvHaC3ADnYk1M/PDAsc4hKM+6GM+Ruu6NLm63139+MHn9n//bXfexsT2WeY7JU4dmCMEIfGRqXYbGxh7r3PMbst5cf8ywSCfcsTK0ZuLxNXDfM8Pb+ddH7iCEyuRblWyvDqg"
 @"KjxOFe8LvK8L1btmHV/93O/xXz/xq3iJX6piOFEW3Qc1FAeIAQt1og5hhOfcyLt7YQkCZ0ED2iYaOOYY/2bOjpfNb65hvVfGSdjq43UQ9RVhrpW4LZ2FhU+8/OKL33/f/W8kn5xmYbnAXBtnoDEyMZGTJ55QFlx1"
 @"Vca27Z5DLy2Cy9CYsnLyMH/3723n73zfFSz1SvrB6JewtFKfJ+FU8F5xUrF9xvPEV/6IT/3mL2FF78MxDJ4oi+5nJVZHJFQFVo7yvTXtu3CNk/O2WpuZUNG/YQGyCeJ7TPPimLkQGqxM7Bl0iBS5S648NXfi9+Ze"
 @"OfTBb7r/jQwkZ7EfSLzHEclbOdMTkQRPWVXsuipj+842x4+s0j0xzzveNs37P3gZq8WAfojgHJ0VZWW1IkpAfIoTYeeUsP+xz/LxX/woRefUv3Y2eLQqug8Sy0MSiyLGqk4TYgN9NxsbPrmw2ubF2LNLJsCzhcBn"
 @"i6zWQRTHkN/WLITa8Nx2jxmFmXXzNL3xyMuHfq6zvPihBx64n9Uy0jWH8ympRbZMGC2vpJYzKEp27nLs3JJw89XCu9+1ne4gUlSCJIGydCwtD+gOIupTjMBlWx3HXniYj//8v2Nl8cSHEwlz1aD7YLS4aBYKrEJC"
 @"XDe9VB/XHF9VYVouwnVdlADPJqxX7yfXGMJGOEtzNXhJJESxnolkWav9ppdfOvSXrui89d43vIGFAQQcKSUTacZU2kZlgGhk0Cu5enfK/XdNsLJc0C1KRJQQU7p9mF/q16eUVZHLtiZ0jj/Jr3/sw5w8cvjD6mxQ"
 @"DrqftVgdDjF0LNQdFRkKLzbgHLEN7SF7VSb0QpXAnZZkX6Jo9MIEKOtwITYyRc38hdUD/yIBkxgEDUhypUvc9oPPP/WpVpa85/bXvZ6l3oCgQuJSplqOxA0I6qlKT0bJZCthcaVPQSCSUAZhYaXPqZ4yCJHZSQjL"
 @"L/HrH/0ZXn7hmZ9KHBRF90HC4AmGZ/BawMVq3fm41swtXboezvkL8zXzgRcmQFsPURx7smFbWJsTvepzo1xHkEycTjrndz/z1JNPzUy1773l7rs42a+IFbRbkSzJCJZRhpJUjJnJhJX+gH7MKVFWBwUnlgJL/YrJ"
 @"dkIeTvBbP/9v2P/Ywz+Vp8nVg8HqZ4iDR4nlUj0vHpBYNlGnrR1DfpFtOLmA5H7dwcg03YhXm6ts3B0bqzEb/31uodoGbZRhKtYMXdbIs7ogHudEJEPT65xZ78Azj795587tXH/zLSws9lGXMJm1cVYwiHUBfOu0"
 @"o9dzDIJRyoCFRc+JU5HEF2xLe/z+r/0Cj33t8z+b5oTBoPsgVXnAYnm45oeuRhOza7cYL0EP9eJSMXemDP/SJe0X04oaU9Aa5bR28yohinUi4EXbGuPDzz39zJuv2bOHPTdcy9xCnzxpkSdQFDVpz/RWR78HoRC6"
 @"fTgy16Nf9bl8m/Cnn/xVvvLZPyH34a+Lsv8Q1eAbWg0OxGGKEMMYGNfGoPAXH/S9egFydgGefzQpr4GgZV1II9qUvWUMei7WwzQVE5eoToXB4Kn9T37jvhtu2seWHVdyYqlHe3KCaJAR2bEtod+NDErP8aWCufll"
 @"Lt+W8oX/77d48A8+RerCb1RF7yuhKvYTimcklPXZgjHWQcsQSW3G38a2Xr82uibAcwN5L67IfeHX0g3n5tWjVeOnqQ/ZItQ0IG42YoVL/c5Br/v55556+s233HkL2cxlLPUL8pYybcIVU57eIDLfN14+ucDsdMZT"
 @"X/pT/uxTv4GXQAj9XytDeTCGcMJCOW8NQ0UNA6wFOUwVLvl2Pcc6rVcS2SyIsYtS9zMd2frq8sONzIn1eNVaeiFr8wiEnmk8HFXb0QhZmuxdXVr+6pGXD9x31x134toT9ANszxKu2OJZGUQOnVyh7eDFRz7HH/7H"
 @"X8GKASEMPlxW/YclFPupygNWlTU3TEM2V88vxFGX4W9agGfVwEsRgV66lIJ1SDcbHtQo46GNjFgkqM8KDCayqGjbQpjT1G1fPHb8z48deP6td9zzeiyfJXcley7LmFtYJZCw/6Ev8nu/8rMUvcWPVnBfKHu/YKH/"
 @"kITBYVdViJUYNe0INsJir81UXGIRXsjmXs8TI7KGmLqID7uUfvCsHf+xw7nWUn4HSAHhqNZlrSL1cfHEKy997Ojhox+69a5b2TE7yY52AlXgoS/+Jb/zS/+esnPip0QkK4ruf9DQfZBQHiXWhWlritNiNkZzPG6+"
 @"Lj59ePVuZl0Qc+F76UwCfG12o2yomdoI07n2lgYxjAWzOBdwWyJhLk+Sq48cPvLwwvzRt7/1DXdx45U7+MsHv8Av/oeP0pk/9kuZlC8URe/LZuUhqYoDo1GvJnAhxk36eK9N2nBhCrBBgGsJ8/+IAtzwf7YRLLXW"
 @"uGlgikTRgMUOISzkaXrdK4cOfLJaOfV+qsBH/v3PcfzoKx/NXFwK/dU/iVYesFAeGvKS1RD45oSS0yzT30bOd3YBDkdBz6utf77VgktpQkWGwzKbNDYbTTSaE6+akTRzKb4+DmFSfHa7aLpPVSezLLu91xs8LqpT"
 @"oew/TNX/eohhPsYSKcva1zY1zhjD2OzCeOJ+YWuxGeJh43s327BnX9fT8kC7KLW/1DnguFk/2+lBa6en1YccD3ueQsRFIUBRYYs+ig8i6aAqDzqIoep/PZbF/hDDHFafRiLN1Gw9cWtjBHMXV2Y8H5D0uU5R3bwN"
 @"p8MTBXSsMHvxJu9iNXLjjt0E571BrDWXt420sbat3hJKX2NJ86BUabqrcn6XD2HeQnHIohEtoqHEYsk64ncbRp6XzmyeSete3XqtM6FuzK/ESyLEzW7sTJHlhTzA2vuHn6VjoOG1/6vR6kp0NdeZogTVmufbDItl"
 @"Q4s1nqCPjYav07h4SVzIxQlss57NkLG3eWh7jZzz8CEvra8cXiuwdhDG2kTwiIjIFItGKYYMQbcNA6BZXR4bzQjFjf28S5P+jG/oSx3oicg45fLFLfDZbvy1fJnF0zCT9QyGrc2gS33W7fj08Yjaw9ZorMzOd1bv"
 @"NYwvL0BTzazhC7X1tv5C04TXqmNxPvXBtYWWDQ8/lt+O/GnDQt90E9bTbG4kbIgXrA0X+kwXWj9eb0Lrl1+rPb46DXsttexc193spJmNM/5rPi2O5YxyjhqsXbL7PFds8GrXc3hdPx6S22ug5pfSj5z9gce1UBrq"
 @"trGjY42xAGjt/3Qdler/KIn6+W8aL4CJnMYZ+lrZ7df2es2g6qa57UbNHGLS5Qwm9NJbkUvjajY7/Eq46AjstShqX3yUerYUhqaEGMfEaK+pT790JTTZYELt/FjrX0t/92o/47Uo512K672WbmY8LfGv9oHGk+o1"
 @"QO44x5dekE85n/LRuTTtbzLUf63To/P9PBH1o3OThq2T098sm4bu40f2nLkge75ClNOGRNf82ZkEHC/ZosoFbolX+3mvRjPXDqY+fQzG6Ygr7WwXXM9RuVbGkrPkOEPLvDl53ukC13WCPL+A4m/PZ//tofXWf64f"
 @"MQuepRozFMb47MK5IiwzThvk3FhS2ti4vbC5+83v5UI140xF8/8RhHYubRXAj3Ij0bMako33fj79rHEUlY1mqsfPpV/fnD2tYq81BUocW+T1v6ObJO7n33cb/5md1fqs3zCnwys2mrp4gSZYz7C51p5z4z3KeCVm"
 @"ra87VnTepCe32WJsXJThoReiul7bxjKtzfpg63aZnD52ZhtM3qvxP2eHqp/5fRs/U5rk/+ylMNt0o16opo2vw7p1H32CTxvKfIDA+nVcP6sQz9A33HQRznBzcnaK4BF98lpdxNbTkWwwe+s7HeMVGR0l9uvvcy1a"
 @"XtOY9Yn8+luUs2rPuRuyNnIPmz368K2q9ameZ7ISonqGtU9boyMDZKj6Q1+3yY6w884Zzz71ZBuEO75VbDhqvQEGszZIyaiawjgfSyMQbUzruSAO6zbXBaLQN157Y7vofJq3Z9sIwIgP20YW8fQ4xausTXSbbE44"
 @"qXb+jnwcTb3Zw0SJp0d+NgyiRlwxa+dUbNi5ERvBJ9YNhI4OCZbzvtfNHPzw3kau4AyR9kZhnWZmL7DrsOl7mrhkvSrIGnebwf8PYWBLbNr4RDsAAAAASUVORK5CYII="; break;
 case 3: encoded =
 @"iVBORw0KGgoAAAANSUhEUgAAAHAAAABwCAYAAADG4PRLAAABWGlDQ1BJQ0MgUHJvZmlsZQAAeJx9kLFLw1AQxr9WpaB1EB0cHDKJQ5SSCro4tBVEcQhVweqUvqapkMZHkiIFN/+Bgv+BCs5uFoc6OjgIopPo5uSk"
 @"4KLleS+JpCJ6j+N+fO+74zggOW5wbvcDqDu+W1zKK5ulLSX1jAS9IAzm8Zyur0r+rj/j/T703k7LWb///43Biukxqp+UGcZdH0ioxPqezyXvE4+5tBRxS7IV8onkcsjngWe9WCC+JlZYzagQvxCr5R7d6uG63WDR"
 @"DnL7tOlsrMk5lBNYxA48cNgw0IQCHdk//LOBv4BdcjfhUp+FGnzqyZEiJ5jEy3DAMAOVWEOGUpN3ju53F91PjbWDJ2ChI4S4iLWVDnA2Rydrx9rUPDAyBFy1ueEagdRHmaxWgddTYLgEjN5Qz7ZXzWrh9uk8MPAo"
 @"xNskkDoEui0hPo6E6B5T8wNw6XwBA6diE8HYWhMAAF74SURBVHjarf15kKzndd4J/s77fkvutWRV3aq6O5aLlRvAnZS4iKJk2ZLbkuyW3d0zhqctxExoODEh/jHGRFjBiRlqIkbqiGbTEQMqJiBH25YVtrrllq2F"
 @"lriLoEgCJAgQy8XF3W9tt7KWXL/tfc/88WVmVd0FBCUncLFUVWZlfuc75z3nOc95jpyKHv7nI588n/jkOafZupLj8BSaozgmD0U5eBTc/WGm/yUiqOr0FZi+hjnyDJn+26DI9HcJMv6umb7C9DWNveUF5OAdiAGv"
 @"YA6+hoJiEBEQUJ08Y/LafvoSB++Zg/eslE9i8m9F8OMr45Hx90Sk/Nr4/49eNwB/x6tWPu/W333oe2oOfVgZXx1L4L3ve+97imaKojr+MOgdfo3e5es/zsPc6e2PX12mr39gPEA8iiDj54pI+VPjDy0IKge3gccg"
 @"dvwdMeOLODacGASJxp8n08nl8AaRyYU/+Iyqfvq2jZY3j07fs4KCqEFFEdXyd+nB9+XQDfnXfZTvyU+vhxy6LoFT1xkbL9Xx3VTeN7feQf4OPvPjPOS25wkCItMbe2K+0hPLL5ixsUQFEcGrImKQqQeO70YZGxJB"
 @"xYIxEZjm2GsjRCIViZGJ8UoDTt+L9z1VzUqD+J4AXjUTKb1Lpy7ry/ekCgQgClpeM5HJ9WNszAMjMr2ef20zHrpCOg0EQWk43ys/zMSE+haM8VbvnLu/hiKH7taJSUujyjjMqY69UwwqgohFEYzY8uem3icIJgKJ"
 @"RCQWYxqCxIpEEyOKDc8gtl06q++pB5kYUXxPVDP142uhvidohmqG1xTRzKtmMj5WJu+vjA4GwZfGm75fnV5snXiP+kMR6LBBJp/Tv0VHOHgEk/PAo5mfnCV68A7Lu9rzX/Zx1BvL3zEN+OWHHN/wasz4opjxUWfL"
 @"M84YEBOVHmWaIBEisWAaEwMiEiO2rUgkYppionOIfRL8M5Te1UNLA6oB9b6nrlgXfA8tDYpqNva8Hup7eNtXfA8pnQ/1mYjH6yQSKKoeMzGkuvLFxd8SVuWQEd/qwwP2qAG9lneWH18xFY4c1P9lzr3bD+Sjicok"
 @"DzFHP5AYROxBmDR27Hmm4Y3EIraNSCSYJpiGGNME08TathqJFNNETMMY+ykxFpFw/Fr+CbyCukNeoogBa4LPqfq+qO+B74n3fbxEiu95LdYR1wFtg6Z4zRSTgeuIKogZJzRmnGz5g3tycm6rHvKjH+98LK/d4UAs"
 @"BOPwmTINnpMQqodeXA496a2H16NZ6Jv87OGs8HBGKWXiosYABjU2UmPbiG1roBlE5wzBCiIRBpBgVSR8SkyACULERqgEiAmwgQUTgJYXVtUh3pdhTcefXHPUZZ/yLsMoZSbrQdTjNf8sGp0ro1V2XkhfkqIMtaht"
 @"q0hP0Ey0KMOqjm9ItWPP0UNx5m4J4pudf3c6upTAo5ni+zJOfT3jDzVN328tA966AUvjydTPDmfiBxmlRcUf3KFIWSKolJ9fDGKihoppIhJ5Y9tiwjPWROfEBCtegk8ZiRATINZgbYgJ6tiohgRVTFDBBhVEDGg4"
 @"voy+9A51iIJBcVrgfILLBniXgStwhcN7By5FffYU5KAFgatgnXvG2eFXHfll0AwHZdiV8+Cy8vx2k9NgfByVRlV1IIrowdXSI+FU75C5H2TI06glWoZQnd4jdysZ/N/wvOOQEfWQh44PdB0nL8ag2DIlEEEkABM0"
 @"IDwjxjTFmAbGto2N3yYmfEpsgLUREtQwYRMbtDBhC4nrmKCCBDHGxtgwIooCjK0hNsQYg1fFO4f3HpdnhNkIV2QUWYL6FO+HeJfiihTNBpDv44s+vkgQ4xExT4g2n0Cz30Lzy+D7eNdRdR2gI04zxY3NcutnH//f"
 @"5By9i3e9lWsbKJp61fTglW5Nd/UuGdBbOXzNLW9Jxx/G4OXo65ZnnRkXXBaLQW3QRsqQKTZYEWvbYuO3maD+pI+rGFunEtYJ4ioa1tGwjQRL1JoLLCw2WDrW4thik5WlOdqtBnEtwIaGwFpUwDnPMCnY7w7Z2OvS"
 @"uTlk9+aQvU6PXm+P0XCPNOkhro9NdvCDfdJ0SOq6uLBPUCiB49Pey+c8xbogERo/qppf8aZYw9v+FEQQfxB+xjdtec3lDsaSNwmbh/JXVYIjAVJ0mv2VSa3e5cWPnm93OuvKA/foIT0pzsuvjROWSdYpFhVThhgJ"
 @"IjG2jTFNbLAihGdMGD9KEH2aoIFEM1QqcwSVWSRuo3aOWn2G1dVFHnjgOA8/eILl4y2arQCALHGkfcdolJJnGYkvz1djAxq1Cu25Jo/cv0IUl7FmOMrZ3Um4cmmPV16/xrVrm3Q7+2TxHmGySZBso8kuuXQpzADj"
 @"9FNG5Gm8bXtnmoJpqkjkxXTw+bpqgXjKMmgaAv2R2lJU3iTvuHtSIy176rHMZ+cLsr4nL2EydYDHT6E0ueOT39SA43T31mwTBDVSohdmcj4GiBHA4k0QGROsiLFttcGq2OickeicCStPStyCaJaouki1uoyEc9Tm"
 @"F7j34eO857338Oi5VSqhsHNzwPkLm1y93mXzZo9uv89wNCQfZbi8wDmPjA1ow5CoGlNr1Vmcb7F6bIbTx9ucOTXHTN1iLdzcGfH9l6/x/IsbXLqwRrq3CaMN8lGHLNnFF120GKJFinfp0+rzy+KLde/yy+rTl/Cu"
 @"gzrUT85dN7aNP0Ca9BCSM73mE4DgMCRoDsKyCNKwJx8tXHa+kCzzFCh5mcSIR7W4O4py1wxTplH/TsYTmRTepixZxB6ETxMgNjxdnnPBKiY6J6by28bGmLCOrbYJG6tEjeMEzZM8+tApfvZjD/Dww212ez3+6oUb"
 @"PP/8Na6+vsmo38PnKZInGDdAsyGZH+F8AV7Li1nWDWADTFjHBC2CyhxxvU11Zob2sTnuue8Yjz44z32nWxSF8NqFbb757GVee2WdtHOFfLhBnm7gkg5Fto93Q3wxetp43/MufUld+iK+WFfvOupcJpqPPQ7QcTJ1"
 @"C56qRyC4WzNXM00AAaRpTpzLfXa+kAxPjkpRfrgjac0dXuQuBjwIEnIEu1MZv7EJelKWBYhYDBaVIMIEKxLaNjZYFROdE1P9bWwFgogoXqBSP0U4c5LFM+f4xCcf5Sfef5r+zpCvf/UC3/3eRW5urNHb76DZPpHb"
 @"wRcJtsiJtYuVjNwXFOpQxt7gQbzFSIDYGG8raFDF2xoazkBljrA6T332JIurpzn30DHe9Y4Fji9VufB6n7/4ykv88NXXyHqbyPAG6XCLPO2i2RDyEd4Pfkvd6FlxrqOuWPfkl8VlGWNvQ4tprahTSI4jhjycdR4g"
 @"WJMsXpCWHD+daX7FmQynOUpR3hm35aX6lgw4SVwOG1DloByRifcZg0iAisGYMBIJz6gNVkwQnRNbeVxM5Uljq2BrmLBC3DpGOH8fD7ztnfyDX3o3qyszfOnLF/j6N15l4+oFXHcdN+ogWYr1A5AdYq8Y5xDtfq7m"
 @"kitBlq2oFpnH9XxAT8VmXkzPiemkxsZIdA4JT6uXWILqk7lUcNLCVxbQ5ikq9ftZaK/y6DuO8cGPnGa+XeevvnWJv/jSq2yuXSccXiHbv0GS7uKzHXyeokXytLr0RVz6kvf5ZXx+Bc0R7xEcqv4g15gakEPnoZ8a"
 @"62gSMzGgOXEu1/xyIVnmNBuHUL3NgGP8cJxIvRUDmkPJli3RpEnpIKbsGJgATBCpDc+IhKfFRueMjc6ZoP6pIGhgwhpBGGNr8zB7L+98z3v4J//7D7G/3+Xf/t7zXHj5Kv3O67jRFWyRYrwjzEbUsy61cP83mib7"
 @"TD3yLMwFHJ+fY3Fphvn5FvVKjLFlvZnhGSQJw96Izt6I69t91jt9NrrFb+znUZxI/FRhqqiZQcwiUf04NJdpHD/JRz/2EH/3p+9n+2bG7/+Hl/jB91+B3g1c7zKD4QZFOoC8D274tLrkOS2y8+qz8/hsXX3pKKJ+"
 @"nJEr4v04lB6uBvQwVnW7AWfMyUczzS/npH1HNk5idJyD+kOGGqPtereW0K29qjJsouYA0zSCwY4zTQsmbIgNVtVE54yJzhkbnhYbfcpGDYKoha22CCttwsZxHnr3e/gn/93HuHHpBv/q33+LrUvXSDqvkY6ugQ6p"
 @"+pz5fMRKlHGqlXDfapV7z53g+Ok2x4/PsXzmFHFcZbi7w+7aBunePlo4vCrGGKwJ8LbKIBc6vZQb2wNevrzJS5c3ubzjfnXPt74w0hgfxJjKCmHtDJXmMc48eob/6u++h7OnVviTPz/Pn//F86Q7m+S9DUaji7h0"
 @"A01HaJ4+ra7/H7VIX/Te9/F5RzQfQ1Alfirej7sbegjKvBMuo+MkUQiO9FunWORdnqh/jfr9kGeWfTMZt4PCBjY8gwlWjI0fNTb+TWNjJKwilRZhrUxYfOUEq6dO8X/4Bx9kY32N3/mfv0jv+gajzsskyVUilzHj"
 @"cu6tDHjkeMByzbJ8fI6P/MIHOfnAaagq1VrA7tVtfviNb3Hz0jWKJCH0ENkAay1ehCIKERsSGEPLCAu1mEcfnedjZ9t8942dL/zlG+u80e18cjchK/K9rxTJFvlwldcGW/yLtV0++bfezd/924+wfKzKv/+D79GV"
 @"GBckZCbH6T6qPKlk51HXMeo6Ht8TXMatPUiVI953OAm8E25qY5lZ8vg9xWdebj/3jqSwb6mIN4carXbcAZcyXI7RlnHobIsNT4qN7lUbP2yD6rttPIutLBI2ThK1zhLW7qW10Obv/dfvJYwifufpP2bz6kWynddI"
 @"hjeIs+3Pnmbnrz7Q5oPvWW2w3FDCOOfjv/wJ7vvQ2+hKAaHh5sU3ePGPvsrwyk1iFapBTBxVCIOIwIaEQURoAwJCTKEUw4Tebo+dTh+X9Dk2V2G+WqPh3X/XCvQfD/q7j/ez/hcL3H9ti5wsFc5f3md7d8jP/+wj"
 @"LK/Mcf7yNi4PoQhRn+D9CFR/RpTvCX4f9X2DjiZNZDnUk5G7IDFy6K9JpAtETFO1zIIOl91/ky7y4bDLuF8nk4NUbGm8MaaJiR81QfVJE80QVduYmWMEjdPMzd7DQ4+c5aMfO0v7eJXfeeYrrF2+SbBzkyy9Ri3f"
 @"/LX7Qvv5dx6bZbmZEAZDkkR5+LGzPPzuk3jXZ6ZmKdKEq997FZN4qjM1cpdRaFl3BRisVwIRjC/TBe8FNYoGFu+V0WiEGw5pSMBimFBvVZivRs+d3+pzMd357EjkqaBbYHzGN/4ixeWG//6ffohf9h/g3/+rb2Py"
 @"AO+6FK6LKTwq+aoac16sHXc06E+NNW0yctfQyRFkWbCxLLzXUVz3ko/KhuT4woveAUaTIwXmETxz+jPmAKQ15T+sWIwxiAlRG7bFBCvGRucIKo9LUP+/2miGuLpEPHsSmT3NqbOP8A///nv46MfPsLG1zx//4bd5"
 @"7TsvkO1fJBu8hs02/9nDs8X/8I6VJoF17BSOnZFjLxNcvc6Nm7ucv7jFjWs3Of/aNW5c7JDlhlTBSEg1qtAIQqpBQDiG1QoUX4ArlCKHJCvIXU7hweeCV0dhDVrk1CWl3WjSjOxPdAf930i0+Jj4DHGG9S2lP6jx"
 @"sz97D3GlyuU39knzEXkxQvIEIfsJj/+6eNcpE09xgmbIAWmkhN044m9HouIhNCxg3E7SH9vr5M4IzaG01Yy76DqFywyIbWNtGxueMTb+NFEVKnNUGqvo/EkeuuedPPkr70WbA/7Vv/5zXnj2MoPeOsVonaR7AZtv"
 @"/lbNZuch4fUbO2zvdz+3X+i/VDWZFdp/cel8VPkLeVwCjUQ1DgmeCggwYqgFIe1axFIj5sRMheNzNeZbdRr1KqGNsdYhDCiyESbPMJnD+4BCI5ymhNYw36jiChhu97i/PsNcrf6Z72wldJI9xF8mM8qXvmKZnS34"
 @"xV98lMuXB3z9yzepDXcY2j28DhCfrWCDVVHNML6vXvrTTgWKqMVLMWlhT1tthzsWMmYhBEcyFD1U771pxmJ+9NekDEk6Rg7Kcy88LSZYEROeEROdE1vFBHUq9TbMneXU6fv5P/2Tx8nSLv/if/wa116+gI7W0Hyd"
 @"tLeGJHtPz9vs/Mma/sFSJSKaCXjo8dOfmjs2+6l6GNKIIA4i9rf2sLESxE3613ts7Oyzsz9gp9tnbW/A5c19ns0dofE0KgGzjRonZpqcWmyyMhPRjAN8FFOoweVDvO8iagl9hMuUeq1GNXAkoyHH6wWV1Qbf3hyx"
 @"nvdwySZup8of/6FyYmWWn/rZc5x/9TLrvR6muo0fDMEWn0H9r2N8T43rTDvp4/ab6vgY8kcL+js5UHCkf6qHexH6I863W3t+t7qhQSdeh6DYRklrMM2ysxA/SVgnjBeo1FeZO7HM/+7vvQ8FPve7f8n112+QZ2uM"
 @"RheJu2ucioafPXsyeOre2Rb3zjaYiZXZE1U++osfoDYXkmWOWGI2Xtnk2//p63zsZz6EVOp8/y++gz9hKPIZeknAIHOkSUpvmNEZZGx2R2zsdPn2pU2+9vr6M1G1+sRcq8HqbJ3VmRpLlQpNU0FNhhhPnibUbZVa"
 @"rcJg4OlnBa2wx2OLLZ7dHLIx6mJ0nb2ixr/7d8/yf/w//wIf/sm38Yc3twjzFch6FN6h6n9b1P+qONfx4jqCyfCurJuNoLc1Ko4SoyZhNEAkRjVT9X/NxOUOoVQOc1zMuCteNmSZJC+2grENbHWRsH6aT3zg7dx3"
 @"tsHn/n/f5PKFi9jhRbL9y9TSGzzYznlgoflUIxJs2iVLElxuWJhv02oo2egmLhcKaXLp5fN0d3YIKvDa669z6dJV5uMQzQTxnpo4mkGFpbkq97ZbGAODNGNrVLDRTZ64dHOPK1v7XL6x9avqyZozM7979tgi55Zi"
 @"jjVjmmFOlYJ6ZNge5WSmRZ5mzIQ93t6eIdncozuKwKxz6XzK1/78Hn7q5x/juReO8freTXy4hSsS8BlqinNiXUfQTJ07f8ANBfUyZkJOstMDnqBMwqpAoF5TlVuJpfojyaZ3IyeVnM3x3SICRhBjoon3YWzbmOBJ"
 @"Y2NsVMfETZbvWeUnPnAPX/6rS7z48hXMcIe8t8ZCscnDx6BmLevbu2S5Mh85js/NQyVj4d5VNIqQzFLBIC5juL3F8vwsjUDJtneompjYGXIJUOvB5aSZhzwFNyovjirz1jA3E3BfY5G9lXmu7idfuLrb5/Ju7+nv"
 @"vvbGv3zpdX3sxLHFzz+4MMPbVgNaFYj3CjQfkfmIXjJivjrkgZkGz3dukqUWq4Zvf/tF3vfTD/LhD7yNq6+s4ZMWNuvifIq69NOI/VUwDSRoiPj+tCIYn3FTa93KlR37YeDF90U1KzNYOaD7IajKbTXJ3QBsDhWb"
 @"5aEbjBlUAWDbiGkYqTyuEqw4ExKYKpWwRlCb433vP44JHd/67jVk0EcHu9TsHu8+EWJcyvXOCCtVrC2YbRoaNqRSg/mFGpKBKVrkYUa+lzLYHHHyxBLOGZKbI+I8IK9mOF/gtIoXQyAOYyZMNIfzkBeOUepIcyUr"
 @"PMvVkNXaPO9emXmyM8ifPN/pc3F39GuXtrpXLm7X/ujepTYqAdaALzyJBoyShPlKwLHQcSmBQCps33id7z/7fT728Q/xpTMrXO5exQR7qBuhMsIRrCCmidHMq4DaMZjtp1RFvZ27d4BKK5oeUM+5g6V/PBLvJBmW"
 @"6eFqGoJtqwlWhWDFYNtiY4ytIGGTxeXjfOixU7z6+k1ubu9DehOKHg+0a5yoNxgMwdqAis2pmyFzUYH6BNOMCFpCql1yO8JXHDudHfp7XeZX6vTzHvu9PawRciuIhVgyQpMikuPU4VAKETIU8WBtec8V4hhlKb1R"
 @"RpZ52vWYn7j3GH/vHac//+6zS3+0Ncj4s1eu/uNvr/VZSwrUpgSak4wcRZax3IDIdcnyPVy6zcvPnScOPY8+dpaw1i5pHyYu22jGthHTFJVo4kCH20V6F/BEpoMByhFm9J2Rlx/NGZ52iMd/MGYKypTM6OicBiAm"
 @"esKaAAkjXNTm5NnjzNSqPPeDDfr7N8nyLZqB5/5mC/IU5z2xEbz12NBQDyoMByn1VotKtYozDhN66lHMzkYHp46VMyfZ2dmjN+pTmAKXO/LcMyoK0jKBIKDAaNlS8s5QeIvzBo9HjGJDwQaGwoaMnMPnfRbCAe87"
 @"PcPPvf0cb19e/t3dXvYPX7hy46Ov7+6x7xwWwSUpdZuzELinfT4En3D96g57Wzu849EV4tY8EjQRGyHWYqzEGNMoGXXjro1w6LS7C71QJsTe/4IE3Wk6LDJtPIqYpojESHhaDYgJsRKhUZWoscS5h89waWvI+fOb"
 @"uEGPIu2xWnPMGs9uVmAx4AJGPkcNVCoxUew4feoYoQ/oJwG5N4ySnLjS5NEPPk4eVZC8ySOPvYuICjkJxSBh1E0ZDoakwwEu9xTOkRWGQoVccgpfFvFaGCxCIJ5YUkQEayOcQpAXzAWGhxar1Krh7722M+KN3USu"
 @"94bnTs3WXpuJLKHPaEfhkxujAbicYW/IhVev8p5PvI324iK9jRYmrKB5gMvNk2BfBNvmwKfGZZk/RNS98yM4DNPoHeq/u2emchsx9/aKQtCSMR0hEmPMk5gAE8RIWKM1N8OZs3OcX9uit7OLG+wRupyVKMeoY88p"
 @"OdAMlKXYstKuM1uPSSn406+/xu9/5YcMUkeaKnmRY4uCwFv0Ly9Qb1Rp1erUo5Bmq8psfY65xYDZ44ZAPabIyUdDunv77O3u0t13ZKmD3AAWZx0SOEIgoEJoIgJRDJ6Rd2z3uxhneWhpjkqU6mudvfiHN3fleLP2"
 @"z1dnGp+JY4iTgtx51KVcvdrhk82QlZV5rr4a400IEiISIGPKpIppqPi+KBhjDpq9eqeRhRL4DP7LeB7TxAcRvBlH8UN3jwEoaYKYIISgwsrKDEszEc8+OyAd9SjyXVo6pBFBnmfMW8+p1RnCKKS73+X1nX3+6tIa"
 @"+0nKMM9+rVBZd2o7YsLIirS9+L6iqcE2A/ZWoMCYvBkYWQlt8KlKJaTRqLDUanB8rsqp+SorzSrH7mmyXDh2d3tsbO2yt5+QZILmNQjBWyG3CpoTeiA3+DQi8WCLLsdjIV6dSc9v9z94fWfw/xh6+9WF9vxX6qGh"
 @"o46Ygs2dBF/A0nwDseOOjAZlW0gkUqOZeIlB+jIt+SbXVG8ry0t2gyEAie9mIr3L/90xwZmUHHLIuNOzWCLwPcFCYLFBBEHMykqLRgi718rudeGG1IKUOIwJCVlqzrA+7PHyjZts7A1/acfrOs424qKaqUYdr+DU"
 @"91AITeVxb6JHXeB7hmI9KExfyc574UXxEgcq/29j8qbZ9o1XzRDRPI6NPtqKwy8staqcnquysthksT3PqWWBUcqw02c0HJE6A1opWXYG9vOUfe8QDCmQ+4KmEd5xrP3NN+LGZ6/u9z+fdvY/qSb6otgCVcfeIKPf"
 @"U1q1CmL0KOVEJFYzjlTjh1Mdsw7NdPrp6CyhjAF5wAt4kTEOd3ii5kenLzo9VCcQ3DiLMvaANYhpqjk06yA1wrDKwkKN/hC2NxPCrKBfWCo1oRJ6ru+NeOXGNtdHw98YGt+3tD7p1D7pUApT/FYujU+b2hxhY56o"
 @"PkNUbRLWZjE2wAQZYsAPhvSHa2T9EflgiIx28S7HSEZFk99wXrN+4n51YzB69sWrPQK7sdJqBP/wzPLcE+86tcADq8dZJqfbS9jpDEkzRybCTlqQqhDgKRS8WIrCIZpxtj3zVBzWnrqy1/ul1CpB6MlNnzQr6A7K"
 @"JMpIjJcxN9Zk4MKnwD5X0hFNBzVZOapWxs9yTrU4NF+q4+TQEIyH74442VtBZI4OLh4gCHdzTqO2Pa0LTZUgnqHRrJAmjkEKSkGQ92jWYq72+nzv1eu/1ZP400QznzEFpGGV2vwq1dYqtrX46bh5grjeJqjXkSDC"
 @"RCEEltDWsJEQ1D3FXkG6v0OeD9A0QdNt8iwlH2YUu5ufKbrXyAdrJMkuRof/zJKdHyX+93avDH/n/LWLH1lqxL953/Is55ZbLC/EuGTARndErzvAuIAsinAqZQkiglfB5SmLs7MUUfQHVzo53qVokZCnI3InVGpl"
 @"liumChKChuOJ52AFyc4jpqkinUOp/aEj6/YoWGKhJWUMc6RUfPMT8E69qcOTspPBViZcGLVPlM4YoCYkCBpUKgFWPN6AE6UisLtfcHG3Q1+iT5ugyjAPad77ds68+yMEZo5kJyfTgHhhlrASl8zAOCSsxgShxVrl"
 @"5DHDyeMNXnihy/VhSu4FqdQIbRPTbBAsx1RNCjpkNNon3b/J4ObF3xysvUq6fwl13X/sJTjfH7iPnn918/KXXl07d89s9YuPnWmz2JilVhvQ3U3xziHGYExYfm4xWCxFmjJXbzDynq39BM2GdDZvcP7V67zzsdN8"
 @"40tzvNGpYEyMNxEqBSAxYppGTE9FOkwmkaYEM7ljQhqISCRj91E9RKCRt0ahkMPDv+aWJKdMTbODanE81GEUkQCvhtB4AhQ1Mc4EXN3t4l2ENcrA1rjn536e+37ybzHcb7D12jZD9pg53uLsT56g0jKQFdioggkj"
 @"RJQ48nzodMiZGUs/jNDlJq6fkg0T/HDE/tAzVy34xOP38cqNjO+92GW2cR8zx96Jv3ePZPcavZsXfre//hJ+7wqWnY9mata/tVW87cWt65fvm6/07j82w+qJFoP9Pv1khEYGZyxqLFYjbB5QpDDbmiHNU3aSEUl3"
 @"lz/5o6/x4Nv+Pj/xkXdy5ZXX8GEJA4ooaiQSb9tqXAcvh679rdoCfsp6P1JGiBx90gQVeDMfPMIYndACJnSKqeeXA5hjlAgrCuQURcLujqf6YMRcs0ZHIlzoSSNHkEekRci9P/FzvPe/+W/pe08+Spmbn6O2PMvy"
 @"I7OcfHudPO3jE1fS4fMCI0KlYVioWpKep4iUmRN1TFKhGIUkWZWlNOfnHmrxwYca/N5fJWxldXQ/ZX83IenP4KvLtJbfxsx9H2Sw+Rp7l/7qK6P1F3/Lsvc7hcBrN0fxtb3k3LkTCy8+sLhMNRmy093HG1dGEm/x"
 @"JiLXgMJDe7ZJ1hnRL3qsX1nn23/5Mo8/dh/zi/OsD66BLcfFRU1TjWmoNw0V0xCR/kEJYW4brS7/YTATDxT+Czzk1jLDRIJpHtwwlvJTphRZwvXLGSYW7nmoRRgaTFhBwgqusARLx3nwv/oZGierPHi2RbNdI282"
 @"iOdbzB4LEeupxobjx5pEAajmiFXqoVK1yuVC2TMOS4a3oGHAbMXw9x9b5G8/1KA3UDppRn0xoHV2hsVzSxy//xjzK22CxixF7QSVkx9g5X1PsPKhf/rpyun3v5ba5i/l2PbQB9n3r3YWvnrhxmcT0+DkseM0TYBR"
 @"R249qRWcDUl8RhwrS3MVrNvDpUPOv7RNrVln9fgqnqjkCEmIEKwoEiPjqkC4rRdf2tDcXp7B4cH/SVeBu84FHmSockAinFrpYBBfxqPPimmo+GfUC2iBKxSXjXjj2iYbWwnve/8K84tNrK1iTItCLe2H7mP+3DLH"
 @"6jnL1YBRv8CHgm0GVOYDnGbU6xH1eojRgsBkWJPTCsAbYSt1qDfEBBALrVrALzw0x8fuCQmMY62vbBcFyADnh3hJMLGhPj/D/LFjzC8tE9Xm8fEK0cp7aL/rH7Hwvn/6u+bEh9ZGtH4l8PWfvtk3z33t9fV/fHWv"
 @"oN1apIqQqiMJBWcUcQZXFMy0KoTiKNKMja19Bt0RC0uLqK1jTQ2RCirBE2Aak7KCseQKIncYnD2UxKhqdlit4SCE3m1OTY6SvMeEpQN0oJwTH/Nm0nFWFYuMwTUtcF5xeUI36ZAMPfVmhMQhBCEqARqHrDx0jmot"
 @"YiYK2doc0U1yosjTbLUIrCBW6DkY7GYUxkBksMbTCEP2vbKXpVQIKQw07IBPnqzziQWDLZReYNgZZmSAtUIOOC8URQlGox4TG6pzcwT1HD8yDNyIoP0OluYfIll/4TPbr36JcLT1W4mV6Bs39j/7WLv21OmFOXr9"
 @"nK4v80rREPWWIBACBFdk9Ab7pP2M2YUmGoaYvEJhRmNNm0lNXlJcDghhtyJk8qbciCNdiSk4feTp5nZERs2PGBo2T6goKqbMPF3BQqPK6kqVH7y6Sbc7QkyAYrCNJjOrxzGiBJFlp5sRNyvMLFepzwcUQFEISe4Z"
 @"eNA4xoYBtVCYiQzDUUHPeZxVqkHKJ5frfGIxojIGilMnrKUFgQ2wYy0Y8Yp4LcUJ1FAUDucVLxC1ZrjnkQdZOrtKUV2kfs9HWf3JX6E49sCnB840e2H1qe9sJ5+7sJMwX29SV0U9ZEYpgvLmtuqwpsAVHhFPsxlg"
 @"jcNaO54X8bx5H0Gnk0yTqabSKSYSHCIHAjoThtt4rFffMj5626EY6zQ825JSKCHWGGwYcPZEm5mmcO3aiDxz4ATvhGhugdpSm9hCnimdXaU522DpdJV4JieqCxZDnpXqEF4gjAMaFUsUQz9RfBYQB56Pn4z5xGpE"
 @"bJSCchhpL1M2cocJLcYISjGelz+IPCKCGEMgIdnI0k1iVs/dy8PvPYuJYhr193Lfh/4ptaV3PpGnQj9ofurZ9fyZK9s9FiuWihZYybBhCex7LyWQb2OiMDiYmdewhNU4LEDEW1B3GqthTERwbnXOH1VCyJHi0nDk"
 @"9hEZD2tOfzYyY3RGJcDaCmG9wYmTMwz6nrVrA7QoMGrw3jCzcpzGwiwzVUs2Ejo3C3a3dgiMp70YE9WURj2gXrWExhEYJbJQiSJ6BVxNChphzieXKnx4ISL0+RS98Ea4mSoDBQkchArWI1IAbtpAFQnGLLqQMKgx"
 @"7CuXXusQRAHv/sSj6GITVz/DIx/576kvvYO8gKGpP/HSZv+z+2nCfGyoa0HdWopCyDTG2yqVaowxhp3tYZlFIhiRI/IhqrdMQky9yh/CQQ9jzOMz7MelFcpYoOZg0NNMx5/G4Pa4C3HghWJjrK1Tm5tj5cQ8Fy8P"
 @"2b05QF2CF0VNyNLZs1RnKzRCodf3jHow6qRcfXWTtOdK7wiUViugPRMxV7PEcYiPQq53U5I85T0LET85a5nxJWYfq8EqJMBG6nBFgZoUDZUgMBA4MKXUCMYgNkBMqUejooQmRJMaV15P6XrDAx87TfVYSDF/mvs/"
 @"/o+wM6sEIvQ1fuqVm3ufk1BpRgFVEzDIclIJsEHM/EKdVqvK9mZvbDSHanrI+zU9yu+VaUkteviPHqjITWhsfxMhrYOjTg41d8dEJiQWUypSSBBhwhqzS8dYOTnHtWsjkqRANSVXT9BocPy+e6m0YiqRZXdviMuU"
 @"2NfpbxVcu7hHOgRvPIVPiK2jUQ0IIkvXOXrZgA/MVvh4q0YcKEZzosmslQgpsJPnWFFs4AlCSxxZwqpgY7CxwYQCgSkneMcoU+GFMAxpBQs8/yevsvv6Jm/7wFkqyzEz9z7MAz/5CzipEpiYm6P8yo3uPo1GC6PQ"
 @"GyZoaIhCy5nTc9SbIZ1OH9RR+CFOR6VyxY/Avu50jBlV31f1fQ6NLOmhCSPBjidhDiZDD7FfOEzD9iJj2Q4LmOhAp8y2VcpMjDAgiyqcXV2hFgiXtvoUfoh1QlFAY2WWhQdP0AwdYi07vZRQchCwcUwYh6RJQVZY"
 @"1MRkBex2R6RpgfQHPF6L+Hi7wqxA4MopHtEyOGIce7lnP0spahYqNeIwohKFRHWIW55KvSBuOIKGElWEsKpQ9XjjCYKYwU6f0dqI175ylf2NDve/fwE/H3Dmve+nfc89pE7AVn57ay9DJcRJQS8BieYIKhXOnpxj"
 @"bW2Hra09QhIoFPEBmOIZwfcmpPdSCbGcWFKvpS7RhD6KlK05sZhS6GdcBuitAxR35uYfpVAcznomvi4IEh3JqsRgrC3Pv9oc992zyDCBrZs91A9Rl4H3LN1zktmVOWZjg8uEQU+xxiPhiOqMUGtFeK/4IidwhlFi"
 @"GIqFYsg7qwE/tdCgMX7vIeNZ/LFOmVODcYbjYY3TlQpLkaVS8bh6jqkptWpErdWg1qzRrAWYluXYww0efrxJbVYp8oK97SFxMAd5k5e/cwPxjuWzDSrHmpx67N3jwVWhP8p+q5+MyIqYpAiJqi2as23uve8kly7v"
 @"0Ov1UJ/ifAbeob5YH0uUjOHHQ+zAO4mQ6B068m/99DMHz5iMTJuJUN1Bd2P8/VhEIjEBPjDEYZP2wgnOnJ1lc7dgvzMA10d9iuBYfvgeqo2A2bhgfwfSUQjWIZGnPhdh4/J3WPG41NP3gpWMxyLDJ+frzCrY8Xxd"
 @"yWw+dCZrxnJk+enVmL5X9p2nkzm2E9jrCXtduNkr6I4M+xSEOKKgRpbl4B1ZlpJnOWFowcJgV1h7tcO97zlGr9Jg4eEHkEqMz3rPWGOaA5+RJlUkbGHCGe49d5rZpRle+9NXKPKs1KHxQ1Rz8L6n6jqo60xUE291"
 @"HzO+vn7aLbAEk9T1MH108tedtC7lSL9oLCUyZmvLoQxUpCwhSk8MnsCESFjBhDMcP77K8nKVP/3qTUb9EZp3cX5E3KiyeO9JQltmb5f2CorcgK2gYUFUq2JCQQKHmJhBWiAu4ZGq8LOzLeY9DI1S9XokeTs8exeo"
 @"Mi+eRauoNeSxJW9GpAvQc8p+4Xllx/CnzxeMdoWtCzndQQZpjEsHeD8gDC0FBZWwSbLrSfKc5vE63aU6Ngohi54woWF7OKQ/spjaCaJonkfeeYphWnDpwjZGM7I0wfsUdR5xEuFdx49J1lMx2Ql/aUq71yNeGPxN"
 @"sc+JYMGkb1RymkwEti0TkR4JMDYiDJpI1OTYsTpBoFy/vkeR9fH5gDQZMH/6FLNL81R8QUBEZ3cIXkp1pQhMxWBiqNcjXAZFlvJIxfCJmRpVPH0EUSEzk9vUY6fvzqM+BJUSjp2MZ5XcShCIImGrMLy2ldAbBWQY"
 @"0kzQNMAWjiJJwOeoBkhQoToTEQRV8tQz2xA07+F9ThBU0QC2+xaCBtV4hqXleR54eJXvf+8Snc4GWuziixSvBWjxtHjXUe/7pcylv2tUnJZ5IqDuxzegHpplk4NW4iHaqQUpVQLLMbLwjDEWYwIi2ySsNTh5Yobu"
 @"fsHG1j7ZqIvmGYXLmT2xQLUaM2OFNIedno4FEXIac0Krbam0SpTEDByPtip8eD5gyUCOEAKRQiogVjFe8H6clilYLf/bq8eZMXdnopVmhed2HP/pQsLlbcE6IfApmddyjj1X8uEIC3hXYCtCZc5i61GpVCKQbO3i"
 @"ixwbB6gI3iwTxfdioiY/+YmzNBsRz379AoPBVYrROhQjRHO8z86Lpi+Vwnlj3bojdeCkC+EPyrVxhAmUgwPzdovrHSWf5Iig3QEfRg6EV8tBFjFNxD6JCTG2hglqzMzN8fCDbW5uD+nt9SnyXXw+QLVgbnUJi9CI"
 @"Am7uFvS6BYowd8xw/KEGlUXLIM8YDjOqoWWA8Px+xkvGUxFL3QohjlANkQZUred4LMz4MplxAYi48RFtsVrCV4kx/NW+5z9fG7KRR8RWyxpRDOo91hfkaUGSJIQISoKJIWwEBFUhqgsmV7YvryMCNopRU4Nglers"
 @"WT7yyYf58Mcf4T/9h+9z9fWxtky+j/dD1Oefhfyykl8G12E8G3gwq3mr7NZRptJEbnL89+Eu+63DLndgButYQkRLEQMzUa8Q08RKhJEIYyGoYIMZfLXBwtIsM03Lcy+NyPp9xO2RZ/sEUcTssSWiQDBBwNpuihY5"
 @"7ZU6px+JMXOeoc9wDuKg1OU833W8ZhRjCgxgC8BkRAgVF7MYZ/z8aoVZCUAcFkXUlHpUAhUKhibgG7uOP99I6NkIqQTkI4+TCFyGcw6rlmLQw7mUwEagEFTqRLUaYcUT1AxZv0dnfQ0jMTaex0T30j71AH/rFz7M"
 @"uz9wij//05f58z/9Ltngddxwt5Qg8SNKFadiXb3vi7qMsfQITJSb3JFRd1XBH6rbg7eOutzm2GMQdqwBNhmQKQv3CLHtseISQRATRC2i+gKnTy4wGsEbl/fRJMUXGS5NmFk+RvP4MSphybLa6RaEVcPKPRVMDQap"
 @"JwgsrVCpVSzDXBiIwasjjALEG5IkxZuCIorIjedEbInEUIxRqsh70GCMtij7RDy77/n6Tgq1kFCVQTGiEIMT8Di8ZoQ2ZpSMUK+lXIpAtRoTxpaootTjkO2LV9nZ2CKKqphwnmrrfn75lz/OI+9a5Pf/3ff43tef"
 @"p79zmaR/A832UddD3ejX1Wfn0WINfE/R6UzgUQCb21pJY9Rm3MTQafl2QI+fPsvcWVn2MFgqE+0YA1IOa8gkiTERJqxiohZRc4GHHz7GKIUbawku7aHFEHzO/Mllqouz1EJhmBT0Eo9Xy/VrHfb6ORIGqEJsoFWP"
 @"mWlGBFbQIqMSClFoyJzDZ4pPyrv3ZDWiLQbrIVAhNYaR9QRGKRC+vuf5aiejLxYJQyr1kCBWJPRoOViFNaCuIEtSrAkxWlLuK/UIExVEdaEawNbrVxjs7BNGDUy4QGOuzqMPzvLDb2/yl9+4wLB3AddfxyddtNgH"
 @"N/oN8dl5fLGGn7T0DlJncycsdMp8ODCuEX0zPRFz27knk90LZqwQbyZtJ4PKWKfa2LYa0xQJPmVMCDbCRHXmF9qcXGmytt6nt9fF5fvgE5wxzN1zkkozolUN2O25cgSsqNDfMoyGDhMApsAbQ3dYsNfNSIcZvvBl"
 @"ZyJxaAEuU1zqqThl2QoVP74x9UCR8aYXvrST8439hEFoECd093NG3YJmtUq1FmBCX2KgNqJIC/KkwNoQtYKJLWEjRMKcSl0JC8fGyxfQUY4JGkjU5viJWVYXY7a3Ukzex2R7SLaP+BH4HONdB6cpTjO8RCXwoocm"
 @"bf2RMb/DXaHDIoPmTunJ3QWBD+Jw2f+b/NuM3bg0npiJ91nUhJiwioQVjrVnmWuEXLm+Szrao/A98DnUG7TvP04zVirWsL3vGat4EwRVoigq+2XqUSN0M89uNyFLHeINVg3ZMEddgHNCXhTMAPOhoTCQipKMz5Gd"
 @"3PLFzYxvDIekUU6gjhSLc8Kw5xC1tNoR0WwBkSMISujOOcrzzxpsIyBsGWyYU2tZBrsdNs9fJlBBgxo2XuSBe07j1fPG+lVsvgdpjvM5aI6qf8ar75dlg2ao7zNWzlAUvJ8ayfDmstXmiH/dofd35yL+MJRmDulc"
 @"y1j2v8xAjbGlUHkQEcZ1VhbmoIAba7vkSRelIM8KWsvHmT+1RCPIES/s9MoSIDd9TCPFVhX1jlACAhGyosA5Q5FZQlvB5cqgl+BzUDUECqs2Yl7GXRZRAiPcSJU/XBvy3X7CcqPKatQgKwKKcVXofUCSF8Szhvnj"
 @"VSqzISYISAY5Ri3WBNjA0JirEjcD4pql1Yq4eeMGu2tbhGqQsEKl2eKhBxbZ2k65uLkHucc7TxYkOByqpbKvUqx5X6yhRUd9cVviP5HB1jtUCJMkxqiReFrLya16XLfsczhykh4SbC3VJxoY28YEK6VT2idFovLc"
 @"sDWI6yyvNtjcLdjY2EOHg7K2UmXpvuPUl5do2JBh4hkMSwlqi1BvQiUUChcQIETWI6lBRhbjM2qRkvaVZFTgXYIUIVUXslITIqPkWnbdLqeGP9xI+EHfUZiYWhhh1Y/7kBbU4jXDaYKxntZizLEHZtB6wmAwQoIK"
 @"YgRjI+LZGnHVE9UUW4HNV2+Q7W7iQkMYNliaDVlciPjB6yMG+wpuiPMZ4vxEi7U3ZpZlRl0fLSZwC+ZQZ14PIzG3ylVPy4gfLQx7RzEROcwYnsiHSLCChGcw4RkxMcYEGBOA1KnWWpw80eL6Zo/93R4uG+DSBLHC"
 @"yrmz1OMKjQDWtxPyNEPFYgyELYtUTDnfHilOyilahy3DmbXs9zw+j/HeYdQSzwj1GUPooRDhfOb54kaP17MAopg895zfSHBZAraCV4vTjCg0tJoVAgOFpCyeDHA3m1yrVMvUPfCY0BLNVAljQ70Z4gvP9Vcv4UcD"
 @"TH0WCWosz1eo1yPeuL6LJEOc28f5USn045Up1qkSyaQPqIdkJg/pFYge1Rs/EL8bj1gfrv/u1HOSN+0OjvEXMRFGYplIJJvqk6XAuEHCEJEGy0tz1CuGixcHDLs90nwPTQdEtRrts6eINSO0ITf7GakEZNZhrRI1"
 @"BY1ymkOlLcJGYshzxbmUWmwQtQwHGeoMhXoK42jFlhUr5Ba+P1T+fDthqyinhgstwMB+AlarZaopCc0ZS71WJawp2BzjgUzIugXihUrF4iXHNIVqM0RjQ2umRra7z8blS2hhCGwVE1VZOd6CULhxfRubdsiKAbkm"
 @"qBuirkBLuKwHvj/dzTQBUybJi3JEIU3uIIr+N8JC/US0rqS/RYJpILZtjGliIySIkdCW8v+myonjLcII1tb2yIZdsrQMo3On76F5aolYPFrAsCcELkLyjLCmhBUo8pyGD2ioYbif4QswbkTFRGQjR5amZS4VGEQK"
 @"zjZCZix8eVDwlZsZ+2mF0BSgZcHvtew1mkCoVKFeD4ijoByxFiVNDf1t4eYl5Qff2KbfTamGAVHdUG9XiGuAzajGIdsXrrN3Y43AlEyDIK6xsjLHtfURaze2Id3FFwO8L2ceRf3TZf9VM9XxePsYLjs8DyjoHVNI"
 @"PTIjeNt84MHOoknhficv1MMNiXIFTrMc1LdtNcETNgywUY0gbmCjOSSqsnq8TlZkdLY3KUa7kAzJs4T5k6uElYjQGEYJpCPBiGLCgGYrpBFanCuohjGF9+SpxzgDhFSCmOFeihs6bGAxRchcU1lsh3xj1/MX2wWp"
 @"GmJfUIxh7dB4KpWAsGIJK5YoKrHQooBBX+nt5Ox2UnqbMNoKSXeEcgZIwFpqMzFBWBCGjpoRNl66QLK3RyOsg1SoVWssr85z6foug91dKLpoMRp7nmLKdlGKL3HPg5DpD+1w01sgszvJV99hxFr1La7ZOTSjPV7x"
 @"VuKeBCtiIzS0mKiODZeI4iVss0m1VufqjT6729fxRR+yEYUZ0D6zSDWMiKoR+90czQq838M5SHrCzqsZWKU2U2dPPd3djCKxeDVIzVAkBWEMphaCrSL1nB/sJ2zsZgyziECENBiiUsd5oW4trZrFRkoROLyzDLrK"
 @"/k7K/o5j1BPSvsEmFhlkqBvRWokQp5goJJqJsIFSq8X4Qc7l778CaQaVGURC2nMtGjNVLn3zdfLBTXK/jxZDxBV4imeMFmuT8kEnOwjlkA7FnXYXvpUR6zcrG+QQQ1gPN3WnG8XGMxDGfkpMhcBWMFGNqLZEVFtl"
 @"dn6e46stnv/+ZQbdPkXRx6U9wrhgdq5Cf6PDt75/g82Xz7P18ha9/Rtk+32SpI8UI0wA1UqAMYYMixQhBAFzixFRo4202lRXjtE+fS/hiWWu2VmiVpUZD/nAMtKCtBjhncElnmKoNOeFxnyNTiehs+5IBwppgMkE"
 @"W3gCb9ne6lMJDGcfXObm5j6pU+JGBFFGpR6zv7XBtZcuYDVAbIANK6wstxklwqWL61DskLs+xo2FfSjWVX0f1VRV04MRrgMAZUKWvnUl350UC8didwf8lsNsqKMpq5mee4dJF1rWC42xPFSkVlBjibTsQNvWIrX5"
 @"Y/zcJx+gWRde+v4l8uGAIt/AuA6SRjz3v/57+Df/hv72Gma4Q2WUfDbwrjNXM41azXymWimB9WAfgixjEKVkI0/Sl8/2Xxz8x93cnc/VdvKw/mgwv/xi/fgpFu9/lLmz99E4eYK5E8epzbeJo5BMlFw8/dGQel7D"
 @"5kK3kzIYVbAqBBiKPMEVOaRK9+Y+PhGuv7ZGL3csnpqnUgFXM9TqwuYLVxls9ghNHRNWieMWZ862GQxGdDY30aJHkI7KEsLn4FwHfE/UdcCPZSbHRbtONGH8gcjdtBr0d60LggM5J7krF/RwHnQwtDRdUBWLmAbY"
 @"thH/jDXuCRNUCcNjBNV5/s7PPMyj71jiX/2b73P99TVseh1J9kl8H5sPf829dC17sBV/YflYjZWZOvWo9dTZdzzMmQdP02xY6jVBsoLXv/o98kGX+z74KNvXdrhx/uZTwzR7qjcYst8bsttPWe92uHn9Gjvnn/2t"
 @"8755OYkXPm/mV2mcPsPKgw+z9M4HmL3nLI3WHEhEtye4RAhzR6BKYQP6mmGMobuzz/6gT+gqpFsJNKtUGxFxxeIrBZVAuHH+MmlRUI9rSDhDY67F8eUZrl5ZZ9DdR12KLxLUF3hfPK0e/Jg6IRMu0uEKYCw5eTRy"
 @"+rvgYpMRa70zLf52/ifTYQtFECMItsw+Kff0GewTVqsQNtAo5m1vX+G971zh3/3hs7zw/GtotkOej/BpykLdPf3OdvXz75mZYW62xnwbFmPFB8oHP3kfzeNzFMMEGxuStR0ublyh1gx5+J5j/NX5S7BxkZlqjdlK"
 @"yL2tGWwUYawhVWV3kH56bavL+RtbnF+/wIULX5E3vtL6xfrS6T9YfvgxFh9/N8uPPcLxc2eZm6mynQ4YZUKQeeJhgc0rbN7sQ+JLzqhVgthSaQRo6KhUhWIw4MYrFxFrsVEdwjbLp49x6niLr33zJbJhF+8SVBO8"
 @"Znh1nVIO2/fL8kHH6wcmrmamxlI9GHHXH30GmkZpfQPeIOPVabeMsMCRhYUTI46zTwlWyiQmQqQKpkllrsZPf+werl7Z4dvfWoNiRJptEaQb/OSxgrevrj7psoTt3T7XN2/w8JkqzbkK9aUGUThksNeHTIilxu7a"
 @"dUY72yyevp9h3ufa1csM+yP8ICd1BYgQWSGOQhrNGieaLe69b5EP33+MzjDhhzd29LlLG7y29vyv3vyzH/zO9a//p/9bdPLe3zzzgQ/w8E99jNbpc0S1WQYbfTTJ0Swi2U0IHVjrcRjiqiFuCkSOZiOgf/U625c3"
 @"CcMYiRrYyjz33XscE3iuXVtH8z6l0E+OqHumBFpcR3QyuDIOm3pArEYOifio3IVScbTACG5vRMhdxVyPxF9lwrweb9A0TTEhEluIG5y7/xwnV+f5t1/+Hnk6JE+2qI+u8aFl5d5GzJW1a2wOMwrnmSNlJmqAT2mv"
 @"nqYa5KRFRhA0ib2lf61DkXkWVpYZ7fRIdhMqYY1CFBOYaT0kPqff69LrDTDEGC9YAw80K9z/3vvZSfIvrG33v/D6tV3Or3376au//8LnX/3Sn7y4+s73cf/7P8bigw/DsRZ7l4YMu32sDXGmAGOJaoawDkFsqEWW"
 @"yxcu0+/0sCbCVurUGy3OnV3ixtY+Ozc7iO+BSxkTOp8Q9f8MXEdxHfWamvGKv9uSFNUfOeguR87ANwXP5A5yy0dgtJJ1LbaNmCcDIiSqYptVHnvgLN3uiJcuXCZPN5DBGg/MFTy0MsP5N/a4OjTEoSVSTz0wzIrH"
 @"iqe10sZpQTEmSxW9IRvXNyGuMLuyxPrVa2g3K2fq1GGMR7wjMAYJoxJY0XKQpZ/k7O8PSLZyfBAzV69xbrbOQ8darPf7T754o/vkd6+d//U3/uOr/8Plr33xf1x89J2fOveBnyeuPEwUWhLnwBjiKKQ+UyGqGuJI"
 @"iPBcffUi2TCnUqlhwoj5xQXuP9HmL1+5xmjQBTdCfV7ul/Qy5noWa5NxPtVbR8Z0Or+hP8Z6gAA0k9sq/zsNmnnGu70PSE2mTGBETAMToEGA2Bb11gxn721w/vwmnc01/GiTatbjdCsi8SnbhSOwlhBhmHuMLad0"
 @"qrMhx86eIGjWifOCIIzp3thkZ79D68QccTPmwvnXGfS7mKAURghDIQxCsGNdUlFEM3JNycXhQwgplXY3dods9XrMVDwz9ZifPD3L24/N//ZLV2/+9teuXP7ola++8X/Z/s7z/6/F+z781PKjn6S2dC/9xCMhVGZi"
 @"TB2ow2Cwz9or59HC422pOrW6uoCpWl49v0mRDEuVeu8mCMszqr4nHkQ1Az/lIflDO5Mm8xHCneBNuUW9t0w8A7ltuPP2bAf8lDYvYsowawRViQSJRUxTbICJIkTqzM/MU5+t8cbXf0jW7WHSPmE4omWq+F5KkZWd"
 @"g8AXrMaOe09EzC7WqTQs61c2uHI9RHxOWFW0m7B0bIX20jx7nR3CWpXj507ickeWJbgsx/sc7w0UBclYCcM5RXKwhSX34ESoBIoxliIP2Nl1oDvEkeXtqzVmZ1a/8tKVHV7cPC9bL176v++uv6BnHv9l2ve8H1ed"
 @"IWwLYa2gUgvZeWODzrUbGFG8iQniFmfPtOllyqWLNyHPS+/TcuJpukBZNZNx/afTLc96aKL5rbUSOKLY+6ZF/6FdgUcgVzNlnpVJkGmKBBipI7bBXLtJOjJcfmOLIh8S5AWVKnjJ6A0GxHnBvQtzLM8LzYoHGfLC"
 @"9Q06L6dsfPE8hTMgGWJyakGFSlhFxCORIwwjIlOjWRHazTpz7SqNOCAWhy8S+r2EXi8nGeaMhp6kYLxGwBOIYrHouAFeOMdwmOB7A6pS497FJeLWnF7c7vza1d2X5eJX/r+/0t66+HvnfuEfsXz8FKGMqGnAxZcv"
 @"0NveIbR1rA2pVeY4fmKGjY0uezf38BS4ErSezI9kpXyW7ymaTeTJx5yGcejUg847P1YIfStNpKOa6eU8W8n9LPUugydFylWo2CrLy7Pko5S9zhDRAu9SagRoVmAk58EzC0RBwcXONje2b9LdG5IW7mmv0qMwBJ5P"
 @"IyMMHhjhZO8Z54sO4shUzycSPBeZ8FwrMr+31ApZmalwql3n5HKbxZkZFlqO5gJsdXps3dynN0hQb7ASQqA4EgoUJ4LzBkeFvRw2u12iqMm7Vu/5/LHZwedfXbspWy/+x/MD3X1u5cSvcvYj7yHLPde++xK+v49p"
 @"1hATMjMzz9Jyk+eeu0I2HOB8NqZAePCeKe5ZpqJZ2SbSgz1JcrhN9OM9gh+VpjImGE7pWIeVJRkr/TLRxQ4J4pjjK22KNGE4LItiEWXWOmKndLG8dv0aV26u/fp+Zv5loLJiCppOXCeS/FzDyN+JI0vFxsSmFGrN"
 @"RJ5QH+JyTy93FN7/fFLkzyepe2CnpysXN+Tcd8Sci8L1T7dqFRabEcvtmOOLFZZPtlkphF43o9vtkuVJyfcUO15S7SmMIRWPp2BY9Mn6GaeacyzcU9UX1m780pUXvtz80//Pfu9vN/458w/cx9qLr2KKHLEBYVze"
 @"sPWG5dKlTUgHuHyEelcut8Ij4w68jIlLU8/USfE+WZf01j1v0mT4ke0klUM6MpPdStPfU4YEmeigGUMQRTTrNVyWUuQgUsWYgPmqYW/U5y9ev/IPtwf9f9u0lUfDwJyOdfS2diS/26jPMBcZGgGY0BJrQKgebIox"
 @"BldAkiuDzDHIiz9KvJIXZbaaAZmHxPnPrvVGl9c7o+gH1x2VSB9faIRP3Lcwx32LCyyuLJG7nP7ukH5/BK7kXRoFO7J4LNaG4JSd3V1mak3ec3z1D1phnx9eeOnxr/yL/+m5Rz/x0/TX1xEsxjQIKw1O3zPPbqfg"
 @"yqU1NOvi3ehguaP6p0tReU3xrlPSBvUoXVd/PJmzO5+BU/aTf/P6X8szReQg+VE92EKPGHxezjGUe9urWKnSlSEXbmywPshfqka1jwTFIGoafunMfOPJpYqlQsCcDQkjT1YtaFUr1KMxdXCU4Ash9ZZRkZNmCf0M"
 @"0tSRuoLcKamDJHNP9YuCvTynn9p/tpfr7+x18t+53ll/7LmrW58/O1Pn/tVFlhdaNOsVtvf26fY9mQsY5OM9tt4j1oLCzXyfhtS47/gqWbzzq9e+981P/uXFC1/MRjkmbGFNkzCucPLMLGvX99ne2kHzbjltPPbA"
 @"ybk33gyQHYbG5BZ9VX2LLaQjhbyKpirT43TKBD74JYeXWSkYP3VcQTPxmpXpshsL+Dg6vYLFuQpRwzLqV1Gp8Mp6xn7XYuO5X5Ni7wvtWJ57fHmRmXBEGHvONpss1gNkFk6/736WTi0QhoYoiNi8uMaL33iVbM8g"
 @"toozEYUafKEUaUGWKt1Bwe4gZW+UsZMF7ITZb/ZzJcnMM0lhnuvkfHJwM3386s6N35xv3uTksRYr8zPMVWBtY4dhluGiAG8VoyWgbEzAXpZTy7u8bb79ZOz9k6/ubnwwCBe/aSp1iqDG6TOnWFxo8L9983XScftJ"
 @"fIL4UmZSveuIL9ZUfa/kHvnxlT7Y1jnd+XHLHvnbDadvJYnRu5QSt6wUUE3LnpbriLqnfZE/6fKcPMu5vt7hJ951juPH5xnsJ1DUGAxCsDWkGESt0J55x9kTLJEyX7WcPrFI3RgyHXLyHffx8PsfQW1O4RLUO84+"
 @"uspov8f3vvoaoVbxRglUCYwhqFWgZmjPwrHc0R9mdLojrnf7dEY5aWGeKDxPjIqcXlbQ9/rZfi9jvbf9VMPe5OyxeRZm6iwjbO4VZA40cBQGjAuxhPTyhKwvrCwssZPLr6ynSmACnLMcW2zTrAd097sIRblKtSzc"
 @"y1Wv+B5T+iCHFh3rkcRQpnmpv/tA0VtKYiazfoc3kOk0aTkUR31fVVPREl3XopTPMumAyxevIeYcH37/fVy50SHJZvGmBdLB+n52cmHmD45VLfUs474T89RNTppnJIFn8dRxnFEGgy5eMwqfslCZpTVfR2yBOgUX"
 @"lR/LewpyhHKNaYDSqhjqYYOF2Rq7w4ROL2G3l5JohYKA/TR/ameYMcj11wbe9beubESz9fgLZ1cWOLPUZne3x5bLSE1I6B0BFhcGrI0Gv7EcVj9zZuHYp3qbfTJVjML1a1uI99x3Zo4XnvVoqTyDTBdpHqqzp0lK"
 @"ObgierBO/q67q0SnxKY7fd9oecDeUZd5+gRzdJ+SlLEdxffxvocv1kRzimKEJjfZuHSdbz13nY9/+Ayn72vjwiZemigxYJ6sRSEmG1GrhQSBIS0cmBBbGDbOX8P0c2aiKo0goF2dYbCT8fL3L+OyEKu2JDiUc2HT"
 @"mUQUvFPy3JPljrhIORY6HjnR5syJZUaph8yzUq9x78IMx+rB5w15Y2iDr14eeXn2wubjb2zfZH6xzlKrii0KnDpyA0nuSB39/TRhrlbjeL2J4rEWOlsJ+TDl9PEq1kalBjYF3hegxefQcrlY6WUl27u8hlIu+NBy"
 @"3E2PjFRPjjM/zVjv5oVvqSN/dMxpsiJ0XMMYzVRdR3zxjLrhEz7Zougd44tf/iGPnGvzt372MbZu7LO+HiI+ArWk3lNg2M9yEh9irccUSuwNV753nl5ni9V7l2nOVNjbH3D+pTW2r/WJqZV1lXGoGPykCe0FR7nJ"
 @"w8t4+qgol3tkRcHVrR1GzpIFkA67VEPDybkqzVr0+eu7g2f2E/8vcxNc/v72frydp+k7jx/jHhNyoZsyQEkL/1nBtgtVAivMVCtQ6BQOVmeoxQZrxt6nboLA9AXfV3yfcf/vIPv0P4I64d9SNmre0kYIucPMYFmo"
 @"9kqKnOuoL9ZxCT4bkCU3Wbuxwe//hxe4d7XNow8skweCiCVD2EszUhNzo5ezvjMqdcR8jsMTSsjO1T1e+OrL/OV/fJ7n//PL7FztlaxnycvpIyvjFeIyHYsrUUVfRiyX4G3MvjT47qWbXO50EVt6rZeAQQp7vYyQ"
 @"gFPzc0+sNipfiTV/m1Tq0bUh8p3Xt54uqHB8dgZTZGReel5tO8KCVXLjCTAYCQmqljAM0VQwxqGSgbMTr0nHEFqK+v5B2XB0U+dhUQm5yzn4ow0oeihhucPRKYcA12m3yWXl4axZacSMwiW40R5uuMfF6/vs7Q45"
 @"caJV3qmmggYRndHoHw69gm3w/Bs32OpnmDjGU+AVrKkSuwpBEhC4CrEJAU8hjkImWqZj6ROvWFWMd3iXIb4k6A7U8sLVbS7vjCCsgDjEOfCCNxEpAXtJyjAZ0WxErCw0/6jmio/GNn60o/FvfvPy5i8pAauNBlZc"
 @"plbTShDhnaHv8nHLzlKbCajGhu2djMSPUJfjvS8zUHWd8QBtplPirp92Ht5cDutHtfUOKzWJjhu5/o6vOYWF1INXvMr48NWyzpkkMuRPO+2joz38cIfebofrN3c5dWaFmcYsGjWRsM5eZppb/YyZaoM9DfjfXtrk"
 @"0q7DBhUCY0pdFFyp3IRSqMcR4InwGpbs5nJxDuod6j1gCMIaLqhzo5/z3MXr3NjvYcMIGQe0QsAZ8OJAckQ8ufMMBglVhFMz83/UdO4Xg9iu7tjgpeevbv7jKK7Srse/HVjNbBiR5oZBqhTWgA1YWKgTGnhjfZ+0"
 @"GOLzAs8I9e6ZaQGvEzzLH9oIzljVkTuISsih3fF3MuLB181bqvpvhQxUx41KHc8Waga+Z1RT41Jy3cePdkk625z/4Rqry/Pc88AJbDxPELZItPGFq3sFCZ5j7UX6meFLP7jGNy/3uTGwOBNhwxg1Ed6GiDcY55Gi"
 @"QJwrYSqXYfHYKIC4RhrW2Bx5XrjW4TsXt7g5UkxUw5gx9djrdLu3V1++/RLoQkUYDjNCDCuzM58Ji+J0GETnOrn/4hs3O8zPLzAXVT8diqFfZPRyjwR1wlqFh+5dJEe5en2DKMtxOgSvlJIhviclfTC7DSYTvcPu"
 @"Db2dDXhXIE0Ph1C9XbjnlsP1diNOXsj1VX0PdR3xvo/PKOjh010Y9Xj5pTWSkePDH3sn8ewyUe04ttLiRup+7VqSUw+anFyYI9GIF64P+fprm3z7/Brn1/bZHhYkHjSICMKIIAyRwEIYkgU19n3MWs/z2nqX7164"
 @"wXcvXOdiZ0BiKphKrbwEOhkfN2XiM5bz96o4LZl2uQiZDRimCY3Acqxe/z1TSKRR4+9c6w7OjNKcpVoTayydJGOoAUQtZhdnePuDS7xxY4eN9XVsMQCfoqTI+JpM8oTDe4dhUhoczS5FJsWEm/4Bf+jP7bmIDWjE"
 @"qsXIjxEYve2Fj2ph63jOTg935kVcyU6zbRW7qda/Cx8gpkamLeaXZvjIR07z4vltel1LUKT0i+HPFaTPrNaq76qHgojHZQmiSneUcXk341Knz9pOj43uiM4wZ7OXstYdcW13wOXthIubXS5t7LK2N2IvcSQagi2b"
 @"uqgvGd7CdAmljleilyA2eC9laEXITfA08O6qEZqNWXZG/tuphGdydVuhkB6bW3p3z8GVXs7ItIhmVnnwHY/yCz/zMH/y5Vd55bkXyEc3cMk+3u2jRfYH+PyK+GId7/qoG3cfivFxdGv2+db2dHBLwmNDadYUN/Li"
 @"prH51izo8DTMuJWEuXW1+FSZMDxh4GVVeVepTlFnlFV4/wfvYX5xltfO76BZROoKeqPuuwIdsNKMqERB2Z8roAgrODEMC+gksNnPWOsmrHVHbPVybvYK9kblzzpbboHBBKhY8GUaf1hFaiL15Q+Vy4qdGs+pwSFf"
 @"MWI/2KzViWtNOgk/Myh40RmJrYRPLSyscqPnWB9agvoq9flVPv7T72FhYZ4/+MNvsX/9Mkm6hqY91A0+py47j88v4ovrJWF3Qp93t2Sgb71kOOxQdzXg0VjModVWB7MTHFLsHd/VDjGBGpzFLoTeVL3492ENoaky"
 @"zOYQqfBTH7uHQVJw6UYPigKylN1hgvU5880azYopk4q07GiXNDyLtYIYMMYSmJDAhIShxVpTethE1WF8LnsMbmJQKefIS0rIZDWQRRGcCnnpjU+Lk7hea7672ajhTchGv6Dv/XPemkYlbL3P+QrX9nO0skiteYJT"
 @"9z/A3/759/Ot71zm2a9/D9fdIkk2wO1D5r7vffIcWlxX7/plRFBU3bi9dCcZlx9XW76k/9pImjVwI5VJjL5bN0Km+wUn0PeBDoIgyMiIWC+aKXYWkWtGeJeYEGOqrO0aTq0u8smPneH1G102tocYbxh5ZXPYR/OA"
 @"5Wad+Qaoc4xGbkwZ9IgvV3LLWKFPbJk1TxUbpu9c8Ubwxhy6p0uxOz+eJDYYxFtUDYUIqcjnEs93qkHt/9lutAgt9H3IWldJrXm32PB9rmiy14e8MkPcvofK7CK/+A8+TKPV4Pf/9Zfprq1RDC+h6R4uH6J+8NvG"
 @"5xdV/f54sgXUld7n9bau3o8n8nnYrQQbm9asqusrnokR71xIym3jvaW6lhmPmY0hWYOoiJWyT/gzXsp6LXVVNnaGPPrIMd7/rjNcuu7oDBzGDcnJ2B+OyNKMmXrMfKsCxpAkpUJgKYRoUFPyNEPx5Q4m7CGJTDOl"
 @"e+htqbcZe53FS0QhAZkxZAqZ4w+jsHJurtV4X0QFEzRY6zs2hxEatTDM4YM6fq5OZf4RbGWFn/jJx/jIh97G//K/fINXv3+evHedPLmE5j3UZZ9Fs1fUFeulAmExDul+upfqaJPgsFH0xzdgJM2mV9f3uDFOpz/S"
 @"eeWQFL6fhlIY91ZTQUeC6wj6PcT8nGIIgP0RXNnMef+7TvO+95ziyvqQmzsjAh+QS8F2UrA9AGMDFusV6pUqmRHyIqXQcttLSEhMCFJOKOlEIYOyyz7eD3NE91QnK9FNSC4BKUI+hgdnqo1PzNaa7xOx2LBGJ8u5"
 @"0h2SVWcgaiC1Nnb2OFHzXqq1k3ziY+/kF/7u4/zJn32Pr3/x+yT96ySDC/i8gxaDXxMt1tW5jvrsFdS5SVd+UsPIHVWx9McMoIfPQBoxuFHpge5Ajwu5u4q6mPGb4UBgRsfysGrQkgSGKA5kiPBuox6jQmegXNzw"
 @"vOOhZd7/ntOsD2BtPcX48jX7ecHmfsJoWFCphMzMVKnHFUK1eB+QS0hqgumOpnI+0eIFCkyZlKDjkGnxMg6pWq4WQCHA0oxi5pp1KmEMEuKiiJ2RcmU/YxTPIvVlgugM0jhO1Fjh3tWz/PIvPs6HP/ogf/afv88X"
 @"/+xZ0r1tRr3X8MUWkueoS/9nfH4R5/dE8/VJ+i964H1vTt/kr+WBNRU/8jLOkuTw+rk766TJEZUKOcj4Sgkkh+ioDFymqZiaF/8zoFif4YqCrf2CC1d73H//Aj/7iXMUKly/tkeW5ogUZF7YyAo2+/vPaFa8q1lr"
 @"sNhqMdOoUasYrC1KHH6cpDi0JAF7odASKfJ+DCer4BTEhoRhRLNaY6bapBFXMTZCwypDDbm+51kfJmTVRaieJqid5Mx97+Tt73oHn/zE2/mVf/AYMws1/vW/+xZf+tPvkHc2yAYXccV1yEeQC7jsD1SzV/DFOlpk"
 @"6ktQu2Rh+0MNoR+3fPhRBlQ3KkOo506bWg7H6yN6vsK0PcL0HFS8eBBGYGpgGhj/HFJ8wgNSeIwr2OsnvHZhj1Y8w8/99AMcP32Czb2czr6gpoYGEQNv33Vz5NkepAzzHBtEzFQbtKtNGvUWtWqFWhQT2pAwDEsZ"
 @"EBMQBRFxFFEJY6qVGq16k2atQb1aJ4pqaBAzlIAdJ6wPMq7tZXRcFTOzjFTvp1K/h5//xU/y9/6bD/L2d55mabHJt5+/yO///nf4wfOvU/Rv4PtXKPJNfNGDIv+c+vyP8aNnVd3NcfIyLtjHEKTerkMgP7bx4PCW"
 @"a0GQmhyLvOZZQY6X4mBebTw5qm+i2nQwrWumL6wiqJXxbti4UW6vNk1jax/RoP4ZEzeJbZtK5SRm9hS1xVXe9/4H+NmPP0Atsnz5yz/k61//HjdvbFGMdjHcxBcdKHapUjAThCxVqixVlHpFyi0uOLwqhVMKrzj1"
 @"HMqVUSklKjMHg0LZTXJ204xe6sl9gI3n8fEpJFpkZmGVT/6dD/DRT7ydr33lFV55+Rrbuxtsb23jhhmu2yEb3cAV22jRw+ejZ9QnzxmfPO9d8px6n6l3JaWiZKRNDXhYaeKvW0Lc6oFSkyWc5jjyEuQ9ZMA7ZaNl"
 @"p/4QGiDmiDG9TDXTEGPBBJGIbauNH8VWHrdB9TclaGKiOeLqMWytDY2THF+5j5/6yCN89KPLjJIdvvrVG3zz2Ytcu3YZTfewRRfNujiXoloQ65CKzakGnopkRMZhFUypVID3ivNKoUrmDbkTRoVlmEHqPT6IMGGd"
 @"MGqiZoawcoJ3vvsBfvbvvZfG3Cx/+Adf5ztfew2X7OD9TcTnuKxLMdrD5QO8G2Hc8HPq05fUpS+pT1/E5328Q7XA6ESkZ6xG7w+68Sr+TWx3q2HNXYxYRjypsoSS4yhwUox1Kv2RM/CAXnFgwINEx9witzxGZqZ/"
 @"DGKCCBOsYMMzYqJzYmtfMEETE84QRU2iYIEiXsI0Fnj47ffwsY89zNseOU5WOL73gxu8+P2LXL20zv7ODlk6xBUZJu+OhfIGSN5HXIK6vJTvF1/KMoop529MBUxMYSMwIWrK1QdhXKW9sMC9993De977MOceOMHF"
 @"C5v8yR8/z+uvvYhLN/DJLr4Y4YukxDkn/+2y3/Iuv4zPr6hm532RnkfzMmHxHsWVewEnwP/UPEdxzSPiSqp/HQMuoDicOBzjC3BbEnO7B95S3t+yN6LMAFVsWSMaW+poW9MQE57BROfEVj8gpvppa6uEpoaPQ7Sy"
 @"QBifYXbuBGcfPMl7Hr+fdzx4knjOcnNvwKvnN7l8cZP161v0OgOSfp8k6VFkPXyR4H2GupKuwJi8KyYsEb6gSlCzVOoV5mdnWV1d4r77TnH/PatUqxFX1jZ59msv88qLF+j11vDZJj7doEj30ZIegfgC7/PP4fIr"
 @"3hdruHEjm2JdXdrBuWnWCQ6vfiLAdJvxDvQ/9W/mgTUpDVhQ4MiO3gVyN+00cxcR9Ek+Y8e1oR2rOI0vpjWICVYwwYoY2xYTv02MbTsbrBhpPRGaJnGlRVBv42uLVBtLLC2scM99Z7j/geOcOTPHbCuAAvpJn52d"
 @"Hjdv7rO9vUevO2A0Sihyj/gAsRCEQliJqDWqtFoNVtvzHFtsEter5Crc7PR448J1XvrBJa6c32S4t45ynSzZRLMcSUc410fJn9FxZ6Ek5xbr6n1PfHZetVgX7zJVB1qM22xlFBA9OjpWNgKU25VBOEoi42i0u93Y"
 @"050thw2YU2h+yL3fzIB3vjOmLcYJ/XBsPKZnokGtQQhWfCmG1xZsWyV+lCA8I0H0ZBjEhNEMNmyj8Tw+aCC2SqU2x/zcPCsrbe67d4n7z86ysNim1qwRVQxBVLZjzLhoLpvOBlcIaQLpqGCQdtnY2uHyhS6vn99g"
 @"/cYGe3sdsmEX43YQv4lLu7gswxVdxI9+XV0pxlOORBfrfsywLqmC2XnV8eIsxsmK99N6Tw9lnjolZP6ozPPNPfBg0+rYgHWziNeCgqyUoZrOZvu3kCWZO5BRGcNc42lfMQdyzKbsyWEDVG1bjGkYlViMbfsgflSD"
 @"8IyY6KkgqGJNA29rSBAR2QBja3jTwAc1NKpSi+ep1Wao1uvUm3WqjZg4LoFvNeUIXOE8eeoY9EeMBiOSYZ9Bf49s1Id8gOT7kPco8i7OlV/TYoTT9HPOJ8+LL9bwvj9xmlJZ0HVEfV/dpMM+yTLdwZwfemgL9NHy"
 @"4W9iwMOyy5O1rFI3ZRZakOEpDkRFb2Fo/2h4jUMcv0O/fCrLPE5oZLxjnolU5UTlMDyDiR/FhGfE2rYY+wTWYE2EkSoQYmyEmBhjYwpbA1NBJEZMVO5lmuikTBaqmfKCmTFdRHyO+gRXDPCuV6oI5iN8kaIuR7xD"
 @"i9GvqybPlQ2OYl19flkwTcX3RH1WZpkTism4TTSu9Q42v91KEzzoiN8poh1OEm9HZuQOBj5YgxSUK1LJ9DZA9a2Cq/omaLoeWaM27oVPiarj7n7fe81ENStJwtl5NFjF2JdwwYqzxac9o+ksjpgSB1VjMTYsddVN"
 @"MOaGjvFGKaPABG7L1ZfcGRRXjIcvfVZuDXM5qvlnwXXw+WXvi3XxrlOKkbuOqgdxnckg5oT/Bh4zTvgmU0YHNrt1Ze0BqffuycuPHuq83UsFqZtjkfdZVpDjJB9joXJbuvvWH+bIGzHThSAHXQIx5sA7D52XIjbC"
 @"jOcOxTQxwQoSrJaN/1JMTyRYFTFPljJtFj/JdKE00rikkenZW3JgSi8p1wiIOvDZZ1XLkIj6vkdT1HW8dx3xrgOuP0VRJhWcd1NWNWN8Uw/J8aC3c1ZuhcvuZMDbPfCtdOXH4EldjkVebzUgU2/5myAFhyWh9LCM"
 @"9/jiyri7P9k7iD2QMEEEY8YapArlLl7TECOxYBpCdA5sGyNxqZShmfoJkQhUTHOy3FJKhcKOarE+GXUu8Urfk3JyKHUyFh4v1wCMCVt6RIRuOnF0SGHwMGdoOrAyRT3fGtpyNwPe+etHDRiMWVPjd/DjtzhuvaMm"
 @"xatgD2AjBRU31VyTCdQ1CT0Tg7vxWapahj9Pqdchtl0ym0tjlUmY7ysSqY6NV6o/pDJdHCVRqZ5fTsV60XS8n6Enqtn06yX1PZtCXd6PzzU3fe9TKWo9APvL4ZWJVLW/hU97l71Twl1pm3cy2Jt55eR3SIMFcsZQ"
 @"GvlRSu+blBG3Lka+/eeOYnZHsdMxbjoZmpkkN2qm3Q2ZDpUy5tyYMowiMTLW2TySM0msgHhNS5rjePlkOcKclSzp8Yye1ymzQMdi48LhySF/QMK9TfLf36bqeGAwP20X6W3XSqfH04+7YvOoYcebw8ei88Hhlp4c"
 @"EfHRvxbUeqcOxq2KfABqfKlGpAAFBwtFD61xncpv+AlQ3leRvqhg1EY6HfMeb2ArPS+WUlA1ZXLHG01LORWXiT/kWZMkS3WsjHQoHKre0oU5OsOu3CIHMh5UufuNrj+Wwe7uHEeZEf9/OzQgnmy3e8MAAAAASUVO"
 @"RK5CYII="; break;
 case 4: encoded =
 @"iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAMwElEQVR42rWYa5BlVXXHf2vvc85937797p4Hw9DMjEMPIGSI+EC7AZVUfORLdyqiJj4pH3mUiSWVVHKnfVQRQU1VPlhgFKRSJt6ORkkkTnAcQDSE"
 @"NwUzDMK8H9093T093X2f55y9Vz6MpkoMzEDwVO2vZ/1q/9f677WW8Kp9IdWvxJU1+QfK0OaEubY+9dHSKbQFOAB0AktNvYjouf5V/j9IqioA90/f/Id9xWffn/XHNwfJapm4g2tro90KZjs68FQ9uuhHhy686Z73"
 @"vcXMgFKtVs3U1JT/jQLu3l0Nxsan3L3TX/rwG1/75G1hex80FRpNaLYh6YDrgPMkrQxHVvtOnwwu/6dnX3P7Zz8wLrOqKudyk+aVAo7N71XBqpx6/G1h9wWe7G91XDurrlNSl3Rr0q5o3K74uFN0YlI3UjpYeX3h"
 @"+x973bNXP3T39N2XiYhqtXrW+PaVwNVqE3bb5LS75ztfvW7dwreqpfaC5fI/CykMi1k5LCaJxXhEMCIaGEdgUpNRVU0Gi8d6VpeOvmn4/c//w9gnx93Ub+IG+/ecFFUVv/rkZZu3SIbGfm+e/SKyvBfXt5Vk+GIY"
 @"3ojtGyTo6SHT1UU2VxQJyyFByRfd/NDeA+QE9Jd5/GJf8EoA50cHVET0/q997QfPzD35+a3bQ0O7gT+6k2RuiaUloRkXsbkcJhR23jPHb2+vMNiN1o+tmAPxhuaXbiaevvHssV42YLVaNRMTO/y/7/rZhp/kX/tF"
 @"7vo5rZm7ZfS6TWRKDXRuhXhxjubcHK0mtBPoacPMowvMOG8KeavZ8v71j371pouAR9mxQwB9FSUeMyKih11lavPm/Nuf6Lnaz+zeIw/fej9PP7hIW0PKPXlKPSHFSkC+aDlvwFDIQLYQal/Riea6lsOtHzwOwI4d"
 @"+qrm4N7RMVVVOZ6a3o05XGF4RI6FRTbpKZYeOsCPvnOS+x707J8znG4LiYe2FzoSQDvxT0VXEF9z0yfeMT44W6vV7Nms5hXk4B4rss2985+ftZvnsF+7fpO7f+gu7vtelfOjnzC02ubwETjYgVgMHsEjVMKYufJW"
 @"nn7Xd7kk4ErgW9PTZ49mzj331IAwPbkt1t21otV07cFldKmZypXXjLPls/dz5D272HfZx1gc3EYS5UljT7PuaDdSZmWIOzf+lfStXUevrP4uwPT0pHtViqRWUzs5KU6rVfPNd37khq/G9s+zJTtS1ERnGtasnI5Z"
 @"aEGy9WrMlqvR5ZjW7HGaC3OkzToSZAgHNvDJgX7tXet57rH0MVVlcnraTk++NORZAWuqdlLE3fKDvZtr6/q+sWVN/xsXW3BJPtFiWSXXZ1iaDzlZT3hqdpkjy006XlHJYXIjRHkhL46wXue/Vxc1Ywd43fLCv4mI"
 @"fvTWR8z/dhKvBLBWq52B2/XcG7au6/veGzZV+q2QnqinJp4Vs//HCQ9nlhl5S4lCdxZdTIl9yPxyk1MrDZqtFnGrQ9xJ8C4ke/mF5m3a1Fxx4ENfv/+xuz/05svnq1U1U1PiXzZgVdVMirgv3fPMxZuG+/7jzZsr"
 @"5TwuPfj9NFjcKQyfMBSOhzx2wvFQ714yY1laWypIySKRYIsBgc1ACJGPsF3dVEZKJl5J/YaLR68y9ZmdN92zf7z1AKsv1TgEL9ZG7QBu3vlEYbi7Mn3ZSKWsaeIO3JwG/Cxg23pLqwinB6EnGmR2oYc9d8xwKjlG"
 @"brBN95AhLCuNwOO8hyCiPxNzaeApX5kxR5eSZPvG4cvS5Oid752Sd+8dVftiUstLFcXXHzh40xUXn/+ZvqJPW1/sBKVDIf03GrStpLtg9VHh9IJy7Kjn8NGYRjumnXSoJ01a2iaWlNQo3ggilqHiAOs+USTzkZDF"
 @"0ybZ2G3Cg8///AMfG99yxy9jnvUGq1U1k5PibvnhU+u7y11/HOXwyz9u2cozEf1/a/BDIBjMWqUsysK3YWa/I3YOa4R8Jks2k0G9IiIokKonFYfvQOOWGFNWMhMZO1dHu7srn6/ufvpfJsdo/F9S/7oPjt1rALJh"
 @"7o8G13Tn09XUP/65RArvMjAExIJPweZhdUZ57gkPxpAJAqxaxAviz7yuzntSl6LqERUwnqYmtG73JIcTs5R4H3UNrB3S8HpEdMe999qzGvWOsTEHSBhE786V0Jn7OtJ8LAtHBV0AjcAGkNTgmW8IHQCjiBisGAwG"
 @"wWB/ecQgCuIUEwt9hQLLp1d58tszSGRYbKGZTOa9ANx7r39JiavVqhER//nvPDIcRNmtziPHdnozdH6GbAfcLrAjytIxx0N/10GKEYXQkjQCYq901CE+xXjFo2ceOVUiK4ShQFY5njvBzpnHyd63lrXvWW/ahUB6"
 @"THjpp27d3Td1w/jCC2X+FcDR0VEBCMJgpFgq5jurTusHrFx0oRAr+INK8Lzlttvm+Wm0wvbbLqD5mVkKc46yzZLrBIQSEhlB8ThxtE2HU67BiXiJ/c0Zjp1axHqDm2+ydKQtuQuLWpZcqauUHQEWJqenf8W8X1Ak"
 @"E2dKW4Iek8nSrnvvYmuzm4VGVsHBnn2OXScTfF/IrjvqNA4vk55aIsp7shlFmwlhoBhNcT4ldjGdNCFOYywQ2ggMJKmnvpBgLsQHUd7aQPrOEEwwfTYf9N5Jx0PiIS0KSa/SqoCLhV3HExYKBYK0SXLXIpLJYLK9"
 @"5C7PE13Txfzn9iGSID7BaIBoQBAoYaDgY5wmGBVsmCFOlMSBBhYxQXjORp0Pw9PNVkyxEEraL9RLUOqF2ZPKYx1DcyiHiUK8pmiSYkoJ8Zyg320i/b0Yn2JcDD5GXAdNU4xz2Cgi9I5AFcnl8aEhTRFvY+JOXAeY"
 @"finAPXvOtN7dhfjIfL2R5Ms9YXvE61wG6eqG5xfhUK+h1WNQLN5F0HFIx2MTj22n0Bdh4xQbd7BJBxN3yJYdYQh+sUkgSlYtvrcIXSGiGN9a8XG7eQLgogle3AenplBQeZ9fOiouPtBwSvYSdJ+FlTIcKsHpDULn"
 @"AqG5wdLYYGmcH9I4P6KxIUPj/Dyt4TytwQKt/jJxb4Uk6KJw/QUU/mIrRF0Yk8eUykQbivjuyBcDpRj64yeOHD0AsOMF88kLJBat7tZAxsfTOx8+eteSk09n1ovf1xLTnSone6G+HtRC6sCpQCKYWDEtsC0laFps"
 @"0xI0A1wzJIoi5p8VguNtgnyBMM0Qd0f0jBYhZ/15JRG7kv7km1MfaNdqakV+9bn79RwcwwMMZNJv1FdXPrXfFczAiNcfNq34gqezBpwFVVB3xhAkEaQDNAXbUsKGJVg1uFWLK1j8YkJ4yJEtFQgjJbPRYi/N0xsZ"
 @"6aYtiyv128+55Z8S8RO1mr3uko37wuWZrxcja05779YMKceygg6BDggMgAwCA+D7wQ2CroV0jdBeK7TXGdprDe2hgPa6DJ31OZI1WWRTDhkrUOyz7rIB7MKJQw9+/HdGd1WrVXNOzQJAbWLC76iqybcfuLF/NX/d"
 @"AVl/3qnZtlt/XmT3B0LSASO/aIYSyGcVTaC9KEisaBPiOviCQB5Ytti2IQwswRbou8joaJdVtzyvq8v1PwV0dHTUnPPQJCLKDrj+HVctFZOVie1mvhUvRfbggy3d0Ejo6lbMoMH3gHYDXb843UCPQI8gfeD7hbhf"
 @"YBiyrzHkrwpYf6noBlzaG2qwvDD7lzdOXvHQRK1mJ19kNpFzGZZu/88nr5kL+mp3z5Yrj8/Gkhs0Uh7J0BgOWS1Y2ghpqpACHYGWQgNsQ6ikMJyBnqxil5q+fDrVt24p23Dp+b+/4erNf1Kt7g6mpsbTV7wfrNae"
 @"jqYmt8Wf/dcn/vrCSy+d+vJ9K+mTM0loQkPUExD2B5g+i+YFHyipEYyDqA25hifXSXGnYhrHm25LJW/fsdXSowuf++CbRv5molaz05MTHl58eD/rVDfKqKuqms739/5XlHbkC+O54Cs/TdNdp8SuDuWE4QCcEqx4"
 @"TMsjbWDF055rs7zSJG20qET4a0eL9g1rVg+U2yuf/uA1F3/3DNykf6m9zDntB6enp3SMHfKFjw/sf83Vv98Y6i2OT1xRCbcUEBu33UqY+HrB4bvB9QmubHCxIEspeZfqlZsK8Sfe2h8WVp77xzE59K53vv1NT9Rq"
 @"aqcmt7lzmcnPfQWsKojoF+7ed0lfT9dnCoXsu7srlUKscLgJh1sJJxqexbrSqUPGC6XI8NoNIaXTR5vLs8dHp/7g9YdufeSR8Ibt25PfyBL9F7I4gOpdT5+XBLlrC5F5SzkbjJYiO+xVivW2D5djjb36lSSOj/WV"
 @"oocHTOe266/atMerGhHxLyfmy16iV1XN3mlk+gWmeu1N93StC1y5O0smZ5PWBaFb+ciHf29VX6DAy433P3P9PKhp79phAAAAAElFTkSuQmCC"; break;
 case 5: return ZLegacyZc83f0d7b42();
 case 6: return ZLegacyZ71a4c9e2d6();
 default: break;
 }
 NSData *data = [[NSData alloc] initWithBase64EncodedString:encoded options:0]; img = data ? [UIImage imageWithData:data] : nil; if (img) cache[@(slot)] = img; return img;
}

UIImage *OngnongCounterIconImage(NSInteger index) {
    if (index == Zshield5e2026) return ZShieldUserIcon(ZLegacyCounterSelected());
    if (ZLegacyCounterSelected()) { UIImage *legacy = ZLegacyCounterIcon(index); if (legacy) return legacy; }
    if (index == Z700020a485) return ZNewCounterArt(0);
    if (index == Z124338f2d8) return ZNewCounterArt(1);
    if (index == Z94881eb8d3) return ZNewCounterArt(2);
    if (index == Z646dcbe562) return ZNewCounterArt(3);
    if (index == Z2f0c1a9d77) return ZNewCounterArt(4);
    if (index == Z87f6d0c11d) return ZTokenUnifiedArt();
    if (index == Z5d92a7e4c1) return ZNewCounterArt(5);
    return nil;
}


@interface Z68534fe442 : UIWindow
@end

@implementation Z68534fe442
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    if (hit == self || hit == self.rootViewController.view) return nil;
    return hit;
}
@end

@interface Zcb66126fa3 : UIButton
@property (nonatomic, strong) UIColor *r8m1v5;
@property (nonatomic, strong) UILabel *q3p7d2;
@property (nonatomic, strong) UILabel *x9c4n6;
@property (nonatomic, assign) BOOL h5m2k8;
@property (nonatomic, strong) UIColor *v1q7p3;
- (instancetype)initWithV5m8p2:(NSString *)title icon:(NSString *)icon color:(UIColor *)color;
@end

@implementation Zcb66126fa3
- (instancetype)initWithV5m8p2:(NSString *)title icon:(NSString *)icon color:(UIColor *)color {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.r8m1v5 = color;
    self.backgroundColor = ZThemeButtonOff();
    ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
    self.clipsToBounds = YES;

    _q3p7d2 = Label(icon, zb1d8336499(28.0, 15.0), UIFontWeightHeavy, color, NSTextAlignmentCenter);
    _q3p7d2.layer.shadowColor = color.CGColor;
    _q3p7d2.layer.shadowOpacity = 0.0;
    _q3p7d2.layer.shadowRadius = 0.0;
    _q3p7d2.layer.shadowOffset = CGSizeZero;
    [self addSubview:_q3p7d2];

    _x9c4n6 = Label(title, zb1d8336499(18.0, 11.5), UIFontWeightHeavy, [UIColor whiteColor], NSTextAlignmentCenter);
    _x9c4n6.numberOfLines = 1;
    _x9c4n6.lineBreakMode = NSLineBreakByClipping;
    _x9c4n6.minimumScaleFactor = 0.42;
    _x9c4n6.layer.shadowColor = [UIColor blackColor].CGColor;
    _x9c4n6.layer.shadowOpacity = 0.0;
    _x9c4n6.layer.shadowRadius = 0.0;
    _x9c4n6.layer.shadowOffset = CGSizeMake(0, 1);
    [self addSubview:_x9c4n6];
    [self addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    return self;
}

- (void)setHidden:(BOOL)hidden {
    [super setHidden:hidden];
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat s = z067adc83c5();
    CGFloat h = self.bounds.size.height;
    CGFloat pad = 10.0 * s;
    BOOL hasIcon = (_q3p7d2.text.length > 0);
    if (hasIcon) {
        CGFloat iconW = 44.0 * s;
        CGFloat textX = pad + iconW + 8.0 * s;
        _q3p7d2.hidden = NO;
        _q3p7d2.frame = CGRectMake(pad, 0, iconW, h);
        _x9c4n6.textAlignment = NSTextAlignmentLeft;
        _x9c4n6.frame = CGRectMake(textX, 0, self.bounds.size.width - textX - 8.0 * s, h);
    } else {
        _q3p7d2.hidden = YES;
        _q3p7d2.frame = CGRectZero;
        _x9c4n6.textAlignment = NSTextAlignmentCenter;
        _x9c4n6.frame = CGRectMake(8.0 * s, 0, self.bounds.size.width - 16.0 * s, h);
    }
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    self.transform = highlighted ? CGAffineTransformMakeScale(0.97, 0.97) : CGAffineTransformIdentity;
    UIColor *activeColor = ZThemeActiveGreen();
    UIColor *normalBackground = self.v1q7p3 ? self.v1q7p3 : (self.h5m2k8 ? activeColor : ZThemeButtonOff());
    UIColor *highlightBackground = self.v1q7p3 ? [self.v1q7p3 colorWithAlphaComponent:0.96] : (self.h5m2k8 ? [activeColor colorWithAlphaComponent:0.86] : [ZThemeBorder() colorWithAlphaComponent:0.18]);
    self.backgroundColor = highlighted ? highlightBackground : normalBackground;
}
@end

@interface Zf721fd429b : UIButton
@property (nonatomic, strong) UIColor *r8m1v5;
- (instancetype)initWithV5m8p2:(NSString *)title color:(UIColor *)color;
@end

@implementation Zf721fd429b
- (instancetype)initWithV5m8p2:(NSString *)title color:(UIColor *)color {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.r8m1v5 = color;
    [self setTitle:title forState:UIControlStateNormal];
    [self setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    self.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(24.0, 15.0) weight:UIFontWeightHeavy];
    self.titleLabel.adjustsFontSizeToFitWidth = YES;
    self.titleLabel.minimumScaleFactor = 0.18;
    self.titleLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    self.titleLabel.lineBreakMode = NSLineBreakByClipping;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.contentEdgeInsets = UIEdgeInsetsMake(0.0, 1.0, 0.0, 1.0);
    self.backgroundColor = ZThemeButtonOff();
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    ApplyNeon(self, ZThemeBorder(), 10.0, 1.2);
    [self addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    return self;
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)layoutSubviews {
    [super layoutSubviews];
    Z611a3d09ce(self, zb1d8336499(22.0, 13.0), 6.0);
}
@end

@interface Z73b2f81c4a : UIControl
@property (nonatomic, strong) UIImageView *c6d9x4;
@property (nonatomic, strong) UILabel *t2m8r5;
@end

@implementation Z73b2f81c4a
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = ZThemeButtonOff();
    ApplyNeon(self, ZThemeBorder(), 10.0, 1.2);
    _c6d9x4 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _c6d9x4.contentMode = UIViewContentModeScaleAspectFit;
    _c6d9x4.userInteractionEnabled = NO;
    [self addSubview:_c6d9x4];
    _t2m8r5 = Label(qsec_s_0029(), 16.0, UIFontWeightBlack, RGB(80, 255, 120), NSTextAlignmentCenter);
    _t2m8r5.backgroundColor = [UIColor clearColor];
    _t2m8r5.layer.cornerRadius = 8.0;
    _t2m8r5.clipsToBounds = YES;
    _t2m8r5.adjustsFontSizeToFitWidth = YES;
    _t2m8r5.minimumScaleFactor = 0.25;
    _t2m8r5.numberOfLines = 1;
    _t2m8r5.lineBreakMode = NSLineBreakByClipping;
    _t2m8r5.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    _t2m8r5.allowsDefaultTighteningForTruncation = YES;
    _t2m8r5.userInteractionEnabled = NO;
    [self addSubview:_t2m8r5];
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    CGFloat countH = MIN(18.0, MAX(15.0, h * 0.34));
    CGFloat iconH = MAX(18.0, h - countH - 7.0);
    _c6d9x4.frame = CGRectMake(5.0, 2.0, MAX(0.0, w - 10.0), iconH);
    _t2m8r5.frame = CGRectMake(2.0, h - countH - 2.0, MAX(0.0, w - 4.0), countH);
    _t2m8r5.layer.cornerRadius = countH * 0.44;
    _t2m8r5.font = [UIFont monospacedDigitSystemFontOfSize:MIN(16.0, countH - 2.0) weight:UIFontWeightBlack];
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    self.transform = highlighted
        ? CGAffineTransformMakeScale(0.97, 0.97)
        : CGAffineTransformIdentity;
}
@end

@interface Z8x4c2v7 : UIView
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UISlider *rSlider;
@property (nonatomic, strong) UISlider *gSlider;
@property (nonatomic, strong) UISlider *bSlider;
@property (nonatomic, strong) UISlider *aSlider;
@property (nonatomic, strong) UIView *preview;
@property (nonatomic, strong) UIButton *resetButton;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, assign) CGPoint x3q8c6;
- (void)f5q1m9;
@end

@implementation Z8x4c2v7
- (UISlider *)u8m2q5:(CGFloat)y label:(NSString *)label value:(CGFloat)value {
    UILabel *l = Label(label, 12.0, UIFontWeightHeavy, ZThemeWhite(), NSTextAlignmentLeft);
    l.frame = CGRectMake(12.0, y, 28.0, 24.0);
    [self addSubview:l];
    UISlider *sl = [[UISlider alloc] initWithFrame:CGRectMake(42.0, y, 154.0, 24.0)];
    sl.minimumValue = 0.0;
    sl.maximumValue = 1.0;
    sl.value = value;
    sl.minimumTrackTintColor = ZThemeBorder();
    sl.maximumTrackTintColor = [UIColor colorWithWhite:1.0 alpha:0.20];
    sl.thumbTintColor = ZThemeWhite();
    [sl addTarget:self action:@selector(c4p9v1:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:sl];
    return sl;
}
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    ZThemeLoad();
    self.backgroundColor = ZThemePanelDarker();
    ApplyNeon(self, ZThemeBorder(), 15.0, 1.2);
    self.clipsToBounds = YES;

    _titleLabel = Label(ZuiMenuColorText(), 15.0, UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentCenter);
    [self addSubview:_titleLabel];

    _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_closeButton setTitle:OX_NS("✕") forState:UIControlStateNormal];
    [_closeButton setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightHeavy];
    _closeButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_closeButton, ZThemeBorder(), 7.0, 1.0);
    [_closeButton addTarget:self action:@selector(h2n8k4) forControlEvents:UIControlEventTouchUpInside];
    [_closeButton addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_closeButton];

    _rSlider = [self u8m2q5:38.0 label:OX_NS("R") value:g_themeR];
    _gSlider = [self u8m2q5:66.0 label:OX_NS("G") value:g_themeG];
    _bSlider = [self u8m2q5:94.0 label:OX_NS("B") value:g_themeB];
    _aSlider = [self u8m2q5:122.0 label:OX_NS("A") value:g_themeA];

    _preview = [[UIView alloc] initWithFrame:CGRectZero];
    _preview.backgroundColor = ZThemePanelColor();
    ApplyNeon(_preview, ZThemeBorder(), 9.0, 1.0);
    [self addSubview:_preview];

    _resetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_resetButton setTitle:OX_NS("Reset") forState:UIControlStateNormal];
    [_resetButton setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _resetButton.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightHeavy];
    _resetButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_resetButton, ZThemeBorder(), 9.0, 1.0);
    [_resetButton addTarget:self action:@selector(r7d3x6) forControlEvents:UIControlEventTouchUpInside];
    [_resetButton addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_resetButton];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    [self addGestureRecognizer:pan];
    return self;
}
- (void)z51bfdd51e4:(UIButton *)sender { Z0418c1e0ae(); }
- (void)layoutSubviews {
    [super layoutSubviews];
    _titleLabel.frame = CGRectMake(12.0, 7.0, self.bounds.size.width - 52.0, 24.0);
    _closeButton.frame = CGRectMake(self.bounds.size.width - 34.0, 7.0, 24.0, 24.0);
    _preview.frame = CGRectMake(12.0, self.bounds.size.height - 40.0, 62.0, 28.0);
    _resetButton.frame = CGRectMake(84.0, self.bounds.size.height - 40.0, self.bounds.size.width - 96.0, 28.0);
}
- (void)c4p9v1:(UISlider *)sender {
    g_themeR = ZClamp01(_rSlider.value);
    g_themeG = ZClamp01(_gSlider.value);
    g_themeB = ZClamp01(_bSlider.value);
    g_themeA = MAX(0.30, ZClamp01(_aSlider.value));
    ZThemeSave();
    [self f5q1m9];
    [[NSNotificationCenter defaultCenter] postNotificationName:ZThemeNotify() object:self];
}
- (void)r7d3x6 {
    ZThemeDefaults();
    _rSlider.value = g_themeR;
    _gSlider.value = g_themeG;
    _bSlider.value = g_themeB;
    _aSlider.value = g_themeA;
    ZThemeSave();
    [self f5q1m9];
    [[NSNotificationCenter defaultCenter] postNotificationName:ZThemeNotify() object:self];
    Z0418c1e0ae();
}
- (void)h2n8k4 {
    self.hidden = YES;
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:ZThemeVisibleKey()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:ZThemeNotify() object:self];
    Z0418c1e0ae();
}
- (void)f5q1m9 {
    self.backgroundColor = ZThemePanelDarker();
    ApplyNeon(self, ZThemeBorder(), 15.0, 1.2);
    _preview.backgroundColor = ZThemePanelColor();
    ApplyNeon(_preview, ZThemeBorder(), 9.0, 1.0);
    _resetButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_resetButton, ZThemeBorder(), 9.0, 1.0);
    _closeButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_closeButton, ZThemeBorder(), 7.0, 1.0);
    _titleLabel.text = ZuiMenuColorText();
    _titleLabel.textColor = ZThemeWhite();
    for (UISlider *sl in @[_rSlider, _gSlider, _bSlider, _aSlider]) {
        sl.minimumTrackTintColor = ZThemeBorder();
        sl.maximumTrackTintColor = [UIColor colorWithWhite:1.0 alpha:0.20];
        sl.thumbTintColor = ZThemeWhite();
    }
}
- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *sv = self.superview;
    if (!sv) return;
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint t = [pan translationInView:sv];
        CGPoint c = CGPointMake(_x3q8c6.x + t.x, _x3q8c6.y + t.y);
        CGFloat hw = self.bounds.size.width * 0.5;
        CGFloat hh = self.bounds.size.height * 0.5;
        c.x = MAX(hw, MIN(sv.bounds.size.width - hw, c.x));
        c.y = MAX(hh + 20.0, MIN(sv.bounds.size.height - hh, c.y));
        self.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.x forKey:ZThemePosXKey()];
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.y forKey:ZThemePosYKey()];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
    }
}
@end


static UIImage *ZNewCounterArt(NSInteger slot) {
    static NSMutableDictionary *cache = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ cache = [NSMutableDictionary dictionary]; });
    NSNumber *key = @(slot);
    UIImage *img = cache[key];
    if (img) return img;
    NSString *encoded = nil;
    switch (slot) {
        case 0: encoded =
            @"iVBORw0KGgoAAAANSUhEUgAAAGEAAABfCAYAAAD4dql+AABTzklEQVR42p39eZTd53nfCX6e9/0td68dBRTWwkKAC8BF4CJSIiVKlmRbtrzbnShx"
            @"JulJOp3pyaQz6ZnJH3N6mZ6eSU88zjnTPTOdpDv2kROfOI5txZZlS6IoSyRFElwEkNgIogoooAq137r7b3nfZ/743SoUQDrL3HPqAHXr3t/93fd5"
            @"32f9Ps9XRITioRT/FUBQLZ6796EIUrxk+5n7XiIyfJto8bLh37ffcvfTwAMBECBRZOSkR9uZ6nzu73vx8A26670CBCIYiFRI1YMTvXsPwwtsfw+5"
            @"79vY4cVl+B1yUdzwM+6uyUcfqoqIoPd/ce5fB/m3vn73ZwTbN60quxZU/5wLDy+qxVdS7r1ZGUpl+/pmeBmV4RX17gLuiFuFwDATGT1lYSJ1cmVg"
            @"OJcr7d1f/P7FBcUa6laYMCJ1taS5Z9EL7eJzdGczqIIp3hWBYIXJ0HBEkNio1j3S7nt9JRFSt3Ozw2v8OYL4dz0+7jW7BbP7EYgUf9wWxPYdbEtw"
            @"e6uoDldzZyfKx0hVES12lmy/XIsfw70LyPAaVogCkZlI9GTJytmS4Wzome04/wce2sXKC6qkQ0FEqqQohfCsnLSik86z5lXaqpoYkboqaXFoJUIg"
            @"NMwaqAtEkXAqEJkxSt1iJgde38xFFp3qFUS3b3n4HfXPOfFy7476dzx27/zt/29rngAxuySzWwDbL/ZwVxbF7h3eaHH6BdRvK6qdg6+7TsLd5R8K"
            @"UQSjOlQpzMSWMyUrZ8dC8xUFOpmeccjawHNORCKBWIVkW4bbAomtnCkFcjZAZlL0ilNdM566CJEY4p2dD5OR5aRAHMKRspHnQmE2VIkzR5I6vSyq"
            @"kWqxMIa7J8FTqJLd6mxnQf89BfBvPy1KwMcem23V4u8eSL2r3He/Rbb18HDht2/W6FBIhdSKEzL8YhYwSASKRSZjw5lyIM9NlkIigTWTP5mhXyUv"
            @"ru2lUE0iGqHbqyRUAvlsNZQvWWFikHPOQ9sb2tsnQIQYD6VAzpYNz1lhoiTSKBshFqEkwp2ei41QF5EY1WLjyN3thOjOifbby7DrBOxojH/HYu+2"
            @"C3dfL0MhfKzev1dzbNtrHd6E2XVuVMEOd7mau6dluE47J2h7lwmCqGKgbkTqgTATGJkpBTI5WrIcqMbEWz3E8Ivad0mqXHHKmoqmAlGxKJIKRKWA"
            @"s5VIZkNjMOJfzLybU0xqROtDW5RYZXKiZL9SDYSSEcoihCI0rCVLlbWBI7TM4sHsWkwPeL3XkRDADNdHdzkz8uda0bsnZ7cg7hWcbAvhrmi3paUo"
            @"6oc7WO7udUF2bsAjWFWMFDcnEDlItzeTCIgvdtIuZRVZZNIaJqxh0iD1wMhMOTCUrHByskpZIOomqKRf3cr97dTpldyzqJCoDG2DEpWsebIRWiJT"
            @"3Gfm9EUAK2ZiaJDTSmAmZ6ohjcAwFlpKxhABe6KIC2sdQisYJ3VEsap1L7T9UM3ePeX37WzRj6jYf1+b8HGnJmBHjdz1aordbIplM374++6PK27C"
            @"bO8OhMjISWOoe0878zrnlFRQhkc9CkVmS8acTZw/bwx1C5NGpG5hMhRmK4EhVmXfoSqzMxXqF9cBWOxn+7s5+xPvydHb25/vvKyXDIyEwngcEklG"
            @"nvtZsy18MYgqe2sBB2oxY6FhTxTQsIapesxW4jl/p0NgDDl+EZHiXovTtq5a2C4/tAdSqMUdTeDZ7UH9/2scdPskFOphlx8AyPAo+ruu5PB/ftfv"
            @"usuJM2i9ZOQsBlLPTOaZU5XUiNRFiAJlZiyUv50HZrHv9JXAykwA+0WIIsNk2QqjoaXWCDnx0Ch2vQuhMGEi3l9YIcLg1e83xqCiDJzfX7JCyRpO"
            @"HpskWNjAA8YYbGDo9VJK1vLAeJnpSshEHLAnDpmuh4yebPDSt5YwgPOQOq4YoR4aOZJ5nTcidUUThTSAukUmUphXvddplX+rQ//vdT62T4LfFaSx"
            @"a7l1aFB1x6Dufs12sGXvutUYqI9Xgv8iydz5gdNzzrGWqc4LEoVWZo2hfqgcvtgc5C96gcAWpys2UBJhT6NEuZMQjcH+Ew1aH3ZorfXY14hpZ44k"
            @"hygKqdbKLKw0KYWWSsnS3OgwVbGMWktPLQNv6KhjXy3m0X1VpkohE5WAWiiMPjVOK1FcO8MEQid3OPVrAcw4Yc0Y6kWIIZFR6hXhxUyZc8p6TmH0"
            @"hxHdjgb5D112/ag64r5L3XUxRXdLWthtGYqos1BhimCM1EWIA2FyZrz64upW90WnJLmXxSTX8xgwQr1mDZ84Mk5/kLDUz1AprlOPDaWypRxaTNlQ"
            @"O1lnf8exlGQY49hMDZ08op87sl6fkXJILEJsLaE6jh0c44mv/ip/9tv/kg8u3aBSj3l8ps4jh0YYPxJSPhBjRkrYIw3W/9kNyqEhV6Xv/Vxk5GSu"
            @"LKpqGggzgkSiGtes/LRA3PHa3vZWDILuZAP0rvPxHySIewPd4K5zuUtO93gFcs+bZfsEoEMvqXhP7mURKwxydx7cmdP7R1hpdmNEZgeZn20NHIEI"
            @"kmc8cmycI7NT/NmfnGdDDKpQDYQyOYFNEXrExwPGFkNO5DF7zCgrzS1uLW7QjEoMvFJ1HgOEgWEkUk4+doIHPrePPP8Mm7/+zylHMY8eH2H/gxHB"
            @"k8cJT/wYPuwgd17BdzPEGjpeCazMlIXnEs95FAKYMUq9bswvlgNzppm5r6mYRI1PRMFtOyIUDofqR9M4u23v/Sfl40y93R34bRvgHfdLZTtI3jHc"
            @"hQDuxgCy4/doOxSZrUT2+VD85PF9dZ56aIpynlKPQ6qhpWKEyUrI3tDz9C+dZo/xVDoDRsOcfRNVjjx2kr3PPU71sUeJj8yinQ3iyUnO/O2/w4kX"
            @"f4aKTwhatwjylDAIiQOhFlv2V4UHPvsJQjvH6NQoSSdkT3KHh5+bInjyBYJjP0EYLtNcvg6bGemlO8zdTriy1cOhQa46CWBEqlYZPRAGf/ehkfL0"
            @"WuboKi/1VV/NlYXYyJGpSvSf93L33bueEvfaTbnrMZldW/hjEjy78li7zO79Rlh2CcBw7ytlV1BnRBDEGqQeGx6uRvZ4lKd8+sXjfPEnjhKsNil5"
            @"y/6RiIOjJY5NlTh4Mmbv83vYa+HIC5/j1C/9AkeefJCw2sB3atjoKOFDz2DHcvKV79E46Dj+pZ9h9uyL1OljN28TWUs1DpgZDTj84lk0WYX+EpWD"
            @"D1NJ2+z5mV8hOPIIVi5jzS1ai7dJlwYEd9qcn2uzlTqsCGJMoN7vtyIHG95/8qtPztJ1nour7W8OhHM5spA6XfzEwfHN8Ur0wnyz/18Za3YWwogM"
            @"f7hnnfQjay4fcVFFBGuM7KiZbd/+fjMtu+yDGUZ0sv2hZjvUl8p28FUNzTOj5ZBqp8uTP/sED754kNraKofHqjz4yBiHHi4TH7CEpz/P6Gd+BVuv"
            @"s/Wt77H6v/wx6988R/d7r7Px9tvYE4bk6hskH6zQn/uAZO0ctYMxR77480zsP4y/eZmywsy+OnufP42uz0N3i8qUYfyzP0O4p4xklxHJIdmgu7rJ"
            @"oGkYLLb48EYXaw1lK4xWSiRJhuDjT+8foyKGP72+Qkf5YV/1FQ9tIyZqD9ILN5rdv4ZIXwSsgcAYQiN1ayQOjNQF+qr37dhdDv592mtoE/T+cO3u"
            @"Dtf7cscy/KOVImgTv+MhRAbqIhrlymKSedLc0+vk3H75Amf+/t/n9OgR+hdeJpqJYPwIZvTTBOUSay//Ljf/hx9QXXbIwGMDYW2zT/XHHqVavUVS"
            @"FzQaIWtlJFfa5Le+gW+8RnnfQ5x48RlW/uQ7TB7dh4kNrtkirpYIshWi6B1MPgVi0GSTvLOKcZ5BIvRbGVNVZaJhIaywstrD5GUGiePAaJWX5lbo"
            @"wVqiel4gHkbGcTvLf0dFEiNghQljqRulPowvYudZU0NqkLbfHW7vNsR697ft5wIR3SWtu0Zk+xqyK4UscveQGdXIikyKEnmRdmBlJjTMWmEy97rW"
            @"H+STmQPxCenqW8RHjxPsW8G7GWz8ZfLNl9n6wQ+Y+/XLTFInGs/xg4xks0v4mZM88NVpbOcW5cOjuM0+NgA/EtJe9nz4jTnyiTUe/Mmn2TsTUzu2"
            @"D/Iu9BM0ClEJwTnEJeASXHcR30wpqdBbaRJVQk69+CiNkwdpHJli492bvPE/f5tSo8Eb19dZzx0ZMicQW2VChSQXXQxFjnilLaJxaOVIYNgvaBRa"
            @"O5t7Xeypf0m0yIntpHiEnTrFn2eu7f3q557kHLtT0PepIZFKKMyOBPKrDWu/mnu/GBiZDoUjI3H4qYlSyEjJMF2JmNrXJj6cYoInsfZp8uZ38Wtz"
            @"XP1/XWWsto/GWIiqEhq4FYYc/+9+ksZEjnMOE3psyWLLhl434Pwf3ubNH64zvuE5+pnHqH3mUzBSovfeuwRGCBsxMhJgxhpoluJ7q2i7i1vNkNSR"
            @"+BEmnnqMyTPT2O5tct8iiErs7ba4vZXzg2trrOSeTP1iFNiTpdA+7tEmghNDFBqOliN5uhrKj1UCXhwth3/TiNQT599xyppXOl6L1Ifebw92cs18"
            @"nGHmI4b5Xjfr3odBMCKxMbYeqZ48XSv9zZlS8Isbg3TOGhmbqsUP762XiHFUCRj1KY2HTyLVZ8nWzhGPHWDuf3kHGx9m3/OnybOMcilmZWmFyn/8"
            @"VQ4//zzeD7DlMcSACQb4uMG7X7vBa9+6xUO1Kk80avTfuIRJcrRs+eCbV7h0sYWUy0yeeoBoagQGy/hWh3QpwbVzXC+n0jC4zdt033+fwWYfW9uL"
            @"f/M9NtYz/vStO9xKHYkHp559E/VTtUq8f6s/OB8EZjqynCyXzDONUvDVeijPHJ6sHgqM0Bpk13JlIVPmvKepSltVdtz57eIV8tEVFQErsisrJLuE"
            @"MPSOhI/WBEQUW6QjYhHiLPfPf2JvozJVLz/ZTAbHy5agbjwHRirM1AwTh2cYf+qX6cz9CDv+KGuvzrH69m0e+Dt/h/TODaJqjSSMWC5FPPK3/o/g"
            @"9yF2tDiGQUA0coBrv/8h3/9n73BqZJRP7B8lzx02E/L3buEvLDAyXqObhLz3+go3X7tF1MqISxZNUtxqHz9w+FxJt3okawlJ2zHyqadIz1+nfX2d"
            @"C9c7fNhM6GmRBSjHtjFIM9pJQhDIdCmQxxtl84WxcvDwaETl6QcnqUUBN9a6pNBMPRedZ01F+h5pi8Hds65y77+7V9YWrpXuuFc7LtZQOPf+O5Qc"
            @"REUCTivGUHEi680kfa4WWY6PlILpUsB0o8SxiRIHDlY4/jf/HunmNQZbUKpP8Pav/QYP/MLPQ97D5xnWGC798DUe+Ft/h9r0Q6jPwU4ijGLjCZpX"
            @"N/jGf/NbRJ2Azzy4FwmFIIow1mDiEEmAxT6TVtg7VWd5ucfb373O/JvLuCbEpZAoMmjiSDpKb7nD2LMPElpl8dvvc/1OxtJWwlaaUw2UiUpI4j25"
            @"KkEg1ErB2EQ9auyph8yMBPzYi8eoWMPbV1bpIXQzfSdzXHOwrErPCx2QdLuA9ee5ptuisIEVAiPY4ieyIhVTlDvd0AuI7v55+0fqgbC/EpgXAmEa"
            @"cKCTWZ5On5mp89PPH2AitszUHQ/8jf+EykSFxZdfZfrx01z8J/+KkWCM8fEa+foqpdE618+9Q3TiEEe/+CRZegsTTIIGiKnic8N3/2//NVd+MM9X"
            @"/vb/hvrxA7hWi1A8Ng6HarNIbbp2SrA54EAlYrLRYHkt5Ufvr3Pjgy3cAGrVmN5ql9L+MSaeP0Xyo0s05wesb2UMvBJ5z6c/dYK4FnNjsUkQW8Yq"
            @"ATMjAYcmAh4+WuPLf+EpDMJ3XvqAloNu4ujn+k7uddEpy6qkiqaooNtp/d1VyI9EZRSVNRGDEalb0QmLTobGzBqh7lXa3rtW8TVN6lXb3tMWIRKv"
            @"UaMa/0XxGvcHySuBlZlyZFnd6LPZSnjsiRrB4aeoHT3Ewtd+g7FjR1l9/TyDV65y+NHjDC5eIayU2bo+x+adBZ79u1/AZ+exJgBt4/MHCeJJrn/z"
            @"N3j9917h6R//BQ5+4jiDQYfakUMk779PfukKNk0x1RI+dwRBhmY5eTtjUhM+XSuxXC5xfqvPt7+5xNzFJk89NcrBH3sSSZrYLGNsJMKlSs0qlelR"
            @"GPRYXd5kfDTGC+ydiHjxJx9kal/MnlMzbFzf4tu/dZlMDEmWknnfEjQS0VggRhTxRKokKBiv+GKX7qouyj1pDrsriZ0aoWKM1APDdByYh/eNVH49"
            @"xp8dK5n/XVXzzwei0xIYK6pBZOW4z10TcjcS2V+dKgeV0dCypx5R7mdMHx7j4F/8q9z+vT/AbQ2oT44z97XX2Jc6bLuF9joE6vnwwmWO/adPM3pw"
            @"DZckGFPB+yY2atG5dZE/+vv/d0I/yU/+jV/GJV0kGWDimPjgAYLDB4o7b3cw3kNo7x5/BdKcqvccqcZMTY2x1HKMHh7nxC+dwrXn0bYjSpRaAAee"
            @"3M/EvjKXL63RyhxRaBirRhydiXnyx49z4qf+PrXJEhf/1de5dCNhuZXQyzypV7zSVKWnSs8rbVX6IA5wKjhFCjUv3Jco3Vbvw78M7UCyLQgjUsm9"
            @"a5bg8c8+Ph3/r/7yJxu1ZHCms7r15QzjEHGBMB0ama2gh545eYCGUcZiy+w4nPjFX0E7A27+6Z8xcegQiy9fxV9YomYMzkNohNUPb+E/fZDjPzOO"
            @"77YQk6C+gxiD4nn5v/unvP+t6/z0X/sFxg6Mg/OE5VLhMKgSjIwQHZ9FDu7DJQn5ehOPQaKgcK/N0I7lOePOcWSiQWnvFNXjDxHsqaOyDD4nPFil"
            @"+unHWHlribWVFiYwVGLLnomYRz4xwoHnH0biNvnaMotXljh/cZXNpLAZXglUpHJ30SVFcALWK53A2kmUttuuMO7ONYkpECf3hdXOiMQiRAatFiVZ"
            @"DaI8O3T6gWl+/OeeYnYsYnF+7Uw780EUyMlyaJ6ohgbtD5gsBxyqGU584gSHvvgF5v717zLox9hmn8VXrtMwgnoPuSNrDliZKHHy7z4EnTuAYIxB"
            @"XY+gYrn0exf59v/wMo/u2cdDB8cZbGyRrqyS3lkmXVgkXVgkWbxDurKKhCHh8SPY/fvwaQa9AcYarDE7np46hXYfvb1G7/xNbHyM+KEnsHsz7GRC"
            @"93vX6d3s4IxgjWG0EXDkZJXjXzxCXLUsvvwqr//BW1z+sM3CWp9+puReyVXJPTkI6n0/DMxBRXqq2hchsiJjTnVNwe2UkO/L19ndkfAwM9oupKq5"
            @"DOsNncTNXHp3vjF34Tpj43Vs5tlqDw6NBmay4jyNUkg5EPZUAo5PWB786i+Q3Vnk0ssXmD58iNuvf4Cs9SgPd2hgDGu9lKn/9QOM7+kVtWwLPk+x"
            @"cYnWYsi/+a+/gV9zfO7AJO7WHfI7K+hGE9nYwjSb+LVNdG0DXV4jv34Td/0W4iE6cgAZbeD7CTpIhuiQbcSCIE7Il1qkb11AtoT4kc9jJydh/SZ+"
            @"swcSMDIWMnOyxv4XZig1Stz5/jyvfmeFD2/2ubXaY5ArziuZKypzTolDw+STZw4+nGf5mWY7+TMPbVXpO2XNi7RVcTsYxt3QxOIkDP3+7cxfUTFq"
            @"ozgRiYyhoUbS1IbTy1tp5fylOyx3EhpBwCePTfD0E3sZrHeJw4DJWHjgzCzHvvQCV/7gT7HhGNrpcPvcDSo2QFACaxi0M9Jn9nD08yO4hQ3IcyQ0"
            @"iOTYuMar/+wKb3zjIs9NTXGgZHFSqK9ADE4M/W5GOQ4L/NKwGi55jq5t4m4vo7lDG1W0UsKnGeLc0D8fRvzW4lPD4NJ18vcvYsqHiZ54BltuUzFN"
            @"xh6oM/r4GEE1ov3eOpfOrXNnfUCnn9NJHEnuCkMrxckuB4a4ZAmjgMXVdtJP/ateaSr0FE2HaqpvdzKuRSxSuP26HayxU6AxOwGFJKAiIoFBKup9"
            @"zwFqzaQKGPVMVCI+/fwhJkdKtJa77K3C6Z/7AoaEm+fmGBkf4eabH6IbA7BF3RqnLAVw5FdniTubiAriFN9OCGPL8nzOv/q115lIA16YahRqxBeh"
            @"pxkk9A6M0X/xE6SvXaIaGfIkQXIH3g0Rg4IkGUFzC4tBxkcgDApBe4+xUmCibLEHs6UOyds/Qtd6lJ94lvj0AaJDFjN+jPRGk+b782xuOPqp0Ety"
            @"cleoIQVcmnP6xCSPPX6QS1dXuLXaaWUZH3qkOUQPOhFia8xoIDJdwHuYMEYCIxoFhoo1Eli5J0oeYm8KIThBYoWe97QFrBUdsyITBo2NCL1uyuKV"
            @"1cLFM3DkyAQP/tyXWX7nPOpD2ksbLLx1ayfQwwgrrYT6Fw9wZFbI1vqIMTvGyvXgW795nUvvrPGl6QmmSxbnCzVpjWHQTek/PcGp//QEl17ZoHJt"
            @"ERsFaOZQ54sTnadkzU269XHSOCJudQjKJaRWLXBjWYbdzvsXOQM0MWRXbpK89wHRnuN0/R6S+Rb1sz+Prcyg6zdw7SZOQ5x6KpWQRjng0QcnGauH"
            @"XLq+wermgNQR546bQ9jlodByJLRmNrbycGw5E1jZb9HJ0DJbDu1zkbXHRYhtIPemvs0QHWdEKkWKVmJBA0FiI1SskbHIymQ4RDV4Uxi9Ses4+fyT"
            @"TDx4ipWLlyGBS69eY321jRrBAXnq6Owt8+gX9pAtNYsiaVqkE8LYMnelzx//7g2ORGXONsp4VYwpEB6BwEo/Jf7pQ+w9tEE+dZjb37zGmDhyIBRw"
            @"W1s0NSJ//tPs+9//MssL85hLC8SRRb1iyhXUBhiXY3V3Dl8RseSrfdK3L5Kur7Fy6Sq1w5bw6BEmn/hpykYIWvNYY2iUQ576xDRhLeIHr9/m5nKX"
            @"zIPzSmDZXwnlVDU2D5dj+0Q1kmdKAc8Eogfrsf3KZCP+cqMUfgVkNMn8O6nTKwFFQYZ7ynUF5LwuEBvVujUyKUKsntQ5XU8hiazGMtRxkTVUI8/U"
            @"Qw/SW1/F58LKh8vcvLEBAi5zpAEM+hmPfOoY2Z0t0kFOXAZXskSpx0nAK99eptfJeWzvCOodzoOqRQKLTzM6lZCZ4xWyzRaHTys3njlB7wfnKTVi"
            @"Vjc98txT7P0rn2biIcFGF8l6K2RZgV7TNIN+irUWbdSh28P2E0SLDaIoGgrag62XbrB6tMrk+fdJvv2HTH7hBQ793F9i9KFnqf3uP6DVzbl6eYML"
            @"c1u0Bx5jDKVAiQMhsEI5skRWUK/kWU6lGjM2Wt6fJsLNlT5zK725Vjf/rYHTc5mX+UC2iwxSGOih4agboR4YZgrYujkZGp2NjJyMrZypRTYOKHCb"
            @"oUDFwOTUCCOzR1h77x02P7jNwtUVOoOMOLSIKIPOgD2n9zJaFZbnW4xNlEFzXOoIx0tcfr/LuxfWebhaZjI0pM4TWgHvsbnS72e4hyaoN3KygVKp"
            @"rnP4Fw/w7tffYHpqL/v+i5/i8OcahOYmeaeFaUzivUezHFKH5r5QP94hGLRahTDAtPtIBt4rmjuMgc5WhlRCwrolnY/Z+sNXyec/YPzzf52xBx/n"
            @"g9//E26sKIOsqLs0SpZGOWR6NGK0YiiXhCiCaLRBY+8o0kt449wy37+6xu3N9JV2yu8kquczZc55bQdDSCEiup1WnbAwadC6hckIOWlcXo+sPVkJ"
            @"zJONQJgZq5G0u1QCoRZa6uIZm57CxpbOrTukzZT11Q5YQ6Ie7w0aBZx4fIr1q8s478EmNKohpcjQaiuvvHIHk8KZiTKp89jiNKLqMWJoJTm1UxWC"
            @"vEs+yOlttJk55Lj8n7/IsS8+wswDKfnWVXKJERsBSppmpP0E3x8UrqGxQw9JIROQEN8waKcPWYYYIRDYdJ6JIw2icUj3RkhX6Ly+hIn/OTI6w6Bb"
            @"uLxeoRwYRmsBx/aVePHnjjB1YAwjNezoKGmzyfuv3OAb31/gjQ+2WOu7VqJyPvd+MfPMOa/rzkNgRAitmcjVrReRs8ZiJAoMMwEyU7fyi7P7Jk7d"
            @"Xt1iLDQ8tHeU1kaLpx/ey0hVGGwmHAgd0ydmSJIOLsvobiV0OykiQi7Q7maceuYAkvbodBKCUsBWOyfNlOmJMhcvtnhvvs0nqxVCURKvxEZIvRCo"
            @"IOrZCAyHj5dw7X6xa72DQcKX/tIBkDmyNQNhCcHhXYpJoDfoEScZ+SAjV8UEISYwiDFDYK8W5c96FQYpwWBA7pV+bNj/5AxRo0tlf4W8nYMtk6WQ"
            @"pik4jwVqYeHuHhwLeepT0xz74l/AlB5FWKb19r/m9d8+x3feXOPy6oBO7hlkei7J9XzquZw55p0rtFAgBoLAzmiuqUHq1uhEIIUAAsOMMVL3eU4p"
            @"KNB43V5CLbbsq8c89ugotgLhoEP9kQOYckA9VDqbPfzQHdTcYashB4/UWbh2hzC05G6IdEocS+spr15Yp+SEmVJAO3eEIniEXIoUbpoonbGA6rgl"
            @"ayVIaDFe0UBINzawpQomiBGXIMbguk38AHq9HnVV8A5yD85jNMSIoMYgtoCRSwa+XELKIa2ldUZOTTD9zH7oziFpmaycUaoHrK92aPcPM7ZnnI1b"
            @"6/jIMjkR88mfOM6pz51FJEZ4j+br3+DNf3WBN672WGjnbHRzmj33Uqunv9XP9JXUc+VuyVMIFBhk2YUAmTBG64EwExk5FQpHYitnjEh9pdmhNkQ/"
            @"d3sDavWI+eurVPo9Tj06QeVERHBgmrBkoNfFNwcE1uBEyRLPicem6G22WN9KKFVCotAQh0KpXuLSfI/bKz3OlEtF94f3qAhOhcgUsL1kkGMPN4hD"
            @"R9bJCcoFOle8AadonpIrWPX4bgff72JqJdqrXUaaXZqBwdsIGwVY74jikKo1RVBnpEDYpooZqbKULrLnhUeIx0ZJfIydDmGrS2Qtb790g2D5Og99"
            @"5Sdp/vZvUspDjp8cpVYvc/F3v0/W/yNMHHLzWoe3P2hzfa3PYjOlOdDznYSvJ57zObKo+GHBv4DKB4FqPUBmrGEiMOyPrZwO0JnQMFs2PFcLJa5G"
            @"IbXQ0IgDJssBk+WQPbUICS2rCz0CB9GjCWa0TW+jj/QyyqFlq5dQGikxc6DGrauLmLBoLMtzT+4sqOfyzTajYpkMQ/qu6PjxYrCiOFUCI2x4z56T"
            @"NeinuFSxxuO1iH5dmqGimBCydhvfH2CMkHQyag8do/LkXqKj48QjMUHFU2pA2lWu/Pff49jAIzGILyLYfqtHJ8554vPPo/YQEmeIuY2JAnQg3Ljc"
            @"Z8/Vt5j4pU9x5sUn2Jq/Rtp1vPY7F7i9OmCr5+lnni7Kej9juZ2x0c1f6ST8wSDXNx2sMUSMGzNEM3ohsMhEaDgSGT1VtvJcNZQvTlbjxlTZMFIK"
            @"MN5TssJIbBgrB+wZiTh4qMJoNcT0IQwCwrJDxKFRRrLco2oNFaNYpxw8NUl7vUM/ccTlABRyr5SM5YPFHqvNhIcqMSpK3xdgEG8KPRmKYtKczcgw"
            @"u3ekqBfgcKnDWguJRwc5KuA7KX6QFkDdYeL+i391GhsajN7B5ykiGW5Q5l//gwuYK1s8cHiaJPNYY4hMwNydFUaePsr4yafIs1Vs9Qk0OYDIh6zM"
            @"LZHMtSkb6F++wOyPneHS7Wu8f6nNjZUem72cZprTzRz93NPLoJX48/2MV3LP4m7skIhGCqkUJonAGFO3VietyIQVJgIjjRDPVLXEw4cbjI9GTO6p"
            @"sGdfiZHJEqW6pXywRlD2pAtbZDdTfLuDCQ2DzTLl5TZ7RytstftMjFSYma5w84MlMIY081gjhFbIM+GDxTYxUDGGXu6IjKBq8FpgTUAIBVppxu//"
            @"T+9z9oW9PP7UKI2KI88dHo+kDp84fDctUhJW0MBgrEebi+RD/KAJBXE1vvZ/vcCt7y/yl07uJ8tyZNjd4tSwmLZ5+me+CEGA+DHEhGg8ho1P8eFr"
            @"v0atmzFar9OZWyDaOsAHVxMWlnqs9RJ6Tujm0Bo4Ug+9TG9nTucEiazRSaesGU8dlCKhp+vboOsg835ekFisxFaY7HsmVxN/Jl/tst4ZsH+sxOGN"
            @"ChJOMnKwQfXsQYJDxzGEhI9s4u4sMHjnOkqH7vUW9UmL9qDagulDDcoupWLAqKHvPYPMEVciFtb6bHQyjpciPEqi261ZhUvr8DhT4HNqwHtzTW4u"
            @"trl8boSnPreXBx6rU7aetJ2iiccqqBE0FExJIHVgCpCJCcH3Qn77197jne/e4q89sJ8SinMOUUMYBtxY2SA6s5+Dz83is0uImQbZjwkmyXuLXH/5"
            @"KhNBhDXQv9HEtxN8ENNLNumnSivN6eYep0KW5qiSWpFJNZp6aBsvDWNo48HrXYi9UqRkUud10XldzlSvpV6vZE5vJk5HE6eTg8TR6+a073Tx81vU"
            @"N9qUR3v4wSZuq4/v9lGXYcfLxNMj+JUl9NqAzSxn8hN7CVod1ENsDaEIgTE4b3n/dheXeWbicKfHYVgkwVP0dSngUEpWmIoCOmnOzTtdbl5s0lrK"
            @"KU1UqZcF38/IcwWvRVA2bJ5Q5yH1+H7A7/6ja7zxvUV+5fA0ewMh16IvQ40hUOHt9RUe+dtfYM8DKXn3JiY0qA6wYZW573+X9/7JN3hkYhxyh49g"
            @"9KljXP/wNjdvrdPxwsB5MgX1nkP7GwTWjnX6WdMrbedZ9tAsKm44VfoqJkHUoYoNzbDoIZqoSg/FqdfUeZad04pzfr9zHhGDV0OYQa01IFhvoour"
            @"ZPNN0jsp2dIa9sAppJTB7XUYaTB9ZoxgpUkUBcRGKA3zLjfWUz5c7bInCojNsNtTthv2tktPRfRupcgdVaxwsBRSN4bNgWN+oc3tC5vkHRjZV6VW"
            @"FvLUoSp4r+SpJ+861Ad8+zcXeO2l23zl4BRHQkvmfQHTVyW0hlvrLQaP7uGZ/+zTuGwN0Qx1myAeE8b84Nf/ObXrWxzfO1Y4FTGMPH2chbklFhbW"
            @"GGBJvEdMkRScnKjQ6ee0+9myV5q51wXnWfHKpiq9QiCaqi9qDFbugo0c4KyR0ZKVx8uh+dR4yb7w8GSVY1N1VjsJrSRjo5lya6HHnRt9Nu9kDNoO"
            @"USH0GZoklB9/BteZI54dY3zME3VTIjEECCGQeuHc9S36Sc7eKCj6z4YnwIohFDNsw7oXIKXDDO94FLA/DkHh+taAax+2aN9OqDQqjO8rY3DkmaJO"
            @"CaOIc99c4+U/XuDz02PMRgGJz7FFLF5UtZzwXtLhzN/9LI3xTdAcE5fRbEAQ5qxdW+PV//4bnD12mFiE3HvS0DPyyQdYmrvNrVvrdFXIFTIP3sDS"
            @"ao92P0sylfk04/3cs5CrLqjS99BUSD10dtSRlV2dlogVI7EK/aLEKccDQ8MGljudAYlX6rUS6pUkURaX+szd6LCx1CfvCKX2OtH4JNHDJxHTQVY2"
            @"iOoBoULgoVQJudPMuXCjxb44ZCwwQ4RaUWtwu9B/26rIqcftdJYWKiuQovtyJo5oZ57LSx1uXt4i2XKMzTSo1AxhFPDmtzf45u/f4OnROifKMZn3"
            @"RafNUNVF1nBjo0v69D4+8UvHSG5fwve6RYtrFBKUG7z8699lcK3PE196HNfp4AYZeVUZf/5x5n90kRuLTdqpZ+CUgVPSXMlUSJxeTHO9knmu5Z4l"
            @"r2wOCz19hb4voDHFRgi2oe3GUKSvtYIa59SvJE7fXe9nVxY2e2uJ6uzAadAcZLRTRzdztBJHM3UMUk8ycJBbSqs3KJ04ho0gv3oTE4eE4yHlyEAU"
            @"cP69LTZbGY/UK8TDapnZBY7KKYybGT5f9BPrTl+x1yHAVpWyEQ6WQyrGcLOdcPXDFktX2zQmxrj6Xo9/9VtXebRe5VQlwvm7uHO/3ReA4Z2kw+N/"
            @"4zHquoHmKaLg2i3E5HTudPmj/+oVPvGpxzhw9ji5KslGC3ugyshzT3DlpR+wsDagnTo6maOfKYPcM8h4M8n1nczph7lnwakue2iCFECAApXa39XH"
            @"vAN3jBRNvEob8UM8ldZzI3WxJup5+W6e68nE57Nbg5w7RqiHlnpkcM5jBaLIUgtzRlZaVJ+I0NUYd0OQ1BMeKtG7PGCrmXC6XuZUNWY5yeg4Rzv3"
            @"dJyj5zz50DD3XY63ASUxIEVBXQunFOcLt9OpJ1Q4WAqZikKu91PmbnZY/Z8v0ellnKzGHK9EdDNPvI1cGwo7tsL1zR6NZ/dwYI/S+2CZYDRGG4Ja"
            @"CJOU7//WPNoLOfX0SZwq5QcOcfvaAo29ddLuJr1WF49BjcEYi8EVaXPV1Dldd17WvGpbVZJiPohP8FD09pkZFUm8ajvYDiBUSUUkUopmbaToiFdI"
            @"Ms+8ep96Q9sbaWsgJ40QD1QxWZHljFNPtZuz0RO6i3eof+YrlJ+BpPEe2eUUl8LWekKE8GC9zL4oIDaGZpazYXJsVvjMiSq5FmNzEu/IECrWEg+9"
            @"J1WKQpL3ODFkQKZFQu2BSsS+2DLXTzlYCjleiellOVaEHAi0OHmhEdqpYz7KefEL+xlcX8En4DYy8k5OMB5yp5Px/X85z9OPnaQ6WaO/toEGIZ1u"
            @"k0OPPEZncZlOJyHJlP4gRcQQ28K4Jq7o3RYhtiKTgWWmHMhze+rBV+PQstl1rTtb6X+cei47WN9RRzv9H0IgSFCoJqkbqBqkboxUrMiYFSZLVvbH"
            @"RrDFlBYCEaJhsi22AfHmOsHWKqVjn6R04iDh1CbOOxZ+2EJaOQ+NV4hUiawhNkI4dA6MEQZO2cocG5ljY+Bo9TPSzBGFAWEwLJRoYcyzoZrKtVBb"
            @"TpVIhL1RSC2wZOp35lHsTphZY7jW7LHni3uZPVhmsFRgjfDgU09YivneHy6x8k6Tz3/qJIF4QgNrS+t4s8Xsr/wEt3/wBh9eXSIhoDFSo9nqE0WW"
            @"Y0f2sLTeKSfOv1O0ZptDomrPzI7+Z3/p507z8PEJkl4e317rzqmYFNQF29G07OrVGa5n3QgNY6QuhliEKLRyJDacGQkMYzvIBcNIYDlaKTEWBYxF"
            @"Fmtj5MZN+n/0NfInPkn10R8nL12iFM/zwDMNRs/USX7YQeczxFqMQCkwNDd6bImi9YCJkmViOiaolGg1E1aurqJtw2QtomQNmS8Cu8QroXhCU2yE"
            @"YFf/mEXIRQkFjBZjIMQKG52E5rTlmUcnuPnmHeq1gKoIJhLCyLK2nPHu9+5w9tAEpa0t+tccHN/L2uIdDn76FF5DNq7Pk/oiB1SOAowIW4Oc5atL"
            @"ZJ55EYm917Z32lY0vbzQ+uY/+o23vpTlfq6T6h9kauac92se2oGIYIfjBFQlteiEeB8LEttAJtT7REQmosCcqoby5OxYibNHRzgxO0b/Tpe1xS4g"
            @"zJ7aT+v6MuU4QEXpdi2ymKODl/Hrtwge+hQHfv45Rk8+hB0Fc/w72FdXMW+lBJtCezNh+hOj7A8NV25usf9IladeGOPwTzyDTP8lrr3xBr/3a7/O"
            @"299dZDwKGIsCAoSc4kSEKqTFMSYUU4CcKWKNTIpNFmqRIr/U6fHsz52gc7NFZzMhTT2DgaNStdQnAn7wvSWCpuP48QZpLyXwbVbnwec9Jj7xIJsX"
            @"r3Dn5jpbA89yK2F1qU1fYeA8vYzLmfdzBqk7kbXM+XnFJGnfX2n2/P8bKSJmrzr8kbaNrImMSEUKzVAPhJnxavx3A2E6y/yHjxwc+Y1yGLwwGOTL"
            @"D0zVDz3/6DSffuEQs2emSVd73FnsstzLubm4yVYvY6OVkPVygtxTiizliSq23iForDH62FHCSSFsPEg48yjB/h5BZRO3mNI/3ODxvzrLe9++SUeU"
            @"46dqzJyuUz3944T1rzA12+aZp5eJE+XN9zbpJjmBlZ2JK0qBrsqHbmyRWSrc3GxoZ4wR7nQzopN1Tj88xtKlFYwNcE4ZpI48VzY6wnf+5DYPV8uM"
            @"hwYbBAT1EoubbaZOT7D3M88y/2++xZUrSyx2HBuDnFbu6TnoO70dBOH+Wjl6WCFSpV8phy9mzs87r2s7AvCFEJyy5pSVoAAnGUSJjClqy5Vy+Nle"
            @"T7+ruGSjk5Bk/nLm/NyNje5zf/hqnzfeukVJlIEzJMO5RhUxHK5FjJRD9k1X2XOoSmkiwFvQNMDdbNFfewuzp0SwZ56g9klKJ/8iduKHJPpNzjx7"
            @"msVzl0lMwMnTYxx7apKppx7Ell/ADe7gOn9Estbk7IkS5qcP8i/+8BYrSUY9KHRlbAyhKcK8fBg8pVKUSYUiJZ6nyrL1vHhmD7cvrpJkSq45QWCw"
            @"AZSrMT94Y5VKAnvHQtqbPVzu6Y1EpD5hz7Mn6S2vsXTxKm1nSVxKqoJDcOrxSjvPssV+nrcHuT+XOq6URRLndM2zPRaOxIu2HawpkopqZIPCKrtd"
            @"zQtxq5/8Vpr7i8ZKo9XPvjZw+roINnV+oZd5NhM/3UyVjnNkxVwaJkLL0w9MM1WPyAOh28noryTYrYxQCl/fVAPCsRhb9mA2kKBFUP8Euuc0Cz84"
            @"x7v/+jJJJvjU46Mapf2foXHgc1j7PfKNH9A832TrVpdBO6U7UG5upAWQSwQ3tGnbsbBTyLfzUUMI5M1OyqEz41TUc+NGE6zBe8i8EgaGtQ6ce2OF"
            @"x0dqVG0Rq4iBXiWkfrTEoS9/hrXX3uLDc1dZ7OY0+zndLGfgi5OmhfAXklzPp46Ludfb/cR9P/M6P3RXm05Zd8q6Qk+VvoILnFe8aGpF1r3QxoEY"
            @"G28Ps7PWTBqRejGBS9s5LKaOOl5nQw/eejzKhsIrl5ZAlZo1HB4pc3p/lfJshXC6hEyH2KkIagGYCD/IIL+GLRva313g+td+yAdryq1WgjPK6AdN"
            @"3vnWP+Dwo3/MIz93nAP7wDcHKIbrCz2czxkZi9la7VEduoaZFsWewBTC8N4Psa9Cs58zqFv2TlS5dn0ZsULeSonjgDgS4nLMGz9aZwxDbKDnigSf"
            @"lEr4yDPz5DHUW7JL71Eul6lEfaIgww7BAbbA8kZDecfGSF20qNejildtK5Ki4L22/U5oMJz8pcMAySI4dN1okfcWT6SQqNHUGKkHIjNGpD4cRZZ4"
            @"Jc5dMYRpOcnZyhx1a3hwrMzByRL7j9WoHC1jxiymFmAig3Ycg8UWWCXYUwbbJ1m8wvuLfS6uOe50E9QIeZ5TLnU4uvA9Lv/Zmzz4qQOc/eQ46ytL"
            @"rDVTOklOJYZWYAiA8hAktjsbWwigaBK4lSZ88vEDLC416aWOILI4hGyQYYOI60sDVpe6nKqX2coddWMwsaEfCqNVmHzqCczkBuOfneBUaCD3DBJH"
            @"Ny+SD6UwwAmNbupf3Or72eHousSrtvGCoqlSzPHT4Ti6ImMsRe7IDBsrDGpFJEAEC6NWmLQwFhiZjoycKll5vGTNmZJhrBzYIDSmGLhhhNAIlcBw"
            @"arzMkwca7B+PqdQDwthAYMhaOclcn/RmF00ybGywsRCMTbGxWSdfG+DvtDgShzxej3j+7IPYcpVzNzZZyZXujRYbG45+X7l9p0U79YwElgqWmoOR"
            @"yBYwmWGeftsYWxEW+ymTM3WmR0KWVlvY0OJ39RaXohI/urxJVYtTs42CC8fKyEiJhz53ivHnHwG5Tvl4jfGzY0xN1bCbKc2thH4OqStwTVFgCY2O"
            @"BUafDESOG6go9FWkh6orMDdFQLw9cdLeRQcXmdQCccFkYJgODNOxlTNVKz9WD+RL45EZ2xMH7C0FTBlhLDSMl0NKIoxElqf21Dk7XWW8FlIrBwRG"
            @"aHccG/M9Olc66HpOWA6wtQDbiAnGQmzjELX6Wdb+zffR1Q6HGmUeOn2UJ3/hc+xr9whW17mw0WM1V/xWnyQtzns+yPnMg1NYDLaVMVmKCCiiTSsg"
            @"xmBF6DslCQxnjo6wttEuIC5DC+l84ePfWElprfdohLYIAp3HlALi8Tozx0Y4+cufIZl7ja1vvsfiS0vceW+DzbZixBCmytrWgPV+RivJ6aY5zivW"
            @"CHEkk+VQnoxCczYwZsYgVREtblHEDm0CwQ5WftcExUCYKQlny4F5bjQ2X5mKDVOx5Ugl4GAjYmS8THWyiglDFudaXFnYYk9ZeOZklelj41j1rM71"
            @"uHatDbmnEhqqtYCoHGByj40MZrKEHRvH9w7w/v/jn3D93ZtoXEKDgPKDJ9iaX2HjvQ84WI55tBbz9laf64FQLidUwoDnj0/w6OcPsfpPrzJTL1MK"
            @"Le00p+MciTd0nacnymaa88nTk+R5hrFFubQYxKuExpC4gJtL60yGltQrsTFFXFEtE9dCTv7ks6Rrq6z8wdusLiu3V/ssd1LWeildYGANzb4j90NU"
            @"jRYZYVVNxBOrFvkhi58MjR7ZHrrq0HWFFKFdDKdVMEUWYTIynKwE8tl6KL84GZtTM6WAB8djnjg9ycmzB5g8tZfKVJ2bX3+HV797h2u320xWLV/4"
            @"2Qc5+Ve+QFBqc/G//QbvXt1iM89pRJY91ZAyAWasBGWL1i0S5GScYe5r3+Pan/4IG8QcmqwTnzjKfDNl6523GcUQiKFmDY3Q0myltOohe2J47j86"
            @"wuaNLkczmNhTJU8c3cAycIWe7qtybrXNyZNjHJ4pc+36BpXQkuQeL4r30KiVuTTfpTxsXdoehTA2UaExUubBZ05S3T/F6u/9DivzGfPrCbf7OUv9"
            @"lGbm6OWeVubp5744cY41hw6bQgob4NSvZ07nnGPNKese3Zl8LIbIQr2AQRrBIPXI6MlKYD7bCPnqRMnMPjBW4rnTUzz3xVmOPPsAqNC8dIP3v32V"
            @"N793iw/W+jTKIY+dmYY44MPffQWaTW7dGLCaZLQyh6oyVQ4pRZZKGcx4hFRz7MhD9OZrNP/kTRjA0ckyh04cpPHjz9G7NM9VVa70M1ya03NKycLA"
            @"QZooM5MhevQQE8kKE5/vkN3KyDcM9b4nywOcKhc3BkzMVPn0Zw+xcv42+0dj+pnSSR2dNKfaiGn2lNZ6l3psMXicV2qNMhNjNR54eD9HPvMwi9/4"
            @"E5bfXyE+sIda1Kf3/gpbfc+W8/RyzyD3dHPPwHM5yf2FDJlz+LWihVa3dX+iSOrRtoeWQjpMjqaqJIEgBNbMhMKR2HCmEvDiZNnOPn5whOc/sZd9"
            @"BxvcmWtx442XaS40WbwzYLHt2MyLmioeXn53hf73bhChSBAwMELXKbVAKElApWxp7ImwVYNtKOVDhzA8wsr/+P9l9b1NpsYbzB6ZpvzicySpY+2V"
            @"c4y6lKOR4TubfbbyjIoxHBmvMB0lHH/oEBNnPkX8yQ7JjSXSt35E9tptsms52lE2E8+dIOOLv/IAtc0eWgrolyDLPPXEkuQWGa1z7bVl9pYjgiJb"
            @"Tr0Wc/DgOIcf3Mdjv/w0K+fe5PprH7DUUwLd4uADe5i4scVq4mmmOWnqyQUMhsOTI6cW1lv1wSB7M/V6Jfe6uN1rYEwx2BAFr9LeTluoknivaWCG"
            @"uNPI6KlKYD87XQufOzQaExnL6+/cofXSHFla1L+G54vUe3JXBEO3ejminsgKxgg2y4rsX2CoS8CBiTL7Z2uE9QCqhuBAFUae5cY/+S7vfPsqHWIQ"
            @"4YNuxt6ldap3VohypZkrnUFKzRRovLqBFx7cw8mfeoRDP3uGML5BMn8FU99P5ae+QHLyPeSlC2Tvply9sM6ZnzrCTKwM+in7Ziokiafbzxl0M5ga"
            @"4bXX19nrISiHRTdpaDlxfJqZh2c48fOfZvVH7/D+N95ioScsbiW0Flq89d4dSqWIMAyopRl7J0rcbvbopDmt9U2Ml3ooMpvDogiRg3VVTTKnc0Wp"
            @"oBgb7VWL6NkXzeZFFtV7iiHfmjYHWatzJ2tc1E6RALMWK8MOw2E+Px82RGzXfw0QqBKKUAsMkTHsHyvzqTP7qLkUUU9Qj4gPCuWTL7L+TpeLv/nH"
            @"5FnAyb0lxo/twzzzDHdee4fO/BIjmULuWE8zukMDeqIe8OSvPs/+X32ErPUOg2sruPUMI+sE+5eonHkaX93Dlbf/JQe/fIiDx6q4q2vEIyEu9QRh"
            @"QCkA98AYb7+zxZ6NjInJKolztAc5e4+Oc+STB9nz+U+y8va7XPo3r3Gra7ndHrDWz+nkSt8pvtfDKdQCw2NTNT59aopmJ+H8jSbvr/UaacBZj7S9"
            @"822nsj5UOemwv3nYUD4cWDd0pwP1mnqkPfC8mebucnvA71gjE8WcUDNrcZMGX7fIhECskIhIbA0TVmTSQhyIYjEYI8RhwETZsrcRowa63ZSxfQ2q"
            @"+w3lk7PkW5PM/Y//EyurOVNjdSbrJaZfeBbXaBBlPdZEubTVJklSeq5o1j4YWx545Aj7fuph0o0fomsd8sUEbWf4AfjuMrb2GtHUc5z6ez9HuXqN"
            @"7Moa3tbJmzmumZFtZpgjdZY2LBNXehw6NEaWOTr9AcHJPcx8+QnKjxxh/dUfMvetd7nV9Cx2EtYGOc3U0XFK4outqwg95/jupWUe3VPmp3/+LMdm"
            @"27S+/i79VJ5MxV8Jjcx6RzsTmVM0EZFIvaZOd/AkBbJEh+PXFNa9SNND0ynLTmW5yHPoSu50IVOu5V4XcpUFRVMjWgmFg4FQNVrkXUIjlI0wO15j"
            @"qhygzuF7ffbtqzL9QIXSoxMEx36cq//P3+XiH5wnrNcY2VNja+8+OuPT6Pvvw9winY0uuJzrvZTbSYp6eGhPzCf/Dz9D4/QAv36LfDUlm+tCM8M3"
            @"M+iD1BRb26R67DRSfQQ7YZBaCwkc4hU7atGZBv6Nm4wZcOIhVia/+DCH/vqL2NESi19/iavfv0pHSqReuLU1YCPztLKi9NrNlZ7T832v7yeeZKBM"
            @"3mlnfHDhNrcXm3Qp0N45nMw817bbaBV6XunocJ7q3fFexb/BdtUJtK1WEiPUhyNh4iJfJC0DjWH1bsKKTMaBnJ6w0piuBthSyMpWn9ga6qHFZxlE"
            @"IZVywN69FfYdqVI7FVF7/GdZfekGH/zrt8DGHAzhwFSd0Z/5Ass37jB/bZFyO0MVVpOMfp6xmTv2B8KDzx7n4E8cxXVfxUiAv92CtYys60g7Dhuk"
            @"yFiA5iuQ/RnR/ifRqS9iRx7DVF4nrS4RHThFtXKEsYea9OY+IFlZo3TqBNFIhZVvvcXiDy4zdydhse/oZi0q5RhRIUJQMfTVk8D5THUuVxYT/PmB"
            @"k3MtI/WNTnYm6GYzDta80A7EzIRGZlOvVyw64dG2g/XtkEzl7hhJkeGAEYYAK/GaqpF1RdMi30FSjFn2sVdpixAHgZkpGRpnDtf55b/wFOdev8kP"
            @"XpvDhIaKFeolw/RoxKE9JQ4fqlA/GlA6+wKb797i8j/85/S7lmo5oFGLqT11Ft/uUnvzbY4pXHaelW6fjTRnM3dUjOXIVMyxv/B5CDchTfCZkt4Y"
            @"QNeTdT1J1yO5x17rImkZv7WBabyFqbYx8SGi2cME0yPkG0209SouryODHqHkBG6OzjdvsvQnK1xvK9e2EjaTvPD9l9s88sBBxrzj1sVbRGGBWVIZ"
            @"upeeNIHz6jTtq76iBaSqLUqk+FQMkSKpGB+LIzIqdSfaviuFu0OAg+1J8bodtHlFRZIcXbQqkyouVZHUGK07lTXvfbtWCojjiD/91iUuX1klKAXE"
            @"IkxVLLNTZR6YCTj4wBijZ0apPvssm4tV3v1v/z8s3+wSjNeYmqjjpyZYtTUa56/CWotOs0MjGTDvYTHJcCgj6nn8sw8x8vQ+XOccYi1uY0C2MkBy"
            @"aK1ndPt5AZdZTgmN4NYygukSwYmbSNzB2iZ+a4P8gy0kV9zGgPYPW6ytZthzEYcPj6CVMp3VNu3UsTIs0qROOTe3VAwsMYbpWpl0q3Mm97ooSOyF"
            @"dmF0NXHomvOylqsugqBCut2/X4xz1uRuGXkI45G7U18C3TXp6+7gC4kpXhSpSoJQVyUV1TgSc3LghVc+WIfcUa+GjAK1SsjMSImje0NO/MxPMPrk"
            @"MQYbN2jeHND88BKlx46Sj3kW3ltg/fYqjx89xtSgz8r5y5huQp47VlJHJ81IFAI1PDxd4tCPn8ZWrpPdXsdGMb0rbZKmIygHtFopq60Ub2CQO0qh"
            @"wZLB21tUR0LMdAktlZFKieTqKm4rp3KiRlJOub3RZ2NpQLPlODAdk881aSWezVxp5Y7UwUoraSmaWmsmt5rtlliJy8Y8q70s8ca2xUjk0bZX2g7W"
            @"vdD2XtvFzCMS3QXw2j140OtdNgwp8Lmyw39jdk2BKY4Vw2NFsm3SE8/5fJBNlgM5U4sDrBEqoWFPLeZAJePwi19m6mc/R+vlf8zytxcIpiPq+yrs"
            @"+8XjfOrUc2zd2sP73z3P27/9+9x49V0ebMRsZTnNfsLKIGUzz0GE8UB59LmTTHzmINnGG+jAk7T6LL/dxLczKqMVNgae9V6OU88g9dTqMUGSU049"
            @"0b6YMCxjpuvYRoyOxtz87grxrT6tdkZz4FjqpFx8u8tTh0c5MlPjndUeA+cZeCFxejlVueKRNr4YyUmu7K0Fv/iF545+5dzFRT7cTP4bb23bq297"
            @"dhY/pejtTp1+lBjkLj9F4R0JWoxfu3+W8C66hdiIqRioWMOYiIk8NAPDdMmaQ+XQMFEKONQoc3Lc8OAzD3H0r/9N0uu/ycK/uAiNKo2DVSiXKD9w"
            @"FFOaojL6Aoce/3HOfPkAK911Xn75CpU0paeehX5CM80ZjUMe2tvgkb/xLCNnBuRLK5Aqy29u8uF3VilVAtJM+PDmFp3EoWFIZiwbm70CBdfOqVUs"
            @"UQxas0gcQGa58b0l3p/v0OzlNJOchXbKSi/ng9UeYRAQGMt6N6Hroe85V3iEupjCRQ9tFelp5mZOP7Bn7MtfeJS5DxZfWG6nv6kiPRVJAIcRp9Ar"
            @"GMd0ZwbkNvRSZRfblmy7qDu8LLJ7HqozSlx08w9LuFAxQmPIM3Coajk0Fln2ViNOjJd46ESdB/63/yXRyAVuf+3b9LdCxh9pIIFSenCW8oGDiH4O"
            @"zDGy5EeI+R4nP3OCyv4S3/nTyySdnK6BrdxxKLI88ZkHOfRXZ5HBPPlqRr7iePP3F1mY6zBRD9lqJXy42qebOxKFgXO0uhlJrnTTAnU9VbO43BPs"
            @"iQhqDTbfXuXiB00WBzlLvYx2poyO1bix2WOu2SO2woOTNQaDjM3M5ZlnPkOv5cqiV2kioNb0rs+vTHc2242xSsxyK416zn0bxHmko0XusL/DtSB3"
            @"yZx2aZldnCxC4Hd+0Z16rarijbQFjVQlQqizM65fiu5Ogbo17C2HHBp1HPsrf4Pq4S4bf/D7DBYN46fqRKFi9oxROTIJ7hhiTwJ9DK+CrtK5doXT"
            @"p3Ia//B5fu3/9Cqt200mqxEH6zGzX36YoLxFNtdncKHH3J+tc+W9JrnzpKlno52ykeZFT0CWoHgmxxr0jbDR6pJ/APumSlTaOXbMUntsnOmz+xk5"
            @"t8wHW+kwuQj9ZoeeUzKvxFtdfvInnmRmcYPbf/zuqUFgz6nbjnZ1Lc+57dSt5YFd/M7FlbQSB59Va1JVKYr3nrWhSrrLqbabKmeXxjEo22M7rexU"
            @"1e6O6jd3kePFlBKYsCJjgchMbOThRhQ8ebBeZroU8OAoPP2rP0P0yMO8/xu/ztwPW/jxMvFkicr+McY//UlseBjVT4OMgZ4D/yrkjnRhif7NVSou"
            @"5dhDe3jj/BYHkpyzzxzlyH9ykmztQ9z1hLXvrfPeu5ssdTJE4cBoiZtbCQudlL5XBl7JFLppRrufk3tPp+eox5aKMfhBRjw7QTxeYfW1BW5tZrSy"
            @"nF4/pZcrfS8MnCYDlWDp1iqVPKfZSdjMXTtHbjpY8yodFel5T9OrttWYXjfTP+qk+ddVpOdg3av2t0mc2DUrREXu0r9sE2DskNBJwaljds3KFiiG"
            @"QBkoxm4W9FeqRRbQChO1yDIah4wHOSefOkW3PMof/Ud/j+b6gDS0xcCPyDB5ZJTZNw2PfOnn2P/IDHCbvP9tDI7BnTVct4/mhpvnVijXSvzlXzrG"
            @"rT+cY+8XTyG1Nlzu0bvaY/l2n6XEYepVkmabbuK400lZ72dkUtxraAwm96BKPSxmJF1f6jM5GqE3lOq5GzQ+/zSHnzvK+M0fDdEcVV6/fIuek1bq"
            @"/ZWuY7G/3Pns4nq3EUcB5dA+18vcS+IlHi5g6lXaea6L1ugEBdxlrQBxkeouQiTVeyf8bpN9sM0utWsMebCbknGbyG44BT4SkSgwMiOJi6KQk8Pm"
            @"wsk8z+gOhPJoiExOcu43/5hBO6UVRCw1+4gIcWjYPL/C8nsvcfF3X+PIp7/OU3/5k+x/JCe902Jwaw1JYX2uQzJQbsxvEJUNL/yff4qJT02Szf+I"
            @"9FbOnQst5lb6XN/ssz5ocWQkpjXIWR/ktHPo+RwjQinQgikKCI0yXg1Z3kgYJNC+mdD97h0eedgzenKKwECWe/IsL2DtTr7ulXbudDEXFjPkudjn"
            @"Z7AQiswmqhc8xSTM7TqAV9qCRsMTwG6SOfXgpZirtL2+O3O+zJAiZ+ctSrCjeWQXo2ChpyYDdGaP87/+hWcPnLm90uWtha1/6pW2d4pznkyFrdV1"
            @"XKfHSm5542YL74rGDgNUSgEjZcu0Duh+/Rt8+NKfceYvfJKnPlfCpBntxYTWSkJ/kNPqK5vXVzn+szGlRkj/4hZbVxPmb/S4uN5jcZCSeeimjtpk"
            @"nYMaMXd9mcTlWC0mydhMCcMA1ZzDYwEuyXhzoc/84haj70JqvsHxzx6kNFKmOdfi5s11MAEhMttJ8j9QiijYO98eeHkz8Ow3UC+gLIJHdwBcArGD"
            @"9e1ivW7v/p2Z4rsoAPVu48sOJeYu9W/vjtG+65gGgYkiOH5qJPzh3/krn5g+eHCU75+7RXPgXjcilcjIbNkKDSscPToBg5zLN7bY6mdEVojigGem"
            @"GnxxtMrswWm2fMRSu0hpL7z6AfMfdjh4bJzkdptOK2ejldFsZwTGEvfW2ffEEbIPbvPBD9Z4f6nHxa0BzcyTOGWqHLOvVuLc9WXmOwmpFnjUKAyo"
            @"lit0Bn00V/aOVJisV3n94hLLg5wUGKxnHD3coJ94rl5r0UIQYxgbqR1a7Q5+W4XUqS47ZMXBSua5VoxQI029XvHQ9GhfEKtoX3d1YKruGkd+3zTg"
            @"4jTcPSpy3yBze4/e2ulgEXukFr79137p8cpqK+Wf/vNzLPb8r3srTSNUI2sergSGhi0YoQ6e2Et7fo1m6jEKe8ZjXKCMi+FLzz3Ej3/l00Q3lvjR"
            @"jU0G5ZDe7TZXrnbYd3CE3kaPxfWE3MFYPeLkkZiR0yfYeP0G599a4b3NhIVOQjtT0hymKxGDfsY7G126KomDZUVSRSqKFC261jBm4WBsGKSOtdSx"
            @"mTp6mcNvpRw9UOPSB1us9HK2Uje3stX/DQcrmeqcU1nPYcF7bXqhnXnmvZe2g/WiSCMo6u4a2Y9O/t0Rzu4Q7F6Nhe6aGGzvneEsGJQQRvfUw//y"
            @"4oer/PGrC1/tGPutFK4q9ENjDkZGzpStoRYFlHsJhx/fz0QIzcUOAxFmxiI6Wc7V7oD3bywTbraprbfJk4ybrZR+FKCthFvLAxqNMpvNPuVSwOxk"
            @"xNHPHsDuO82V332NH823+HArYT1xdDK97b3G09U4aKWOW/2MvvcXc8+CV23mzjcHadZTsBVr4pONkC//tWepDzI+WGiykivNxLGxMWAyDsmd5+py"
            @"l4FjIVHOZ34YDxTz65pepek8w+5LFobgrb4Ok2+6a2jdblkUOTi5h5vzHvpS+ShLW3A/A95wYHl8dbU/6ZW2CUxdM59aYaJk5cnt9p/UadzKHGvd"
            @"lBtvXOfMlx/i2ZUur15pMtkoUQ2EBeD2oM8/++EF9gYxdRUOl0LeXu+TjpfJFttcEuHI/gr1CPYfiah98jEu/947nH9vifmOZ2OQ0818K3FciNWf"
            @"7gyy/R3n6Wbucqpypcj0UldDoiKJqiRqTCPGM/XQPirlmB+8cYO5HDYG2Zup0ye/fWGVw+MVKqFly/ltDs1YPalH28OkW6pCgtLe4f3cxQui9xG1"
            @"6C7GFRX9SK5ohypH+QiP9T0nwQwHpTpoe6TvRVyu2veQioozQjkycjI0MqveNSIRSkFA1E2Zmqpw9IVDhNfXCGzIsaMjxFkxQi2zQst4PuwkrA0c"
            @"LedY6GTsbZTIe30OHB7l5EzMzPP7SKqHePkf/jE/utPlZitlY+Dp5PrNLNdrZw+MfOHU3hGurrZoZvpKgrzj0HVVScC6YeGkHwZyfEyEY/sipk8f"
            @"4tKfXOJ6N2PL6bm+40Incw8nqSfxsJX79zPlw1xZzJFFlYLredsWqKijYNVyyr2ezu4N7bmbiij4Sndozj+G+ute7WONuVcqftfP7vSfQjqcEFRV"
            @"JbFGjocFmU/RLL7SYWq2waHn9+MvrtLvePZOFRj/7iDHq6dcjvmwMyA3hcAzhQP1CASe+PwkU587w9v/4gPeeOl95hNltZ/TzjmfeN7JnM6fPbbn"
            @"S5U44kcLm3SUr6eeKw5d8apN9Zp61c1cWcTrdMXIZH2QsWeixOW3lrjZTthI9UI312/2Mj3XSvJ6z/l04PT1RPX8cAbRugppYYBx2/3Uqveqnvt5"
            @"03QXS+9udl52CMflY3nr7jkJ93La72Zb2EUHXFzI7UTRIpNG5JAAznsshuBmk8kHRpj5/EGyyxvcutYmrMTsqUSEYknUsN4fEBmwRnGZ58BIiWiQ"
            @"8tBfPoOt7eWP/i9/woebfRZ7ORuJznWdfjP1ekWsBIurrZlLtzd7W17+cd/rK16lrZAUK1WMyvdK03ttxoE8I72MSa+sbiTMb3TZyPVaz+lLiedC"
            @"6vVi6vTiINdzac6VTJn3qk0Hqddtyt673s+uZsqPFcJHaL3YpX/uocm5n0tBi/LmPdxSuyjdh98NI0WU56GdeZmzwkTf6SsWP4H6U7krWlnroaH2"
            @"h3Mc++IhTvyt09S/s8CFb98uGgCdcqfZK0qgXrHWEALlOKAqCT6f4Z3fucqHcyusasBW4unm+s3E64VMdU49iXqTeEPbeS1yNKqJQOyRVgHj1KiA"
            @"5uiVrRwWujlX5reIwgBUCERmVDTNPYu5Z9FAXZWkyJBqst0n/RESx21drvct0X1LNgR87UzEvpdPXO5jJL+b4t7JHbGL5HkHvi26k1OSu/xTfRS3"
            @"7S2gTCBMRsZQCg0OQ+/aFn6ty9Qz+5k+PYHNMmw/owrUAks1CqhHlslqxANjIXsPNBg59SB/+o//lPl2wkrqaWb6Si/XbyWOd1KnV7zSyZXFIXlQ"
            @"W4WeRzpFck16TlhTpadIvyiwgxE5Y3KohyFzrT4tSHue72aqc1606YWmIqkaekM3926ybbf3qXddz53x+7vVj94ti91/Gu5d3/uZRGQ3Aeougmf9"
            @"eJpbPyReM0VwtChO4mJipEyUkFPOCMupo7veZTUKufPDVWauNjnw2BTHntvL4U9M0rrTZ3OxS3NlQJ459u0pMb63RHj2cf7sD9/g0o01VtSwlbq1"
            @"duZ/Z+A4l6nObddvvWpbtABQ3btbdafXSNAYoOX910qSn73e6p/qpo604FZui2q8jQVCwIumMhzsMVKOf9oYU1/r9n/LDA2r13t9e9216z+W+PQe"
            @"avd7k3kfRxl/l3FQ7nLn6K7vtf3c9hzt7YKEII6iWTKywlhszVlrJG5njk7u6aWOjnO0Es/GrQ5b11vkiSOeKDE6O8rkyTFmHhoj2F9j0VZ56Y8u"
            @"88rL77PohZVeNtfK9Lf6Oa9kqvMemghue9GGhfZ0Z0hH4bXs/O4Lz66dKwt4FY9+Nvcu6OVKO3M/7Hm+m8KVQu/LzoIikHt3JcndhW0vx99H33s/"
            @"WbJBdgiguN8e/Acwlu/YhO0sX5EH8btYyrfLn7pD/TikrWrnnsUUvdJO3e+kuTsTGpktBzLZsYZW5tjMHHfigMbAUV3tU357FRMKWWjoKWx1MpZW"
            @"uqz3M5piaCbuzZ7T7/bdzsTENV/Ax7eNXDqcPsA2fMQJ6T309uzQ9KY9Ly9tJv4fGeW/8EqSOq44z5rbyfPfZQBEIXN3/R+/K8/jd9vaHfWz6xr3"
            @"TaX5tzEw33dQinap3SyC27H1dsQnKCqK13svpCiueG5evMQu1zUr/EkoeqTi5cWB5dmu942WV8qJJ7IZpSGBEkCaO9LhVJSOV9piaafum32nryRO"
            @"zyc55x265lVSLzuKkpK1p/u5v3D3KO9y+3ZZTT9ckgF6wXr5ps10wgiNRDlfJN10p1Pyfj2uu2aH72RAtWDg+qh7qh/jMukuW6C7jLDcEz3fR4q9"
            @"nf27a7G5n/Zc7uVo3n7OqZDCFedYEyHODHN5rouJ9+cHjrPdXM/EViYDU/B1GhG8FjODvBZdkwOVNxOn5weuaDlNPVcydNFv1wHZ8SAYxgJDo6h3"
            @"USJ69+Z2L6ZT6MMr4jUKRWY9tIe073d1vexQGSOym3zoPpJw/XcwK+8s8r2BmOzi39x9CnYqb6qIMWYXm/PHmpC7EfVupnLZYdbasRkWjQKRmcAy"
            @"EwqzoTAbGJmxIpNWmBjunlSRxFE0TaRer+ROb2eeeedZy2Hd33PUh7vFCKJEmW6rn3v1tN4Xi/pt1lyBCKmHwhGKoOJCqoKXXa4iH2X127m2fpx6"
            @"13tSQKpy727f4WQeFnDEfMwd7hKVtXZXQDG8wC76E4bzqnekulMVul+5sbOTrBECmLEiE4hihcntKfRDbvvEQ9HR7nW96G6Xtkc/lmZdi9r2XbTC"
            @"UIfvDpL8rkPr5e4+FQqWFLsDM6GYEKl6r7uou/JBIn+uN/PxIr9XWvfq/d1CkPuuMUxtW2t28fzu9slkuM66iwOmuHmzi5heuNuu6raprLaZaneG"
            @"oQsW6iJEXmhvlwq3E2G6vcB6r3nTXcUQ+dizuVt1FAuuu9jUP44LXPlodvPP9Vzupgs+VgiyXbT5c4SxDe76aKSs9+zf/x/jyOVSO0chLAAAAABJ"
            @"RU5ErkJggg==";
            break;
        case 1: encoded =
            @"iVBORw0KGgoAAAANSUhEUgAAAHcAAABsCAYAAABQKC3SAABtLklEQVR42oz9eZRl133fh35+e+9zzp1r7qGqAfQAoBtTgwABDgApkhAlgRpAWRQl"
            @"W7YiR8qzFdlJHMdxVrKsvLfsLDtPXi/Pec/LtPM8xnrxi6RIoiJKoCiCI0BiIoBuDD2ieqrqrq65bt3hDHv/3h/n3BoAyAkWa3Wzhtu3zm/v3/j9"
            @"fb8SRZY/6z9VRVUJQTECiAAQgu75LuH/zH/ldymKYESr/1d+XhSMgDWCE2YD0i1C6KoKOvo+Kb+vfDEFFSj/h2r5PaDY6nMiEgskKAToelV05+el"
            @"fFV9z3s01T+GIKb6tgCB0ftQBLACBokFTRRSVTKv5fMK7HlZ2XlkyOgJjN6ECKM3JCKo7H7Xzve89xmK7Hne+p7vk+rroBoAcB9k0Pf+gLW672t7"
            @"3hf7n5Ds+5uI7nx19BWz5wUEMAgqijVgRaYiy1ED7cyY84XXxaBkOjKE7Hmt9722IAjOMCVCYqAtSoyUxtXAFd1537rPyApYEYwhViUzSlsgDtD1"
            @"kEn1/UJ5yJ01Uw5mBZOAknudD7A6eiamOohaHTzZ8wCMyM7nq6NZPVfZPT7VD4VQHWrZNRzv/a1lr/F3nvwHG/ffe/tGJx5BpHpDOno8uwaXPQaX"
            @"6rHvmqL8rWXnLJe/sBWmnGHWWeYi4agLzA3h5UJlUZWsPNqKqqaCJCqkqpoB1ZcUQYhEjhnRNgLGSFuUxAddCZiuBs3UkAaqA1O9J4sQWTlq0Laq"
            @"ZCiolq8vaKbIzqF0RqYiwzELU06YC0pXVdIQtKtGMqksF2TvhSnfo6n+3Gsk1dEZ2/vMhKB7n6l+gB8M+5+5SHVIdr/X7bsSOwZkzzfKB7yw7rjE"
            @"/T/7fldXXjLF7Lkluz+h5S8mghFpx5ZTseFk4jhtxUy5XGcHuT4fVLqle5WuqqQAHl01SDsoXUQzKd9P7AyzkZVjo6NsRNshyGyR62KwdEHaBtIQ"
            @"pKuqmQpYYSo2epLq1qiQqZc0BLoisuPBnUg7Eo7FVk7GhpMoZJ7zIiRiJDFBMwF89YxG0QMBo7oTDfaGEt29L6WhRPd4vtKEOwdgx5q7nmfnzuv7"
            @"Paj7QPvtMTL7D9X7fX8ZfwjVzSndpWB015AiuydfR5+Xyi0bE48OsoPZxMrpupMnalbm6o4nt4TfTD1nvepKCHRVSasHkRVeFkVIFNLRm7GG6cTx"
            @"kBE6IsSCJD6w4gMrhbLolRVVMjGalLdTsthwsmblcdXqdQQyOG+URQSC0kXBic4mVk7XLI85y2zhWbSeVeC8oPHowDpjUIUgZRgyporRQlJdnNQH"
            @"zXbMKCP76n4vJ4JUh0JV99lk9zC859LtMabTPe6R/9Op0X5r68jg1b9mlJ23aQWsoe2szKLgvaxUv2BWHgxtG6RtRNtiJE6cPFRzzDUiQ2Qkcfhf"
            @"6WbhuSzIeR9YCUG7pSuWzBqmC68LpWskKxMqmUqcnDYibWeYNdDxykrmOU8ACSHO4YoosUCsQhY7TiWO06NkSiH1QVeN0FbIDGCNTCeW07VIHms4"
            @"+YwYkuqQzEvQuPx9ymAzin1GFAuxEdrG0B69ng+yAtL1QTMjOz6sdN2VifUDE1IQI/vi+K7B5X32cSJaXXv5MzLmPT69Cka837Q7CdJeF20FLNI2"
            @"RtqR4agTmQtGuz7oiiLpyN9Y0Wkj0jbQdsJsYg11Z2jGlpoR4p5/qleEx1KvZ8ubJ1mArchwNIPzueo8VbbkrMzWIvN4ZMCKQQQKr9PW+Kki6KJR"
            @"OkZpo7RVSK3odCsyz9RjeVJVUoWsCLpoCn3FCtOooKJZbDmZOHmoYfnMRD06NSgKCq+LRqQtkIgQW2hXeWwqZWLVtsL0XuN6z0qALuVHmY3L7jMN"
            @"e3KTkZH3mW3nE+Wt3m+HvTWI4kbJ0V6//kH+m/clRnvPSPnDAcVo6ZpNmYG2LUwZpU1QXCSzSSSni4KFQlkUTCIQCyRGaDtjZkVMUosc9cjQSSxJ"
            @"I6LhMjaHvrOdhSeHXvEa0qDS9YEVJ8ylnjNB6QomtsJ0zRlqrjRsCKHKymkbpY0RItVjqqQqktYdT47V7OcjC74q8fr5KH7LrAZSY6Rdc/JY0/H0"
            @"dDM+1YgtaZ4jEFOWi6lB2krpjaA0phWmnDVzVpiyVqaLoIshhK4gsaKZUpZOo7Juz01CVfZkv7rfX1axeSeR3K3h9t/c0pijTFQ+IDMrA/hubbv/"
            @"H9M92XEZiQOyc3gEY7UdCceskWkrOtVw8plG3U1nWcCLbAXVrqpkpXumHWlILIFW5BirOabaMQc6NW5vpaz1CzaHOVkRkiJo4pXpQaGnTBbaRdAF"
            @"UCwyHRkhcYIVULXkRkmsPx0C3YB0vcqqBk0VskZsnurUDajiVfBBGeQaiynLqRhOOSez9UiebMXm8ZlWTG+YV8lMyAJ0RUiMaluFjLIOnnJG5pxh"
            @"NnacrEfmSVXSzVT/5W6wLC/LqOZHRjYu85MguxfnvdVbmbeYfSUW+yyyE3O1qj6rbK76e1lvhQ+Is7qTnanu1nTlz+9kBpiybmxbkenYcNIZmY1F"
            @"T0Ui07PtiPvmxrl0da2zkoZOwe4vawWa1jBej5iqO+ZqgfG2Y61luLZquDlI2EoDgzQnDxCZAKpP50HmA3SN0k6M0IoNVO+vCErNyeNF0MWg2pUg"
            @"iVpSQZJ2bJ5sxaY6vMIwD2xoyGLLSY9MqdGsFvFYy8lTc50a7ZpjvT9ERMr6GcmMoW1U2wqpiCSJ5XRs5GTsONmIzOPNyLHSz8+Yym3vvTiGveVR"
            @"+eSDyj6vaDGE6vnu1MQ7ienev+8Ppw7dU7O+LxX74OyZqvlQNgjK2GrMjuuOCWW8qbLAFIHI6rF6ZJ5oRIa2hcfun+Zjjxzg1VeucWUlo595QIid"
            @"o+FgyqTcc2iM4w8/xMFT9+MDXH/nbX7wvZe5dqtLN6nRy3JqmUFE6Of+2CiJqznDeM1hql+jCIFmJOReTntlxYi2Vcms0amJuqWd2NK4KhQejKEd"
            @"Iye9MG1FptqxeXwqMXzo7mnmr68SPPgAXlkR0TiyckxUYgzEhpONSJ6qOXOsboWZVo3VfoZXXRl1tIrA4sgTBt3fFxhZ2o+uWfWMK/fPezsXuyFU"
            @"9oVWERm55b23V/cUzu+vk5RRyVOdquoFrZEpi06LSFy6LM1EJRbRBARnZLbmpNNIDJ1mjAy6/Ojf+qsc++rX+aN/9wMWe4r3Si2kTE93+Ogzz/DQ"
            @"p3+Kztw92PYMmmfc8ck1jj/1Kt/+zX/KWz84QzdO6A9zrBXW+oqvmiM1K8y0YoyA94E8QDvJGRb5sYAcC0HTAN26lelDrYhOUh4QYwzrgz5OZNoY"
            @"aWMhcSaZiuDRew4wN9vh/KWbGCsUqd8SSJxhNqh2rZHpyMqxVixPtxNDIzIcbCWkhZDmBVZkurzpZVZtpHK4eyqYPX0h9nhrFN3TnlTe3xuUfclU"
            @"aWQtjTsKyLq3//qBfWPd7RHrezx9CJkYiS1MR65KWFSzqihKIpFj9cjSiR2t2NGOlXzzCkefepyPvn2F8/ND0sE2xz7yKR774q8wPXWUIldUI7Kb"
            @"N9DuNmrg4JHTPPO3/iGtf/Xfc/ab36brEiKTIar08/J3aMSWiUaEqJKHQBGgU3f0co8vy53EiCSTieWOTo0kFkwIDIJgKdPeoCSxM8zUI+4bF576"
            @"0fu5dPYaSWQxWUFpWJktXa0SWY62Yzk11YqYSBxHxmvUagmvXF5FEUYhQSE1QlstmWJS3dNelbIPjpEqg1be3yzS/6PCdNc+7oO/VRi1wEWFP8vc"
            @"e1NxhTQEurHjVN3JE87InPe6IkYSJzIbGaZrRqg7sAREErLrZ2l/8gke/Px9zLx8nfojv8bch36UcGuNwY0FkuMnyeevkL7+Blm3j50cIzk2R3Jo"
            @"hs/+8n+FyfrMv3aGRlzHyICNgScvPFPtBq3IIaagKCwihrF6xOagKEOKgbqxnDrY4L65Jv1BxvEH7+LFH9xA/SZ1V8a48djyw/d1ePoXnmD8noe4"
            @"8sqb1JMI0/fEThIJ+iQIFsNY3XB4vMbBmuHkHXXuOj7L175zlaABHyALeq4ILJQtzbKZUeUpZTMFMpU95afsGjbsadu+956WtfXeFuRuK9Ltny7I"
            @"/ragym6La/Q9eyczUrqJsrltEhSsYSqJ5PRY3TweiSHPA1YgsULDGdqxo1Nz5Fn1ZouLdJ74JO2HH4Z+h+HbF1AvJCcfoP/6WVZ//w9YOneBPPd0"
            @"Zg5w4OOPYZ74MNHUGB/7uV/B9f57VhbXSQxEJqVfGLa622w3mxwYS8i0oNlpMDOE5Y0+NnJEVmhp4GOfOMbJE+O8+c1z5MOUQZZRjy3qFWcNR1oJ"
            @"99/d4O5nvsBgfZtmyxC0HHLETnAYLEo9NhxoxpycqfNDn5jj4T//Fzj7lT9hu/sOagyF+tQrq9VjmBKIq0eZqZYhIghdhUy0SqjK+rpMd/fcqLDH"
            @"+u9tTez1ujsxd89V3N/s3GvyPTFhZHh578zHQAh0rTHTDWc40IqJgOHQE1thrO6YG69zdDpmol0QXAfb/gLqP0x2e5F88RIEQ3z8HtIbC9z+3d/j"
            @"6vdfZDAcogLbG2uIFiSTY8hDp2h3DnP6Z36Bq1/9nxlbLmjc6HKrl9HLPIVX4sgQ2QjNUyKfMd2OKVSpx5bJOGGmnRNnW0yO17k0v0y3l9OsOxKv"
            @"tBLLfQcTjpyaI9u4yZXf+zLLy0quSmQNzbh0fZExTDUdh9oJ98w4Hv8LT9K4+xhRtkktici7Q/Kg89YwFVlzzKi2g9INQbsB7SK0S5csCcKKBsmM"
            @"qfoOIwPusZqtKpIgu7dZ39cu1g8w7r6sbX9Q1dG0Ufc3PPYMmWIrTIMwzPQV2zTHmk44MlGjboUsDUzUDHfPWu5+/CiHnvgR6nd/lnwtobhxCd0e"
            @"IDbBTE8jLqb79edYOnMWnxckUYyiDIqMtevXab9+huj4UQIwPvshos9fp/n1b+KHddTCxtBjrCGKDDUr5D4w2XAMshgNSrthOdhJGGs5dFgatKh+"
            @"/1ZicQJ3tmo8eLzO7CceZvP8ed765kVurRUI0IwNDTUYgVpkONhJODmd8PHPnyQ+eIiz//h/4J1XF+mHMjUu+83MiWgSlNmgdIvAYhFkIQTtVv3x"
            @"TAJJmVBJNvKeRog1SFZOlqoyVEaT5T3ReI9R9rhl3peGC6EaU0npfVV3UqmdAF41OEcnRiAp+7Wa5D7Mr3QzjnRiOonh5J1txltCY6LJsad/lvGH"
            @"fgw/TMiuLBA2uqi3iMRgBDtzmN73vsfS915isLlJ5GJ8COWbFWFje5uxd+fp3FikduoedCWlefAJJk68yeGN23hR4u28LKusodm0CJAHIfUBY4Tp"
            @"TsydhxtMHqqT3RrgnKHwnk7d7SRkd08nnHjyDmqzx7j+1d9lMxNyXzAz1iTNC7I0o5FEdBqGEzMNPvzkFHM/8iGufPV7vP71d3lrKefmVkauEFtz"
            @"CgNeddWrrPigK4LGRmjnyHxZ6WhaBljBQCwiyaguLseU2g1BMtWdemVf/RJG07dRTYqWTYzRnFZQNJSNa2R0U8NuQEdReX/WZqBdDc8z1TIbLIIs"
            @"3N5M56K7Osweijn6iQcYe+LXIO8weGeRYr2PeIPYCLEWDR53+Aj5rZss/8mfsHr1GtZYQvD74kgRCraWV0ivXKV27C5CkWM2xmiefJKJxS9TFHXi"
            @"xJKHQKftGGs5rDG42BI04JxlbqbG3D1tGgdiXL8gWs6oOcNUOyI2wqFOzKkHWhz4oQfJNtbo3VrBuYhOvSBXT71mqLcbjDUi7jhY576HWsz91Cm2"
            @"ry4y/41zLA+E7jAnqFJzVRzz4VTumTdouxa7x3Ifrgzy4vmg0g1euyKSGKWN0LZGp4zSHk2jgkq3gqJ0vUomO31n3WuD6m7q3pGfVnNY2RnC63uS"
            @"bJH3ZMlhTxtyZxJUTnaskenImGP12M4ZEdbXB9Qn5+h87K+S3gzk536A2DEkjhFnEWvLg9RuQxSz/dxz3D7zJoSAWIOG3YRPAGcMvcGQ4bUbdLa3"
            @"kVaTsLZFcucDjJ98hVhWGNuKybOCesvR6DiMNdS7BbEzRInl0Fyd9v0TuCmL6RfYhT5T9YgjR1qE3pA776px5IePEM0dp//Cy+Ch03bMkABCI7FM"
            @"NuDQYcfsg20mPn4Mc6DN9nd/gO8PiLSgEVvGaxabg8kCpnz/x3xgK3J0AtLVjLRMrhSj0nbCbGQ4Jkbisi1L5pUVDWSqrGoYlU1lsvXegGr21MUg"
            @"uJ30ec9weOTDtZrDisrO5GK3b7wHq1TileJqfhqX051AM46xPiU+9SPoemD4yjlcfQZbixDrUGsRY8AJdmaa/g9e4/aLr5BubRNZCypYCfh9k23o"
            @"Zzm91VVCdxvTaqN5AeuO5j0PEes3aaY1io0U23C4Tow0LLVBTu1GQdRwNO9KiE8eRiIPaUHtUsKhQ03Ue1qH6sw+PkFy34+i2kSyDdoTCTPB0G5G"
            @"xDanNRYxdd+9TD30EZK5+5H2IciFqR/6cR6YeR337FfQ1y8SuxrL/ZxIcjYqE+SinTTPVwrPohFpB9WuUdpOdTaO5KQTZhWyQmXRKyvB69aoyzdK"
            @"asP7Rjm6g2xRLTtawk5CNYJ0jKYRu4aU90yVZCcbY6edIqoJRhAlqUBqU4m1xFowPXuEg6c+TO/1i0gRIwbUB7AgGFQEd+AA2dVrbHz9m6zPXyVx"
            @"FiMGEcUHg6pSqMdX1Xeuge3uNn5rGzvjCWrJb21RO3QS93BMEiYRO4FNOoirg1V8kdHqd9GwiRvrYcenQC9TtG5Tm/IcNDF+KIwfSWjdN4tpniSk"
            @"b4HLaR5ogBlgIqV94nFa9z9NcuA0aJvgHawHdDhEfIeD959g6sSnGPv9L3Hm689RTxxLziAmI84D25lSwLQJ2i77xkw7I7Otmvu8Ud/2qis+sBqg"
            @"mwXOF8qiQjbqH+9AnHQ/jmzXiqG82Yw6VHtD8x7ohuieH65Kn71grio0l2M70cRamY4MxyInx2JniULO3IMPEYeYwe0touY0wQeMKmhAUczEGOnt"
            @"JTa+9hyLr72O5BmxizEVKCwPnjQEvELhlUyVQeHp9npkq2tEhw5CXhA2thm+0yI+/lkkA6KYMLDVcTeIEUxSQxpRWUNuF0h0H/GB03Q+co76xmV0"
            @"5TrxTIxMTCD6DqQ3sM7SmDIkh49Qu/cZ4omPon3Ib3UxSYpYi7+5RH75IunaOnZsjMb99/PQn/s1Qp5SfOO71KMmcwc6vHV1nazIcOWAZDq2ciox"
            @"4XRNzGP1SDppYfBeV1I4M8jD83nQeR9Y9ehKCUZgT/+hyp51d0a3AzmsJkdub+o8ai0a5QPajntaJntioJEy1iZWTjt01lkza40kxoDVwKF776ZY"
            @"20QzoFHCLjWUEcLUEtIbC2x+53vceukl0o0N6nENZ0yJEtQywAcgCzBU6IdAryjopxnDtTXc8mr5RjyE29sQruLaY5ikBtYixpUHMYRyFC5adv2t"
            @"QaIEqd9N1H6QeGqIHr0E7l1MzRP8FoQebjzCTjyMaX2O0Bsjv3oLiSJMs41mBdmZ11n/3ovceucdBpubJLUGc098hJnP/wSnfuyX6N5c4OqF6ywX"
            @"QiIQiRAJeMOxRDjWsA4nkKuCE/oqFF5LOJBIutuiUvbeXq1sZvaNBXXfzMftz7n2z/L3/t3sDIt2wXFGaYuU3ZbJevxfHjs4durS4urzpoR4UK8n"
            @"dKYOUtxeL8cfCtbY8lW72/QvX2LjzTdZffsd+rdv04gTIut2xnR5KBgWBbnCQANbeUYeQIzBxjESlDAcYttNoqkD2E4L02whtRrGOVRcld0LIgbR"
            @"gAYP3qPZEE1TwvY2fimAs5jWLHbyHqgpJrqExpu4I0+SrzxMdrGL2BTTGsckdcJgwOD7r3Dj2a9x5Z230bwgdo6+bpL+8dcwzRaTP/4j3PvZn2fp"
            @"+j8ivdmn7gwNZ8h8oGag5SyxERrW0csCV3spA8/zadAzXlkJql0RiY2hHVS6I/e8d1S4D52hstOEEsBRdTxkNKXQEqdDKF20KUFe7bKGLSGlo9Og"
            @"pvzHjNDuDrPfXt8a/Hrd2SedUSzQaNZpNGukVzfxw5S82yXb3KTY2qRYuU1/YZH1GwtkW5s0nCO2jthasuAZ+ILtLCfznmFRUCiMd8aYOHiQybnD"
            @"TM3N0brzCMncIexYG0lqSL2ORlWy5hyYCGOEEbYJVSSUBpY4IeQFFBnicygydGubfHMDf7OOPXA30eG7SC/dZviDS0StFjIxUXXRU7Izb7P41a9x"
            @"6eybWCCOonI6JpZ+r8/y89+j9eADTMw9wJ2PfYKFr/wRrcSReU/NOqbjiFZsSYtAYhxvLm3TG4aXh0FfyQo975XVnczJ7KIed/sMuxOknbApVFnJ"
            @"n4Fblh3UTFlMW5FpEeISpqLtnR62kJXZm8RWdNoHXb2xtvUbY3X3y5Ex007Ae09eDDBbK2xdXMQPh2ieYoqMfLPH1tommuU0oxpRZLGmHLBn3jPI"
            @"CwaFZ1DkNJoNZmamGTt0iNbsIcbmDtCcncNMTmDqdag1IEkgjsA6iCKMc9XmgCnLLaQqqwIUBUQBE3u0SJDg0RAgz9CiIKR9siuLFMtNNDcQW4re"
            @"gChpEqRHdmuF5W98m4vnzmEEYmsxoyGLKNZZthYWyS5epjE9zT0ffoqFC28i125Rj+s0UI4faNDPhXdu9Hjndpebg4I06BkndrZRt59Z7qf/lYgk"
            @"Ae2O6pzREGcHdqy72xi6A9OQHeSV07DrbkexNkg1KBDJjJIapG0N087orBMzK6pJUO3utLuQ2InMRpZjohobhcgZ8jRj+cZ1jk4maLxK7dAYutAj"
            @"u76JbufEAaKkRuxiosihKGleMAzKIPfkqkwfmGHq8EEaB6ZpHDxA/dAMtZlpZHwCmi2kVoc4ARdhk5io3QYb4dVjXQQIRV5UjZnSNYvz4AsIBVoY"
            @"gg9IUDAWtVmZfFmH9rYxxlKbu5P01hL52gayvsXWqz/g4ttv0+8NaccRqh6MLQEMWs6Fh8OUzbNnaT7yKE0zwYd/9POY3/9XFBpx36lJalb46rcX"
            @"uLE5YDNAprIVoJtYczp27qSGNFWjaTmhK8H35RZE+fcPgri+F8BujZV9QdZUKMKdib6qF8QJmjgjc7E1d9ccj9ad+WgkeiwWTiZWHnCWucjKHZGV"
            @"uZoRak5oRpbhrUUah5rUDxUcePpJTNcwfOsa9XYbZywOg4tjxFqCwtB7+mmOt4bpuUNMzx6meeAArdlZmkcOkcwcwHQ60Gxh6k1srYFJatTGOqRF"
            @"wVuvvcm5ty5xff4mt2+u0usPmZyZwjiDYjAuLpMsIxhjEWPLMLTTrTGMZtxibOnFvOLimGxji94751l85xwX56+QGMFK9YGUmxNVgho0EPKMyfvu"
            @"w0d12s1JXNsTrV2jPTXGq2+u8srldZYGBdt5YOCZV5HBsPAvbgyyL6mRDBVfAunIAK+qGSr70JCmakCHvSCNqkx1OyWQ7i+IRyfAQwa6stsOU8RI"
            @"XBMen51oUhSBzcEQay22apFErnyFwhhWl9Z49Q+/wdEJoX7gDjr3HcV94zVMVCOJY7LuAMQQEPJQ0M8yhqJ0ZqZoT09Tm5mmcegArblDNI8cxrXb"
            @"SC3BNFoEkzDIM4w1vPXOBf7gN3+bqzdu0E0zggqHDh2hldSZmp3gV/7zX6PZGseHArEGIdoTrxSJ9i5BJeUtF0GNQSUj5AXJWIesVefCteukaUpS"
            @"r+FCIBFH7CyRGBAtc0dj6K1v0rt8ieaTP0R6c507T/8k2fYG3/3q81xch0Ismc8ZFh4fWA2BLa+6IkJSbT6k1RA/ruJrJmU6tB9mU+LVKoAjO5WP"
            @"2+k0VcE6jAYEurtWF1Qzj1nJA/OWMOXEzGlEKqrJRN1RtzGJMUROMK5EEMbWYJ0hiCWYiGAdw1tXmf7Eo0Rzk+h2hI0c1BoMN7oIhiwd0lNPbXyM"
            @"+tgYzalJJu+Yozl3mLRR5+raFqvXl7m+tMJ6t0euhiiusby+wvPP/SlXbtx4eXM4/JfqQwYBa83U7MHDvzFenyALBX/77/8DTMhKpONgWEJZQwkN"
            @"FTFlX1WqGbZ1pasOikSKJAmmKBg/eS+nP/1pvvP7/ztpURBHCcYYYmupGYsIZBrAG7Iip3/lKp2PFLhmE1nOOfrxn+ONH1xkcOs6NkqQ8jBshaDd"
            @"IrA42j0SNBYkGbljVc0USRXNjOzuEu3dJxpdT9ndFdp7CoS9S4Lo7vKXolkRZDETztug03U1T2wM0zmC42Ar4b7ZNhFAkWGt0h1kDL1STwTnAOtI"
            @"V24QoozGQ0cZvnYbSZpEtSY5huHaJptFIG63mTl4gInDh0mbLV5bXObVl85ybvEWi2sbbKc59VaTpFaj3WqRNBp8/6UXvpz7Yn5y8uDfONhsPe6s"
            @"RRC2+11uLd380urqWnvj//c7f6k9NsWDpx/kzqNzzN1xhKTVBO/xwz4+LQgExEjlxaTMuLVA1UEUI0mBz3Pu+8gjpN0e3/+Tr9KOyjI0VJWItYa6"
            @"WIwEisLTvX6DmaVF3OFDZCurNIpJPvLTf5G3L/zfub01xFeAiCBlL1lDuTnhva6WLUJTDmSqlRn9gP0QqVZHRcIOykpEscZUdeAOnPI9Y4NqxUEM"
            @"iUh5koxIxxjaiZNTjdjSioWxxHLPVI277zvCqZ/8YY6eOMQdB+tMxoFECpqthLGWpTkdUTv5CL2L59G8hpoIkoSNrS5IoDMzw5JE/MGFd/kX332R"
            @"f/edF59/6dL8VxbXN1YLI3dH9RomckRxTFyLCOqp1ZunThy7+2MHDxyg1WoR12KctTRrdSYmJh8fej9rjGmYIFy9co3zZ97hrTfOsrJ0GxSarSa1"
            @"ZhPnLARPyAq8D+XwglC1WAOqgaCBLMs5MD7OcHvAysINmklCzVkS64hcXGb+YvDek+U57elJogMH0aAM17c4eO9xFq6d58aVRfpYBoVSdaNWVBio"
            @"ajY31fpyI3Kf6WXFswiecvrar4CR+4bzwvvn6+XelKlmtnt6xvt2fCuYR7nPI42RkQ00QiA26FwJn7GYPOWuR+/mnZspr72d0jp+H3d86B6Onpyh"
            @"Lj2cM8TRNrX770VJGJy/hjd1tja2yIZDFjH89sV5/uWrr537zpWrv3Z7MHxOarU4rid31xrNR1wUNYwxWGcxInhfIGIY74yXTSrvy8y4zAvI85y8"
            @"yJmamGhMTk5jbNn8SPOC61eu89IL3+M7X/8OL3//Fa7PXyUbpDTqNTpjHeI4wqKEvCD4guA9zhlqcUwUx3hfMNEeY+XmbUKvSyupUXcRURwRudI9"
            @"B+/ppym1eo36oUOQxBSDIUk9YXO4xpuvvMFADf08OE/ZT/bIihFpP3zP4Z/b2O4nW/3s34x6wipkCtmftdule3Z0FcrScnRLzZ5N8J0ulAjGSGwM"
            @"ncjIHSKSGKFhkIaAU5gVaDSsYTyxHDk6yVah/N5vvcDapmVxsUcmEXMP30W7meF7A6wsU7//JOm1NbKFLTa2tvmTGwv8q7feSV+/ffs/yYx5O07q"
            @"d7skOSjWJca6plgbG2OmqbLSKI6xtmQF6HW7XL9ymSsXL3z5xtXLz968fuP7Wxub47V6bbpWr5PmRbkzqwpiCSrkeYovCvrDAdcXFnj99TP86Z9+"
            @"k29+63neeP0tVlfXiYxlotOmHjsSa1m+vcxbF69wa2WDsVabThKhwbN2fYFW5KgnCXHscJHDWgiFkuU5XgPNiQkYG0eLgMSwPljnje+9wnYQ+nnA"
            @"I0tB6QbYEDHJ1Vvr/2ZrmP+mGJME6KLiRcSpkCL4D0Q/ym5ShYAbOWOR/ZgoDaNyqISmAnivq5HhqLHltppCWiiLvUKnF3o5DVFWb29zx6P3MPTP"
            @"sbi2ztH7T/Lu+QUuvHiWz/7sfRybsKQrG5jp1xn/zGGuvfEC//zteb59c+U3VFwa1RvHFEnVSKpCasS0S4SY7nRrxDkwBkW4cfUqC1evfH4ikv/s"
            @"rpnpz3fak3hfcGt1kwtn3vj16Tvv/HtzR45Q5Dl5ntPb3iLLc1QDufcEARdHBJSsyLh0/RpvXbx47rf+969cmey0nz519C5+6OMfZmZ8nD/86nOc"
            @"vXAZGyXcMzfLf/jZT/Lg3few/u4V/O3bmMgiUYR1DtQQxzmNPCJf3WDj7XdoN5pIs42Nxkm9kueeQHlAfQirAboCiUdXsAYT6HgNK6LEiqR7Nuhj"
            @"0bKS2ds6NtU4cFTuOt0Dftu7AeSMjYP6bNSxMkg7iexp1OOMzJbb5TodCUfRwCAP3OoXnL+wxMc/bJieHuPilSvp8QceTo4euZe3Ll/gf/3XP+A/"
            @"+zufZNzdImrfxa1bA/7Za2d4fin7UlxLTmZBzns1K1VMSZyJZkUkEZHYGjct1mGtwxiDFeHqu5fObCwvfekLP/ZDX/78T3+eUx96hMZYh6w/4Nq5"
            @"t/j93/rtv/fv/ujrvz7M8mfuPn7s8cIXSJYTqiTGq8cj5EFJfUFRBKy1xHF8ytlodrPff/nbr71x5oXXz8yNd8aeXt1Y+83hcPAKwIWrlxd/cPHi"
            @"v/3vf+5nkrtPnODK+jpqLOIiiB1gccMhsTM0x+v41Vtsnj1D846jmKPjrN5eIvMBtYZRsiRCLIZYlESULKh2q1XTxBglIN2S0kFKLo7AqhrdlxBT"
            @"bfCHMrmTHWqDEbJRjGDAAt6ItEWJa9Y8MtOu//1hXrxi0YlmZJ6eqMefSgxJPSoR9o2aw2ZDTjx4J0vL21xf2HJXbiywtrrKRr/P7aVtDh1q8PCn"
            @"TqC1R3n2f/o9Xjxzm6TefHxjkD+bBl5DDMaYjrGuba2dFrGJs/agtdGEc65hrSWJY5aXFtPB2soL/+3f/k/+9n/6d/4OD3zy00wcvZvmzBE6s3dy"
            @"x4MP8pEnP8aYz5762p9+679zjcZPtpotcl8QVNHg8UHJC09e5Hgf8MFTFAXe+5XgwwYi3jjbcVE0O8zy89a5iaTefMC5+KAYkyytLP/V1y7P//Uf"
            @"OnWKli8QDdQadWxSQ4xBhwPcRMzB//QJklad/htXyba71D90gG9/47tcv7ZEXw1Dr74a6Y18qgfxBhpGpGkMDRFiI9KJjNwR5+GeFvpM4uR0pvJ2"
            @"1eR4D1pVsG6ULY+233d2cfFGyqGFiCQo9IfpnzorByORO5qReXqyGbnEKq3Y0IzLfdq6M0y2hGSqzaWL6+AiLr178V+sbXWve7WnGiblqV/4HDdf"
            @"eZ2z33yFlTzh3MLWbw+CvoAYL2ISa924c+6gMbZprGtbYyaMsW1jTCOKHXmacfPdi3/rP/8r/+F/8Zf/5t+kMX0AU2+zsbrKN7/6x2xurDN75zGS"
            @"zhgf+shHyBau/+Q3nv/e3x4/cOhHQigqUEIgBMUXBUX1EbRk6tHg+z6E1SKERQ2a+aBLqvRVfR/FizUudtHdcRKfXFxf/YWbG5t//VPHjxHlBbVW"
            @"sxw3hoKQD5n4wmnWWWHgDAdOHaE91+G6Ub72O8+yngnd3FME9SMDGaEh7Ixi3Wj/14i0a/D4nQ37pac+fOSLX/yJD30qDPOnLy91/zHWpKrq9w6G"
            @"BMqcRN6zXW9KjorYGNPGKJWBbfknSWLkdD3i0cQGxhPLZN0x04o40ImZbNcwm+tMtuDVc7dYXB0+V2s0Hh1k2bfbU0eenH93iScemiCsX+V/fW6Z"
            @"b51d+41U5DWM8SBexCSlIcuba62dstZOGGPaxpS7uzeuzf/Go/cc/3t/87/5L+kcuYuoMc53vvVt/ou/8qtAzP/wD/4+r7/8Ep/+kR8lqje458RR"
            @"nn/22R9ZHaQ0my28DwQVfCgIIeC9rz4K1IfUh7Dq1a96dDUo3aDaNUYaimRZkZ8X9daIaUTW3tmI40/Nry7/PzDuJx8/eACJHDZ2+HRI7ZGDuI9M"
            @"sfiNF7n6+rssk7PiDF//7T/h+u0tulrOcUVw1jBhjEwbkYYVma6wbXH53KUhQd2H7hr/9Z/93ENMT7V44+w1Xrtwe2U76B8E2AgVv8de1LmNjGBM"
            @"WTqI7PIlGZFGufQuiRUZt4ZpI9K2YqatMBEZOdaITKOTOGZaMXPjNU7M1Dl+0HLHh05y8okP89BjD3Dp3MKx1e3+knFxu7udPXv3veOPf/zBGn/n"
            @"H77Ec29sPO1q0WyZJRkvRhJjXNsY27HWTFhrxo21nShyx+LINhFBQmBjaenLv/zzP/MjT/zE54jaLXqDjF985hkuXb3+9/7+P/5/feqb3/wmf/CH"
            @"X5HxVv3/9uRnfpjEwbUzr/P6hcsvt8Yn54qi2DfY9r6gKHxl6HzJh7DkVZfU01cNqVibpMPs7GBj5dtRMTyadrdf66eDP3VRdDC29u5I5NiF9bX5"
            @"O8fHj91Zr1EUOfFddTpfeJiVV1/i+ttL3FjJOX/2Oj/4/tvcWO+xWUAaPFaEyAp1Z+lE1o0LnbbRaRuZU15xqpqJqhVR64x87MK7y3z9e/PPn722"
            @"9Q82fPinhZpFVQYImalKHTNKqJzILm+TId6lAyMbNTFNoD2aDFnDtLUyjRiyQulnnsJDTeDgTMwDv/gLNGcP8L0/fok//eYiyeQ007k9dXuz111Z"
            @"X/71Z37iI//xv/2td7l8w5+bGKv/jd6weFZFUzAY49rORbPOuTlr7JQxpm3FTqFKPa5x4NAMG6trjNVrv3z3vSfw3uPimJe+/lWuXbr8H6+L/NOH"
            @"H7jvv0Vhypm/+PU/+gq/+tf/GrFzHD58EPE+CYHdXSg1O0RqIxqkEhBeNWRDSMVI0u8NvjEd8Xd/9gs/NXf30aMs3LjBn3zvRc5cWfg87THqcfLk"
            @"cNh/5Y9uXeXDd0wwMeno/OwjbF55k+U3r7DaDyxtD1n10HUxg7zshsWmDId1I0w6YW484sQDcxjX4I+/c54Lm+lpyTXOCn/eB1m9sjr4G0XQRTUm"
            @"DY6uV10JhK5KRdSi+3exnTG0DSVfQ2Q4Zg3ThhHJlnRRIah2RyWRQdsOZq3otLGGyDlsCNQS4b5f+mUwA1795/+Cr357ja+cWVu4udn9RTE2Hub+"
            @"lU89ce/K3PQYl53lzsOTpy4vda84y2yALmIw1rWdi+astVPWmGljpB1Fbq7dbDDWGaPVaHFw+gD9lVunXGQp8hRNM25cuEBb9Iu3gvmnDsiBxJnT"
            @"LhuQ5zmJEYyLcC6aBcjzHOcMUeSwVgneUFRLWWJMXEJyQAxJWvgz45H86v/7H/53c5/++Z/DZwX9jXWeeuF7/JN//KUv/9FLr/wlNzYxG0fRyeu3"
            @"Vlk8HnHfL36c9YuvsPLiGyx1A0ubA7ZzX241CDQSSz2xhBBwCkcma3zsyaOc/tRJls/M84M3u2Q+lDgyQ1JNBVArqZqQBk9XKQ+ioImUS2TZfsiU"
            @"4KzR6dK41czWMutEZp1hVkr2gVmDaQelWyLlJYlFTyZGSQw0LRzoRHzmr/0K3Zu3+ON/9Ues6EEubRdksnV+cmzib5sQ2u128uQvPvMw3/jqm3z9"
            @"xUU2M/NsQVgo4ZCCiqSKiRGLi2qzkXPHrJMkiSOccxgLw8GAJHLc89CHeO2tCzzyxMcRDRw/foI/d+/EUy9ti75wfV1m4uiZn7t/4m+3HrqPpNEg"
            @"31ilv91DnI3FwJEjh5mZOUCjUafIPbdvL7G6usp2f8AwzeZUh5n3YdVEEdlW9/xf+7Vferx1/Bj/6t/+O37yp3+ambtOcH+9ya+qsrjy937zrYWl"
            @"Xx/vdH413e5v3c6zjsQ3Gbz7Nt2BsLZdbh0kiSWJQNRhK8rFzCuzs+Pce3KadiviymsLfOMrF3h9YZPVYMi8pnkR5r3XlaDSVSETTGKsolqWTEHp"
            @"epUVA22FtOpipUHJXMm4YqYjo0ed0dnImGOR5Vhk5Ghk6LiSjxErZtoZORZXs0tryg32yabhsZ/+DG++/BbP/u7zLGQT1JoZ3sfMNNtPDQabrGxu"
            @"/saHT9/35MtfP8PzLy/grGHK+6dtUOLIkbgIcZYg4MOQfnebVCFYR16v0Zo5QJLENFstCh9o1JtcXd7id7/8LJ95apsPP/ERNr/ws3z8wgv8hYcP"
            @"aN0p2pnhI//J36LWGGP75iKXr9/kzqPHO3ccO86BgzOkacrKzQXyXo+s24XtbcwwhWFK0U8X1UmaGzN/7PDBL/fF8p/9zf+aH/vhH+bP/8Qz/I//"
            @"0z/jgYce4sRHPsrnf+yzXPnX/8vTopKojbOF8/Nkg+O4sQZiN2m3IgqEsazg1PEm4+MxwyKiEMfVC2tcub3N1567RHcrZZB7uhg2sPQLX23ul3tE"
            @"O5sdZUYcC+Uy9x4WnK4KsUIWKl4NN+ozipGkvL0yHVmO1p3pxLbct3EjLh4RGk5oxpbYGhJrODiRkPcGfPl/e4nzl2+jtS1s3AAx+HSA8xljVn/5"
            @"xtl56mMtPnNwijtnZjgwMcH4RIfxmQO0JsZI2i1ss0FwjsEwZXl1las3bnLx6nUuXrvB6oVb5ONTjM0eIRqbAIFX3jjHa2fe5o675jhw6Di9mSGH"
            @"zBbSnODIU19kbPoAZ178Hm+/+BI9kzA102ZtZYXu0iKHJzs8ev9J5o7dRWd8DBHDcDBgZWWVyxfeffKVV1/j+6+d+Xxn5tjf+MOv/imLKxtfkmbj"
            @"P37tlR88/o/+zn/98j/9vd8nabd55KMf4a6vPPvk9a3+mUg4urG0jkQHqB9sM3Ugw1rDeGNIo51wz48/wfjdd7Dx6ktc+u5Nbq30mF/usTrwZChF"
            @"gNQXDIqAV8q1T5E4ijhmAm0NmnplNah2A9IdYadUQ2pE2n6HbK2C2fhQ8jr4ICvWMFXNE7PRCqE1JUtWzQjjiWMstkw3Iw6PJURBsSjuwjl+6YuP"
            @"8v0zt3j5+xfZ2trEGiExysxEg2OPTE0/8EOf5ng/Jru9RdTs4Oo16uMdamMTxO02ptXGtVuYRg0bx9ydxHwiLofmW9s9bi4uceb1N3jtjTe5fPkd"
            @"iBt0xqZIVXn5e6+jotTbHdIsJYnWSd75F9VUR1jd3KTf6+EM3H/nAX70cz/JY08/w/j0AUj70F2H4QANocRbPePY6PX4xndf/PKrr7zMH/zRV1eu"
            @"LC792n/7f/27vzYd2R9bffc8a8vLTI2NceiOO7n36B3cOHMhxhi2t/vkmVI7UGP6OIwdGcNNH6d59AjRxAzkqyy/eo0LZzdZ7WdgBWOhyEp6h0JB"
            @"rOBEEyf2tKrivU+Dka5XWck9VwoNC0WQRYIihlhV0pKSgbSkbCJWNHV50Csh0A1Gu1ghhDK2Fl5O515PF4XgnUEiQxqVc8NOI+ZjP3ycdlvINvv0"
            @"1lNivckv/vRhnvrsIRZv9Mj6ns5EnTvurXPksUdoxE9y41/8Nlv9NgHBOIep1bH1OiZpILUaGsV4cXgMqEXEYeoNmpMznDx1Pyd//HN8cbvLlXfe"
            @"4btf+ybf/u5LXFtYotZq0xpv09vaJKCEfEhqItI0p7/d5eDMOD/6Y5/jYw+c4N7TD9G46xSDi+fZuPwO5OloebwEymuZwcbW8tMPn+Jzj5ziiQ9/"
            @"ePrX/9E/0R+cOy8fOtx59uiBFloRmEVJzMzUOM64WQ0+y4YZeb9P58RHiQ8OMbEyvHqdpe++w+rlrzLzobtpf/hR3Nvfwmxb1OSMtWs0gmFhbWun"
            @"NJJqFzcoFN4mXjXJg0ynotOZl7aBTqZyzqOr1si0Bk1FJRFKMlLBZE6VNIh0fWA1DXrGG131QVbzPMynqmcGjpOxkZPbke0Ms0BvGMhy0D++xB0H"
            @"GzQblsgJ9ZpDry1x/I4mD3y6Q5hoEk13SjKkzg+z/fY1gs9KZtXIETfqJPUGUb2OqSflYlgUg4vKzYB6HYnLz2ujia+1CUWGBuXofSc5+uB9/Lkv"
            @"/hTP/fGf8O9+5yu8/cbZtN5uJ0k9YdAfEInw0AP38hO//HN85nNP00y36S1ex7UPsPX952F7A+ciXFyjCNXsdoSSLAI+zdnc2oasz9MnDnPvP/y7"
            @"/A//7Et6d+8tpp/4FBOTkwzW1/DpkMgabBJ3skE638+y6eG2II2PUWx+g83vvsjVF65x+UqfjW7K8XSNox85xPJ2xtYgp/CK9wV5gEZkK26qsvdr"
            @"TIXH8lr2vwulL2F6KGY6LcK8UdpZ4FxhWATQkk8yFZVY0NiFkjOxq0i2A2zOAw/cNfGP7j7Yot9P0SBs9TOWNnpkPictPL1hxvxij7G6Y6LuGKtb"
            @"Dk0mmF4A74mSAXkRMK0ncTJNsfDHhFTKEqSWUKu3cEkdogSNHGJL9moxtgSpBYWiRC0G00N8+bq63WWYDvB5jouEn/riMzz16Y/zh//715Pf+f0/"
            @"Yau7zZNPPM4zX3iGD3/0MVxnjN6lSyy88gKdB0+Tvv060utjrcXfvs3Su/OM3XEH9uBMuY9c7kyiWY7xHhXLxsoaR2LDf/OX/xLfOvc2n//Vv0ns"
            @"ygmMG26z0h0iUYymmm70AkuLSxxa+DIb3/4WS28XXF9IWdrM2ep71n8wz6svX+Jm17M6KEh9oKgwTw1nqBmhZg11a4icwVbsNKkP9LOCjdSzlQV6"
            @"hmO9XKeMp50FPZdhziuaasXUs8sgB5lIxWIqJZVOmgeiOOZAEhMbZXXTsbC2XWKKMsWo4hG8hVpimalbxqdrtI+1iE9NEd15BDd2B5J8hmJ1Gd3Y"
            @"wkpEiAxRlGCsRZyr1jhd+TFCWfuAZhklKVSB9nvlGoov0CxDixzxBbkvSIPiEsfP/9xP8NM/+9NkYmnPHgaF4Xaf9OpVNp7/Fo3xcXR1g9DvI2Lx"
            @"aca//dL/h7Ovvs7nPvlxnv6VXyRvNEbEVeXmYAjEkSXENYZ5zliR8clHn+TtN95i7vAhpN/lpdfOcGV9QOHDlrFRuzuEd9+c54H7HmWwahikSpaX"
            @"jI6NsSa3lrv088D2sCAtAnnFQl93hk5kOFCzHOo4JluOdsNSSwyuZuj2lKs3M66upyxv52xmQt2ETs/z5NDz2KDwz6cFZ0RLdvhc9Yrbs9GZqkgW"
            @"VLvByNa5W5s/d3FhcyqxnLbCtLVMJZE9HSHT4mDglaTwgGNiIuHuk+MceWSG9mMz2MN3YOKTqBwE6ZDffoVifYCqJbIRxlUfNtrldw6UrjEv+70l"
            @"vroydvBoXqB5Br0+YThE8xwfPBSeAqXvhNqxO0kOHmKwdKvkR05q9M6fx99exk7OoFvbhDSjXq/x0iuv8M3vv8Rko8lbFy/xqZVV3HQFPCu3zjC+"
            @"4J0XXqfVaHDo/lNkCJPrS/y7r/8eL7x9hfHxNqubXTZ7A2zsOta0OpiC5kQbjafZXu8x6Al57skKT3e7V7EEgHWGGhCpEhvDVD3i1FyTBx+a4fCJ"
            @"A4zNTdGYHsO129jxA/j1NS7+mz/kwsUel5f73N72LGwOWNrO8D4kGaP2sE4Z0baIxG7PYmBJdyek5YqIaRMJqegZJzJrDdM+yGosclI9pxEl8bCd"
            @"BbZzZSt1nP/uIgdvdBmbu0Vy8Azu0EHiO36ZYmUFMsWoKbUDjAFxpUG1wmr6oiJeVaQQQijKm5rnkGZof4j2exSbXXx3G81yCIFBnpNlKfWDUySH"
            @"psk3NzBxghiLphmb75wjynPCdr/0Dh5M7Llx/RrjccxUrUEnqeERTJpCUIL31OOYl189w//4pX/Oh2cP8x/91f8QN3sE4z0fP3WcP3j+VZbX1+n3"
            @"emmeZ/MafAaQq0x97cuvzT3+6U/RufchVm/9gCh21JwnJEIkytB4MufoZ55QdtO4azLhh7/wUe76+P2Yeg3jtATu9QYUV+fpXrnFrRt93r21zZWN"
            @"ITe7OWuDnM3Us53rl4eeV3LV+UJZLFQWg2rXMRJdUDJjyIxKu9IESFVD6pDZYLRrlEVnmS357AQJnN7KC1xfOX99g253wB2TDTZXBszdbDE562g/"
            @"0CY+VCD9LQyCtSXVT7nC6UtMZQjl/o73uxv8GiAr0CwlbPcI2z2K9Q2y9Q0GKyuk62tsbG5xc7tP0zomjsxy4vQ9GGvL5a6gYB35+ibbN5doa0bY"
            @"WEPiGioWtcJ4s8VsrcFMUuPOuTuojY/hh/kOH5CI45uvvIazhv5gwNb6OgcOHmTQ7XGHcxzu1MmCMnfPHcnhdutUnUC+ucHK7SWunb/Ov/r7/4Rf"
            @"+s9/iomLl8h8HwXStGDu2CHqcWD12jqXF4bc2s4JAluDguf/4GUuffN1Ok0hdormgbRfsL2Vc30p4+KW50Y/ZyMNbGeeXh7oBZ7NVM4XhMUc5r3K"
            @"qldd8bDqxOzfMFBIFS2FH1S6wdAV1URUEh901cOKF6a8J02FZOCVrTSQ9Dy1OEeDJV5NEZMTnajTNgafZ2gd2BqRllW8zVoalaIob7MXoCi/7Ask"
            @"y5CsQAd9iq110tVVNm7foruxzq005Uuvv8MnDs3yyx9/HGk0KLb7OKnUVrwvT31/QJH1yVZWidodsJasyHngoYfoXl0gxvLAz36+5D3OMoxxEAJZ"
            @"mlL0eszVGxxsNIinJymGKX44RLY3+Cd//+/QOHEPrfExCAVsb6FLS/SvzHP1ygW++cbbfP3/+xxPfaRNZGBiIkLTgkP3RMw+80m2Lq1z9NXLXHh7"
            @"lTfevsVKL2f10gaxMdQjS2RLg6SFsj30bGQ564OCzdTTK5RBrmcGXp/PAueLoIu5Mr9T65Z/VrhlszvPrXj/MxGSEZFY2Xs2bWt0ytnSRYuRBNWS"
            @"wjYowyKwNcxpxob+0NPv5XhtloZKPBpZQuER60ZYXCSEarVTy53daptNg5YQ06A7vBvGOCSOse0OU4cOIf0e8VsX+eMbC+ndPzibfO7wIYIKdQym"
            @"VkMiC3lG8IH+Vo+42QU1mMjh05yxzhif+PNfQJMGreDJrt9CYlcOwooAnSb3zR5ia+EWJz78Ieqzs2RXF9DCM+xuM1lkRMNt+kv9EhReZGWAG59h"
            @"9mCPX/i5E/TuqtHMfofO8RqoA2Oxh6YwM0cpXltAt4dkvYzeMLAx8Ax9uWReHnxFxeBVSYtA6kv6w0Gh84NCn88KPZ8FPe9VVrzKSqG6qEqmommo"
            @"2pVOd+hdK+ISiMusmdgobUUzNZIZo20nYTYq9Fi75k4neFwU7ahGOGfwXik04IHgFUyMGsG0HOTl+iQSyo264NGihKaI6s4qi1a7OioGiSM0z5F6"
            @"HTc1SXOsRd0dp3n4EPGlS8R/+DWCDrv/8/MvJJF1fPbpTzMMAZskuCRG8xy1hvXtPm5jgyIoUb2ObQRCkZN0S6xTnvsyay8JstGgFEXGR5/4CMv3"
            @"HOPOxx9FF5dgOCAbpKS9AYNrC2gWMJ02Jq4SQ1/gBbQxxmD+IpP3fIraw/8Rmn0f1SahnxFoMDx3ibXnzzB/sc/5611W+zkbaUG/xC9ThBKpWTHD"
            @"pkVg0QddyZTzhWcxD8z7wGqhLHhlVdlZGEv3SvW4UhBqD3FYSa/bHjWpDbStkSkjtO890P6Vpx49jM0LDtw5y7e/e47F21tMdho0I0OWpfjAHqoj"
            @"g40b2DhCvCKmjLFaFIQsw8c5knuC89ioIu1QQa0gEhNsRXcQO4xvETmHtBpE4+NMhpxGo47tbk9nAv/8299iddDjpz77KVqHphlaCyEQNRI2h0Oi"
            @"zS0aeUGt3SHJM6wrt+6tdTt8wmafcBN06gkTp+4jv34Tv7FJKDy91TW8C/QuXkQ2e0QHZrCNJtST8oAEj7GWqDbOxvPfZfrO/wAawvCd36H3+lUG"
            @"SwO6ayk3lpXFvmd7ZFCEoqKvyYNSKAves1qoLvqgKz6w4lVWixAWi1AaNUA3aJkEB7Q7GjCM1kqcrbogGt4jb1IuLMc7jCeq1GoRUVLj5sItri/P"
            @"s9kd4iLL8kaPLDFMNSO8hgoUbjDkSFSv2owGHylFroRQgA+I9/gsxzpHcAXG2NKDOIs4i40smsTQqJf8GZGDOEKjiOb0NJ12i2Lx9oKJmMuA/+X7"
            @"L3L55i1+5omPcufdd0IcQ+xI2k1urW9yQIXhIKXWqFGrJ7gowVpXUikoYC1GLMbYks53mKLr6yWUFuh3t9hcX4d2zMr5VaSX0uz3YXwM6XSQeg2J"
            @"HHjFJk3C6ir5tQswdo7BO/NsXM24ebXH0lrK7a2MxY2UrVEjwwfyEMiCpj6wkge9UkJ8ypFehWnuljlRacSyfNWS+VX3wFwrsk8nZRm5Q6hdxtq9"
            @"sjKlaxZD/M71tecuXVk9Vq/ZY7GBVj2iHlmcE5yzWFuCgcSARAYN2yX3RaOObVhcooQiENSjwRN8gSlyQuGQwhKMQSRCgpRu2dryjdpy3RJD+Tlj"
            @"qHc6HJieJJx/t5tXcdoYy/PzV7i8dJvP3HcvHz11LxPjLcYmJ0gHA26tbzBWr5MOhmxHgovi0rho2eozjiiKsXFMZF1J8WBKGbo0y1i5uUTRjDh/"
            @"8QqHM48zFg2BepHjgscVLaglZbYfPBRCcf0mrt6hd6PP+kpgbTvndjfj9lZGd+AJRdk0GfFdqJJ6lVXVstukSmpU2pSt78wLKzvToHIDk13pneoe"
            @"hlByP4aSV26XIHtEkyAkgpY0CQgeXc3FzNvETOeiaeQkCVXgNyXfMPXI0qw52s2I9rgjTnrgAyZpIU1BXPkQyxIoQ/OI4BxkJdmYmEpDj7IWFky1"
            @"Ge9QIzsdLB/AxBF3zh2mdE0VK4hC3Tk2spTffeMs37pwmQdnD/P47EGaUclSt9zv4YwlGQqRSSttg0BaFCRJTJIkOFvOmKPqPRWhYDhM8VbAK0kW"
            @"KIDgS2B77D0mz8v1lsKUi1lZjhZKvngbd+ooeW7pbg1Y28pY7+VspQUe5YFTh+m0G7x07jbvLKxgjHRGWOXIyvR0zZ62IdAberZyfb4PzyGGXJgX"
            @"iDVI+l7KolFjyO3sBe1e1lLgsLzF8U73SiX1QVcL0cXIyFFVktEisLNCPTK06pbJluPgoYiDD4/RujcmkCK1DtI0JdBqWwk+g9yhNgPnSnrA6k8x"
            @"lUFDyWiNCVDkaHm1UDGEUBBqMceO3oWD2chUZDUjRohKrGmh200vXeg9H5r1p2brNeIsJy486odYHEZDxYJa4qi8DxRecdYyZIAzBmssuYFh8Gha"
            @"0HQxH/7o4wyWbtNot0haLUwcQ0XkIlSdtqJAc0+2ukkDR9SoE9neqLtK5pWtzPPquVsksWOtl1MEpeRkLikpHMx+9qPHeOT0HL1eyuLS9pOvnll4"
            @"8uX59WfXc/1HxtNWkUzRVXm/ckFp3L36NapkQegatK1QCSGRVCTQcaVikpXcTuCsoRZZJlsR9xxucPzBMQ48fojGvYcx7Taqm4ibwDQibCOjcKW7"
            @"CnmGWEeIIrSI0SJHc0MwYCrgWJn12TKDtga1Bozd2Y44du8JptuNuUE6rFTJRnoA5TGNoygJeXH6ndvL3P/nfgrXajNYuU2xtk66uY2kKTYoVhWr"
            @"ZRmSWoNX8IUn04Jb/R7bgwGnWgkT9Saz993L1B1zDCfHMApRHGPqdSSJwNpSibMoCGlKMUwrr2ipdRKaiaGRRFiTIcZQ+ILVfsr2eiANpLkyH0LJ"
            @"vSyQYC3fefU6i9dXeeDUIR48eYSZiQkuX3/+6e3Cf1mMJhrIrMpU1V3MRpWPILhQCS2akZxpuWjUrhhu4pJETGNLqW4pSryzjS5CzcFEI+LeY2M8"
            @"9oW7GfvQIUwrhjSlWJ4ntC4SNR5DWnWob2PiApNDKAq0KNuLweVIWmWsqvhRDFVFvYIzZesSV8ZwUfI85667T3D0ziO88c4F6nG0I1upCkGVwgec"
            @"s9PvXl8889z3Xjn9C3/lV7jnCz9LCIGVhQVWb9xg8/Yy/c1NeltbSDrk1tItvvq9VymKIvXBrwxy/8JP3TX7xZnGJDMnjnH4/hNgo5JFIC9KUi9r"
            @"MFFUTrS8R4cpmuZo7jENW3FuCZPTCeMbBZGhBMGHkoJRjcErK3kIVwplIYQSZZGF4lx/03cWNoYnX76wcrrt3kRcxFYRzliYDkjXwtQI/aiqqyM5"
            @"vSBaEXu+h99ekFhEK8OSWJiOhGNWZDpxcrpmmY4NJUAussxN17jzjhaNcUu4vczg1S5hPce2FXvPm8T3fgY7fgAztoJdBtPzoIaQp3hjS8+hYKta"
            @"11SoeTUVf5QfCU8GkAIVwecp7fFxTp68l5ffujBfg2N7lStFIBItwWmRO/3qS6+eeffyu6c/9ulP87EffopjJ+/l3o88Tm9jk+WbS/TXNrh89izf"
            @"eesiW/3+s3XnntCg2T1jrS8+edcRmpPjzN1/LyaulTPXTgctyslRKXFTXo6Q5miaE/ICzcuNep/22Lq8wfJyxjArEBUSl5D77VEtSwjaDaGkBPTe"
            @"r/pQJk7W6PRQ5OVtY9srOYmmPg3QLVQXC2VRVbKK/aC7J20qNQ5GbnmH70MkGdH+lXWutmMjJ5uRPN2I7XRS/WRihZqzRFEZB6/Od7n1pbeYrDla"
            @"dUezHVE7EBM3zlE7tkY0eRw/eQVt59hNj8kpVzkkLUlWKDMpsRa1HrUBdQExBSIWiqrNogY1ggZDkQQ+/vHH+Z3f/8qxCRcxXm8gIgy9Zy1P6WZF"
            @"JRwFrVp0ur++wR/+b7/33Ff+t99LJsc6T7anJ2l1OgBsb3ZZunUrHQ4Hr9Rd9IQROojhM8fv4uDBA0zfezftmekqe3cV11Vcth69L+N2lhHyjJAO"
            @"8WlKkWbUWjWGGyssXVnn6mLB9fUhq/1QAuCqUFLmpZoFDVsln5TEIwlZH1hBQMKu1xxpF3pkZdSVGp3qvYQ2TqSUBqwMunNjrZGpmpPHm06eHovl"
            @"yWmBww3DgekGZrzF1ZtbbPUyVrYLti+uc8EZJuqO6XbE4YmEucmEA5FBbq0zvP4tmkc/g52cwI/3MCs5dljggyGkJR+aVkmVugyq2KpGCCGgoRrm"
            @"ayAEgziHMZClKacfe4TTJ09Qv73MwXaLiHLo3y8C7/Z6XOhukYewVZKnmaQTmaesQLa9xa3Nra2CkjhTIDZG2rG1J1GlXxTPPTIz9dQjd84xefwo"
            @"44cP7SRNVCRsxgoqZbMkFB7N8tLAWYZPh6Ce+NAk20s32Vgfsp1bAo5B3qc3yCsxxzL5s0ambJBpI+VtNKKdXHVe1aQh0N0j+z3S5y31gKVU3h5x"
            @"IugeVnsXKgB2xXqeOSPt2MrJupMnWxHPjMX21IlmxOc+fhcPfOwoSS3i3fMr3Lr5Nt1hQT8P1JxhGBtStPwIijFCZyyhMUgIgzOo/SzSOYx2FpGW"
            @"Ir0ck5fA7JCXW2diTMX4Vrpq0VCSjWjZwNhRgS6VlvBZzsSBGX78J5/muf/pXzMWR7RdOfTvZ562s3Sc4Xa/3zHGMAiBjbykHLTWEjk6iHSCVslY"
            @"tWJSqG4dqCVPffHDpzn2yGmaB2dwUYR1tpov6468i/qyjRoGKcVgiO8PKQYpPs2wdUN8aJKNl1+k2w90B8pgWJD7MqufaNRIw4BBkWGNmXYis0Ov"
            @"rzTrydNp4c+kw+xMJT6dea3q29KI2Shv3KdNtMMLqSOhxl0Gukg4mqCna0YeS4ye7sTu1B3jDR65s82J03PcXtzgB9+/wpnLq9zKlEEQ1AeyoDuM"
            @"r84FGgG2soA6ZfzDs7i7DEX/Im7iHqIDF2Hdw2BYxqXUlmuTkpbwGmMrbqeA0VD1nuNqy98gRisZrbJQH3a7PPnUJzn7lWcZC8rxAzMkcUR3kLK8"
            @"2aXtLCtxVPZqUbq+4OYw51p/UGKn9iycuwooVxQFf+GTH+HxT34MNz2FtRYTRRVRKKUrroxcMs7l+DTF9wfk/QHFcEgxHFK7a5yinrE5f4nMW9K8"
            @"YCsvGFYIjF5viAblrvEmWW+YLBb6eObM+d5g+GyuOi9I7GF1JDOwI1Gzj013l4p6h2GuqnOtM6WXsSJTTphzwqwR7bTj6Gcm6nFDgrK40ePF773L"
            @"C6/c4MzNHkuZspmHhcxrN5TrDM6UOrlYEepOmG7H3HWsQzTWonduFb9xg/rxH0VMn7C9VkpdDgPBl5R1WvE+7TQypMJUyR5GD2Uvi3dJ2TtM6Yy1"
            @"8UXGxhtvcffRu5g5fhdjY23acUSiVSKG0nAxibGMR5aaNaxV/Bkj+TrnLP1hvvX5xx/q/MWf+QnM+DhWyknSDlveyPd5D3lOSDP8MC2pjwYDsv6g"
            @"dMl4Jj9+lJ7eYuGFV1jvw3q/YKuaw27nnlRBC89nH72TX/7LP0TUSzl3bXVqIPYFY0yjCHq9FNJWX9azDHSPuHgYyWqr7Mp57SBYpNysL7NjSVQ0"
            @"9ciKhentrPjyYC2f3tGwMaWggldWvIYVEZLIyjHEkKnMDQPUfJX0GGGQB85f2GLpapfJ8YTmxDJm/Dk69z8Ok1fQ1QFmK8NlpYHVW4KRUoq4YnQL"
            @"IWBDwPpQxROtWMAVCR5CuU+TrW3wsR/7DFtn3ma4skb8odPEFiKhJCFxlpXNEkvdzws2slLTYKsIXOn1SiCBM/QHGZ/90H2dv/If/Dym3kBUsdZU"
            @"tAOhYvYNJYLE52jh8cOMMMzww/LGhixFVWkeaJI8cID07ddox47IeYwp5eeywlOEclwaEF587SpHpsZotprE1syJl7jwftEY2qpkgVLxey/V9T5v"
            @"LOwojusecSkbOcEYaZQiFEZEsKpkWdDzWZC3Uy9nh15fGRT6fOZ5O1e9rGL6BmkAXtF+SbWrE/XY0ah08bIs0OsVBBWGmZJ1A7I+T/v+j+HaTXx3"
            @"CdIMhkU5n/dK8LvZ42gXT7SEnYZ9X6iEgbUUGs37PZwJHHj4IRaef5l2mpGcPIU0Gki/S2QtNevoNOq0ajUiUw70C/XcygqcM2z3s/SJ+0+4/+JX"
            @"fwkX12BkWEBCGf/VlyC9kOf4YV7G1n5K0R+QD4blML8oqEUw/thR6p+cJh67RTNS7HqfQU/Zzj3dtBoWhBLVuDL0vHz2Bmfevc2WmOcyr2/nqvOK"
            @"DMoFL/GiYoPIYJdUTPYzpAv7Wo2qinVWdqVRS63DvoclH2SpCLpYwGIQNlSkj+LjyN2tZfdsVdG+gIuMuTOxZsKIUvhyySl4GOTKRi9nu1+gYokG"
            @"PRKzxdijP4aELTTbRooCKRQJpYE1aJmkhJ2MoaxbtSLEVr8z/x19UYywfXWBzqGDtB79EIvffoFkeZV47gimVsd5T63VoN5uE7sI4yEvCoahYL43"
            @"oNtL+fEnH3N/46/+ZcgLRMG5igR0dKgKRQuPZhk+zQhZicooBgOyfp+iyiGcBNqHW7Q+ez8hfwkGy9SO38XUfXdRW19j+3bKVlq65qFXsqCkQea7"
            @"yIsbBb87KPT5LOjbXlnxgdvVxCctFUp2WWz2iPzxXsGY0R2wVR3otQQ0dr3qhg+6obChQl+tZEakLaK25GpQGRXMTuSgMzLrnBwEmaDyXj5APwts"
            @"DgqGucf7kpPJ2phkY4H6dJPGyY+hw9uoz8oZqA9IUTZeQygnGzsf6is7hhKaM6LWHbXarCEfDFh/601m7r2Hzid+iIXXzzI4+xbWB6LI4VyMi5MS"
            @"/xxgO02ZX11lod/nL//sM/zyn/9z9FaWcUaIkrg8SKGMreoDWpRwW83SMnkaDCkGVWY8HFLkKVaERsvSeeokoX6Lwbeep7jSJ7u6QjQ7x/QDd9I/"
            @"c52bK0P6XhlUC0FZ0Et50Et54LJHb3tlSVUGWtq+G2BDK3Kx0mHJvkRwV6FT9qmbl55H95BC7p8u+FEzQyqt3XK8pBgxHWuYriRUfYUrmygB1Eqv"
            @"KtJtRcidWCH2gcOzbZrmKjJxhPjgMfz2EhIKJCgmaOX6dqE3QUOpLRR86bJDdYLCiPy7bPpba+neXGLtzJu0piY58PTTDOst1t6dZ/36DbbXNuht"
            @"bLG2us6NtVVuDgeM33OMX/m//BIfufcEN868Qa3ZpN5olm1RX86cKYpSQyFL8emAkGYUg7R0w4OMIhsSihyL0Kgb2o8eIXlkjO3vPsvW5R7bt3OG"
            @"yylrb7zL+vwakQqDnudWN6NfBPo+kHk9XwSuF0Gve2VFYaBINtI1COhAef9gYO/t3aluZZdMzO1wCeqIi4rdepJRR0S7Oxp/ZWsv8RpWciQOQbre"
            @"hJVyUcmsZGi7FGdg2kggLYQsGNTDfR+d5dD9YyyfuU339r9h9ud/leTEg2Th9eq9ZkQSCFsB0tK9a1Y1CLwiRcBHEbaIsD7gQgmXMXlJ6duYnuHW"
            @"rdtc++pXGbtnnkMfeYKDj56mu3CTzcUF+murRCFwbLzDwwemmZ4YY+PiBS599wdMHz9R7vIOB6XLLzVcqjrWE4qMkOWEwlOkOSHLytgbFGegnhja"
            @"x6epf+wo6fw3CWt9NtYLeoMc72E79aytb9AtwAfhUDNhIy1GQh3JiNerGtKkqqXcjNeyFGJfMiU7LOm6Xzx1p8khRkq+5ZHOgZpK0brkeiwZectt"
            @"P1d1UxolJxINMZJUCp0DEZwqaVHoda+6VB2NcSckzgh1a7j3yBgPPHmCc9+5xsattEym1i/Quv9RoqlDhGy1HDL7gPFl8kKo2GV8pU0QPMF7QvX/"
            @"Q/BoUbpP1VDyNvvAxu1lhrdv0z3/DvnqbZJGg7GZaSbnZpk8OEPDCIP5d7n0zW+wdu06B46foDbWKQ1WlMb0eVHe0mGGHwzJ05R8mJIPhxRpSsgL"
            @"fPA4B7WapXXnQdpPf5ibr/wpq999gyx3pIOCzW3P8mbG9bUhi72M65spVzb6I9Y4NrNAGrhUBFkMhA1V+tXN7Sv0Awzeq22rVYlopGSc3SHIF9nH"
            @"nVByP0pFDYhUy0fsVQKzRqWBKNaUitDOmkMmhIbzOltL7CNF4LpXWapOXyaqiRhxVjhYs4bJuiMEz+U3FululpvmaixJPkS689RPPYodnyHk66gW"
            @"CAEbPCaM4K9VMlOUiMgQAsGHHUOXf3qCBuJGA2MM/c0tBt0e20u32Lp8kY0L51h7+02WX3+Dm2+8we2rV3D1OgfvuZu42cRnaTmpygt8VlBU9Ws+"
            @"TPFZik/LxoTmedXEKLAOkprQPDzBxI9/lHfPPs+lr3yd21vC2q0eY3dO0D48xttnb3G9V4LI19KCzSxwa5izlpWwmgK5XoLedMkjFYMO21U1Mtgn"
            @"kiy7TLq7DYvKhntpWbUiGdsRiKpeYaTpI0hcLWU3jNGGMaYTG7m7nvuPPnyk+Ruf/7EP/UjaKx69cXv7X4oRB3gREmOoG6HjRO6cbMbUYks/9RRV"
            @"ozzzJftpLY5pRwXF7XeI5u4mOXwM6CI2IKYUUTahKGNvoLypo5uroTR4CPjKKBQlfCdu1IlbdUIIZGlBVniyLGM4TClUiVptJu+4g8k75jDGUqRD"
            @"NPP4PKPICnyW4YcZeTqsYm2Kz1PwRdk1M4qNpDTs0Snan3qQM89/nVd/+49YGRiWN1O2skC6MaTYTinEsrA5ZDML9HJlqwgMPAyLsDDI/bfrLnqy"
            @"EblPbQ7zfylS1mmq9Cu23TRUWfKu0Ly8p9XInvp2D/cjldImpmLd1j1SJmVDPVHR1InMRkGPHYz1n3z+R+7rPPLYCb7xzXNcvLLyrFjiwoeFEVXv"
            @"aAE4ckI/ywihoBXZnbGdGEfwERihtx4wfp0hv4X7zDMkJx+nqJ+lqC0TahGSDJHVHOkG8jSQ5b7KqD1qDCHPMVFMMBZvDcaWUyNjLGMz09TbLfLB"
            @"gCIvQIQoTojrCcYJxTAt3b/6Xc3Aap0T76tQkJcJG4q1ZQZqE4uNoX3PHPGHjvPis3/Ma3/yAlsa0c/6aCjLj+WtjLrrE0RInMEA/dwzyAPDXOdz"
            @"1fkCWVxLs39YbtDbY1nqzwehK9Ym6kM2EqDebc4JulffXnfxb/tVUiuhxrBPKGqXDUVFCSpdKzKFwoNz7d/6i3/ucfIs51/862/z1vWtLw2tecXD"
            @"ShV/y81uI4mzMhtKggZMUIZeMVnJ3tJJlLHpJhvdnDDMcdKkNfDo8FvI3Mdxxx6C5AaFu4pGhigaIi7DdgWTKkVWlKSc3oAvCHkG1uIr5S+VClAn"
            @"gjWCa9YrmwWCKnmWoQNfxepR/eZh1MsuG8dVclkqXTsLUc0RNWKisQat+4+SzrT43u/8Lm+8cJaVwrE+SNnOytBhjWGZnJo1xKZ8podbCX2vrA2H"
            @"qYeVQiq9Puh6rys1sY/9xCdOfenC1RucubJ5WmIbj+bF7xOrrm6rAYKa9ynXV+LIOlLM3c8jV62YVEK8mS/CysR0h++/+i7f+v67z/UwzxbOLuZe"
            @"5wOmawhtW2m+imhcBFksDHO5Kk7LYXzLKQcnEkKmXL6yznjDoZ0a070Cd2cTd7iB+ktQD5i5SVznQ8jYNXx8C4n72K2CqFuQdj1mqBRF6aZ9yAmh"
            @"NKZWlPZBZAcEoBXcNoRQkWJTAeNDxUc1AsZTaQPtGtU6g40F23BE7YTGnQeI7j3K7VsL/OCf/RbvXr7FcmFZ7WVspZ7twpN7RSgJxKDc4qtZYSsr"
            @"RScbsU3yzLfVa6oqmfe6Akrqi7OLN5f5wo99hEOvnDvz3BvXnw5iukF1Vd9HrGwqxNhIsXwv5/JOKWTew48v+5uWJeyla62Z+vor10+j4Gp21mtY"
            @"Db5iUymFlLMRLDaodr3X1VyYjwzHNEC7Jvz8Lz3FyrtXeeXFq1gbUVQPfvzuFq1TDcS2QOcIa+9AyNC1Q2hykOiBe/CLaxQ3lnDxoGT/3/a4rBRi"
            @"8UXZs/W+isvsbfLLzl6S0d31lHK7oZw8jdTOTMWmZ6xgneCSUnfXNRxueozaiVnSmnLxm1/jwvNvcHMrYymDle2Ubhbo5p5BUbaUfChHgqZKdGpW"
            @"qEflJoEzEBk5NvS8MhKD8sqKsdJ59fLtv7S+/vxv/swzn+D2Zvrsi5eXBSt7pTerXbWwj2W3nMu/ByC37zCosF9HbBeB79HV4ExXICl8WBypQAok"
            @"RqUtRmIIeGRVgiSF0QWrTIE5NtFwHJ/tcP1cCfayiaVeK5le7zje5sAnxiisYIc1/O13YX2NfNWz9dolfGGIT52geeIeoofuJtzuYpfWiDb7hF5O"
            @"MfD4YcAPQwV4LyGnhJGIllQscbtiS6U8eCjffzXNEiuINaXKiqWMq80INzmOPTxF7cGDDFfeZeF3vsHN+TXWU1jPYHtYUIRykyLzgWEI5EFWcq/z"
            @"RWBR0UyQWCCp5+GJVmQ6vqI0jyzHisDiaEabe523kZk6v95/8p/8L3/6y+qiTAxx0HIhXnfkGGUHeD7qJ4vsFRnaZ9zdcdHutgE747Cq+9QVNBYl"
            @"UyQtO1el4pQajRElCFsECKZEyguSOCtYK9xcGXD1xgXiJKJdd9TiiHvvafPAM9PEc02keR/5wmXS8zcYrio33tygu5qTxEJz9U2aF99l/OET1Gbv"
            @"wh26A7PpyW6uYTe7mF5KNPSEoUeLqjYulODLj1FbtNo+Kw+wMWAqXXhbErqIc5jEEXeaRAfGsDMdZNISHfHgXyexmzQmI8yNhO20S3dYMPCeej3m"
            @"iU8/zh987SU2uulKFsL5IrA4QjOWtINkQ8/Lg8I/XovMY2VypLE1TBmVthaaemWlKHRRxMTLuf5XIU27Xsh2uofyHgEL3RU0HimU7O1iud0E2+xT"
            @"YdV9wXsE4ZAMNNtTKycj2oVqnSEr1xskLUso2j4EVrYzuoOCxBnq4hEj1GI4+dQczYdPQfIUoXeF/NI32ZgvuHx+g4UbfTKv1BPLWDNishiiehH3"
            @"1iXGHztC62MPE588SrEOYb1HWOvC5hC/PUCHJfKQoprkqO6wXQqh3GqUknBarcPUYqRZw7Rr2PE6hVW2NzbYfusicbbCoR/qgBhss8bMDx3i+uVt"
            @"mpGlUChU6PVTXnjxLJn3JXVQkDTAVjke1dWg2tVAmovOp56zQ68vx1ZOlb3xsndvhLaGkkBbqVZETCXPxp7QKiMdqMrQKruDg5GnlTJ5dLzPU8ue"
            @"4Ly7db9XNUx1pHNvUNHMENrV6UmVEO+0t5SVoZepoNpJC09cBIpgaSeG6ek6jckImr8Icpj82m+xeiXjrXNbXHq3y+Z2jg9QrxnGhgV5UPJQyotP"
            @"2z5m8BZEddyRSbLIo+MJPm2jg3GcRJAVMMyr/d8yiWLUoHEGiS3UYtQq3mf4YY/+2iobZ26ytbBMb3kTciUyjnQzZfbRcYIZkhxocPjDE9xa7jPr"
            @"E7aXPUUhLKxskSkIJim9WKnBF9BuULZUJQtacjbmQecjr2edyKwS0hFhmDG0g6c7csPlndMKzLCnkaGyv63MXqk3RVUwRva75f2Vku7yVejOPLhi"
            @"fNld1BbVRJESyK60KyWtxMNKrlxRr1nhmXKG2TxoJzJCHDsKXzDM23QG8/Qv/XPWX7/C62e3OHN+nY1ewTArMch1b8h8ickaDj2dqQ5uMqHYDhjb"
            @"J6RbZGfWkCDcupLS6xsaB8dIOk2SdkLSrGFbjvjOGcREUBSEbEhI+/SubdC/scpwpUt3tct2N6O7XZCrIdPy33OasnI2J809h+9qkW0FDj8wxsb1"
            @"HuHtddb6EWuDfqkNFJQQtOtDWNVAZpB2Yt1Dw+Bf8bBaaeJmqpp6z4oVnTZCe0TSWfaEict8QfdKFVfIi/3edCRH8meJ5Lq9cbX8KTMirMXoroF9"
            @"VRqZHS2EEnFXCh5VIybDFAIeVggwDPqyNUw7dNZamRYnn0limzgj5FHC5kbE4pf+n/SXN7l22/PahTWWN8ppSeEVZ4SmLzcMIldAgNZUAgNPnnqi"
            @"lqN/uc/25RwNcOHtTdJhTuvKKklsaHciOu2IxpilVYyVnAFpwPcKikFg88aAhfke3YGnmylpgGHuyYocrGGrV/6Kjciw/sY6p1M4eKBGzcB9zxzF"
            @"tRqsffsaV9eHdLOSXr9QytpVpRugK6rxqP5XKXmiFLIcrnhltUw6q6V3JQ2i3R2J+V311D3m030XTnU3ydqrNVRBWz9ApUZ2d1R3+tBVIf6e8VK8"
            @"97R4WFXItAjZiJTSmZJ6wRJW2ol7OolN2ZNtt3j+919i6eYW3Vy4vTFktZeznRUUoWyBJtag6pkaa0FkERNoNB3ZrRTNPUXiuHlmg43llG7fc26x"
            @"hzVCve+pJZaJIUylhmm1NG96Qq8gzwK9zZzBIOCDYXGjYKWbsZ158qAMfbnF7owQVNhOC2qRsNQr2Dhb8MiJSQ5u97n70Q/x0F/+HNcv/UMO3B6w"
            @"lpZzay+6MuKB8uiK92FFIRMjcdX921H38tD1ZTdv54ruxUiV5dr+JEr2qujuSKp+8H/u/Z8Ku4GZfRv3+/qW1RvISp5B0oDsQj4hFSUxhrYXVlHB"
            @"CbON2OCsMtZpcv6tJW6tdelmytYgp5eFShlrpImj5CEAlqWNbYqB5fTjM/gssHypR61hyYYp717ughjml/pcW+vjrMXZUgV0shuRZx5jlNaCpbue"
            @"0Rt6Nrs5CEwfbJErbKaezbRgUBk4rWrUZi1ma+hZ73uS2HK7O2S9V3DP4Sab//YFHvtLNe56/BTtt75PLXZsZPlWEVgMmK6nNLKISQKhW8q4laEs"
            @"lMqa+xoP7+kf7bmhMrLhvix3xyKi7xne/5nG1X3nQ/f8bTRY0D2ta9VASehc3vawq1EUWymhmD7oihHasTUnEYiimJurA5Y3ewwKpZd60kIZFrq1"
            @"UxeKxBadjp1MWxGWt4ccmhzn0Z/4EKuvXaS7kTExnXBjacC7twbMHJrg5tYWt3o5xnocEFlDmgfGGo7+oGBlecj1G302h55hEUhiy9iM0unEFLf7"
            @"DHNlPfWEAHlQPLA+6BMCDAuPHZRggYWNjJXtjKXVAWsrf8iRe2epNxPsaooYSYqgi0HL1RBU8bASlK4aTQmjCkOyfcFU3zME2CNHsGO8nbUfYX+z"
            @"sRrPquxb31TVD7q5vMfAVWqNYsLuFv5eATndkUUnDaMhfxmvE6syZay0nZVZRVjvZSznA4Ze6WeBtNCFQRpeKIIsIKVEujPMqZXMBNMeBhKP0GxE"
            @"zH/3Iu9e20BFaW5mvHurx42VAeduDVjuZ2zniua+pBA2SjMy5SjQWVaGwvztPr1QPodmWpALHD5Y59y1LYqeMshLt+xDCaEea9VZ3erTzUqeilFL"
            @"Nr9dvv9b3VscvrCBi2OsgciSWGEq9XrGU9Ic+KAr1ZplWqEYs/cmQGJk36hudyav+4y4D32h702V5X2h1X2AqPn7PjPy81qhPMsF6T05c0kOlu0e"
            @"xJIi1qi2rZEpa8sVw2ER8P1AEZRhrgtprmeHub6ceT1fzSkTi04F1a4qKQTI5SRWkq1uxrd+cJOBLwcdhVeWN1O6Q88wD2USprvqKsGVQ4HDdx+k"
            @"t9HnyvVlFrYz+lkgSQyuFRG3LIfvH+OOSytc2xA8yjAvQfbOwL0Hx1jvpvTz4twecHicDny7WBmc2m7HLG3n1GsRceyQfoGzOqc5WXmDy3XMgO66"
            @"5Q/2oPu8pMoeY4+U+fbo8On78Dayxw4jFI38e27uHtewN1MLo1JIdQ9QWxhtd2vQbNQJK2MOyQgu0i/0jKjGeaFXiqALw5xX0kLPVG85EaNxEOlq"
            @"IFM0U08WAt1aXZ5c7qVsDs0OZmpYKKu9fAQwo/C7dYKpmOjW+4HOXXdwpTvP1Y0BG7mSFYG2RHTahgMP3MOhTzzD41v/hsv/9iVubkGhShECXoWX"
            @"37xeAr+N4H1YKYIuVklROij884M8/ZWxhiXJfDkKtOXCuhHaIdD1sFrWtrs3TPfTjuwTM9aqsSKVt9w7ztvrbj/4WMi++6ka/j3G1dFASUdUCuxt"
            @"bcgeq4ddbFW5mlnFaGMlESH2QVdTr2cyzznV0mBZwfnMU94IBQtTJtBGFC8SV0crVhNSME+uDYpS9a7q0vTSQDctcdGF6pYPrIqRuDwkxD5oZ2kI"
            @"f/QHLxGCspwp26nHKDQSpRYJzQMzmM5THHniLU586yxvLWWVcBQUqmlAut7rShF0sQgsFoHFEKSLgAZNVwZhMQ36xVoUTjkrjHrGxmhbRJKq7bgP"
            @"KP4BvaI9/18oZz27z1N3RCnes2a7JyTuib77DoD7s2+trcZhsFfCcfSWQkUItpcRLuxNAUdSn0rmAysl9rbcTCuUhdxzxcNKBZtNRuWDVhp2Ix7K"
            @"mJJYbmvoq7WP8t/pDkOaej0TKJMXFTITtG1FpgiKF6YVPXZhqU/iYHNQ0M88RqCthvVt5cZ3XmD8vi+zdfFVDI56Yii2AqkvqYCKEBa915UyfrJa"
            @"ssqUIsbB61auzOder9QifSx2clIMSTkIKBfX1e/G1/03dWQ42ekPawW72MVCldfm/YaVfV3C0dc/qKJ1+/uKu5u7o8WunX+YvdnyLnZWR2rLO9wS"
            @"I2HH8nTnMD/Sut8p4IPMV+uHCJKV6D/NPKwKxAba5T4OxNacTAtdyYvQruRdyb2u9LPwjYBulesW0kUVY6RdCAsimgj+iveysjrIHq9ZoV9l5Qhs"
            @"DDwrg8Clc2sceft7pNs5uVdcVCp75l6veNGVQln0VDRBQbpBQ7dQXQyhHIygkBdcyZX5WtDHrGV6RC0kqokIcRlrZRdJIbrHg+qe1rEQ9jzrnZJ0"
            @"NBB4T5DcJ4Ys7xNbHRnX7FpV3jMu2LtKVo0Uzc4/vTcm78HvyB6pbSXzqqvel8mIomkIkgUNO0mZlo2hilxlp81WZpUVRXA/D9+QUmqhLUKS5Xou"
            @"D1ypGvTdKonLJBAb0bYx0hZCUogsrPX8yWYsnawIFOXuVbox8J3b/YzLtyxHvnOeRDxbw1DmE8aQB1+xn7LoAyvBa1c1VOIR0g2ie/iglOClq5Da"
            @"wDQoQbU0/h5fp+8Vuq2y4d31mHJPuSR8GzXC98Ce2GWB2wurGblgeY/L3imF9hbNe0+DyHsMvSc13+cFVNiL4imVPCua37DjblEEH8oJtgkVpErI"
            @"9jdISilRQWNQiiCLIdeuIImRckBRzkp1UZRkRGRZ1XuxUe2YQHvUPdtO/R8ENZ/RQOaVFVWyfqZPrnQL6nHO62/c5shMg9vdnLwow1DmS17FUMXy"
            @"cglLys5SdfNKw5bQIq+aei8rTpndWd4SunsriL3GlIqzYtR52m3pVp5R9q0G7EOjjmbT77XXrpF39ZDd3iGB7u2ACO/JzqS6abrrGpB9rbBRv7Ps"
            @"L+veygylGqTLKLaUfzclgWU22g4fzTkVUiO0M6/nR7xYxpTyK7nX+RGIe2/WaJS2CllQ3areX5J5OT9qe43iPllgrVc8ac0QY4T1rZzlrZTeMKcI"
            @"nsLrYh50noqDujJmyfdUzldTQWJFs2qXB1DyIFcM0h5l1LpTNeiepsQejGrVOgxUrLmqe7TJpQSSVxCMUQI1MvD781/dYQAa+VP33pMxgmxU56sE"
            @"PVcvFio1bH1vFv4ef68qCKZ6W7uuB1uRmuj+HqpUjGejjH6kyx4oCUCMlFyU4jUOSrdQFvfvvZRbEBrIjJF2+dZ11xMUO94jVSUrQli0vWwqhHBq"
            @"mHnWtlKGqaf7/6/r2rGjiIFgldYPIjJnXIBrcBXu6gsQsZFJyOwEv4fZmVUXgdRSt2ZwvN6d0ac/VdXdt4rd8EvQrRpfoscawZ6x5a3opZz+7mo6"
            @"tGq98UjXjdWFa60jfnHenIFsj2E0A89uxyHmi4uNY940Eao1muPptQcUekMia64w4S8tCZN/IifiwU9E7tjmyVbfXAhvKmw3rpn1F0FbVgPyA4Vt"
            @"CMUCwdGCtwaIeGGVB20F9dtu9vnvvS3xn93Qqukubms2P7yj96IsI4eajUxNee2tv1OSP4SzzhJc6XB/PbLh9LMRMBq3NvpiZOhxdAqIJ0ZW4UQ7"
            @"6ba9piR6fklMkPTfpHo+FuG4pRZ01AOyHmGPf6rERhBWW4c0tx7+fBP+1AZh04U3GW5NBdn6RnTKbfOWA/6b77ueLsUeDfx6V/1SCnGr5fcmu4rN"
            @"Z3oq19QRoQd4QPqN8waSE3lXwH15AjtA3nPTxnrK18ZzH/kQ7Bg8rT6YybSAc1ce5lESwEsfmqhQAB2+mFGRsSbmShufNj210FGQ8iQQs/vjXLgW"
            @"88SU8OuoRKhVm4peFaQppUfhc7ROe4Ed/Ple8WT38rbBrhfyca96ft/1tFX9uNcpJx1+TAmPHaWT4x0HcZ43YQUect+vGbCKmoM7xs+UYDl5KLBW"
            @"eqYZlBHAQ2tebUGjo8W8Dg4oMQSp2waCQkMM1GEHooMRd4Plb2RBLuIZgE7QNSpXuiX74PAdCOuSFIf0IGxGvpJKz72ZrqgFBr3tVc+F9qkaXm93"
            @"fd8qrt7dRgxnuT+HBW8ZAf2ZSTLFKJ6+NG0TTk3o6glba64SbjqjLZ4WjwFvHmVAHmBdQkPKHD/gfyhm5hXPEmgttaQLoczIZAhRKFIi+aGFhFyR"
            @"mHDTY0wvzLSt+MHSHGXjEWcpxENvFE7oIwDsFc+tZBaTzVa0NzznztICMlXktWkvXfzfN3zdXET2XD6agIfgaQ5zns2/x+QP5cyk69xmRJyACT9h"
            @"0gnbi8EvUjgEU1woYs+/ot9oprW1AzyS1XM8N0Ijm0KOuz/lJc0CyM6ev32159JeUWWDo56ZB3sRevXDgLNbdgrEH2DBlYQvi3sphRn3W2Wr4a+E"
            @"FVcDSaboPqRIM8BrQd8/CnoxgyT3MssAAAAASUVORK5CYII=";
            break;
        case 2: encoded =
            
            @"iVBORw0KGgoAAAANSUhEUgAAAJAAAACQCAYAAADnRuK4AADSaUlEQVR42lS9d5RkV3X9/7n3xcpVncPkrJxQAokkiSxyzuYLGAwYk4zJyRhsg2"
            @"1yNDkIBEggEKAACigzI81ImhlN7AmdqyuHl+69vz9eTeOf1qrVvSR1d9V7556zz977nCeMMezfv5+JiQn63R7aaIrFEtWVKlNTUxw/doz16zdw"
            @"+Mhh1q5dS7VapVIp0+v1AUGlUiJJFPV6nYmJCWaOHqUyNIRt2VSry6zbsIEjhw6zfv16Zo7NMDE+Tq/Xx3EdpBDEcYzreXR7PSqlEv1+QJLEeL"
            @"5Pr9fD932UUgjAcV263S7lcpnq8jKVSoVWu00mk8EYg9Ea27YJwhDHtgnDkGKpRL1eZ3x8nPnZOSanppg5NsPmzZuZPTlLuVImSRKiKCTjZ1ha"
            @"WmLTpo3ML9cZ9TQrrYChiWnmTs4wOTXN/MIC02vWMD97konxCRaXlihXKvR7fWzbxrZtOp0OI6MjLC4usnbtWrTWHD9xgumpKU6cOMH69euZn5"
            @"9neGiIWq1GvlAgSRKEEAgEQRjg+z5SCBKlsCyLKIywHRvLspBSEscxjuMQxTGObdNptxkaHmZ5cYnK8BDNRpOh4WGazQae5+G7HsdPnGDN2jWE"
            @"QYi0JFEUEUURo6OjLC8vMzo6yuzJk6xfv4GZmaPp12MzrFm7hka9QT6fJ4oiVKIoV8q4ros4fPgww8PDtJpNXNdDSEGSJGSzWZqNBkPDw6zUap"
            @"RLJdrtNrl8jn6vj+/7hGGI1hopJeVymcXFRSrlCkHQRxvwPY9ur0upWKLZbOJnfOIoQkiJbdtopVc/SCaTIQxDbMsiThJs28ZxHIIgwHEcjNIo"
            @"o/E8j263Sz6fo9VKg0cpheM4aK0HwZZ+Bt/3SBKF6zp0Oh1KpRIr1RUqw0NUl5YpV8oorRFC4Ng23V6frO/RiDWVpaOfc5dvfo8+7Sy65nzh5Y"
            @"q0W3XKlSFazSa5fJ5Op0M+lyOKIizbRmuN1hrHcej1epRKJarLy9iOQ6lUotVqUalUWF5eplwu0261KBQK9Ho9bMdFCNBKYTsOSZLg2A5xEgNg"
            @"WRZCCACiKEqvn9ZYlkUyuF79Xp9cLkuv1yeXz9Hr9PAyPmEYYJSmMjREq93CsiyUUmitcV2XJElwHYdOt8vQIKgrlQrNZpNisUijkQbPqXtx6r"
            @"5EUYRoNBq0221sy0Ibg2PbGCAMAjzPQxsDBizbIgxCfN8nCAL8TBpArusCIKWk3+9jWzbSEghpkUQx2ujVU6OVSr9qjTYG23FQgw9/6qIkcYLB"
            @"kM/naTabqxfY8zziOAYDnpdmomw2R6ISHNsmjhMAlEoDBiHQSmNJSRRHqz8vpRwEl08QhgjAsm0QAssYEi+D2P/ouwtLP/p85pmvDTHu/tb83n"
            @"NC/2kCYYijGM/3CPp9PN8nCkNs28GY9CBpDCpROLaDMgphBIn6Pwein2aqoB+QyWbRRiMMxEmSXidLYoxZvWa9Xo9CoUCn1aZQLNJoNshms4Rh"
            @"uHroXM8jjiJc1yUMAqSQJErh2DZREuO5HsZolNZYtk0UhmBA2ha2ZZEohTAGhEDK9EA7jgOA4zjEcYzRZrUyWFISRlGaJTudDpa00FqDASElKk"
            @"kQQgKQxDGu5xJHEdlcliAIyOVzNJtNstksSZJgjKHZbJLL5sAYbMum3+1iDVJ6Mri5Qkos20ZImb6xMMJ1XIJ+HykktpV+4KGhIarVKoVCgUaj"
            @"QSaTIY7SUmdZFmEYksvl0VohRZrOT51+KQRhGKUlDTM43U6aJaw00GzbRgiBZVkgBHEYQZygfA9z4ODz8wd/8Hnncfehk197xpl+VmGigIxuNw"
            @"IHKcVqEBit04wQRyht0gBXBiklSitsaeO6DtlsFq01URghhETpNJMa0rJrBEgpMEajk8FBSBLag6BpNhrk8nmWq8sUCgWCXp98Pk+v18N1XeIg"
            @"TMtZFGG0wRiDAJJBUKYZOr2HKk5AGywpcWwbrQ3W4D25rku/18P3fMIgSAMyDNP3ajSemwZqkiRIKdNSqJQCweCm2iRJAkLgDtJUJpul1WqRy+"
            @"UGp6CQfrB8gX6/jxCCOIyplCu02y2yudwgY6SpUyDwPG8Vx+hEYQ2yUDaXpdvtksvlUEphOzajIyl2KJfLNBoNKpUK/X4fx7UJ+n0MBiEliUrQ"
            @"SqOVSrOkSLNkYjSZbIYwSP+267lpicxmieMIIcC2HXr9PhnfT9O/FCjfRRydvSy/5zvX2Wfei5z/K6Z2N0bX32RsGBqPsdT9TSlctE5xiTIG27"
            @"axpIVlyTTrDTKuThRaKYIgPe1AGmCAGfyc0QYDxFGM7ThImf4Oy7Lo9wMKhTz1Wo1iqUStXmN0dJRWs0WpUqbZapHJZul30wMSBgG+569WA6TA"
            @"y/gYrXFsm3a7je/5qCTBsi2kbRFHEVIIgqBPNpOl2+tSLJXodDuUKxUa9Tqe69Ee/K0wSg+A1pooitK/VSqViON4tVzpwR+M4pjK0BDtdptisU"
            @"htpUaxXKK2UiOXyxKFAa7jgIFMNgMCyuUyKysr+JkMSRJTyKdZwhiDJdPMIe30q2VZBEFINpslCEM83yMMghQcl8t02h0qlQrdToeM79OPYjzP"
            @"RWBSTKQ1SIiTOM1etg0GioXC6sUKozBNy6Rg3RhDNpej0+2Qz+ep1evkc1m056KPL05l7vv6nd4Zt2L3HgIbRG4SITd/AmNjrFlKlZ1FE9wd5P"
            @"OjRFGIJWSKC1xngOcspGWl1zPjE8URmVyWdruFFDLFgHFENpsliqLVcnoKhyitkQKiMKJcKdNudyjkCzTqdUZGRtIDNVShtlKjkMv9rYzGEZZl"
            @"0Ww2yWQzJEmC53n0uz2y2Sy9fp9sNkO/3yeTyWDJFE9JyyKKQorFEr1el1w2R61WY3homOrSMsNDw9RrdfKFAr1ul1wuS3oaBIVCgVw+h6zVah"
            @"QLRYJ+kII1adHv9ymVU8A5PDxMvV5neHSE+kqNoaEh2u0OmWyOOE5QWqG0JgpDqstVKkMV2s1TEZueLG00iUrwPH817UZhiOPYxEkavFEU4Xoe"
            @"+UKB6vIK5XI5xTm5HI1WiyISZWzwPPq9Lo7rAgJ3FacZsrks7XabUqlEt5/+HWMMXsan3+tRKBSp1+urQLZYKFBvtclom6FDP521Nv8evXCA+I"
            @"QFjRLJY4uo2ucN6gCmuxet7mN08m4v6t77Ky9Xodtpk8vnCfvpYdJJAiYN8FPlp1atpl1av4dt2WSz2RSLWRKlErKDw2e0SjMoLl4mQ7vZojJU"
            @"odVqUq5UqA+AbW2lRr6Qp9vrkclkVjOegRQ3Nppk/g/UaDTSLqzX65HL51LcNwDjRhv8QebJZNNrNz4+ztLSImMT46ysrDAxOUGz0cTPZOj1+n"
            @"iuh+M4NBoNpJSIfr9PvV5P66YQWNLC9VzqKzWGR0aoLi8zMTXJ4sIClcoQKysrjIyM0G61VttKrU0KGDW0Wi3GxsfpdDr/v5MmpSCKYzK+T6fT"
            @"JZ/P0+/302CK0y6sVquRy+WoDA0xPzdHIZ+n0e1SDoMR/8/fXBZTW2lueNJobsvWanNlAc+2kLaDVopsLkd1eZlSubyaNfvdHn42s9oR1VZWGB"
            @"oeZmlxiYnJceZm55gYm4Zff9pUT/6Y2qOz6BasGTEkiSbY9nzGTjtM7qyHEb0sLNtou4LOnE7Vests8exnrmksz5LLFuj2emSzGZJEEYQBlXKF"
            @"ldoKI0PDrNRWGB5kkFwuR7fTJZfP0el0yGT8AaCuEEddMp1Hljp6bE1+elPUrC5TGR5Os8LwMAtz84yOj9Ht9tKsHAY4AzwH0Ov1GKqcogbytF"
            @"otyuUyrVYrxUzdHrlcjiAIQKQAORxUgUajwcjoCEsLi4yOj7Ewv8DadWtX6ZKFxUVKpRIYMBgc26HVbiEWFxcxxqCUAiCbzRFHIZZts7y0xMTU"
            @"JO1mi3KlwtLiEuVKmaDfx/UGncigu7EsiyiKyGZzabobtH22ZWEEMAhQpfSgiwnIDNKq4zh0u930pvd6JImiVC5Rry5TnNqI9+P/MN75DyEqEO"
            @"9RNLPPwTvrOaJrSVTQoVIo0ep0KBTyNBpNcvncoDV1Uy4pm96kfD5Ho96gMjTEykqVsdFxVqor5N75chP37qXmOnRCRbWpsS5dx1M+8zpE7aWf"
            @"7/3pVe8pb94Dex2iozHJQeANv6T++CtEyYLl5RUyuSxKpfjOtix6vT6lcplarcbI6Ai1Wo1SsUj7VEkO+uSyOYIgwc94JJ0Db8ybP37LMQfpzp"
            @"xGd9ubhefqARYqUK1WGRkZodlokMmk3VuaRkDItERns9lBd5pmIM/z6HW75PNpJ5svpNSDJSRKKaRl4fserVabYqlIt9OhWCqxtLjE+Pg4jUZ9"
            @"cK1WKBWLqw2JECLl2AoFxNzcHEmc4Hruajud8igxhWKReq2WRnWjnpaGdgc/kyEI+qutsOukJcn13EEHolOwZtlEcdrumUHrblnWIOozhEGIm/"
            @"EIgzDtBI0ml82yuLBIqVzCz2epzVQpfe2lpvD2NnJ6GyzuJFlZR9i4gLjwnFBvvNBXnsRKYvr9gFwhPyiPzqATY/XinjqJpzJUr9MmMzJM9JcH"
            @"bh6+4aVXOkPLPHwb7NtyOs/9aBXPXg9TX2kFxw4Vl//744yaAzgbIS69meoVnxDFokez0SSby60eIsuyiOIY102DtzjoorK5HP1+H89NQbhtZ0"
            @"BILHPiiqy+4xZZ+wGWmoPJ9fRuWKFz3i9P01Mj+z0haHc65HN5YhWv0gKniNVT4NyyLMygfEZBiO26aJUgBx2273t0Ol28jE/8f9r4JE7wfI9o"
            @"QAu0BsniFNfVarc4hZNt26bf72OMJpvNpd36ieMnUjAsBVJIwgE3cqqO+r6fnp5SiSgMyeXz1Gt1yqUS/TBt9ZqNtKW37DSyU0iSAnLP9QijEM"
            @"d1sQetn+3YaSvregRhgOe4hAOuptvpkM8X6LZb2EMVsnfcb/Svr6bweI284sng1CFYwhgHtXwaYe1yemOXv4eNO/6LKBxwF2lAM0jttpMytYV8"
            @"nn63Rybr0w9C3GyWJIxxiyN4i98x/kOfZKV6BiNXL2H3d5P4T0FMvAfL3kf9oXHkA5+ieGmZ6siPhV9YQ21xnlw+h1Ea23Xo90MMBj+Tod8P8H"
            @"2Pfr+fZoQB4A3iGD9bwI5PXGgld92fk7dgOvcgey104VzE8mMEdyyQbP0h8ZUvFd3Fk5SHhmm1WoN22hDHKf1hMJhBh6eUSkuZYbUhSaGDHHB0"
            @"Aa7rEIQpl4eBMArT5gMGRGRa4sIwBfrNVhPf80mSGD+TIY7jVdB/ijAVJ0+eJJvLEgURcRRhuy5gMNqQy+VotZrkcnlanRaFfMpB5Ap5mvVG2v"
            @"J12vh+liSJkLaFFCkR1u/30zcThAPEL1c/YBLHuP+3jPX6FIoF6rUa2WwuxUSuQ+RkyX7hg0bVv0y/BsNPnMB95RPB2QK9wxhTxXQ30LlumWTq"
            @"xYhnvFhYYY84SYG9MAbbstKDkMvT15pcpUIUx3gGosVFhNXekS2VjshMPnLU942o/gDZfxBtwBp/Kqb8L+jwTiyvjIk3oKIWwn+2t7KURI5jE2"
            @"obt5gniUKIQnQUYrTGdT3COMLPZOh0OxRyeZqdDqNeBnHw+0auP4qb2YMhQYgiRg5h2l349W9Ri4b+5MsIXvJN4bsJnXZa3nv9PnGcdre9fj9t"
            @"1weUgJDyb9hvAC3CICSby9Lrpk1HGISr/JMUKYjX2uANAt33fYJ+n0KhQLvdITdIIs6ADxIGHDftvDUaowy24ziE/TDlYVwHBmXGSEOrlfI6UR"
            @"SRy+bo9ft4rkO7lXIR9VqdXD5HFKUShIoVsYmR0lplSU+1uKdOiBRi9cO5vkcURqtAMp/Pr54QJQws1TDHbsMek0RdaNy/RHabReH8CXRjkeSW"
            @"3XQf/iv6sSbm2U/Cch1UO0YAQmnwPHqWRW54mP7sSUrV2r9F1/3iA96hx8hGNbwNMZlnlEkmr0YKF7Pvh8j4QXTewSorFu+oUzj/UbJr8uioB3"
            @"aAzDz1WVCMKpPtESu8ZznY9RjxjIMYP62VrNlYkmNjWLkcUa+LIwVBt0vG9Qh6PbKVMo37H/rm0Gc/jHy8JhnfgNgxgbjgEqzSs0Nx/J1eeMhg"
            @"5SzkkXuQMyff2N00+u20S40xSpPNZAjDaJXkswdkYBSk5GK328VxHJRSZDIpIWg7Dkkcpy3+gM4QFkjLwrIFQZAqCkopXC8tdY7rEEUxruutyh"
            @"6n5BMhJMYMsl6j0aDZaKQp0Rg83yeJY5TRGK3xfD8FuIUCvX4fo3WakdpNcvlT/EAOlSiCIMD1XLRSWJadvlEpUrIxitDapNKHWKUTUEqlnEWv"
            @"h2XbJErh2TYU8zg33W28O1+Ct6XL8r2GP+236JyUPOsfEqa3JdR+DWEA+XgN4b/+8RwzPb5HItHZLDYQHzo05Ty4c9a78w7Eo3uxV+YRRR8zXi"
            @"YZySKny3SsDLk3XIlT/xpy/n5U0cbeKDh0q+b+/9rB5h0eZ/3n5WSmz8QkeZBnXIc444XxI7cY2bgXs3QMHl5ELIYkbYnJjKB3nE3/jLOX5Tnn"
            @"jvWzOTKeR9xs4NqSoK8o/tOLjVe4C5EBXQT377YTHT2N2d/eTr7fYvRM6DchWvd1Wi98iRiSUGu0Vjso13FSCcNP6Q8JWAMi8pQyYFkWAojiBM"
            @"exUzbaTu9JolJuzrbS8qW0wpLWQC1IAfIp2eUUB1QsFGh3OoNA04RhSLlcQi4sLFAoFFHmVB3vISyJ57qUBqr32Ogo8/PzFItFXNejUa+Ty+ZS"
            @"XFEo0O/2APAHGSWNVJXqOqckEpFS9cYY1IAKj6NUUe4PtK4wDMllswOtRiIO3AZPcDBb8xw/Kjm+N2ahEXLdN2D/j20i5ZFxQTz+Kpztp++JjE"
            @"A0GvCjH5nM//t/pvji58/m/v0TiN0PYHIOvdN3UPVLLCwELN+0n8P/+ms6RQen+h3EwfvRONg5w2N3+fz8LYpLxzez4Vkf4NDrforudRFyUwtV"
            @"+ha0kJnRG8PP3Yz6yG2o2+rENRuTLUJ3BefW68n/8ztHc699ucl/8P1G/Olm4yPpa5vs5ATBZU9FaFC2hxMI9n5lhuvffD23/qTO/fcLAtfBvt"
            @"xHzvyJYTfPSr1OsVQkGOCpfhAMsknaaeoBux1FEbY1YLgHbPEpYtIaBJcQMr0fBuI4Qpv0UIdRiJBi0LXl6ff6DA0ohFKpTKvVJp8vEAQhSiWU"
            @"K2Xq9Tpifn5+QCCm3dOpVKWSBHugvDYaDYaHh1lZrg6sByn7q4wmiWOyuRxa679pMEqtpljHtlfVdaNTusCyrVU6PwxDMr5Pq9Va5XDy+QJht0"
            @"3x0Y8Y7wkgbrqW+i8CHnhAcPey4TAOF270udhpccHLsySvu46kOflyec23rnF+9ydEtU0yPky0dTOW6yMf2I05eoJ6vUFjkPzawNRX3sCGqxZg"
            @"541oz8IuwLETDl/7Z3hiNeD0x1/ChrvuEY0PftKI41+l+KNfYJLzBCy9RtrHfhCfzBxJnvu2TfaDO0kABTA5gdm6FnXxOdj1Fvah/cgoIdkwgX"
            @"nh0+mc+/RzKnn/cq594pfNXUvsXcnxvb2SsU6XTWXYaME5V2msd+4gua1IbftnP194/OPfWz1xgqHhofQ6lUopl1ZI9TAp5UBEdkniZFUXQ7Da"
            @"3UohVoVUx3HQJsW5AIlKgXG/36dUKlOv1xgZGWFhfoHJydSyUimXabfa+JkMtpN26/lcDlGtVlfVVmBQ+6LVN2VJK22BOy1cJwVimUyGOI6Qlp"
            @"Uq7APlmIGiizEpkh+AsFN2BCkE2pgUJHupXuVnMyn/UCym9ohCSt1nikXy//1u44Z/Qb5rGKu7l4WvBXztvw2j59u87h+3Mk+G9Rc8FzafiXXL"
            @"11B/apKctBAUaew9TPvICcj4FHIZirakW2vS6gXMKcXQ51/PmVcto3f+DlGwkJZhYS7Dtz4d84RZKImITU+4jPJttwlhWXRf9lJjPyXCfcv/Fl"
            @"Enf2eSv1yO10HNnEvwnPdiHXwUs34NllJoaZG0erhBiH7yefCUC5DLM8gNAfIJFyA2PxUx833qtzdQxWEevf56fvfzJs/dIjnvTZr8iybRe7P0"
            @"fxzBx254+0Km/JWi5xBGMcViKtUUikWazeaAIEyF61OH3gwcFIZU2JVCrpYm13HSA+3YGGVQKhkA7IBiqcT83DxjY2PML8yzceNGlheXGB4ZYX"
            @"l5iVwulyIPIbBsi3arjTQmVW8RabsbR3+zPvh+qid1uh1saSERq3rOqi0ik0lVYGNQSiMRAwCXBsYpbuSUhQPAsRz6QT9td3tpWm612xRLJbqd"
            @"burxiWJ6f/cpEfQfj/q3BaJwhInnuTx1s+DSC6Hw2F42uxpr3TCuWyBeGCfZHeEcrOHcdh+VvYeYjmKW6k3uOrnAz08s8r9ByA2JovCfL+XMJy"
            @"+i7vkdVtbCxLAyk+V73zTkZg2ne7DZgGdAITBakfn6t0X4p4jolve3VPzI5cLrQW8v9obbcH773xzYvJ37ZmbZdWKJuUMnsJZW8Dt93BvuhHt3"
            @"IbsC0RlF+JMIe+hONn/wM4WnnM/Yvus5/7QWoxmLoW2awjPGCW/2Cb8qEC/9EvXS2FcquQyJ1hQK+UHmKaQNzsDW4bjuwF3wN4cAAmzbWoUPUR"
            @"zjuS5RGA2sNen/57re6n2sVqtMTU9RW6kyPT3NwvwChUKBWj0tY1ppBKQCbC/t1qx//Md/THkB0lrpD5B7sVCg0+6Qz+f+ZhsYlKK0FU8olko0"
            @"Go1VBjSTzQxU9dRDYjv2qnPuVKD+Xz9Op9OmUCjS7aYMaKvZJF8oEscxIkmgUiJ59su+Ygf1f7aWl7C2l7C6XSauHMEbbWL2z6Ord2KGJhClC5"
            @"B7HkM9epx4qUbLsblLSu4GHpOCowaOJ4on//urefKVDdR9v8cuS/pdydxBnxtvMbTvidhsayylGTcG59KLkC9+ySdEnCDyOawzz6f3yc8/OW7/"
            @"BVxw1lbQ3SXcMfCvevPug7+9Z+JwdZk5x2EB6DoOOSy844uYbRmE78M5z0UMTb6f2Y9/gT98EbUSkH2Ci5jTbLo8i7dio+/w6b3rq/vCpz/zYt"
            @"1qN6TW2K6bcmd+ikGzAwdDEscIy8ISAq0Vrvs3ZUAlGsu2OEUWneqyxAAznbIJOK5Ls15nbHSMRqPB6NgotVo9DbgopSJSj5ONUpokSZ0TQghE"
            @"u92m2+2uIvegH1AsFWnWGwyPDLNSXaFUqVBdWqJYKqbmo4Hdo93pMDQ0xNLSEkNDf6vPQb+fdlSDgNM6NXapOCZKEsrlCstLS5QqZWorNSYmJ1"
            @"heXKJYLtGs1RkaHSFwPdy5Wde/93uhvWEO+7RLECIgbi9hu3cgevcjZx1Y6tKfATl+LvrSF6P/usDBz/+Bm3YeYh5wpCQUUFWaF3/6lbzgymWS"
            @"h27GrkhqixazDzscaWuWrokZQ7EGwZQlsZWm9N8fwX3nJ8SAq0M/cLPp//wW+o98F3WOhf+0Cyg/dRuqV8LKrqe2v8K1z3wvnZlDjLk2RAnrgO"
            @"1TGyh96G04r7kQaT2A6dyBtft3sE+ifeB0RXBoA/YXFzDPOA38IcQDVZrbnoj3zx8UdcsmqxKCMEAIC9tOVf8kipG2tYp5xCn+rVBAJQppCZIk"
            @"tdHIARbyBgJzHCepLWXg10qdpj0QIlUkwtTi2+un9mOVqIH4nWBJazU5iIMHD1EqFTE6daz5vk+jXmdoZITlpSXGJyZYml9gbGKcRr1OPp+C6F"
            @"7Qp1KuUF2uMj4xzvLSMpWhyiptHw0ca1EcY6IYt1ggkIKcgVq1ythYGu2FfJ7FhUXWrlvHiZmjTG7dSqtWo3jjDca96ZuI80vosXXIHZtxLn7d"
            @"lVC4VfU/amznZmZ/eILwwYBNo4bO8YSVHtgXXYh77lOZPRCz+6d/Yeef72cOeNlHXspLLlsg3nMHzlqL5UWL3bdKylthzzU5zmpDO+rhS4dCLs"
            @"MOBMk//T32RRei/7obNk+TLCyl7sXlBuHiDdScZSpXXUL52S8k6R/EzrRZfGQjP7n6v2jOHOac7Wdy1utfyMRzNuD7f4EDv8SqhIiRUeq/bzB/"
            @"d8D2V2nEtIs+eSG8/U649DTCeh6yLm51mX7g4H3ysyxd8nhhJzFEEc7ATuzYNtKyUIMgCSybQiFLv7qCsKwUz4ZR6lBMYnw/tdmcIhVXlXyt8T"
            @"OZVPkvnTrUk1SrVYaGh5ifm2d4ZJhOu4Pne6v4OJPJIOI4Znl5GTlwqPX6fQr5gXg3MIZPTkysmrvqtTqu6+JnfJaXlpleM011YFmo1Wp4rofS"
            @"KbejtQalkCMj9B7avaO4f/++/uPOF+XNW1icnaVUKtFstchnszQaTca3baV7918+Vvzcv3/cru5FP/Xx6IUOMjyG+9HXITa+8AVGr73eRJ8xUv"
            @"wbje8l/PnjCn+rZPN6KLoJYU1hPBi77CKcs5/Eo/OaWrXFU8ceJn7kXtz1FvPLFn/9neTKv9f8+FeGh3+TYTyrOdYLCYVAJjFvtVzO2b6VqNbC"
            @"mz9OArjZDEF5iAc8D1mGC679EEtf+DLlJz+Oygt3kLTvxi44zN1/Oid2e5z5lAKZ5i2Y47/FqkWwDFEpx8quiKW7FeWLbda9OsKMr0M9PIa89i"
            @"FEZjt6d4/42DLJ5Rdh5xzM7j3w9BdS/8d3i8z0JEm9jibVxBzXRSuNAXJ7HwnaSXKn/YTLr5JBHx0nWM7Aq63SLtlxHfq9VAzXg2riuM7AZ56n"
            @"0WgwNjq66rpYHoi4tVqNzADv2paNM/CZi6NHj5Iv5FMv8iAS2+02pWKJlZUqI6Oj1KqpDaJer1Eql1PFPE4oD1VSz9DIMN1ud2ASC1L/70CFl5"
            @"VR1/7VtaH93W8i/7oT9c730PqnfxK5MKTV65HPZAi0wc5mcb/zv8b79v9gNoyTTK3DvnUnVqmDeMtlyEvOQ4xOwthzi/S/1TLdD2I95vLwVwQ3"
            @"/MJQnFI4Jcn2dZIz1yQUPIUQ4F66AUou4Z0H8KYsDs3a3PZ7w4teZaicr7jvpxYf+3bMi2zJQWWYMYZxKelpzdMLJV6sBFqFSKNoRhFHEezFcP"
            @"lHLmD9J6/5eNzY+/Ej7/lHyk/dwvirNqAas1iuA22J2XsTYrkPtmT+ry4P32UoV0M2Tk/gTglK71hGdxPM5JmIQw76Vyfg8Ah0DeLkEszVibZv"
            @"IbnsApyTB8Ap0vjHD99iXXbZVUltJe24tEb7Gbzdux5y3/H/zpHb19C58IlYb3q/UFJDv088sKuGQbjKUKcmwtSRGccxvufRDwJK5RKLC4uMjI"
            @"6wsrLCmjVrWFhYYGT4b50YJnUxFssl5MjIKP1eqqs4TsoFpF7kOqNjYzSbTYaHh5mfn6eQL9DtdHE9Dz+boV6vk8lm0o7AzxCHUarFdDoY1yHG"
            @"xvnsh0L3Dz8j2ryZvgLrnrtx44R2r0fW8+hLia80pXe83fhf+jTJeWeSdCy8b/wcZ2YG4fnoP81gfn4bPPoQLN3YMgwhTAFMjKeznO7kcKwyJl"
            @"Tcv0fxnT9b3DXrE+ZcWJmB6ADeWov9B21++nPDs5+nqWxQJEuGi59ueMuTHX6RwCWOzeMtizbQBw4pjUATG8NJlVBzHA5Lm0tfnWf9+16OSroX"
            @"2eXJ1ubPv4Pj1+/h6JcfxCqPQdKFaCdaeuzf5/HjL9nc8AtNoROy6bKzGHrNe7BK5xILhSiArIxgOgZ9T4zYdQyz/yRxM0B5HtZjh/B+eD1JeR"
            @"1qywjlT73jyvhbXzPeyChIgdCGRED/jtvOyS1XMU6ZUqmP/JdXmUx1ZUfHsnCt1CRouzaO6xJFqTn+FNj2fI8gCsnlc6wsLzM8PMTS4uLqmM/I"
            @"8DCNRp2hoWGiMEbphEKxSLvdRtbrqU8liROSOCLrZ+h2upQHPpBisZjOiE1P0Wq38DOptCGlXJ3ZsmRqpyyVyzRXVhjesIFwbpnCe19j/GwV+d"
            @"Z/wP/JL9jXaKIXF/GrKxd6GZ+OkBTnFt6YfeXzjTmyk+hJT0Xduxf3z3elrabrIHbNYf1pL2b3AslKAbVcQx05hJFF1ILBklvRlmZ7zaZsT3LJ"
            @"+oTzhxQPPZjw1V/AT673OLqQYechm1/doHnDczWTExrVBmlAS8WzX2t44RmSX8WKCUuyGYEEsgOT+8kooGEEy8Jhw1M0mz5xMbowjUBN66RetM"
            @"uS8771VKq3H+TQvz9Ma1Fz//cTfvqxgEev15yVMbzkwojN27bhF58MNz+A9s7CLJcRIy7dGU2zNk74jEtoFyfot7rE3T4tk7Di2gQqwvvZrxH3"
            @"HMO86CrGHrgGPvtRYzsZYpEC/okjMxxeatP66Q3IlRGKb38t+sMv2jfx8H7TcTx81xlYfy1c1xn4sOzVUahMJkO326VUqdBupc7ExfkFRsfGqK"
            @"6spF1yu4WX8ZCWRbeXljyZy6W2R8u2sAZm81wuR7PRoFhMLaBDI8OrTPEpp2EYptYJ27JJkphcPsfy/DyVjZvo7dr5mqEPv9l4l5+FeNfHLjdv"
            @"eR8n6jVudGy6B44Q7959f1IZObt8z93GesNzv2V2DJGceyHWrj0kx0/QlpLQkuheQBLEqHMuI37+8zATJxF/+jTBdb9AelOER2Hk8U9j25Y1mO"
            @"Yi57tTLOQvwvYVzz7b8NT1CflWwr3fVjx6p+ANzzOMj2iitkFqA0ZgQoEzrHnNmwQXbxH8Wmme6zhsENBWCV0dMeJ69L0MycUBF/7H6ZhN2yG2"
            @"QYpQyhgd1bAKFo/72hn0HjvE/e/Zidq1zDPOjXnRCw3bN8bU1VY89Tjc//k2yeHj+C941Wx8sggll+bOZWo//yNB8QDWV6+i869vY37zDnSkEF"
            @"HCnLRYtiTirzvhlkcw73wzpdpdiA+9yWQcBy+KMA/cz34j2WvbWB/6EFGjQuHfP4f+4TuYuOl6o7IlpBSIQQdmDbKS4ZRHK1iduSuWijRbLUbH"
            @"x1haWiKfz9Ma+K3VQGvzPC+FKwJwPW91WiBtCVO2OQiC1NLRbK/yQ/lcLrVvZjKr0kehUKTbbFDeuJHeLX98qPKtj5wjX/ZirJe9flP8iS8cYd"
            @"eD/MlxqCaKOdVm6/59BLeq3Znvfhz10ivQBzrIe++HZgMrVoRaE2iNPvNCMu95Cd7jq4hd38fZfZLePMwfNbj1AkLm8LefwYbTH+bwQ48ye+wA"
            @"RxdzROskkxWDlxVcMKmZnDLIksSg6PUEjgASAUYgbFChILMdXv33Nplvaf7ziOJFtkOUcckZhweTBPuJPS7+4DrUeTuQYRFjZwARGhOCjDDdDi"
            @"KJOPuj05jZFcS+LjQMqgatQPKrB2o8tX0La6yE4vbNyAvPXiOOXWhM705aJ2OUFGQOHGUo+02yp59D/rsvoXlzl9rXfgrVeTpSkM/5ZG69C3X2"
            @"BsQ7/pHiH39P90vvNtHFL0a3WjSFYQbBJcJgv+VtJPf+aTr7X984EnzsvV65UTX1l71FiKSzOkEi7FRkxZi0uxz4gk4NOURRtCrg2o5DHMZYUi"
            @"IsuequsN7ylreQyWZXGUyDQSBSTcy1B1KFJIlSYlAplQp6A8+J67r0Wy1ya9YR/fE3pvzjj07I178B64rnvD186JE/Zt71UW4J+vxRCIpKUcpl"
            @"OMvr448tok4/F67bizM/Q1LJYP31MWyt0ZUx9IffTeEzl5BZcz1i+QbkXA3Rtej34PCjCaXHFdDdDObrJzn2h5v5sTHE/ZBW3OYJOyS2MBgjiJ"
            @"UBKXA9g/AklhRobZC2QbgGIQ1CaEykyU4pNq3RtA5pbqlqzo2gX7Hg0hYXvL+IvngtQo2BPYoQ2xFkDyKWNwlOIMJ5TLeNMQlitkZyJEQYSdKB"
            @"jBHceaBHc67LOqOJ9u7F+8MdH4/zLsnmPieuq+InPUrrbPJjEjM3Tya6g+Lzx/Bf/AZUd5jcnt0UogTtOujlGubgIubyy3CGFc4vryWYb3FopU"
            @"lPCuqOzY6FJUJXvMd55ksd+/InTas/fPkC77GjH++f9cRPOK5ExzEGcKzUAWE79mDkKpWnMAIp00HDlNhOrTgIgVIJtmWRz+exh4aH6ba7SEsS"
            @"J2mESWmlkwKGv/0CRwyY6gy9TjdVzVVC1O+RmZym94frzNBvP4v1rn9Bbj//PcHvb/py/P3fEC8vca9t4ypFCbAdgdnoEw+vx/rVfVidkyTPuw"
            @"T7f29CGIN+7ovJffY1uFv+BHu+ggkEwhtCT9qw3MT3JCKM6B91GRpbYHb2ZkYiwZTU5IVNYVwwnFEEWmBJg1bQa2myGcj7IGzQiY3SRSAHdgbj"
            @"5zCOj3Qy5J7k8Kppjw2PZKlGPmc8cZSNp9dRUx4mkRiTRag8wuojZONKY+qYpAVxG0kP2jXMyQ6WC0QgsQhjw7qyjZJQRaNDRXHPrZiLbILW+Z"
            @"ilNnYJvJxBawM5Cz2chRO3Ui7uovj1v6f/ku8Qvve/8A49gu1JzOIc+qNfgTc8HzkxRlfvI0TQTDQPCTi/7DD21e/SnBwzxVc//+P+J7/7rOhH"
            @"H7lx6I+fN7Ur3ils10ECSqVstYoHM/hRPNDVYmzbSqdZB1yRlJJkMJiplaZer2O99a1vTacJVIIUAttOx3AsmToLpWUNhLlUsU8GExRRFGEDol"
            @"AmvOv2343s/uZW9/+9DTac9/bki1//Qvi1n5I/coyHOh1uE4LTgU3GMF7OMTw+jj27iHPpOnjWRej5BcTxJvzrp7A+exH26K+h8Qj0UysI2oAj"
            @"ke0+tjCsVOFoK8/pT5PkS4pooYRfS/iLgdM2GDYWFHFkkBbIjIs3NYw1NQZTG1FTZ8COMzGb18Fpp2Nt24pcM4KczgBt9O5Z3PwK2568yNlXhF"
            @"ROS1BliTAe2BWEPYy0L0FY5wmjM/ebOPNidM42cQltRtB1D1NzECrENEJoa9o1Q9AX3FkVFLBYv2Uc+SyXkTd77H4gy8pf5ti4zmZonQGhoWgh"
            @"JvMIN7XL4hzBvSiPfOnfk3TLyAMPwRM2YW1bjxABaucBuvUewUqLcUeyogzVCM7qBgQn5lG79jzZftrV/+Rc8KL3m+aNH/ePHPp4f/0ln1Bxal"
            @"9GSKQQqS/ISnUyP+OvDgmcGjs3Og02YUm0SUlnO3X6N1dnxOMkXkXkpzSuXC5H3A9S/UNLojhGApHjYB/Y//zKPV99lvOa16FGz3t59MFPXSO/"
            @"9EOsS87C7rT4i4GO1iTAqICtI8M4++awn7cd8fxngldBBjHyp+9Abt4J3f8FCpCdQJQDdNBHoLAqPuGONdz7yzrX3tumlm1z+dvGyPtz6K0Jxw"
            @"4LdBJzxpSLWFsmm88gy3kSbRFEhqSZ0FucJWMdoPRMkBkJbgWUC0qBBaK6gLXQx/ig6mDa+5GTk4ihNQjhgRhBWOMYzgSKCDn0e+Hblxt92/3C"
            @"2oepdtEtg5o+DZE8DjOm0StzJEdOMtyaJRIhNZkhv8VQ2VyD3GYeeCDmD7vhwr7kpWMWZ5wvoSxQlkyNd5Uyorwe0z6EPbKE9bVXkPzyEjhwHf"
            @"JFTwTpIk8eYyxqUTRl7jvcwDWC/QKOGM3GKKB7051Ez37ZsvOLXwnnif8pxLV/Z8q/+7ppXP1WobpNHOml+wP8dH6sWCjSbDUpFtKhinKlQrfX"
            @"Hbghw1X3hRQSe25ujqGhIaIwIopicrksnU43HSxcrlIeqtDpdNMpisHkhYpjjOviNzvYv/r0df7Ln0tsxsP4nR+4xv3tbXDmFpJ+SKPV5YAlGd"
            @"OaIQyTQjLS7KMuGIaL1sPw2R9Aj3/Wecm5GK43dO5AiCJIkYqv+WGssT4m8Dl0v+CWb5/gkfu6dEOIm00WqjvYMgaj5YgNT1lHabTA0PqQ5aU2"
            @"0ckA60ANgghHGbI+eEVwc2AHNoxMQXEKkKAMCAmjPmZ7FbHWRmQlZHKI8Q0Yy0dYJYQ1jGETgu2vNdikxb37Mqxl0HPo6sNwrIOQIOoStVKkpa"
            @"dZiEbIP36aF53psXzvcXKVQ7jrDIk1yvGdR9DA3Qdiat+weNJVGS591TDTGwVGgi6PpGXWeIhQIKLv47zoOeil98+Sy90qbT2lnrbrSqm7ZI63"
            @"ydDCw1DXhgeFZOvMCcRFZ2PfdSfxK15o+OK/z9rPec8+9ZG3nFYyZdN5yetEuDRPvlSi2+2lK3MazcEmk+qqpFEpl2k2Wziui+ulbLYxBnt6ep"
            @"qlpSU818O2LdrtDvlCuhmjMjJErVqjUMivjsVGUZSqssJBXvs5U7jqQqL+MMn7Pug5ew9j71hHUG/hdXscNYZlYzgLsISgLCyQErGpCCNlMMOf"
            @"FVYBTBcUCHcaVA2jExAJsjzB8pEyd/7ng9TumiFsx2zNCUzBYtdyxF//XGXLy59Gv1/h3JkTNA8dYOamFXpdg+dDNg/ZLOQnbPyCwB11CDyH9k"
            @"oFdfcEopMhqiW0TrZpLLep10J6dYNOImwDsYlwZJOMZ2E8j/JwgS3r91Jev/sH3rrpH0R6nIZlkMMR+fFxsrKJPXEcZAytCKvZoLa/weIJmLEk"
            @"Qxum2X7mOvTFZ8OZHR4+1uPuhxc53ZK4lmGdrzh4c4NjDwQ87mUbuOgfNpAZy6K7g4EEywFZgvBR5NiFtwpz2uuMmb1QjnhXqrbC6RnWCMlfjS"
            @"LA8IAQvKAfIsM+5nFn4D7yKOGLXjOd/M+npt2/fz/RP72XzJqtRj7hEtFdWiZfLlNfqVEopZlnZGSElWo6JVytVimWSoRRRNBX2LaN5/nYC/ML"
            @"DA1V6PX7CNL57c7AkZ8OFKZz6qeG1XzHIfGyeL/5kSmsgzCzDf3G9+MtVTFb16FrTZQGr9FkYYDfexiMgCFtUJ7GNHvgPR5Ldq9AZ24VMgvytN"
            @"BwwkMFSL+DiqfZ9cWjPPy1u7A7Tc4YF3iTNodbFr9e1ixPjjO97hJ0YxF/5Ubqt7ZREsbzglbRxhmWaN+mlcDJLnSWYfEuQy6O2ZJdoajmsawI"
            @"xzboFegtQzcArcGWgA1ZkSYm4wtyvmCkqRH1PbAM7n5Qe+HEATiR5Gg6LvGwQ2lDnvF1McP5kHVjBpYTiqHCbiiae09gZk6wYzyPKl5A3j8Hcf"
            @"o8Ow8e4dKMw9ZhTcZS1HsBj3xnPwdva/Lkjz6ZLc8dxwQrKYC3TgNxPug1r8NohBx9IOmuxSQhKtZUlMaRkBiYF4IGUFipEQ+XkeUSzlKN+DVv"
            @"I/zvj2K//CXoj70N8d3fFfzxoXa31SJfSKdjhodH/jbRWxtIWN0e2fxgH5Jl0W63sCenJllcWKRQKBCGAUolZLIZ2q12Og9fr6f6yOICYyOjNK"
            @"OQ0uFDb8scvh397KtRb/gI7qOHMWsnoNGG40skUyNIDT1AGk0XGNFAUaJLPvo5b8c9awHiO28R9guOYHZshtN9OGpkxtA+nrDrIzdy4pZdjJbh"
            @"jNMt7IrNDw7A9bOa2XbM21+/jsuvOkL0m9txy5KpCx1qbcnJ2GK5JqnNG3pzirijqdUSVKyJNEzkYa8L0oF8BoIIdsUOewKox2q1YVAR5BBsAk"
            @"ZqimFpiE/Csg1OARwfhJLkIkMh6mGSPp1ZOLTTkGAIPJfskGBoWlLKWWzbApOBYsO4wa306D1wO1uftsA73riZt7z7ILNdeHRJ8vr1DpdNah45"
            @"oTh0YJ7fvu5aLnrbM7nogxdhZcEkG0GuPweTBZGAvtuIS596Y7Jz6Vny0e+jGg5+P8KI1GLbBCpYRK0eBDEm5+MuVIne+H6i//4g/rYxok9+oN"
            @"X/8jeF53m0Wulms1a7RbFQoNlspAOlg8nhdidNLs1mk6nJSezDBw+xZt1aWs3W6sREFEYUSkWWlpZWlytMTU6xsLDA2NQaxKfe92XxpG1EH/0e"
            @"3p594GdguQndAN1qITdNg7SIgASBxDDiWJhMFv3OD+M+awYav4PsGaCu3YR4uoGnCGFf/qyVe07euOcjX6J/4gRnbbKYnLS4O3D48V8Ux2cTNk"
            @"jDmUKSHFjAeJPYGzyWZl0OrcChByP27+uRxNAAAqAFiIIkWx5iuFDEKZaYnBhi/eljrD1/B/GhExz+8HeISLmjnkkdd2MChrXi6jGH5336HST9"
            @"IZYOz1Kr1mkuLvHYQpXDzRYLqs3+oEU9UGhgBGgPdhTl5yGZBxuLO/IWW6ZszstLLujabBiPYShh+egxpgGBYX895p8bgmdscLi64nDOOkW1oz"
            @"j5/RsozM+x5SPvxN+w8VtaZ/ZIITBmpzHJHUhr4Vn2215EPNPAn/kOw8ohG8csC0EA2FJixwmi3cWyfYywcHo9kvd9juB9ryX3y+sIb7jBBFdf"
            @"LUoFBo6MPLVaPd141u0NlPp6Oq3abDFUqXD06Az25q1bWJhfIF8oEEcRlm0NWOdwtfaNj49Tq64wvnkzne9+1wzrRZKZcawb/wi2BVEAwoJ4sD"
            @"MmCCBJ8BC0jGaj43BmnKDe+wHcZx5CHP8BYvwcTLKCoQ72bQjvcvSe227sfebjDHd6TJ/jEpYsvrYz4s4HI84DXgmcLeCYhsMzdfr7Rgl/FPLY"
            @"zSF7axD5cOUrnkh74lLsyaHrihPTP8sOD99ZGikUh0dGwvLQyKzIZSNwAWtgE/sPc8k9ZU7+rkEkBXll8I3Bk5DHZtMLY4pv3AH8vRgiTmsbmm"
            @"cSQrezMaw3LqtXG1GrurKxt1C/XM0+8Kwf/vinJPk1JK0mvfl5+rUubkdRPRBx6wF49Hq4+GzJZRs0vcU2JVL77JAQhMCfj0Y8tGjxys0OT9sg"
            @"qPgadWgn9Q+/n9EPffVN9mk73kzy8O/gQYTsYVrzWOY/MZ/6e/SxeR7/+99wh0xX3/kA3R4i0Zh2Hwo2Jo7BtrFbLaIf30Jy3nbKX/tvmk+9gr"
            @"6E7KALz+dzq2pEZzC0mPrW89RqNTZs2IB9bGaG0bHxdLTGT/2x/X66IKrb7TI6mm7oGB4epr2wRP5Pv4EnnIn5/h3pLRADHz0KtEECstmEKGII"
            @"w9VDJV5Ta5K8463kXtFAPPyfiPVngupAEiFsCa6hf+tHjbfve4yvjZneYPFwNeKbv4K8Huafn34uZ592JqPbNiM2jrHOznCBbYPbI/PMo1x47i"
            @"H8O/Zw4+078S9e4an/cC7w0hdCw4Xus9JX/yJjjkwlKimiRUtgtaH8Fak0l/6DRN7lYjc1ExmPjC1p9IG1Xc58y9no+NyW0fc2ESJEyDbINtKe"
            @"FTkLL+fum1gzenSCx30WddNnOtfeyaXnd3jZ514M2beK9vzcM1sLJ97UPnLwBQuPPkb/4AFG5g6T6Zyk9bVF2kc1vhA8RQgiIXjUaKalZL6n+c"
            @"7DITObXT7yJIs1viCI5xFHPo7ZWDD4AcR1IEY4GtOYx+bjhF9/F53nHOO1jz3KLwoVrJU69CNEoiGMMW6IIF2Hg23h7N9PeO5m/LkHKfzi56b/"
            @"D/8genNzeNkcarDLqNvt4vl+OqOfz9PrdClXKsyePJlaWqtLy5TKKcIWg1V0URBSGhqi2e6SdQQrYcT4nr3G+8aH0Zdfhv3+L2KhTs0HYhAgQC"
            @"aaaKSE7PRpmlTR7l35dHJffDzeYx+C0ghMjYHngy2QldOZ+d8OhftuYOiZmzCzM8yczLCr9nR2XPWCO0+76uKvWKPln4FE0z8b4k1gPIlVBXef"
            @"ITcHWQR9lh+d2bjrhn8/stZ8n+2v+CBq3RWIeAVh2QhjpdlDyoHWbtIsJKa+xd43vemGp9/N0+cz+EUfXIfOckDnQx0mPvVdlD73OsHKCwQeCI"
            @"ExIhTgGaPBJGiRv9NKTly+8t1X8p139djxDper33Mpauzno7asfwzKX4HSfvABhe7UClJ0Xtv63ae+/G8v+y7HgIuk5MlCMIPgVqXoSQiEYFlp"
            @"pio273t9jjOuWos5ax36oSOoyvNwnjAF4T4IZqE7D7V5pMiz2P4HvNd8mf5KFdNoMFYpkiiN1WyD7yPiOBWtBIhEE23fgtw4jFlo0b3hZqF9j7"
            @"DdIVcZIohCfEvQDyIyvpeupsnl6HS7jIyOYi/MzTM6Nkan00kXLmqFUIp8uUJz7jg+/Ze1/dGfjUyMw/U/w5qokDxwAKEScCRaGdqOQ9GxkN0+"
            @"PQFWt4/yXUrdPvPT6yj869PIHPgIRjtgSUzQBx0iRzaz7yuL6J/exNrXTMNTnkeymGPIPOcDLz5rw1fg5C2ah69RSesatAZsBDYGlwQHKR3QLg"
            @"YLY418fvSM8s827Z3hQ6+VfN39NpW3bUa7ZYRR6SQdyf9JmeniBa3bz7J3vI/jT3kDX/1xk2f1AvpNw/wOwRPe8T40Z98PJ14AHkYEYCyEsLx0"
            @"ksVgUFh2dHn418/w6Jd6HAx9tnsBwtqCMc3Xqnjm7ZB9O8abNTj7hHDmZNbfp+TEZ3NPdL/8dxfZHNhf4WBrmQbwDMtinetwaxxT1obzz6ywr1"
            @"nn4a832fL4UXzRRx+dJ77hC6joTfhPKUPvRLok0/XRi0cZH/oexz71OuxXfpJxxyWWBqcfEQKW0bgCtDHpJZEC98hxoq3T+It76f72BhO/4uUi"
            @"UyzSP/royyzLm+1PrP1LxvPo9wMyuWy6miafY3lxETk6PpZufnCdVPeQMl2L2w0pzN1u3PBP1+QrI4QHDxbc/TtJimU4Pp+6DbVgP4JDWiO1Jp"
            @"I2iwhkpBBKM58I+OzfU+l/C91tYbIeRoAJAqSf4ZEfhcx9+09svADkVc+B0X8TzpkfE+WzzLuT5NetJLrjIpLZtHJYICwDlkbYCmnFICKwQoTV"
            @"A9SoSX50/9Ff3M6JwOKmHy8hHv52ysmYBsI0ELRSWG3aQBdBhDCHp7G33PjKf3kTf81rdhuHx4Dpfz6b0vjL95nk6EWSBOgNfq6eLnWgCmY+Lc"
            @"Fz32Dmi/exMGtzUirW9gC9BmFFlwnpIixvWdgylLYZFTLeYXTjTSI+9n0x9go2XT3K1Wdt4ZXPeTJrNq+jKeC0KOKNxubpZxked/3LeM2dd/Pc"
            @"//kQsn8awa0LGLeH4wfI276LPtEBv4QREqMVOAX0zIOsOf9emu99NUEUYhuJCiKEEARKYSxxavIHIQXoCNXuoLI2+V//Ct+2CdshuSPXX5O77Q"
            @"t3OqEhMamTMTXXu4PhixKy2WiQyWaIkgTbthACYungn3z0p364h9zmdQi1jHvgcMtqLKAdC+n2sQwsG0PTGMaNQSSaO4xmWQhcKei3eyy94eWs"
            @"OftR9OwjiFIWHBsdayzf4sAtFvu+ci8bJxP8F7wes+2zwiQz70Y9/DudzI1KFJZ0EAIECYIAQS99mfZgtrQBpgrUEKb+Wv3gtWSOCypCs+sRmy"
            @"M/uBdr/maMpYEaxjTBNNOfo45hGSFbJPEDzxo+8xk8/+1ncH2S0L4cznrJq1Dq0GlCLAx6ufRnoAZUEWYpxeG1u1n64o+xHrE54RpmXNiogf4k"
            @"guYLUjKjPwrhJkx4DoTnINQIovlaKde9PX7hS5g9+QDjs1W2XnAa2ec+hXjzOgqTPhOvckjWXYBef4bIvvlfhP2anwvryt+8Vj7zGqwXvRXvZc"
            @"8B4aKaBcgW0wSbJJDJYs38lk1vznPkCZcS1xogJT2gZlLiXZ7Kx1qDa6P9GDVexn7wXqzDJ1/mL+6/Izu9hszZa3F3/c4kTjbdK4QZTHNYhGGA"
            @"nR+sCjk17orWeE4W5+gfX24/YRzkCuLI3cabOwl+iJl2scdzmLyDHWo2xgalDXei+as2PMeWJIlifsM2Nv7TGciTH0ZVspBxMUpge5q5Axlu/c"
            @"whNiQh+ac9F/HUz24y6tcGljFMg3AAiTEhoMHoQemRCJHuAxQmwRgNOkE4JfTSTsQdu8h5krYxLNhw7Foob/0FlTeNo10v/X/TSfLB+UvPoSTE"
            @"mJjn/eMbuPlX7+HiD7wQmd9KEu1BWnkMwQDnDX7WGBAWJhbE130Z76EYk3f436ZhtKIo+lmUVUFwZDCTlQAeBhuB8EB7CIVK2l/Onv58jjzzFz"
            @"S+/gjr9jxCftM6etNrme8dZ+zqd2BZl39eR7cYI3yEzGJPjf8ArhKseyGaGIuI5MjXjFHHkVkP03bATlC4+K2fUfn0uzj5zEfZGHYIpWSf1vSE"
            @"zWlCpoFkGUQ/wRn3EXENnDb2o3dfY2XqWJcMQ8ZC/OR3+OblBEbjWOlub6N0ulDs1JxPaiwCHJdk9mhB9HcjJgTCj/Bb92Ae/QPsGMLaMok+t0"
            @"KSc/GUwZKChwwcUAYxmKA6bgzyQ69meOQWVCmHHCtjPAchDYHKcP3nq3SOdXHO30TlbW/BmP85YvSfwCyDOQjmGNAdTJsrjO2CbSMFiLiLTFoI"
            @"ESHsBOOkskfnnj8RzCmmttvUgRsTQ0Pb1K5tkvz1BoQMEWYRWAS9AHoBoRdBz6fZSN2DNzHMf3z6+Zxx6QvQZg9S9DGmDaaJMY1BKayDqSIth/"
            @"YtP6RzwxzlMZvvLMD+2IhzyxqZG0WXMwg9PyibVWAFQW2QxRqD7DkPGKbf9nKOViDRFn8+eIK777gL912X453++iNa7X0Ptp2mDGJMsvxakxy6"
            @"z6gVpJIYLKRs0/ju/cShhfAlOC4iX0AnLdac/RDmHa+mqTWREHSF4KhOaGtDbFsYy4HRHM6GEmLSQW4UiN0/wbQeQIxqRGkZrzhHcnD3u518ET"
            @"XYYHfqiQa2UqmukQaQwrgFxKHftvz1CuQxhNqAu0OQuI8itk/hXHwpetfdECr6UrBXaQ6RsraWtOgkiv7jL+ecV/iY5X2IoVGMSUCDrNjc+PWY"
            @"g3fVWb/G5swPvRQnezuqtwthj6UX2nQRwsMYD+whhHaRx3YTPPAw7ZPz9NoBjg3+sEtu+wjOmk2IiXOp/2EXEzk45qaG+Eas+ZWWXB7aNH/yME"
            @"OTo7BxDOJuKqAOzFHCGAwWGIHifkpXvxcj7wO1AsJD0MGgEIQYE2FMgHAnCB+7j+Wv38XWgsNvFyXfPxrjgjm7BGJsDSaXYHQtzT6mN8iqFhgr"
            @"1UdIzWwqOUTlzEswzxvnX7+/jIPgfe8uMfzKd6PjI5uEDMFkBhnTAem1MJk7Ye5XiEPPMqrqifYfkEfaLN2QYc3zXYwG4dnpvezcy9Q7/4kj12"
            @"4jP3OQjhAkg+NpRRGxsCiuLyKfMIou2ejkKJ64G3H+GzGWBfow1toEa8/dnw+3n/Vfrm2hhUQMJl3t7GC9q+/7aJUgYkVmZTdsnofleSgPIyaK"
            @"WC87HTlyOqK0/fNypvqeucBwQmkeQRANknvPGE4Iiwv/5QX4uXtQ7QoiiNGxwa4IDu20+PMPj2Mb2PaiCSbOUajeAwgrhzE90gcFRGAkWB6sQO"
            @"+233HXT/Zw9E4wLfASKFipnFCZPk5lwy7Gn3Enqtkms8Hirt8YJjHULLhlRXH7eocrHhWsfPVeRj5wKZQDiHVagkS6Q0cYi3RZTx1j/QEh+mmX"
            @"ZvoYEaZfTReho9TK2l7h5Jd+zVRbsDgs+eZdmkhohozD1pKGkbUIsZTiLaHSm6+t1M2GlX4+YaXf6xhwOOONT+PT3/shH3o6DH/yncQqxhILQC"
            @"l1pqUULZiVIhx+T/pegdCle9cRDu+NmLlvkSeeu5Gx7RY6kgjXRVkWham9iHe9kPl//Cy2FPS0oCYglpJEa87eu4J4uIf9hn+Akd0wPITYvhUT"
            @"LyF6RxFrI3J/2YPq9Ygx2Fa6gcW2HWS31x2s4w3Rto1ZPFnQ7d1YuRamMY8WPVBN5FnnYpxHSQ596z3maJOFIGSnECwDS8C8JehrTfuys1n/zB"
            @"66N48sjEOugPQstJPn919vELZikiJsf/ZUWqpMNMAIMdr0gC7GrICISHbdzO8/vIe5X9msbTis0Q4Vy6UkPUaly0TiMTbvEHx1kWw7ZCGx6ezR"
            @"+AgCLehj+I+DiiXLYfaWHt2b9kESYvQiqBWEWgbVAN0Z4C2BMHOgW2BaCFND6EWEnkPoKsY0kTic+Pat9P7UIbvB5lt3GfZ3ExIEQw5smAKGJh"
            @"HiOKgaQlfBDEqXOQXCa+m/MzWE7KDNDBvPuYh3vCzDxZ97HyZ3NlIdGMC0fpovTBM4DmYP6L3AHIY5pInonrA50YCF2Zjbv95AOwVwXfDziPwU"
            @"Jl5g62s3cXLrVkKt0VJyAjhmDFoKVAAcbWD83cgnbUBc/MwBUd/F1BeRuQbKfQx54uDnhJ9ZfS5IHEfYpWKJ6nKVXNYntlzs44+1suMxOm4jwh"
            @"Cj2inpZI9iem3in/wSvadLwbLSgDGGrhBkjKENbHnlVix1J4lxsCwHkylhVXLs+VmP43+pU8pKypsM604rY+IFpNRpWSAanDCR5rRYw+NeSG1b"
            @"xP2HHmFnrFkZ9F4eUApgfRUuXA8X91we71nc/aBguRsxbwnyChwpeLit+cqMxdvKFsd+Ps9pO3KY02JE0hqUFRdkLv1qamBSAC9I0rbddIEYlE"
            @"JkJ+nfvZdD3zjOhVM2Pz0g+NHBmI4FeQVrS4LR8yz0miLCPJbedB0ihJU2BcICk2ah9FkkFoj0SUTad3jFR/8ZuWUrWt2HkD7GNFLWOF19Abo3"
            @"UBd16lzXGuFWaGZzPFCH9TmLgzctc/iOSbY+v4SO8uAX0IkgUzrExP97Cgv/cpAeKQ80JaBjoGdAdFpYf/kRIhshLtya4kRi6NcwUuOsG6W9d9"
            @"d7xOnnvtcEPZLBDk179sRJJtdM0ayu4GbLZJYOosebOCrERCHEXYT0EXYXveYsxMM/xa1C0RaoEHoIEgEdpfE2DHP2RTXMkb3IdVsxOkE6Fkky"
            @"zP3fuYcRV9MxNqIssBEYWun+aBOnwYPACAMmAX0SJ1/idde8jvMfabO4ENOumVvazeBordaanZut7j9+eP7Iz/cdvf/7S0tsXIL1eyyEY7OQJI"
            @"yQcodaGH55LOGqSYcL5iOq180yNjmFLq5AIhDSTXGJ7iJMCFIM8IYC3QeCNDs5OcTxJg9/bi/jSvJwLPn3BxKqwjA5EG43TSiy20okIwoZnRx0"
            @"YAHGWKdYlzRohZ3iLmwEDgIbxAx626UYfeegW3QHfWLKdoNOg0kM1vGc+m+ySW7EY08A01lB3jbs/t4Cm5/3VETGYIQNJoZoL6c/dy23/0eJTq"
            @"2JZUkK2tA3GpnPYN++hNhRh1c8A5weqAChA0wcIoIIhi2Kh4/SSFKi2c+k0MfesGkjJ0+coFwpE3Y6RIuPkD1XYHpdiA0i7mJyJUTUQRaniHds"
            @"JPrNPurSxgIiAUoKqtrwnKeNMtR7jCRoIcsr4OUQQ2UO3BBw4J5Z1g5LdtcF07ZBmASlO0gVpycTK71pwmBM+vghE9yEJ27mceePg1UGylfCMD"
            @"AKbAJKNKsVDu6rhz+75g/f+stPbnr7Y42QkiXZplOmRwKLRvM/+xQ/udQhvr1Hb0cL/7kjwAJoG0OIMA3AxhiR3jij0g2qOgCZINsjHPncY7Ar"
            @"prjR4aO7NSdjRVkIhhCcADaPKsgPoe0GMjmBoDho3Z1BdpVgpYudEA5IG2McBBZCWEh+k8otZkBVDLwlaRZK52VShKzTmTY0mCpDOY+WA48Ggq"
            @"cMS2q7ljjx5z7rn1VB92oIEaHay4yqE6x5+jpu++nD9IQgg2GLgLyQiJkFdHcYa/15EM2C7WKCJiIKETrBmogJWvtwun3w00dHFAsF5PHjxxka"
            @"HiaIQpwowW8uYTyBiNJlQiZopoYMaYHu47zlCnZPuixGmvWWTDsepUlcyQUXWJjd89DV0O1gOnWIDDuvOUwQGpAWuwJDu6eg2gUTIlQrNSCrJU"
            @"RSRcRVSJoY00MYG60kqj1HUn+EpH4HSe164vp3iRv/RdL6NKXCf/C4y2/1/vMrz3v7NQ9ce+cLX/rkD4wpzXopWIdg1AhGpODhRsKXj0BJWqz8"
            @"bBn5mEQ4WYwKQbUwqoFRTUha6Uu3EbqL0R2kM8TK75aZ/WOL7RttvjEDf2kq8kIwbFKYW0CwcRhwhhDWEqg6RrdBD8qgCQaAPAYrA6aDUM0BLV"
            @"Ab4KUuQjcRuo7QNdB1hGlgdBOjGwi9MsBlKZ0gVB2tF3EqLuUKPNgG25a0eoZ7v/sIxE1EsAhRHT23hDhxmNOf6FNHEilNFUFJSrxeRNtLiJ7+"
            @"JCThoGvU0K9CkmBCA34XJ2ihF5euUEKQyWToBwFydHSUbqeDXyxiTs7+m24uId0k5e6Mgc5KigmEhYm7ZDaWWPtfT2EejScEnhS0DIxs8Nle6t"
            @"BfSNDHY+j2saI+zX11jt4zw2QZ5pXgmNI0j4L5zSymOQ66DkkPofqgAkgiSIJ0vly1EaaPRA/GjTwsO4dt5bDsApaVQ0cdkvZu4tZnWL/lwcu/"
            @"/bNrrn/rP15BVynW2ZIhAWXAE4LvHUjYlVhkmoYj31oimt2EtEldAaqPUF2E7mF0D6P6mKSDcPI07y1z4JtzbB22+H1L8qPjClemuXAjMGUMDo"
            @"JtFUAOgVxK1wybGEyE0QFGd0F3MaZJ3NyAjgWYOka10pdpYXRj9SVUC6E7oDsI00boNsa0QLXTgNcthGmgVQ1no2TTKBxQigdbAsuD4/ecpLZ7"
            @"HmnamHodcaIGK122r+swvDZH3xhcYZi0JF0V033vGeQuOx0VLqUz3yKB3iIog1AgrIi4uUSm3vyVHCwy930fubKyQrlUotMPCOdOfsDLS7SXPj"
            @"gFgE4NE0cIYSOkgwpW2Pjyixn9p83sThJOsyURsLYgcB5bIpGC+ESCnu2DSZh9oIla6VPKWxyIIYthsWYxZy1jsY4kdxnC0pgkglhBrBGxRkQG"
            @"Ep2+VIJJQoQKQMcYoQeEsEBIH8sqYdllVOfHJMF39732v5/AOc8cohonVCxBaZAlOsbwhX2GppHM79KgplKIasCo9Ik56AihI4SKIQkRtkfnsQ"
            @"z+kmHRsfnK3tRvXDIwZGCLFGgNG7KSdRNAqYRMTmBMnGIoHYDupcEQ1RFen/7tB+g/ECP8PkQrCNUYvOqIpIFIGqnsoptpYJl+Cuh1H2N6KaVg"
            @"eqC7aYabEoyOp0XusQhGixZxK+D43Q0QGnNwHtEMSWIYSpbYuNWiD+xwJe0oYebqYSY++gKI66k2JkgPc2eOwVJXjEhwKzbNAweKSLn6gBa5dt"
            @"1a5ufmcTMZimEfpQPEWBYzXoash+jUodfESDetwZZBJ02e9G9XM/XMAo0wIRSSDeWE9rEApdIyHT3WhVgyt7vNiG/IFW32dzQVAV6QUJ+bRhZb"
            @"JHf2SFpPRBbORPhljGthbIEmxugQo3qYuAdxH1QCOkAk/fSmqA7EVQhnIDiEDGeg+1VkvMzzPpxF522yyjAq0gAaEXB3PeGag7D9DBen1MOEEU"
            @"JphFKpZybWkChINDIxqE7M5BmKkTPg87sNRyPFkIBhBJulICdTbnnjsCF3hocathBBFZIYog4iaEFQxwR1COsI1SNoL5HsWRmMFDUgakBUh6gG"
            @"yeAVN8GsQHwGOliftv66l5YXE4AJ0y5Jt8EVTIxlGQOOBxp8izUV6O1vwYk2zLfT2ToDHGuwJR+Sl5Ik0MyeZbHuGy/CsRVGh6vVhqCFaC+BZU"
            @"HOQVQcEsdQ6geIUw/5rQxhz83OUywUiI0hXFjA10naQubymHwBuicxK7NQWQcqGTyuoI2VdHjVVx7Pf73iNsR9EetGU1O6akiGRg3JkiLaH6JW"
            @"LEbzMCdgJVCsARxL8Oi3T+Cetsy2+Radn2TpXjCJzK0lt9HHGhGQEWm/7klwJcZuYqKDEIcIoxD0U2+OVgM3UjoKZLmLhAf2snFxhXOvcth3Xc"
            @"JaK7WdKANdKfjNouZ1RQchDKatB8w0A3vG//lHg1bgFA1/EfCntiZnCSY1bAXWCOgJQQ3DRdMaa/soEWAHbYS2BjuyNWgxeHxEAjlNLehw5PZ5"
            @"nvPyLRhPQDdAWCItHZKUJbcAvYOj31lk6rkCe7KHUTFCWgPwLQcDx20IhpjyLcYwnAw0VcvinFGI5juER3yc0IBloC9oHdGcPgm/11DdInj6T5"
            @"5GYcxDJSsIy0mbF2ljWrPIOICJMiLjgOdhZRzqJ47jGp1moGYjfdTBqT3BjgkhawFuWsJ8H1Mpw8px2HDhgPqPMUkDvfQwvizztq9fxNE33k0u"
            @"MpgstBqQy4HvQv8ETDo9KmvgwbrAaMOYlIwj2BUqgk/0qb2+xCV2l9aPD7N7H3ijkvIGF8ZzuCUfk/HxpjOUN42TOWcSU7wvPd06FVLTgX6xut"
            @"oWpdG6Dfcn7KgIHhUWk8bgSUlXa9oabA/yBQvTi1N+zhIpaLTE/2+LvtGkHZNRRG76fIhRYJ1MzfaxNhhhKCI5fZ0Gt4SIGtDTGOx0NMKwuuTS"
            @"KKCr6XR6/PammKvureFc4kIcYvRgGaYlwIqRpWkWfxSy98YH2fj6i1D9LgIPowVC2giZdmqIVAscz0umgaqG2QCePCpY6cUEdQ8PMFrTXxbEEZ"
            @"Qymsltmhd+/0oqk4Zk8T6ssTNTauGUYL10HDwLChmIYsDCWFDyXULLdvv9XlQolrB930MYl14QofotsrYE6WOEQCgDw8PQWYTaLGJsEoIutOeR"
            @"WqM6JyiVNvPZL1/MyvfvJliWaMewsiyYGAfH99g02sIdlnztZkMWwbiAcWO4VsKaZcU1X+7zxyfYvGmHzbldxcwjCe2DASsEdAR0gMCBauYRrn"
            @"73Ds569xZ09AhCy/Rirm4cHWiv0iCER9yDKaE5agnOUIZhadgmBE0D0wXwcgL67ZSZdAZBJFcF+pSyUaS4rJuQVzAErBewg3Sxkz3AT1kEW9YY"
            @"YBj6K+mbFgaSU613miFFAtQVUUPSDmDvzxqcd2YJJQUyGjgEVYIeHYL78/z0k4+x7bws0sQpW4xKs5NUYKW/E5GAHTI8KpkETgAnQ/AKFlMywh"
            @"IWuBLdhKQJhZzEKYS870dPZnydT7K4G1kYhaiJcIcw0odOHdOeg7XlNHsagzEWlhS0wx6OkFFm8FRFeWr1me1YKFmh9tcOwjgI3xk8KA7kWAHd"
            @"OAoqxARL0KlBkiAcj6RxkOFxlzVvuBhR1JhI0ulDYzmlOjLrQG50WOhpRjCcJmB6cHrvdCUb+hE33BJw1S80H2pL7i7aLOdtMjmbnOtQchwqyu"
            @"FkEw60C5BIdLOP6UWIQGMCgwgMMkipBxPnEDJP/JeE8VDS9ww1UtF0SBgKwHAGvKxARyGiBwQmZQJT3hARGOgb6A++r8XYHfCRnGEEw0qnxnsE"
            @"DQUlRzA5BsYaQTSWEG2gM5hr6pnUi9YF0RdQ08w9FKERVHeGxA+HiNjDdBS0FRoPa3eRuz9wmF8dN6wtJNBsQyDS9xYC4an3aiDQ0A1wtc1aR7"
            @"AJQzcwDG+TbD9H4RZctLYwNUO+bCM3WGRfcgXj60uo6m6k46eZPKxD3EBIiZl/DFlW4GVBg3AkwvYJl2KylVE0xu31+lQqZewwDAmjEE8p/PXr"
            @"MHdGxA/PYSUN2DCU/nLHRgR1dO0kIq5DGKa/2Gik46Ma+8lMXMiGN1/I4S89gApsagE4LYvxtbDUs4giwQZiNolUwNsuDG/50d8hjoY4376enx"
            @"1s8f02xIMKkhlQizlgyIOrX34+V77jSejF7yCj1PiWstjpknQjBCiFyW5F9hPcqqFzl8QYxaPG8CQh8DBsxrBjSCArkrinsYMBRJGDE50+yyj9"
            @"/eoU22soJmngFwbKnY3AQmMhOKMM+QmXRDjIRvVvzlkzWGLFoIxZEnqG6tGQeQS6J6jf2mNkyl/FPWp+mJOfnef7O2NqUjBiaWj200ESA0amT9"
            @"oxYoCVBCD66GqWCRvOiiW3dxV6s4ccEuC7mFmJKPuwNoe54InIrItavhPhZtL7G/cxvQYiCTCBxkTHsCrltOR6Dnq5g+72sOsJvakMKoyiTCZD"
            @"EIbY1eoKE6MjhCohGR46Irtyk+kn8FgNliLMxjxkBULEqOVZLHvQpQyeKy+kAMdFr+wkf/Zr2fjOIY587o+EHUnQi8DR9KVGRIo1QpJXCUI6fO"
            @"zZI1xy2Qw89SIue/3/cMWuh9i1cycHjlRZaPfAknilLNvO2MiF503zuG0SufhDdK8Gls2pCcBT+7IFGqMFqEl49B7EpZL6faD7hr4AXwhcYRhH"
            @"sGG9gY15iKy0xCiRLpzSKTWAHmzEMRJsASOSiVGYXIVHqS3flhJfwflTCnn2OhKy0GqDayO0SX+v/huswtaYrsZKDEcB6QrqDypK5xvssyxElK"
            @"Xx3TozuwPuSyRnZaGSg6ShEWWBSAxmQGhjseq/Ml4f182jZMpLHdeSoJCFDRI6RRgqwVnnYDa/GCmqMP8dhFdIy6yKU0zZb2MSheoewspGGNuH"
            @"xKBnWnC4BZslejaEp00hBw9zEbaDvXnTRmYXFylNTaI3rHl2tGz2mY4Dvg2HO3C4h17rY61xkdYKyoxjCTEwZKe+GoOE9Veh3EmKF53G2rfBwU"
            @"/+kX49Sm0TUfqMqayJyU2WOGP9GIWXecQzD8GJmxGlCXYMb2DHS0YhOw2OTG0OYQeCFWjuQT10Em0DTgo2jfhbpyS0xEQxZvpi2jceRv/HCkMv"
            @"cJnfrElmDImEroExIZhAsO1iF87ahrVrPyYwEMXp5zEDAfwUB2aD8IqwcQe5yd14g8BxMBghsCWs14ItFxnM9tOQ+2OEJdIOqa9WnRxmAKSNJ5"
            @"BdiSVTmeXREKZqhtqdIRMXTrByQ5/6LxvcKB0eSxKelZXovqY7H1PIWph+8jesJgZfNSA0ubxBW4Y2hiIWlkhgeBpK47D1XMS6939GmOZrUfdP"
            @"M/U86O5Or20UpocvidHaQljV1GVysgPHO9CNkDbEkUWyotFr137LymZcoU1kwgB7ttGkfPL4r5Ibf/eC4DWv8XKldejdS5gtOUTUTLPM3j76SI"
            @"iY6KLLLnJ9FqHaGOmnwTN9OaJyOiKJUVGd4Se9luTdmoXrbiY8UkY2unSUplby2fL2Z+Htv494RxbvYA1sG2oLqKWFtJRYf/N7GTH43gJpOxAb"
            @"iE7dZYMwMn2EVBSjpi+AZoHGl+6jdFTAHYaHAkEHKAhBYgxFLThXKioXnIcZeheUvkgSAbaLtCVIkw5/KBth5xG2g1n7bBhdQ2H4WjIYhABbpL"
            @"MhJSM43ShKTxpHZ1+PMv+LMAbZilZrsTHp/p3Us2aDtNAFgQfsagmuqoA6pmj/Pib8UoNHWxbfkYpRBNMSOksKaprSWhvdi8EWA3JvANC1QNgK"
            @"7IjzRnPc1E/Sx1J2FThZ5ORzEdmXCHTvMvT9H0BkIXMmOCVo3QvdZuo08DPodhu7XYO5CJoRWCI1LBRdmAdLDqPO3vFm+xe/NHJ45EhwwQWb7Y"
            @"mxUYKvfuEF7k+/jxofDXnaM5C7voB63BBWv4nwBcYG3TPo/Yp24wTx47YxeamHTgSMX4oonwYqwggbYRl0XGf82W/CGy2x9+vXUz1q4RrF0177"
            @"RCbu3UfjORUKnTb0FHipeCikwBKrE2b8X8EZbSBS6YmTqZ3SIDBJArZEr78Sec45RP/0LSb3WtiWRftRhxNJSAEoGhiWktHEMHapwHrcv2AY2s"
            @"1Q4RxR3UBvf5PGXI9up48jFKNFcJ0uzmgeetehNzyXzMYrGONmXCzkQMbZmMDUDg/x9E9AvAbCUZT9JFRxiSRaxjV9bKEhTNAqRjsejJYxlRZ9"
            @"BMcDQy0SbMpbxD9o4S0J/scxtGLDKIJRIahWDUOBhNiBfg8cMRhRGjSMRkIrRJd9tozliLdt5OZb78dZVtBTiOwVH8A4CLNwjRGjA29SCNY6KB"
            @"n04gFsz6Z50Efcu5fCcJx2g3bKM9FTqLWTmDs6qAufhn/owL/YH/8AydOfs8l9wmXY4eIyYmUROTJC4ZMfhVe8BlMfBTsPznFMrEliCANBHKdd"
            @"bf3mk3ijZ1O5dBM6fyaoQWtgSF13wiEJO5Qvegm5fS1u+c1NXPWEi3jOXxaoso/Ck54Nt/8uLYHBYAvZAMSawcDbqud98DlSQ/SAkFMJwgI9Ok"
            @"3sXkL84AKZA9fiJhnUBgurYbM77lJOFFIK1mMoC4GLxnnidlTWJ7n9g+dwx23ofSGNI5qZuZTs9l2IS5BRUMxDtgDhrx/FLjyOgm1hKY0n0nU1"
            @"ForCa88n6eXQd7wReWiG7oJPb0VRN5LAzeAWDaPrigytK2F2/B04D2PEt3GwSDD8dUlz6fOHcRckH7Zq7Ek0wwJsDFNZCHpgSxtiB9NPu3YzCC"
            @"DB4PsoIjOa46H2MTaZKYoXnsHirkcYevVLQHRfgPrtZ5AhwnQwJKAH19gaRY6eS2f/ceo3HGS0ECOUTDFWkiZOHYHOTaD2NXEetwH+4a2f0ZUi"
            @"rgkRQR/barUujKuLZDI+3LMb0/sG1sQUetmgN5bRO1cIpEXYgyg2KC3xZZcjP3qM7addQSGzB91ZQpBuukfaIH2EdMA+xrHHmhS2lnl136X24P"
            @"1ENzyRkaNHUL0YMvapHJ9ahwcla5WPMadS0N9OnMwI9NAkkbeOYDFH77a/kPvDIma0DK/M4b7KYuYPPRYeClBS4mvNZiGwtaGJoPHrWbLT70Rf"
            @"H6EeKGO3m2ToMz1ougSQnzMUsBB4IHO4j1n0KvdRM4aNAoaFwBk8t7117Cj5z78bcYMmWRbM2A0WMpKugVZiGM0I5No2mXOX8bM/h2c8j05uDS"
            @"6zSCE4EQpWJka5szrHr1TE5gFXNeQIpnxoafAKORR9xKmVG4MhFa0NYtDlWSUINrk8csM+XvbkMwg2ZujdvZfM+tGLjJnHqATUSVA9EKmnR2ZH"
            @"affXcOInt1NSDUJjoZYNtmuwXYFtFGYyj+nnkCcj9KEfIXfvgVc+B+MLukdmrrD1/MK3nCjC5LMI10EdOEbcB/uPY/gvkDSMJOxBHIPSaTWxfR"
            @"uvWSN+8NdoZxNk+piwP3ATaow2WI5F2Oly+x/28cTpTYz8eR87X7WFc578ctQf/gtZdKAfp1hhNcv8n8BRg9hywGR8yA2h/VG68RDdwwGdvcep"
            @"75yjstcw2ssQ1SXZIzC/RrPvcAtpBA8LuAo4z4AjBDkBt+3vsHlfnrPGKjDeAyuP35WMkdZ8ozUCC7wcZsiDDTZis+RENaa9r8tWW1JMFGPjGe"
            @"6rG+o1xSXrijCkoWFxVjNCNzRHMOk6YQvq8zHZfTGjd9yF94gg284yjeGYEVyuBAe+OscXTjQZQTCRjjCy2QJfC6QGb+0YRrbT7idOvUDi/9b5"
            @"lChm/Gyf637T5Jw9J/G2DNG+81YyL9yUWmCVQJgQo/spsHfy6OUFkp1/xVdVZEbS76YPDLSsFJq6SlC4ch3i1pDwcBVRmwOlcSbHSZIIv939vB"
            @"0eOXJOzkoQnQAlBZYRcHyGH/24wXkKduxwae4NEY5ImV9B+uD5vIPVOAj3HEOddjbWeAYRdFJtSikwMcGSS3s5Yv7IftqBoTyxgc4nv0HTd5k4"
            @"8zyccoRlh4i4j1YBwlKD1sdHWBmM9FHKR+sc/aUujb2LzO45wsLRNr0ajHQsKkZjpCHrOTx0b8CfD9WZbgvucgRnK8OLMjZTyhAqQ6FocV9LU3"
            @"uwS7EgORzH1O2EFd+mmkDTGGKTrmkp64ChToB/0HBeYDFaUFw1bNgaKdycg3t6luwdKxy/LuBBb5l6PzUOjA2I7QIWZ0vBhIQhY7DrAtMcofnD"
            @"o+yemWULgr7RHBKSm482aWI4UwhGBawYw7gUlOKUxLN3XIXubCZZuRbrlNU4OsUpSEQioG/hrcvRsprsSzrkj7p0bEP+xH5yI7PoWGBsLwUJTg"
            @"Z9oop95K9YvRjXc4D02SJg0EYQdBT+tiwzD9f40xdnuXqpRVkKFBLjOlBdRqysnGPnoxDtGugF6EIOqxyRbUYk7SYf+77gG2/N4o0o+ssx0har"
            @"OpGlEqK6jcy04L570Nu3ITblEEkfHUZIoWnX++huwknbIG2H6z+/kxcXPXIjiv0TgunzygxflcecO4GcuBzsszHJfkz1PsyeE3Bgif7+HisHWy"
            @"zPJiwswmIXImWRw1B0DOukhbAcvkfETXvaTCnDX9FsiuHlwJZhhSlDZsTHLjg8dT/cuKvLZ6MOj5D6uAe6NnpAYOaBQgxru1CSEreteflzS6x/"
            @"wyTR4TbitA3Ecpgzt5Vw9RgZL4dl95gNl+98aOXYRY2FBW/x8CLZJcVwBGdh8SS/xOMmszxQiXhkj+BKkXZiB7XhhBRcaQTnCWgK2AkMSUlG+i"
            @"TbikSHdyLaD0EnSyyykDc4foQTdKHTRXcNqhVRmhhmqDDPbSph01IfR3psmDtOrtTG9CUiE6FlDrP3CGLmMUQWdD8DcQj+gNoToCKFXbSRls1/"
            @"fHyZ0UVFybURcQKFPNIGbSU4SYiddNrY/R70Oog3vwpz0Vnot76LK3oRP08svvDLgE++2iXMG3Q3fYiZJcHYhrim0BMOggT5yD7M/0fVe4fJeZ"
            @"V3/59zzlOmz2xvWq16sWTZknvDNphm00zvLaH8AoSWUENeIARC3pBCCCWUEENoxjZgsAE33LtcZHWra/vu7E5/2jnn98czkvPquubaa0er0ew8"
            @"5znnvu9vm+/Dbu5NNexGE7e6436RcDeCBSH4TsvlC80y7uEleGye+A8t5PM1zlWPIjYdRh9chMePYR9fwh6MkbMBhZbBQ+AjyAmLUZpeKfBiy8"
            @"8x/JIGe9swAbRzcFYuz2sH+lmxfQ1m21o4Zy1y5QrizAgTD13Phg99hz1LLvlu/HWF1Dcjn8KVlIWgAgxkJesLCds2g/+Oa+Cit+PUFfSdsRlV"
            @"3ld0JOdiusuvc15qI1MfI1lc02jMcuTQfh5+4EHuv+NJfnXXIt6RKs6Uy4SjuNRahi3krWU9cLkSKGN40grKAiZC0MMZklUx6pO3psdVNqShNI"
            @"sZn2Q0Q2FdH+XxVeTGYryxHRQH8pDdxb1zlkogiMKEHc2469skU2Lk3iPIhUWEJzBGES9quiGU6dGmLSKnGB7L8K0fh+yehL/3XdwwJnzFy+FN"
            @"V2OffQQRhwhpcBIscqGF50rE5j7Uy7eio88y9sFvc+nMcXadVPzqZsMVl7rorMUmFiVBeIJo2RC1BBkJVkjE8UXMbAO7rR+1QqGUwFegleC71n"
            @"CeFewyTf7Wl/yd10u2UYNqEQ5rzK5dWCdGWgcbOchiAYoCrx1Ssh0IA4YxnAT2C8U9saV1/mamNwx87ZIR9+PvXZunZ6zA2Oh6hkcuwxs407dO"
            @"PrIkSArPdS0D99ntP8lifx/ypE3hpNhAWcAYliEXBguCgT6BGk0oXLqVzOs+jN32+hR3L4C1Edhde0z8zGZrprE2SMltQiKEi1B5ij29bDv3PL"
            @"adeyXv+csTTD1zJ7/4yeP88fv7GZ5LWCkVW5ViI5q11jIhBQeEJGcsPQbGsuC+OIvalyALHsmhCHNSo0houR3qhQ6LPUtkRjMMbOmntNFn8HUX"
            @"UNp0Pe2ZBomByIAVfsrhmm4j9xxFhSE2o0BbklDCkkE5FiMkOrHgCYoFn/t/nXD0CcM5aMZCTfi21+N882++K5pL7+HoIyQnpnFzWRytQIQJzL"
            @"YRHMPaXyBfM0DmrP/DVZ/6Je0bbuU7uzUnAp83X+SSGUkwYYKxEjqW5WnB8KjERhYhJbIVYR6cgfN68QaGkc5unFRQzDwwYQV3RU2uMhGv810u"
            @"tZqJRFFOMnhhNq0e8wqetehhQ/BMjsVJh8lJwa444HFpuTPUDK0z/PZ376TS//r74NDHU61lC0gwTGL0oVBELQQaSy+IK64V7oGbTPMpcpk+Ru"
            @"MpXJtCCg0EGWtZKQWb+jwqowHyecOId38Kc8a7hRbFlN5ik27ZIbEMvVeIk/dKNY/FfU5ubzSYJXS0kI4kjAuywujWK/jIl1/Eu/6yyd5//gPZ"
            @"r99EKdQ8f8xDO4a4YfBrUDIwIQVjWYeDN1dxezP0ZH3KGQ88TX+SIOOQqWVBfVmQmQrIHD2BfeSHcGbAGde+ksJd19HWEs938HvG4fCziJ3z3f"
            @"pHQGARWQhnBSq0qbIpSZ9TgccvbjH87rGAq4F4fIK+v/v/cN+xFskd70lmG4hDy4hjc+D5OIWRUayxmOPz2JljKOsiWhrW1bnkl9cy/Mtt/MuX"
            @"rufLTx2mughve36W4c0S24kxoWXxqKS3N21rrQGUTD/sxxbJbmhQHMgQzIW4UvAssNKRnONLbm0FfJGAibDJuocdxncLVpSgvyJxhEQ1DJXAMt"
            @"uE+xoJz8aWWUcwGWomBuD733sNlb4sUftfb5J0UqMFKZGpD0x3HuVjySJEEysP3mQnf46c3UXr2YS257FKGUaMJYwMJQtjJQdXBYRn7kB+4FtP"
            @"OWvOPxs9eZ6w4lFkPl04tjucEivuE3LpFuzc1elwzjwXe47synVIiVwsoaNFjM1THt7Ahf/4lW80r3nFB+0n/g9J5yRi4wrEkSX6djY40xc0Hc"
            @"mvlyKqswZJi05WkXV8tmUznGkKrNIOPXFInGhsAOakj9MoE33nfh6aMkhP4RtNpj+PPzeNPT6fAsUqVQgJadFtSfOwoSBNOpwtKcIFlx/eGvK5"
            @"I5o39Ja55L2vYsVHX0ZpcBkdHsA6R6BaxT51DEcI2oi6o3MFlHRJTAc728YJprC6jIjWAbvY8NoBvn7NJ7jq53v53tdvZvKmw7z8Wbj8co9szj"
            @"BzTHPiiMPadQbT6X5+CKw25OZ30zPqsjgNZVdyIEjocxzWepaLEsm0hkPacrIT09uB3nnoAUaBYWC1K2hKyGrJVk9QDDXnbyrxqR+/n43nbCcJ"
            @"HsF1mmC9VJKD85x8GJW2411jKSHaJA/vxZs6StDo47C1nJ93CdoJLaPxHYleimhefimlr/5KqIHgBSa6zgq17V7k4PNOzaLEaRhFYy0hVvEcMN"
            @"flAf0/tMYUVBMyhT90fADM7AcLl1/18eSPd03aW//pZ8o8SvL7EJ+EFX1ZLt63zP0LlpaVPKEthzqaOi08Wgw6DuPK5Xw3y+V5jw1IssqFrR5f"
            @"3TfPb55pMdHjUJSQH5QUwoMpMd5Lyc3CgpSWuSOCcNHQPyGIrcfhRyN+9EDMb7wSn/6rF9/+vvdffdXgWh84hAmTLsnwQezCEOLQNMnKHJlSaZ"
            @"/DQP/tSSZ7lQXsyVY66Gk9DPk1CJNDd5oo1/Kad57PK9/8fH71i3t5/Nu/4egvDrB+JWzZoKgfs3RGFL6TdFt9i9bgyoSh0TzVxyDnpJ4U+Yqi"
            @"2Y6pYJGu5FBiKYm0cDTdOVmfI7hsGMZKFl8KdFtzYgHMm1/I5V95H5mhmKRzL0pqsN2oqq7FXooSdWc5/K+5kk0JXhxPoB7wcKx5WSzRYYKTda"
            @"AdMX3NGoZ/9I+POIWTD+vwhvOlswlE7j7bJXBYa5+7QehgOXGtMFUsYUrfQKSfXzd/4vQ03crTC1xIH6SDiY58TZWfJ+wb/+Pntnm9VeO/xk7O"
            @"YO6fZPhQk0uIcY1l0aY15yKSSWN5Nkl4Okm4BeiPXFY7Di/pyRIuNfnxnja+VJR9i05gcF0GJ1xKbVx0Fz2TgqgtqU8KSnnY/7Tm+JGAnd4Qqz"
            @"79ssl73/7isf6R4lUwSxJNI4RFuEVo3IvwjmOO92KqizibBtGO94hTE/KfS9n8VS0c5PEFckEZJ9yPae2Bwg6E0FibIQ5mcNwsr33ruVz7xo08"
            @"dPPTPPCdB9l7zy5W50Kk73HWZYq4kcIHSAH1JhNr8ux1JaXE4CDYPibIdwTTVcGDjdTzdAhYgWXICNZa2JaznFsWlF4wCqsL2KVBVl74l+RetO"
            @"Fea++6LGnvQqpU4Xlqkn2aMiFsFzMXXfWnQgiDsakzT+JCqxlw3FpONGNWGoNpGw5fVGHNTz5ELl89X3d+jnCHsFiwc59G5G+CzKNQxtr09YTV"
            @"CNsX4u3wJaeMq+qpUxgGbAeSsLtlnVpJXWmzGEE4a95jdZfEXni94LKND3PjR8+3B+axLU2USKwx9CDQ1jJIKg44KAQ1K2hgaSYxxk348XyHTU"
            @"1FryM5ERnKSpBkJeNrDKLZnWB32b+yKJjcKZk8EHPfssKuPZtNn3kjH7rmgvlyoToGNaJoMQX9Vfc9JzOI+u0pE+9EC0uELBVp5vJfcEorxm91"
            @"K700XUX8bJ1ydRhHWTh5F0ysguwYwti0UjdtjI5xGndxyRXTXPy8bey8bys3fPMpbrz+Gf4iSLjiJQ56yYAW2GXDeE+H/JDH4MmAPk8x7Fr6lW"
            @"bjmMfCPjjR0lyiFBVjWe/AmqJksFfgbVSYN70Fdrzju0aufG9W7JvTwfcvwy6hnPypijVlA9jnjs5TWIhAphN/2yWbWZCeQfvQNJamNey3glVW"
            @"sHfEYcUPXkmhtA7d+WNKbrchlhmEyIMVj0AIYuXHhV3zz6nCNINlzreLdxI8vYfWvjpJGFMcypPfsAqxajW2pyeV3pBgrdM9UgeB8Z9ZKt9DZE"
            @"5hEliz/oLocWndY1WEdRlQhvOMZIWFY0Kw01iKxrISwXTqFERJSLb4grGKxVMwtQhWCvzIUD6jyIpSBzutwZUIZZG+4rZfJfzmPsmG553HFZ++"
            @"jM0vKODkfTAHB+KwihQ+jlJd04s4fUzdiGgsYzJriZ5ewAN0JosqlxecKJvFHxqEnGJypsPAsw7+mgwsNbD2N4jNf54SuEyQkuYcgVV59OwJpJ"
            @"zknPOK7LhunJtvfSHf+dd9VK8/xqsvAeMIgiaUcyHrtxeZPxIw1K+YOAMysSSzeZD+Q23GqTII9Nk0xmRbj4P75g3Y/++LMPxyIWwbaU/+k40f"
            @"GBCqgLUSS9QFpLvovRBdDP85PohFpgYGNj3erNUIlWDTDhbbvRD3WMvwVzcxvOklJJ0HkDIA4YOtdXeykwiWUhDSFj9mnc4/w7Gf6r1ffaP+5s"
            @"+Z+lPIsWnY14SahYE8DA7ew5kX5xl5+7m4F78YRAmBBjkErLoX0fcFyHYXfYzVB24UTv4++c7PEf/6MZxak2aUKjQmhGAlsFEIDks4bOEpoCYk"
            @"wlj6yoqCMhSkZaxXsjhvUQZWbM3hLy+TBOC4YNqS7/4M7jVreNt/nMELXywR3t1QWyJZ9hD9r0Q6pXQntTZtCpTEHrgZMbk/DX4RYHYvgXJJ+o"
            @"ewvoeD5xEWi9isz3ytzaEHW/RvKmFNiJg/imn/DLHjdQgVQtRK1RCZDNIrQBKhaw2EfYJXXFXg8q09fP8/fb503RHecF7EyLhELwRs2tbP3b9x"
            @"2DEkOOOFLplBh6VmmU7QpF8K1hlLUQrynqJdN+Q7bUTPH5DRyJyR8wOCvWknZcNTPNPT2nHRXThCCKzo0vXEKclLCjTKrrEdyoBK6c9awnwi8K"
            @"4yvPDac9HRAlKcTEmrXTOD1EUsSBegXItQ9TH96Ous3b8bsXsB/yeGkapHFcNIV2deWYJCCNl72gTLd2OXDuC99H3gnQ92cC+i558RxX3Y2qg1"
            @"UzcJls9HHMCE89e6619zXf291749+PAPSRxFbC0dawlMmn+xWkqmtGXQwllK4Fp4yeUZBgYjmrtijs8pZmcSsoMZNo5qWkdDMiXFsactP3zMY+"
            @"ClK/ne2zz8zIPYBYNWeYRykZli14x0PmUoSolwPMyeu+HozvT7oiJ41mH5eIuBvI8aXYnbU8FZbjYZWLue/EAPtZklHrltlnPeUkIuzkHkIBvP"
            @"YKoxXHoe0q1iO3FKtPIyiE4dIR2syJBUO5SbJ/nYW31uWdPHN75T43WzAetWany/zspteZpC468qY5TFCQbY5B8FY1kHrC/7ZPoVJtJENx5FXf"
            @"wjOCccEGPPh+Rg12qwhjyl0xdut3BWCLy0A+vuOhaV7kBW/i+BFwhp0AoaAmJrmclZ3vbRFUh3PTq6G1QOIcLTQ0FrTVcJ4SFVi+j6D5P8527y"
            @"EwVY1cvU5ia3P9Xm3sDQQDCKYEwJrlwvGDpTgRJE182SNP4b5y0XgF17BsRFax+z2GdTGxtbBdFGiCWIfv/23Ptfw7Gf/hb50AKJq9J4TpkS4x"
            @"rG4gnBqBLE2iCEJSMzrLjCYDeHPP+Q5NEnYOX2DHK6QachuONhwZ/qWd7wkRwXnHUSO9si6SkiK+V0h03CVOdkZlN+tJcF7aAfuxNxZDcy46T0"
            @"mfEhar8xLCaGSi6DXbuO+nIdJ5/NEA2P4hVLZJXg+OPLHN6fY4N10dUEkSj0w/uJd8/gvXQD3ro8NmyD66X1h0lAW1QzxLQlpt3k6rMCVn2mxL"
            @"/+s+GKasiL3SYrVnjsESOITeMkzjCF8plsHLiXnpHNnJlIWseOsTQXYZsxriuJvxkgX/V7cu/bjk0az/k86wQSnbLyVNfXR6ruwvlfPhZd0Dfd"
            @"q2IsAVJaYgNVLItWsPblktWXv5S4fRgl5kCOpLQHIboLUqWxU6qfuV9/l9and7N6Uy/HOxEP/WSBew9FPBZb2kJQsJpDCKIEbtojeX5V8PaLPd"
            @"aN5YkenMac92PU5i2vMvGDNwlzd7cBEKlA8pTBVud23MoK/L+5huor/ptsuu4JhaBlLUukzMoXrBzk+NQyj4iAtdtGSbb7eNUpfBmRHdGcMxzQ"
            @"mY24+VHFiZLHxz4tWNEzR3ISZDGN/yYOU9WpdFLmoV3E+lnMYhuxaydyajKlDwcpbSWxK2j95gAZQFX6ECsmwlIxj/rEJz+J6zp3uPfe/e7FyS"
            @"lUEDPlCc6+wsU+GmDagjAUxIsBrZ2zhIsRTp+D0+en8HN1CeoR1ANIDMIKkpplOBtw1lmK7z+gmDlsOdsLKZ95MWte+iqs+/rDSq5R9qnv+qUN"
            @"V5Ar93Dy3qcJlYPE8kACu3BYL2o4l56L8BoIvYjQUQp3ZCpYuzn1U5QKK73/1emYtN6wCYIQYTtAE2vKyOlHCE/O8eBtikel5pN/P8Hwlmuw0T"
            @"MI5T23SK3u8kkSrOqBQ7u552P30nc0w/Gs4Z/vavPwXELOwLlCcK0wvGm4yOYo5nwEZQ3P1Ax37U0oVQQbX10ivnc3uvqHN6r1ua6RVYywtW5W"
            @"WgsbLSPiBWxUI7flAg7cfi/ZYyHSU8wnJjULFoIlwNeGi179IvT6Gba8/2LM0OWo/jkWawPoe+fY6Ef89H7JwrDDZ9+p6bcdkkQiT+VAJUk6MY"
            @"8DRE8vsqeMqYfE9xzF/vpx1MIy5J1ULRtqxOpVNJ/qJ/7BAfp9h9ymDQSvfdMrGlI+6zhC0nCc+3oGBpnwfSZaAT+/scm+Nw+yqbdDMB1hHEUi"
            @"FUlkaN0xSf2xefJn91A4bwSvU8QJpsAITCCwOm2ekxasjDt8+R0ZPvOzLPbRmNdc2Qf8RaqONk8+7PZUzj/2o1vpnwuYF2A6Ib2O4k5rmG9ZXt"
            @"22cOwQdtsAIjmAyWxFLvWydMt+nK1jFM4NsZ3JdPJs4+dc6OmaMNmk66cTpXZtYep3cCgRrN4EZ249AxPHSKVTD59TSlckCINRPiqOOPTbe9GP"
            @"C+7PaH72eMgwsEVJxg1sVZYdF5TI/utP2fAff0V4y152Lygy0jJl4bY/drDScNV0wuSPn2B0ooDaeiYiOpG2+0mAiNuQxAgMpvMEXuUMSu/eyM"
            @"L9j1LSlhaCILXjYkgqdL1N5+mj9F8iwe1Den8tEFtspe8Eg+Jx/uUWy+BWl797q0Z0YnSskI5NbVoUKAw02uieQaJWls5vDpM8NY+7HOB5oAKJ"
            @"6qTuEbbgYEbOovah+ygDpUqB9qoJwkrl1mLGxzFhgKr0odeuY6yvjF+rs7YJN/5nnc98dgTzXyeIrU1dV7SErES3Nct3zdJ4aAl/fYVWqchwtk"
            @"U5p9NSvSuR6YSKnnbAv7zd40N/B/JAxEdYLBrzSB1bxUyV2Vk7Sp/jo1I7Jx5PNL4QHFkyTBrJmqN70ee/FjOnkHdMMXXz7dz14FFe+f316aJI"
            @"GundfDr/4pS41HZ1Y4CMQESIlsB2YArBZTsEMrORODmMo+PUxaLb0aVmUDFQwhzfw4k7lzlpPb4TJZQFrBJwqbVs83zKcUD8qlehzx2/Pfuha6"
            @"8q7T/IRU1FuR0zJ+EJafnb34e0+xzW1RTc8AQTE2vQTgsZtlI7G91tDIRAmBbUdrPm+YP8bghKs1BX0DBp9zhiDUUl2fvUM+kg9XCAmbjNKrZf"
            @"m9Dj/3B3+2fnb3b5xMtjTM1glUBKi4yAjAXXUm9IImcMuzdH6/r9iCDC9UFkFWCRxiIjgT1k4HXn0Ln1CP7ji+SVxGR9xJnbEMUiJopwms0mmf"
            @"5+5Nnnom65GXlkmhd58M83trj3tUUue/EojV+cRBdUyhPDpCKDnAM6Id43R7Kmnyc7feSdgP5yneFCh4xvyWYsjbqg2G7yzgvhnqV5MD+oi/aj"
            @"iMwQJ0WeXQa00QwIiyckM0BFQRwa7jhqWRvXiG//BYs/+SN7Hl/kJ/ugMCx4a0WQdOaQSR10pzv57T6sPN3ipxclwooAESXMNaAmNJevK6RFc7"
            @"QzvYjSSWuf02bmFhELwsef5eAj8BMbkQjFRgEbreUSR+HHEU+Wehh+2SaGkx9dZbeuYaZnO72dR9nuuhwzloeNwXcE/1RL+HQChZubjF30LPKi"
            @"LHRq3VqrqynCIDAk9Wep9I1QOE+y+FuLkZbYCLZJgSsEh7E8KuDixMMmSxD9C3ibb5pdHCXjw0euJs1+dwReNj3WG3XJ8akMi6YHt9jDmnyDYO"
            @"fBdEfKOxgMSZJaD8dKIJY1YvsE5MD+7dNU/AzYGNvbR7JhK47vEndayFKlgjCaYGz8autm0b7LYCnDa7IZfvXxWWbHNKXze4mW9XNCNgtCW1xH"
            @"4mcUq7xlLj9jjtVDDrVwgl0nV7P32CBHF/2u8YFgvAJnmUMki3cj555BLj5EUFYsJ7AP0EYwGScYIVAWerDcNWPRxQKNb/+OA9ctMvm0Qxg5DG"
            @"QtOElqiRLWEOEyRPX03Eza6YIyHYSJUla4jrC6DUbTCECUNJtH+rCyjgjnsTqGuJ0eJXEHG7WwViNrbWYfX2CvKdFeuYaeWDNhDXklOQpMGkPr"
            @"gy9kcFOVJKrjeAdovn8Hx6VDhGVewpAUbEg01URxa18vzzwLcw9OIzoyta9J0veXPuIUt4oXER1N35Yss8CySc1KslKwU2smteEkmmrsEfYkqK"
            @"VJCPaTzD7KFUPgOgbfkSwvSPbtcbl/Z4nb9g6xLFeyacznopUnKAZTZAsC15PYxGJNtzxCEi8bkpEh7Iv6iP7yCbylHAxXwPfRK8aJN24USbuN"
            @"6/lIISW63UGPr7xVrFmHm/GIMhnO29jPOdOWf3//PN52QWVLmSSwYCwKgedDNm/xctCZM3QWOvSpE5zVu48do7MMlz0a4QD37C9w68MOtUDSnF"
            @"kgOn4UefIEHNxD30qJr2DeGnAUw46DMakNywoEe2uCg4uGyn0eWzVc6BlWCejJAqoO7Sp0mtiwhYg7kHQfuruIdIBIAtCd1OtQWAINw72WolNC"
            @"i6VUUWISbBJ3ncpSY1GLQe9b4MF7Qg7Gml/94AV88JPvpuSUqSaa40bzzLqVnPnhMWRyHCFjTDDF6pdpGi9bwx6t2RMnhFqz/ryL+MFNf83ml2"
            @"/m3gDqxxYQLZXa5eo4LWpj3TXTIs1S68T09eVYVJZES/JC8ESi8bpDxLqAofEiqlSFoAPtRYIjexjNwtMHJDfd6nD3To/lIMe6jVledUmdS8af"
            @"ZVAeIai2CGYsni/w/ZT/LLoKyKSuYeUA/uuLND71DOpeg3rFJqKsh+gtYrefDf0DyCQh0RqpE00chVjXQ199DQz1wXKN8NwxXrtjiIFHDF/5cA"
            @"2vBwbX5UBB1kvI5k7t+ukMuDMvSLSDbltEq0lPcoLVapLNowG5kuK2vQ63H4qZ2bcAc230TJue4Tbl/jzaWnbHCW0pWOUoEmtZ5QpoW+55aBFv"
            @"SxnpFbkPwW3WkkFCWINOFcIWRAE2DtLWNAkQSQhxkO5GSfq81W2INLUIcgZcU8TSRCYGoZM0e0PH6WvEAQrJwQeqPHkAdjVb+Ed/yhv+4SDX/O"
            @"7PGLjsUv6kLXPX5ij17yMJOwjZxtgYFT5O57UtrjMWZ8V6Lvi3T/KXv1jLxRfexJ5Hn+CIhaXZABab6VQ9SlL7lDiGKIIwRAQBNl6kz8sSFFMo"
            @"15ziWkvBrIVeFzZsK+MsHsHMNsAGPP30En88LNi5VzA0CBedmbC6UGdAzUK7hW4YNC6daYGNDFZYpAN+1uJKjQkFue0rKb2qwO7PHSH4SYT/vn"
            @"PQr9qCiBuILSNw4eXge0RBiHIUzvLyEn09PXSMppUvHvYq7hrOXoF42Wq8N1zFW9/1f/mbxxM+NNviS691WbulzFIQYxeayASMTOuGuG5pZiWl"
            @"UlqoolIdmVmO2VpO6Dtb8PgNliefClhzkUQHhv6eFts2lzgw3WJZSp6MYzYoRUEqaolmTMAvb64yWC5wKzF/SAyhgBWuS9JoIkQdwlMk/iTtoq"
            @"SbWvSn5WDXECtMTb47ESIS9EaWMFYoPZ/GP4qg++9tGoWkY0QcU5sJmGtBG8n+xzL0v/xB1pz9FOM/eyEn/+Nazn/Bn7BRESl6wUqkrsLSEc7Y"
            @"FrD506/kRa9aTf/wjbB4kHCmzMGpmCaC5ZmE1kyHTK+BdvM0iyDFzCzoCCNnqPR5iAqY5ZQikpWCwxamrWFDv0P/Ook5NItC02pr7nkyZEe/5B"
            @"UXaCJt6CxBaZVAuKm8XGYkrZYgqiYoT2C0xbEGHDB9JYZXDRH3NLjnI/OU7oSBV66D912Nk12DePNxqAxS7e8/3wk65EtF6vUGcmzFCpbrDTwJ"
            @"3tp1l0VuHsbHkWcMET1vJX2fv5KPuIaZk5o3fS/id3d06MGhMlJB9eTI5AVSa0xkaUwaWrEDBnRiKZTBzUgW6+ALy/PGBCeejEEo9BJEhxfZfn"
            @"6FoiuYSdEmdJda6iEYRHJ4OuRr+xa4Lw5oGxh1JWNDEJsOIo4gTtIdJwrSOziOurtIekfbMEj/TrfToVgsmJ2HZ2cDnKQGrTBV7wUBhAEEIbbT"
            @"gUTjJhYpoYbl8afbyCBL3GjiRjfwno89zcbVEba22B0TRNA6gW21qGB5z3v20e/9G/HRg+C5HHvKcnApoSgErQVLraaRcQcbNCDqQNhBhGH6O0"
            @"QxNgrwhxyKvRB2BZdLvsOyo2hiuWhziVIpwszEiCZMPhVSmI44fyXUW4ZWR1AZkBQHQBuLjSwhivZJg0gsyhjISkxfgVz/KP19FfbtnuEfPzTL"
            @"Q3dq+ocV7lcuxJ79Ilh14cfFpSN0esbxx1c/qoym0WgwMDiAc+LESYaGBqkvLeGNjU7lXvxK+N7/xSgHNjSo3dUks2GClxyd5SfNkA/dHHLb/o"
            @"T3b/GYiCWz/VmSQUO23yKbMboFaiwDCx1UFvp6YGnR4jiC4QHL3btC5vcoci0JNmDtasFZa8v8cd8yOSFodnnKeQHjFlYIwYIAzwpGsKzMQ09F"
            @"pFhdqLGx7SLyqZQIY1Og6zRLXKQX2AlYnLJMzVhqCQRhB+IAG0VpZpbocnlMmNZFSQiOoNU1kHr2cII+anHWKHTHhalDKZOPOcj2pBhhYwESg2"
            @"lp7OL+FAVHQgCPP6yxGHJCYYRBKbCxTp1OTps48ZzI0jMwYJBFwSyWnBTs6sQsWUHBha3n9ENtnqgGri958glIgrTaDmNBX69lYNxCBpzYQn+R"
            @"dk2k7IDBDO1Ikpt16JnzOR43+e1Uh18/naAtnOFI5iYmGPn5AvKKP2D1zNf43SOYl/0LOptBtBqUSmWmp6ZxxsdXMDszSzbjQ6xZvOh5Xxn62X"
            @"9/OvnGAyTnL5J7+BDVrMu6niJvjjW3JJobD2huPxpwZU6wXQuKBQn9gvywh/At2TGfDQMK61ryJc3AgCGoa0b6IdxtOXBIcslGaC1BiTkuv3KM"
            @"+/YtUxOCI4mmRykcYxmTgjOt5aCFcZHOQQp5KJYFkqRrPydTmqZOsBqE1F23+VOdsQXdAtFiqQ46sLhAEnRSv8UkAONyur1EI+IE22lQ7nfwHR"
            @"iI4fhswvJBh77VKYdcJE7qCR60oDmF9YYQnXZq/NQGoVXXJ0hD7PLkrgQPEMaSKwgyeYHoROndotJ51SmdoIhTfZGedshImOI5EWEby5VrCoye"
            @"kUfNHsRzBUEgeOgxzZoewUgFPF/SNyJZaAtsS9FcjDm0nMNtdvBrGZI5SzyX0K5F7BRt7gk11RhGheRyT3Khctg62cb+117iEy2cowfh0hcTbb"
            @"9IJI1lsn6Ger3GwMAAzrEjRxkbX0G9VsPUlshdcOFn6qu2frrwzGHks/PI7Wso3P0UdwC+lFwlJNs9weOx5rfLlt8qS6llqMwIirtT84zARoy7"
            @"krzRxEC2x8H6gnUVwaCj2bsfLt7u4AUxslll68WrOOO3BR440WJCCk5Yw4AAbQyrhWBUCAoCDgLWs2T8NIueOOUdgcaKBBF17U9EdwGZbgaaDi"
            @"CbpHz3rrmHrtaxgYAgTFH6U7oNASQG3WoysXWADYOw8yQsYjm0G/qe/5xBqjVALEAup16CDYtpCwi7Y00DKidoHIYDU4YsKWW3v+giCgKaIUTy"
            @"VPoTpzyHbQTKUSw8ZGgfsNSFpNda6l1TqytftIp8YYFk1uIWJfvmFIefjbloWPDbp+HwksBta6K2pU1C20KNWQZI51sNoCmgKtL2faMQXOJJVh"
            @"tBnGgmteX85SbR2WtRtx/BKbgsb76K2PXJaEO706FQLLKwuJBGHczOzuK5Lq7vE0UhhQ/+JfEdf0AenybJ+AyMj3L+iSluw+JpTa8VnCFTJUMN"
            @"QVMKZo3mAWNJQKxSwmaHBWduKFH2BU+cbLH3iOWuSUMLy7qdMa98VZGBgTo6MPRkTvLCl67mif/cRUsInG6U5ggS2b3z6jKNbhsvSDIVRZREiL"
            @"ZOdUynaKYySS+G5LQB1anFJIwgiiGI02vOfIyJc4i460d9mhoCGImtNXDXr2TjWkX5JHSw7N+tOT+QEGukk0pg0gt/CrVX4JsUU+sITARkFUcP"
            @"SI51IipK0C9haNzDzQuYibpp0va5BWRFmquSODitkGA5tVzMIKhby4UrC2y+vAiN3al9W0Fxxx8ED4WanccEA0qwZVQxstphtCI5VDc8NZOwe9"
            @"phPkxEHuxqJckLyYgxjEjYKgX9iaZqYdlaXua4OMO9JEdn8dpNWpt2EF90uchaQydJyGbSXPnB/gGcudlZXOUilSLRCbZeI7r0YpF54dVW33Qj"
            @"4ugkZmSYazJZVBiwX6ZFXa8FYw1Huw5cfQjOOfdMrnidZ6/eMsPYiIJOCDMdqEmSOcETe+AXDxt+fSDhzocd3vDmEubYMvbQDJdcNMSVf+rh9g"
            @"NLrJcSRZquVwA61p6W73l5gVjtpjVP3Z5mjBphnzNm+N8GTEKmXVqS1hjGQCgFohYR1XL4XbOCUzbBwnajNTttGFVsvaSEunuZDDB93GJmDNaV"
            @"LJx0WDwhWJqRnFjwaQcJFbJUBg1D45axcUPWxpAIdj1tiLBUjODMXsPohT1pUd8G3NS99pSplbCpVNYYnx6nieOnvqaTMjVpf+2rV1Ewh4lbFr"
            @"coqNlefvFQlfU5yWeuUpy31dA/AFQsrPahLCEQHEw28MvfFewz1++jeugEHoY1wKAU5G1Kg5HWcLFUnF0sEXYC1NwiuuTivuWdyKFBOnOz+Pk8"
            @"nXabbC5HdXkZx1rIZH06QYDneSAN7WYL/xN/fbv5/R+vakcd2nML9JZLvHou4AEkM0ZTBqaly8T61fReuY4zXznEuZdnkbnjUI0w1Rbx3ceRcd"
            @"rSu1k47wLJlhFF8ReK226r8bJrxsnQJKwmuNEhXvLaNdz1j03mjGaFgHkMrhBkupzAFuCpBMZEavXWTI08rbUpcqz+X6MGK7uYWJJuEK4DWQnz"
            @"UtJeDOnMeGR7FDowCHmKvZhS0GRk0fN11lw2yBn9S+xalOw7rgmaeeIeQaNhyBZicus1Y1vbiGwLZiytOVg6JOgsSjacV0BowzMHAnwsGSu58B"
            @"yBf8EI0dLR9Bi0aQpu6pWQ7mgmAetkEeOL1PKSsGo5rA2v3zHA9gsM9vhs+ruN57nzRstwLea9z/O46iKLU7QkQYydBTsZwbklnB0TrHciPn2+"
            @"pPWhK3jsdsHMrw9h791L/3yVLAlzwDqluMQvpBThmQUS16LOuZDONS8Ttl5HuGmt6LguSRzj+x7O0PAQMzPT5HJ5rDVEcUTBybK4ceML+9/9Tu"
            @"v9xzc4FoUkRjLo57gkaRN88d2IzZdgVlky65ZxSrtBT2LaAfGSi6QHuziNMyAQLZBK0JiTHNtraSzHnLda8eyJhD/9uso11xTotJZpzDQZWz3N"
            @"2y/z+Z+72tSVxRjLgoUeBGH3Js0LmwoPmybNYct0axdpT6l5Ti+g1LbfpoF/iUA6qYp23gpqCwnhQYO9KIsIW1hpur6I3bQgI0iOHcPbcSFXPe"
            @"8QD96oiYRCPrUKKocZUyFepWuBX8xCyQW/DYMR1C12WRDsAeX1UbWWrIjZpCxnvqyfZGAUte8xrJOK/OguHGFsymHKeNA2kItZyigaIuHyosNr"
            @"XihxZw+j2wKvIliczvKHG6ts6pdYobn9NsP4SsW6MyR+waADA40YG0u0VphggXx2kcvfNgZvv4Jw9p3Y3RmYDKn/4XoqP70j9aBu1qg7UPQ8kg"
            @"//FTWrKXZxRa01SimCIKC3txfn2YMHWTkxQb1eB0i3pqUlBkfHWHjfe8TIrb+32SOHaCYtBvJFTCRxjhzA+ewORHsO6xwiCacRSYx0JI4vEY0I"
            @"Gk3oEST5EjP7DMceaJLolMNUzBlWjEluurXOtlU5MnmPeC6i/fA8r//oB0i8W/nOHw4zqiShsTQwlLra+JJnwVOIWKTzQSnSOqlrhWdVV8wnuo"
            @"tHCESQ2vcqF/IOBMYy2YLFB5v0XlzGS5rdNt6cNtm0QuJ0muiTDa780Ln86J6HONq0fOmf9tNpGoYyhkFPMuBJ+rwYt2CxGUlnUbDQgACBDSP8"
            @"4hJLWlOximsu0GRe+SKCB57BCwzCU2kneSrYRgiIDKa/jDoc0piPORhJxqzl/3zyKla4hmN3/pGh7RKnmOGmbzWoNRMu2qZwXYM2gmOHNAszgo"
            @"0XuAxvMmAC7MwibF6DjNKgOl2bR+Qew+1pYZ+/GqIByt85iZEeXtTmiLA4YUzpXX9O/ZKLRa/RVGvLFEoF4iRBSkmxWGR+bh5n9Zo1zM/Pk81m"
            @"0VrTbDbp7etjcWqK/jO3sfTJTzD4vvfRcSVxp4WTLyC/fx9RaRL54Qm49yiUfeywhyxIrHKJD09ijmhsXdGsJUwdCFCuQboSnQgcARdNCG6Ytv"
            @"zihoi3XC0g9FnxyR+QO+/MW95w8AdXP/m0y4PTCSsVLJm00AkBv6QgqzAdQdxJTc5st1iW0qa6QueUJ6FF2jROwoQCxxVknJRtsjuSvOipGs3p"
            @"XvqUwrS6LGvzv802JfqpnfS+6W186h+r/MW7D/DtyOJg0C2L3zI4XW2I6Ba6ma7bR3SqHOu0GbGSd09orvzaVURLA7iHn0b4KrXU1WkNlApeBS"
            @"KGJF/B/+0yJwezLE/XeO8gbMgfRb3/d29fmvnEdY3JG3j6uMODjzQ4d1yxeiB1APRUykj1FNSOG0QMTlbidhp4Xj1VX+gE24gxRyYRPQew69aR"
            @"vHMX8v4abtZlPm7TThLWrl6L/tu/FbrdYqHVZmBokKVqlUwmi1KKVrNFf38fTr1WTwN3jcFaS6FQoNNu0zMwwMLhI/T82buEuf9+m7nuvwl8l4"
            @"I2yN4B1L8cR2QM7lsU8fVHaR0P6ai0swaBctIL6rsxvWVFdUkiJbiOIIkl+45Z9iK4bTJh6I+S167YjHl0mmiweXUxDPj0X4zyuX+aZ28tYkBJ"
            @"6kCIJZN3CB6ThEmME6baJSFSwZyVApnYNAvdTb0UMYKoDVZLpJJ4EjIize7QswnBgyHJiwaRC9Op+kSb55AFI1FxTOeXf+TCV17MX394ih/8W5"
            @"MSkoqniLRhyhrCroyx36aNkSsEdWHxpELFli1lzau/thGz/tXwP59PF33cZQNrMOZUQo5G9BXQ0z5yf8BhL8O2xPCW54HnLtB+5s7rxpb7WNqz"
            @"ks88eZy9QrI0Z+nrcTh/q0BJg5IC5YCbSQjnLR0tsIfrqHufIleS+FrjNMG/Yhi7YR3x23ehdgucVQPo2UUWhWCV56O/+R9UPZeCtYj+Pur1Ot"
            @"lsliiOsViKxSLVxUXU5z73OZIkwXSD5MMgIJvLUastU6lUqFWrZK956RecP939eXP8BLgS1V/ByeZYvHWe/XMB/e8epJBXRAuaxGjcLtVWOulR"
            @"UMyniG/YNESux52PWW6fMtybWOFZ+/mPjGwjqUdw/W/JrE4wwWHKScyabYM88HiL47EhKwVLCM7qJBR1D/lVYKaXsFKku3+3BT99JOh0DJSEgr"
            @"htECtWEE+3aB2vcde0JLbwQgOVVgcuWYUXVLGdFA03icDqlGGRGIVeWqZzIubcP38FgyMN5u5dwAsNkYW8lPQqQUUIBhQMC8FlUrA1MUwYw/qN"
            @"lrd893yKF7+c5KZv4bamUigntphEdNONUi63CQ32zHXYGxfxm4qbOyGrWxGXbwcz3oP85h5O3HgP+Z5V7O8Ybu80RNOIzxermt5eh/ERg7CGbB"
            @"ZiI065MJNCgxYTWvKVLNnXr6eaKzP51l3kj0n8tSOYqQUiEiqdEPuVr7Lw8mtE0RiCOEZKiVIyjScxFt/3qdWWGRwcQrbbrS4LzxJFEZ7n02y2"
            @"yGQy1Bp18p5H3Qq47r+vzqxaTdwJCG0HsWaIdl5x1y+bfOMNkzwwmdCzsczIcD9+fx5RVIiCRLoWP2uZuMJj4twcR/ZZ3KZlTZ9iXGBvOGsHBR"
            @"PxjcP7ecB08G+YIZJjNI+22Fqq8rd/PkhfRnJCGzoS/JNQcn2EFekdnAiSOMXedGTRsSCKuo8OBIFFx+lFch1JzkkNw+csaClpH4zo3LuAHpjA"
            @"dAxxLIlDiE49AkOsFHbqAK0bb+Ml7/4zPvzAF1j9uvXEGUtdG+Zjw3RiWIgto4nh+Zs117w/z6u+eRVvue+z5M++kvj3P8ZrHEvvpG4UZ1o8d5"
            @"NRQ40c7SFecHHuXqJaynNwf4cVFYnsF4idEfFDc/yPafK9I3v40qaNvLNn0OYcw1mjHjP7NVpkWHW2T66QWg1qCbYgoeiQ6yszdPYw0bVj/PF3"
            @"y9z04qc4dCiG4V5sVqOHHLxGG/sXf8Hyn71b5OOYdrczb7fbuK6HtQbPcwnDsLvJ1FCf+vSn0ToN8XCUQicax3FIdJJ+NQZfCqLe3mflRRdd69"
            @"36x2EzNYMuePT397NcXeahxYS77oh46JkQf9YysuzgLit0rGgnLgsdl7mlHh7dI3n66YAntWR6Oebfrrycix3Fr3buxEVwVFpWnGzQKwuYzS2c"
            @"pQ7jAzF9mQy7jmpOaMFrPMva80cwgxo9XcW4Mk1U0gKtBbo76zEadJw+J0KDs3ol7lKAOFZl30nFPYlhh5KclcDCdIPyjhXonCVZbGBQ6aLU9n"
            @"RN5OUVGRZJ9txDf88KLnzXy7j0raNsOa+H8bU5Vm8ssu3cCue9/kzGP/0B5Lv+4XbvvCuKyeG78tzzHZxCFSsdiJ47IqUFaS2im0ehN57J4e/s"
            @"Y3gyx705h93HlrjqbMWKcYn6oeX2ZsR+QvJBTH/c4a3nnc+TMzPcsdwGrVhedKjFedoNgU4UgzrDQMshP+uxeNBy84GI7357kX2/q1Gy8OKeMu"
            @"VymeAVK3Du3EX82ndQ+8qXRUZAHEUopYjCCN/36LQ7+L6HwaJSzTOO6yBm5+bQcdJVd6acYCUlURzjeR5hGJLL5ohaLURvD9n77rPZd76LeHYG"
            @"MdiHF8PPmjX+lCRM2hRVL0nBaiMYcSXShaORZSoxVLEUpEPTJHzpDdfy0kKB+n9fz5yw3J9ELImUEfd2WaL3LSWcDVM0j8bsPqg4UHX54X7NPz"
            @"gx53xwB/U1dZKnnoVcGmJ7OqRWpFu3I1MjbiMk2STGv/JSxNQC5vf7+MnvXT7VjlmvFD8WgplEs/Jyn973nUn78B5svYV11Gncw3UEuaJFegK0"
            @"IVm2BMKHlZvIrFuFNzgE+TK4LvgZdF5C+ykwT8GjB5BNge1VsGwRdQstgY27Zg+JwDYN9ryz2HNLDfXdo2wZHuMjSZOSrvGuV7us3pXjvkc1t4"
            @"gWgxa2CcGgNqzffhbVTWfwkV//mpl2Gx/JPIZxFIMebFaSIDEcSyyHbKrsGERwkYI3ZwqstNDu9xCLdaJrXkv7P74upNY4QhB32/UwivB9nziK"
            @"cV0HY226sSQJvp/F0UmCchRRFAGQyWQIg4BisUi90SCfy1NfXqZYKdNeaiJf8pIxe8cdZ7l//me3hDsfY7+QvEA4eALuEhrXCqYM/EkYwsSSxC"
            @"lNI5GCjKN4fpTw0csu4oJzd1D7129TVi7WRgwA8xaWheEGXeddNyicd42gC5M0ljW52LK1oOgNwM10J9HmVCF6SokhTjuRJRKyGfBdiydBegXs"
            @"SIwcT/O+BhA8ZAy/UorXSYF9MMBZux//xesIntmXYmSug8KQyVqkayG2JJEgFIokComfeorGo0+hfPBzkkK/QPRo5HagH4Trw5iPnU3AM4isSJ"
            @"1gXRCNFDOzsYYLtjG9T9P82VEuFDnujTUnmg3etEYw+liW4/s8HlVVMrFli5LkjCHreIj9h+hbvZJ/fcU1/OiXN3CrhN1acNhovAh+j8HtjqoG"
            @"hGBYWC6XktdZh6y1NKzGX5REX/y/RB/98JhZrOG7imajjpfJoI2hVCpRr9fJ5XJ0Op10fYQhmUyGIOggs7kccRzjuS4Z3yfodMjlctTrdXp6el"
            @"iqVsmXSjSWliicuN86P/73yfoT990SfuJTVC55HuO5HL/xFaESXCAU64TgDAFnkxp8l4Wgp5tR4UWaa8/ZzgWbNtH8+n+SlQpyDlJJRgEXQdFC"
            @"TVp+0Vwiuq6FPVzB5gSN0CKMxc8C5UJqiN09rqxNjxpjLdZYtLXESVr/uJ7A6wHrFxETw9i1kpVOeieC5TpjaErFaFwkutng7T9Jdutm3GIRN0"
            @"nIlSVuOZWLJYGk3YQwMGijEFkHr+zg5BReFlTFIn0Hqn4aZxka6BOp4VFeYIsCCgLRp6BXYxyNvfAyOq08M996hjPqDqaY5wftJqtyho2zPovP"
            @"ONwUL+ElmhEp6DFpUtCoq1C+R3LfAwzWm1z7/BdwNDLkNYwIwSYhWCdhPYK1WAaBy4TDJdLlZN4jKWcojo/R+synaJ29ftL95Xcmy/f/woYnj5"
            @"yXLZUJOx2y2SzNZpNCoUCj0SDj+92dx0+/z/ioD33wg/i+j7GWOIrI5/MsL9eoVCrMzc8xMNBPtVGj1zpF58d/9enCSy8ke/gJ5B9u4Mmnj/PM"
            @"QpudseVfkpCMlGk3IiV9QlBAkhEQS4lvDJ+6YDtv3bGDuZ/fgJ6bIyddEpvgdGKMEGhriBEkFg5Ly4kg4pwjECk4IgxJ6HDpCw25F28jmp7DVp"
            @"cwKq2BnvPu6VosCIGUAonE7Tew7WwYGUKHT5L/leWptuWQhJqxzArFi0YG8GSZZN8ycqKOe/YmHAyOX4cQ4pYgDCCKxelcWKxFSYvvgO+BrABe"
            @"d6jZ06VylIYQpRJCtBCO6gbJRGi/jDjrzcS1GjNfuo/R3S49hR7+yxHcHSyxw0jG2w532g4tk1AQknEEOSFYISVF5WDaLWQnZPHAAVZsWM+GiR"
            @"U8cORoasggBMrAgBQMS8m4ktSA78cxR7Ug0wGhY3rzc/jRs6XMhRci9/4KzfB72ivWfaE3n2W5Vuuuh2X6+vpotlr43UWUyWTQiUaWSiWSOBXU"
            @"+X6GdqtNX38fc3NzDPQPsLi4yGj/AEv5bCM8NoTdcxveez7ws8wPPsyKX7+K4C8LJFtDVpUcnjWwURsWkoQla9mK5Z+U4gta83eXnsO7Lr2Ixi"
            @"9/xYFajUi5qHoTGViUkgwKydnARFegXDBwQhr+MwkIDxucWUFvTpB7kcCsWYGfl5T6JEo+Z64gEEghcKXAFYasY8iIKOXbyGlE5UrE+nXks6mh"
            @"9wohGJeSP+iYn+VjnAkfdUBgvxXA4jHU269Fn/MCksAlbBrCjjk9t+ka1eMo8FyLckVaDKuuTzA2jXdyR7C5F0PfChiIsL0RZvwFiHM+SnjyAI"
            @"uf/RO9j2boLfbyWM7lB80qK4ygEwluNwGJSSggKJLmj43lMwwJsEEHayxCSBpCcvz3t3FNfx/ff9O1vNRYzhOC9/sem4EFa1mINSe0pepJzAZD"
            @"/S0J5f+5Gv97nybzNz8RcpWH3nWYYM12UfYktVqNUqnE/Px89yRaolwq0el0TnOtgqCTDhL9jI9ONGEYUigWWVxcZHBokNnZGYZHRpiZnqYyvg"
            @"L9/o/eHn7k6qv8C6M3isHVjJypeOObJK+tGZ5d5/DUScuOmRwTUzE3RiGuUhTjmBdefSm89AoaX/wOOxcXaStFwWoiYxBaIBwHD8tYLsvRJKSv"
            @"EyBE6qhxBMOyEvQ1BcWhCP/CC5Ar34i34qfYKUNWm5Sz1eX6IFI4Q+Ul2YKHs6qIXeOAzYN9gWDwiGXg73BOtBi0hi3A7Qh+cHCa/FybN+Q8qP"
            @"rYuxXJyB7k1jx2+1rEoTpqfhG9HJx2hnddgesKHLc7+Y5FaiVXEeAk2EIe66xHyNdDpoJ1F7F9WxDJNM3/+iaNL8/Rc9wl19/D1ESBv957HBUn"
            @"zEpJiGVLFwfsE4KcTWdMI1oRu9lugnNqI5F1XY5GIf6vfsv5730zA+98Nbkf3sik77IQGXqs4PIeh8Jq6BkVnH2Gxn2xC88fQCctLN+z0af+Ab"
            @"32g5Q2r2f2wAEGhoeZn59nZGSExYVF+np7mZ+bp1QukyQx7bBNqVzGKVfKtJpNtDFkshmWqlXKlTL1Wo2R0VGmpqbo6+ujduIkvVde9kKz4502"
            @"/vgP8b8+QvRIBBM+rVFFfirivH6I/IhLRQ9mss5C1MG/+Dz427/CfuizHJ+fp64U0hhmhGCFMAiT4GiJxeIIl2FpOWQDxpXgEJZMNxcii+X5Qw"
            @"7O2i9hWHW+LZcfYfUQ/qiDEm0Sx0ULFyssmcIQbr6MrOSwKwawWRdRHkPIAzWRf8cA7/71fM/MfayaEvylkJTRXIfgc7U69UqZPz+jDJst8aFn"
            @"sNfFBMsBsz15Clv6ya0QmGYbJw7x4hBl4udyuwBb0eCBzWQhewlCvhLkFQKuBGfXHrP/M5v1V36P/DH0aZdMtsjMcJb3nphiph2SFxLPpjXLAG"
            @"lwdbp4YKNQKb/Z95BYRNCmaTTTxtAQkmNhROa665n43pchkuz5yS8ZloptGcnlGySTPREFz4IPUXkc+/hO1NBd8EiCObyS+MvvE53pafqHhpg8"
            @"OcmKFSuo1Wr0D/SzuLBAoVQkTmIcpXA9j2azidNoNBAIHMeh3W5TKBRot1oUikWWl9NpdKPeoKevj8bMDLm/+4TgijssP5rBK9Uwv3LJjmfpjE"
            @"nCkzEDJsL2JFxU9VhyHQrf+Qr2hn8nfnQ3QkmKJm0nZ7D0IHAw5IwB3yNpBQy7aR0lSLVhLWFYk0he2q/p+dD/B94LhOU2y9rXYc0Mcm4afegE"
            @"nVpAc6lBdbpFxT3OQMXgDhq8MthEY61AFoslLnrFPKsKDMWW52eyTLx0K+984hjB0Vn+KARfXqpxeDLiU+UByhtLxH8M8H4XQqbKU3cu4672Gd"
            @"mSZ2h9D+7KMrKcRXgSkckj+rMwWsGUhhBqK5YJ4BwhrMLaB2xy+6ewX3oIcY9LVmqUl2Fv1ue9R6Y43AroF5IslrU2lU+vEpKGTdOB1gsXx0oM"
            @"FhyFNZKqNUxLRcda1qt0sXmxIfneN1H/+CW2P72PiWeeYc3qAk7QoqAt/iof21+A386jnH2Y80ZI/qpF4x9+TKKg4PtUq0usnFjJ4sIC5VKZpW"
            @"qVUqlEEIQ4juoeXwG5XA5HSYUxhiROcB2XxGj8jE+r2UI5iiROKJWKhFGEozXNYoHCl7+E+tibSD5TwqkvY+4I8Xs8/EqWonCRNot0p+n9m6/i"
            @"bp1Ge5PYnxUZ3NcmcEF1s0SXgKIx5HMKR0liachbGJCSOWMYQWCkpGA0xc1lnNe8mujwlyxHf4zZOUty2zLLU1BdhKkWSCsYs5DTkqRQQSJIFg"
            @"OEAY3F2RDB/p9ihnuRCy7zRcHcSJly3xl89E8OG4/NcYMx3H60zfLnpnnHO8pcuNbHnSiw8mhEdQpOToa0Hu9wskdQGJqhZ1hRGsvjDRdwyy5+"
            @"2cMZ6ofoKahY1EYsQzsQ8Z9Q04+hcz24fRqWYq4Xls8vzzFrNEUhkVi2AFsErCG1p3GspeR5FK1H1KUzeEWfeKaGTjOSyGLoz3uU+itE7TZc08"
            @"HbVqX8ja/S89HXgTTErqIw6GCXJObwMq6rMS8sEvzNNPbyD+K++iXCWVikpTUDA/0sLy9TKleo1ZZPY2BSpTKpJElwXZc4jlGf/exniZMIIQRS"
            @"SqyxSCmJkxjXddPdyXWJwtQwUgUR9tyzvqAO1j4vfnM3XFJAHo2w85rkZILWChW10c+7GveL77rdxj9YI3sWkeMx8jcR81HMjIEla9mP5B5P8G"
            @"g2y9mxwdcgpSAyltAkDEmIEEQCBpcFucpOOHA79octeNjB2ZsnewxyzYS+UDAaWcYSQY8qkh8rk9mUw/Ud3MTBG83gnJvFGfcQ6yz379b891SL"
            @"jY8eJrt7ipq2JGFMwVqyUrCnoXnw/jYnZ2N6ZIaRlmKciKKweFqSrQvEjME+myCf7CDvqeHeVsW5vYb44yRy+jBq5XHwjyHKAdYJkbKDc8hh/g"
            @"h8oRny1SQgD5whJFuACyyUZBornhfp766wbPJ98jhoIfCUYm/W4cfNDscVRIklYy2VSJNb24t4dRb3w9uBAnLti9+YuPK19uE7ETKDPBJjF0OU"
            @"tLDOJ3oyREyehf7xf4o4DAmCgGKxxFK1Sk9vD2EnQCqF6PKAHKVIdIpUYFPetjhw4AB9vb1EcYyOE1zPIwgC8vk8naCTDhRrNXK5PK12i0I+T6"
            @"I1Fkvu6tdYr+cBxKCPfCpIk1wWDMaWce95/OPOxme+ZvV12OVDqIJh+p8DHv1DSGdMIPyIeqNN33iJY60cZ//nMa7I+CTG0s4I9rcaKANHgZa0"
            @"bNeWvoqk57tryDwdwW4NixIOG5hdBqGxjqItfIJclmitIjzTY3mmQ3t3SKIgHkxICjEZablxl+G/T4SscyQrtKVkDY4UGCRHbSpgbCNoGcMKJB"
            @"f7Wa5AsMWE9FlLxnb5p6KLaYkMVPLQ78JWDVdrWGNh0IO1YzDdRv/yMM9+O+Hbh2KetikmNyJgSEjGHMXLvQx7G032S8sggthCvzXsyOUx1iVN"
            @"p1V8exiG31Kmc3CO3koZazIMLHpsKBUo/t061IoBbLIBIa78mQ3Xvim85vnWe+RBxJiLLiQwodADLvzSx/z2D081zjrj7Hh+kVJfL9WFRcrlEv"
            @"VaHc/3cFyXTncmFHUxsCAIEAg8z0UEQcDJkyfJZXNYa4jjmHyhQKvVoq+vj4WFBYrFIo16g3KlTBiGeI4ilAp19Miryi97xU1i2xxSC8QhjVkG"
            @"+91v4b7mLULXbrF2+o/QPoZ5tkXrhGFhahFbnyduBFSnYja8soJ3xQp++uLDvK+W0hrsigrPLC6wWG9Tl4J1wmGD73JrO+CKlxaR52Q5emfI8Y"
            @"bgyJzmSF0zpzVtAcvG0CbBSYOjCLDkgTg2eEATQRNLgzR7tNyV0gSCrqkDVBDMWUuvlITCMmcsyqae1UNItgjJBgRrpWIEga8csqUCuRUuYo0h"
            @"WR+iBzRJK8YuS5IFS+3JgIeeDvmTFSwJ6BECp9s1Ni0MYLm0r4dXZ/IcOznNThIGpeBsoegtl4jCVJl6ILDc8wrNn39QsOc/m0QtSWXQo9hXID"
            @"u2AnfHIAxmkCt2AFci/XVj8bN7J+0LX4kXNdDjgmSzj/hVG/Ov11F/02tFMjtHoaeHRr1OT28vk8dP0NPXe5p5mMlkqNfqZHNZki6hzHEcoiDE"
            @"OXz4MKOjo6TFNBSKRRqNBv39A8zPzdE/0M/c3BxDQ0PUlpcplko0Gg08pWDjpl8t/uu/0v++96DPbuMUJHoGomd+hnfFL6yTzBE9M4s9VoVdCf"
            @"k21Jow1UiFo6UJl95tMd5Ai8wlLvtvTtjSn8MkhmJsmALOwGV9pZf7PcP9YcDsrXWeurXOYdKcixYwKKGs0k7ItemiUN1s97yBkpKUsy6OMTQS"
            @"Q92R7JOSWsdQxjCgBIGF5wvJeRJ2GcsuLMZaGjZdiL5IabWLVvN7YfidgCSO0UJSIGTTUpvBJUvmWUF8i0GElqwGhaVfgfUFJzICD4HS8EiScr"
            @"yxEFooCUFuoUpuRPGCjRswB48Q2A4Va4mMxVZSa+NjssmFFwUgFYNnC/b8OoZWhDPVpMfMQC/oKpjwAWThR1jFZHL3MDYwuBaS0SzilibJB/6W"
            @"+uteJWR1iVypRKNWp1QuMTczQ99AP3EYnYa0lpdrlCtl2q02nu8BEIYhPb09iHa7zfz8PLlcjiSOSeKEXCGdPvYP9LMwt8DQ8BCLC4tUKmWWlp"
            @"fJ5/PEcQJJjDs8SPTd/7L9n/o44gxNsFdzvJ5Q2+Qz+Gdl1r1xBWQLxN9+mqnH2hSHBUEtpt2wDL2qQGGThPFeDt5tmHr/MlesHiaxCUv7jtEU"
            @"kvF1a9jlGo7sP8z12vAg0GNT6XNFwYQnKEuDRNDWlsh0kxUFGJmSu6SEnCNYU3LwPRD1hJyjWRhxuee4YGkhYjuCHY5gcxdO+YNJX9NLvVppAv"
            @"Mq9cCfSiwnEbi+ZLVnmIgMjiPI5Ry0gdlGQmzT5D8r0roGAdqmoG/HwnQMh5OUt9YBGkBOCD5gDDtGBjlzZIz8/mdRrZCkt4R31ko68wEPD05z"
            @"5ZcjmEtQ9ZjjD0niwwnDa13qBUU5o8jtyMPqDPHjITPfqdF8IGDAg/JFRfQTDXjLR1n+xy8IUW8iHYcoSo+msFu6hGFIEIQUiwWWazX6+vqoVq"
            @"tkM1mEFKfhjHarjdi/bz/DI8PUajVc10WpFEzr6x9gZmaG0dFR5ufmGBwaYmZqmp7eXpqtJtlsFmMMOozIjQ7R/vZ37eDffx5bbvLsSc39rZhj"
            @"wNptFc76s9VsWtnk8FcmeWAyoudMl0svcRl8gUq5mCP9mFKJhWuP0l/ZhIkCzJ1Poy46lxllaD24k19awTesxU2zcbhAClYry1BBsmyhpQ19WU"
            @"HOS5U8zik/aGFPW5dYC9mMZOWmEuOjPWw6c4GlguGWBxTHftOhZzLiXAR9nqSeGDxfkbdQjQ1z1jJvLEcQLJQkZ60SjOkkdThd2UPJ1mnORRye"
            @"NzS6Cmup0vdhNMwtQz2wBAaUtIzlHRqB5XhgOCjgpLWUEPRLyRe15syRAfLbzybz1F5kj4vz4m0s3XYA/bEWg8+rEz/TQlUTjPB44C6f3Ts7TC"
            @"xbXvJnZY6UXeZ/22Tujg55q1nvO/SPe6jpNubPP07jbz8tpDYYrUm0JpvL0Ww0KRQLtDttHMfBUQ7V6hJDQ4NUF6sUS0WSOMFicV23e0r1I5rN"
            @"JtVqlXw+j44TEp2Qy+epL9cp95SZn59nYGCAhfl5evv6aDQaaUEVpZ2b57oErTbFiXFav7jeDn3lC0SLRzjaEOyptXnGwjTARIYLxhTe4wEPhp"
            @"p3/Pxszr14keTwEmJ0BLWin/B7c5jbenAyLrpToiOh8NvbuA7BV61l0FoywBGb8odf48N2z+IWFfkRSb0TI3Q6iQ7iNC9LipQ3nfEg50MuI1i/"
            @"VrDymjXEmzfgZxpQarC8ZHnoF3Wq/zXFqsMB64DS9iKeSqg91mEnguB5JQYv0Wwud8hGPlV3E/mJHsTuPTz76CwdDVECndRI9pRJGkJAEgsm5w"
            @"0nAkmP65JpxrRDy92xYKc2DAOrEBzB0KscvpckjI4NE77j1WSSGSgKkmd2kv1WGbN4EnukhpqNCfpG+OJHA7z9S0xs9pnMCLwnQoaxrAS2ZT36"
            @"Si5hI8L89d/S+OuPCNtqpfmrIu2w2+02nueloLrnYa1FG002k6PVapLP5Wk2m7iuixSCKI7JZjPUGw3UBz7wATzPS1djkpDJZmk3W5TKJeqNBp"
            @"VKhXqtRrFUotVqdY+vOLWilJIwisjkc4TVKplzdnyhum3HQml+4eq+xZOMZjwmgoQBazm6nPCHEwlLnmROG8590QomzlaYpRqyUgGngF23Btsp"
            @"YM5+AclcjfK9d3Abki8FCQNY+oAzgO1S0LGWR7RgwFGcpzWDRpAbcOlIS9i25LOCSlHSW4TeEowOCsbGBCtXCAZXGGRxEVlexhRWkLhnkx8eYN"
            @"3lhomXZYjWV5A1RXG8iRl3sGeP0vd3E2z9qzLjV/Thbr2EeN06ClckuM4uxNE5HCswsSVIRGrzk4jT0IqJLYk1jK70OLfHpTwVs9i23G4Ee5PU"
            @"J3u4S8PuE4JZY9jlubxEtsgtzBNd+xrkeIK6pI7c3IuoVyFoIYUhKAzyox83Od6OeHDeMD5juErAeUpwRjlDvq9As28l+mtfp/nOt4pkaRlHpb"
            @"weSNtzz/PQWuM6DlprtDGk80FNJpOh02rj+unPWGtwPZcwiCgWi4jp6Rk8Lx0KCQRxHOO4Dkkck8vlaXdSFWIUhjiO02WqOadhb2ssxmj8TIa4"
            @"08EplwkWlyj/+Drr3vAjxPIcoq5ZXGrzZaNZ73vcGYa88ksX8M6PZEgOPokYHEfkhyF3AcnsecT/+SvyN/+Ie0yOz+5uk+1q5McRjAlLjCW0gt"
            @"0WngQuz0re41qyHiyudQnHLbRiRGSReUGxCPmiQChLPgfF1WA3eNiij9ARdBwSdwes2II30gTfEgcTmN29qIEyYuUhFFOYpk+yCGL+GWTtUcSE"
            @"A8KDgzXksiA+BMtHod6CViulFHWahjirKJY88ocN/sGIA0by9RiWtOF5UrABQWRMVyktOATcZQwX9Gb4Wo9E5Mrob30M//w8lvsRi49iJo/gID"
            @"jS2szfv/Iob2iF/EGHfMBYJnI+ss/D5MvUXvhK7F9+1Nejo5Gt1UAK4jhJOc7WprkY3RA9AYRhhJDidEPVbrWQUqGNTpmINs2clwiiJEZ99av/"
            @"QKvdRknZTadJJcuOckiSGKVSZp6Ussu7SfveU1NJIVMk3Nh0SzRhgHAc9BVXfCHZfsGYbAfnyIVJymUXt51wNpartWbxjDHOeEkvtjmHKPSC24"
            @"fIvm/eukE+8x+f4skZxacOReRizVoleTWWS5TDjIVj2pBDMCigjOVADPdbwQolWL8UU7SC/KYMhZXQm0nI5QVGSTKepTgEYlQgemQ3XRBEJ0BO"
            @"HYWD+9CLvZjseaje56FGXytk+dwvCFN+TzK1ULL7HsA58jtU8yjCM4ieHHgS5iKsY1H9kowrcCJByU8lxv1biwxpj8I9If4xzR+E4pshjBnLpU"
            @"JwthQk1lDAcpZU+BYaInWkf6SdsJx1uWJgCbZ1kFs//A2MPl/YPdCeRvZXmD0xzvm/mOFMY9DacOGafpKRHMn5z2P5Q39D/O4/FybjatFup3SS"
            @"bvRDqoQSaQyENSgpiZMEP+NjjcXzPeq1Go7jpiHLXed+ISVSSrQxeK6Let/73ofjOBhj8H0fbXQq7JTiuR3GmnQamSQo5WCs6fJv0sUjhSCMuj"
            @"nUQuJ5HkmziVy16ub2ZS/4ghpZ9XnxzCMMTVhyMzEDVlAeG6D0hpXQnoFcBZG/kCTs5N2//yueejzir3cn7LCSlZ7DFXHCRlIIZFUafUbNWsaU"
            @"wgAFLLE23J+AdiXnLVn6DmlkfxbnjBxWR7iJpjQiUP0yPS/crg2wsdgm0FLIdgAnDmH2PYKNGsjhM/uxe24xz36+JHf+ELl4vKvFd7AO0CNSrX"
            @"SooZWGuomCwekYTK4A5X6y92nKf2qw1IZvGMnDkeFMa1klYUxITJcDNYZgs+ewEvC0oWZhjefw9HLEXD7DRfIket3c+XLwBRA8DJ3jyOGVJI+W"
            @"KN+1jBnqp7e3SW7VCPGb/5L2Rz4rwnVrv+B0Wug4QnavsTEG5TinvQAsFtdxCcIQ30u5Pp7n0m62cB033W2kTIfHNv3MUh2bRQqJ+vjHP44QAs"
            @"dR3WLKBStSdD6TIQhDspkMrXabTCZDHMenSUXWWlzHIYrj019LpVIXN3EwnTZCJyQXX3CdcAc+LB75Oe7qCaK+TZTaC8h3bkFEx6F0GTqKcT/8"
            @"BY78uMb/mREcTAxnSvjcQB+loQG8epOCTk0mNyrFVmCL67GikKcTxrgCXAMHAst+IekzlhX7IsQRhdg8SmZdBjffwPYb6POw0qbcHS2gZhB1i4"
            @"kF2nFQKkRVd6H9R89H/A/q0E5EW4JxEN1UPOEKKJuUvuE70DEImWB9D7NiC7JaJP+LSdQzbe6Rih90YDk2bBWwUgjOcl1ekPGoJIbtQnKmEGSs"
            @"gUQz0Fthy1g/hVaH32vDiQXNWMdlzYEniM+YQ/atRNSehJEtqFsM5oBCnbWeYrCX8OoPk3z0kyJo1MgJCOKIbDZHJwhwXbdrJpLmbwA4jksQBm"
            @"QzWcIoJOP7NOoNCsUiYNP62KQDZiXl6ewO13HS5z73uc+htU7nP13eK3BazlEqpoPDUrlMo5lW5KfqIeB05d4JAnp6eqjVat0WX2OsRTkKs7S8"
            @"HJ+9/QuZXUc+b+ZmkFdejX3oftS7L0Xm2+jZCs7ffJ+j/5XwmUixFMZskoIZBEmzzTmeT2HjOnAcCrU6whgyXhYhHSpWsE0Y+oTAdRUlY6gmln"
            @"1aoD3JcDsiS4g9dxCzcRNiIEIUagjPA0di2wYWwHbSolcpEHmJcAXG8xG2hZjvpJ4wSVcqjQVXIIoWm8siCjlQdWx2Fbp0HqIzh3zsIHOHDL9e"
            @"kjzUsPQZyzlKsBXJCxzFpkQjkQyUy3idDrHRxMrDblpDrreHkyfn+a9WQEtCBcue+YTsSY91Tx9A7yggih62vBL7syq6sAkxUIKZCP79e2Jpdo"
            @"pSoZD6+OQL1BsNctksUZSWJFJKjDF4nkcQpBTmMAzJZrNUq1Uq5Qr1ZnrNgyAgiqJ0gYVhGt3puERxTC6bxTHGoOOEfLHA0tIShUKBJEmo1+tU"
            @"KhWWlpfo6+2l1v2+trxMpiuDllKiHId2u0WpVGZ5aZlKT4X5+XmUlOTy+fSokwolNY03/vl3M7eMvCfatJ5SPYDmGKY8R/yVn7DwXyGB43CW1j"
            @"zpSLLaMOzCfa5ken6G18wvs2LbJsKV48j5WezhSYTrYgo5bCBYWauxxnWoW8WC1Swkmtmm5GjRZX3W4Lr7kcU6Zvh5IOvQuRfRjsAIRJJiWspJ"
            @"CTjCS53KyKZHXJqfrVLtvUiDR61IKwkhQ6zXh13xFxAGqLmfQ6NF46DHU3s1uVjzcmBUOAwj8V1JrC2xA/SWibRG53Ikq8bxB/poP3uUeycPcZ"
            @"O01IVgyFoWBBSVoliPWfhTnsLHHkH9y0aclZtgejeZC7cTFktw/hUs6pi+cpnqco3evt7TI5p03pMliWKSJMFxHYIgJFfI02l3yOdy1BsN+vr7"
            @"qS0v09vby9zcHIODgxhjqdWW8T2POEmI4xjXS2dBTrvdJneqdS+mtA1rLZVKhcXFRQYGBqhWq/QPDLC4sHgayshms1hrCcOQfL5Aq9miXCmzML"
            @"9AoVBACHEaR3F8j6heJ7dt63ujLZvfm3v28G2dsHlVUY9g/ngr0f8sYRPY1NPDxnqdW43mjowiKw3jnsHpVdzYidmy80kurgySfeEFRFvPwDlw"
            @"GKdTA9/FlT62o+l1FP19vSS9RWRs4Mg8nZtDlhdylD7bIbtVYfkYtvUyEN+CcE/3SHLBMSmpxhXggqi4EKQOYtaRqQ2L7EZsyhgrJfjnY/2PI9"
            @"wL1pD/wuHoJz78qyZ/SPP8vh7k2h7kYgOmWySdDlHJR1c7qJ4SYriPZHgYVS7j7z3MM3c/zGP5iGjYYaSucQPLghFsdQXvDhPWn3kGzWPHCO+M"
            @"8L56EOe/N8AUdMIY+aF3iKXJk/RIweLSUopjzi/Q01Mh6AS4vofRBqkkjhQkWuO5DmEnIJtL+c/lcpnaco3evj5mpqcZGBik0WgQhhGVnjJBJ8"
            @"D30yI77ASUyxWcdM5TRylFtbpELpcll8+ztLzMyPAIM7MzDAykU+n+vn5q9drpcbeUkmw2myo58nlqtRqVngqNWgMhIF8snD7uPN+n026jclkW"
            @"XecdwxOrJ+3OPxJ+4y7cJvReczUnPvM3V/c+9dQtL/3Qh1hpEu4uOviepiQN29cL6hsdHjm0yMbrb2N4+1bM619KKBSqs4QzVkKGTQxtkl0n4O"
            @"kTMFXDdpr4gPNATOuaNuG7dlH47AzO2ms+qOXJb5g+FzX7LFK3UusOV4AH5EEUXYi6i6mrlcdqCDXGG8T0X4KqXIsQZ1+r77r9cPSZ63EequKc"
            @"ytptddC6jH75mYhNozBvEVWDiDPEYyXsxATeL+5k6frb2C2bnJxQnD3usDCtmapaKnnF+bHllW1N9i1v4+QXPicyt9xqi1/8IvYni+irbk657J"
            @"s2Uo1DCuUy1cVF+gcGWFpeSk+MWp1KJT2KpFQIKTDGICHtunyfViOd7zWbTXp6e6gtLTM0NER1sYp0FL29PTQbDXK5HEEQApAvFKjXaogTJ07i"
            @"+yk9sVgogJAsLy+xYnSMmdlZevt6WZhfoK+/j6XqEpWeCp1OB6XU6ULa932CMKCQL9BsNMhks2AhiiJczyWOIqRSOFIShTHZYh7nRS+2ud2PEF"
            @"dG6PzVJ+m85U2iWC6z1GhSvP9+W/zAB6jOnOSZVR66RzNaStH00piinXXI7slQsmPYN74c76WXolYO7zVL2rf12hp7ZA4z00TPL6OaHUSzgQk7"
            @"2FZE0goR547jnD1C9qLHIXmSaKqMODqNCg4i8gKyHrYUYod3wMIMcmoKtAtxjA0d9OAZsGEYd6iInruEYLYCv3sK8fg0or8InovIFdMaqr+I2j"
            @"KGnMginAommYXZZUwA5t9+SvWBJ5hcHTE0DvWZGGUty1Zxoupw9lTI6sTD/t2XmX/nO4UyCTJfQOx84t8LX/ziB52H78B6GeZ/8buv+edu/6v2"
            @"YpWBoSFmZ2cpFVMf557enueMEcIIx0kjyE/9ieOYbCZLp9NOy5jFKuVKhUa9Ti6fJ5vNMj8/T6lUotNu43s+0lFpzZTJIObm5mi3WviZDFKmsx"
            @"2lFAtz8wyPjrC0tER/Xz/V6iKFYpFms0kmk8Famy6iOCEMA3L5PPH/UjEKlc4NjEnbPqnS9EDPcQiFILdzZ2D+eKfvvuttb1wYGf35gOeyODtH"
            @"qVSi4ToUp6bOy3z4I4/Y2/7IzISgvdEl5yWsWA3u+ZJ40CM6uQIxNYF6/ptwz7zoa8lvv/Vxfvh7mJfYRKGtQng+1nMg4yFdhfZdTBTSfmInB8"
            @"7qZePnRxm8JItuDqNPzqOa9yMzLSi4mNKFUDuOnD2GjcAwhBm9EG+1AVtnz08i9FdPsOHcNTA0hjlUxbQMIogQ7RYEAU7BRZQsps8iLtuEuOoN"
            @"WCtIbv45yYnb0CMNKm2Nfdaw66CltManEAmKdwYwtBHz7W8ze9ZZooKl2WiSy2SJfA8VhWSvv9F2ghD/Pe8WS4uL9Pf3s7S8TKlUYnF+gVKlnD"
            @"rKuw5BV+dutMFxHaTomlIIcfr6nULbTyEOnudRrzcoFYs0mo10zJNobLdDb7XbiMXFRYwx6RQ6iVObN5MCbIvVKv0D/TSW65R7Kiwvp/TGtIjy"
            @"sCYF5ECQ6ATPdbvSYpn+R6eNLtM3arp+zL7rEgqJymdpzS/Ql8+zVKtRrlSoLlbprZRpxAk534N//3db/LevU20tEL7IZ+QacPs1dqCE2LEZ3e"
            @"ohPrIetebNj6hM/fzo8/8G378PGYRpDMLpfNXnUHWVuuiigafzeYof384FnzgLlR8hqTURjVsQahc2/0JEYx/MHUfnLkONb0fmLDN753j4b56k"
            @"fOOzbAT60DS7vkCD3de1gMpnsb0lSDTJC87B+fJnkeMb10RPfP2w1D/B86ZgZ4g5ADbxWOr45HY28PdkqL/+3aj/8zlR81yKWJrtNrlcHm0Njh"
            @"BooOMoCrk8tclJ+vr6WFpaolwu02g0yOdytNsdcrksYRThum63Tc8QdU8EKQRxFONnuoLSbI5Wp32aPBaEIX19fbQaTfxMhjAMsJB6KGiDl/EQ"
            @"U1NTp1t2z/WQMsVHjLXkcrmUG1ss0W61yOZyGKNRjkMYBAgp09mCMSm2YtOgNykViJQzopTCcZwUoEs0UqWzBN9x6LRaeNkMsU7w/QytVotisU"
            @"gYhrhSkViDrJRxdu/+mPrM575m/vB7audYsu/roe9l46jKACYpQvESrJaY1iJm3iG+fh/yWw+ijs/ioDEK5qRgylqWgREhqVuDg6U3MRwBOH8T"
            @"W/7vqxl93hkYC7ZxG8Kz2PYxbLwONbSVRC/z2Dd2c/zv72LV/CKek6oktll4XEmWBOwQgoo1KOsg8wWS/gL6bZeg3nUeajCHkC7CfQS58FvM1E"
            @"lsNYs+USK5qwm/ayEnLmTpM58k84qXi/rUFKVsjnbYwXXT3cN1HbS1JFGE050eZ7qcZT+TSY+eXB5rUm17JwjIZbN0guD0MZaSEyxJko5u4jht"
            @"708tprjbqZXKpdNs1DiKEFKeHiq7rkMQRIh6vc7y8vLpIaHruLiuQxwnxEnqDWMSjed7Kcgm0jd9qrZx3XQnUq5DFEU4ykn500p2V6o+Pek+Ra"
            @"vQXVVeNpOlE6T1VNz9AMIgIJvJEHfrK6E1Ml9Aui7c+jub+/t/pv7kQwTX9lH867MpXXQ5Dv3Y+DCmsxfqs9jAQ+/SVG+apXbfMuJom8AmGCxN"
            @"AZNScMxachZeJAVSQD0xdByPiQ+9ktHPvw1ZWrEXnbnPyun3SLHM0qP7eewTPyP809OsAGJXUdeWEpZ+IdhjLcpYhhHkERSGyhQuH8V700rkhQ"
            @"7SWYDcOlArEd4iQpxET81hbljEfv0ocWsM9clPMPvKq0VldIz2zAyO75N0b65THW0cRaeti1X38xWA15WlC6m6CuNc6nfQ5TNnMhmSJDldu2K6"
            @"plzWng4YlkphtEZrQ7lSplGv43reaeaFFAKpnC67ID2FxMH9ByiXy4RxSKFQxBjz/0D3/xs4jaM49bbpVvOnrM6yuRzYdEIZdk0a0imnk7L44z"
            @"gdn3fVo1EcIbuYipSSIEjbQ61TwC6MwhQO6bL/w06QOoL29dOYnqTnNzdb59+/Q/PALoKXryf70RdTvMLHj5+GyaPY2So2SAWAjVmXqX2Wmcci"
            @"6ns0jVnLYqipAz6WMwRsFuki6rVpWp84ZyPulz6D95K3C9uZLwZf/5v6wpd/hluvE7uSBZ12ZYlN4yjngSUElWHF4BkOoxfmGDzHp7DGIAogcC"
            @"BfhJFzsGzD1Opw4xPE37wPO50nfsNbcT76QVGvVFCtFiaKyRbyp2+iUwSuJEkVxKeMLoEUmpAKrVM+exzFyG6bfupn/vf1MMZ0L6cAa0i07pqL"
            @"+aeLaqkkYRhSLBYxWqfsCyFwVPck0RrVrWlFtVql1WqRzWTRRiOFJI5jwiikUk57/0w2Q9AJcFwXfdruXXQtcekW1E6aN2V0ulK708600I5Ps/"
            @"tP/Xx61KUArQCM7lrtdrdXKeX/82HFcZzGBBQLdDyXTBhifnmDLX73+yw/+jCt7T2od01QfJ6kmKvjzM3DyRpUgVBgOpLZquTYLMzPCvYfNExO"
            @"W4yGlUawycAaKxnJFsjkIjhHIL/4IXhmEvOlX5IchZPAMUJOKsusSmMHcnnJlrMlqzbC6BroGbE4eQ2+wWZBjAxhhwbQ3hhm3wj2p4fghidJoj"
            @"K8933UXvca4a1fi2k0odNBuO5p5YMQorurd5URXSwrRdBTANsYjee63ZtSoYQEKU6fBkKmHowpwi4wJvWCShNB08/c6O510slzlj7do80ae3oh"
            @"Wmu6lI5097NYxMkTJ1MLj0YdrTW+5+M6DkhBo9GgUq6wVF2it6+Heq1OvlAg6g4brbV4nksURaeHVCBOX3zbDb9VSp1e+damjDad6DRXJEnIZr"
            @"OEQTpX0jo9LsMwxO36Esdx3LUTCTDG0FsuM7tYpTA6gmy38W+7zaof/A+t2+6knW9hr+rFvdyjuKZDth3gzsfYKU2zlkqgtRB0IsnkvGKpBcWi"
            @"xilIYhQFJAMix+BZYzhveSMcO0Hzx7/l0HSVSa1R1pBzLEnLIh3BGasNg4MaKWwa6FUglVuMZohKPURLvSR3J3i/mUc800FvOovorW8mftUrhB"
            @"gdRrTa6FYbKwWe6xF3m5Fmq5XCD3Eqr4rDCOWo0yi6tSnI7TkuQRDiZ3w6nU4qDG23yfoZ4i6bwgKqy91yVJpFj+D0ju/5Hu1Wm0w2LbBLpRLN"
            @"RiNdrK57ujsPOh2kkDiem3ZzSqU1ULPRxHEcgqCTtvPdFk9KQavVItPdnTJ+hna7RS6XOw2untpWjTFYwFPO6aAcnWiMNWmh3d2KT22jnucRdN"
            @"LCrt1ukcvn050w+xzzP0kSlFRIJdM5Val4WsOfz+XQUUSQJGQHBzEmIXP48Nuyv/rddcEPf/b/F3UuP5Jk1Rn/xY3HzYjIzMjIzKrq6p7pGTAg"
            @"hGz81owEGlsyshdmEJLZeG/ZG/4H7H8AiR0C2Qt775GFZGPLC4M9m2Hj4WGBB5qZbrq6siqfkRnvF4tzM3pdpVBV3Bvn8X3f+Q71L39GOi3p3v"
            @"DgMy6ThzZW1dCmLdW+pit6bMvCm7tESwc3y2HWwWsO/QOL9rXXsR/+A33yHbr3v4FzB3zYUHzY0o4d6rFN2DZYpRTp9syhi13KUFOkFuWPwH43"
            @"Q/24YTT/Dfo/+wLNX/7F+/0bf/g7rW1jFwXV8YQ2PJSnNW3d4I0EcPV9n4Ox2Nnv95Ih2hattRhdmjry/LHmec4sitjvxRShLAs5L6PnOqsOS8"
            @"O6d103yHZaE8WKsiQMQzO2YzYwWMKL5nluShAxGrcsiyLLsZ4+fYr2tDFWEIfWc/jsun6of84TrJZSFHku+lnzu2eZgPa0SYMWTdOilOhO+l7M"
            @"xgUi6FBKirVRGHBKjgRhIBdkMjGIqUl/hv09p76ubSXPNxW2cigrAbNKg4Q3jkNp24RtDe+9V+h//y/d/Of3aZ/8lLTYYn0CykeK7pGLfe3heh"
            @"1TB5Rrw5WLN62w3SPq8YT+8YJ+/BVU/gO6H30Pfg792qa6ngIFXiZryPLaojwqyicF9jPgZw2jdIwzfYT31udxv/I2+9//PatdLhhZimq7w7Ys"
            @"0eZYAn/Yyh6K0jyXWbz0eCKcjNnv9iyXC5LkiOs5RgxmrAhdl65rRVrseQN/mSQJofnIwzA0mSMkyzKCMKA1z7AsGSB1HJu+63FclzRNcRxHsk"
            @"TboJSYj51dyc5QjfhpelhpmnL74pZ4Hg+UfV4UMkDveiayiC9eTz+080PBWxZSjZ9dzJWiB8qiZDTSks9tm87obF1bTBrDyZjUsPyHw4F5HLPZ"
            @"boX9Px0HvElrTWngc8dxyLOcSSQX7ZyfhSF2OCVHJmHIqShwJhNG0YRyv2P67PnXmv9+92/V//wAfvhDmrunpKc1XEP1yGZ05RL/dojzxd9Fvd"
            @"pg2TdYzojO+2Os/ldYt/9Cn7xCG/8B/S+e0Hz3Ccn/H2lvoP1Fh51pwqvX4eOfQr31JtYffe55+elPvdJGEdrz2D59xmIacTwdGU+nHE8S8RvT"
            @"eVbGlynPc1PP1AR+QHJImMURu+2OxcWS9f2aIAjI8ozJeEJVybSw6ziUVYXvyxKUyXTCdrM1fNg9i+VymKopilL8oEwE8lxPnjeZDA5kqfEBsp"
            @"VNlmfy/LJiPA7Jy5KuaU1dnGP95Cf/x+PHr7LZbAj8QNRp5mZ6WlNVFdrTZFkms0DxjK7vaeoax8xHa/N7Z0lAkeVyQVIzyVo3YkbaQ93U8hLS"
            @"1ACHgqDe36+ZL4QBXi6XprsT3MJ2JPpVZSkKgd2O0cgf0qTryZcTxzGbzRbtuQS+T1kUOFqTdx2Tiwt22zUL7XF8/8d/tdgl387efQ/15CPaD3"
            @"7KOE6geoL6pKJ908J5+xLrwV/LQlznBf2zhO4b79D9c087/hjN/JrytY8zeetzJNfz+8mbb1yurZ5JPCdZb5m6Lk1ecHe34tXXP8Z+t2O+lAMd"
            @"TyaUpi3P85yR75PnuRxsK5rj7JQSz+es7lZcXV7y0dOnPH71sczqXV6w3WwY+b4AuZbFSI+EjgjHbLcbLq+uePH8huXlBXerFdcPH3I4HIYaiZ"
            @"6h5pxMJxwMmXp/f8/CDE/Yto3v++z3ezHjzAtsx6btOtqmIYoirKqqeP78ObPZjNPpRBAEglA2DVkueqBknxAvYpLDgTCUNOf5mjzNiKIZbdcO"
            @"OTZLU8bjMWmaMYvlmeeo1HcdevQSMEwOBxbLJbe3Qtiu7+65enDFdreTnycJWmuZRapEgnBMEuJ4TttKLTSdTtgaBHa32xHHsRyK1rRdR1VVjL"
            @"QmTRK5sIc9iwcP2aYn5ssl+8OeZRCy/fAjol9+2Lff+SdG3/8PrN+8xf3m34H7Gs07X6f/357M/VOaP/nSv44++5k/3yuLOF6wWt9zOV+wfvaM"
            @"RRRx2O2ZziKOpxTHdZjNZqxuV8TzmO1mI+/G1I9VWTGZTkhPJ5nLKkvBdSyLYCT2cvFizmq14vLigvu7e64ePGC9WQ86LT2SS9c2NZPplMMhIZ"
            @"7HrG5XXD96yIubGyFGt1viWUySHAbIpO96tD8anDaSJGFufIA87cnsV5axWCzY7/ZDWsOyhMHf7rE++OADLi4uSJJEcpqpN4qiIIoi0YRcXbJZ"
            @"b7i6vGS9XhNFM7L0ZeHrui5dL3WQsPOC66RmfqwsK7GEBRoDaqVpShRFbLcSau9WKx5cX3O/uhMC8Jjgud4wG+OaAlCUcA1d2zKNptzc3LC8vC"
            @"Q3+f4MuB12e7Q/kih5zuF1je8HHJOEKJqy22yZL+ZkRYGtPSpL0dLj/fzJl6Nv/f07Vv9v9J8d06i3qb7wN4+a1x/eOG1FttszjyLu7+6Yz+ds"
            @"tlvmZvguimaUVSmYifHeXiwWbNcbHMcZQNTQXBhLKcMhSjTSpg5Sts3IHGC8mLPf7lgsl9zc/Ir5XOzmxuOxqCIshVKWuMtdLAdR2O2LFzx65R"
            @"GbzYY4jrkz0a+pa0aepqenyAuCcThcosPhQBgE8o77bhCbOa5DkeU4jovruuR5xmQ6FRzoTJB2rdQ7Sim01sMXvd3J7c1SkbwWRYHvBzRdQ9dI"
            @"99V2reFfMunSjidpC41i8czcnyc7fKN+DMKAw16mHw87GZ3ebjZMZ5FEOk9LmFYvOTbXky7glBzNvLZY0jRNg2Pbg9TkbEnbdd0AxpV5gfZ9ij"
            @"wbpJ6+P6JtGtnU07U0esQ4nlN/77sF0fQf1W99/qvFflVpkCLWYDWB73M6pYOPsh/41FVt2tzW6IYsmqrG8zRZJgbuyjYGoSbatF2LpdSALNOd"
            @"96f2uNqjriqCQBoNz9PkeYYfhNR1NUAd5+4qyzIm0wmn44kokig1Hsu4+hnP87SHbXTOtrKpm5qR1uaivIROzhYuruvSNI1Bo5XxEDeTPKvVHa"
            @"3pBLq+e4nhdB3heMzGhF35A72hu+oMIum67uDmcUaUU8Put3WDp2Vg7Xx5+r6XLq1tGGl/6AxOp9PAIs8XC9IsHcZnPe0Z/bXAAR0dfddTlRXh"
            @"OKRt5CCKssS2FbalcD13yNUyRSKdX2+Jj9BLZ2l51gCYKQvVQ9PUqIkQoaousR2H83Y74Y6UAfO6gQO0HYeuFTC2B9lh1gvE0Z7poKbBcWzKos"
            @"JxbLpeyMmqqdGeHt6VrBbozG6uRjZaWco0NEIndaajVaaJqMrKgH0d4Vg0WyMT2ZQthghKKaqqEnZAOTiu6QbN1OlIa1PXCgQQBAFlUYpu3tBV"
            @"ylIy5uM4qPNXW9WV3MpaeBLHcUgO4tZ6TgF10wgSbclL9BxX8rip4IORz34n5Gtb1XieiLjPZF3fdfKPVjVq6ODEe+jsALFYLrm/u2MSirVsOA"
            @"4FRLMUbSuTs7alKIuSaTQdwmtlLri0tw6tWZrS92cds+GPTDfpekIce66WNli72I6DbdvYrmxwdKoCqpzeskBZtG2HbcvSFqUUdS1ob9O2+H5g"
            @"9E8eTdsYDrGDHrI0lZSVF7iO1HF6pKmNR3fdiuuptMuiWRbAUM7DcWy6ppUC1kQ2DEDbdx3KdMBY4LkenvYG3usMJiplG/RZRr1tpWi7xqxpNb"
            @"N9niY7pXiex+l0ZBzIdkLB+UQ3f0aglVKEfsCvATQE73XiZgNUAAAAAElFTkSuQmCC"; break;
        case 3: encoded =
            @"iVBORw0KGgoAAAANSUhEUgAAAGkAAABlCAYAAABOQM1BAABdOElEQVR42m39eZRl13XeCf72udObY47IiMgpMhPIBBIzAQIgCM6SKFqULMm0bImW"
            @"23a1XVatKss9rK5SW67VVd32ag+9yl4ul8tD2bIlW7YkarQoiSIpDuAEECDmTOQ8RWbMEW++wzm7/zj3vkjWKqyFhURkvPvuveecvb+997e/LWGY"
            @"oNz3jzGAIiqoKiqCAKiiCCoKKiCAmjZoCpKISAyaiZi2v5CmqpIA5e9KjEoCEqto5q8ZzGFcDyRBTFsFRDUVJBEBrX5XJT68Diim47/Xf7f/Pv9f"
            @"xXVRSUQkEST2z6aZfwTX9X+WWNDMP7im5XNkiqYikxfR9g/uegKIagaup/jnUADjeqjEooD47/D3p6m/1fLZcL3qqgI4NDW4TCm/TBQUROTw3Quo"
            @"KqgiQblIglTvACcQIP7nAqrg7l9KNbH/8uolSXz4cNVLqz5bvmBMu7xggmhaXU4xbRGYLNL9+wVwgIjpqEos4nqTF0QwV7180FSk3ACqGSJxdR8y"
            @"2TCg6nr+M5r69+JfnqBptYEmzyWA+AUCScrP+t8TTe9/VtHy97V6J5ohhwujqim4nhH/fv3m9X+v/uUjgFH1L61a7XJFJIzriDr8qgqKwyEYFUSq"
            @"l1ReDH8itLzB79t15cugfOmqmgnBnD8lmqqYtqhmSrVomqn6exFj2mpAJtfx15TqFEj1Hf60qr+pWCYb5fAeVMvV/b6/O3xu/512R8X1RKG6pqjE"
            @"imaY8p7Edf17cj1EElFNVatNcd/ncD2/ATXVyaaQxG8A16sWVPxi+cWbWCDQ8rsRzYwqTvyKiSoGwaFIGNU43L+K4p/SmwrNnFanojrm32diyhOk"
            @"WbWzRbz5UJVkclkxbRGJFUkUiQ2aqfMLqpQ731R3YTr+hZcPL9WCSawqiUhlclzPnx7TnmySyhQASDDnzdPhAvkXZXe8lXM91PUmp069aUOCOSYv"
            @"szw9oqlBM78Q9y++ZsJ9p0o19SdIkmohVIp1ud8cV99TbeqJ99CseufVOQqq81QtkuP+o1adGP8Buc+8+Ac8vDGRcqHUtJFqBwVz/mZK+y/l6Sp3"
            @"/OQ9quloaVqE8vMC4oI5jN2pzI9ItUASUy6MamWygnl/f+EKk++xOyqVDyyf1BTrohKXPiPDlScFu1P5kcMTa3dQu6143ynieuC6ftHKDaSSTEya"
            @"eh9UPlSGHloLpDKzIFL5aW/+ZOJHyxNbLqw/4S6r3nxYvkxKp+09k6p/kMqiIzHYHW/KJC5/herlT3yTSiwSzCn+FIlKgkgscvhfVdNG7bY3CaWP"
            @"mpxOf2Iw5ekQ/yCKaSPB3OR3VRJRmVcN5jCgYtpI6xkT1EEL0DGC7WIkOTz1mvrvLZ9KTFvJr3sz5npC+ZIUkPQNJpvR7mh5UqW6ZwyC3dGJuSz9"
            @"HpqJKzdB+V5Eq9PueoenyG94h+tJZca1ukZlLby587caJhX6KuGDouUR9H9RISuPlg6dtd+9gqbevgfzfvdW1qXc+UF59AWEYN4DidLklCdWSjOI"
            @"BPP+q4I5qP5cmjcpr2OCeY/2NPOnR2IlWjXRHBLOIVqgdre8TeN9rah/Lhw46/FV5WR1AhlLfzW6BoM/QF1PncSU5kpdCTrEbqMekHlT6HreZGkm"
            @"erhYkxcv1Yn53/nHyaLdbzFcT5BYVBIntgItSFD5JD3EiA4wpbmrkNT/EXqrfJLqIdytTlHlAwj8ThEJ5iu7LRLM6wR1lQ6/fBAhWvNmK3kMiU4q"
            @"dsfvIdcTCeYQb950AndNAk1MvEzcOQVqKcZ3UB1ixJToySFqQR0Oi6iizvlF09AjDTWgY9QdgI4u4Ip1oVh3ThJv6op1VbtzCJCKdXGaIpppdSIm"
            @"O89ue1ReIcEKilcnr1g/BDt2x2l1orzHkRIhSnlMQiMmVpXEiesZfCxkkNiVYMGIJB7VVBe5P66o4KRHNniUkjL5mSQlPEwwmon3W7GWoEAJVyah"
            @"gkdIGcY/rEowJ+F0R7AdIxkoOASREkOV0FCIQTooc5x87nn6W2P2rtXB9tFykQJTIKIoBeoyrLPgFOcsEKAqfgHzHcTmqAvPqYzXVIt1EddTVyG8"
            @"ciE0v65q2iq0BbvtQU0F531Y4SOVYt1/pnof5QmrNqTfxXNG/OfL2DDxlmUSXhCqaubQzFCdHInBtI1UC+N6gqaIzFU7wV9IM2/GNFNMW+6Dr4eg"
            @"wrS19EWiwRyTRa1QouuJRGv+xuNzE5Mgpg2SBEELDafB7QEZ4kCwKIKo8/hHIiSYIm6eIJ5dZuHULD07izAkNIrBkueOwhlcmkGWEboBgY6AFFso"
            @"YiKy4ZYHdcbg7BBclKjN1zA5QtFVDebQ/LoYu61OEijaUKyrBvMQrooUdwTNnJbBPZr6v9PUx3jl5hZNBdN26qhOmEj5HtX/vzuMekEgpIqOhEzU"
            @"xJOYSDzMLWFwuzqe/kJ2W8sFqtBb5as8VK8QkA9E/YawO0owV2UffAxl2hUqFBOuqMRriEsFkyAhjhpJ8xEUSzF6D2y/jAatN2ESIUGbMFmCqaO0"
            @"5hd5/4uLfOpcm9X4gCOLNSQ09PdTdre6dKXDhQ24cKXL+q0DBoOCWmww2YiAi2SBYLMeYvdw+QiVEeqGaJB3xGUdFdP2pyq7aERipYTrWppttdtS"
            @"xkfVqVE0FXO4ob2r11REYh8fVVDeW5lDn2/aGB+bhaU/mDhwyuhZtUJbFSLx0bygmappixxC6WpH+B0jCUYSNJg4Sw8W/GJ4PyJJ6aPKn0drSH3N"
            @"RNOg6oNkE+Fsg+aRkyw98ShXv/ht7PBdbDEikBxnU0xgCOIlkoWT/Myff5Dn45vIv/23zNkdpgdbzC/NUz97il5vD3vxPdpLS0RPPQ1//kNcHp/i"
            @"leuOl69bXv7WPps2IhkvoNkm2ege1uzjbBfNY1wxBCOgZlWl6JbZihVxkmAkVk3fFJdfO9ycfiP792/aInanhJQJ0BYOfZD3WR45e0BTLZp3AU4k"
            @"CzSI/AL5HR46JAQdikhQngI7SX8IFgmmD6Fo+cUiYWnmbHlSrUr5cyQEfy1FYsE0pIxpIH5ATHRMTOM8poaEHUy8ggmmMOE0JpijPn+Gv/gLTzMa"
            @"19m+Y5g7coTxIEVCQxB10MYKf/Wzj/PErW1e/yf/luzy75OvX8Md7GI3brO7c4csFmonV+i3Whxs9xhfvsLq4DYvHhvxybUxTz8QUl9dZjNfpDtu"
            @"EYVtTGBwld3xyBREEJFEJJxH4lWkuQRmXkSDidMXnzdEdIi4HgYQ0zBgBQlEsOI3vxWjqUh5yowO/fvTkQ/8sYhpgCRhmdtD78smlGAgE7Hbgmkf"
            @"Iq/yz0Zi0QpCljGOlGgP78uq6/ojHK54O23afnFMGxOuQHQSqa8qTUSaiKkT1hZBFhBykDorj60ydypiam0epx3S8R5BMotqjNUGZ84f58F6nS/8"
            @"x7dYre/RjGvU44R2PSZYatGcb7MSF+TS5cZcg4d/4BNo0KZ7t8eld6+TvflHrOzc4/+xdpyf/PDT/OGHn+S3vnGcW+8ukATXKIY3yEdbID3UjVGX"
            @"oap+X9ohFArouUnyV+02JYhgYuo98pUSbPlf1RR3fwK6QoA+UyITFAmBmAhBguoUlCcnrHIrPrqVBPyq+gxvadL8CZMytRKglW2NjkMw7Y+6JCKm"
            @"IyZcEROteScZrUkQnzNBckSlSVI/TtRYwBGjMs/xR54lqjXJ0xCJjrIbtpFmwtbbQ4o8JQhrRLU2Ll7i0z9xkqA/xcFbl5jOv0zNQNPAYqdOY7bG"
            @"bDMkjkO2W3XCuTmOLM0RtFvMnF1DTZ/2dMA4qLPx+rvwh/+JTy/1+egHlwjX1riy12Q0CIkIURIIpjHhLGEyhzpB7cAHzxQgtgemgdodpFgH11PB"
            @"+uyD66E60hJaq2IBi0oIbt/7IdMR0UwEC6ah6Ah06BfBxIcpDL8QYXk6QpFgGiQACVEJkNL0KdZfTAIVCSYJWyRAghkkOoaJz2GiYyLhChJMi0nO"
            @"q0THxISrYuIzSNIxpokEbaLaDCZuobSIklmCaAGo+Wd2CcZ0OPZsQtaPGO8aomabsLnIyccW+eSzC1z/tW3qG/+JptymGcbMxYbZTp12KySMAmRh"
            @"mnvtKU498RDx/CLRzAK7t9exl75LfesmrbyLbTbIkpje22/BH/8WH5/e5NlPPsK9qePc3Z+i0Vwm7pxg6dzD4BoMdm8gZuRBjBaAHeLcvvcvxS2/"
            @"aU3Dgyvvy8uFCfw71cy/T8RDVtMoD4oFrGq1YNiwXJwySXmYTZD7E4+iqT8tHmqr0VQ1XAHXk6o0oJJAlXUo1sXEZzHNT0K0KiJgBIPxDlgiMHXE"
            @"tAnDKZyrY/MOEq9Ce4W+zBG369SP1mkuNdF2yDArOPeZWbJRBJkjDyyf+KSy9x3H7nc+x1L+EhrFSDQkDmsYl9KutYmmWuy1mswcP0ZzZh4nhnzY"
            @"Y3jtHdq9XTQryLoHjC5tsOwCspWjHEyPuPzlL7Pwymv8w5/56/zm+ef53Vs15o5F3P56l9uv3SJMYlwWgTGoBuAkQeyOoKm66CRkFylLKz4tX2W9"
            @"QaoyRZk3FJH4ML4qs+eTpG0FwcUfSed82UAOFy0tY5a4TMeXCdZgvoTfiZbpGpmk5CVRkRhnd0RAgxYSdMBouWHASIIxUxDMkcsCUWeFhZWjnHn4"
            @"OCfXppluKXHkiGsBGjvcrGJWEuIHQ4JAuPLNgk5ryJl54fLNWzx4fpe56ReoJU3qbkx31MdlKQd3x7QLoZ86Hnn6KcKpNmZ2ls2LF5EbF9A0w4xG"
            @"7G10aY0tUbfHsHeH0BjGM7PczIcs/dI/44Onv8X7/sbP87XlBd79nQG1RotUp1HbAx2iTnxsJ8GcVplw9chYK2Dgc4MdyK+paopqJhKuhGHjo7nt"
            @"/Zo/IB5F+9ipDHxFkvAwQSiJMaXZK4OuyemSYE7QzKfUDxOKzjs6n6YpAYGvqoYrGNMuUzqrErQhnAIKQiM46ZBHy8wfP8EH3necjz81zbnaHp3t"
            @"N8i3N9i+dI9jR1YZ7Tu+/toWbmqO3aUVah86ywufWOP4vLLiEuKtIc0nCoKzP42rx3QWE06emmZ+NiGyOfl+l+HdddKr13nri7cIv3KN2TOr1HWL"
            @"ObGYMOCgO2S42ePIqKCwSuYc49GYW1vbnFqeI5yJufjqV5n/b9f50C/8XT6/Msv+5RXCfBmb9cANMGaMkiVKMO/fn7dO6vLrOA/JFUlQ1xX/XtJJ"
            @"jrI6bQLqJBbxlun++p9I2DisnKKZT25WVUrNjJi200kKYx7xidBDNOjrIJTIzQe24QomPofEZzHNeROdIJ56gtrUSVICllaa/MTzc/zA7B7Hx+sE"
            @"NicVgxunmCxl6/pdhtfvsb+9wys7He4VU2xIg/X6Cd73M8/x8//9M3z+tS6vfvEuta09JN2hJWMePN3i1IOrrJ1Y5MTxDtMzLV//A2yh7F69yeab"
            @"F9l98030zhUWmkPy/R0WhkB3xMFwyHA4Yj3N2A5hYZyyN84wS0tc3+lyYvUcjb/8t/nvPt9k/c13YPQ22egKWtxDbQ+1KWrTO+qyi2ixrs5u+9OR"
            @"vinOb3yXpW9IGK2JgIrd9hbHtMuFjKskgC+D+PUIxCTTpS+SSRYALIL1SVMJPQqJH9AgPiNBtIapPenBgM8zleAiEQmXMGVsZOIzYpprYpqYsEFQ"
            @"O8X0uQ/wsz9znr/9TI8n3vxd2nvXaZ1apP7h5zny1Blqt9+itXGbWndAb6uLswU9abBr2iStJjZq8Jm/8AjjtSW+8PUd8qtbNDSjZQacPj3Nw48e"
            @"48jyLNOdGjNTdaxav0iqBKHQnJtm8eHTrH74A4THH+Tyesq1713EbG7SjAKy3DJKc67kKQuRYZzlHKiwvr2HRAHX79xk7d51nv2B83z9Tovhfoow"
            @"QK3F5q7MK9oOqinO7oDd8XFRuKSiQzSYX3no058rsuLPF+nm3/X0kWBeJpVcrFCBjcOSaSAmCkskN+ftqushEvoqRTANWEy0RhCuiEkeFdP5cxLV"
            @"n4NgXqRMmiKB/4wnlHhzFx0X05wJ4hmsdkg6s/yVT7T4sZv/kfDzv8lWb4/ZpQaLJ9s0Hn4QE9VI334Dt3sAY0vvoGCc5+wVCVuuw/4o4NTja3z6"
            @"v/0wX94s2Hx1E3Z3qQdjlhfqvPjiKU6fOsJ0K2F+JiGphT5Z7G04qg7nHM5acI6Z1QVOvfgMSx/5OJdMzDfffJfx+h0ORDH1hKnccpAr+7llRMDm"
            @"aEwPWN/YonH1HR76yOO8fKeFHQ6wNmN6YQ2bDXBFiojMgxv6MFhTVdcPo+YPLJ741F+XoElv+62X0dE3UF+O8VBbQhHNtFwoKZMAIEEgJmmLmIbP"
            @"MPi4pzRfDUQCJFzCRMclqL8g4exnnZvpuHErNFE4D5xU9ZC8NJ6BiGkopiFBfMYEjQbBLJ3Zo/zFj60QfvnX2P/al2kbZa5doyMQ1SOyOMbu7hB3"
            @"9wkPBoSFY9Sz9HtjdjLDXTtDt+jws3/rY+jjS7z0nXV6l7YJIqGIauS1FruZYXdYkGNJmiHNekg9DjAmwBip8pFI+W+RFwwGY4Jag1PPPs+RD32I"
            @"24Xy2ndfY7UYUY8jtnPLQebo2pwDVUZZwbaF2/fucTbK6LzvRd68WpCYMSIpRdYrw0yHqlkVwmNG3L6SvpHU5n7epjnb17/wV5z0f1s0XCrpBiPB"
            @"7YsEMz6z4TM1Upb3RHQUGuMTqlV2uqrViEisFYfAhCuY+gfQaebPPsfzf+6jfOuXf4fta690xHTXVO2Or7dU/ixcQYN5lRgJ6vzpjz3A5p+8weDS"
            @"XeaOT9PNhOnUYQmIc0ext8HuO1cIuxn7V/fY6WXsSIe9hVn28zpFv8mZs6eZfmKVf/APLnDhW31GByPG/S6qFhM6iA1Ju0ZnNmFmvs7p4w2ePDvF"
            @"+9ZaPHqszXStwjtKmnuQ4IDReEx/s0dOh6f/y/8ry899iC/9439A/r3vsthukKMMrC+L5NYxspZ+mPDdl17lA49d5ZsPnGD9Qo/x8B1U6hAo6joE"
            @"tQBst+PSW2tGak+PR/d+Xt16L6jFZ5XKBxnuYyvFTOhwVTZHYpA4rGpFJcNnkuLRCfesRG1i2kVW5wOf/TAf+5sf443f/xZ6NcEEwby6Sfa7M6mX"
            @"aEgxEh57Ypmp9oO8fvMaZ1pTjNINRnHEqJfSvbfD2AT09hy2sYAsTGMeOQatBYyt072Tsrs+ZPf2mGPPT/FvXtrj218aEPR2Obh1DZeOgQATRgRJ"
            @"QlaLGN6J2W7VuHGpxtdf7jK72uLEiQZPnGjy/rWE959oMV2PcLmlyC3jtGCU5wzHjv17ezBzkhf+1t/n9T/6DV75pX/F9GhI2KrDyFKowaIULuD2"
            @"uGD45su88NR5/v2lOZLaEnmW0Jheojm3Qm9jnfHe1+8jx4QrYsq00aQE5JPUOiG6lEws9YtT8fZCLZGbHrJD0smHJ+it4rVl9O/tsbfeo7u1jwlB"
            @"nd32lcRw1RNGTBsDIgaso91OCE4+QDZ1hbz7Lv3csrmzTxrMs3TqIZY//CKnn3mS9uoiUou4taFcuTWkvzXiINhjx+b0AuGb74w4+mHHMz8+z9u/"
            @"L0S7Oa3TM9RmWjTmE1qLISZynj+oBdkw5WB3xM7Vffau7/H2dIPfXmizdmSXF09FfOLhFifnGhz0YJwqReEonHJwcMCNO1vMPfIJPvQLJ/ij//kf"
            @"0ly/TRw3KcoEgSFBasfYur3Bw58OiKaWkF6PIDnDR//Ki4R5n9/6R/8WcX1PkMHn8JT8esn7yw6Jmz6McbheFWuipl1VewXNQiPhisfqYVulzM0p"
            @"aIXcytS5uvErBPsvXPraK7z4g++jGPfBDXypWCRBwxWpiI/+xpA4Yf12l7xREMyvMLhn2IwsK5/8OGd+6qd46AOPMzPTIAwgy3J6uyNIlbo4mglM"
            @"dWq0Ojn14ZjCFpw/3+CtS22asyGzHz1ONFWjsRQwc8rQXBKiRAlrlh9cCVlwwhv3RnznzS7vfHuH7s19dtYP2L0Y871Xa/z63DaffKLDDz09S70e"
            @"0+31yAvLYJzhEN64eItm2ORjP/e3ePk//EvWX/kOUmtiJCI0M9ipJznoJByZMjRm54jbEY/+yEne/PoGG29/Ey2uonZcJpmjk5BfF8IVpao5SSx6"
            @"H9dDTBvVBHHdimgpJYsoCMLaUlVKmDB6qqpqSYNAJXDO7gTGxYP93urOzQM2b1zEZZt3lPy64IGHqoRIfEYknhETEybTDIYhT37ifdy9KCw37/DU"
            @"X/5x4hd+gvriEaZrQhIqoUAcewc/VFjv5ly6M+LK7SH3di2jXPj4zy7Tbc/x1h9npDsG4pj2imH6FNRmIYgFZ2Cm5njfdMB8JDw4V2PudB15aJrp"
            @"Y3NI3GG8VzC+vc/OvQO+/W6fb761iwlzlhfq5GnOzbtb9EcZWNjZPeDKjW1WHn6YcZayc/0qSTRDFD3I3uLzHP/Jj5Outrh02xC6OvcubrN14Q2K"
            @"0QVwWxURtoE4yjKFLy0TzHiEYRqTRLaWGXORpAx/koqxG0iQtMtsdShlvOPdkWa+BmQaAlbQEa5Yx43s3ctvravd24f8ijisqCSi8ZmkdXJNJU7U"
            @"WZA6JmxTuAXOPH6K5eMh4eost+0Ke2nKXCvg2FKLxYUGXau8cWfE517d5d99YYPf/Pw6X3lpg3fe3OTSu7s8+0PzLH7oCF//rTF3v5UhQcDUScPs"
            @"GaExr8QNCGtC3HDMTRs2HdzMlJuF5e2hw9YiplZqzD7QZPrEPCTzjLcN43v32Lq3ySsXhlzZHNJoOigyBt0hg2FKOk7Z3d/mwuVbLJ9+FOuGDDfG"
            @"RNPPMj73Ih/4L85wWSO6d5XBdkY+zhAZYfMDsENQi6oDdR1POtUMlQAN5sWYDujQWx5Jyth0Uo8SdCiiQ0GSwARxo4Tb4STeMVUNpKwrYRoI1hP/"
            @"8msmcD3VYn2S1RUd2jw6vrD2ZENVSIddTNQiSBZwZonHXlwja7b59pc3SeKC5myd2YUOeeD49W+u868+f49f+cI2X/lqn0tvjjnYMqAx47HhzJmQ"
            @"H/qbZ/naVw1XP59iwoCpEyHzDxoai5aoDmFiCCOh3YJGElBgSA3cKwyDzFCkynAIhVXCOkwfT2gfncMWCww3Umz/Hvc2u7x9tQdhwFQzYjQY0O8P"
            @"6e3vYm3KzbubrDx4nrzv2MzPc/Sjz/D8T81wpx4xGIcsn2tw+sPz7FxR0m4PW2S4IvcUM5eXCW/TQFzPmHApTjofK/LRG2J8hUEM1vt91/fcDx0K"
            @"wYIYtxeYsDbnoXcwoyKhTHjYpqkVbQvTESNhRVD0FC4dTbhqxnRMGK4M9jcb+WhE0lii0VlllLZ5+OlH+fBfepavf8vC1i61xBHPT/H2zX3+0+9c"
            @"56sv9bm7W2P2yALzawscf36ZY88vMHdujrkTdX70Z45wLW/w+q/nZAeGmRMBcw862qtKfSokqgdoHKAJNOpCah2PBo5HY/hePwcTYxzYwnNC8xHY"
            @"TImawvTJOnF7mt69gPHmFnl/l1v3RvRyw9x0nd7uBt3uLk4t1lp2uyknn3w/1/dWeO4nT7P5uS/wsBge+dgR4icSNu8qxR6k3TFRkBAEQjY6QCQD"
            @"pwmiCYHf2M6m10r2fVmy0GFJNS4LrFgRCUGzIAjqx2RS4JPQlUcO/IJJWewrySPzvoCHFWMaosF8uXjziGZikiVMBGELMW0yO8X55x7i3J86y7vf"
            @"GxEMR7iG4b13drjw7R2KdIYzz5/gp352hU9+agrzRExzLaI5FdDv57z/nKXxYIev/XbG7pvQORowfUqZOuaodUJcYtBYWWpZnpk2PN0wPBIbnqyF"
            @"PJJETIlypZ/SLQICNdhc0cLn8Yqx4qyjORfTOTLFqBfS3+jjhnvsH4zYHQpRZMmHB+SFAyyFa2GmTvPYD5/H7Fzmzf/vv6H58hU+4DIePznFaG6a"
            @"292C4qAgG2SkwzEu65WsbIcxLhQhVqliUddHdCiKLTs4bNXQYJAEinXFtANM/biKhID1fUOHcZJfoLJKqFWBqoLj4RFEYgK/iCLBPBLOSBB5s6sx"
            @"QTJPa2GJBz9ylDvXCg7Wu1x/Y5P9GzlTq6c49xNneP5nZjj5WIP9EHYHMBgrB/uWuWDAk+dbvPSOcO2PlCAJmTltaa8URFMBJJbzMzl/+kjET87V"
            @"eL4RsRYFHI9C2kGAQzmRRJytGe72h2yMFQpDkTmc9RRdLZR8pDiNac3PoNpgsJ2T7m4zGhwwsE1qjQA3PqDIc9pTx+mPVzn3vmmu/9KvEHf3ODkX"
            @"slgzdLr3eF80Zv7hI1wchYwOLMWwTzEeonaESI7iEBMmYuKOJ+KYRZyEiN2s8qUqmhlfeM0U0zBqdwIT1uYE01CwiusZnxLqlOmJAJHESOmzfG6u"
            @"4VM/FJ4oEcxggjkxwQxiGmiMCWJUQiRok7TmePJTJ7l2YcyVL99mfJAzs3aa0z90guUnElwt4CA09NXgrGWagpWo4JljIe8NlVc/P6Z3PWLquNJZ"
            @"UaJZ6LQzfvpUyF9YneJ0PaKG4JxiTODhk3OgDmMCpsOA52bqXNrocntsCJzgrKdSU0CRQdZX0j4EYQvRFuPeiHTrDvl4hzGz1JoGtSMa7dPYxjwn"
            @"nl7j6MFV9i9c5+njx3jk+WVWHu2w+513SV76Bk9//AxXwjk2ro4gH2GLFDT33GSJKIoOErSAMFHN54X8si+jS2Imft6X1VV0GPrCXeV7gjlVSbSs"
            @"xkrVGSFVC4rEvhxepo8kmC8DgYRJM5j1qMZlwIDdjR12b/RIplo0jiwQ1uZoHVkgSMDmUIwDRiOlUYz42FRA0g5xhWPLCq9/L2P3LYg70F5y0LQs"
            @"tcb8N+eneGS6Re4cTsEYQwDc6fYJVViaagKGW/tDvvDyDt98u8dep0PjkSZW1TN/nGOcl8ZBwOWQj5SgNk3ryGnywQ7pzrs4ewcTHuX08SOYvMPU"
            @"qRWOPLXKkdsPEr/0Lg+dn2F2RXHvXGbq1i123rqOffcd/s+f/Wv8j2cWuLq3QVTbJbM9jEDUWGXlxMMcbK4z2r2EdeNEi36CmraK3fGVXLtdNqtl"
            @"qG8PKMnnng+nk/aSYL4iMyqu51mbFfsUlHCFKr+kFXU2KHucCowoQk4+7vPH/+Zdlo71OfXRI4TNOYpCCErm+GA4pr3f4y9MRzzcqHN9UJCK4bu3"
            @"4PY3C7Kh0l4qMC3L8nzK/+2pWR6ZbjLMCyJjEBG+9PYWP/+v3+Wn/953uHrQ5cZWj1/8pbf57N+/wD9/rc/dE7PUHpnF5mBTQ2/kiOnzxGyfIi3Q"
            @"QlAnmCDwjNZwiubiAwT1E9iDIaO9jL4uM3viKFPnlplpOfZ2t4lqyrHHZogp6L95nYOLl2gyYOfWReq/9qv8tQf3mTq6gATTBGFCUdQ5/f4f5P2f"
            @"+ghWE9ARYnK8JfKs17Lx7LC1UzUNcYc9pVJ2LUx4yKKZlmR9KelZE6K8aCoE84hpiwlXnfV8lSBOQAzOWYwrMHS59foOj316TH1mBmdz4kZAmChp"
            @"lnEmLPjZE9McrSXcMkoSwJ0U3n41p3tFqbUDajOOWjvlrz4+xQOdOge5YyoKub434P/zK5f53nbA0afmeejRBf715+9w6dY64QNLPPjnZ6lPR2Sp"
            @"kh743Fuejjk/PeYzZ+qcasf8zRubvDeY9iR+q5jQoDm4okFYnyezI7L9Lpt3LbMnazzwcIPoYIvkzKOc+q+P88U3vsXTYZ/m3g6Fs6wPUrqjMXe/"
            @"9ycs9Af8xHM/zf92u00wjomSPle/+zUuvPR57Ogq5Fuojt5A7c4kb1omVwW77fniph1qlfVWiTE+r3RYUj9sL/TcZEkQu43EZ33AZdpiwhWnMe35"
            @"s5goor9/FyMNaq2jFNZhizFhLUVUMCGEtZCkFeJwNKXgh8/NUm/G3Exz/uCtTRrLMZd3a2y9Y8mHjtayxTZyfuiBiCcXm+ylBe0k5MK9Hn/jn75D"
            @"vrbMh39yhampkGyY895GzqMfn6M2F9Lv5Qy6DptanDPY3T1+/pkm759fIFCDCPyZ9zX4f10ZQNbE5hbUE/nz0YgiLzBxm7DdYHwwYKdr+ewDBr14"
            @"gA1afOL/9EF6m8/w5b//v9K59V2aknOzN6CfFWzkA15/6fc501rkqfPP8ZU/NtTMkHT/ZdTm4EYo4wuo59i5Kg006bOVRMX1jEpstOqvqDroKrI9"
            @"JZ9h0g4ZrogJ5jE+mysSzEkQrUkUJ0jE7MoJVh44j3MBakJWz54hrHdQDXGqOOdozDrijmBCJU9zzh+NCWsx93Llf/nd63zh27u4RsjWvmW8oSRt"
            @"YelMyrljlk89MEM3LVCB3eGIX/ylt5FHTvDYD61gc8v+Zso4dTzw/BJhXejuFxRjQa3gCkNghK27OV/+w6sYhFGWMcwL3neqydrsiPHYooXiigIx"
            @"4GyOKyx2DI3ZZerzR5C4xTHnyHsBjz24itGUqYUFPvq3f4GtH/lJfvPWBpuDlL0io5srAwOvful3eGRmTKMzRVEY324jOUjR9amfss/YSOxbSKte"
            @"rrIpXSEwQX1FJjmjcNUY0y45dVUrvPXsoXAVE64g8Rkx0XET1I5L4CvnYVzjYGeb7bt3CeIQIyE7G/tARFjrYKI5jr9vkfpCi7tvKiKOznLOk4+2"
            @"kDjmG9/d4Isv7fDJP7VI3mjxjV9N2XvPMrMKP/0zTX7ssRmWo5hQHY0k5H/5nXd5Navz4AePMR6kqArOeTLpYFSQFiWCK6BIwWV+U7QXpvmTr99i"
            @"uTHi0bUFuuOcuJZwc/OA775tkUzIhxnFMCXr7aHFCEjoHDvGQ3/mUU6dS3j7G2/j0pjPfGyVEOX67R7XbuwwnD7GeLrDq99+CXVwUBRkUmNz0GHx"
            @"6EnSqUXWb9wmNCPU5fg7K26VHeWI2E0R0yhZ2jueS24aGKzxzt+3QYq4nmrVFe7/e8h7kBhNHkWTNajPOzrkxREKe5y8mCeI2iSNBcJ4GQnbREmM"
            @"CSPCpIZEMcUIolqIxmAFFmcjkk5Iz6a8d3fEqSfarBytcfFCwc4bGUHgGIyE3//NHRKndAtInaEmwtJyi4WzC2RDi2IoLOSqZFYonOByxWVQpA6b"
            @"F2jhcKlQjDOWHjnNb3z1NsPCYoOIzBrOHasTS4orwOU+jjJGUKcQdWgfn+P8h5vceOU6v/E/vcqv/OpX+Ae//jK3tocMhwVXbm9x+do97PKT1D/y"
            @"I9wcjik0ZKwdUnmO3v40s9M136ZjPDlYXVVsLSUFCObLvJ3vtsB0yv7kLKx6O7XsVNP7u74rWpcJ5pHkMTFhBxMDLVoL5zn7oY8TNacZ7fW4/O1v"
            @"M3fiJOPhmP7mdYIoQqVJlExja0vk2mJ6PuTpT9eozyrTi0IWBjSxRCfqnGkq/SLh6stjhhspjaWEsKXMtIVaEJBbiBLhpQvrtBs1pkaQF0oISCQ4"
            @"Z1CnqDO4Qr2pSh02U2wGLvdZhnqzyfV+wMXbu6yuLjIYK/PTCRF3GeU1XJGjzpWFOoOECQvnprC7B9y9FvPgp3+IzTe/x//0j1/mjXf6fOaj5xiP"
            @"lVQt3/nOWyTNB+H8s+y/8V3y2hns1ONkJ87R278ALsBa32EomI56M5e4AjSvP4a2IB5hgp1fxg6/TNnBMeHdVejCc7Wrrr6S4IdvBkNCgrCGdTWm"
            @"Fhc59cQprryzzdbtG9hsi61rB+XpDQhMi7h5lNrKAzzwzFGe/9AMU8vCuC/celdo1gNaJwJMLgQhzE4lvHc9ZuPlLrZwxE2DiS2nTyQEJiDPLSLC"
            @"P/r3F7mss5x9cY0wB1fBzbJDwGWKLc2dK/yJsrngCsUWEBhIpcHlOwfMLi3SGxcoAYFm2DzHFYoWnqwChqTdYvHBJkU6JOrEPPJjy9gfXOQb//xV"
            @"/vh3L3F7vc+fevE0V6/eZTDss72fMr38BNlmTm/vCdpPP8XS+xt8+R9tE4bOX9cFqOS+OcIl59rLD7P27Ac58/TjvPfVr/LmH/y7F4Igu6jWbiOa"
            @"hRWxUSSYF6nYKyWPrmKolpVZwee7TFBw9/Kb/Mf/4SZGC0S6BJGDLMZEbcJkkSA5xvxj7+NPf/YoDz+ZsK3KtQ3Ha39o2X1HWVmAjSFcef2A3vUD"
            @"7A+ucPHlMb3rGSYOCGogktNqNsicQQJlNMoxS7OcfOAcGjjytCBwgrFlF5U1uKKU27GCFoIrHC73C6VWGYwyBplhMMrpZ47eWBllissdNrdoUeBc"
            @"hrUpIhHJbJsjJxqYmzu0ViPiOYOlzhN/8Tle/ZcN3vradxj2xyy1A0a9jN6wYDC2LJ//BPtXH+HRP3OS1176Gvvb+0Qy8i2gWoC4npFgTqXF2Wef"
            @"4+hj59i7s8PWjbtIqKlgt9VIIk7S0Juysi2FinxSUYZN29tK1/Nm0M6rjlFnMUVOFOyBkbINJMKEESZqETVXWHjyaf7C/+UUyycK/uj1gmIjY3E1"
            @"pHcjJ9uDg92A7X3oZQHHjkRs7oesf69H1s+pz0cEAajzpyKzPoZpBkKtGTPKC5zzDE+rZtIO4orS2FOiOku5QJZ0FNDKDvhzzza52Kpz+sQc/bFj"
            @"VMDeyDIcFLgsp8gzbDrGZgUSNGge7TDVyPnQkw2SuYQbfSUoUuIpOPnRBxjvDbj6yvcYPTCLGdewxZhCmnDmPO//5MPcvXWZ7331OvVkHzvue8UM"
            @"AziJnSvWxfQ6r/zur/Hyb/wnn4KJuxeCoP87zk50irJQJyzykqCnxssBlItVNfCidhvJYhFWtZIUcKDEYEIwIRLUCGsrtNee4Id/bo14ccR/+LWU"
            @"618umGsMWPory2Ag7Vu2risL53OaUwnHj83yrVeU3jWLBOJPUmywEtEfOQrPZiJOAo5MRWxljqTmF0KtZwA5eyiYpKq+cblQnBVsapA84vatghPP"
            @"pfzMTz7E93YyNg4shYZs74wZDwSXFxRpRjFO0UKJZzosnJ1hZUrptBMeso5LlzMaYcxguwAD8w+doLd+g3sXb3HkoZPY4Yj66gN0HjhFc3aX3/rn"
            @"bxFwgC26qCuZdOrbYdW6ntr+bxsGyYS8rfm1iRwBEquhYuG6bqlkMn+fwlYMwbwYz1yZNCtPMKPXRXCq1BqzBFEDCZpEreOc+8QDnH405KWvWa7+"
            @"XpftN99je30XsZa4ZcAU3HsvZ38jpd3IGAYJWzeEvKtghLAmBLEQxDG73ZxCwVpBg4j3n24yHgyxGuFyxWaOYuwoxgV2bLFjxY4dReo8yB0qWU8p"
            @"hjmZNviNP1nnbqHsDyErQI3h5vU9hv0Ql2e4PMWmAySMqS/Oc+KxDunBiH/+uU3+6LWcMIwZjJQiVfKhxRZKMn2cdF8Z7IyYPvt+ps+eZ+XJaTZu"
            @"ZYy6Q1y+B9RYOHmeuLZKEDQA1zPGyyaojl9WsgvO5dd83u5QeKMUwqrUTO7r2iNcEcLVkjFUZSHKYFf8xzw3nCAISNMe6kJMOEN9eZmHn20w7sH1"
            @"b1sObqwTyJjB/pgitTTnAsLIMdxVbr46ZmrKst2DnUsZ+TBHjBJEBsUQJYZ7uzmDkSV3sDuwPHFqhheOZLhsjM0cNrPYTHFlncgWRVkvgnyoZEMl"
            @"Hysut2AFKwF3upaDkTLKIE3HvPm9e+RjwOaotbg8I262qR9psfZgyKW3Brz6XsSoFtMg5cFOhutnjA8K0p4liGOC2jK9jRGtk2c49Yk1Hn28zZ0r"
            @"hqheAxzOjdm5+x5OUyRM8Jx514uS9ifrreO/KGhmjMTOxueqBudKXMroRD5m0pjk0Z5oCsG8qmnjPO+ulJCp1FAQI0jZYyamRlSbpbU8x8piAJmS"
            @"jXKimsHEBluEDLoZUyuxZ+ZRsPOuA+vY34futTHqHCbwSVN1EEchG3vK1TtdrBoO+hZTq/GZJ2fJru6Rp+qBgfXgQAuH5kIxUvJhQTH2MFwcDIaG"
            @"qWiPj3/0KHd3lO5QORg4+mnEsx9/hOkZRzbMcekYEYibHWbPdFict+wchEytNHh0LuOvP93hxx/rEA0G9HdG5P2UcXdE2DhCPHUKGwgf/kiTjXcP"
            @"2MvbNNrLSNgCKchHuySNNvWpEzhrd5za7bDWoT6zhiqEJnns4Rd+/DO15vwvqtptMaZtMG1PZ530I1WCSVXvkZcI82bQtEvBvw6uZDlrJfsVYUxC"
            @"ELcI2wkziaGeKO3VBLvRIUtrRM02SRPmm0J9vsZo2zI9a6FRZ/s7wngnw4QOEwSlKfV+ZVSEfOvVTY4emaKZRNza7PH3/+k1egtHmA2FIlMfdFoY"
            @"p4Yiz6kF4DLxfikX+oOcTtTjr/3YDNOzM9zZsowLwYbC1774FtubKUExJh2m2HGfoN4gnGpw4vE6dpSyuS0Es8JwL0OJ2LMw23KM90YUgwKbWerT"
            @"cxz70ElWHwm58+27/Pa/O+D4U3N0r3Zgt+4rs1Gd/u41nMsQE8yhmo66914e7t94wxjTLlx+/errf7iWj7u/bEy4UiW5w6phzAtjmLYnRAZzEMyJ"
            @"Vvp1Ff016Pgg15SCF4fyeU4CVANcDsPC8eBsxNK5gP6VBkdOz3P6Q1PMLRnkwNBabTDs5hw/OyZ3cO/tnKxfYCJL2AiQoEDEUBSOZqfN6+/t8cLT"
            @"B7QS5R/+/17BnjzH8kpMPnKIBOQOsnTIcj3l2fOGP3nbcafbQHCEDHjfqZzPfHCKeqvDjc2CwRhMLeLCazf49X/1DkVRx0iM2DGqBVGzTft4i5NP"
            @"RFx5e5vRKKBDwHs3Cy6c6tOemyJJhHE3R9MCIWHxseM8/ekOO1c3+OW/t8l43GHlfUprsUb3ZghiKnK3/6MGHd9wV6wbYzqqdls1v5b2d17y0nKS"
            @"SMlkDQ9LEl58aBIbiWY4Hy+pFwCMqdo9RT3UFUHVTOQ/nUsp9odc3kl5fjnizNmIvettzjxR5+3P59w54lj7aJMjDzhCk3LiwYjhUMj2R4hxxE1H"
            @"bTrAhKU4Zi643BHMLPG537nI1p0e6cppVk91GB8UZC5EGXKsk/Kxh0N+4KEFxoXyylvXeHhVOLlgeOp0g1MrHXaHAbd2LP2RQ8OY9Vtb/OYvvUvc"
            @"OkZUZKTdPjYbEdcTaq0WRx6bpdVS3njNIaaGKyAdwZ2+ZaruGI4N+dChqSOamuOpH1ticO0OX/5nO0SB0lwxTB2pe5cQxkieABEIGAIcIyBPxLg2"
            @"LlyRskNQjT8o4iSmTNOFXuEkKDXlQEypaKJV914wLyIxJuggBhGDEHg9VpyvCKNADpqTbfe5eTvj4LzjQ8fqbLxQsHcd7r6ZMzetLAcpm+M+C5Ky"
            @"cLzDty5Z9i6OcHnuM76Rz79ng8LLyVBQn424l85jTiyztNJhdJBB6HjyRM77Vw2PHZ1nplVnNLZYVf7Wnz2FBCGFwv5IuLxpGYxzhhm4pM6dGxv8"
            @"x3/yCt3eFAFKNhhjxwNsMSZpz1BbaLL2bA13MGJnN6G5kOCspdWJGUQx6SDn3kYBhUGJOPr8KscfyvnqvxzSmIrJR8Lpjy/SmDOkAzBmjJMATODD"
            @"OAIvW+f7mdoq4YrvWC8Pg3phqVKTKAsnioe4XiW+RKWd6vtA5z2aM4gJEEK0Ukd1BZgC5yxiC5ztkw96bF/MufwRx0/VYq6s1fjaTk5zCRZnLDuv"
            @"GbZfFT743IhrWzWufqPG1uUcMTlmEGLHjvp8BOKwuQ/BbG7pLM8Cyrg3JkzqDPf3qDe2efYTz7B7YOnupEShNym5CxlkMMxgkBUMcyUnYOyUt77+"
            @"Dp//1QuMx8sEEjA+2CUf7uOyIUEQoFpj9uE5Tj0YsPlOxpN/tk09dGzsGGq1Nn2JyO6l3LthqDUb1E42eOanOvQ2++x0G8SzAQ88s8yjn5rme587"
            @"YLx3jyLv+k2tiW/sxiIU3vUr+Bod4CoRSEmUYE5NsY5CQFg/Zjw5MpkoJ0owIxKuikTHRExCECMmQUyEmMgnHsVVAqoYAggTxCQESRNxM8ipGk8f"
            @"iTiXhFyaEogcz7wv4s7dgEeOWZ76UJvhhjLrBkw1eiThkP7A0uuBU6ExFRHHjgmvFosr8AJNWlBrNHj59QOuX77N408dpVBhnCsujEglYCRCKgE2"
            @"CBk75dKFDT7/K9/ja5+/jcoxICHtHpAPD7BpF9Riwhb1haM8/ueOsjo94Cv/aUDUbnLuIcMzD0YsTQVYdex0M7RZY/bhDic/Ns3ZZ4Ste8riiTbv"
            @"//QUa893ePMPxrz3+Uv07r2Ky3ZRm3m/JCHoCHUjX/wjH/reWrshuP1S7cvCRIAjCI2CSil6e6jHkCDBHCbq+PR6DedqOFsHYsIYAunhdIxSIGZc"
            @"CjOOsVmf0dY+732tyR+ejvir7To/NB3Qfz7AtAKW9zLev9bmy5sx73ztJo3uFsdWLU89rNSTgJu3+rx16YAr74UEnSkWjjcJoxAXO4LI+ykxQuYK"
            @"Vs+d5lvv3mb4T17nZ//SI0RxyKVrW2zsFYwLYW97zO3re1x7d5dbl0dYpmlMP0I2HJMPe9hshMv7aJH5jEnYZvrsNA8+Jrz3lW16/SbuNSUdZzz7"
            @"AzVONkJWZ+Dx4y34sKFwQhRCKHDmgyE7Pct77yjf/BdDbn7jEv31V7GjbdSmh6IcmqIVQ06cR9JaiRFXEg2VbKiXEA21LElUcp1eT0xTJJg3poZE"
            @"00jjDMunHuLIySUWllrs39nhlT/8fdSuexFDpxg3whUDxOa49IDd12f4+ptNHn8+4geDkL2ZGl/cy3jxbMy6ibh9L2O0PSTrj0gPcqKVhNrsgE+9"
            @"MMXP/fQsl2+n/MHXe3zz0pi7uzNMLzeZXVEkLnyWO3OMxmMW1lb47nt3uft3X+G//K8f4X/7p2/w1jvQaNVJR4poRBAvUJ9tYXNh3O1j06FX4cq7"
            @"JaneISahsTjPgz80T4cRf/JGQVw3zB4bcuzhJltDw71uxs1XhjSMMjMbsPRAQi0Rbl82bG8qty9m3Ht9m+Ht66R7l8mGd3H5Xil0OC4XKQeXl0Sg"
            @"AnWleoo6z6L0is+l3myxjpboTiYZBdeDaF61UucKcLrE3/h//zVmHz3Buy/d5dqrl7j21kVcse+zlxKAcV5zx41IB5sEjWmS/jJ3Xrb87hnH8QXl"
            @"z8Qxg6ZlT5UbB8rexSFpP6MlysxUzPR0RC0pUIUiK/jIU7P8+EeP8d6tIb/7jX0+/8oBN96IaUwnTM97tlFhHcP9EbNH5lm/FfB3/vuXyfQIKw8f"
            @"w6YpLfXoMB/n5MOcrDfEpkNs2qcY72LTHqgHLHF7kcWnVzn3TMy9d7bQmRkefn+duRMJph4jtuC9P9ji6td98No+PcsH/0rA9ZcyrnwjozjYYby3"
            @"Tta7Qz7cxmY7aL4DugvaB7IytzihvKVKsY5mF9HiDuqFN5jIMFSS1b6elGhZO5ooovgsQ+KkwDDk8//uT+j2hfUrV9H0NoZdjElRI5M4iRKKF4WS"
            @"DjOCesDscoN7dy2/WlP+i3bEZ5sx/3qYs923RMbRPNGmkwcsTlnatZzZmRpTU3WSKEYlYjBynDvR4qFT0/zlHxnyn1/a5z9+YZc3vyuE9YTZxZCo"
            @"IaSFpTUzy5AGdhzjBhkus9jCk1CKtKAYjbHZGJePKLIBNu2jNkOdJUimmDq+xMoTHabDjG9dsyw82KExH4MYxttj3vvaPrdfSRlu7EGQ8MjHG9jt"
            @"gstfHDC4d420dwWbbmDzHi7rg93Fub7vWfZ68UCeopqq70zfrk7KoeBZRZsrtR9Khc5AwtZjnvSow0rkybfLBUsiYUOkYOPGLfo7Vwm5i+EASEuB"
            @"8wAIffNwUCdorLD29HMsnTnBsO+YXm5CHrKtBft1x+NJxCOxYV0cl+9l9O8dQKxErRbzMzEPnmyzOFOn006oJyGgBIFgFdrNmCcebPPpF1ucXrZs"
            @"393j4ts9DraUOIrL+QARxRjsuMBmSj7KsGlOMUp9ri8fUKQ9tBiiLseIRYKQ2tRRlp49zTM/3mbztQ1urcfMrIRkA8vmxTGXv95n97qlv77HaC9l"
            @"7aMrPPRCwrd/pc/ejW2y3g1ceheX7+KKPd+Tp0MMaRmaOIQCfClyX1SHnsdQag5Jfv1Q21VHEyV/L2tjAxM2zhwmUL2AkxAuCTpSzHGcJQhHCCOc"
            @"HaNaNpqreG9nwhLxRdSmTvLUDz7BsDtk4/I6ezd6jLshSZywFRYMGvBkPeKxxDA+knB1V7n65Stcu7zJxVs5V7ZznAk4MpdwZC6h3YpLWRAfX+SF"
            @"JQ5DHntgih/72Bznz8DO5g7vfO+A7o4SSITagnycexpXVpCPfX3I2ZR8dOB9kU19iwVg4hlmHniARz9znMVOjz/+F/tIOEM2dOzdLNi/YxntWQb3"
            @"Bgw2Dmgfn+eZn57j2jcOuPgnOxT9mxTDu7h8B2f3wfU9tCb14rwUpQy2epEodX3fReF63v/nl3ETOpdQ8Uu8jM0eImEgYfOsF7ctYTg6miA8P0Sj"
            @"ri5HnQ2hKLVPnY+cjUHw6E9xuOyA975zkc0r1zBmAKoU/ZThQcyZMw12cuXiQHluLub9DYM93uLGOCF95x727YvceO0yX/rmHf7o5V2ubGXMTtc5"
            @"vtQkMIFPunriBuPMAiFH5pv8wAfmeOSUY/36Hd55fZthHwLrsOOCfJTi8jG4HJseeCRnU1yRorZAJaG1epJTP3yaxz4mfOtfXGFvd5rWfIgrBJfB"
            @"eNfSXe8x2NghmW7z1E8v0mw6vvXLu6T79ygGt7E2Ix8PvBvRsT8MNiv9XQHO+s2txbrvOrcbRiss4HpV20up8DxCdOT5JV6oMJCwcdIr6QYzh/M8"
            @"NPPfhAW3j9pNcEOwPaAhSjhJgpb40TOMxhj6QM+/CEKMKOkw4Pnn5ji4J7z0pmVv2vHodMgzDaF+psV6s03SMzw5HPFA/zbppSt87Zu3+K0/ucsb"
            @"N3t02nWOHmkShQGiDucgs8rOfspolDMzHfDic03Onii4d2eT6zf3cdYRGlBXYLMeNj3w/HSbIRSIianNneT4h87y5J+fov/6e3zzt4a0jy4iquQD"
            @"pb+ZcnCzy+DeDlEzZu0TR3jiB5q8/Ktddq/uo/kGruhSazU5+4Gn2Lp+C3U7vuSheXmKys4AbFfEbnqOvSReF08zEa+aoor1SQUdoqYh4vZFNBXv"
            @"k+rHEQm9loDpqHgtNkFHGAn8IumwPJ5DD/Bd6oNZScChYsv0kOeCiynHk4ggkhAldc4+Nscbr2e4XceVjYy7s4aTnYAX64aTDza5d2aGe2ae41nC"
            @"nzlV8PFFQ+tgi9e+8hb/4bfe4KU3N9AwZGVlik4rZu9gTH+QMk5T7m116Q8KVpYTPvhMk6W5MTdv3mZ7q0cQKDbdxhUjcIVvj3SGqLXI6rNnefCT"
            @"8zSDbeKLQ/6rzx7njXd32dmtYQc5vdv7DO5tEcTC6gtH+NBfmOLGdwre+sMD8v5NitEmWuzi7IhRNyUfbnjlLinwRX0vju4rDdm6qt1xVofGaCZS"
            @"rEOxLvf7n7Lttez46/lZF9hAwvqKN3WerjDRTPXqkVakEhSvmK6alclcK8iMzz85z6X2K4WzhVe1r8oZZoqVs0usX8+59vvvsPfWNje2LLdmIqbm"
            @"Qj5QC3lstc726Rm+Mmhx4c42x8/U+OmfeYa/9BOPkdy6zrf/+Gv83h++zldf36Sfh8wvtmjVIza2ugyGI6y17Gz3ubtxgAkHPPNkhyQccfm9e+Q5"
            @"BIEHOkFcpzY7zeozayw+NseJh+DyH13ig4+c4IOPzTMV7/HehQ3u3RLy/X0Qy/xjy3z4ry+zfCTii/8mw+QZWf8u4+466naw6R7DvdsgByVQsP6/"
            @"op4VazMI7L6h+VizubiWZ/1tJX2tVlv6BVRmbDH4z3LfKCHx/UqVk8oCE9SP+U0vgdcNkBBx+34ORSnXWc5eEC8sHvqMrY4QHYoQG5HES0ALuIjm"
            @"7CIuH2MLRSUiz2rEnVnmlztcfmkToz16dwbcu1ZwJa4RrMQ8VTN8YMow/cg034uP8Llv7PH5r1xllET86J99gY/OTrO4focLr77K733xHV56YweX"
            @"NFhYaoPLGQxGjNKUnf0hdzYGbO50WVmJOXWiwe7GFjs7I8IkodaK6ayuMLW2ygMfniPfusfsIOQTH1jijTfv8caFPVqNHlt399jfgZmTCzz5F1c4"
            @"ugJX3i4Y92I239ojH15H3Z7PWboxJkhRmyKkYMtANU+ZOXKK6cVlelu33qm35o6ffOg5ttavr6LZO6r5jmp2Ady+H/WgQz8zA+v1NCRBdRhIWD/m"
            @"NUEl8Y1L4rMQnocXKBKWYnlhJTdZAf+q8VnVzJeTSlCN6Cyukg4OfFY7aBLGCd2diDNPLxLU22zfGhIlY/KBY/dSwXt7hoOlmBPTIS/UDI+cb6EP"
            @"n+JqdoQ/+Moun/ujK+y6Fi+cO8tHlmZJDu7wzltv8cWvXuTC7YzOwhHmZxvs7exyZ6uLCqRpxq3b24zSPseOJ8xMBWzc7TEa1+gsr7L01DIrx/b4"
            @"z//d53jm2TUeOjXNxcs7XLi8w7U7fVqzFg1bnPih0zz3YzW+8a92uHcnYH4t4No3NrHj69hsh9bMHEdOP8ju+k2M8QE9pEDmyzeaU2Q5Rd4PCpsm"
            @"W3euhMakbyB2o9RY3/HC7qWLUQmr4VvlIbCBBLUlKVsBwTQmNtIHQTIZB6c6BB2p8xPDSmH3Kq4qKtUPcPR3N/yYM6mjBP5fF7G7CY9/Yon+qE5/"
            @"cwB2gMsz9t4bcfGKcqUVEc4Znk2EDywZFp9sEz5ylINwnu/egC9dTenGTZ49dZITgSPpb3Dp7Td46ZVr3B0ntGdmgTHdgy79/oiisBzsD1i/s0u9"
            @"LZx9+AiFaVJ0jvLYJxfofuFL7Pzul3jttcvsFg16Wcyde/vs9cbsHzhOPDvPI59a5N3f2+OtLw0IY+XI+QZ3Xj1gvH8bZ7dQHWHzgnFvE6Ffmjpb"
            @"5qoVmw3JRwddEyKo3RFJ3/G1Ox2puH1BhziknPVkK6nP0idlIhCIqa+UpiwoIXjmcz1lfDiZTwSlyrH1Tc6mg8RnvK5dbcYEIV5MyhGEgZetwRDX"
            @"Fj3v2WakQ2E4iHjikyt0DwIGu0NsOsLlBf2bI+5dz7leM+zMC2uJ8EI94MljEYtPtkgemmfYmuX1DfjWZkEezXO0Ns1qZOjt3eK9dy7z7q0BRTRP"
            @"vRmTjYf0+0P63THWKd1uwUFvzMmHFllam2F6MWX9332ZzzxymsiO+f0vv05fOoydMBpkJEeWePSHj2G2Uv7oX27DuAtByNoHZrn7epf+veuI2yIf"
            @"7zPcv01gRig+D+hDFOf13p2gBEkYBQ0RDTyKszuibs/rOtgdVR2J6MiTcO3G5HB4kNYLgqi+gjFtI6U586oooYhplO0v/lQZnxkXgmkjpiNBfFbC"
            @"2vkgqocmqpHnMda1CWODFoVPEwmEYQyaY11OFEX0dpTxMOTJH15inIf07o2x4zF5ZokTR60dcX3HcLEBUjc8FhreVzOcPxrSeahB7ewc484slwY1"
            @"3ht1IGyyGDapWdhfv8utm9tsjzs0pxdBUw52d1E1BGFCVoQc5Msce+okz7+vzgI5t7+7gWqTYTZmc2cfM7VCY2mWxfcf5YmPzrH1zoib7/YZbmxR"
            @"n53hgY8vcvObG3TXL4HbBs0xJkd14AFUieoEixYhS6cfZmpxmb27XYLYJCIuRotbqprh3D5iN0R0NEmv4fYETcWVYvlo5nUcxDTEVwVL+RqsV9eX"
            @"0LcGBjNouOJPUriExGdMVH/MhFM4N0UQrfLID/4wL/zUj3LzrTvko02PCE1InvscGQrOWsSk7K0PONgMOP8DR9AgprtpMaoM9wqiJGZqvsnWuuPC"
            @"WLkaO4JYeDAIeL4uPLxiWHi4TnJmmlGnzS07TZ95oniWOOogeUF3e4+NHcHVj1LvtCiyEVZDgvoyU6efQBdm+PTH5njvlTt84Yt7JLUmjjmGY8V1"
            @"pjj5qUd55kfmSfaH/N7/us1wc4grYPWZY6w9X+et377NcPsSuN0yYB1OKtNaliREAlQdtdZJfuZv/1esPHCC917foMj6SRDoNOr2heJmSVsIUB36"
            @"xZoMcxxVs5kCCZIZFYn9wkng+zZNc6KUX0rxe2sXrWHCFYLGU7ZogVlk9X0v8OH/+2f50f/mB3n7D9/lvW9/A+Gg9Htamj1F1OLUgrOEMYwPAnq7"
            @"Uzz8ySXi6YjupsFIwMGNAQBzazXGOynXb2W8lSlXI8VEhnOh8HRseHo54PhDdVoPd+ivzLLbOIK0FtD6AioNinGPvf0xtn6SxpHjBGGN1sp5Zh86"
            @"xgs/3OS4PeAf/J232MnaSG0WmyyRza7SfugEj/ypWd7/QMJv/KNd7lzI0SyjvjTHcz+3StYd8s5v3cCNL4EOvGt249IXlaUIdSgWEwq97QFXrxT8"
            @"yP/4WT7xmQ9y87V77Ny52wgk21OKW6I68pvf7VejFEoVyWGFqgNjavMo1vi29L768zrRu6uOohjTxsTnTJA8jEwls6ee4vmf+1ke/nOfYubYNJ/7"
            @"xc/xnV/+dYLgnm+S8iMBPB1ZS7IMghAiQZ2ovkTYWmHh0WmWTjdpzgf092JcEbF/vc9oK2PugRZJ09C/k3PzjuOtseNKABob1kLDo3HAiwsRjz6U"
            @"cOTRJuaBKezyAnnzCNJcRGhQ5NBYmqe+dJLFh5dZeCzh40/G/MG/fpdvvyq0p6bpWiFcWqb50AlOfXyWxZmMP/7lETfeMRiU5uo0T/3lI5z+UMw3"
            @"/tldNt96A7W30aJXorlxlfaZJFTBoRaixHBwe4OL393n/R95hAvfuMjGzUuIpDs4u1EK4g4Phds1LYPasm8ZK0E0dbbk1PWQcgqlb272s/PEtJFw"
            @"RYjPShifE9N8QcJVfvQf/Q+0zj/O+M4mr/6L3+DyV75CGG5S5H3EFSCui0YdzET+AQk7YI4g9YeYP/s053/sJIPtlFvfGXH8ccPciZhr383YvDAi"
            @"3R8St4RTH5tj+ckOSkg6UGwgtBYDTq0Izy9HPDcVsFzO2dtDuJApr2873rqec/1GzvaNMbZImV4Nqbcj3v+JNid6Y/7eL9xk2K0h1lFYoX1kimMf"
            @"bnP+A5Y3fm/IzYsJ7UWlc0w59WzI0cdDXv+djK/8nXcYb32FYnQbV+z4hKoboK6qvmal8GA5OU3jjgR11NXRYBp1exjdAdv7A3X5NcivoXbHU7v9"
            @"rENDNdPWy08HEsRJOWK2HNlW5ZB8slWqeXwCqsG8BNEZVxiKPGHtzCIv/dNf5urXvkScHGDzAZBuqxY3S+X4TtmqjgkTnC6z+sSLPPGnX+T0Dx7n"
            @"3tv7XP3jm4x3L7L+5j1Ge8LJZ6aYPd4gHUWkXdi5NGD3Sg8RpTGXUK/F5D3Y2Ba++caIb90ruNkMGccwE8K5AJ5pGz5yLOLZRyIeebrB8kMNpk/H"
            @"1E8kmES5eitlx07RONogWWnReaDN3JM1jr1oGI9yxiSc/WjC+Y/EPPZiwvRKwOXvOF7/90OGGzfJhzfR4gDcqDR1qZ/h5uF36sej6tBD7mIPxzwy"
            @"RnQbcd1tddllNL8GxbpXPZagUj6mikX9NC8rIoGYqDVXDTwsZxvF1fRjJJjXarwo4QpSf0FMuELQfEZkisbUIsPuLkEwoCiGqMuulUbaa1sTncSE"
            @"q0KEieYw0WOsfuTP8ov/5kkuvTnmf/6572H3XqEY38FECWKWqM+d4eTza8yutdhfL9h4t89oL8MVGUnb0DpSp7NSJ4wjNt/qUbiIzukmS4+3WHsk"
            @"4sxxw9kZw+nQcBTDVGkzeih7wI517OZK3yqjXBlbTwOLa9COAowNiBIhD2DHFlzZK7j0XeHqHxd0b/fYv3GJ/t3vYtOraLGF2v2Sw5CBy1DSa36T"
            @"F+uldFrsGcBlu6uzO4Lrqe9Suchkek7uBaGkmkbq36HxlK6SGK7RST9roRwJJz6N7qdlOU+KMNlFzxsbvkGQn+ztHXTCQLFZvq1qt4XsYjUcy5c/"
            @"8utouAoRzgZIErJyJuI//1qPq986gNHb5MPXUZdj8xgTpYz2LO99eUT7whxHH1/kgY+16G8q+3cLRtsZBzfG7FzwJJggVEwQkO3FHLw7xZ0jbV4/"
            @"1WT2XMLiGeHIEeVY23AiguUgYEYNxwPhwZoQlqWbARF9hDHKwDm2woKro5zru5Y7N+Du28LuO8pwo0fa79Gcnacz8xQblxzZQamzrq6cc634UoTr"
            @"GV8ruqYazCP5NfExU6KTBXQ9z28oZb49384PSTblKITS7EkQt1cmJXMptRxsOb/1cIhVjEZrfhxPMIfE59BgbtLD5CPoTIzrqpoO6icwQ3wWE62J"
            @"TCVqFmkuPsPMqQc52FCKwS3s8HVsuutnPeAnwJhkkTBpAjEmWmL6xDFOfnCNuTM10r5l+3LO1sUeg41tiv4BLh9gTEgQNQiTBkHSQYKIaCpk6nSb"
            @"9sk67WOG+TU4tRZhI8HkZZc+QupgkDpMbOn3hZ0bht4dR/8mdG9Y0r3UFwx7PXq7A57+9BEWVw2/94+/QrbzDYrRVbTo4hgjLuuqS9/05s5u+zFG"
            @"kxRP5n9eDbAvySfl6O3JCHFXTjMQScT5vwtMUF/xC+GdFiqxGM2Ml/sMSzVe6ymvpl0OwS1E3L4/kvmVyZer3fF43+2DaWKi4yLhPKZFWD8CJHTX"
            @"r1L03qIYvOH5aK5ANECkjnUGEwagfdT2EfqkvRF7N1oQLjB9LKQ1qyw+UKM2XceEMc7WgHopE+AF2tVliIQUoxpFP2K0X/DoqiOejdjt+R7dUQEH"
            @"BwW9zRQZZiTqePsPHFd+Z8z2G0P2Lu3Tv3OX4eZ1Rtu3UeuFBQ+2drn+xj2KwR7ZcMeXJtzA16pcdlFVMyP5NREdlVILIehIya8JOvT5UZ9J8JOg"
            @"PVtVFCuT6dV+QIXP50kY+l++f8j8ZNymX12dzIDNqkkkQnlMJ6q7kkB+XZ1nuqjEZ/035dfE1NfEhKgdUQz8elaNbFqV4AkxcYeVM8/S3brDuHvV"
            @"U1edgiZocUB6UPDOb+0y2EpZeKDNzMkGax+qo1bJh8KoD/lQyIYOR0DSjOkcMSyfCzh3yhFFBS9/xzHeNpA7puag1YbmQgwNw7vfyemvp/TurjPa"
            @"3aEY72FTXxJ3to8R9YovWxEiDpGSNychaABqu17dxG6jpqO4LuTXRcMVPWTrlAzVSSdf4n1QSaPTcqomgPNTSRXNQm9Dw5WSIu9hYzlIfVJD0kqG"
            @"2m6XsxW8/aQajlvNBK9G9xTrIkGGSuxUETtG3L2yqdXzz1QAFyEEWLU06rM88oHH+MbvrmOLPiZMUAKKIsIF09h8yN61ixTDPje2pll/fZn6XIuZ"
            @"Yy2mT0YsPBjSmPZdgiaCKHJ0pgKmEtjfgwsXIvauBQzvpQz3xhR5RphEhPWIBz5VJ8uFg/XUs4iybTTboBjfLcfv9Cl0CKMME9Z9XlkF5zLU5Ydu"
            @"YTIjyXW936mmulTDf/1A+snMdCQx5bTQydhS9QW/w0Q3lD2zdhspifn+4vOVjawguE6maflFBXqHnD1PnvCk//snFJs2mm1rsRf7G/M8Mj9YN1xB"
            @"gkQJCYwwHu3zpf/w22h+GSEDJ2TjgHMfeZQP/tQpvvTrdxhu3wF2kaCJsMMg6zDYmOLum7NEzQ61qYTGXELcMphAMbGlKKDIBNsvGG7tkXV3cdkB"
            @"ruQ6uCIhGxznz/4/j6G34e539xG7RZHf9OGLG+FcScsix2V7fkhXyYlXl4IpDnuA1G5P6m/qek794KsJ2cdUJ6RS4TocIlwtpKivJWk53rRcJNfz"
            @"w+PLKZl+bl/se5VoT6aR4SnJaLHORFFf04noeNV0Jn5KWUW8gGLdlzdM2xjTdl5lckUk910aJkXtbXA3cW6MkPhEctAkWTxKbdrQ37iHzdYRMwR7"
            @"QJptI1HLT5QZT1EMpkh3W3RvtZGgRhAnRLU6qgVqU2w2wuY72HTHT3CmYNTbRdRx99VNvvPLMBwU5OMt7OACLt/1kFqH4Kp37NM9PkFQjuR2WrqY"
            @"ciF0gooTrcaYopkpJen4Pr0Mb6X0vhHah+6jJPIrSBC15nyJwr9kKeX3pezuAy/br5Nu9MNJmJX+XcnbyyoNCKemffj5ckGrObTE5wiqsQDxWTHR"
            @"vBJjTM0TWvy0byAmqJ1n/uEf9UnYK18jG7xd5gEFJSop601MUMcEDSRsYIIaYvyMDJFaGZtniKS4YoAWPa/k6DJUxzg79gbbHKMxfQyX3iXtvoPN"
            @"NkEHnvVDXu7y1IsuOkXVdqEUX9dyo7vsopKXsWKVEChPlg9leocDlv2CSblAh+bQc8MnhT881/w+FqrrKdWobE2lpG6hricT6QAvG+CV1VwPJAXT"
            @"KUdH+6SsL2BR9tmk1YRIrzqZX8MFc5CnqpqqujURXXMUvvxOjBjrmUg65ODm9xCG5MM3fZSP8dKhEvmh8vRwLkFtHXF1b9Lva5j3lWhX0tk87xCX"
            @"4WyKOj/dUjVHZIN09xYSTJUvpBSBoMpsO0Q9d0PVD6wHH5h6zcAyppmMN/A/E61GlZetLaKp4sC5npkU+O4bqlyp0ejhrAoJ4kZ8OEu2Gqd9v+ad"
            @"JL7Lz8+g0wpUiGm7SpSjmg5TTSxxPoOhcp9mnvoRcofO0zeo+YUPV9SYtpFwBeJ5AkFoQXQUE3RQPcDl93xBTQNUQoyJ/BdIMFk0CcrDTVjORa/6"
            @"RaXsYHDlrFhfVhBSlKJUY3K+WTuY9r1ExRaa98oyeOHTPcIkL+e52yUyVrutZWwkotmhX/Z+6XAwfckAKmdVTPz+fTNlD3uW/Uht0DQ8nFjvf1ld"
            @"pbdW7YBqdU1bVdOyVTNVNJYyKvaj4/xAjGqMnEycYTAvUjlKu82Ec14dfUkU18UF8yqup2K3jY3WMFmC9RBYXd+nwtSUpy3AaVQ+UdkiSoi6shNe"
            @"Av9zA6LGy9ioLYU48tKfFH6BKLzeT7mQWvTA1Pwp0qxMmLqub0897Hwox2Fvq6vUZEriSBmkyqTNtVoA1610BKv+fTdJn2kmpRqn/3+/sOUkuCRk"
            @"MjnatP2qV+ZvckriUp/VT2PW7xvD2XNq2j4Qrk6jJGKqL5ekyuwe9uTeZwpLlqxUEThlpG6KdVQ+htUyThuDK8oFNglqysMe4M1wgBpBXFQ2XZtS"
            @"uqbk7WpJ3qy4cLj76j9V553DufLvihGKKcfq2m0/ndpul/xh/JjSYt3Lb7ueavVcrucH2Pv3xCSb7adkVsLDWsFwud//SPz9sdSE0pUGJogQgpkS"
            @"FATfRzMuZxZKJaZbDgMuZ8sG3i95LXEfXQfzZRtB6hlImoLbF4KZcsqZVV9Y9BG2VNevuBV+yLCqjtRHvdPoeF01fce/DLePaCGQiBRDUZuoWN91"
            @"qOpHDmhW9gCVfG/NfQaiPAATNKxFKWzvF0vu9z2SbUMRgCszLXbDnx4Au20ku4hgxfhnFHF98ZOX03KEXuOQX49FPKlUqMilVSefDgUdTcTz0UzE"
            @"9fwQZrevvg6y7zVYtVgX7kNsfhEmEzJVNfO9NIc9tZWwrpEqHyWJkl8D0xYniRhve32y1m5LeS2QWJ03mTJBQKXN1jI4Fslw+TV/Qn3Dr2q4Kkis"
            @"zvXUp/VL/2naUJRCIJJMHGHJoFWVMpXqK8VamY5Sh8g30Gmq2B0/lkgzN2nw9vk2b669ifMCtmVmoLqEX/lS1F6y+/gKvUOl55Kgf1+GW+47Mlqm"
            @"iVT9rEQm1gYkiBpxZTtFwVQqkaXKvpaA4LBVEJBS4Vg1cwRz39fXVPqfkmjpYbtIopOJ0OVNfx+MLzVd5X5zUDWyVfOYvLoippwOLZUcdkXgrIYX"
            @"e13zauK0lPzAwwnUPj+Gul6Vj8TnI71pc5JoWVYo4570cJJ1GRMe+tKe7zcqQYL4a6L+e6oEqpbDgI3eFytJNfr1f9eCOQFsVSAssYRRvdpdsTKZ"
            @"dukXbjLqzKeKDi8UrojcD90lqSbFlIFvVtWjKCGqoqlIuFotol8Ez+HzQ+2rLvj7TK1UKsv3nWABNFxVJBaVRM39ecdJZB8fmuvqRdx3jcM5rlUr"
            @"fvli7E5J8uyqSCJa+hOftzy8N7XbVdB5OMWtynbb7UrGW9V1tTKTzsdE99/jxEeVZnKSL8WXNKpYKTBBiO+PEFuBAs+407QcwmR9h0U5P7bK4PqS"
            @"dUcoM71eLKLvacqHs2rL+GlYqa/5EUCmLWK30WCmzFNlpZxb4AezTwLjsGoLKW17dvjCNRNxe/f93bCapXGf37VlNO/TBN4H+Ey0VklOt+8p7Han"
            @"9CtD/51uX8H6mW+a+Z9J4ud26EjE7atOpPYs6FC15CZI1c5SchS8SRzJZKiyBJPpBWXrCyKhaMUv0VHpy6cNSFhOwZsgvHKOX3rYAjPZjYfpjEl3"
            @"dHmUDxOGPpUkDg/ZXa9Chz5f53qqBqQoq5F2h0mGo/Lspu0zE5Vd9yzOyX2UcYkc6pf3ZGL7q45tybRUqze+TuZbToMK4t5Xv1EPpb9PD/0+lDuJ"
            @"6wA/psCfhCrz4ofMS0zp07x2uuuVvQu+yirVpi5bLl1lTQ4rDdWJnSRpFfyIbU0DCSKMD6xsORAwqKyK8YOvYp+60KEgwUR93w8dicvuisDvGI9Q"
            @"vM/xJIrJYh86SvEJRNOYQNQJOnRdqRK5KjGmrPsjofcRvhtRsTseXVYtI5NAUMrqsi3LAZ7pJP4EHV67QliuNzmBk+DR9ctAC8Htl1JX5e+4npZk"
            @"es//qDQXfDwgHj4OfUzgucZGsZ5xVUmklhZCdFRaoZI5fKjh4Gf+eisAaoMgiKoAwhs9HxlWi2tBMwPWlIyi0nxIZev9DCCs/8L7mtDUj5iRCm76"
            @"4y9iJFEkNFIRpssRdb6LICzV5Sem1Q968nPu/Mwf15+M8cb1y+B4pBMo63egDyckqGD9hOBR/as6KkXGfANX2dZThhtW0KE3vZOUzb6/lo5E/USW"
            @"ElJLWbsYlS8/PTRzmkr5uZLKHZb3lx7eh485/Xg4CcT4ac1l1cGH68YEh1hQBAUrijUigec5+EUrf6F6eSWBTwLUj/UpIXHoW2ZcrzpZWlZ31Ugo"
            @"ZT9oycELdeLU3V5luyveX7WjmIyqK8GB6HASBEt1L9jKfHmoXMYn3Lc41ekRHZY9VrayHl5upWRJqYQe+pe+Dtenmh/lLcXQf64aJ65DcHs+N1n1"
            @"deloMhwESVDTKMMLW0L9kVHNjOhQTCW2oZmRanpO+f7K7IREUc2fmtKzV6vnbbDxzKEK5ZQpHZ2gsPtl1u4v/lWw2uuNq4Ia05b7Imrl+yH44T8l"
            @"dJbDSTQT+IzEHjqXvPT7kVkpu6OlushkIo3cF8GrR7BVwpf7/N4hsqzusfS9evhsXu+vvP73oVH/HaYqhpbpHV+JqMx0lfOrkPAkAZu68vT7Srem"
            @"iKs0hvwixXGtFCcqkz2l/pZg/IJJ0FbxFzKVg5MqzVNB8wnoyA5T9L7sUcFx72glVjmcwTAhaFQvsLLZE9XKQ7nrspYV39fYdh8kLrdcRabxgr+T"
            @"5rcSDU6qojrZLKUDrwBHxTGopqyYKr1TfbZarEnNLfHP5oFClfqZWMhJHa6sMZWfcTKpEGSefXUYi8lEcEN9nlJBoiippG/LqwZ+t/lAkXLiSOxl"
            @"qTV1Fe7XYM4HZBVPrDpBJfqhHN1T5v9c1aFBqdo/2eyH6lRIqVGuPgDVCTe6UgkxHd8Y7Msp3ydH6mH9jrpyRDjfH3Md0gF8ElgmBbhyw0iZk9P7"
            @"Yp8SpfnnN50SBU7uv5rYUmWrq7pc9ZkyldXzPvKQtlX2wjI5leU11AMNVMCUu0IUgsBETBgq/o1Zf4ZK5DaB0H5ArfNgAWDkd7T3Haqub3x53MdN"
            @"ghVx+2U2oIGRsJoG7Xe4ZqhvEsBUQ3FLTrSUDr9ytOX3+6l8EgqaYSQsUzJDjxgngMBXOaXMBao/eVJpJ5Q/q068B0eS+PxaFYdNMgzlUMTSRE8Q"
            @"5X0lCK38oQc5oiVS9rHY/iG/2zTKfOawFN+sputUnZO+ZcKX3cu4XUFM/P8HjYezJ4Xwk0cAAAAASUVORK5CYII=";
            break;
        case 4: encoded =
            @"iVBORw0KGgoAAAANSUhEUgAAAHcAAABkCAYAAAC8e6+/AABkAElEQVR42o39eZxk13XfCX7Pvfe9F0tG5FpbZq3YqgAQIAAS4AIuJkVJJEWJsmVK"
            @"thYv0shujttLjz92u3vsHk9bM/0Z+zMee3ose3raasuWvGmzForgIoAEAQo7sQMFoFBrZi25x/62e+aP+yIyskDNZwofsqIyIyMy3nnn3LP8fr8j"
            @"xkSAggIiiACAVA9UlckfBUSB6kkq4eHkKcKf/EfCdxW0+gGp/lORGCQxKjEiicd3RSU2mJaKJCY8Ow5vr5kg8eTdVBLBtESA6udVfZfq3yqaCZoK"
            @"kigSe/Xd8GuUm4jEqpqB74KmKpKET6epohkKKr6r4QGKB/HhGTr9waeukejU9TSoluGTji+NVtcV3fsaOr464ZEAqtUHlH2Xn8oeItVTbrrkwW6C"
            @"quK4yS7Txtx7bAC/z8CiJvyCEwPLlJ31JmPL3l86bWoJhlaTiJiWiqYgsWAXK4MmBoml+hlTXXyjkohIrEhixLTAtPbeRjMRA0iCSCxopmgKksi+"
            @"z2paqO960YzqZvH4rhFJQGOP76oEW04+kwDjzy2KqiAyNrwGw46vhyioIpg9YwOKr65G+JnxdfBoZTiz50T6JzjZxMbTblK9plLZShBjHP9//Rnf"
            @"qUL4UBMjmskdM76T9t9R07dWuBmqDxSraGYxLY9pKb4LEls1LZAk/GQwmigIEpvJPWKXhODRInYxfKCx8SQe30PBWysvRGIqQyuaKaBablSGS1XK"
            @"TUVTnXwkzbxqqpSbqr6rSIz4LFw9QUVR9VMeN+VRk6s/fXcEzx9fn5u9TSd++94IGK6tTnm5rd5PJ8bf//zwHu7mr8rUXbLvrqnCsQBiqk+gU4Gp"
            @"uiqTaDJ2Ux2/uUcwVfSvwjB2CUzLiO+q2kVRSRBNUYlFNAtGNa3gnePbyLQEu2QkGJzKe8P9L7EweZxQ3TTBc8P97Ck3wXe9auplbHDfVSTx6ruI"
            @"705/LhHTCkdCCOdj68n4MdPG2u85k5tbQDDV9dTJ32PvG4dlQd4bZ6eMOLaLjqMooOoru8k+RxTRKc8V+RNPzOkbTdTcdM6y/wyuDBA8KFy0cOZN"
            @"rlYSQmIVKkVi0cpAUp2JGrwwGMsuGfaMbMJrJ0YkFiQRlTh83a0YMa1wVktisIvhvSX2BK/0+K7iu1591+O7JeWGV8085YbHd72WmyqglBvjMI1o"
            @"Gp5fbjpT+6DX/Hzp0wtMedv4eBKpbl7Aazm261RInwrN+8LtOFxMeeJeGjSxgu7LbfQ95+ze18JruT2jhViqqoQzS/ce6/SdOPbGmz1z7K920WBa"
            @"PpwXSfUrL05+R++71dmaGCRGJTFEJwsfPCOW6JSn3JAqUUI0VUzbYFoGu2SQ2IYbITFqWs5Ep4Jx7aLFrVgxGDE44zBiQRUv2vbV5yl9icdTapnm"
            @"WqzlvljLNXvTS7FWIolH0+AXviOYlqrHSDgHF+qnHt1Oz3/aa3oBMXFwKs1EJBYxLYtdUg3JWynlhtdic5KA+RD99o4uvck5dN9ZOrktdF82u8+b"
            @"Jz87SXTHr1siIkjIlpkkTCJm/+sgU8aV6bN+ku+Gv+2iQRLBLgqSqIazT8bnm2iqVZYa7tPgsSJu2QN3LXzo0XqS8OLVxz9tRWK8XRLRLNyHdtFi"
            @"l0QktphWJNEpK3bJ4ZYjE52KjMWKw6pFC3BEaAGCw+CqcOxxkcOXBaUvKSkYkVK4nFSz1dQPv1tI9mapvusp1jzlxvh3pUrIVHy3pFgbR52QZZuW"
            @"JTppsUsR0amF2tL/mJbD727n2/+spFjz5Bc85ZTRxt5eXe9xwrWXKFROJe/JV8LXv/+ZvBe2Kw8XGXvunmeq37sDxmfDvpAr49xqz7BG7KKoXbK4"
            @"ZcEuefWdWOIzVQjqgqYezbwWqyrB2NWZFYuBoszP37F8kqVDCzyz9kfnW7bxaa/gkcQisZEQph1uORa3EktyT2KTldg4pAAdCbGp02q3OHL0IEYL"
            @"bj19kKMnmhw4PENrtkYSR7z23Vd5552cW24/jnUJT333LV58813W042VmuOjIy+xkp1VfHccfYKBJakMHBvsYvhcxRqYlsEtR8RnGq7+UUr40Q9+"
            @"fuWt1Xe/9N3zTzzixC6lqpnCmlJMHcFSJUV+qgySygn9VJK0z8u+f9kj8n0P0nC9Ji+gTB0S4Q0rNx1nx3JT2AipvInREBYFt1yT+sNHZ2/58vXu"
            @"2rMl+QWvvqNoVmqx5pHYq10KoVYzj+9qCTVJ7v3qK7/zZXlFkqapPejL8H1TRQEjphURnYxJ7k1MfLppa20zAkvE8vIy93zoVu7/0BFO3pKwdDgi"
            @"3brCkdmMNO1QK6/S3+xy/o0b1HZ3+Kt/+SPM1dcoveOHP7zI+SuH+fdfe5c/fPylpcQm94Ikqpp6ijUrbqWqyzPFo1W9HPIJt6z4riM6GWl82uTJ"
            @"vTM0P/3w+x4m9jM8++7zH0WLtSo8r+0vL2XPAzVk3nvZ9ffLeGS/jaaSqUlJedPPqYLbK1vk+/UdKjObSQ0X3sJUd5+JTXX3WtxKJNEpr6b1g+/7"
            @"Ak+99d0Hz66/SizRqVLz80J2tkBiodwcZ7CCZp5iVfEUkp01mJZUyZQRu2gxLaqzzEl8pm6Te2eklriR4a7338kX/sJDPPCRRRbmerj+Kgx7FMMB"
            @"KiOuvLHLo3/wKrMzjqXlBQ4cmuWjnzpAMrpGt1uCL7lxo8NSY4b/4S+cJEruTH7rm2+eio2mXsuNAkmUYs1gl8aZchky02RcNxuxCSrJ4fqxf/Sp"
            @"uz7NQ/c8wMc/8AMcWzzF1u7mL7x2+Q3Odl7dzBl+t0qzpmpcP1WfGlR8lcOYSaPk+6Sz7wnNY/uNvzZ9Rk88908qlquGQHVX7Rk4BJbolBG7aHAr"
            @"EfHp2DQ+NSx811jPJ9/3Md5+9O17azZJCu+WCuySFbdcnUPng1drJlWZU0WJdJxtq0qiRhIrpmWJTsUmOplIkrRtgy//45/nsz99O43ydXz/AmsX"
            @"15mdaWC8QW2MzkT0bM7pD99O3Eg4desCDVOSdweURYR1ghaWWrtJvRbh/DU+dt8xvvXsDls7q0vORqfUg0fTEMAkUZXEiWl5ijXFLgUD+64E0+AM"
            @"nDy6TENq3H76Fj756Y+x8fsbvNUJtbjo+PyeToWZhOJxlhvMsFfH7iVMN1coVdy8qfM1XbxYMWavRpLv1zCUm7oilc/iFgXTEHGHrEanHMm9sak/"
            @"HPnaA8dnj/K5T3+Kp7/7kjMmwhqHMXZekFPhJX0XdACUVVuk8gR3WBArmIYR0zDiDlncSizRqZqr3a6jPP0rf+/n3M/9/S9givN0rt+g2yuYm2+C"
            @"z/AimLgGohw4WOPU6UMcWW4hAml1U1pfolFEUo85cKDFW5f6/NHja6zeuJu3V28wGPYaYuwhRYch2zcNg10UMQ3Qgahph8e+K+HomM+KbOfS6oVT"
            @"Lz3+UuPBBz/A15/4Ov+3X/knXOic+7URg0cLzS9UjZQps8hU0jS2cmXQSSekev5em2xf6TPu3E0fu6p+Yj03/WaTkmvcS5WpjonoezpOgmmZKpFy"
            @"xKdj6kuxqbN5Y5f3PXQ7H733w7zw0hv4Wko/75KKRZR7VX1XFZT0FUVixbREQi0suGUbOlCxqF0y4par6IBgk8OHMkbXXmT1/HWyTFg8fBBXFzIM"
            @"kqd4LbGmBkC/P8AasEnM4uI8w5FA6bHpiPPv3GDtnVX+8KsvUfRv4Y6HT9PrfJvEzpCRJhF8MBwdro14cu0/kqIpUm6Gq2hagiReNE1JXy7i2gdv"
            @"ZBtLz519hm8++w2G0vvdTLKzhRZrVfcttCwBU7VjJlGzuqbWxIuqUGq2uWeXUEPrXsJTNZX2+tXj5+3z3tBb3vP3SShXA0b317UqU95s4tD+G9ee"
            @"0alIag9GEtOwLfJhSRRbfubLP8qlL68zyAaoCHmRUzDE4pYxvhvaesUaoeRpoWCJTzviM+C7qKZGwg0kGgLgy995l9P1d3jp0ad5+Mt/jcXj97D6"
            @"8svMn3iAmi3w6hlu7fLsI9/ko194iFGnx3Brk4uvXePxr79CEtfZWr3Kqy9dwpoYJOLkiY+SlhbyhCSKEG+JaSSxNBNrawz8Op50Oabxaa/FakF2"
            @"Njia7yrlRkmx1st7v+fFd//jo//505c2L632tf9IWmZncynWQrtZK1OafTVqaH7YuNA0u/Xg+zaOzJ3k8bO/LUYS0HLKWP69GdO+hofsT5bE48Y5"
            @"7/54XFWiU81tqc5fH5rhrfH/QjIVnXTExNSplQ2W5ufZvZLxvpN381/9o5/gkV99jq3uNq6mxLHjjeuvnnpr57UNI27FV2eRKBixSxa3UpP2w3kp"
            @"KMMNUU3BJaIWh3DunSHJn7uTRJ7k6lf+LTeeOkR3kNH4Uw+RJov0r1zitcef4nuvrTFXMzzym98m0ZwbN3bo91KsQj8HGzma9Vlq3Mbc7MNc2dhm"
            @"1i6DzYjpY8qY+498EtPwPPr2b5FI+17xxb3eZBto73dLsrNeJA5pkO+MdPhkLtnZZ9ee+1eCxIUUa0qxpppvHmqffKI72vxH3Wz7axaH7usGCiJ2"
            @"SWCtLk1W2rcjIjgTLReeNdViclswfQ5XJazq+Jy+KQkb17myr+EsU6GYydRHFQqf4SQeV7ctwbQsdjG2tQcTGtSZwfqYj3/+fuo6x7XHhnzk/gd5"
            @"6J+8n6LwnH3hAt9+7GleXn0Jg13y5BdQifciil0UMa2IJj90z4/y4oWnl2703sFKhCGi5iKun99la3iQUw/cieQdbL5D1zuyK2eRvCRbvUJztEHb"
            @"FJz71h9TrN/AJAn1JEYR+qOyukEteM+gU+AaTYrNLgfcSSTOyMoeC/Ygt8enefbaM8QS0XInODp3F29sfXup44sHwzXML4AkJQUqmhaUG2IgtCs1"
            @"VTQVca2twbVfKMrsrMXttXnHI1bsoqhdVLVrS7Vl7lq6D1UhK7tr4CpPL997JMpeSTU9C5hk0yo41Fapt1YzyqkRVzWyKn3BoZnj/+ti++AvvHn1"
            @"RYkkaoWmil0y4laKwnciau3l2SN85gc/xqc+8GlGb3tILVtPlsx+wPBb/+VRfv8PHuVqdomB2SaWOJRI4paFcjN0uMIZW5Q5hw/NsnBjke3eKs7G"
            @"OGLqSYPRdsrq1Yj7jhyje+VF6vPzrNTrGGPI8xEZNdqzTVZW6tTqDW45OuTGzpDBsCArPcNcycuQ3ZYeouQQSeyY2zrAbc0YqWf4VPjImTPYOOZb"
            @"V3o03Cyz0WEOtw/wxiZYtYsl0alwkxdrBk29FmvBoL6LauYlTJhUJM7L7Gy4llUXSUIULLVkqXbknz144LM/e3ThMJ+55YvMmWP8D3/qV/TZ1Wf4"
            @"3rU/evZ6952Hphse033mcYUTKhr2DSUA3L5ESfd1Nau6OvxAL+38uunbpXFz3FTjuMQ0PvWpuz6d3H/6Ae678y5uP3kKt9EkU09eeBpLMY9+9wl+"
            @"57efoKwNiRNLVjoyb5HqPCUM0hPULRsfnRLj+fff/Pe0ojaNeA4jULd1ZuIWUVpy9slr3P3nDpIPPbVmQToYEScNMAJShu6MlnR3Oqh6CoTtXk4/"
            @"zSmwFFW/2JsaZTTP8qlFFgYZ3bNt0r7nyC0LPPTZU3z9t8+SSI2WzJOXI5449xVyGSLYpcTMrORadDLt/Lrgu+FGl8SrplBuGDTz4ruhJ6DZuP0K"
            @"ZVa1YQHo5Tv/8rXtp3724qDFieRO7lio853zX2cr2yQrs7NTFe4UJkL2El/2ABNippPiSYdqr3k9PU+USRPDMsg7j/V3dx5zUl+czADUd3Ofn7++"
            @"u3nm8Wef4fEnvsds0uSeu07xIz/0Ayx2D1POZjz/X97GWk9GSVEWlOpRBSOm5SWM/UTD+a0qeCByYbhRkzaRgXbUpp7WmW87GtEiM8eWGL7zJGlv"
            @"RNcKSysNsqJAVMmyHPCM+ilZUVKWntJ7vBrGAwRMxNDXqXvHG8OIoz91iPdLSfNFYeFMi7gttLMWB5uHyEe7bOZrWOtxGgE+qQAM7RK3LKGlmHjK"
            @"jXHk9ApWyg1Duemxi1BuIpqqmj3MhUBaDr57qfdmor1B9hVzQC+O3uGxi78uYKu8ZwyUMMhUc0NvKn4nM4HJQNpPzXP1T4bJhPBjMRLF1VeSChkR"
            @"p9p/5LnLz9Fi7kxL2rTsHJcvXeHipcv8H/76LzLTmGVnt0tuRpQ+p6Cg0BIvHsEu2fFAPsxp21bc5IxVLzhTp2VbtMoWn/zinXz85z7MbjrHpauv"
            @"MtteZLR7lRN3zKNGIUvJs4wCh9MhTkoKH4YdkQ1dtrLwlKp4aUDZwNbhP/zuv+HEtZ/hoQ+d4C/+zZjFGcPwTc/xA3Mc3z7OTnmVro+JyholBUYM"
            @"uc8QNHUSncoFRDQ1XmLwXcUumeC1LV81OhDT8lp0RQICZHy5jdiWlehk7rNXJCm53D+PEcFJ82Sh+QXVYqpqCZ9B9iVVsg/+tFfzGgxTTeu9noW+"
            @"d7Qk4NFMK8NSnS8CxMa0sJ7c5qQyxDcKXnv9Ar/zyNeJlyEvhqTlgFQG5JrjKass3C5FNFcc9ZWIpJ2YOpHUMBiMWhwJsUlo5nP8+b/9af7iP/sS"
            @"1weH+fqjF/iV//nrPPXoOXq7A7LNbUw+wqmnUY8ZlYayBHGOrFCK3JPnJWnhybMUKXOy4ZCdzi4v765RzMyzdLjJPffXuXZ+m+3LI+whw8F7Io7Z"
            @"w8zYOerSJJYGicyQ0MRIBEQJ2EXxdsn6+IyV2oOO+HToiYc6WLBLoKl63z3cPvmSlTBGlKqv7LXoFpq+4hXWeu+m7+y+iKoJs+QKuYFMdQinw/P3"
            @"Q8pMzYjdfpiG3NSwNlOdk/cMoDJFszAGy87mmq6IBrSB5jCTtHj0G8/ymc8+zOLBGXqXOqgfUZCilCg+FYXENJNIGpQ6RAzgDUYFZyJiUyPydY4d"
            @"O8hDP3UPpqnIzAazR2fIu5/lW69scrH7DndsbzE7t0OTIeVoyPkLHUShO/Tc2O6x1S1YH5R0c4uXg0h8mIE9jjtyH63jd/PAPXdzy8mSF7/2PK/t"
            @"NPnyX5tFEmH2hy0nH5vnbHqMfr5L4Q1WewzoYBlhsDhNVowkK6Es8WlBdtaTX6BCiQiSaoXn2h2u/93Sa6rYGPXZ+NALmCzLhZ03a6FzH+G1CI2M"
            @"KXjTxCYTZMzNzcj9HSunqnugN8xUL2uq30xVEu29VKph5L3htVgrJTsrIomoPCwqqAcx0Bl0+cZXn2Ll8GEG9LAUFJpTUoBoKmLboMzIQQRhkG/j"
            @"ovBekdRITJ26NJmp17jy9pDf/E8bLBwuufvONvE9Z9j62H9P7+oau4MbbI7WSTsdhr0hXZ+Sl0KGMJwrGLWVZtSg6WYobBM7M0vcNNgoYjgsePXx"
            @"3+PR/3WHOH+Av/b3PkT3mQGb1yMO/HDM0Q/PcOcf3k4+U9D2h7jSv0CWDYl8jKfAU8MQYXyDUoZJn+snS+LTqhleNEN9J1xwuzTIBo8ZMa2A0JSs"
            @"KjVjtMz2xrfVUEFvjqLs7zP/iVg3M/Ftt9e02Jso7MuWp/qbogYo1iA6GcrmcqMgjzXMLPFI7ClOK0VbywIjwuPP/TGfuPtjQE6hGUqGUqaoJEai"
            @"gKvSktva9zEzm3D28usUtouThKZp03ZzFLuG2RlDmTb45//tUzz8I8f5wR+/jfc/OMOtdz6IdYZhFzZXc7K+obuTs7U9YGezy+bGBpubO3S7fXrd"
            @"Dju7O1x76wJ5WtIZwLa2ef+feYj+xkvMSIvFEw2uP77Lja9arn8XDn3EcdvHmwyfOs11d5Vrg2uIOoxEJLQwEjEvh7n39H28eOV5zvc22o74dMiO"
            @"izWRADZQfFclhGhR01IJgMAKpZmNj8DxSHAPoCZ7SEqRanokNyE4dG98OPm3TmXLU0C2qXHF/nETEoPPwgDbLgqaqpabXiTJNX05jPLKTa/5ci7Z"
            @"vZHEvL3+NrxmMU4Y+ZwyvH5isQgOKw6hoG5r/OJf/nH+/a82eeHCs9TjiBmZZ7l5lBNygFrh+OgPHeB7Tx7Cl4br1+Cuex02CplhMRpy7tEeRWq5"
            @"vrrJ5UubbHe32di8wcbuFv3BgP5oQH+0Rek9isXOrbBy3/0cv2OZ7hurSNZibsZx6e1tbnjYfSti7vgivT70hik38h18qVhJiMoWNVfjgFvmttb7"
            @"mImaaPk8TmIKzZYE0zYSnxaNTgp2CSk3ch0+WZJf8EZTUYk9mpXkmUy6TFQgQj/lZTo1HJoeCbIPmrM3uC8nYdqpjicUN6FqboJKCrYV3scAdhE0"
            @"A7uoVQFvRJJy8pblRujS5CfLslh58erT4TzFIEQYwEmEkQSrFmzB6u45/uDX/pjbZm9hNbmBtQWLyTInayf5yIMrzM7V6BjL3OI8w94WtbrHOvBl"
            @"uFfjdoRNEoa7DicLFL0MRoorlNiANGYwtkspGYWWlFlB+8QtmFpCv7ONj5v8wGcPY85u8/bLHVKb0bU1ym8LWsA1rjLQHpEYWnaeleZRZrJF7j5y"
            @"K4tHDvC1Z55l4DcxYrFaO1WT2ilHhDHBWLkO0yE7/3JE59dFi24YI2o2mxz4m8Oi97uFTy/sVbMKYiq/9PshT8L3mf9V+OnxGV4Z202SpnGHSuWm"
            @"0dLE4l2wi2OM1BiFqBVcZg8PXG4odtFTrOVoWqrvRkSnjLokYQYnjeq1PeOyBxVGZpsXLj7DHbP3c+fCPWRFyiEOc/+DhznyQJuL/3YL+VyP5ZMR"
            @"T3y1x/k3drjtDseJW6tCzcbU53p0b5S4REnqhtTHRHENm0Z00y7d0S7eWyih1ljCaw3tbNMwh/nZL97CzAs3eOGRlH7ZY+RTirrS6VxjzjaIjKBS"
            @"YI1h0RziTPMMx48uc/LUIi+8cpXU3sCWhiYLtF1CIg1EDQUpI+3R0fVkD49VQXRFU2vsokyNUgPMxu5BWsft30nyU0XWqiwaX8txdzHgqaozdxKM"
            @"/f654KS1VQHIQ+gPBhUkVjRT1cya6CQa0IljHLFKgKeGaB+go4ZkJZY6LbNAzbTxlGS+E+50EgwWbMlWusmJ2WWOJ7dy9H116ouW898asrGWUrx6"
            @"lY/cX+fMT5yiU1MuvtBhxhQcOlFnZi4hnhE2rvfI0ozhqGBnd8j6zg43drfpZFuoOCLXJq5HzB5YxkQRrYMHOWFT4qeeYvOFu0kHKd4W+LJg2O2h"
            @"Bqz3NKI6LhNars2B5BhH7C3ce/8BnImR4TUiJ7TLgxyQBgvmAImp05c+2/kO6+VlPGt40leqCrSlFSZ6d7T5SyKmJbhF8F0Rkym+GvNNtRP1ZrTp"
            @"mM6jU4YesyCkSqh0zFuRKYNOIzJsCxkf/GA0ALkT0/rSTLz49zdHlz/tqvmrwbRCr9gu6QQgblpU2GODUjcNVmpHadBioDuMdEhsZsjLADkVgbTv"
            @"ed+PzZHVhJd/Z4uubqAmp7Zq0M6AO/5OzDXv+Lf/4ms88UeLtJvzNOcaRKZJv2MYpAV9U9JvgY/btBdq1PJlsjwFU2IlZ6dzmd13exztHufG8Fnq"
            @"xTMcv/8fsv2uUp81RCZCC0EzoVaDetzgQO0QiLBcO8HBuSbXz+Vc3txhyw5ZcLdwqnmGM/OHmJuZBYGXL1zie72XGOU7pOz+hlJuiLpllYCpEsBK"
            @"dEpDy3LTo5khOulMdCrX4ZOiwdD7aSjT9Bw/Vfu8d2rk3gNG12kMMmNQWGxEYtS0gkdK4nDLDx354eTr7/76w0i5KdglEbtYMQIWIxef9mV+YQJI"
            @"F0FFKLVkub3EbTMnGHQ8eVFSn49Y2+mxNdqlEc0wN99g42rO1nnLleEqPb9BM07QUcL9f+048eJjvPL/foXzb+9QmBP8xJ/9MXY2e6yvX+DyhSt4"
            @"PLmWpGlKWRYURUlRDBilWxTDCEtMM9ngjsVdbov+kO1XzlHWLbef2WLlfbdy441NnBHmTjRpLyZk79ZgWGPWzZLUYiRybPb7XLm2zaXhJXaya0TG"
            @"cCy7gwceuo37/u8r3Hisy6t/dZX14gp9fwNPfj4Q1jQB063QKBk67jmbllB2IxOfPta695ELnefPlJqdnWDJx+AmGYMW/U29Cd3z5Mo596Mf9ea+"
            @"ZcDoVNyXLFRMEluJTvXKnX/ZNu0v3zX/4X/82vYTPxvb5N4wvpPEGLsUWbuUed81Ae6aBOOGfupmb5cHT7Z48MGj1GdrXH16wCJ9tv0um+kul7qX"
            @"2fxuxm0LJ5mptegNtkEs2BrD7TXcuVe4bfEd/us/E9HL1/nRv36A9vKDvP7Hl/hnf/sqad/T2c2g7JCnPZpuhDE9mrN9Fo8riUtp1a+QZV3Orw6p"
            @"W2Vlrk7f/mc+9N98ibe+dpQDp9sce7hOfa6g+3bE7ssx2YUm+bph9dKQ3vWMbrlLL1vH6xCrbVqNFr1Ny1P/eI1SelwoztEpVlGTdaxGp0r1XZX8"
            @"vFfTUtVsujEYjrtoudDs7IXOC/eWWqzty58m+Ga9qVWs3w/ViIhgxdjqjjA34XOqroiIBUlQcYKdF6LjTqJjhRaXT8Rn/sqHVz7HM9e/8b3E1O5H"
            @"7JxXSoHSe7DYeSt23hmLkwSncWhKRHPM5Qd56Mu3csvfWSBaF3pveK6nu1wfrNPLeqSS42zE4cZBMp8RWUurXmdwxbJ4j0XLi3jjmV0csr36Crvv"
            @"Pg2dV/nwRwruuuUad9xyg4fev8kDd+9w/51bHJi5wJGFDZrxVcSv0+8XpKlhs+vI5BC7ecHVaxeIBq9z5+dbnPrkYazrYPyQ5nLO4gdz5j7UZ+mT"
            @"OUc/JZi4ZP3lHDWBOnK0dowD7cO8vvYObzx5kZ1zA872XmfXr+NVE5C7A5UGFL8TOEqUBtNCKBFKwbQUzbyUmwTMVgpa3kz02WNt3dTRkOnsGazg"
            @"9oBaMkZcjP/PxIG2EUBrgtgAM3WHUDs3axe/8OnDf5HMZJ9e718+XmNm5Ujt1lOxrR0f5d3rBjtnvE0MEU5iIqlRMzVqLiamxsrSIlHXkb6Tc+Wd"
            @"PtfTTii7TIyzBiuOAzPzzNdmiDWmlkbM3xZz5Kce5Fu/f4FGvcfBWw7RahTY/CqL8x3W33yRor/GQrtHXfpQdBh1tplrJqSppze0mHiWqx3h3FaL"
            @"Ix/977j19A8zy5D2SoudjS5tt87mWofl2+/ERjFagM9AKLBRSjzT4/hHDUVhufFsycHWErPxLO/23uFC/w22/DWiWg0anm6nD8ZUlFeOey3LgvQV"
            @"j9+R0MBwQClIIkIpRrMKG20FzSoIEnuG2Ts0J//JGL6z/4+bsAv2UQn3+LbomP8qsRCdEqKTpdc0Jz9/pHmMnd0BH5n9Ce6d+Sg+N1xL3+W5nUew"
            @"YpecxG2DxagDtQhC6XPSYkRqU1752ibP/dYmxw7OE89APDTkGhPZBOcsB2pzJJmhmdQ4eHvMwU84Tv35Ns9drfG99JP8x3+zxsmVlDuOz5EOS5y7"
            @"gXMF9bqQpymNhqO/WzDKE4ZZyep1x0bfsLozfLI2c9/DB4/+abLsAJ/9uQMcq3+eVix8/T/8Fq889T065VXevbzB5/7cl5iZW6IsSjAGFYuqpRxk"
            @"fOQvJ/SvznLuD0t26hvsZFfpFdsM0x7Lh5Y4uXSY85fOE9eaOGmQFilKsTZmI2ogvcVIIH5X51+27wjdT12vIrLcxCG6eZwgVYfq5iRLQcTE7x37"
            @"hcF6ZGoPHqwd/9KHlj7J/c0vsDnYwUrJQu04j+38Gs9ufL0j1rSdqS+JGoy4qtxxWCwijryAYtDggmyzWV7n/Oost84eYak1hxsYrLW0TZNFW+fw"
            @"A8rhH29Qe1/C2jDnmcvwxJOb1BfaPPjZv8jnv7jC/R86zNuvXOX5b5/jm7/zOoPhNfq9dXw+QE3gCpSlYE2d0ngc/mGGi8y1FpnxVzh1YEDTRfQ3"
            @"erzzznXOXdqgl9/CU69vc+jYc/zgn/0C/V6GMVF1SgmeCIqMT/yNGbo3dlh/akTsIlwek8SOjeubyGbCw6c+wlvbF7neOU9Gp6P4TgjFbrkMAP2O"
            @"6JifrFlAVQY+sMG0Qibts32k9WniF9OE33GtPMYtYytmt8erxxhLxfUvReycMXY+8GTtvEcHZ2Y/8j+9b/bTaNZmkJa03CxNN8Pb+RN8Y+3Xnk3s"
            @"zC2GCDQMmq1xOBMRERNJjNMmJ+bv4aHTH2T1xipD36HUkl6R0YrrHJtbZIEmK7fUuf2/anPH316iN2v546eHvPpKxltvD7h+aY1iu+TW2xb53E8u"
            @"c+hkkxN3LjDXOkwyups7br+PpDxBXN5CzR0ldkvMxEeJpc3szEGUmCLvM+hlfPRj8AM/fJh0KLQW59i8ts2//b2zv9bv3nvvQvMMH/jEErecOUrp"
            @"JfCSra2iXBmGlnHG8Q/OcOnZHt3rIyRSfFlycuZWPnjn/XT8kOevPcmWv0jG4KwX36tI4EMTGP0eMe3KmxsVlziE6QkdlhI02+etyvSM9qaulY5x"
            @"ywbVgrn64s8YolNbwyu/BBFW4mqoLElAzEssIsm57vP/+s2d51F8tyGtL93f/vzKZxb/Ipd3zxOZxoORSYIEgLfUbA00DBycJDiJsRqz0DhIve3o"
            @"F33EWSKJqBlLWRREhXD7T8xy9C+1SVYidi8p6+8oMsjZuXCNF566SGNOWDm5wMJSRpwoo2FGrR5x49KQ0hc0Z5vUG/PEziE2oRgWpHmXtMzxowgX"
            @"RzRqLdLhO1g7h4neTxQXYGI+95d+Em2s/OzjX13ljnvnefAT7ycf5ZhJM6EMWhcCNnFoLsweHvAj/2CF//zfpCQ7huXWcY7OneLZS6/x1JUn2OEq"
            @"Xj2CWzaEQb1BYqVYszru8ulimBYVayq+49V3vWqG+K5UbV4oswBzmg7C34eOULWz3Jj7U+T5+R+69wu/9trqa/+on+2+vLp9/v1GbEWSDlwZEbuU"
            @"+8FjztQfNtQeVIq1p3Z/+7nj9bu+OGeXJzh3WzHZTszexmA4oJ92qZtZmtLG2Zh+p8t3nvoePiqoSZ3ZeJalZJYDcYvbfrHFbb+4EKgII2Xn+pDv"
            @"fOUc33t6jW4O9XYTzSJ2bnju+OIMo0HOhXd2yX1Mp8zpmB021hM2+j12pYuaDNNoUXd16nYRophUt8nSTXYHqxxaPoYYh0tqIBbjDH/2Fz/LF35m"
            @"iHEWKx5Ri3ERXjxalogq1jmGvU186UniWY6cHvG5v3ucb/3SDr3C89TVJ7g6uEBhthAv1FyLIi+Wxix/g8RlSKKqDqBmXn23UNMyahcbpvWl2DZW"
            @"SnL6/tqXR9r5dcRk0+CJfSyE98BvwClK4hr3LNaPPfpjD36RO07ezf/ytX/6G86YGCRWDbwdT7EmVZtRKTdUijWR5B4npvXC7iN8eOHzWI1DaMfg"
            @"TMx6Z526zLIQnWTWLjAfzdKKWiCGru9SM03magscqC1wqDHLR/7BYY79+BydazmtOcf5V3f4T//kLVYvjzhxzzFml2dQHNaUfOKHZrj3w4u8/sIu"
            @"rzznMbWc0gjJiRrdawXNew7ihgsUeYGYEvB0d/ukg4woS0iLLi5Sjp9YxsU1MpMiJqQg2SjDJQlaFoCl8EO2rr1Es3WcZvMQZTHCOcv22ktsrl/i"
            @"zAd+gjw13PqxjJ1fjPn1/+llhm4bGxls0SA2OXHiSMs+eFkx4laUcsNSrAmmpV5ip7WVtpljuXmcGbdMp+hwOXuTrfL8IwXpyzLm8I8hsdUcXqdp"
            @"tlNIcw0jP0/N1R6sR43kX3z1X9Buz7HVv/pLsakvepUkIPcq/QktVhW34ik3RYtVj8SRiU9fS99IN4p7k7lkkU62iTWNICHgBTGGGbPAicatLETz"
            @"zEqTotbjQhfqUZODjUUORHN8+O8fZPlHZ7n4dEqrrXz9P6zyx797nQNnFvn4n5rHO0ORl8zNCweWalDCs9/e5oWn+pRlTNGBwghEbVpHQJuefi8n"
            @"SwuGo5z+7oDMxHgpcEkbG83SnqnTXmhVDQKz14KVUPeXLkKsI9texTWuUsRX2Lh2mIXF+zCiGOnTrl3k8uuPceyuzzHc3uH+L9ZZWzvJI/8mw9Rd"
            @"yGXKlP5gm4Q6RmqUlJTkS+p1qUaT29u388CxD3KoucL5q+s8t/kU59Ln2PWXf6HQ9OVSirUxYGI8dn1v40LH1LDJCNgJlu5o51d2Rs/9CluOY/O3"
            @"XonNzOnSh0EzYlpGqzR9j7sbC0G/yWu56dV3X+8++aAnR9Xv6TxUjW9rwJdw5z1H+chfOMm3//k5stQQ1SPmdYYP/NcLLH++zfd+d0i7pXzj19/l"
            @"ymt9PvyTt2EPztDr59QTz63vSzhyLMKXsHk94+wTOTOtJiUlWW7oF540U7LMU2Q5gkdEia2FVpPERqTWQpEx6s8yX1+gPdfEq2KsBWOr+aZBjWAR"
            @"rEuIkyaDnYKV2wZs+G9x5d23mZ3/MGpSZus51y88QefQHdSbyxTpiB/5K4cYbMO3f/ssM/UmuR+hFpzPyaVAKYlMnVtmbuX+Q/fRnpnnYvca/+XN"
            @"b/JG52m6XP7HJaPnkGKV6owek9UhdLb2EQzG/9A9iaQJEUzELTqiRAQub7991Eq0GPrEvkulCiOV3lOAzAZkX8jkNDVIvD68cN5JdCoy9dD7RFHx"
            @"YfqjI4Z+wPZgl2vnOiwm87h5ZTTw3PlT89z+l+b4498eUvTh239wjqtvdvmRv3onMt9mNCw4flI480CDZiuehKD2gkNVeeXZktzHQEmuBiKlKBRn"
            @"BaKKRyweY6GUCEsd8ph+3GY2SZhJLETBQ0VMwAeJCeFOgr5EVJsl7wrDrmdu3lMzF3j3ubdw0QwzbWXW7bD++jc48eBPU6qnGK3zI19eoLdziucf"
            @"80jNspv1yCSloCT1Q5abK9y2dDvP33iNt956nY3yMik7T5bSf6QgfdmTn6fCqAUbBuSGTJH0xlnzfpLYnq6FDVAXHY5TcGui5TALkcRg2kYquZ7Q"
            @"SZmue9smpO9NI+6QNe6QNS6xYgNlkwgjoTPjPYg1jDol7z63RS4lK+1ZTnxwhnv+/gKvP1Ny4zycff0Krz6/zad/4k5su0HpC5ZPee55qEatHlVU"
            @"Fxlz2lg46MhHBbvrodr3HnzpyXIdSyJNUP6ioR40KJEBKT2+v8pBvUhzvklraYGyCGB1Y0K3x9oIDESNJjuX3sDNeOKog81L5uc9DTvAd1P8SOmt"
            @"rzH0bdpLy2Rphkif2x86yMbZiN5ahk0MpYdCczI/YDO/xvc2nuHdwQurXS5/LTe7X8kZPV1SrGmQU9qpZuQDQVwY4PhMJyGY9yRQN0stWCdJK/Q8"
            @"xVVdZYeYRsjiQssRNe3qx0sJU35nJTqFiDMSHRfvDhljD1hCw0IwWDEYHMY4rFiMGEpKqAkeSyNK+OgvHaZnHC98LWd3Z4tvff08D33iFhaPLaDO"
            @"c/QWuOsDNYyzAcRuZNwlrUB4wqhXsrvhiRJDkkA9FmooNfXU8DSMp+mgHVsakVC3ligSYmfZvJFx9eI1mv1VDt6+TH22HV5XBLGeQgdkoz5eoH/1"
            @"LcT0mFkoKDp9dKRIXlIOPXnP4yhYv75O8+AZjHUUWY6zHY69f4G3n+2wtbXDyHTplhsM2KavW+R0N0qTvV5o9nogdY8F0SrNKw09Z6r5OcHpABNC"
            @"1ZSIyvTIdmJcI3GlnSiJyFj/yTRETKPC3c6H4bzfETEtI6YtYlpOTMuIO2TUHbpz+X1nRtmAvCgqTJTBVCAyR4wVhxFHJHUarkXbz/H+Lx7h1p9c"
            @"5Du/kTPolXz3268zMzPD+z96C0SwsAR3fygiqTx27E0BWOARKwy3hmw8NSRez5jZzKhfScne2KJ4o0P+Zofs7R3ydzvopQ6y1qO9OeJgT2kOhjSk"
            @"T5llXL0OO9dWmZMNDt11AuscLqmzufoyvcG3qM3vMuq/i631mVkYYHwXzQo0KymHJVk3pxyVJLWE4c4mW9s1Dt1yhjIbUeSeZqvHoTMHePrxc2z3"
            @"NhmaDkPtk+mwU5C97lWHXvy2CKUKJUYHiqaIDivJxEGodSkrQJQFzQwmDgMHmajjhPrZTma8TkRiVOIpHZQKaREYBaKmJca0aq71pazof208hEfA"
            @"YlrO2qXV7QuUpcfaQIEwxmFk3NTW0H6swrXTiLmFBvf+3CKvPJFy4e0h/e2r7F4d8md+/g4W2yP8+pATD8xQn6njC0XclDxehQ8aXh/x9JdX6bxc"
            @"YkxEox6DeK5ud7mxMwRnGGpJ6ktUhPm4jkvqWBdhy5zN4Q36+UWy7DKvXM2Zb17m4PEXuf1zH6bMM1oLJ3nnmadg9F2O3tEirZdImVIOM6RU1Cv5"
            @"MEc82CTi0itbnH15wJkvzqGlR7C4yJCNRtx+JuNn/u4H+H/+0lchLZEphUxF0/G56dV3S83O1uPmZ1U0Haa93zNSqeCJaYlqHBj9U8KmoexcPtq6"
            @"5d3jS7cm3zr3+2IqHTFrJZmvQDvsKbOBJT6T0PqSGN8VJGlErS8VPjsbxlR2yREdE3GHREyjLLUlEjlnahNxLycxThIiU6NmZqi7GdrJHLN+kY//"
            @"1ClO/PASX/l3PeiO2L5ymTuPtVgcRnQe2cF2etz1k0dA7VjRc8KtUa8YK1z9xgZ63nL84TmOfKDO4fvqHDk9w62nFmnWLH4As40ZZht1Ds3OsdSa"
            @"p1aPUQcmclW3bB5rPN4PWdvIqBe7HDo2R/PgDEYsc4fu5N2nzjHYeJeFgzHFIAtn9aig7GVEatm5kfHCH11je3CUu370p1k5cxfFKAexk1A56nW5"
            @"/fY53jq/yetvX8bGQqlF4kUHiGYilCX5hdjWH3YmOp6Xo+dKX6yp6kBEM8E0qtCbIL4bRFfCaDVILbpDP/+Jv/q3fuyen+PRd75+LM13fg8M1klt"
            @"sZLZc0YkVh/YBG134P/6uXt+8osX1t8a5pq+nJbDx0VMw4pdcsYtG4mOG9whwR2y4tpWoyqJslgibBWSY2mQ2DpN02IuWuTI7CF++L89xeqG47tf"
            @"7fDhMyXNjYLilSbxpYi2WN7395Zp3zpDMQqMPcrxrQ0SGbL1guhGzMEPzDBzNKY+H+OcpeyA9BQ/hKtrw5BFmpDIlB68CrkvGOYj8oqM1jSLJC6i"
            @"M9xh9fqAOXosnz5E3IgQYPn2u1l7ZYPNS++wdKRO1kuRokRKx8vfvsYLj3VY+cCP8uCf+xlmDx6izMuqxi/xvgRRrCjXzl3njx57i8vXd8EqpRaU"
            @"xndBhyI6VMrrjaj1Z5yNjg+KwWOCOBFxgQAgtnLUCmAaxoGKWCOS5D5dy4blP3z+wrNc2Hr9p0G6ipbWUjuk+K4EwcJstrH4D0pfXlct1ta2zy8P"
            @"y/4jBkks0TERO2/FLRvi20ww6rIVu2QkwkoSkim1xCbCisNJjcjWSaRBK2rR0nnuefgo7/+zK3zjqyPKK12WF0f4LctJt8ThhuXwj9U48Pk5il6J"
            @"iWQCltdc0FzRQhm+lCEdi+ZQjhQdgO8r5dCTdQuKQUGeQjEKp1QtiqhbgzNhvJkHS1N3lvl4hqONE8zEda7ubHLt2jYH4gFH7j6KiMcXnoO338P6"
            @"hSHXz73KwaN1Ni+lfPNX32F7+zCf+IX/PXc8/DGKPA9HkzGMubhR4ihGA84+c4Hf/M23ePbla/iKdVFokQalOt9VDeIqmR98IyuGTxrjlsUgCiWi"
            @"w5DsalYlvaUSvgaUXv3QYOPr3dV/cqnz1n9v0K6qz1Q81pqkJWIaoqYhIklZ5udR0/RoOiqGTwZFlyAgZk103BAdtwGNccqIbQeERQOLIzIJ7Xge"
            @"vBKJxZkkUEJsnXbUYpY5Pvazp4iOLPCV/3yDU82Sb37lLG/dWOPgGWFuqc6Rn1ogiiLIZeKtlAqlRxyMLmdkZz3WVnqKuaBDYCiQg6jDWstsK6bd"
            @"cizNJyzN1ZlrxczWImZrEQvNOgcaDWbjmJq1WBHmoiVqUYNLmz06W9c4tFCydPooFCXew+E77qW/Y3jtO8/x3CPrHL/vs3zqF3+exuIBRr3BnrKq"
            @"16A9GcP6+VWe+P1z/N7vX+WFNzcoJMdLQYmnlNKhOvCiQyoWPioJRhJPuak6Pip9dzwVEsZC4JIwNraYxEs5FDQLkChf+kpSyo1J1N5IYtW0/FjI"
            @"xJjAntcAegNJxFcSusYuGokSZxxawF3H76Hb77G9u8Hh1mHWO1dDdkxMbGISiYhwNGZqLN/T5q3Xc3pru+SHHdfWd9DM8xvvvsLnf/pWbnPLpNs5"
            @"UdNCGsofNQG66dUzfLPADA2lqToxQ8H3hbIDRR/KtKRQkIZltj5DWShZD/JRSU6BjQw1dQiKkTp4T1kWZGnJvHsfOoq5cO4Vnv6di8ysHOTYB05R"
            @"DEYUo5RbH/ohRqOYkx+c4dR99zPY7eGLgiiOKMuQQdsoJs+GvPLo6zz51Q2efyXlen+AWo/3nnLCyxJE7KIR3/WiqVHwlci3rRRjFc2C4l65oSox"
            @"Fc/XSBAfrUDrFUVU2ccZk0AEy8b6xEHEppKUr1TcRAIxWoKiTGzFLQuuLQjGW5yNuLp5CUtMLaqx2V8niRpYtRiNiSWiZmOiMuLA8Sa1hRne/aM+"
            @"LWfY3uwxHKbMNGMYCgcOLzB8RhgOM+IjJW5RiGYNpgGuYdEORBsxFkvZLaEQfF/Jdj3lsKIoiyFKhLIMV8vYcOYlsaNIDT7zlGUZOjs5+AJiA/WZ"
            @"kplWwj0Lhymub/P4C9fgP3yXHz/YYvbwLMUoJR3k3PnxT4BX+p0+xgjWOHxR4LwhatdYv7zGc7/3Fi88ann78gKD4jrWEQjgWlKqx09BLESDtDBI"
            @"Jpg26juoaZmgT5KISJz67KwRt1yVC1mpfpxvZ9O6JdPSCTohXxvTmpQ9wd2DqDWSiNqlUAfbRYtbtsRLTmOsGoyJsBKTpSWx8UQuIbFNIjEYb2kn"
            @"i9SlRsPUSPIaR+6YISscW1c6xHnOZreHpyTPPLPzjpWVRdIdj2SOrAsjPJrkmCbUDyhvvnaBzqWcY7cscviOFsVW4LnG9SiImPhAAaVUilLxXsP0"
            @"xAlEimlbSARvlN6gR3c4pLDQsTlboy7nrmyxurPFO9ff4mpni+1v9Dlx6nt89Kc/FBoppTLq9St5IUHV4/MSG1kg56XHnuG1r3a48vopNnYEMdcQ"
            @"A740odOrFkNJmJsZFJ9U2ClUJQ5RskJCaqVS56OTDyx88l++tfPsb4zY/dde3bKh3PBB2T0LnKNppEZVZHlwYiSGQEoyQdshAdMyWolXG7skfixL"
            @"FK04qo4TDkuEk4RYEiIbERFhFaxxWBwHWgu4IsIUkJiEuaMN8szR2+qj3SE7mx3ECHkBC4tt6oMWeUeRqJKZ9xbNLXShczXlG7/5DpcuDWjWI+6+"
            @"9xAzcZ0kjphbqCMCRhQxleClgBqlND7IallDWqR0d1I2dnvsdoZs7w7Y2R7Q6YwwhaUzTPEeiigiimtcuNHhN3/vZRZWZjj96bsnQLRwthaIV5JG"
            @"THd9k2//xvN0R7fhBp9kuL0B7gpaAGpRrfg709OnYODEI7HxpuXxoL4ruGUjplX60LE6Wb/li186/vP8s51zXyrJzxfk5yGthFUkrtT3JpzdcdNK"
            @"jAmMA6o7oEI9xhXqIjZil4LOlcTOuOVAcQj9P0vQOHYmJrI1YhPO18hGxBKTRDG9QZeWzNJMZpkxTWYPNOhve9LtlBkxpKOUyFnKHBbbs2Q3DEVa"
            @"YKNA8NVq/OGsZaPT5/pGgUsSaknE7lsFu6MS4xRvCjIp6RYj0nLAyGd4SgoVci2IxFE3dbrZDkWR0c8GFOSI1XCmU9JMZqgnMRCRKwzzLepRi2df"
            @"3+Lk771E60CLY/ffQjEcAUrkBCPChRfP8Ue/8TrPvn6KBz73MU7dYvBP30An/MkADDRGEG+C1+8TIw/X1wBegvfGNM7cMffAvZ1Rh88c+UGWzBEK"
            @"D4bolJMgB6zqu6UE5RyZQkfuSeWPz1yp1rdgl0THsgiSFL7cOFg/8aXYxKwPrqxapI0KSZLgc4+ViNjWqbsWM1ELV80SIxyxJDTsDE3XppXMMVub"
            @"pTmb0NtWGECkMX5K29mVMf11JfUZUb1qN1ahplYT1jcGqI8QlNn6Ao2kRkczxBkyCnKfoVZRtaBBDE2lJAJEcno+p7SKWqgndQq1eM1pxDEnFpe4"
            @"dKODLwwewWqTullEfYr6Jl9/6gpHl18jmW1y4OQC5CW7N3b43mNv8u0/2OaVt5pEBw8zHGVE7VrorROhJSRRQhHV6PZ3UTONU6xMb0yr0HIzyPdr"
            @"aowkTmscbZzm4ds+zjF3miIr+dkTf4MnNx/70puD7zxSaHZWGMv86t4aG92/QMPJNLZZNCPoIWeqoAGVhxHFYZesCXdhXmTEJsEZR2LrJNkcP/jF"
            @"j9BoGL72716gPhsRlY5EatRdjaar045qRLGj2CkxKlgP+KoVZwQyy2CnJKUgKSKM9VPLH2Bnd4R6iF3M1m5KR7JQDmUFAWeRh2RFFDWCqEG0RPEV"
            @"H9chlTKTx2OBvMg5vXyIB1fu4ze3nicrdkPbVCxtc4gy7yKuZHt7l6889g5LB+e4+5O3sr22wXceOce3vrNGPLiXmAPMtmc5deIQrWFG7KpmjnEM"
            @"RylEMe3GLBv9q3hRxsrpIg4K267RvDdznfO5+q6qxCoF31r7fc5tn+Pv3Pt/ZLPYZHV0DWeiar9SVToFMt6+OZGMh70iuAq9HvtKHMtO5raaOiPJ"
            @"1nD1EUd8Ora1U77KTcbRxIhFM8cHP3aan/0/fZrWUkJ/e8SL37hAnEQkpkZNGtRNwkwtIa5ZGjPQiCAuDc46pIhwJsJkjrSfkntPOSrwxiM2jFfL"
            @"TOnupKgqBR6vI0oclDZs4RDBI1VJPKXNJAb1ZoqJMT7rwsWNrOXC+jbdzrtkuRDYF+FiRczQtAfwZU4rOczb52/wla+9w6W3t3jz3C4vv1Xi0zke"
            @"OHSc7bLBiZWjnDjaRs6vgwqFD0jSA/OH2U5vENc8G71xGRTAH2UBf/fP/02ubl7jX33jX56NnWmpLzdL0pU4StgeXWfdX+HXLv57Xtj9o1VH+opK"
            @"9ibVhGh83qrs3wUlZkwEq8ZJoqZFRec32EU1mnlfblhjFy120XudaPuKhizUlznqcp5/6i0e+ZXnuO3eQ7z+5FWcc/gC5hZmOTS3iN8WakmdKHHM"
            @"Ngzt2Rr1siRxCTLKMBKx3R/yzIV3Kbzj9OED1JzDWAEjlKOCPA0eJThUoJisoikRDTlo+G9KekAFIw4/RhWJBLBbJdVg1bGbZexmF7BiK8UtO5ED"
            @"apilMH/VGi5u8L2XOrzx5hZpFmNtgwO1I5yavZte5yIzcY25NmznntKXQZIJT6tWp7fTY7dzDbFUXutRSmJT48LaRV5850VUy42iDAN5j6ZZkS/X"
            @"o9bKd288yVudF2lYt5Lr6LmgfJOf99WKnJuFT/ZIBjJJqFJFY4GWamVsH6ZDqCSK70YibSd76jZqSpSMnB69IuYP/s1TzM3MsLPdo1Y31Kix0xlA"
            @"1mE2nmEwKEh3CqIjECUxVlIatoH6AZG1XNneDfUrjp1Ryr2HlymqJtXBmTYB4WEr1r/gTcU6V0NVE6KVgUyFyNcKBmpQtGqCCIKVRgjjlMQmodAC"
            @"QbESxENDlVhiTZNZWaFXrpP7OklyiKzskjjB0uCQu4t20iTLC+ZrNRp1y2onI9URhaYMiw5rq+fIZQC2wFMEYrRXSq+UDPnVb//qs4LvRsa0SsqN"
            @"kAUXa+CWN4oLfOXyry4VpC97n18oGDxahj0RaRAsG2OpdP+wXscJlVRRa1pSOawTiQWIrF2sabISlZa4tDRsgyhpkFKSaUhkjOlwfWeN7Z0GDReT"
            @"5zUi6xlkA6yPiDBspxGdKy0OHpknqllGZcFcs43Z7gT1UTGIGCKj9PKM51evUPgwpzzcniV2wWtD8m4myPoxIlAYn7GBuzYmLXtCPVr6Sqiv0sCi"
            @"MqMRiMQgeJxxiPfMJI5j8zOc39jCFBZrDSMZ4qTFiHUKzWjZwxxMDlPSx4hloZngbEF3PcMbDXAbLcCWFJriNavm6x4vJRil8OWGs9Wob7wRRTUL"
            @"his3SvLz42rGV1IUSrkZ2pOBdvL9VamCMZ0x1V6BMcG6yriMSIJKQgEH3BIP3fk+7jpzO7HOsL4+4ltnn+ZK9xJGcvJyyNBs4SWFfAaMwRmLKxMy"
            @"ych8Tqae4XrAJLUX66y+s82RdpuzJqEwKVDisYhXrBTkpa/qSuXq7k44L41jLLw1AYmL7kn1a7UcR32FAzSVF5qgi+gVLwZfofXHrzFWRpVSObTQ"
            @"5PBcTNYVEpuAamij+rkK+lBixbLg5lmZncFHXWomYbZlcU7ZvDSiMDnqPaUGb1UKfBVd0MCtzcv0ZWvsYmha+m5ZGS6snNOs4hQl4UfCUisV3/Vj"
            @"767mwO+VLZI9MW0tNQuuWymVi1sBTS128UC08rMfOvwhPnHPRzh8cpl3zl/nWy88x9vrZ8mljxolLzO8GSdoghVLgSMthdnaIvOteYZpSjuG3lqO"
            @"9wWzi3XOacbtrTYHagtsFFtAGVJ3ndYOD5c+MhbVABN12MnZ7yVI606eLxatFE6NhPajZ082z4tWnaFKSQAfBFd8iY0cRZHT0ITetuFaZ4fYxcRW"
            @"mZEGSI3NbBtsg8TEHKkvcmRxhnfzdRZnZpldchTDgs0rGYVJKcocrzmefKJCoyJ4D003y3J74d6LO2++PEXJjLXKhH2VCQfWQbkRmH5hm1nIlMeE"
            @"sUpWQZmwEKZZuw58V7XaVyeaOUxr1i78neXaLStHm6fIgd97+nE2/7DDht8ko49xZSjES4PFoppXtM8II0Ocdxjr6GVdokGgaw59xtbFAX6Y0WjX"
            @"SLGUpsfxuUW6GwMKGQUZSwlnqBGDVoJZXhUjgcYR9tT5iuhkpxeTVuvWfJiGqUGNrxLl0Jr0xk8QoUYUUxpm2zFzs5at1RHRXMR9nzzAq4/vMhvP"
            @"ouKJveFY8wA3Cs/WaIe6iTmQzLJSW6R9ULjx8ojl5RMsnorYPt9huO0xEfiyQKUAH5pHXoMAgvcQOUejloTjxFRaI6Jp6DFoJYHvO9VewG6Fn0p1"
            @"goAMSIyJjue+TSd7JZGrNB1Tg8TqNU1c41OxSVauja5wofvOm7n6riM+ndha20ZR1VMNpUZCk9nGLDu9LUrjCO0ER05BTEGaD+nSYTZ2ZORsXR/Q"
            @"udJl9nCT9vwca73zHD9yK2s7LXZRLK76hcIw01pHqWU4JyWEWZU9+fdxGTTp+FTZ9BhDNK0jUYU3fFUDWkLG/9EPH6Bzo6R/FaxkrL87IM4dgqWd"
            @"CHffMU+dNo+9foO5uEbDGY415ji6VGfHrDPsO5ZXZmkuKxd/a0Se5ZRxTl6OUPXY6nAQJNT3xrI73GJ9cPVNZ02r0HJjT+Yp9PehqIQ/K6DcXsgN"
            @"uGX13fFpuyefoPt3BwY6iWlNlsuIJP2y+xv9ovsbqCRWknuciU6V+G7q9V6j+VLYlRd6y6mM2BoVVZ1Z4DWUHaWUFL6k9AV5VqCRhslzJmy+MuTU"
            @"jxecOnOAV7/9FrfdlbJ8aQaygkyBouToSoPYClcup8TWUYzverRKvMbLIALqQczYo6XSumKynFiqhEsn6wAq2Kp4rBMuvN4l6wmNRvD23fMZTRNx"
            @"/585SLKhtMXx+sY2iZacaMxSixxHolkOnjI8ernHbNJm+Y46tlaw8SLUGzNoJhUiJUZIMFoEaUSyCXbciml5LTerkJoKVadQQhtY/P5VrFNSRV0m"
            @"0kQ37eydhOaq+2WltljR9mVMEwyQNEkCrJJSwtQfDbG/VKUxjgne63gDdchYCYYXNbRrc5w+egvDTkkzmqFZq8FAuO1H2jRcg0uvDHDNLkvNRTo3"
            @"UnKrOKt88PQSZ04cJM2GpF2oOxM8DcEYizM2jNskhHFrqP5tsWKwAs6En7FisEZw1fedgdgKkTHEzlGkULeOWAw1Y6lHhmYLbl+ZJ5GYS5u7vPVm"
            @"j4WaYzZOmI1rHJqvk9024JnvbPPAvce580+36F9Pef4/dUjjnLxIsViMt4hYvBDGfRSUMqLQrOPV91Q1KymvK9X+QPU74bEOK4KYrRZWlSKU4Hta"
            @"TYB0snhcqvyB/WtW8Vhr44aiodMeWN2lIFYFMWIaVsRiJEb8Duiw2oxZingriJPxKTall6QSQmtsEhpJg0GvRIzBRIL2hQO31zh4X5PehZh3Xr7I"
            @"nR9eoHfekpMh1nFicZZ2UufI4Trb6wNUJcyHqxLIGBAzNhxYEZwxREHkozKkYI0JRhaHFSE2QiSG2EAihsgYEifUnKFdi6nHFYUEgx8KI1+weSlj"
            @"1gnNxNCME2YxHP5ozHfeukarbPHhLx7m0Ecinv3ftnjrzRuMpAsY5uIlPnDPLRRdZZjnVdlWUGiKGk1KzXcCAN33FB1MIDfTyZPqYLLlnOJqqIGn"
            @"l7XJn7gKVxWsiCvx4sa7bBHTMGLaxogLm6XFVnOgpRA2oFroNB8GRFIJbVdHeIX4M2LIy5JOt2C+PUea9ilFMeJgV7nl83PEWuPiM0N8vMPxlcN0"
            @"LiqFNSzORCzUI1Dlnl+Y48BRR7YxIu2DE4cRsKbySGtw4rAGosrIToTYOGIrxCZw+hOBWAjeaQwNa6hZSFyA2bTalkgs4iPqLrRVbcewUDfMr3jq"
            @"RZ06wqHb61xb7vPMH3T5gR85wdHPJOyuj3jsl1fZ8Gv08i6J1DjUOsjxuWXM0BKJkPmCTrbNTLNBo9Fkd7BxOWCU/Y7idzzlpkCp4nfGsBqEUvE7"
            @"haavGzGJThPAhIlS3GTl/JQIShA8UZuJkAakXQCimwko3TQQScJjd8hgGhUHzlZZqA3t5rGBQ/pnqrApoiSu8t4s5AbGOUbXhIO31jl8fwu/1eT1"
            @"x1c5/r6YxnCOtCuUknKwZnEHMg59vsXwFcFeNhT1IVlPcNYG7zTgJDyOBGJjiMWSGCExVeg1hsgqiYWGjagbR90JdQuxNSTOEUehnEp8TDMyzNQd"
            @"C4mjKSUHfrKOZDF2zTK71MD9KfjNf3eeY4tHuPsHFpi9U/juL1/nrTeuse1X2cmvk+ZDVtrLLDQWyEclJ29fpJ+mXNtdp19usTO8gZfSei2vl+Tn"
            @"gyyRDsYa1j4YGMXvOBPfdrh96qV+vv3PQ+QU5GZC/SSZkn1iGtYSgVCKBE3HyQ2hklR3kYgfjwHHYT3I6IiYhohNxFi0ygpDbDBTYlgFg6yHcTIl"
            @"gxSTXxdu/9wsTmK6V4Vzr1zizofm4UbMYOBpNDyN2HL5iW12X7IYjSjqQ3a2UlpJFMKwczgrREaIrSO2lrqzJE6IrRI7cBYSC3Ur1CNLIpYkhtiV"
            @"1DQmjoQkMjRcRD2yzDYs8zaiVhcWfqrJwscW2PnqANeJWPxSjd969C12ziZ8+s+e4MjDMasv7fDEv15l215jJ71BP9/ExUIv7TEahP7y6o0dNrrb"
            @"ZDJiqB0y7VFoXhSSX/AUayp+x6ND1WJVZbyGPZy/xtg5Z0xzWPZ+p7JBud9Jq4V5+t5NqlYktOHEUAp2LiRPAROLiENNw4jERsRVFBMbKCZ2Towk"
            @"ojYxOGbcDFYjjAimkpitZJxDJ6jKchXBJZZ83TDTdBz9xDyxj1l7M2VrfZu7HphntBbRHWYcWIwpb1iG6xa3ULLVG3BxZ5O5JKEdxUTGUDOOmrXU"
            @"rKFmHYlz1JyQWEctstScoRZBZJRDB5rMthLKXknDxCTOkkRCzUU045i5ekI7ctRvs8z/79q0P9EivZ4xeCzn8I/U+cbFd3j6P3b50Z+8k5Mfq2Hm"
            @"Mx75P19gbfsq2+V1+uUOqR8hzrCVXuVa/wo7oy12sy7dcpe+3yEt+4x0QM6wW5KdLSkuh3WzxVqArGo6LoEESbwp1vrp7v+nUr/pjdsV1crXmxQB"
            @"9/eYrbMRYaVa5ZEaJNsD08/Om3HWLO6QiFiRcBNUUJy2lchlhedjZz5EuzbP+vY2cRRPajupNmwYcYgfr0v3RLFjcLbklo/Psnhbi5Zp8O7zIzqD"
            @"HW6/a4b+ZUOnn3LoRJ2kZsmyjM1un43RCAQO1lsk1hJbSy02xM6SRI7YCbFTas6SOBP+bQ01Z5CyoMxg/nCEKyzqA3e3HkW0ZyJmWkLjMzHzPzNL"
            @"fDBCIqHzRMbMfMxz3St881/t8kM/dIbTH51l7oPCd395lVf+eJWdaJ1OfoOR71GQ08mu0/fr9HST7fw6nWKLnt9lUO4w1A45IwpGg0Kzs6WUm7lm"
            @"Z0V8t5qpD4ORA6NAhdKa6JhouVlpLpfT6ZOYKTVXlX1K99ZKVNEUTGuscBaQGZIYESsioQpRHQaCmFgwDaOSWHGHrTicJizW5vmRH/kUr33vMkmt"
            @"hjUuUJb8nnGX6kfIihF5WWCswRQRows5p39siUazxkJthrdfyNjJu9x2T53RpZKNax1MXcjzktHA0zBNjMBsXCd2EXEkwUMjS+yEyELNWuJISRwk"
            @"RogjH85orfQ6jEIRYVSpJ0Kjbak3DY3P1mn94AxiQxOl+2KKv57zwsVVnvq3BT/wmdt4/2dmmfuI4e1v3eCJf32Z3eQ6W+k1Bn4Hb8J1T7XLSLuk"
            @"vsdQd+npFn2/xUh7pPTJdUDB6LXSFGtey+tLM0d+JS0Gj5fk74yNGjpSIQSHYYHfkVAalYrfp2LPPobf3h9rbTTu9gwQcVKh2oPYotiAcjetUGdp"
            @"JmqXUHEipm2IDjlJaEYzDDvwcz//BWwZ8+6r10FtoJPE8WS+6qEaYC8yGqREiSO9IZhewS0/tkg9Fg7Otjj7jHK5u8WpeyNsT9m+0qcsCmrWMdNw"
            @"LC/PEGWO2Bni2FKLDDUn1JzSjKEeVedrBEmkxE0lkhhTRsSxQVKHM45G09JYjKk3E2pnYhofb2BiIdsq6b+akV5Pef67q7z9B57P/Pgp7vupOo37"
            @"hGtv7vBH/5fzrOs1NrMb9IpNevk2y/NHOXpgmYsbFygkJdcRueRk2iNjwIheJ6N/PmX0ckl+QYwOVf3O5+/8qR+8uP3u8qDY/d9ETEMDo88pOkR0"
            @"IBPhsakRn7x33cyYjzyukqZ2+VW6R2GxUUuqzA3GajamVUn1ZohmStjBF7QXIspC2L0x4K//vS/RihsUhWKM4/EnX2CrWEfF08u3mbFzdPt9IonJ"
            @"ihQ/k3Ppm12O3HmDEz9+iMNRxqdlnj/6LeXR767zwL01lhea7F4ekedKLXYkQ4dGiosMcWKIXGhcWBTnAtKRqjcdwlVEjmAjGyJYYkhqgms4TGKI"
            @"DlmS22oM3/akuwVGc3b6A95+ZIfyYpPP//xBln84JrrDcO35HR7/H65wPd1iK99kUHRI/QCVjLWdS1zvRBhbjRmlpKxW7eSavVmQX/BSrGql1loU"
            @"6SsZxepyY4WGnXvwOufXEmqtMZM+6F8EyfzKpJVkwvQCKVORlfc2o0/4udZEY/FOF8Z9mk11qNg7ZyvWgYiryqK2FXfIEJHmyomFFX7yT/8Q8405"
            @"Pvqn3kdeeL7y+0+xsbuJSoC1WAL7T7xQd3WaUY2GqzHbnqV+0TJ30pHcX8eQ067VWL9Y49U3NyibI46datOOY3zP49OSKDbEiSWuGWJniCKhPpdQ"
            @"m0+I2wmuGRE1YqJ2QnygRnIgQrxgywRbN0QzgokM4i0khrRTkm4W9PyAt1/Z5PxvDTjcmuOBv7XEwocc7rSl80aH5/7+Oue2N9kq1+nlO6R+l1SH"
            @"lJoy9F16xQ4FQzIdUpJRklNqseGlvB7q2eKy12ItjpJ7b59/39+9p/2Bn/3TK3+eucYCV/tX/2Gm6fXcp98LFYxY8L0KglKKVMaV6a3kOtFbDssy"
            @"9qoSV0EhAxA9dEVbhL1zrTHCPWgshwzOV5AcxS17lHbS4pP3fYwf++xnWJ5boejCuXPX+eX/x2+ztnEdVw8SrmMCNkZw1hGLJcJSMzXm4xqLszUG"
            @"f5ih6ZCZu+ocHHk+JI4XvyO889YlLl66wplTLW67bY5aapBu4AahEC1C60gdm9RDLLKKmKrP6iRU4xJWAucI+AJfekxkiRYEljzbDDh/qculp4Yc"
            @"9C0+/JPLHP7zNdwKmEhY/fo25/7pFqYUTKyUaYGRLDQLkAClJSPXlIwRRdX08xSd0H0qN8dr0DXQNqnVGpyo341szbOUHODukw/w8mrxj/rbu79i"
            @"xS2r+m5YMUBYQyABQjQWlFH2VruNyyKd4jBbI26s55tUqzmT0LzQDBWHjIWwxu1JiQmrvpcUOLF4bH6+Pse3v/0Mzz79ErfedoKyEL72zSfIZESh"
            @"eZivamikOxPRsE3mavMsxHMcrB3kxG0LLD3UYHRRWX9+yPrFHosPJTRWHHXnqEmDbGB55+Iub1/foZ94okOOmeU6M0s1klYc9rxnWjEBQ8Khavaa"
            @"sFmgj5gZJTkK0SlDfiTnqh/w0svbPPO1IZ1XDfe/f4mH/sYB5n4gwh0WykJ56f91jef+52v0iwDXmZ+L6A1yRr5fqZUbRjpi5PsUjIK3UqLklJqv"
            @"BXbAWCim3DAirijLjUudc//0ta3nL6/M3v7wr5z95zy99ocyHPa/YYxpaKVio1ASes7lBOb8nl3HU1TucR9DtTJueFJmxC1VeKoBiBUT9BgCb0kS"
            @"U0kpVIV0acQd2urtzJ2/dtENhiOuXr/Bq6++xQ/8wId5/oXXWNu+BrbK7DQ07hNpUHcNWtEcS/Ul5pM2c4drjLZLLr+7y/mNXS693OPGCx0W74w5"
            @"8pE684s1luZazLdnyQcJly4PeOPCJm9f2+FaOaDXLMkWFA4rblmIjljcIYM9ZDBHQJaBY5At5+w2h1xc3+XcCz3e+Gaf1T/2RLt17jozxwMPL7D0"
            @"vgi/BLatrL/R45v/3Xle/P2rXJdddooRdW1waL7BiVvbDC846k2hMRtxbWeDofYpCR5bUlBSULUXu150GOiX1R4/1Swy0THV4vKhhWNfOLvz4mqp"
            @"2WuhPeC7od+sQwlZs4xhrOMmxRibLFOS+DoeIow3gu0XQik3NMjcx4gkQUE08FgMplV437UiiTWgvtwoNX3ZGNMyoqdSGRE3Et5cfZv/8pWvcfvp"
            @"Ezx94Vma1FAN255zHVHoiMznDPMhO2mXRhTxzqspgyxltxyQlhlqhK1zTbb/R7j7s/Pc8oU5Fu5ImH26RcPErCy2GQxH7O522T6bsvbyDhJtk9Sh"
            @"3rDMzjVptmKSxAROU+4p+gW+L5iRIxLHgZU6Zz5VY/ZMRHJQyYee4UAxR4Tc5jz/73Z48Xeuca2zTifaZtTPsBJjZ+Dgxkne/+Mr3P7ZZb75y6/z"
            @"zOofE1lhJm6xMxpQlkW1WaSSRRCJUU1Vi9UK2NYNSAtNlXLzfO81hmXn11XDrLbqUmUySWZ1shrO4yeToEkZVI0yZQqELoYJ+rGib1TUhGo3UOCi"
            @"BF3CUou1O1buefTa9esvbxcb/6Bhah/0WqwVmp0dKhTiT/mR4kzEHzz6dT730R8kiWNG5RAjUTUkV4zuQuFBC9JixOZgi8QlAfLpFWNCY8xGJXmp"
            @"DH+v5OITfY48XGP5Ay1u+VyNnbPCzgU4tBOjo/BBvDGUvgwFlzfYviHJodGIaC5YGnc4Ggct9QVDdMggSx4WwVsfaB5Dw3B9xJvf2eXNRzbYWR3Q"
            @"sV225Aa7/U0KLXBSZ7V03Dt3mHjZcuCjM8i/SMgLxVqhKNLAUxpvq56EyDDl8aEJkTHZp1tuqmj68o0nf9b7YMwwdx5XKeOcx08EWs3UIuSxfvbe"
            @"shHdt+/AaXUn4H0AgYrPwLVCCC83RSRxJjrVL7KzD9/9MB//xY/f+8v/6X/53RfPPvW3xJhW6dOXA1QHVPypxNS4Nuzz9NlnqdUDx8eZBCMFpeRo"
            @"BajLTJ9h0SE2DSKJsMYRmZjI1IikiS2ULPdkSUm2VXD1P/d57WtbrHygydH7Wxy7r07eNQxWYbiqSGZxxlBrGhpzStyEqGGJG4ptGKgJOE8hJWXT"
            @"42ZCEz3rKDfO9jn/eI+z39nh2o1N8qRLFBsGaY9h3iH1PdIy48BMk1ZiuDC6wNY/7nLHx5doHgZzIUER8jybbLZWLScNo+CpAXwY9i5JogEY1xHA"
            @"+2xtT8N8D31RbdFmWrGm4qRMoEXTa+L2QnT4stPx4t1JfDZhKX21QwggL4u1Y63jT5xaOcHRuRVu3NgICwbRtCRbG4O2vBZrRTlsOXHL37vy/NI4"
            @"WSs1w2hCKY5chyzW50jLgqxMSTSpetKBWJaYOrE0iUyd2LQYpEM6tkcjSki6Nba+NuStx3ZoH445dHeTA3fUmHkwxmmCzR2aenIVygjyyJMbwWmJ"
            @"5EH9r1TP4FrG7ks5G28MWX1lxPqVEd1RnzTq0483yfIeNo+IJCEfCYXNSXVIv9xldTjg+m6NA/Eu19e3aM3ViZMaDCrdatVKGqFI6/V2Mso7p7RI"
            @"X1F8J6Abw94lHVcfWiEZJSSrKpqiEotW2KnJaqC9nfST9Xvfp6esU/8n1kQVBkUmm67BtvZWhIaN1PWo+Vnjo1MP3/mpLz1z9smXd9ONfyBiWuMN"
            @"1lbHO4XcisG0rNhFg1s2IomIXTJqMUSIOhbrs5AbCg1zV3wQJLMSEUudqKKFxqZBYmaIpUFkY2q2ThLViCTGlg1MGuPEMTNbI2la6jOWRttRbxhc"
            @"ZMCFLkuZK+mgoL+bk27DqCcM+hmp5mQuJ7NDMj9gmHcoygElGYrnYPMYZ+5e4dFnv82N0Sq5z0GhHc2xEB1g1s1TMzW65Q7vDl5no7hC3++QaUoh"
            @"o7SQ/LzX/IIfQ1MJf3vKzeDB5UYwnu96GbP1NA3UHt9VLbPxDr99XjmFnVImY7x9OFfdS6jkZsxrGsjXdFGJVcqNQdr9DSE69a1XH3kZM77zwh2n"
            @"apcKNLNoZtBMxS4WqqkV3/VqWoZyQ9UuecolJzFbw53QzEAYeYNTizMxTmMKKYjH2hG+xLuCVHrEWiP1dUxusRIRmZgkahC7GdK0gU0TZNNgkRDm"
            @"xVYhsaTUUIOW6lFRCilI4yGjckhaDCmyjNynFH6Mn84oNaOfN7HRETxK6odk9CnJGeW7DMouPbdI07bx6itPGk9sCkp8t/TlZsAZF2thS9okQUrH"
            @"Z2rYmKbZFBUk0zC43wP5TcFX95U9U6iLvd6yn6xDd9PLGPfoomUGpgq9lWqokQzNz2dabmihqZEx4l1iKFYRu1RWmFtbfYgKcJkYH9j5VuyiannK"
            @"UCzlGqCsViJKiSmDDAiu4tLEdoaTh27n4o23yHIfvNhmVYrvAiLDOFweEUkt3BwmNEqsiQK+GYOvSpJSgyZF4Uu8luRlRu5H5FpUN0BRMQUDQ6DQ"
            @"jGH3Ha587Qoj1yVjyMh38Vrg8Qx9h4Hu0CrncFInrxYqaiW467VYG9e1ATLju2M8slYwGiZK6OG6V9uuq2bFfrnd/X9Vw/mKJjLegRxGqmO4o0eM"
            @"cXuIwZs8eN9CZAmrus1YTaVa+zbR4a8W/Yq6FalKqfG6NyMShxAdnQrd0GqPLJI44tOWJLEE/YxYEgwJiczTjufpjraYbxxgqbHM2tZFxJgAwZNK"
            @"60pcAMlJAMYasYhEEw1KX7EExglJqYJXj9e8MmhF3NKckmDUXFMyHeE1Q8WAOgpN6esWBYOKc+SxJNRNm1jqKEKqO/R1mwGDjVKzs6Xm5z3Z2cqQ"
            @"qRfNoNzwlBvjac/YD0t8N2TLvov67L3zWaZ24970PdGpTayyf/WMyM0LeasDW7QaPJiY6oD3gXaSBe3f8fv4Cb9ITbEKpmW8XRLxVVfGLuoYAFZ1"
            @"uYyalmDanmLNUN7jKFeUEu+FmhWGusNotIslppd1KLww1H6QLEKwJg44Z4kC1Xm8BUUcog4xUeC5qa8SkoAKCRBcj9ciMHe0qML2iIKcUjNyHVJo"
            @"1Rf2BY4ZIK7WyIXXgAJDCOeOGkaqKBG+v+YlP6+anR2fs+GyBqOOudAh75FYtdwMZDbN0PEESKdNMWFGjbPk/TN6mWw43te8Cp5bTX11v+Unnjum"
            @"a8u4uTHe2myXZAymnnhzNQ9WiYOHVljcSrfZjF9HJREJyZogidH4dCtavHdpZpnt7XWMrXQ3xGG0Fk4QKVHvkcpbA9+h8t4qIbPVY6mIXuM14dUC"
            @"msq4oTXoNXR/S80qw+ZVCM+qcJ6jlJUPOHINs1jE43XM2QnyEoY4EZRCs07G8Lslo2e95he8aBq0k8eC5L4bVrqHwUzIln1XVVOv4zalTsBvOtlP"
            @"P+Y06b4OFd9XkrdqeQTj6mSKvxeex55s9jxbZOrng5D2nth2tX8dSUJCFiiggls2Gob/ewlfwGuhEhtxy0btkiE6lZiZhxPbIM+zKrwarMQh+VJB"
            @"NQ+dGGTCpTUSFi8a7AQsb3EEjMEUd6a6SKUGHn5JXp2fRRjLSRnMr1nF8i0C2rf6VyhxcjxFB/XdaidQJfql6fjSlDrGIGdnS8nPTxLPCe67KntC"
            @"X6A7Jr6HWngsP+TfsxRqrICu/P/+M8msx/Pcyaq3vd3ak11+uh+uP73kPGgDC6BFV73ElbLoZrULp3p+fsEHyd+pRVSaWoJgWQXpDL19349zP1oy"
            @"Ep0Ka89NMIDm1WvtLfkNC6kEoxYJKhzhsVgmjBOxlQC3TvBGqloZsqjoJUW1U6kK1xVHv6JxV54+9qeiCrF7bDudsO4qjajx96XcCKpwe10nrTaS"
            @"asWJDp67F4qrGXq1A3fMP56uYWUqLH9/M8sUcNndvNhekQkcJ1A0xina9Ppl8BCSKa9ZUFKvGhlB0Xvi3UrYcBX6pOPGSLU/VjQ1aFoa3/Xqu0Y0"
            @"NepWPOWGxy6ZyZo50x4zbsbwkqAdYrEYRFKKyntRqVCYpmIABt9DywotVOK1mOyk9WPO7CR0B8yIVv5dEobrWmWyY8FrX9Wplar5eByaBkhMVepM"
            @"UpjgsUFeM0jbo4G0K5VXy9R226kO8UQSYdz52sfJ1e9jYN07effO3ClYZLVKtQrJ4++Z/fF9nJ1N5FPGRKV991EyJnEHLx8vTK4kCMO+3Xb4mqZg"
            @"l6yG/bthoXJYWIWalmEc5u1SNakK2K/QaJmistjqdzZ7ZxQ68cqwVTqM7qbnoiqKVu3AsYHGXTeVcjNweitvRLOxIScht0oWq1u/o6KZ7PPaMQVz"
            @"bMlyo1I+j/d+TvcvPZ7qQIXIE7jIk3N4Gs46RUVQPwbPGTu1c3Wcc413pcs+6sJem1Om3njauGOtnKq7JaA+JB1BjDLUdCLRSZAkiKtILL5CXAqI"
            @"uhU7XpihlTRhVVKF9d/jxK0C802+DiISiwbpQqaWKI2NGcKr70zOvEndOe7pjn/Xqg6VEFFUA31yPABAoCTsExYZe2zwxhCwwuuHRpDv+nG/eNwb"
            @"8OPaVlNUMxWd8thK03Icv28+EfUmiYRq6LP3RD9pUU557k2LpmRvor9vI/afsM5z3ytU728wLV9NlcSP9fvHhq+8cLIqvTLcXhiuPFiSCkdUqceG"
            @"s3r8XCYRYfzvkKmH1miow4P4ZdgTr+NypJrMTBGnKq/STNV3VEPC5CvDykRsc2pTpmiqkwQyfL5xcjW5QSZeOb485cak3KmOhunt41qdrOMsfxLY"
            @"Vd+zoOI9a8Gq83pC4Zxy2b0f0fcqo0xztlUrRnd1d+3NkPd3Uzzjksm01FSPxwIroul4BU6JaZkx6A5JjGpWBlpjuncDB+EVqdbhyGQdTvAAE4yb"
            @"hKPCtMIW7kpfYirIVPPpRCucsKrv7DOuD9IFPgzHpzpKEov4bsXE6IxRKZ5yQ6YSJoxmvuoXV92mILU7vX2c769AM73ceP+Ga50aH+7feC37ull7"
            @"PefAA6g8V/f3pt7TBRmzBSb7a6Yglaby5P1Gn35DIWTLYcXwuIwSNEPtIiKJmWTglWeqxGioo2VszMm5XnmuVKx0Qt24x2E1YclklaGLVhFDQp2p"
            @"1cXXKWyY6ngyQ6WZURlIyo1QMGgqEwzUXm459tbJQL1a7KQUa+PIMkZQyM2yQjLlGONvGb1p56LuP/bQ90ZmmZ7r7n1hz7hjw+y7k/bKI9kX7mXf"
            @"3bCXuEx78N5r3pzUhXPbxOM7erysUMYokKqU2kueJDHjMeTEC8aheFr4Y8JpukkfIkSA4NlBUGR8Vu6FyGq9S5jCpGNC9FiHQiZGrN5DqnKGqXkt"
            @"469phpTdvWulEx1L9kWQMdfnpus+VfjsXeiKrSG+uvtuom/qe9uVItZOQGQiN7/B9Bhwf70lk360Ts6OgBOm0pCZfleZeP/kdXRaJ1gYe1ZYHBzk"
            @"aEUkCYqx4cKHZcFj75XEVMadJHrj+nr8GweQXzwOoaZK8jya+onUTziD9zyuSoTG7cDxuc7Y6HvD9L1BfDj3dbK5upI10PdQaN/jkTrOjKfldNkv"
            @"0ClTb6jq913TvajwXkP/fwExvM032dJj1wAAAABJRU5ErkJggg==";
            break;
        case 5: encoded =
            
            @"iVBORw0KGgoAAAANSUhEUgAAAHkAAACECAYAAAC09oSOAABzV0lEQVR42pX9abBl15XfB/7W3me48xtzeolMIAGQAMgiilUkayCrVCpKqirJUl"
            @"lqDSVLsuyQw9ERjuj+0B12REcPXzr6Q7e7I+x2uCUrNLRk2VJblmouVhWrCA4gOIMEiCkx5Pxevnm67w5n2Hv1h33Ovee+TFBlMJJIZL53371n"
            @"7732Wus/LAEQEep/VJUP+6f+ug/7GhFBVRuvp0D4vaDVv6s/kflXzL4/vEj4vYI5/zUavkYlvJ4gYOZf8GHvS1UQUVTr34cXk/rN6OL7b74frf"
            @"7fGINqeHuKLr5xqF67fg/zF60fxfm3JiKzz6Ia/t34oagqqvVTC68p557Xj1qr5nrZ5gKfX/D/Jf9IvZgyX1TTeCnTWGA5t9hSPQwRwVQP0kj4"
            @"kLMPTbXootXXy2yjID/ifTT/rvoWI43fGwk/VyQBHCKzBQi/B2PDN0h4bwmIe8xWmj87EQSZ/ZyFN9hc5MZ7NPVCS3MddOHjyWy95U+0XvPX/3"
            @"cs6r9rtzzuh0m1/+v3ZKR6uzo/eOHPhMZzqbZ7c79KdXr0R/9MAfXNkyONGKKPPORqUyUCabXJElXNFcmqDZVXX5eE3aCISFq/nCpZ9dv8cc/H"
            @"QNIIPrnzi89x/vC18V4VxcyihBdFqs2tOn9GyuMiwzzCLkblajMbU3+DnAtTH7boPPZvZ7u/ertShcPq8IWFaHynqc7cwiLTDIX1TvcLH6J+47"
            @"NTa6r3q/OoMFsgX4WQxhM3In1RUhESEU0FEhVy7xkignrNVCRHFSPSV9GsEUZQ1TxsCnLmobjaHJobkb6FNRFJVTVzqgel6lBVGg9+cUPWG1HD"
            @"fkIVfHgSs8/jz21VVRpHaXHdmkFOEcRaUH/+G/SxISbslPqEPWZnzk9J/fLhrVZ/b7R6s1L9TfWujOqjYaq5bR+5GuoPU39Ttfhh8/TDa3lwMl"
            @"tkgSQsMn0rrBuRvogmhDsx9zD0MKzu8EzRXJSkESNBQxxS1RwELwxD+A6vIUpihXUREgN9rwxL1a3S64E28oP6ylnMc+afz2u12Zl9vPmdXW8U"
            @"wM3yCGaRoT6wzUgaNV+8PoMf9mCZJVaLSZZUGdFiLJB50J29acHMNopiqm2nVQYyjzSPX2BZ+L/Zz0xUya3Qb+57UUnEhNNUfezUiPYjw4a1rE"
            @"fChogkIeSSOThwXve9yhCRPuEtZWGzzd+MevLqs+UG+nVMFZXUiq4ZoW9E+wYzcOi+V4ZGZOhV8xAQqlRKZOFJz/Z09bNM429d47rS5v7XxQOp"
            @"+rgYrEThSYXwqh/2YGcHf77Qs4RBdPF81Yu/8GMab8RU4Uqbb7Q67KZa7FlOOX/AjUQoETQN96IHFSJhA1HUk4mQhs8khJMYnog1rEXCRmS4ao"
            @"2sJVaeMzBQyJyy7z3D0shWqbqlqpmK5ih9VTKBVCH8WR1qkVTRDK8IJhUhiQ03rMi6Eemrkjkv+4hihD4qw/qzeiWXhZg0z/wxUv+I2XM2zZAt"
            @"8+upkactZOHN3wlCJLPQqIiZP1Q9l9nV/yHVqz+yIWbvVx8J9s1daeRxWaHMP0VdJyGY6r6c36faF0LCpFWYFCEND9VkIpoomhuVfhUSQ3JlwA"
            @"prSSTPx0aeSiN5MYnkOSP0VclzpzdLp1t4QZ3mHh2qJ6veVl8gdei+KClCv37KCln16dLIsBEbuREZ2UCgdLqlXl8Pn0P71ccbCpIaFA/5bIHr"
            @"Yq3OtKQ+lY8kdAuHVzSE9tn3PWahAaJHMp/G/Xr+smhcnfPQ2lgss5AgCHI+25Ows+RDbv1mtSFoEpKvcJeKkIqSmOohC4S/V9KwebQ/Dyaaip"
            @"KISCqiiTEMImM22hGfSyJ5rhWZF1sWIiuUXpnkup4pr6OKiuReGKrOFnl23yKgQt68IEXCPZxa84nYcqNe0Inn61ZYB3AqByZsulTVZ1SlYn23"
            @"i5GFWKzaiGTN27nKXOva2tTPXOdXZ/heXehpRAu5ViNJWgzSuhAamvdU86t9454xjb+tEwIT7rT5/S3y2AWuf4ZR+qGcEQz0RcPJNKL95i6pH2"
            @"z19sPXGOmLkIqYxAj9WORGKzKfbsXc6ESGTiK0IkNWOMQrorwoQoIozrMfTmnYXF5lGP5b6oAzVNW8Kgn7qZUX2xGfTay5agQyp/sT575uRdbD"
            @"+1QUyUPIJ/fKEKSvSGZEZ5+xqiPxyNChw2ZShS6kImideJ2r0R9XEkcf/pTn4VX10RCr8mjMlmZ2rI+WR+d/r6FMQUIjotHZCaVNFZLCokEfox"
            @"ioSpTqBFv61c9OCU2NflgsqTdbX9DUWl1PLTc6kdBLDMtty2onZjgpEIVIPKb0zwN4K0PV6sHXyY+X/Soa5ajilVMR0gjZ6Mfy+U5ssd4hkSV3"
            @"mqiSGyN99ZrhwaNDhUQht4Y1VKtkkD6h6hjWn7/welu9ZF7JZ49ZFm9FU4V0rRJYZZ6BS11uVusRNevOhSK0Dh0Lobz64zoMiyyG3Trtkyo0V+"
            @"9OdTFQhK6TJNXmTcWH0BwyubBgimbiSYUQosPCayIiaWTlav1wZqdZqsUWTQRJwTP7XiG1ImuJKJ3I0E+EjUHCi9f77B5nvL095uCsxOQOjH++"
            @"dJqpVLWvau6VoZWwMAq5GBLUIGjaieTG5V6LvoULly9xa+uQ3bPxgYG+QfsiJF4YOjhQyARJrbBmDP1Qzpn1KhkbOmS/9LrllaEXhkY40EYDqY"
            @"5+pi6VqhX3hnOtYwmHsM6uHznd5xe6Wcv5egHnjY+qRxPCc32yFxom+kigqN5fakXXFMmrjHKWZIlKEpoVITQbqoRLJBWRNDJsWGRNJTQmjNAX"
            @"E052faoFSUK4DpEgtjzVioVBathYavGRZcunf+UTnG7vo1/8gPdF8EOlVCUTTUHS6sTilHUUEhsRWSEvSkBII0sX5RNPX8CPp3TXBrxx/xCPDG"
            @"PLDause9VTJ3JglXVVMmtYTyzPJdY8F1u5ERtJnfeUnv1xyUsT5etGdMuI9I0ydGhuDAt5tFYt09DzlkZStpiz1xdt5P287p0tQOO+1cZpfWzC"
            @"VG8Ir/Pm6qNX+0JvWUzVAxbBwppQLVDYoVnVOOkjoUNlhEHdvDAi/Uh0IzH6XN1qrDdEtYcTjCDIbIEFksQw6CURa72UJ5diPv7CMk/+8q9SHL"
            @"zH/gdbnGbK6aRgWgpGpUogBa8hJrjScWWtR7cVc3/rkFZi6EeG1TRmuHtM6ZV3HrzPWeaIItkQJfGeoSq5Fx16GBqk34rk051Y1ntJTNcKHfH0"
            @"eh1uHWXrD8+K5zLR10P0kVTQ1IS7/JGGiTbKTNHZws3bpLM+kRLVfeW6tpVzoYFGjbbY8GBW39H4GdJAHpr1NICYWeO+L6ppfWdao+vG0A+ZZT"
            @"jNqpoJ4SRaI+vG0LfImhGtkij5tEioX0MyJqnI/MqoAQwRxSC0IqEdGzb6CZ/67JM890sv0LnicYM2Nz55mc3NLU7GjsJlFNbgnEO9olFE6TwS"
            @"RWSjMcVIWe5EtCNhrRWz1IrxznE6dZRWiKzQQtdLZd0bzVCDVx2KSJKig44ol9oRl7uejYsdXvjU0xzvnrH5R7dIjDxnCNeQep/NO3C62L9uPF"
            @"eZd4GrpEznyFYV6qMaXVH0kc71PJVvZniNVsVCRtUM7x/SBVfQareJkBjVvjGmH1nZiIxuiJCGjFqyUtmqMsnUGl2LhKtGpG+trEVGNtLIDKwo"
            @"XkkNgjF1yNJZjalVhLIitIzQjwxPXVziwb1T+J+/ySeSlPxkn63v71KUnqVOi5NpSV6WPP3MJXrdNq+99QCfWtSHQ2Ct0LJCLzVc7qf0EktWGK"
            @"alEtuCTiJEpaH0ileT+lDipJGHJy8u8Zkfu8jVCx0++umPcf2zv0BqPP/0f/N/xhiDiEsFEq8MFckFTWZgyUKeO8+6tVq7GXQ5b1fM/jua4bPa"
            @"iPjnS5vGnVoDFHPgYd78WFzc8zmczHrLIYEKTQxjGFhhPTZyIzbcMCJ9A33vZZirv1ndz2lkZCM2PBVHDCIjpAZaSdTY1SFTx0PZ2JlKCFexV5"
            @"7ZWOXu7pDjD8ZsDVqofxlKz9ZuydG0YP8sw0bQEqHX7zBY7tGPwKYR3vuwwLFl0IpZbxmeWI1ptRM2dzMORzmr7ZikcIxLT156nIfMK84LBs96"
            @"L+InP/Mko0nJcGePzmCPk7sZx/tjnDE4dfveMwyLTGaQvhcdGiSgXUIDvZovfLNnIVVirDKvsaPzwV4eqZMXAQEj9aMz4cUaWPHj4MnQ+pTQfT"
            @"KShpJGZt0qa1izhrXIsNG28rnYCGJCiC2cfTHzummgHxkGsRHSKHxTOzZ0EosYwTuHCFhj8Aq5U0ofKk4jgs9LnnvyAnE75tb2EZ1uxO6k5J1b"
            @"J7SsYW9UkDkljg14xaaWzdsP2RZY6rcwqlhraaeWQRpxIRauXV/mub/2Uxy/eYvhl25xealFKy45zRyTwpM7z7jwHE5L8tJjjeHBzgn/8L/5Eq"
            @"3Esm5yVi4Lzi5xdz/jNFOmhf9urtxUJAtXkWbMAA155LkuLnDjgKqZ3c8iQuRVP7QDtRilZbHl1ajNzGNYEs2TP+tLz+vmVFSTkAFLaoX12MqN"
            @"2Aq9yBBZsFWyMCn91cJXp9GGBkYnMgzSiMu9mG4CR1NPVvrQ5nOeXAuyKKbA4kvH+mqHZ6+v8MO3NjEWXOnBCIfjkn5sKbwHA63YkFbv16YRsR"
            @"VigVZi6XUs/ciw0op48lOXePLf+yi9j14guei49t4u7b2Cw3HBybRkOi3JvbI7KnEKmXEUpWdSejJraGHIM8O9D6YMx0NuHWWcSrw5dXzHqw5r"
            @"gKZKvvKqy5U3+8nNcDz7+vMdsuoLowUsVubI0cIl0NguAeFVkPBQzeNADVkM1eG0SxpqMFCRbJZgqGZIABmsIfQIOwmRVawRcucZ5S6UAsaQRN"
            @"CJI660LD/94ipPffo6b758h+2dKTYybDy5wsbHnuIbf/Q6Nz84IG53+MiNi9z5YBtXlCSJITKEjNMrYiCJDF6UJAqRyhohtoY4MqSxYdCNWe9G"
            @"rF5ucf2XnmLtJ68gEbjTHZY+2uJjf/sj7L10i9Gx4fTM4OmxtZtzcvuYlhXKUvBWcB6mTvFFSctYCi9873sPOCwkmxh9xakeeHSoIrkoiaJVTU"
            @"6NeoUEeLF10cihZNbThjl9KFI+5Ag3EJAmBKYexMC/izAyy+jnGWFmTIDwqkY/Kpp7lQAGEHrJxsJSJ+bGeofRaIJYwyhznNULbYUWwpOXUj7x"
            @"73+W63/2z5F0/jmbbx4xHY259omnkOWLWDzdNCJJDA829yiKkm43JjJCOzKkkbDajem2I5LI0K0g0CgKC5wkllZsaLcsvdSwdr3Ltb90nc5TA3"
            @"zhgC62dwGI6H/mBum1T+NOBS2nHHzrZXb/8A7dVkQ7d2ROcKXgSo/zSp4p6cU+pW3z2ltbFNbeLr1uVrShRESTAHPOOUFCtejncPaFczuDMXUh"
            @"l4oWk+NHV87XdbNUaLOC+Pk98TjgdxHIqO5jkVRU0xpkrxCiJPSGdahIZkXSVmRRV3LjxgqpXeZk8wiSmPG0ZDLOyUvHhesrPP2xS2x+4y2Gb9"
            @"5k994he9sZZ+OCO+98i9NpzthbWqlF1ZNYodNNMAKtyNBLLP3UcHEtpdWOOJsUeBXi2JAkhjQxtBIhSZWkJXSf6LD6p5+mdekS6laQZA31bfxE"
            @"KadHuPEJ+Bxnp8Rrl0g/8hlaL92h3445HpdMrJK5sImMMeA93cTwgy9+l9NpQalsqQZcuwZEGiE4rQ5NNjul0iRISaNFXB2+OpOWWXYtH34Zn0"
            @"u+pMaDz4eJul6pKT81KU8CcA8+gAgBM81FNJ3dzZAghtLLllcGxkAUGw63D/lTv/Yp/M4B/uE2GiVk7SvoSp/xyZi7339AdpLR6cVMnZIVnrxQ"
            @"ps7g4zaJ9/TTCDHgspKkOr2d1NJrW1Z7MZeud2n1I872p4iFtCukXUvSj4mX+0Qra8Tr6yRXLkHSIzsz+OkYze7hJ3tQnECZQ1mg6jGijI/fZf"
            @"vhJTZ+7Gl2vn6T/cRipyWiGtISEXxW8JM//xNkh2fw2jYSRSl+hh6lRrWvQqIaQI1qiXJRSVXIlNA/r2HdxwCG1YIrHiHiT0jOlAYpVM6d3vpM"
            @"y8LXVu1Fr0nV86zZH3PokNCmBMV7hoULRb+1hqJQTt+9y4t/789QHCfYVpt8vMW7f/B9bn1nk5NRiUcosvBwCh8+WSuqGZiWdisijQ2oJY0t7T"
            @"Si07EMuhFL64beJ9q0L7QZ7LQw7R7x8jrR0iVsfxWiNuoVl50y3T/CT96HfIj3E4wvCaCDBTVEUYIvPUk34v4bZ3zvn73Mn/qPPsfG+w/YPnWk"
            @"NuQBRkCdx6lyfHLGZ3/uY/zm732Lk4xEJPTljWo/MrLhlH0nHOBmqF6/BjHEkyDkNRHysRHY1yxQaaBQP3Jx590t85hGh+giL0HmDI6kZlUQGh"
            @"Z9VLHCmkASetISmB5IXvhQ/jjn8cYw3jkhP3H0P/Gfkx/9W0Zf+C2K/Qn95Tbe5GSZCyE4tnhVjAEbhYQpTixxaui0LO22odWCVkdoL8V013uk"
            @"19dJP/IxbP8iOi5Rb9CyxOUnlMMH+Mkhkg+hzCpEJ0JJkHgdTfqYdIWk06PMxhy+9W2W+kqRWd752i4Ht/fY2zrhykev0v7gmDSOiKzH2BLxHp"
            @"PEvPP6LVrWMBWDNawbDf0BRTJVzU1FVvCGoVPd9zBUJKtXvMK3cxpsnVklI/PC10udXVdnfQFKbID/oEhFUF8k9S3ixSJga3SporsiQg2eq2oW"
            @"0JnwAQRJRJtIE2TOMykdWe6YTGNO3r9F/+NfROwZ0mrTH5TkpZBGhixzOK+0U0NkBWuFKBHSVGil0Oob2oOY1qBLemGd5MJl4rXL2MEqxF3QAn"
            @"ewh5vuwOQAn53hy0nVJozAdjGdi5h0CUmXMGkHEyeYGNCSqK3svXOCnk2QQZutDybc+/4+USvm9rdu8em/+DGW2u+QnDkiUWzFRfdWeLg/ZPcP"
            @"vs9UDGI0sV7XnchBxWhJfXVyVar2rpKbKs12wkHN0Khg2vw8lKCzEleIdEbOFR5hPesiGbS+e2synzaapvVdrJALkgSuMmkzUzAEeE0hr1iNqR"
            @"HtWwLDEVGcKmdTz8mk5GSi7L96h7Wf+Q6tyyX9T19i+HDCIFPSRHBlaLSkLWi1PFFLSXoxyWBAsnqR5MIVotUr2P4yEhuQMyhP8dP34fQELU/D"
            @"ojqL9xY1Peg9gW2tYNsr2KSLiSxictAM8VPQM7QsQJRi0uLsg1v02oKq5d1vbFOc5iS9mIP3txmdPcu1py/wYH+TxAiRGCweDyz3+2wenlL6OX"
            @"Jm8P2KZdwvYct5v29V1j06FCRRlUxFq/KKPLRwa3rUvH6uNQleGtm19yEpWMza5uQAU7Uxq9xggd2/WLNJAxFaQBoRSCys1xl1xdxIREgw1Qao"
            @"3uXUefZHOXvDmPV7Zxx+510u/dIaxkxY+sgAnRzTkYg4gbQL6coSyYUrxOtPYlauYTtLEAnqh7jsEHV30fEhlGdQTvClQ30bzGU0WkG6K8TtJU"
            @"wcYWJBNEN1ivgT1OVo6atWYd0UEmwr5eTWPnZ0QnKhxcm+Y/P7h6SJDR+4cDz4/n2e/vEnuPDGNiclZA5KBV96NvdPGBclXsF4+lZkzRpZ8+iw"
            @"8Hrbu4BaOWFfVFJUhnMSIWl1mGaorp5D+mopkarOSQOLuoWG3EQXCdtiGix21TmjcHYPh2w61NSSiWhapf6pGEmsYd0QqDnWsG5h3VDhwVWbzH"
            @"tllDv2hwWH/YThGw9JlywmzRHn6N/oYownvnCV9o3PES8tIUkKlIg7Rcv30ckxFKeYMsN5g/dtxFyH5Aqmfx1J2hibYaMcYQz+DPXHaF7icRj1"
            @"VevWzDIfxYN3YIQiKzm+eZtuAmott147ITuYErUjxCtRO+Xw7Yd85Gee4MYza+y/uc9ZJozL8PALFDWCVbDCIIbP4DxqhHGp3/HKsES2cIqKZJ"
            @"gQxlFBhRl4IfPCZiHNlgYqFdWQ3CMnuCLDn6fuaIMSJNXq1QvcLMhFJQkvambMjRoXDiC/pkboW2TdCuuiJM3mifPKcFpymnuGO2OmX7rNxk+t"
            @"oqUn7Vvsao/283+ZOC1w+X3IJtVClXgnqG/h7bNIdJUoeQKJ1jHRMiYeoP4hWnwNdYdoXqLMSPNV1DKNjp+vdroPz8YKWpxwdP8Af3qMWbIMJz"
            @"G3X9kmtoGgZ60QRxYzLTh4d49rP7HBu+8fcJxHTEqlKCH3od8eCUQiDGLLxZUOt7ZPcGpeLLy/k6vcREC8pqKae2+GzvuDODJPOeTAo/lj1XRN"
            @"0l+AGpt96VrpUHOsH4UfF9QLAgYD6gOjUcLCCtW/RdIQnjWp+VdGpG+NrlthLUKuWmHNGlmzhkEAM+bvc5o7nFMeHmTY4wn9SwmDJ7uYtCS+8D"
            @"Q2tWj2JqJQFh64DuYqpv0kNr5CEq0iJgU8nimGEtUjfPEy4g8wWNSk4DXQ50RB3SKrRTyqobctRiiO7uPKEWe3z4jKEqI2t75/xNmDU1q9hEhD"
            @"azQWaPUSRm895PKP/RiXr/TZPTvGNJRrghIbSx/H5168QrvVYnP3lDiS1Dj6xvm+gUG9Lq3UfPqFJy/9i/ceHP0XR+Ppfy0NetZjm1nNO3lGGF"
            @"BdUD8YeQzNvvFCpkKTMFItMmk4wRrkKgpitEKeZhTb1EA/NuZGZGTDCP3YcDUyYJt6Kh+Cfl4oD/YmLPVijranrH6kh+0nmP4TaHkXRcnGyyT9"
            @"v4pNr2Bsq6beARnKJPxefWC5lG8hDBHTBV+ClrN+r84IiiC4iqmiEBl8OSHfuYfJTpi4ZbLtE7oxjEbw/lc3iWOLhQBq2ICWtdKIVubIHxyz/v"
            @"QavH2AV4/znmrfsGyVz714hV/6Gz/Lb/7Tl4hiC1M/I/Azo/KSdVrxL55OS4aT/F8Hcn8VruFHqNdmMiQ9x8NXBF/VXueUFTNcmERF8xodMRKY"
            @"iWXhD0QkrUl6NcFu3mnVTCSUTBXf6WpkCICAkWqhw0ZL44gsc2TO4xWKQsE67OACNl0Gd0SZT1H7IknnacQYgipmQugQ+qoaACRBy3uo+wA0wv"
            @"tKraEyF9hVMoDZqVCHRIIbH5HffwdO9iHucnxniE6mSBJx6weHjB4MSdKIKDAGAxwaGdqRod2LITYcPzxFI4tIaBmKCdfhtYtt/u7/8T+hOFP2"
            @"d07wIpTeVzSoQEWur7vD4fS/fOf2XqpoPleTkKg2NAmPW+QZhafKvbWRis/F1br4Kzy+vLrYEwN9vHJh0Pq/v3B9WQOMSLULpeJZVdJPlED9US"
            @"JhPbVCNzK0XUknNrQiQ2oFq0pLhLL0xEaII2gNosAG610FRohmlHlM2v9Y0D+JB6nZWU0yUwT+GO9/OOMnmQU5rM6FcxASOOORyFAcPyTffBcp"
            @"MmwrZjg0jO/tE6cR2RTufnuXNLZYA0kkpLGhnVp6rYiOVTpPr5AZYe/+CblIJVIzRNbQii2lM7zz9e/wx//jH7M3Fc6mBXmp73ivw/CZQt/BQN"
            @"8Y6SepfU6MJIHzNjtMH06qmwsyZ/3sipWvj4UNzyMftVIwSGxI8ry8+cnnLrOx3vufvGqgsdIg+AFGpa9oxcsKddnTG0v8rb/xKZ5YSmlHAVtb"
            @"6qV00wj1njg2dDoRS5dT7KCNbV8Ef4jLx8ATxMllvGYNcpuvpJq+AlIc+NcxjKpO7kx4Fe7b84sdGcRCsX8bt3uXyApiBVodTu4MMWVB3EnYuT"
            @"dhsjel3Y6IjJDYsMDddkSvbWn1YjofW2fn5i7HY8c4Kymcw3uP94pTOBnl3L21w/sHU45yZVwqheodp4Hg71WHoYohV6+ZenJVzb3ocMZNX9CK"
            @"PYZcv6DIn3W1qn9Lsy5udLoCGa/6AZIGVR/pcOr+9e+/8h42suuxladCvawYlb4R7dcNj8BRksxrKCNOT8544pmrTE4zvvXKu7SShF4nCdivU1"
            @"qxob8U071ssYPLmDiB4oxykmN7n0AkQv0UwVYcsqYSOkbdW6jbQohRdVV4ctXnNmGh64cVxaifkj18B4ZHWGtDvh0Lo0mHbHOLJDE4LA/ePKUV"
            @"RySRBAgzsbRTQ6djaRkleW6FSZ7x8PYRZ0Xo4pWF4n2InsU454mPX+HwNGPzaMIphszxjvcyVNVctQYiAvneqwwhlFQ13qxoLkjitdJWPVZBIS"
            @"HCzXuedbvyUXRKKi1TzZtuwBMV81L6o9z/vsld35ig7DMifTE1GDGjzaaqmjsvpxgGxxPH//e//X2W+y067RbtWIh9QawRS4OEfs+yeiGldSEh"
            @"GlxD3Rm4MUW5Qq/3HMq0ev8+3GJ12UMMuoO6dwK91te5hlD/T5sQThRRTnbJt29isgmYaL4h2qscvzHBTCckF7rsbhec3hvSbUdYI7RiQysJv9"
            @"qJJekbOi8ss/WtLYa5hp68CL4ubL2y1It58toKX3/5fY4LZezdful1S5WsktRkFRkkq7luVfcr9TCsqpt+IF4sqkAXFtksMN/94nHXR2vnuYpd"
            @"ENUkiMM0CZTaoNPlXEfMo6cikgisCTXMGO4aHwRhnHkhGhcst2MGLcuFfsxSO6bbsVxYSVm91iJZXcGkF9H8NmVeQPQ8JuqhfoyIrTafnaUbqh"
            @"Movg86DY2NGSOtnN3XAYwLl152dJt87wMir2DsXHQbG6Z5l9EH75BGgiQJd7+7SYwQ2cAsaUWWNKow6QiSG31KHMdbI6aeQByoTkdkhbz0bFxY"
            @"4oO3t9k8mKDWBhqy8WloetQViqDiczWaGzV9Vcmais3Q3yafBV55rNRpznZ8XDyv5TBiZlLRmbJQhdxokKHMcUY95x+hGGQQAAhJBUlqvte8BA"
            @"iZvDGG2AaC3mo3ZrUXsb6UcOFSm8HVGLt0FVWH+BHFJCbtP4NwDzhDNa9+ZaiWKB5fvoH3+3MOuJRU8hkEV/XgI5CSyd7b5Lvvhfza2lkXD++g"
            @"M+Dw/SEyOqW11GLn7pjj26e0OhGxCRTdJAoVQpoYzCAifmaVg5uHHJ0W5E4pvMc5P3vWvcRwZb3PwTDHi+CaTDuZ9RiqxCqUqmrIQmdQMaJ9Fc"
            @"kq3nkya0Y9NrvWOWVaP4QdEsBnciOSVPVZNrcwklRMVQNDWp3YcBdXOqRaEYAoYioqbuiA9eu0p8hLOv0OKxeWySY5/fUuFzd6LPUi+pdS7HqC"
            @"pFch38XlI5xfI+21QO8D94BTjOYBfRMFdwfxtzFia573TAsogaWG2Ah1I8YPX8MdPkDENvoFlRIkNmRZh9H7m7RaFo0i7nxvn46dM0cTG7LqVm"
            @"pIE4ieHuCtcPjBKaPMU/pwVXitXQlgtZtw/emLHJyc4URx3lckAA2L5jVR1Uy9zwHiyN4Q9YFc4AX1kle3UkqI/rk+Zt002HXI3H9KtfGXiwT7"
            @"muiuBDW/CEkAGSqxWkPVFrDi5gKTGAJeWpdXQewlaWQFI4Y4iTk9HbG/e4REEUc7Z9jVDksbXZIlMMvrAdPNtylHJUn3BsaOUS0RM0HMIZgyFK"
            @"B+D+/eZm6vUllM4OdarijBTfeZPPge/uwAY+JA7KN2QRC8OqTd4/D2MTYf0V5ps3t/wuj+iFbHEijCgeyXppa0G2H6EelHVhjfPmR0Fliao3FG"
            @"6X3gp8U2iO4iOH64hys9MmPbSPW8NK0aSwGGNabfTpLPzpyHdIExm6lK/mHuSCJV4lXbIzV3/GLoDjW0xw8Npl+RzYKcdIGI7xNRUhXJA7uwCt"
            @"NCGpKiuTYpyGNA8BhjiawhMhXeZYQydxx9cMiFz6yTXrXYlWu46QGSnVEWfbrLl0AnITv2I7S4hTpF4k+gfhvRUYXEuGrjORQX4k1kKU7vkO+8"
            @"CUWJkXhhM3tCP97EltHUMn7/Ad1eBInl/g+OaMeGJDKhuxUJrdTSaluSFKJnVzDtmNHdEzKn5KUPqakRUrH0UFY78Bf/459nd3ufr3znHlYMRj"
            @"zG0Lcq6151GElwLEAMTv3+aDz5AyP01ZB5H+QzTcakqUTynpnMqKlP1gWrIX1sFt5oN4pmM0ui2q5BmZH1ZiKcqiMTEJNKS2yC844VWRdDKqr0"
            @"2x2Mlhg8RsyMxeCtgVIphhPSy9exrcuUJ2+i0wJJNohabbw7xufbaL6N6BT1JeozJFqtcHBX/arqYTEgJfnBu5R77yM+sM/OqzeD8t8h3T6nb5"
            @"wRFzmtlQ4P700Zb44Z9GPiKCx0K7EkLSFtWWxXaP3YBuXWAdnEU5Y+JFtGiKwB53juyRX+6v/ub9JZu8Dr/+U/JEoiogKs8SikeDZAKOC2gX6Q"
            @"zIKaQPQTNHGGg0AFCnZVHhmKhJLKBquNzFeqCxEhmpEAZsX0YpiuP7hHsYROS8PmMJ/1WAO8lVS00lSszk5tdTiD8t8E5b8hLHKvnVJOPRZfhU"
            @"ofFsUrJhHSJYPpXaKcFkg5osgikrWP4ouHuNGbiBuBiUFtyKx1Up3eosJTPWiJFYP6KdODdyiPHyBqZ9dS0/NKg5ELJrZMsw75vU063RiiiPuv"
            @"bZPGITlM4nAPJ4mQphFxrNin14iWYs6+fUhRQlkpPaNISLzBqONjn7jCzVde5Rt/9Drv74zwIlhxJBIydWdIS+FGrNwoPZu515uFl9tGpe9gzX"
            @"sdVpLYYHkR+NW5E91vaKATgmVVzsxOYsEh7vH/WExi0L6qz2edrka7pT7FIpUUpsKPRTS1sGZF1oxI34qsByK9EkeW4+NjukmETQzWmBn8Fhto"
            @"tS3tCy3oXKA82ULzKY4niTsx7uybiCtR4gDqE4jyojlCBnXAqUwXXHHGdPdtdHyAYPF1j76p8a2qAl8WSGeNo3eGyGhKutHj4WbBaGtCrx1hLI"
            @"F4nxiStiXpWqQN6Seu4PcPKSaBlmTq6887eonlxz59g6P7B3zzB28wiWK8sVgJf+diQUPPmjIoRxgV/qpHhojHel13yFrdghRI1ZOV6recclA4"
            @"bouSNoSCuUDu63BtPsRtZqEJolqzEZLaea5hzpIskK1ZoAVV4jYGsciN2PBUZEhTa0iMqbpFBisSlAvG0IqEpUFKv2ewgyVUWriz93ATh1neQI"
            @"sP8MUUkTggSSKh8a8AOepPwRcVCiD47JTp7ntoNgyy+SZMXDsLmRofBxNFjCcdph/cox0LRZRw53ubxFawsZDEliSxRKklaVtsAvaZdZILCdlr"
            @"J4hYEoFey3LRtFm9fIGzoyNWVjq8+s42WZyQFyXqPYMEliyksQcTM/YR++Oc3ZESWwHR5yNvNrBKZILYz5aKKUuitjBSy1Hm/7WqZOo1m/mbhE"
            @"wdlLnTwPl72DQkMwKJGjIhsDwssjZbSi+psdqvbQYbS5xUvOpUQu9+I7Y8FQmDpGogxCYscBQJ1hiskUCdbUV0W5ZWR4gvXaUYHUM2pCx6dHtd"
            @"/Pi1gB7hAyfJBJmLGAWXg56ErMFYXDYi3/0ALTLAoj4AGH7uTzIX5QXOLHRWOHn9GBmPaD8x4J2bpzx475DrF9rhdJrQK4lSQ5RabAvST2xg4y"
            @"k2Dlqu1Y+tUH5wSr6TceIyzkYFX3/pJhOvM9CghfDsE0t8/i/8JINLK4wP9vnK73yf03s5iSilgdgIxsggRegZZa1vufb0Gs//5FOsXlrjX/6T"
            @"V/jWe/ufKCJzu8jd7epqHSqaMYdnHtURS0N6Wlsl1aXRzGBUalqo4pWhMTqzZgolVuUCUCVn1shaJ5FBJzKkBhLvSZMIqeDFyEBiw8luJ5Y0Ft"
            @"LlFLt6kezkLuU0Q7rPY+wRfjLCSAuwIRP2rkqWLLgM9TnYCDcZkR9tgStRbCAj64Kb3zwPqY1SY8N02mJ0+y7d1JBheeflHfLSM8k8K704lCYG"
            @"bCREVpErq7SeXYGzu8SDhO7lEj+GclqSFSWTs5w4FrzEuNxRqkckIorAIhzf2+b6z/w0G5/8JN/6vW/RTWPamaPE40vPAHj2yR6f+ex1XvjMU7"
            @"QHfQ4enPDtL7/H3t4QNSZ3ue57wikODkOS12saPVbNWH3o+jQ2YOm8Bv5Fwn0bNgGpuiqEV35b58J94pWh99Cyho9c7fFTP3GNvTu73H14xjD3"
            @"xBWboBObgOJ0hc71K5BY/NkBvkxJly/hJ+8ipeClqGDFipWogXCIerAWzU8pT/cQp3g14QTPvK4WdVoigolCZDDdFY5fOyaajOhc7vLW6yccPD"
            @"hj0Is5Hhd0WxGtNJx6YwCrJB+/StKdUo4UXU7g9pjs9hArwqAbY62hmznGuWMcGVq5I3dho3nnuP/9d9l45ltc/ewnSSNLEgUVZ9vAU08u8zOf"
            @"vcZHf2wdVcfb37jD299/yPv3j7h/WnDozOZZ7n9z4vTrhZc7Suh7SyByYGredaN71RB0B6J3g/Yzsw5u3sdhM2gixqQVdzqtbSAavf/cwzD3nm"
            @"npkDznEz/9Udb/wk/x2//gd7i1PQHvGbQsy/2YQTemt2xoPX0NNz5GJ2fYzjPYOEfPjhDSCiL0cyTJVACpFlBkuMkY9YQSxis+4NiPGn6bcHVj"
            @"hKiVcDaKGb13i8EgYVoa3vjGDkjIlEXhcJgx6HawNmDSstaj/fF1hB1Mv03x4AQ3dSSDmGVraPeULHcUBUzzkuFZwWhckBeBVtSOYandJUrCm2"
            @"mnEa3Ik0QWI4Zr15Y52jnj3377Ptu7ZxxNHUMHJyWMSvOdcaEvTTxfdyoHVQmca+32V3W8ovNu9DVvqBZfMW+OpDPTNJhxuJp4sYrU3Zh+0wcz"
            @"MDc1915OS6+Dhycl//q//UM+8vQFzsaeXmS4en2JyDuWEsPKsqV/bRm7usr04Vu40hAPLoN7GMgeVa+7BhCMmPDnNkJdBvkUrdqI6uZ8VZWm11"
            @"itmw5YsYginVX2vrePmY5pX1jiB6+esL8zptOJKEolimGae84mJaurCdYq6QtPkK5ULz4Nr9O6kmI6hm5NqqZyHTh2nO5MOZukeDEkyx36V9cx"
            @"o0NscUy6dpHli8vEDx4CyqRwfPkbdwM8GQkFwqRUJoXfHDt9qXDcLjx3nOqB+tDHnvc75uhSNLOHOOekvqA9bXRXPDoMBmqSivh03ikLcpc5A4"
            @"RguiaSBM8q6XtlmJU6OJmWfHAIuydb9DpxYIYklud/5glknNGdntF74QmcG+NOD8AsYTstdPI+RgXVopI6Vy1IU2mCcGiZgdPAGZgZllZiAJG5"
            @"bqsi5mFDEW/bCaeHCWfvPmTQjRlmhje+fUCcWPzc5h4bG8a5wzuPGSS0fuwJhGkIjUlJcqNLfKlHK4/ApBC1kWQJdRPcyQGrY6UoHDotkdQyeO"
            @"Eq7vSE4/cfYuNTkrgdIpBXpoVn4qEAilwpvN/Pnd7MnL7ulP3C6Z1S2VTI1AQ7yCBiX9SXR4/a52ttwU8TFpyxEOrTq2Zu61TVx8GPf+ZmO+tz"
            @"16dfkNQrTArPqZT4xKJTwbYjtu+d0o2UFz59heXLPeJL62SHO2hWIGuXsTLC51O8RoGU5+vs2FcJtkF9Cc7jKxZg3ZM3Muem1SMHxJhwr1qDiI"
            @"POZXZe2YZ8TOeJNb77rWNODqZ0exHqAt+6HBfk1lBowtHRhKWf/xid6y+ijMKuiSNkAL7tQ2nnS7TM8d4Qr18lunqT6Pg20b0Dprsn6MRxuL3L"
            @"1ltD0svrPHz793nte3fYG3vGuQ/yRa9kTrNpqd8tnW6Vymah3Ale2mw65UCFvGmKXcue9BHbRcD7gCeLzhDjSowWfl4NeTUy6Fl9rGgmSmqMmS"
            @"kjakruzHmvouZ6IxQq5E7JSkdeCrmPGB3nnH6wx4XPP4G0B5T3P8BpTNpfw0+2UKeoBohQvS4O85AquarRHJUFf2wNlOBgM2UEa81soW2ny8le"
            @"zOj9uyxf7LB3nPPtP3ofm5eU0iLpdOktd1nZWGXlSo/1a32Wr3YZvHCJcncPX5bgpmh2Qjk5xRVjAt5fIpSYWLj76grXf/E6omNsW0hXWkyPRz"
            @"x4ZY/jYUmUdXn1ax9w67hg76zgLHdkLixw5vT1wuvtArntlINSdcsrp7URu3qyIJSba6JmzsdSL7LMJC6V8sHnIpKohEu8nsVQ/T4NqIenJpgF"
            @"pEQGkZGNIne3rWVdrA2+ICaw/kU0Mcig5kSa6hSZqO50CWIMJgFZu0wxHqPTMyS9SJR6/PAQtDIRnhEPK1QJqU6xLuq1ZlaO1c+T4Iks1iAmwl"
            @"RcLtPe4OBrt+i0C5LLl/jmVyY89ZnP8sRzT7Gy0Wd1A5ZWS6J4jDVTLBmuOEX3txnvlUgUNgxiUSJEDOIKBCHppexuCm/+s1e5+LGn6D2xho52"
            @"iFYSzP0pFuhcXua1795l83DMae7Ifeh6OQ1mrqVnq0S2AqHeDxXNPBLIAkgSHH11gXPXNHibh+uGS7YR6deX+KzBoUptB9FQ3CQV5XOgkCXCcz"
            @"/3k0/9V+/c3zvdPxr/X+LIPBXQKu2rSj4zE3MeIrCErlcaW1qJpdO2dFbb2AsXyA8foAWYtXWsHuDKAoiCgdosXFeJE4E39biurJjKKLzqfmFs"
            @"WJAqrbadASc7gh4+ZPmpJTrXl/nV//3P01m5Ttxewp18m8nOG+TDKX6oZKWgEmPSAVFnA5O2kbSFafdDKdaJGT+4j269TtKKyKZtvv8b75M9PO"
            @"Lh1z7go3/naWjtIh2LjYWVJ/oc3J1yeDAmQ8hLrVwAK3BUGCqaq2rWHHJS66GClbKmUrsJK30vFReszq4X3Hmq+3f2QjP32vkYlTqMz618Zh2c"
            @"flbo6wfDnE6rNUDHGNGKHCD9SuCGUeh1UhIJBiQWDX3qxNDtCd1ra5gU9OwQtT3ipSX82bvgBe/KELJrloOp+ENG6pJ5PkFFQoiWeoFrQp5YxF"
            @"jERkhk8WaJ8d13GFxy9K6t01rrYTpn+Pwek2mKy9pI/6dpL7Xwpo2JWtg0xsQmIFVxCTKlPNtCpzsMdyzjN9+lnZTQavGd37zP9mv7rC6l7Hzl"
            @"Jk/+ezeIlrq46RCzGmNPLKPv7hMlESZzoZzDVaZzc86VGFLcjFs3VDRTrdz0G7KYYKVFgpe8rnqiuQn2bIZBPmtw6Hx0jpnNeKgkqdW/rQRjUO"
            @"Ppm4j+m+9v/SeRlY0kMc8ZdGAICxwZNoJtk+fyxSVMljM9GxEbIYmEVmrodgzpExdwZ4eU4wnSf5LITPDZBCHCl25u5GqqGVL1w5gpH7QOR1Wo"
            @"tmBCeJYoLDAmArFgg1PP4NmfIWl3sOkyGrVRE2GMx6DEA0AKrOQgGaLjQDNiiliPy84o9h6g0wMyc4nj796l7cckyz3e/s4Jb3zhHp1OROmF8e"
            @"YBB989YOPPXcd3b2KuDsi/v00qSq8TTGTaTpmoEGmJKV3lyKBJIDTUOVEAg2qygFZoTCD+meqU+zxsdkNkzLlpJpV7e10KBVZH6E3PhGzzhCdR"
            @"yKyYdWtkzaB9m9j12oDcGlmrRgOsRyKptUJqI7Y39xikMYNWTJoY0qhiOS61SFaXyI8e4HJDurQC2X64eqv+cqDJhAaHWjubhiZVoqUm3O1qAn"
            @"Ev1MAWiSxYi0iMMQYTxSAG8SXp+mWCduwIYRe8Q7RGMOzc1l1A1WGi4A083dvCHWxh3ATfv8bet3eJjw5JrvR4eCB889/cRSRIg6WCs4+/e5dL"
            @"n38Rs3KMv79NNJ7S7yf0Ro5uYkgLQ1L6ANoYRdQnRuam7SpkNTtzbjFBI7P2uagkzUEkkTaothW9NlEln81DqhrepuZzBa+PZDZZRRQvOjSqfT"
            @"XkYoI7bSTBk9oYqQ1SiSWYn0WRRQ1YoyRRcNzpJDC4fgESoTw6CXdev4U/OsEYiy99DTU3Jrv44A9SGzJbE0jwppo6VZ1iFYuYeBaqVQQvJqBY"
            @"eopkbwVMWiLEplB9jUiQtegsfGhQVUyPybduo8NjjHhYucjOD08wW5vE/YSR6fDyv3yXcpiTdiMiH8rxOE0o7jxgfO+I3o3n0WyH9oqlux/RbR"
            @"m6qSWZFIiGbphXxTk9cCoHKmQOPaj42FlYI7Lg2lcvPvXJzpszvIz6qnFQ/dv7ihDWUCWG7Sh17ZnV7I/674xUs5hEKjeBQPupmSAGsJWdgiXA"
            @"ikH6EuwT+62Y5YGl/9En0PEZmudE65cx7hQtctRJUB2obwD9oSSiTqxsWFCMDUfG2pBk2QgTxxgbVaHaIjYOYIYGD1mkjUhaLXpl2u4FvMf7HF"
            @"xRzdkryLZvMX33h+jJUfjIvR77d3Py9++QtCNkdYlXfusBR+8dErcsxgfIMLIQJZa4KBh9803QdZL1LslSTCu1OA+jzHGalQxzz6TwZE73nbLv"
            @"nO6HJkfV/KlcgQL5nkeGXtajFWYAxXn3mLqUmpHKIEGDqUsonzRTIbfCmrEMRCpdTkULDV9f4chKaq2sh9ATXPBsBZ8lcSC1dVsxa13L+rUlWl"
            @"eWmd67idg28fIyevZeBQ+6xRkMVXfOmKAc8zZky2IENYKpTjBiq18xXkIJJWLDycbOvCdN6I5ULV0/85JUgusgVnCjfbKt2zA8xdjqe9sJx4cx"
            @"p9+/TTdR4vU+3/7aIfdeeUC3lyAorSiik0R044g0saQtg+7vkI8OKB8cs3trws37Z9zcGXHrcMLuuGQYFpjS6VbpdSvMvCBXJAtsTk2M0A8Smp"
            @"qSNZ82N6+XpXYamMOMpvaIppazzNTqqShpbM0NY0wYx1P5VgTXWx8se8PzyevyK4nkRuQcRpUkSYkIcpLICi1raceWbmpZagurH90ACvzZELuy"
            @"gYkK3OQMaZDspPbMNkEwpkbQyCC2Lo9MOK1iq0vcINhq8ULJNHMPqId4eKkGt/maOVBdfiUmCrKabOcWxcP7iHfhLlfFtCzDvM/et+/QxpOuD3"
            @"jv7Qlv/f4tWp0YUFrW0LaBBJHGhlYsSCzEP3aJ0St/wMMv3uH9OxNu7U7YHZWcFcGxzQXa4WmtoKj4XIiGUinwrXWWdKkPsGKdIzUdFGXGDKmM"
            @"xmsyQBhhVzkFBI1xkhpelNyFLDsGa+16XY8162wjVSZtzTqF55M//gTPPneZP/7dHxDHUUUQCBSf1EI7MfRXYtrPXKE4OQrhZWUdneyHvMforH"
            @"Mzk31WRrAaG9RWTP0qg8bYih1pMIRwTXW3Sj1NbuY9JrPwb5oD0MQjNiYfHjLZ/ACGx9gq3Kv32EiYRitsv/QAOxrTutLn4ZHhW//2fZK4osHW"
            @"/px2rlnWssB+6mnK8ZjtL37A3Yc5D46m7IwKzkpPrkIZWLFVkmXyoK0OzklhASWr+9N17+FclZufHw4RVQ2DxBKy45kHQQNwFSW93I//8V/55e"
            @"coCs+D+0c82Dri8CTjZOr/9cjx+zYxayEj12o0gCQezfqDbvpw85jSe1pVqE6t0I4tncQyaBlWnr+IXRmQ3boLrS5Rp02590G4X6vNI7ORt4pG"
            @"BhdVIRmpFtBWBldVT1oshojaICJ8jVm05pf6z6v00nuILN6VTB7eId/ZwqrDRFFjaqyj7F1m+xsHmINj0tUWp7bN1//V20jhMKklNeHzteOQTH"
            @"U7EWmkdD+9QbSecu8L7/FgK2fraMrWacbOqAgWyqWn8IrzFXYfRA3D2cCziqhXz5OcJVkVvOapDl0DgQr0n+oL61S8mp6WzWYRokSGjcLp7SIv"
            @"b7z48av8wuc+gophb++U+/f2//r7d47/+rfe3t0fjoMC3qND79wwic3Vr339JqkVet2kSpaUTmzpp2GRlwdC58lruMyh2RnR6tOojqDMMTZZGI"
            @"EgEhbY2whtdLK0ntAqMoMeBRNs+mVx9Cy1H0j9MKRSOZrggJafHjJ9uBWuDWNCK7QmqvsSltfY/uGQ4u5D0l4M60u88q9uMd0fk3YTIpR2EtGO"
            @"hX5i6XYj2lbpvniR3icv8PC3b7K5nXH/aMrOac5uZZ88LBzTUimcVrzVoHmazyCoE5KFCW6ZSBgLXOH4+WxYWaMxFNVNBIceOOEgOPNoItrEio"
            @"WT3P+Tf/nbb7/4hT94+6+vD1oM+jGDQYfeSp9OO6EVmfVj5/atMeuVcXmKClESEUchO09iYbmT0o6UJCKUDSsprcsblEcPwFui5TV0dD+UO42B"
            @"22KA2OLjqCpvQrJkGkOpw6jD+s41jcHWOnMdmFlkaFQpFxQTCb7Imezcpzg8RNSH8Fx/fg/4ErOyxPatktFr90jahvTqCt/4wy2O3j2i3U/CBo"
            @"4s7VjotSz9TkQ3MSRPdFj62Svsf+UOW/dH7J7mHI4LjjLHMPdMPRRayQBE8XmZqdPcO4bWsu7E7C/olKvJcM2Uusq2s7DAMtdqa+0Z0rDE9abC"
            @"i8VXpmuCEw5ypzeJLIcqp0cnRWqOsr7zw/2y3NlyykGSmufiyNyYjzWnMWgyKBkMhnYSEYkjsYZuKnSvrCJth9/bxfRWMQn4oxMkDpysevoMaY"
            @"QmMUYbNOBZpl2BAzrHi5sjF2qBb2gYeqzVSoYeNlJ+fMh0Zxum0+Biiw1T30TDa3uP6XfZ2044ePlt0kjpPHWR1793yJ1vbtHtpRiUVmxpRyFE"
            @"L3ViBr2IeCVi6VeeZvzDbbbePmLnrGBvWHA4KjnJSsZlQJsKVRxKrx3zkRcupFeu9G90+90br76+zTfe3Pl/GCN973TYMAKYndr5WMG5FXLTqj"
            @"xq0mG0oVUNC8xsrFzueccVup+jN0NP2vStYU1apAnynIivXegrfjVrYZJLPewr3H3jyZRuPyVJLe2W0H7iIj47ppxMSS48C9lJ8J8MLLdA2WlF"
            @"aJrMRvnYyjAtRN6QhdU9ai+6YNkvzZmvtbuQeowFX2ZM9/YoTk6D4NVE1UCRagxLlVDaTsqoWObwa2+Takn/qTU+uDPljS/cod2NEfGkkaVduf"
            @"D2OxGDQUyrb+j/+WeQwzN2X9vncOI5HJUcZiWHefDwnpRK5jyFQlE4rl8e8Lmfeop8mnFy5shzjzHSt8iaM7IfqMSaPNYHRhfgBM6xNat80zDz"
            @"+Kj8M6qp35p5rWYcIcMgVvPrKpIZpa9CZpF1r3o6H5gpqREJLUQJZVNsIDbBMbYVGXpLKe2NNdxwF7EJ0u7gR1sYCcQAMQLtGE0qC4gKLjTNeQ"
            @"e1ME8qSaqx50YSztp9ISp4RawyPRmS7R1AXiAmGLCKd3PpqBFs5TCQRcvs/fEHpMWUzo1l9vKIV3/9TdqtqHL6MbRjSysRui1DrxcTJ0rnF56i"
            @"1YaHf7zN3qlj/6zgYOI4zUIdnCsUPiRbpQ+Y+O0Hx/z9f/ptytIzLvX1QsxtrME7HYbbwyeBe1dtctWkJpCHRq7mwZ6xapQ0B3IuXOehlZfXzJ"
            @"CarFedi0whcYRdVc1eSlXrJCDUyGIkNQYsEFmDtaG2jSNIY0M3VgbXVrH9iPLBMXRXMWaCFJXC3yjaiZFqgWf/k8pFTjXgwlGEsVFAmSSmzHIo"
            @"y6qpYebmsBBAfKtMD87IDo6qcG/wLpxeaQy3MgomVvL2GtsvbWJPhnSeGHDS7vCtf/w21kOcGlrG0EkMncqRtzeISWJP/MIVlp5fYed33mJrN2"
            @"N7mLFzlnE0LmeEgMIrZdBaUg8CLSpyfCl2y0fBgrEsdctp3dIMYsKAQmkumKRC1BMvoTkyHzdQcbxqwkBzOlvVVUlroXiYtlYxDTDpjAoLp4Ik"
            @"lQl3Xl36KV7x4k+9kUHAez2GsMhpFNFNI1YGEasvXMe6MUVREF1ag+lR1SN2QfeYKFiPjWLEJhibgonxROAiylzJhgX5sKQ8nTA5OWbtxat0e2"
            @"e42gtLak+sYJxVjKZke4dVNGjMbK7uMit2RkpwvVW2Xt7Fbx7Sv9Jhujbg6//0Jm5U0m7HREJY3NTSb0f0BhHdRIg2lrj4F59l+vYtdu+M2T7J"
            @"2BvmHE1KRnlJ5qqOVsXl8ijeS+aEfVVyp7rvvB7U9B6vOvSqQ+8DGyQoJKhwhnpwdzUKEal8ROYGPtG5dmF19CtOcDWZDOZeXAHWkrkvo68Ud6"
            @"F+6ys+UzVZlQU2nII8VoJyot8yXLi2TP+Za7jDNzHtPlG3hUw2kVYb025Dp4uYFNWELPMURyXFWUF+dMpk/4zp0Yj8bIpOMrwrcFmOHSxz6VPX"
            @"G7bOtdNeWGxRGO8dz1qjM8x25oVSsRy9R1ZX2Pz+GcX7O/QutJDra3z9X7zP+OEZ3UFCLEInNXRTQ68b01+JGXQMZqXLhb/1Aml8yMPXjjgYFh"
            @"yPS4ZTR15WC1vJY0sNqkfvBUdYYE9YUAdzj+tKyDDvcklez6lcZEqESMtimVyT63U+DLpy9Wmo1XM1kgVfapNgfD0wMxVPglG8ytAQ7uZam1zB"
            @"kpWdhMFK0PN2EmGpBSvPXMbEOcVoiE1XMIni/AXUReiZ4LYzisMd8uMR5dmUcjSlnGZhbpMJY/l6SYSmlrMJZOpY+vhHaA0s7jQHiarMPowNsN"
            @"aQH48gL4niYB2lLgzyDnvaY63FFyXxWo+9uyWn37/H0kpM+5k1vv57mxy8fUB3OcEC3STMsuj1IvqrMf3lhGiQsPqXn6e/kTH86gmn2zlnmecs"
            @"9xS+2nLqayAoMEDCr1OneuC87ivk3jN0zBQR+aw5ZSqHJm8SI76vopl4Exa/MUNolmpW5MUoTBad++CoSB7KEp82F3rG0qyptqYeOy95oAtVkB"
            @"cB/hKVpBqhGzROkdCJDcvtiLWlmPaT65TDLYwaZDwkv/ku5IpMM3BlMF1BabcF07UoHZzv4kplOnacHBccHGUMRyVPPt3DqWfw1CU0P61G52hl"
            @"dKMYI6jzFMfDoPHSgLiZhpOdiKCFJ+qmHO4Zdl++Q7dt6D2zymvf2OfO1x/QHaRYCQu81Ipotw29QUx/Kcb0LP1f+Ti9p0rc7oizWxOGE8c48x"
            @"SlQ0RIrWV1uc30aBQm0mgARJRKeyyk3jP0VG3LKokK4VrqzldSAxKiJp1NkMHO5lIYTOLRfN4MWRz7VJm2VRYR8xOeqSdRCZZN1XTUPDgI1BNO"
            @"NVWp/DWRSmmhJMbQjQzLrYhL/YSrSwmXn1mnvdHGnO4hSYwYoR1ToUfd4OrhhWLqOd3LONqecLiVsb815mB7zOFhxnjkGB1mPPmxVZ77WBeuXK"
            @"Z/pYObbkFF2515fxhDdnCKn5YhjPtZ7hHmL0o40aZtOc1abL50h9SXLH90nQ9ujXnz9++FEG0I3bq2pde3dHoR7W4E4ul+9nmWPhrhxidku46T"
            @"B2NGebCTQMNm7/XaPDgaU3g/Fx4FhkemhDnNnjCh1cNwNlmzanZ41eG8dVkTPHxW3cOZQq5Cbrz2RcjriBzVd5dIo8mA1NlyOu+FBn+skBiwb6"
            @"CvhiTMOWBYmb8kYe6l2YgjBt3UstSyrHdirvRinlxqce2pNus/u0GyrEwPPWdZxPh4QnZaMDrImRzljI9yzqpf41PHaBSmppWqAdauSpw4sbzw"
            @"qYsksWKuXCZOh+iZCyhUfS9Zg59mlMej2VCOmWFs7TboFYmELO6z+dJ94qJg/YVVdk+F7/2bW/R6cSA2xIZ+EgaV9PoRnUGCWEf7p55h9TMD/G"
            @"gH4pThe4cMT3JGU0dZhmdbOsfBcMhZXuIqVUftx+tFhqqaOXTfK8O6NKz9QWovzcZdmwajNskUCaR6GNYborLdmo0HjhYWuLZSRDGGfpPHq+Lz"
            @"eRlFXg/uMo2dFqigkhmj/ZYNrnTr3Zjnrg544ZkBG1c7LF1Laa+WOCd896UR739/BymEcn+EHxbglCgKw7dMFLSvthfR7VnyQsmqAVpF6Wmttb"
            @"n2TJfM5fQ2BlAeB5xYqvGyVb6RH52BcwGs8DMqMbNBWsZTDla597Ud5PiMtWeWOdaYr/7ztwPQ0LJ0Uhvu4XZEbzmit56GUunj11n9pWsw3Qvj"
            @"dw9KRneGlF4xTmkbxcXCyAbc2lQTAFyl7PBwOnffm6tUNNhBVIkYp1790CtDEVL1dZ2swftLgqWHD5VQ5dQ3L4mj5gI/as1Gc9pjgL4C3yp9ZO"
            @"R2pbgw0FevWWoNn/uZF3AHR/R6lonCe++fsHrPUtwfcfHzlp/4G58hTd7k7M275KZF2Y3QMlyS1gTTFUUYZY5poeTWExdQeBhnJdeeX6HddWSu"
            @"S7pq8MUIJJ5ZR9pIKM/GlGfTwPauwrTMvbJCubaywuZ3jykeHLKy0SNLU/7wH71NPsxZudihm4ZWZadl6Aws3bWEtCdEz2yw9isfwbhD1IHppo"
            @"w/2Ge8P0URLq+1ePojS0xzzw/eOGDslIlXJs4Ff7AwIjefQ4dks6zaB2jRK6fhzpa8fu4qms/ZH0LdqHqUWB8WyEa2IQCrnQMgAuMqL0wXnrl0"
            @"pLK7m9fXBM6XCcZige4jK1ZkpR3HK+U04+BoyPbuGTvbY0ZnJUVWQiak04yVjwhP/MJn4MQR7W6T2oSktkFKLZ12RK8d0W1bui0b7AwrH0tBeP"
            @"FXrtNtF0QXrzO4FkFxVkGOIWKjSrZ9HEwVVBY82sPd7InWBtx/Y8zpq5usXG6TbAz4o391i7OHU1rdmBi4sJTS7Rg63Yj2ICZtQ/TECiu//HFs"
            @"dAJZicQGX0YcfXWLyVFBOfX0V5SP/W//Kus3rjN87R32R3DW6FeXCiVypMrYqx472Kmmu7nQ8CBHxSmBFKDIWGGiSFZZPOeouErRFVV3slucni"
            @"sNA1Xq+RHnemAN0fbC8MZqKmrVfcnD7AiGDvZLQ/94mm+M7+2n/VYYR5uL4CuUL4kn9B4k9N/co7fyFs/8B59jM7aMvvUaRdmmLDxWPHEkmKja"
            @"mV5xpZA7YXqaMf3oKk98pE++d0T/2hpWT3BiZ8M1xFqy3TPcqAhyGNWKAVJ9EOeIVrps3i7Y/eY9lpZjOht9vvJbD9i/NaTfD4mWrbp1K6spUd"
            @"uSdsA+scTKL79AnB6h0ywkba0Wo/cn+P0xRjzLT3e48GNLHH/ve2x/ZxfvLf1YSOwc9vQaBPx19tz0xawy7nzulFtfk9W1qJKraCYmeIdUgsO5"
            @"J1vTW7Omu2qdjVXzAUU0UXw+F5+fMxEJDy03SL/S5fSN0newL07TXLlpIvPiuFBEyyqLDb6SnbHh4HjKhe2ceOuY5OnvsfE3X2QnUabffQOsxb"
            @"RT4n4b20ox7RbSaWN7baJ2FzU9CnYpjjaR3iqtFYPLRqgLMhoTgcsyyqPxQn9btKodvSNaanM4TNh5+T2WuhFrN5Z49au73H11j04/xqqSGksn"
            @"Nnj1xIOYblfQ1Tarv/IJ0qUROpqGDSQelRbZBzvEqy2e+KWPUzzc4f5Xd9i8fcrByLNzVrI9zJkU8xlBQemjufN64DSE6fqXU/YJ8tthZZyYzT"
            @"zJa6eHyqE4UK40ozFutwnKRAtWTlUWPQ/bOu+yhFo5mXe9guVfyPxCd8yJ2UdDVmGUfo72MXLDAFHuSCJDO3OMp57RSYZrRUCEf3CKWXmDS3/x"
            @"RYYfeZIo6RKtDJAoLJhJHCbVMHQLgCc5+sGXmNybkNy4jpFTtKjdKYMLbnE4Rp0PqJOfw5+iHptGDF2P+1/6gJ5R1p9d4d23R9x8ZZdudYLbcT"
            @"11NVCGXVHAap/Bn/0Y6XqGjiaV+5/ipYRpAmVBvBJz9NYOd752j629KTuTMgATo4KjqeO0GqBdOOrSKavVn6pyEBwZQtertkCercFsTmMzVwpK"
            @"EvWa67kp2LXWfI4nh3w7F/FJRa5PHpHK1NW1zsf01eqJ8PM0d4Z9gNLrpogkBu0XnnWnhmnmyGKLUbj+uSfoPXmZ/a89wEwd6YVjuh8b03vmSe"
            @"wgxp/exB2fhOkw4qFl0BhMr09ZFORbm3jTIr3QRbN9qMxJsYofe/Q0DyiWrxgltcQ4EqZpj1u/fw9zPGbtuWU2twte/eID0laEqRCybsvSbRn6"
            @"vYSlvsGkEe3PPk/3aok/G2EkQqvdbNIB2lol6qc8eOUht+6P2Tlz7J3lFfJUMswcw8IxcdSLfFoQJKiI4JzuO3Q/nOzwDMNMKJtWE6tDFzH0K/"
            @"IZI14kmxvyyAKBr47a0fnxrPVIuFpyuoC+z0XqKQ1udjWvMVEJRmEehl40QJPK0MN6kZVcuLTCciJEqeHsYMo3/+H3kVxp9yMuXeuw0Ysxa/cp"
            @"zwT/YITxEqi2LYs7BbNkiXsp+cEZxdEQ6a6R9ECzHIOtqDxCcRicBkQq++OKdmuMxw0G3H1pB7N/ysVnljmeWl759fcqiq+GSestQ69tGQwSlv"
            @"oRrfWEC3/9p+h/VNGzI8DgxWHaLXzeYvpAye+9xfEP93mwn7M5duwNA/vjOPOMSmXkIfdCEYjt+4XX207loPRsOq8HDg7CCQ6LXnUNU5WqyVFn"
            @"07XXmMwz8sd4+5wzNX+M+556zb0Q8EvRdO7AR9bAmoNUo56tLORG6Nd8o1liICZRB5fWW/zqX/sk3/yjd7mzdcTh792mnUYksWV5HAzPLhlQic"
            @"nfO8GMXTBRizz5/Qlx35J02ngfke3t4yY56fU1rJnMwBITCe7MwaQIMKRvIm4eWR1w/xvHuDvHXH56mWkr5Wv//Xt4p8SpCaBDbOilln4vZtC3"
            @"pGsRa/+rzzD4WIQO9xFjMamldBGjt8Ycf+8WR7cOGZ1kDKfwYD9j5ySbMT/OCs+48GSlJ/cho1Yli4xs5OPypk/MsAq3mZcAM9aLrUI+m8UnGh"
            @"QrVX1sVPqh+1WT+equgCwMjIHzU1e1MTfKa26MJJWNX1otXlJroYJ1YmCIGJHB3EekUlw0HIMU5azw/I//7BXc1BEnEaelp5U7Bi2LjRKK0hFd"
            @"aJPdHlI8CBPQLXC6O0Vzz/IzPXzmkDyi2DlAbUrrUh9Tbs5tmhyUh9MQm1zIXsWYYAG1MuDuD0YMX9tm9VoHt9zhpX/+HsOjjG4vJjVCJzH0Ww"
            @"F06PQM8Ypl5d//JIOPW9zJLoLFdGLyvYLTrzzg6OYhe3s5B6clDmFSeh6eZuyPck6mjlERlBATF9gfuQOnsp9P/c2f/MTVz1/eWPk7v/vHb//+"
            @"2OuXKrw4m2XR9dDsemQQ5GoIGHI9q1E1Ewmjg1RnJj0zUn3tqhI1DVN1xkauKJ5KbqRSRKgkRrRvTJiaGnxAzKAa/bMWinIdipDa4FCfqJq89L"
            @"pljaztDKeD00mgyMSuoBsbonYwZbFAfKGDLw3DH+5TOjBemJwUjE9yli+kaO4QYrJjT3l0RLS0TtLz+MkEozESGfK9CZq5oIfylWGM89jlDlu3"
            @"S06/s8nyhZTW1WW+8ut3Obh3RnepxoUtg3Z1By9FdC8krP3qT7D8Yoo/3avsIiwnPzzm+KUtjren7J0WHJwWnI1yLjx5kVanz867r3GmYVzfxG"
            @"kY4F16cg+5450SvyWxSd9+fyfrdFtpr9v6leOD0d9XIat717PGhgnsnJBhC7WPeNUNy4Ifih9WVK38vH11NVvv/JDswFIwzTrZhdNpDeuRkQ0r"
            @"rFtr1iJhI7HyfCzylC/KkAFGltKzGZIEg0dPnSfJ4IcgnxDRgVelFxnEQBIbeq2YpaWEyz9+ibO3jjjZychy5fQkZzJ29FLL2sUW5J7JJrA+xW"
            @"cZ6dMriB6jZbh0yklBeZpX79lXmmUlHqTsHRgOvnGXtbWE9tMrfPOPtnn4xgHdXoJVrQziwsSafs/Qu5iw/td+jqWPgz9+WInkLMPvHnDwlW2O"
            @"jwt2DyYcDgsOp56z3PHgzS1OMsfQC6PcMyk90zIUuiVCgb/t4EC95k714Hji/v7vfOW9V0xs+hjw3g9VTWBihtw2857hbEQxoGJqO8WszpeC2l"
            @"Lzmhhe247XyJpfIA00XLL9jHwXdMmhk6Vr1sh6YuS5NOLFbmx/ue3dYCmFn/jck2jU4gtf/mB/bHVYOL098xypjGFKZct4BrYC16wIlwYpT67E"
            @"3Pj0RTql5+jukLOpsvNwzCRzKIHcJvfH7Nw/5eqfuUgnPUajhNZagsmPULGoQHGcz/26JdgbSzfieBKz/dJdBi3oPbXMqy8fcOtbO7R7CcZAO7"
            @"EMWpalXsSga+leSFn7Kz9H/+Mx7vguYiLKkefolV2GbxxxeFwyPJmycn2dyc6Io5t77OeO4aRgXCiZC1NjM6dkPuDIuWfTedkPZADZd+i+M+Yg"
            @"bstTReHuhLtVgr5YTXU/B8Bh5vhQlVFhkrxUDsUh8qpviAUaOZhW5ISZPpmGsl1rzVHlnm7RdSusJ0ae68Tyi0viP38pLvjMZ57hZ//sx6GY8h"
            @"u/8QZO3b5T2XcaSgCj0sdQz0vIIXSQosjQTSM+/lSHT/7pSyx98lmGL9+k8MLezoiRs8SDDtv3D0kSwzRXNi6mJJf6FIdbmEGfqFXgxhlRnFCe"
            @"FTCurRcBp5hYmNBm88sPSIuS3o0VXv/OIW+9tEWrG2MkSHR6LcugG7PSt/Svdrn0N3+a3gtCeXQHMRHjhxkHX9zi7MGUw1HJ8XFGb6nDM3/ps7"
            @"z79/+Qw0nBqVNGpTIpfXX3BpJ8oZA7NkuvW96HieYO9gPqFBIsNZKpJ/MqIdki0HkEScOiV1oolXoUYSVok5mX2eP+0TkLuZl41aegIpwLwX/L"
            @"B2Ptdmw/17P+Vy8a9/yf+sxT/PKv/SmWVjt85Te+wR988S3unBanE2++nnu9OWu4i+SK5KKaGvV9tSazRtI0sqy2Iq49u8yNX/sv8OUB2atvMR"
            @"47HuxOOC2FzI/w04KlbsRyy9JZ75P2U0b3J7SeuRq8swCXOcqjfI4oCQE2THtsfW2beDhl5dklPnhvxA/+YDPIS8UHtWFq6HdjllqG3uUeV/7O"
            @"T9P7qMOfbGGThOmtMbu/u8X+5pjDs5LjUcnoeMLg6au8/dJbvPPGJkMvDCeOiXOzxS19sGYqvGyWqlsODhy675DQ1dLwy1GxQZQ8L/WmEekbS7"
            @"92EBAkVVN1uirmjlZY9CNDYXQekn3d2qxQr8jXLjk0TNtq/0xIooiNdhJ9boni731io7/+a//hn+WFTz/La1//Af/4//UN3tsaMTSWMfal0utW"
            @"/QHq6TyimlTkszygVJ52bFhJPd0Ll5H2U5y8/Ac8vDXhnTtD9saO0bTEOU8aW5x6xDu615bQ6SkYS2u1hWQnGLEUJ3mwyolq13kou33uf20Xds"
            @"9Y/cgy27sl3/29+yStMG4vjSydtmG5n7DaNgye6HP57/4CnWcnlPu7SJRQ7hVk3z9iuD1l57Rg/zjjZOQYjx39rSPuPbjNvhPOchfCc6FMfXDe"
            @"cx4Kx2bh9U7pdMuh+0hITL2aoWogCKgPNa7z7D91cem1k3H+T47H038QLC81UwnMkJl1ZbO3/biBMHVFUw0zrRl2UVAdzEJ6+GZj6k4H1pj12O"
            @"mNz//MM+u/9nd/ga17e/y//0//lHfvHHBEzFii29PMfzdXfccpB6o+q8uuuZsQ/djIU4kV+mnMpVR4Yr2LmZzxxj/6z3nwjfe4v+3YPskZTUsy"
            @"p8EaObbExtDrxyxdWyM/OsEs9TE2gzzHO8FnQcbvITQ7lla5/fIeev+Iix9ZZu/Y88q/vROAhgjSyNBtW1YHCet9y+DagMt/++dpXR9R7m1jJG"
            @"b02hGTt4fsP5xy7zBj9yTn8Kzk5Kwkiiwnw5K3H5xw5qmSrIpe64UydLNul6pbRaG3e93Wr3p1w9NJ8T94ZFh4f2fGBlX2FckFUqccWCPrFXYf"
            @"2B666M0lIo9d3MWVltkgt2psZehdz/01ay1YrQFSnPh9NWS7xxP+wX/zu7z73g55FJMTb2al/2HhuV14bnskpP9iwomVYAdVT46JrdzoxIbLHc"
            @"Mv/fmP8fynn+KtL77O5t1DiFJ2TnKOJyXTqr41hjDEI4b+pT6ttS6j2w/oPH0NU56FUD0q5leMc8iFi9z79imTt3e49MwS+6fKV/+nO2ipRGkY"
            @"9NlpWZYHMStdQ/9al0t/5zOkl47wBweQG3a/sc32a8ccHRfsHmYcTRxHo4KzqeN0UvDE5S6bB6OqBw3TwpN5R6lQeLLcczPcrZKV3m+trnQHz9"
            @"y4PPjCS29seSNDr3paj8oNC0kmluTBwcmfFySxhjUvZog2HYY1fww+tDDMTRdMrGfMzYYVcu0xKjW7MvCOvDAsnW6NVP7gKz/c+qGBvk2jNT9x"
            @"w8AHrmGyAGw3LBrTKoNeEwkj7pHgFvMXfvFZnv3Ms7z8e9/n5ts7tNtt2kbYPyvINbAloobv9aAlrD9/FV9muFKJOgk+PwuTqaY+CNCLEllb49"
            @"5bOaNX73DxyR5jH/Hyr9+hnJQkrTB9rZsaBr2YlVRYvrHClb/9CdKVQ/zhGeWJ8vDL2zx445j9ccnBWcHJuGScBwvEwoXGSqdn2XpwhoqloKzC"
            @"YshwS6dbdbfKKfsmlv7tzcP/amt3+KJEJvHOD6txRMGaSWeTXnNrzdriPHpdQP90IVQvGtHrnAaDby531ZSKROaU3Dp5acqTnbI/Uf/1SMyGCI"
            @"lOaxpQBXEp2QyjDULutPINCa1O6FtYW2+Z9BefWeNk84T/7v/225yMS1xksUdFKKoqAxYRJSYYuPVSy4X1hNVnL+KH+5huBxMV+IlDx2Voq7sS"
            @"s9xh827JySvvs3alQxGnfP3X75KPClrdKuR3Qha9lCpLz61z9e/9LEl7F7d/yvhhyf2v7LJ1a8TOWR4WOHOM84AYOQ1sz8vLKT/xp1/k5j/7Kk"
            @"XpAoeaMD01V92vie9edeg8+w4OQDjLit8KSNPsAAy9Vhl23avWwPYIL+UzJaB+tQyVc27Giyd7Tqxunuj6xEemIjyZmlgutYOS5kjojRoVCuV2"
            @"DU5U3iDpDLwQRdQkQUzlZ+SC2uS8n5jPPLPUZusk45t3j8gIhuBSFMHvsho1Zy20Ihu0UrFh0LZcvL5Cb73L6Xu3aF1Yw7gMPykrKo9HOikPNz"
            @"0HX/mA1dUY327xtd+8z+gwo9UJE1G7LcvSUspKH1ZeuMz1/+DHiVu7+O0jjt4Zc+vlA7YfTtgb5hxMSk6mJeNSKb3iNPC8l6zn83/hBU6znKOz"
            @"KUVA2sKvkFFXZRIHHjmteFaZqs8RQUPreljJSwO1Bx0i1cQ2Kv3SedeA2h3hHL7wyAmX0K80NA6qD87A0aygblzFNWLlveZV12QYZDNzRCoA17"
            @"ULkCQBNdG0mh2VCKwb6Hcj8yv9NOLBKKc49RWZPDjXxpXNk0GwRkmrJoYRSCOhFyvLT11A3QgRJVlqwegIU4ZgZnst9veEnS/dZWkQ4bodvvLb"
            @"9zndHdPrxyQ2oEn9pYSVLqz/2FWe+Js/ThQ9xG+dsfW9Ie+9ssvuQTi9R+OS08wxco7CVeoGga53vPjZp7n+qY/yj/+v/4aiMpBxCqWHUmXTqw"
            @"6d6n59Op3Kfo0JK5o7ZT9wuDTMdJrdkwYn/mAulJfZ7IjgT3aOevdYOl4YdTTjztfrKbX7T3WfqMgjMk9tzKKoQesZgQCTiIaFD7RQ8OKHRqVv"
            @"lL5XTiPDhhH6p5ljVCx6TxsNd64FYpmbrRmC31fHGpZ6Ma0rS/jhEbQ7mFjgrAQVbBpzOk7Y/+pdVpcs0fqAP/rNe+w/OGNpOSaOhF47YmkQs9"
            @"SC1U88yRO/9nEi2cQ9OOPBd054/9uH7BzlHA7DAh9lJaMi1Lu+OkpiLGni+djnXmT9+U+zsvb72IdTUCiDaO209Gw51f3636GxUYH+DTVoTfOp"
            @"LBPzYAI/i55ZNQh7sRyiMdy0MXnPV12SAO/rY9df6xxrgVX0uHnJpkaSqmky9QaQYEERyOB+qOIzUZnBklZYd579ce5eGub+66PCb04KPc1KTp"
            @"0Xet0WpfcULgyspJKktqJgNbHcMqxc6JIsp0yPjokGPaTM8B5Mahn7lP2Xt1juQufKCi//4Rb7d07o9RNiY2i3LP1BxHJPufSzz3Dj736GSDYp"
            @"bp+w+coR73/vkN2jjP3TgsNxyXHmOCs800oQXmoY3SmimCjljd/4Q2KmPPPJjyNFhlehVE/p2Cq9bgU7pjCjqeZOz58Pp6o+m3lxhecXpppXtX"
            @"BY4Pkc69rYtp63+LhSaQ4tUllQMkOevM4d+yNXmZrWPGQVFsYf19PvavZgGCKySB6oSYBC5RhUZYaFcsc7hlb9euHkdiRsRIaNVmwHq8t97m5O"
            @"A+8rDlKWJIloRYblTsxKx7L05CreZbjSE3cjyE6wrYhJmbD71W06riC9uMSXvrDFg7eP6A9Skhh63YiVpZT1JeHKLzzHlb/0AuXxO/gHIx5+55"
            @"R3f3jEzlHO7lHG0bScAQpF6XGVV7apnO1bsSVxBU986tPce+0u73zzh5C0KEcFzkNoWYaM2osMK8uKfm02PpO51PaIplaHks7u4IqiNM+Wa+K/"
            @"Ls681vlhrMGH2XVb+4tUzS3PXLgYCRrs95FqIvpjLoEGO6QWN4ekqhqpW5G7qwCfemHoPadqgnjdqwxVNMMEO+VpUZ7evLuTRtakkZWKDBcK6o"
            @"0rA3q4MBfq2ip+NETaLawJU1OnmvLwy9ukWU5yeZkvfWGTO28cMliOSWOh141YW05ZHSgbf/qjXPnLH8UdvIu/N2L3nTE3Xz9ia3/K7mnB/lnO"
            @"qPRBfFb1h4xoEKCbME11gOMX/spPs/TEOr/z9/8Vtx+OGLvQ3QqsjnBya4ZGuJN1VlrWo/XC6Z55Uee1OjQIyisLCM9Cz+IRqL+ulLS+c5vuIP"
            @"Xk3MXcKrj/VOSnmYJV54f+0dEF8zg+08gKSfA3r2Sv1SuXKlvG0zei/Wp4WAC9kdzD0BpJjQQH+pnvtYV2HBGVnqiXkq4vkz+8RXRxmUhyijhl"
            @"5ysHxNMp7adW+crv7vDea3ssr6SksWGpF7G6lLC+Ilz5lc9y6Vcu4w7ewW2X7Hz3lLe+f8jWUc7eWc7huGSUB6QIhVZsacU2KB8MxLGl4xw/9x"
            @"d/gt5Km9/+B19gc+TZH5cMs5LCQ+H1jkdPnbLvlIMANPhh5aCX1QscdGOSBjNyhjUBozkYpDlwbd7ZaqgX5sd7Bj5Iw61r7rknDZSp7njVwnMh"
            @"WBMqj5xk7/3stJ0jfM4Ld9FA/quU7krQ2ta6Ha8yVE/uRYdO5cCqrkdOeepSH4MGNqQa9naO6a8k9DZWMbFHfUk6iDEtOPrGCfHxmN5Ty3zjy3"
            @"u8/d0tBkspkYFex3JhOeHSBcOVX/05Vj9/g3LvVYrNkq0flrzzrX02hwX7Z8F1Z1Rq1coAYwLtZ2MpwUpw5tOi5GN/6nl6F/t88Z9/na2R5zBz"
            @"HE+Dz0fh2C+9bjnPgYOD2Qmu3PNqaHB+91UnuNG9CgPHK+brghGAsGiHqfO5z6rh1Ne1sMos0GqjqSUNa6yo/mJTO/5L01ZiZgJcid2k1hHN7m"
            @"Dxms7sJiqrhxk3yejczFPmFEIj0hfV9KmNAX/655/jla++S6kFeemDh5UqnWtr6NkJ0kowSy2OXt3HbA3pXevz7a8f8sOXH7K8FE5wt21Z68dc"
            @"WI+4+mu/wNJPr1NufYv8/Sl3Xj7gndeO2BmWHIxzhoWjVMFYweRKNzYs9RIuLSd84pPrXLy+ynj3ANcaoN0ef/QvvsnmacFB5jjJHeNCmTg2c6"
            @"c3na8kLVrNz6q40B5OvTAkGNPms+wZsqY1R+XPkoSNoY1WpT6CIGrzxNYj7Bc8UZgPNzt3TqP54NT5os4ChWehEzZzSxJyEzLAxAn7VlmvHeSY"
            @"D7jsV/d2OpsWB0lkZCNGb7QkDMV66SvvMBrldFvBYc8IxJ2U9pUl8sMHmAt9hm8e4N4/ZvBEn2+/csirX95isBTPFvhCL+LSpZirf+NPsfRTS5"
            @"SbP2D69oRbX93n7ZsnbJ8EztVZEer0tinpGrjw/Bo//tmn8GcFnW6Lpz91jSuf/5u4cpX9b/4Lvvj//LccTpUzr5yVnpHzTB2bmdcfFp7bDtmv"
            @"u1QO3a+vsHpswNw9T7PAXpW5UwCSqfi8OQ2vtqSeJ8Z6brxpfdDn/ma+dm3S5n2+2AINIvQKXpwdOJ0P/aq/SZqpXxjUk4uafCEVrwCJmdxyZo"
            @"oufSP0I9GrLfTFZy8O6C8PePeDTVppRDsKo26tNSQGBleXaXUhPyzwD4ewe0bv+hLffeWQ7/zhJr1+QicRer2EC13DlSe7PPG3/jxLL0L54HVO"
            @"fzDm3a8dcOvuGdsnOYfDnNGkQNKIj1zv86lffJG4FfPw7du89+oWBw+PWUpiTr5/m+mDIVd/4c+x+/IP2D6YclwEQvwkoEtZqaGzVSeU3usw8K"
            @"1Ca9KrDis327ym1tbEvEWaleaEmjjXBWChybmTqiFWKSeq0Gxmh11mGuuauCcLk+krO4naRBRZaKDMR+M2EoF50zvcBV78UFQSFcnqaeeBYRgU"
            @"FLXKIpics9GJ7S8uW8fPf+4jvPnudjDtVsido+UrBZ4ogydWkHKK5g6TO9obfb7zyhHf/t379LoRrUTo9xIu9A2Xn13mxn/8y3SfLSk+eJO9V4"
            @"a89Y09bm9NODjJOZs6klbKyvXL3Ptgk8GlJSRNeO0bH/D6q7c5yzzEhm4UOGXD//mbXPzqd9k+Fe6deQ7GBadZwaSAzOnrpQ+zmRzse6+VK0AF"
            @"6FRIXC0/rdOXxuS72okhnwlrlYVR1LrAAVBcXfnUUxe0GbwfB17Mp9nXs1giP+9rzQCCJkDRtNWdX/eNeUuV9NLM7tzgQiNGU5HgmW0t62lsXu"
            @"xa0o89c4H1K0vc/cJrGBtRuOAM5F1wBogiw8q1NcphGGiZXmzzjS/v853fuEu/Fwc2Ry/mQke4/MwKT/+v/zzdJ07IfniTzS8d89YPjrh/kHE8"
            @"ypl6w+FoylKSoFnBMFe+/PJdXvrSe4zLgPGVXvHTklgMJ1PHw0lCZz9Elv1xzsm0ZJIp1VS1g8Lp7RK2ajlLwIRDuJ61K0MHMavD9uLizhsZs5"
            @"VbbGrNnq9nfqBC29IjKjh5tMaqg69/DNwc1afXqy7YP81OayByz30mw65tvLCCSCXA0rT2wQrySu2LkdQqa+1IPtPWgp/86ed58P4uk7xEkgTv"
            @"XJjXVUWU3nqf/mqEDkekKx2++oVtXv2d+wwGYYEH3ZgLXcPl59Z48j/9ZTobh4y/eZM7Xzrm7bdP2DzO2DvJOSscaafD0Cm7D0/I7u5jkjiQ27"
            @"EUXsmdI/ilK2IcZ6XjOHO0bEjMzvKKGO8Jw7c8t0tlK5AjQjk0z6wD+yXcwzoTpREwgOFMjdLoS1fihRApfcOVuF4sqdVd1ETpWatyYWjbh7jz"
            @"zVCoeRI2T8Wl6o0arefWngekG52Y6pU8ZmhrkXSgGQ+Noe+9DiMrV6O84Cc+eZ2f/rOf47/+P/x/kCgKrTeZ909d4elcXKbTKSE3vPR727z6hf"
            @"usDRI6aaDrXOjDpRev8NR/+mdor+wwfOkmt750zNu3hjw4ytg7DX5ZZ3nJ5GBKoYG14YylzGt4sPLPCrMNw1XjhUyUzDliG4Z8+Gr0vEeGJbJV"
            @"wlYlQMuCFEhmQENDNZLPH1Qld5Fa/T9PjHRBr6TnKDwLQFDVxZonWefD+vlOWdMJmabgrRmia+DZy3wEz/kxBgvLHn54WFgNxjHhVSS3wlpiea"
            @"7TjvHjEQ++9yY//Us/x/v/wxdxPmwWS2gp0o4Z3tsjy57g9e+c8p2vbLF+pUtfYKUbc2VZuPSZ61z9j36eON7k6Lfe5d0vH/H2vSFbw4y904Kj"
            @"Sckwd0xdkCDkXqsFDf5Zha9hvko9WN+d1WfOrbkRO7deOzCUKpuF97edsj8jSaDDuiQKGbUJvWghE4LlkkCiXpuEvFz8owvwOFTJqdKEi0wDWW"
            @"KmjGhOkK2TLpqd09ldH3mVBS6CNkxulYZpnT9nWdmYYdM0Wq2TLhWT17Qfa82aRJabO2fc/0e/x9KFNbwVimkZeGSEYdE4S4pSfrDP05+6yjRp"
            @"c/jtLS6hXFmLuPgzz3D5b/0kMvyAvV+/zTvfOOHtB6c8PMk4mpQcjUtGhWdUeqa+4l2FUXj4IEcKKBEMVTSvxtEG07MQ9oaF93ciIxtGtC8iif"
            @"c6LD2h6eH1wIueqidXTOY8B7MRAZUQXyH3TocaJuIlAa4NoxuaIxPnflvnabQyw4rqUklrx735gapeQx9rAuK1YVS8QMmVeVre3G7S2BHnFay+"
            @"ulNm6IlW6EplxRiGhpm+h+FpVpIZ4cRYPrizizfBdsAG4SIta+hEhmsfv0i+P2GQwud/dYP9n7rM6JUHrD1zkYt/9dO4B6/x8LfvcvP1Ie8/HH"
            @"H/aMrhWcm48MRpi/FkzMgFi6IK7913nn2vOiw18J9rdKjepDWXuZaeWMO6qCbWyLqIpk5lfzYE08s8ow4zmkKzQ4NZi/M6vH5x+Y/z0t18eHD2"
            @"nxkjYaC3ykLWfM7QdEYjqgkATqlsnxsT7eq4qgsda2DRQVLOncVokTckc/DqnJ3woriZWTtwAab0Daf14AqKU93PnP6w9GyNRfqiPkUs4jWJjd"
            @"ywRtI0tnRiy5NPLrG+MWCyfUB8lJHe3ub6z15Ff+HPINIie+N73P31W7z9zoh7hxMeHufsjQJVJy+VmLLSAHsKz23nw6gdp3LgNDQr5hYNZlgT"
            @"H9QHlX4NIjjVAyPSL51uhRHBmofXYui9BCtEU3OwgiOh9zoUIXHOU3rdWur3/t79vdP/LLUmUTX5woTYOhQ37lKVc4Y80njq+hgL88e4IBthIW"
            @"wv6JNpXObSnDXc7G7+KBaoLqxzLpCLIRU0dchBVurr9YuFpggbkZWNCLNhkDSpVHMffXGdrpZMJyXpoEP65DLZcY7Ze5vp7RPufnmHt98fcWd/"
            @"ws5pzkGl/z2rVAvZeESpkuVeb4YQq/vh/tQZM7JG0QKOS6aeGizIa54VKkMvMyHZLGmpMuhQGvmq0SFSu+klXjWPrPBg+/g/9Bz/h7EF53zejJ"
            @"YzQKi+OKuxv1LdtWYBdjjXtqwetp+jk/WITZok27m6okKhaGRz8hgtcw1KzKJMo87yXhdO9qxvWrMXVId5oe/UVo1h0oxsYBQruu5Fh2J1EKuw"
            @"0rNcf25AazRi6WcuE1/rs/fGKeP3j5Gi5PCg5P0HZ9w+CLMbjsYFR7njrPRMHRQqp6UPAL7zehD6ykHvW4WymU9lbYLmZabvzebS0ID/Gh/mb1"
            @"S3Vz5jdKD5XJ80F4fX2LD3ionABpXnI8dNZwiRVLjvOSjxfCR/TCer/sfMW2MVz27RrkvmpuYyK4lmLeo5AXu2a6Qa9YoPnCwxDTP0c+GlFlQX"
            @"KrcRxSj9MLxT1wJsLP16kIYxQSR97cYK13/mMuVpwd67Q+7+9+9yvHmGSSweYeco48FJxt4oZNDHWZijNPEaVPueg2AhHBY3qDjmnQWHHtQa6h"
            @"oha3qBVjL1SmQmeSiPtAIY6hG3lc80ktcsj9DxC6yO5sAtfZxGae53NoMLH0m+zsEO+himppxPjpr36/w4z27P6HzzeyFON5ZxNhaA4IZjm7u0"
            @"bnvKrE2Xg+4HpIpqxnJNh5n3fUVII2tpCzz58Q223y159f/3OtvvHzHy4KpWTV4GHPdo6hhmJSe5Y1QoU6evl6pbIbGSYY3rzk6nasWj8tThup"
            @"7MEiqBamCWr7wpZX4ynep+uI/r5obmtbJ/TnqXeU/63GBqOce5qJ3lqyTtXDna7HxJs2Catz5l8bJtnvTzBnva9Ctr1sn19LRqJ5+7DaoHY+as"
            @"It+w9zovfq5OfV5bTVT3YjA990Gk7k3lsq4QtRPeePkO3/yttxhOS6Ym8KfqMmKcO05zZVy62p7hdOJ4pVTd9F4q8VjoPIXEymc1z6qekjZ/jj"
            @"IPsfWQjvDnDQSpvo4YqlQw4qzUNIlTPVhwZvA/IlepSx/VGdDQBPeNNGBEbVYuMh9VJOfpt/JoJfsjbEPmBqqNxkaTzC3nSX7VJtBmJv64l65G"
            @"9KpqHibHhUFWDvadsl5TWJ0368e547sfHAWdcUVW1zB4DwdMygD/5EG9vz8p9eu552ZNe51lzDU4IGFgVg1/1uVN+G/fdJLMKjnobCJLrcisTU"
            @"lFKyEBC3ytxuPQR8iPj5Sl2kiGGtfiDER4hEvNjxS2Pe4akEZ7ajZtteJ6VVqoajRtDSkG05CQ1jex5OqOBsX6RmGustjXFl3YYk44EEgssq5K"
            @"7nygr+Zebo4K/3zu8uoqWOzkSNVTD2Ju3bcSrY+L8qXc8U6h3Aku+cEtdu55VWG61TxD1eqEztT4shgiZ31AXcyeZyG/Ij3UrxGcjj7MaGeeOF"
            @"VlUXh8M5O1WhbzaELWiPHy+CExf6J/5nlVHSnOG8MsMD5lFopFWDi5M8uC2vmH+Q5duIv8HMQwWg+SJPFGhmWpW1P4rvNuPxK5atC+imT1OF9D"
            @"mHvh0WEgy8nQablfKLedclAL3b3WGXSQhiqV+/4cPslrvrhHh6IaRgxqEAzUfmW1XKU6DbXTbD4Lx7Iwd2eWFAXMVx9bZta9qRmUKI9QABZWRz"
            @"4swfoT/BPmTco5Ep/Mw7XqnLQ3/wGy8ALzIp4ZIuUJFk8qjyrqQijSxq4Ghz+oCWCqZOo0Kzy3LbqOCGI0LC7NyBEWrkpAsnohPQydl/3ZCdVq"
            @"3Hs9h8HPT161MA3V/pw2HGhLhvo1RTWpu1jNvGYu6l+UEj6WEl2H/nOVyrlBkcy9AD5k4f4XnWB55F4OVGpFZHYHP0o3Wei6NGu1amFFq+k9Mo"
            @"fC5izPRhTQ2Y4gMtI3SL86DxVrRPvBZTdop0SDUdw8bM7prrWVfy0amyVQUte0kjW4jPncPrJuWgQpz3mr5xrvVd9834/ekXKuUtGKgD9PjCWU"
            @"LtVBctXGsCILCdbi/S2zcP0n0iA/js/1CE2okaSFsXWP7huR84FFHwkg53MM0+jDLfDCZiehkshUhjFhsHZQXRjoi9HZn1dJW9asL2caLK9zWU"
            @"kt3akB+apbM5sU3nAXrKwtksr7auH76nxsXgrqY2Wij0uOmj2JZjRUzkuN9EO+Xx7Jnh9JupRHWF8iupAkz9gluvhZqkVeLMEXMUmtj/zj9TYs"
            @"uiQLTTLg7HRVpcJcv1OVBrV/Z1hopR96wtXiakXcb4w0arIrZhl11VGrtJlz+wW/2CsI0+rIFwGX2Qj5x/eEtflc9FExgyx0+PgQsuW5LPgxna"
            @"1zNfCPSuqa76fJjZdGTb4w3b4+yXPA2T8aRmjqcbTBET5/kmU2zlZoTE3DLD6gRufFyHwBZtIb0UafXpLad7sxhLJBpaFBUw3mojMXo8YdOpsi"
            @"8/jgNq9pG2C9NqbsPPIdCwwNCX2DZuvy3Pf4D0mklHNaJ/0TgAXN2ZrVgsoju2hu8yRzJKlp9aSPkWvoIzizmTetZxqcmstZ63NEOcdF1IUWHw"
            @"15pta6ZQlhvA7XTa7UI8yUOsPXRxUfP+puq71SjOjsFIt8+KJz/q5c4KiHelTCqIDFoCrymIvuXAvz33GKF9dAFv1DtIEtnCvSa4PzxiKfv2X1"
            @"kYU35jy9SBbRq8VgEsJJI3TJwiad333n770PE1rPP2CzNaiPPZkfFu4WSrzHPvxHX8OzyKiUmcB7nnSG+VrMZCwieh6vfWzZ86NKorpN/EjCJ4"
            @"smMeeTtfMva0XMPKlZeMGFZPxR85iakt94RdNot9Xf3URZTNPLQpulRL2A8u8u9BthuDYNRWVGlxE5d182F1TOJS8fFhmr96LVv32l4F98h/MQ"
            @"rSofWgwtYAd/go1XVzuL2qbmAfgTVc2Nny78/wGgc+b9uoToQgAAAABJRU5ErkJggg=="; break;
        default: return nil;
    }
    NSData *data = [[NSData alloc] initWithBase64EncodedString:encoded options:0];
    img = data ? [UIImage imageWithData:data] : nil;
    if (img) cache[key] = img;
    return img;
}

@interface Z6dcb301a04 : UIView
@property (nonatomic, strong) UIImageView *c6d9x4;
@property (nonatomic, strong) UILabel *n7q1v6;
@property (nonatomic, strong) UILabel *value;
@property (nonatomic, assign) NSInteger p4x9c3;
- (instancetype)initWithC7q3x9:(NSString *)imageName fallback:(NSString *)fallback color:(UIColor *)color index:(NSInteger)index;
@end

@implementation Z6dcb301a04
- (instancetype)initWithC7q3x9:(NSString *)imageName fallback:(NSString *)fallback color:(UIColor *)color index:(NSInteger)index {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.p4x9c3 = index;
    self.backgroundColor = [UIColor clearColor];
    self.clipsToBounds = YES;
    ApplyNeon(self, RGB(245, 169, 53), 10.0, 0.9);
    self.layer.shadowOpacity = 0.0;

    _c6d9x4 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _c6d9x4.contentMode = UIViewContentModeScaleAspectFit;
    NSInteger artSlot = (index == Z700020a485) ? 0 : (index == Z124338f2d8) ? 1 : (index == Z94881eb8d3) ? 2 : (index == Z646dcbe562) ? 3 : (index == Z2f0c1a9d77) ? 4 : (index == Z5d92a7e4c1) ? 5 : -1;
    _c6d9x4.image = OngnongCounterIconImage(index);
    _c6d9x4.layer.shadowColor = color.CGColor;
    _c6d9x4.layer.shadowOpacity = 0.0;
    _c6d9x4.layer.shadowRadius = 0.0;
    _c6d9x4.layer.shadowOffset = CGSizeZero;
    [self addSubview:_c6d9x4];

    _n7q1v6 = Label(fallback, 18.0, UIFontWeightHeavy, [UIColor whiteColor], NSTextAlignmentCenter);
    _n7q1v6.hidden = (_c6d9x4.image != nil);
    [self addSubview:_n7q1v6];

    _value = Label([NSString string], 1.0, UIFontWeightRegular, [UIColor clearColor], NSTextAlignmentCenter);
    _value.hidden = YES;
    [self addSubview:_value];
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat h = self.bounds.size.height;
    CGFloat w = self.bounds.size.width;
    CGFloat iconH = MAX(1.0, h - 2.0);
    CGFloat iconW = MAX(1.0, w - 2.0);
    if (self.p4x9c3 == Z87f6d0c11d) {
        iconH = MAX(1.0, h - 2.0);
        iconW = MAX(1.0, w - 2.0);
    }
    CGFloat iconX = (w - iconW) / 2.0;
    CGFloat iconY = (h - iconH) / 2.0;
    CGFloat zoom = 1.0;
    if (self.p4x9c3 == Z700020a485) zoom = 1.24;
    else if (self.p4x9c3 == Z124338f2d8) zoom = 1.24;
    else if (self.p4x9c3 == Z646dcbe562) zoom = 1.311;
    else if (self.p4x9c3 == Z2f0c1a9d77) zoom = 1.25;
    CGFloat scaledW = iconW * zoom;
    CGFloat scaledH = iconH * zoom;
    if (ZLegacyCounterSelected()) {
        scaledH = MIN(MAX(1.0, h - 4.0), 26.0);
        scaledW = MIN(MAX(1.0, w - 6.0), 28.0);
        if (self.p4x9c3 == Z87f6d0c11d) {
            scaledH = MIN(MAX(1.0, h - 1.0), 29.0);
            scaledW = MIN(MAX(1.0, w - 2.0), 32.0);
        } else if (self.p4x9c3 == Z5d92a7e4c1) {
            scaledH = MIN(MAX(1.0, h - 1.0), 30.0);
            scaledW = MIN(MAX(1.0, w - 1.0), 31.0);
        }
    }
    _c6d9x4.frame = CGRectMake((w - scaledW) * 0.5, (h - scaledH) * 0.5 + (!ZLegacyCounterSelected() && self.p4x9c3 == Z646dcbe562 ? 3.0 : 0.0), scaledW, scaledH);
    CAShapeLayer *tightBorder = nil;
    for (CALayer *layer in self.layer.sublayers) {
        if ([layer.name isEqualToString:@"counter_tight_icon_border"]) {
            tightBorder = (CAShapeLayer *)layer;
            break;
        }
    }
    if (!tightBorder) {
        tightBorder = [CAShapeLayer layer];
        tightBorder.name = @"counter_tight_icon_border";
        tightBorder.fillColor = [UIColor clearColor].CGColor;
        tightBorder.strokeColor = RGB(245, 169, 53).CGColor;
        tightBorder.lineWidth = 0.9;
        [self.layer addSublayer:tightBorder];
    }
    BOOL tight = ZLegacyCounterSelected();
    self.layer.borderWidth = tight ? 0.0 : 0.9;
    tightBorder.hidden = !tight;
    if (tight) {
        CGFloat borderW = MIN(w - 4.0, MAX(34.0, scaledW + 9.0));
        CGFloat borderH = MIN(h - 4.0, MAX(35.0, scaledH + 9.0));
        CGRect borderRect = CGRectMake((w - borderW) * 0.5, (h - borderH) * 0.5, borderW, borderH);
        tightBorder.frame = self.bounds;
        tightBorder.path = [UIBezierPath bezierPathWithRoundedRect:borderRect cornerRadius:7.0].CGPath;
    }

    _n7q1v6.frame = CGRectMake(0, iconY, w, iconH);
    _n7q1v6.font = [UIFont systemFontOfSize:18.0 weight:UIFontWeightHeavy];

    _value.hidden = YES;
    _value.frame = CGRectZero;
}
@end

@interface Zc1dba0f365 : UIView
@property (nonatomic, strong) UILabel *y8m2d7;
@property (nonatomic, strong) UIView *k5q1n9;
@property (nonatomic, strong) NSArray<UILabel *> *a3v6p8;
@property (nonatomic, assign) NSInteger p4x9c3;
- (instancetype)initWithD2n6k4:(UIColor *)color index:(NSInteger)index;
@end

@implementation Zc1dba0f365
- (instancetype)initWithD2n6k4:(UIColor *)color index:(NSInteger)index {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.p4x9c3 = index;
    self.clipsToBounds = YES;

    _y8m2d7 = Label(qsec_s_0029(), 13.2, UIFontWeightBlack, ZThemeGapYellow(), NSTextAlignmentCenter);
    _y8m2d7.font = [UIFont monospacedDigitSystemFontOfSize:13.2 weight:UIFontWeightBlack];
    _y8m2d7.adjustsFontSizeToFitWidth = YES;
    _y8m2d7.minimumScaleFactor = 0.30;
    _y8m2d7.clipsToBounds = YES;
    [self addSubview:_y8m2d7];

    _k5q1n9 = [[UIView alloc] initWithFrame:CGRectZero];
    _k5q1n9.backgroundColor = [UIColor clearColor];
    _k5q1n9.clipsToBounds = YES;
    _k5q1n9.userInteractionEnabled = NO;
    [self addSubview:_k5q1n9];

    NSMutableArray<UILabel *> *rows = [NSMutableArray array];
    for (NSInteger i = 0; i < ZHistoryVisibleRows; i++) {
        UILabel *row = Label([NSString string], 11.0, UIFontWeightHeavy, ZThemeHisWhite(), NSTextAlignmentCenter);
        row.font = [UIFont monospacedDigitSystemFontOfSize:11.0 weight:UIFontWeightHeavy];
        row.adjustsFontSizeToFitWidth = YES;
        row.minimumScaleFactor = 0.30;
        row.clipsToBounds = YES;
        row.layer.shadowColor = [UIColor clearColor].CGColor;
        row.layer.shadowOpacity = 0.0;
        row.layer.shadowRadius = 0.0;
        row.layer.shadowOffset = CGSizeZero;
        row.hidden = YES;
        [_k5q1n9 addSubview:row];
        [rows addObject:row];
    }
    _a3v6p8 = rows;

    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat gapH = MIN(25.0, MAX(21.0, self.bounds.size.width * 0.23));
    CGFloat rowH = 15.5;
    _y8m2d7.frame = CGRectMake(0.5, 0.0, MAX(0.0, self.bounds.size.width - 1.0), gapH);
    Z3218ec4b5a(_y8m2d7, _y8m2d7.text, 14.0, 8.0, UIFontWeightBlack);
    CGFloat historyY = gapH + 1.0;
    CGFloat historyH = MAX(0.0, self.bounds.size.height - historyY);
    _k5q1n9.frame = CGRectMake(0.0, historyY, self.bounds.size.width, historyH);
    CGFloat y = 0.0;
    for (UILabel *row in _a3v6p8) {
        row.frame = CGRectMake(0.5, y, MAX(0.0, self.bounds.size.width - 1.0), rowH);
        Z3218ec4b5a(row, row.text, 11.0, 6.0, UIFontWeightHeavy);
        y += rowH;
    }
}
@end

@interface Za540ef69c7 : UIView
@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UIButton *r6q2p8;
@property (nonatomic, strong) UIButton *k3v9d4;
@property (nonatomic, strong) NSArray<Zcb66126fa3 *> *a7m1c5;
@property (nonatomic, strong) UIView *onMenuScroll;
@property (nonatomic, assign) BOOL onThirdLayout;
@property (nonatomic, strong) UIButton *x8p4n2;
@property (nonatomic, assign) CGPoint x3q8c6;
- (void)e4p7n1:(NSString *)code;
@end

@interface Z4c5163ab2a : UIView
@property (nonatomic, assign) CGPoint x3q8c6;
@property (nonatomic, strong) Zf721fd429b *d5q9v3;
@property (nonatomic, strong) Zf721fd429b *t2m7k6;
@property (nonatomic, strong) Zf721fd429b *c8x1p4;
@property (nonatomic, strong) Z73b2f81c4a *r3n9d5;
@property (nonatomic, strong) Zf721fd429b *v6q2m8;
@property (nonatomic, strong) Zf721fd429b *k4p7c1;
@property (nonatomic, strong) UIButton *q4n8p2;
@property (nonatomic, assign) BOOL q6m2v8;
@property (nonatomic, assign) BOOL a1v8m3;
@property (nonatomic, strong) UIView *u2p7k4;
@property (nonatomic, strong) UIButton *m6q1d8;
@property (nonatomic, strong) UIButton *h3c9v5;
@property (nonatomic, strong) UIButton *g8n2x6;
@property (nonatomic, strong) UIView *z7h4p1;
@property (nonatomic, strong) UIImageView *x2c8m5;
@property (nonatomic, strong) UILabel *p9v3k7;
@property (nonatomic, strong) UIButton *r4n6d2;
- (void)setQ6m2v8:(BOOL)collapsed;
- (void)setA1v8m3:(BOOL)enabled;
@end

@interface Z1c94f803b6 : UIView <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIButton *k3v9d4;
@property (nonatomic, strong) UIButton *eyeButton;
@property (nonatomic, strong) UIView *eyePalette;
@property (nonatomic, assign) CGPoint eyePaletteDragOrigin;
@property (nonatomic, assign) NSUInteger eyeVisibleBits;
@property (nonatomic, assign) CGFloat eyeFullWidth;
@property (nonatomic, strong) UIButton *legacySwitchButton;
@property (nonatomic, assign) NSInteger r2c7m4;
@property (nonatomic, strong) NSArray<Z6dcb301a04 *> *t6m1v8;
@property (nonatomic, strong) UIView *d9q3x5;
@property (nonatomic, strong) NSArray<Zc1dba0f365 *> *p7k4n2;
@property (nonatomic, assign) CGPoint x3q8c6;
@property (nonatomic, assign) CGRect h9m2d5;
@property (nonatomic, assign) NSInteger v4p7k1;
@property (nonatomic, assign) BOOL c8n3q6;
@property (nonatomic, strong) UILabel *y1m5x9;
- (void)n4q9c1;
@end

@interface Zd4f227a905 : UIView <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *h8m3x6;
@property (nonatomic, strong) UIButton *d2q9v5;
@property (nonatomic, strong) UIView *zAutoStopThumb;
@property (nonatomic, strong) UIView *p7n1c4;
@property (nonatomic, strong) NSArray<UIButton *> *y5m8k2;
@property (nonatomic, strong) UIView *r9q3d6;
@property (nonatomic, strong) UIImageView *x1v7p4;
@property (nonatomic, strong) UILabel *c6m2n8;
@property (nonatomic, assign) NSInteger t4q9k5;
@property (nonatomic, assign) NSInteger a8p3v1;
@property (nonatomic, assign) NSInteger d7m2x6;
@property (nonatomic, assign) BOOL h5q1c9;
@property (nonatomic, assign) BOOL v3n8p4;
@property (nonatomic, assign) BOOL k9m2d7;
@property (nonatomic, assign) BOOL q6r1m8;
@property (nonatomic, assign) BOOL z7c4p1;
@property (nonatomic, assign) NSInteger z2m6q8;
@property (nonatomic, assign) NSInteger z8n4c2;
@property (nonatomic, assign) NSInteger p6f3a9;
@property (nonatomic, assign) CGPoint x3q8c6;
- (void)k9m2c8:(BOOL)animated;
- (void)zAutoStopRefreshToggle;
- (void)r8p3d7;
- (void)a9m3c6;
- (NSInteger)zAutoStopMasterCount;
- (void)zAutoStopSyncFromMaster;
- (NSInteger)zAutoStopCycleProgress;
- (void)zAutoStopSetBaseToCurrent;
@end

@implementation Zd4f227a905

- (NSArray<NSNumber *> *)t8m2d5 {
    return Ongnong::Z76e4c1b909();
}

- (int)q4p9x1:(NSInteger)slot {
    return Ongnong::Z76d01f2a88(slot);
}

- (NSInteger)zAutoStopMasterCount {
    int idx = [self q4p9x1:self.t4q9k5];
    if (idx < 0 || idx >= Za94c0d401a) return 0;
    return zce119e8048.zc9f4191bf8[idx];
}

- (void)zAutoStopSyncFromMaster {
    self.a8p3v1 = [self zAutoStopMasterCount];
}

- (NSInteger)zAutoStopCycleProgress {
    NSInteger current = [self zAutoStopMasterCount];
    if (current < self.p6f3a9) {
        self.z2m6q8 = current;
        self.z8n4c2 = 0;
    }
    self.p6f3a9 = current;
    return self.z8n4c2 + MAX((NSInteger)0, current - self.z2m6q8);
}

- (void)zAutoStopSetBaseToCurrent {
    [self zAutoStopSyncFromMaster];
    self.z2m6q8 = self.a8p3v1;
    self.p6f3a9 = self.a8p3v1;
    self.z8n4c2 = 0;
    [[NSUserDefaults standardUserDefaults] setInteger:self.z2m6q8 forKey:OX_NS("ot_base")];
}

- (UIImage *)v7n3k6:(int)idx {
    return OngnongCounterIconImage(idx);
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, 166.0, 88.0)];
    if (!self) return nil;
    self.backgroundColor = ZThemePanelColor();
    ApplyNeon(self, ZThemeBorder(), 15.0, 1.1);
    self.clipsToBounds = NO;
    self.userInteractionEnabled = YES;

    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    _t4q9k5 = [ud integerForKey:OX_NS("ot_slot")];
    _d7m2x6 = [ud integerForKey:OX_NS("ot_target")];
    _a8p3v1 = 0;
    _h5q1c9 = [ud boolForKey:OX_NS("ot_running")];
    _z2m6q8 = [ud objectForKey:OX_NS("ot_base")] ? [ud integerForKey:OX_NS("ot_base")] : 0;
    if (_t4q9k5 < 0 || _t4q9k5 >= (NSInteger)[self t8m2d5].count) _t4q9k5 = 0;
    [self zAutoStopSyncFromMaster];
    if (!_h5q1c9 || _z2m6q8 > _a8p3v1) _z2m6q8 = _a8p3v1;
    _p6f3a9 = _a8p3v1;
    _z8n4c2 = 0;

    _titleLabel = Label(ZuiAutoTargetText(), 12.0, UIFontWeightHeavy, ZThemeWhite(), NSTextAlignmentCenter);
    [self addSubview:_titleLabel];

    _h8m3x6 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_h8m3x6 setTitle:(_d7m2x6 > 0 ? [NSString stringWithFormat:@"%ld", (long)_d7m2x6] : ZuiSetText()) forState:UIControlStateNormal];
    [_h8m3x6 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _h8m3x6.titleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightHeavy];
    _h8m3x6.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_h8m3x6, ZThemeBorder(), 8.0, 1.0);
    [_h8m3x6 addTarget:self action:@selector(y2v9m5) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_h8m3x6];

    _d2q9v5 = [UIButton buttonWithType:UIButtonTypeCustom];
    _d2q9v5.selected = _h5q1c9;
    _d2q9v5.layer.cornerRadius = 13.0;
    _d2q9v5.layer.borderWidth = 1.0;
    _d2q9v5.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.22].CGColor;
    [_d2q9v5 addTarget:self action:@selector(u6c1x4:) forControlEvents:UIControlEventTouchUpInside];
    _zAutoStopThumb = [[UIView alloc] initWithFrame:CGRectMake(_h5q1c9 ? 23.0 : 3.0, 3.0, 20.0, 20.0)];
    _zAutoStopThumb.backgroundColor = [UIColor whiteColor];
    _zAutoStopThumb.layer.cornerRadius = 10.0;
    _zAutoStopThumb.userInteractionEnabled = NO;
    [_d2q9v5 addSubview:_zAutoStopThumb];
    [self addSubview:_d2q9v5];
    [self zAutoStopRefreshToggle];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(zCounterIconStyleChanged:) name:OX_NS("ongnong_counter_icon_changed") object:nil];

    _p7n1c4 = [[UIView alloc] initWithFrame:CGRectZero];
    _p7n1c4.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_p7n1c4, ZThemeBorder(), 10.0, 0.8);
    [self addSubview:_p7n1c4];

    NSMutableArray *a7m1c5 = [NSMutableArray array];
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    for (NSInteger i = 0; i < (NSInteger)idxs.count; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        UIImage *img = [self v7n3k6:idxs[i].intValue];
        if (img) [b setImage:img forState:UIControlStateNormal];
        b.imageView.contentMode = UIViewContentModeScaleAspectFit;
        b.layer.cornerRadius = 10.0;
        [b addTarget:self action:@selector(b4q6n1:) forControlEvents:UIControlEventTouchUpInside];
        [_p7n1c4 addSubview:b];
        [a7m1c5 addObject:b];
    }
    _y5m8k2 = a7m1c5;

    _r9q3d6 = [[UIView alloc] initWithFrame:CGRectZero];
    _r9q3d6.backgroundColor = ZThemePanelDarker();
    ApplyNeon(_r9q3d6, ZThemeBorder(), 15.0, 1.1);
    _r9q3d6.layer.masksToBounds = NO;
    _r9q3d6.hidden = YES;
    [self addSubview:_r9q3d6];

    _x1v7p4 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _x1v7p4.contentMode = UIViewContentModeScaleAspectFit;
    [_r9q3d6 addSubview:_x1v7p4];

    _c6m2n8 = Label(@"0/0", 12.0, UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentCenter);
    _c6m2n8.font = [UIFont fontWithName:@"Menlo-Bold" size:13.0] ?: [UIFont boldSystemFontOfSize:13.0];
    _c6m2n8.adjustsFontSizeToFitWidth = YES;
    _c6m2n8.minimumScaleFactor = 0.62;
    [_r9q3d6 addSubview:_c6m2n8];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(d3x7v5)];
    [_r9q3d6 addGestureRecognizer:tap];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    pan.delegate = self;
    [self addGestureRecognizer:pan];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(m7d4k9:) name:Z1e3f87b2aa object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(p3n8q2:) name:Z9a421e103d object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(z4fb91b7407:) name:Z02a7e13d91 object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(z4fb91b7407:) name:Z6a3e9c1d74 object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(c7v2m9:) name:OX_NS("ongnong_slot_spin_complete") object:nil];

    _v3n8p4 = !_h5q1c9;
    _k9m2d7 = NO;
    _q6r1m8 = NO;
    _z7c4p1 = NO;
    [self r8p3d7];
    [self a9m3c6];
    [self k9m2c8:NO];
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)z1a3b62f4d9 {
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    if ((NSInteger)_y5m8k2.count == (NSInteger)idxs.count) return;

    for (UIButton *old in _y5m8k2) [old removeFromSuperview];

    NSMutableArray<UIButton *> *a7m1c5 = [NSMutableArray arrayWithCapacity:idxs.count];
    for (NSInteger i = 0; i < (NSInteger)idxs.count; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        UIImage *img = [self v7n3k6:idxs[i].intValue];
        if (img) [b setImage:img forState:UIControlStateNormal];
        b.imageView.contentMode = UIViewContentModeScaleAspectFit;
        b.layer.cornerRadius = 10.0;
        [b addTarget:self action:@selector(b4q6n1:) forControlEvents:UIControlEventTouchUpInside];
        [_p7n1c4 addSubview:b];
        [a7m1c5 addObject:b];
    }
    _y5m8k2 = a7m1c5;

    if (_t4q9k5 < 0 || _t4q9k5 >= (NSInteger)idxs.count) {
        _t4q9k5 = 0;
        [[NSUserDefaults standardUserDefaults] setInteger:_t4q9k5 forKey:OX_NS("ot_slot")];
    }

    [self r8p3d7];
    [self setNeedsLayout];
}

- (CGSize)c2m8r4 { return CGSizeMake(166.0, 88.0); }
- (CGSize)h6q1p9 { return CGSizeMake(110.0, 30.0); }

- (void)layoutSubviews {
    [super layoutSubviews];
    [self z1a3b62f4d9];
    if (self.h5q1c9 && !self.v3n8p4) {
        _r9q3d6.frame = self.bounds;
        _r9q3d6.layer.cornerRadius = self.bounds.size.height * 0.5;
        _r9q3d6.layer.borderWidth = 1.2;
        int compactIdx = [self q4p9x1:self.t4q9k5];
        _x1v7p4.frame = (compactIdx == Z87f6d0c11d || compactIdx == Z5d92a7e4c1) ? CGRectMake(5.0, 2.5, 25.0, 25.0) : CGRectMake(7.0, 4.0, 22.0, 22.0);
        _c6m2n8.frame = CGRectMake(31.0, 0.0, self.bounds.size.width - 35.0, self.bounds.size.height);
        return;
    }
    _titleLabel.text = ZuiAutoTargetText();
    _titleLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightHeavy];
    _titleLabel.frame = CGRectMake(6.0, 5.0, 76.0, 20.0);
    _h8m3x6.frame = CGRectMake(84.0, 6.0, 34.0, 20.0);
    _d2q9v5.frame = CGRectMake(120.0, 3.0, 46.0, 26.0);
    _p7n1c4.frame = CGRectMake(6.0, 31.0, self.bounds.size.width - 12.0, 51.0);
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    CGFloat count = MAX((CGFloat)1.0, (CGFloat)_y5m8k2.count);
    CGFloat w = _p7n1c4.bounds.size.width / count;
    for (NSInteger i = 0; i < (NSInteger)_y5m8k2.count; i++) {
        UIButton *b = _y5m8k2[i];
        b.frame = CGRectMake(i * w + 1.0, 4.0, w - 2.0, 43.0);
        int idx = (i < (NSInteger)idxs.count) ? idxs[i].intValue : -1;
        b.imageEdgeInsets = (idx == Z87f6d0c11d || idx == Z5d92a7e4c1) ? UIEdgeInsetsMake(-1.0, -1.0, -1.0, -1.0) : UIEdgeInsetsMake(0.5, 0.5, 0.5, 0.5);
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([touch.view isKindOfClass:[UIControl class]]) return NO;
    return YES;
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *sv = self.superview;
    if (!sv) return;
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint t = [pan translationInView:sv];
        CGPoint c = CGPointMake(_x3q8c6.x + t.x, _x3q8c6.y + t.y);
        CGFloat hw = self.bounds.size.width / 2.0;
        CGFloat hh = self.bounds.size.height / 2.0;
        c.x = MAX(hw, MIN(sv.bounds.size.width - hw, c.x));
        c.y = MAX(hh, MIN(sv.bounds.size.height - hh, c.y));
        self.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.x forKey:OX_NS("ot_x")];
            [[NSUserDefaults standardUserDefaults] setFloat:self.frame.origin.y forKey:OX_NS("ot_y")];
        }
    }
}

- (void)d3x7v5 {
    self.v3n8p4 = YES;
    [self k9m2c8:YES];
    Z0418c1e0ae();
}

- (void)zAutoStopRefreshToggle {
    self.d2q9v5.selected = self.h5q1c9;
    self.d2q9v5.backgroundColor = self.h5q1c9 ? ZThemeOnGreen() : ZThemeButtonOff();
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    self.zAutoStopThumb.frame = CGRectMake(self.h5q1c9 ? 23.0 : 3.0, 3.0, 20.0, 20.0);
    [CATransaction commit];
}

- (void)k9m2c8:(BOOL)animated {
    CGSize size = (self.h5q1c9 && !self.v3n8p4) ? [self h6q1p9] : [self c2m8r4];
    CGRect f = self.frame;
    f.size = size;
    UIView *sv = self.superview;
    if (sv) {
        if (CGRectGetMaxX(f) > sv.bounds.size.width - 4.0) f.origin.x = sv.bounds.size.width - f.size.width - 4.0;
        if (CGRectGetMaxY(f) > sv.bounds.size.height - 4.0) f.origin.y = sv.bounds.size.height - f.size.height - 4.0;
        if (f.origin.x < 4.0) f.origin.x = 4.0;
        if (f.origin.y < 24.0) f.origin.y = 24.0;
    }
    BOOL compactTarget = (self.h5q1c9 && !self.v3n8p4);
    self.d2q9v5.hidden = compactTarget;
    [self zAutoStopRefreshToggle];
    void (^changes)(void) = ^{
        self.frame = f;
        BOOL compact = (self.h5q1c9 && !self.v3n8p4);
        self.titleLabel.hidden = compact;
        self.h8m3x6.hidden = compact;
        if (compact) self.d2q9v5.hidden = YES;
        self.p7n1c4.hidden = compact;
        self.r9q3d6.hidden = !compact;
        self.backgroundColor = compact ? [UIColor clearColor] : ZThemePanelColor();
        self.layer.borderWidth = compact ? 0.0 : 1.4;
        self.layer.shadowOpacity = 0.0;
        self.layer.cornerRadius = compact ? (f.size.height * 0.5) : 16.0;
        self.r9q3d6.layer.cornerRadius = compact ? (f.size.height * 0.5) : 17.0;
        [self setNeedsLayout];
        [self layoutIfNeeded];
    };
    [UIView performWithoutAnimation:changes];
    self.d2q9v5.hidden = compactTarget;
}

- (void)b4q6n1:(UIButton *)sender {
    if (self.h5q1c9) return;
    self.t4q9k5 = sender.tag;
    [[NSUserDefaults standardUserDefaults] setInteger:self.t4q9k5 forKey:OX_NS("ot_slot")];
    [self zAutoStopSetBaseToCurrent];
    self.z7c4p1 = NO;
    [self r8p3d7];
    [self a9m3c6];
    Z0418c1e0ae();
}

- (void)zCounterIconStyleChanged:(NSNotification *)notification { [self r8p3d7]; }

- (void)r8p3d7 {
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    if ((NSInteger)_y5m8k2.count != (NSInteger)idxs.count) {
        [self z1a3b62f4d9];
        return;
    }
    if (self.t4q9k5 < 0 || self.t4q9k5 >= (NSInteger)idxs.count) self.t4q9k5 = 0;
    for (NSInteger i = 0; i < (NSInteger)_y5m8k2.count; i++) {
        UIButton *b = _y5m8k2[i];
        if (i < (NSInteger)idxs.count) {
            UIImage *img = [self v7n3k6:idxs[i].intValue];
            if (b.imageView.image != img) [b setImage:img forState:UIControlStateNormal];
        }
        BOOL selected = (i == self.t4q9k5);
        b.backgroundColor = selected ? ZThemeOrange() : [UIColor colorWithWhite:0.0 alpha:0.0];
        b.layer.borderWidth = selected ? 1.1 : 0.0;
        b.layer.borderColor = [UIColor colorWithWhite:0.66 alpha:1].CGColor;
        b.layer.shadowColor = [UIColor clearColor].CGColor;
        b.layer.shadowOpacity = 0.0;
        b.layer.shadowRadius = 0.0;
        b.layer.shadowOffset = CGSizeZero;
    }
}

- (void)y2v9m5 {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:ZuiAutoTargetText() message:ZuiAutoTargetPrompt() preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.text = self.d7m2x6 > 0 ? [NSString stringWithFormat:@"%ld", (long)self.d7m2x6] : @"";
    }];
    [alert addAction:[UIAlertAction actionWithTitle:ZuiSaveText() style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        NSInteger v = [alert.textFields.firstObject.text integerValue];
        if (v < 0) v = 0;
        if (v > 9999) v = 9999;
        self.d7m2x6 = v;
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        [self.h8m3x6 setTitle:(v > 0 ? [NSString stringWithFormat:@"%ld", (long)v] : ZuiSetText()) forState:UIControlStateNormal];
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setInteger:self.d7m2x6 forKey:OX_NS("ot_target")];
        [ud setInteger:self.a8p3v1 forKey:OX_NS("ot_current")];
    [ud setInteger:self.z2m6q8 forKey:OX_NS("ot_base")];
        [ud synchronize];
        if (v <= 0 && self.h5q1c9) {
            [self u6c1x4:self.d2q9v5];
        }
        [self a9m3c6];
        Z0418c1e0ae();
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *root = UIApplication.sharedApplication.keyWindow.rootViewController;
    if (root.presentedViewController) root = root.presentedViewController;
    [root presentViewController:alert animated:YES completion:nil];
    Z0418c1e0ae();
}

- (void)u6c1x4:(UIButton *)sender {
    BOOL nextOn = !self.h5q1c9;
    if (nextOn && self.d7m2x6 <= 0) {
        [self y2v9m5];
        return;
    }
    self.h5q1c9 = nextOn;
    [self zAutoStopRefreshToggle];
    if (self.h5q1c9) {
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        self.k9m2d7 = NO;
        self.q6r1m8 = NO;
        self.v3n8p4 = NO;
    } else {
        self.k9m2d7 = NO;
        self.q6r1m8 = NO;
        self.v3n8p4 = YES;
    }
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setBool:self.h5q1c9 forKey:OX_NS("ot_running")];
    [ud setInteger:self.a8p3v1 forKey:OX_NS("ot_current")];
    [ud setInteger:self.z2m6q8 forKey:OX_NS("ot_base")];
    [ud synchronize];
    [self a9m3c6];
    [self k9m2c8:YES];
    Z0418c1e0ae();
}

- (void)p3n8q2:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || !Ongnong::Z76f880a1d(self.t4q9k5)) return;
    self.k9m2d7 = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.h5q1c9) return;
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        [self a9m3c6];
    });
}

- (void)z4fb91b7407:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || !(Ongnong::Z76d7aa0492(self.t4q9k5) || Ongnong::Z76b8e20f53(self.t4q9k5))) return;
    self.k9m2d7 = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self.h5q1c9) return;
        [self zAutoStopSetBaseToCurrent];
        self.z7c4p1 = NO;
        [self a9m3c6];
    });
}

- (void)m7d4k9:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || self.d7m2x6 <= 0) return;
    self.k9m2d7 = NO;
    [self zAutoStopSyncFromMaster];
    [[NSUserDefaults standardUserDefaults] setInteger:self.a8p3v1 forKey:OX_NS("ot_current")];
    NSInteger progress = [self zAutoStopCycleProgress];
    [self a9m3c6];
    if (!self.z7c4p1 && progress >= self.d7m2x6) {
        self.z7c4p1 = YES;
        if (Ongnong::SlotIsSpinningForCycle()) {
            Ongnong::PauseAutoSpinForCycle();
        }
        [self x5q2v8];
        ZAutoStopTargetStrongHaptic();
    }
}

- (void)c7v2m9:(NSNotification *)n {
    (void)n;
    if (!self.h5q1c9 || !self.q6r1m8) return;
    self.q6r1m8 = NO;
    [self x5q2v8];
}

- (void)x5q2v8 {
    if (!self.h5q1c9) return;
    self.h5q1c9 = NO;
    self.k9m2d7 = NO;
    self.q6r1m8 = NO;
    self.v3n8p4 = YES;
    [self zAutoStopRefreshToggle];
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setBool:NO forKey:OX_NS("ot_running")];
    [ud synchronize];
    BOOL stoppedByGameMethod = Ongnong::StopSpinForAutoTarget();
    if (!stoppedByGameMethod) {
        CGSize screen = UIScreen.mainScreen.bounds.size;
        CGPoint p = CGPointMake(screen.width * 0.5, screen.height * 0.85);
        NSInteger pid = [X7q4M c4d8];
        [X7q4M x7q0:pid n2v5:p k9m1:UITouchPhaseBegan];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.055 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [X7q4M x7q0:pid n2v5:p k9m1:UITouchPhaseEnded];
        });
    }
    [self a9m3c6];
    [self k9m2c8:YES];
    Z0418c1e0ae();
}

- (void)a9m3c6 {
    [self zAutoStopSyncFromMaster];
    [self z1a3b62f4d9];
    NSArray<NSNumber *> *idxs = [self t8m2d5];
    if (self.t4q9k5 < 0 || self.t4q9k5 >= (NSInteger)idxs.count) self.t4q9k5 = 0;
    int idx = [self q4p9x1:self.t4q9k5];
    UIImage *img = [self v7n3k6:idx];
    self.x1v7p4.image = img;
    NSInteger progress = self.h5q1c9 ? [self zAutoStopCycleProgress] : 0;
    NSString *text = [NSString stringWithFormat:OX_NS("%ld/%ld"), (long)progress, (long)MAX((NSInteger)0, self.d7m2x6)];
    self.c6m2n8.text = text;
}
@end

@interface Z9abcb7bb90 : UIViewController
@property (nonatomic, strong) Za540ef69c7 *v2p6k1;
@property (nonatomic, strong) Z4c5163ab2a *a9q2x4;
@property (nonatomic, strong) Z1c94f803b6 *n7c3m8;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSTimer *d8r4q7;
@property (nonatomic, assign) BOOL collapsed;
@property (nonatomic, assign) CGRect x5m9c2;
@property (nonatomic, strong) UIButton *b3n7v1;
@property (nonatomic, strong) Zd4f227a905 *d2q8n4;
@property (nonatomic, strong) Z8x4c2v7 *w7p3v6;
@property (nonatomic, strong) X4f0a1 *q72p9m4;
@property (nonatomic, assign) NSInteger z4b51d86a09;
@property (nonatomic, assign) NSUInteger p6d1v7;
@property (nonatomic, assign) BOOL k4m8r2;
@property (nonatomic, assign) BOOL h1x9c5;
@property (nonatomic, strong) UIButton *u1x7p4;
@property (nonatomic, assign) BOOL r8m2d5;
@property (nonatomic, assign) CGPoint r6q2p8;
@property (nonatomic, strong) UIButton *b6p2x9;
@property (nonatomic, assign) BOOL v7m4q1;
@property (nonatomic, assign) CGPoint n5c8r2;
@property (nonatomic, strong) UIButton *e3k9d6;
@property (nonatomic, assign) BOOL x4p7m2;
@property (nonatomic, assign) CGPoint h8q1v5;
@property (nonatomic, strong) UIButton *q8z1u4;
@property (nonatomic, assign) BOOL m3k9a2;
@property (nonatomic, assign) CGPoint c7w2e6;
@property (nonatomic, assign) BOOL zForestDragging;
@property (nonatomic, strong) UIButton *k2m8v4;
@property (nonatomic, assign) BOOL p7x3n6;
@property (nonatomic, assign) CGPoint a4q9d1;
@property (nonatomic, assign) BOOL n3q9c6;
@property (nonatomic, assign) BOOL b7v1k8;
@property (nonatomic, assign) BOOL t4p6x2;
@property (nonatomic, assign) float c9m5r3;
@property (nonatomic, assign) BOOL f7q2n8;
@property (nonatomic, assign) CGRect p4m9c1;
@property (nonatomic, strong) UIView *c5a8u2;
@property (nonatomic, strong) NSArray<UIButton *> *s4k7e1;
@property (nonatomic, strong) UIButton *w6j2r9;
@property (nonatomic, assign) BOOL a6t3y8;
@property (nonatomic, assign) BOOL d7u4i1;
@property (nonatomic, assign) BOOL onThirdLayout;
@property (nonatomic, strong) UIView *onThirdBar;
@property (nonatomic, strong) NSMutableArray<UIButton *> *onThirdButtons;

@property (nonatomic, assign) CGPoint f2o9p5;
@property (nonatomic, assign) BOOL zAltGridDragging;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, UIButton *> *zAltFloatButtons;
- (void)p8c4n2;
- (void)zApplyInterface;
- (void)zToggleInterface;
- (void)onShowMenuVisibility;
- (void)onThirdRefresh;
- (void)onThirdToggleMenu;
- (void)onThirdTap:(UIButton *)button;
- (void)onThirdHold:(UILongPressGestureRecognizer *)gesture;
- (void)onThirdBuild;

- (void)zAltOpenMenu;
- (void)zAltCloseMenu;
- (void)zAltGridTap:(UIButton *)sender;
- (void)zAltGridPan:(UIPanGestureRecognizer *)pan;
- (NSArray<NSString *> *)zAltMenuTitles;
- (void)zRefreshAltMenuTitles;
- (void)zAltTargetCycle;
- (void)zAltShowShortcut:(NSInteger)tag;
- (void)zAltShortcutTap:(UIButton *)sender;
- (void)zAltShortcutClose:(UIButton *)sender;
- (void)zAltShortcutPan:(UIPanGestureRecognizer *)pan;
- (void)zMagicPopupClose;
- (void)zForestPopupClose;
- (void)zMergePopupClose;
- (void)orderDiagHold:(UILongPressGestureRecognizer *)gesture;
- (CGRect)collapseHandleFrameForMenuFrame:(CGRect)menuFrame collapsed:(BOOL)isCollapsed;
- (void)z3q7d9;
- (void)d2x8q4;
- (void)h9r3v7;
- (void)m1b6k5;
- (void)h2p7m9;
- (void)e7k3p9;
- (UIImage *)z0b9c95dabc:(int)idx;
- (NSInteger)z3f0b8e15a2:(NSInteger)slot;
- (void)z7ee09a13c4;
- (void)q1c8v4;
- (void)q9d3m6;
- (void)t6r2n9;
- (void)j3v7q5;
- (void)a7q3d8;
- (void)s2k6v4;
- (void)z6m4a8;
- (void)r9b4t1;
- (void)h6d2q8;
- (void)p3v7m5:(UIPanGestureRecognizer *)pan;
- (UIButton *)c4m8q2:(CGRect)frame title:(NSString *)title action:(SEL)action closeAction:(SEL)closeAction panAction:(SEL)panAction;
- (void)b2v7n4;
- (void)z3n8v5;
- (void)k1d6p4:(UIPanGestureRecognizer *)pan;
- (void)t5x9c2;
- (void)g7q3m8;
- (void)v5c2q8;
- (void)w1p5c9;
- (void)a9r2k6:(UIPanGestureRecognizer *)pan;
- (void)q4d8x3;
- (void)y6m1p7;
- (void)j6t3a8;
- (void)y4d8p2;
- (void)u7m1c9;
- (void)h5p1k8;
- (void)v7b2c9;
- (void)w3m7d2;
- (void)z8a5c1;
- (void)q2n9v6;
- (void)n1c8f5:(UIPanGestureRecognizer *)pan;
- (void)b6x4j9:(NSNotification *)note;
- (void)u4m8p2;
- (void)c3n7x5;
- (void)r9k2d6;
- (void)y5v1q8:(UIPanGestureRecognizer *)pan;
- (CGRect)zClampFrame:(CGRect)frame minW:(CGFloat)minW minH:(CGFloat)minH maxW:(CGFloat)maxW maxH:(CGFloat)maxH;
- (void)zSaveQuickPanelFrame;
- (void)zSaveCounterPanelFrame;
- (void)g5x9q4:(NSNotification *)note;
- (void)ongFriendModule;
- (void)ongFriendClearLink:(UIButton *)sender;
- (void)ongPotionModule;
- (void)zBuyVipPayOS;
- (void)zShowBuyVipRegionPicker;
- (void)zOpenInternationalCheckout;
- (void)zVipLoadPlans;
- (void)zStyleBuyVipAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle;
- (void)zApplyBuyVipStyleInAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle;
- (void)zCollectLabelsFromView:(UIView *)view into:(NSMutableArray<UILabel *> *)labels;
@end

@implementation Za540ef69c7
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = ZThemePanelColor();
    ApplyNeon(self, ZThemeBorder(), 24.0, 1.2);
    self.clipsToBounds = YES;

    _title = Label(Z6ddd40608f(), zb1d8336499(37.0, 22.0), UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentCenter);
    _title.layer.shadowColor = RGB(255, 120, 20).CGColor;
    _title.layer.shadowOpacity = 0.0;
    _title.layer.shadowRadius = 0.0;
    _title.layer.shadowOffset = CGSizeZero;
    [self addSubview:_title];

    _r6q2p8 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_r6q2p8 setTitle:ZuiLanguageButtonText() forState:UIControlStateNormal];
    [_r6q2p8 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _r6q2p8.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(19.0, 12.0) weight:UIFontWeightHeavy];
    _r6q2p8.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_r6q2p8, ZThemeBorder(), 12.0, 1.0);
    [_r6q2p8 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_r6q2p8];

    _k3v9d4 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_k3v9d4 setTitle:ZVipBuyNowText() forState:UIControlStateNormal];
    [_k3v9d4 setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    _k3v9d4.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(20.0, 13.0) weight:UIFontWeightBlack];
    _k3v9d4.backgroundColor = RGB(18, 105, 45);
    _k3v9d4.layer.cornerRadius = 8.0;
    _k3v9d4.layer.borderWidth = 1.0;
    _k3v9d4.layer.borderColor = RGB(40, 155, 72).CGColor;
    [self addSubview:_k3v9d4];

    Zcb66126fa3 *b1 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoClickText() icon:[NSString string] color:RGB(45, 255, 70)];
    Zcb66126fa3 *b2 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiHistoryText() icon:[NSString string] color:RGB(234, 76, 255)];
    Zcb66126fa3 *b3 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoBuildText() icon:[NSString string] color:RGB(50, 190, 255)];
    Zcb66126fa3 *b4 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoPigHammerText() icon:[NSString string] color:RGB(255, 120, 30)];
    Zcb66126fa3 *b9 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiMagicCardsQuickText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b5 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiUpdateText() icon:[NSString string] color:RGB(255, 65, 65)];
    b5.v1q7p3 = [RGB(205, 28, 28) colorWithAlphaComponent:0.90];
    b5.backgroundColor = b5.v1q7p3;
    b5.x9c4n6.textColor = [UIColor whiteColor];
    Zcb66126fa3 *b10 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiBuyVipText() icon:[NSString string] color:RGB(255, 212, 55)];
    b10.v1q7p3 = [RGB(203, 148, 20) colorWithAlphaComponent:0.93];
    b10.backgroundColor = b10.v1q7p3;
    b10.x9c4n6.textColor = [UIColor whiteColor];
    Zcb66126fa3 *b6 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiToolsText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b7 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoTargetText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b8 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiMenuColorText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b11 = [[Zcb66126fa3 alloc] initWithV5m8p2:Zr7f421() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b12 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiBetCycleText() icon:[NSString string] color:ZThemeBorder()];
    Zcb66126fa3 *b13 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiAutoMergeText() icon:[NSString string] color:RGB(120, 235, 170)];
    Zcb66126fa3 *b14 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiFriendInviteText() icon:[NSString string] color:RGB(90, 210, 255)];
    NSString *potionMenuTitle = ZuiPotionStateText(Ongnong::AutoPotionIsEnabled());
    Zcb66126fa3 *b15 = [[Zcb66126fa3 alloc] initWithV5m8p2:potionMenuTitle icon:[NSString string] color:RGB(185, 105, 255)];
    Zcb66126fa3 *b16 = [[Zcb66126fa3 alloc] initWithV5m8p2:ZuiInterfaceText() icon:[NSString string] color:ZThemeBorder()];
    _a7m1c5 = @[b5, b10, b2, b3, b4, b9, b1, b6, b7, b8, b11, b12, b13, b14, b15, b16];
    _onMenuScroll = [[UIView alloc] initWithFrame:CGRectZero];
    [self addSubview:_onMenuScroll];
    NSUserDefaults *visibilityDefaults = [NSUserDefaults standardUserDefaults];
    for (NSUInteger i = 0; i < _a7m1c5.count; i++) {
        Zcb66126fa3 *button = _a7m1c5[i];
        NSString *key = [NSString stringWithFormat:OX_NS("ongnong_main_visible_%lu"), (unsigned long)i];
        if (Ongnong::Zx8fIsVIP() && i != 1 && i != 15 && [visibilityDefaults objectForKey:key] && ![visibilityDefaults boolForKey:key]) button.hidden = YES;
        [_onMenuScroll addSubview:button];
    }

    _x8p4n2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_x8p4n2 setTitle:qsec_s_0038() forState:UIControlStateNormal];
    [_x8p4n2 setTitleColor:RGB(160, 250, 255) forState:UIControlStateNormal];
    _x8p4n2.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(24.0, 15.0) weight:UIFontWeightHeavy];
    _x8p4n2.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_x8p4n2, ZThemeBorder(), 8.0, 1.0);
    _x8p4n2.hidden = YES;
    [self addSubview:_x8p4n2];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    [self addGestureRecognizer:pan];
    return self;
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)e4p7n1:(NSString *)code {
    _title.text = Z6ddd40608f();
    if (code.length == 0) code = qsec_s_0039();
    BOOL known = [code isEqualToString:qsec_s_0039()] || [code isEqualToString:qsec_s_0040()] || [code isEqualToString:qsec_s_0048()] || [code isEqualToString:qsec_s_0056()] || [code isEqualToString:OngnongUIVaultLangCodeEN()];
    if (!known) code = qsec_s_0039();

    [_r6q2p8 setTitle:ZuiLanguageButtonText() forState:UIControlStateNormal];
    [_k3v9d4 setTitle:ZVipBuyNowText() forState:UIControlStateNormal];
    NSString *potionMenuTitle = ZuiPotionStateText(Ongnong::AutoPotionIsEnabled());
    NSArray<NSString *> *titles = @[ZuiUpdateText(), ZuiBuyVipText(), ZuiHistoryText(), ZuiAutoBuildText(), ZuiAutoPigHammerText(), ZuiMagicCardsQuickText(), ZuiAutoClickText(), ZuiToolsText(), ZuiAutoTargetText(), ZuiMenuColorText(), Zr7f421(), ZuiBetCycleText(), ZuiAutoMergeText(), ZuiFriendInviteText(), potionMenuTitle, ZuiInterfaceText()];

    NSUInteger count = MIN(_a7m1c5.count, titles.count);
    for (NSUInteger i = 0; i < count; i++) {
        Zcb66126fa3 *button = _a7m1c5[i];
        button.x9c4n6.text = titles[i];
        [button setNeedsLayout];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat s = z067adc83c5();
    CGFloat w = self.bounds.size.width;
    _title.font = [UIFont systemFontOfSize:zb1d8336499(30.0, 18.0) weight:UIFontWeightBlack];
    _title.frame = CGRectMake(6 * s, 10 * s, w - 12 * s, 48 * s);

    CGFloat side = 6 * s;
    CGFloat rowY = 58 * s;
    CGFloat rowH = 40 * s;
    _r6q2p8.frame = CGRectMake(side, rowY, w - side * 2.0, rowH);
    BOOL freeMode = [ZuiBuyVipText() isEqualToString:OX_NS("FREE")];
    _k3v9d4.hidden = !freeMode || !Ongnong::Zx8fMenuItemVisible(OX_NS("upgrade_vip")) || _onThirdLayout;
    CGFloat y = 104 * s;
    if (freeMode && Ongnong::Zx8fMenuItemVisible(OX_NS("upgrade_vip")) && !_onThirdLayout) {
        _k3v9d4.frame = CGRectMake(side, y, w - side * 2.0, 40 * s);
        y += 46 * s;
    } else {
        _k3v9d4.frame = CGRectZero;
    }

    CGFloat bottom = self.bounds.size.height - 5.0 * s;
    _onMenuScroll.frame = CGRectMake(0, y, w, MAX(1.0, bottom - y));
    NSUInteger visibleCount = 0;
    for (UIView *button in _a7m1c5) if (!button.hidden) visibleCount++;
    CGFloat gap = 3.0 * s;
    CGFloat available = MAX(1.0, bottom - y - 4.0 * s);
    CGFloat rowHeight = visibleCount ? MIN(40.0 * s, (available - MAX(0, (NSInteger)visibleCount - 1) * gap) / visibleCount) : 40.0 * s;
    CGFloat itemY = 2.0 * s;
    for (UIView *button in _a7m1c5) {
        if (button.hidden) { button.frame = CGRectZero; continue; }
        button.frame = CGRectMake(side, itemY, w - side * 2.0, rowHeight);
        itemY += rowHeight + gap;
    }

    _x8p4n2.frame = CGRectMake(w - 30 * s, self.bounds.size.height * 0.40, 30 * s, 70 * s);
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *superview = self.superview;
    if (!superview) return;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged) {
        CGFloat halfW = self.bounds.size.width / 2.0;
        CGFloat halfH = self.bounds.size.height / 2.0;
        CGFloat fixedX = (6.0 * z067adc83c5()) + halfW;
        CGPoint c = CGPointMake(fixedX, _x3q8c6.y + translation.y);
        c.y = MAX(halfH, MIN(superview.bounds.size.height - halfH, c.y));
        self.center = c;
        [[NSNotificationCenter defaultCenter] postNotificationName:qsec_s_0062() object:self];
    }
}


@end

@implementation Z4c5163ab2a
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = ZThemePanelColor();
    ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
    _d5q9v3 = [[Zf721fd429b alloc] initWithV5m8p2:[NSString string] color:RGB(35, 255, 90)];
    _t2m7k6 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0063() color:RGB(52, 225, 255)];
    _c8x1p4 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0064() color:RGB(255, 69, 230)];
    _r3n9d5 = [[Z73b2f81c4a alloc] initWithFrame:CGRectZero];
    _v6q2m8 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0081() color:RGB(208, 76, 255)];
    _k4p7c1 = [[Zf721fd429b alloc] initWithV5m8p2:qsec_s_0066() color:RGB(55, 255, 72)];
    for (UIView *v in @[_d5q9v3, _t2m7k6, _c8x1p4, _r3n9d5, _v6q2m8, _k4p7c1]) [self addSubview:v];
    _q4n8p2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_q4n8p2 setTitle:OX_NS("›") forState:UIControlStateNormal];
    [_q4n8p2 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _q4n8p2.titleLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightBlack];
    _q4n8p2.titleLabel.adjustsFontSizeToFitWidth = YES;
    _q4n8p2.contentEdgeInsets = UIEdgeInsetsZero;
    _q4n8p2.backgroundColor = UIColor.clearColor;
    _q4n8p2.layer.borderWidth = 0.0;
    _q4n8p2.layer.shadowOpacity = 0.0;
    [self addSubview:_q4n8p2];
    self.clipsToBounds = NO;
    _u2p7k4 = [[UIView alloc] initWithFrame:CGRectZero];
    _u2p7k4.backgroundColor = ZThemePanelColor();
    ApplyNeon(_u2p7k4, ZThemeBorder(), 12.0, 1.0);
    _u2p7k4.hidden = YES;
    [self insertSubview:_u2p7k4 atIndex:0];
    _m6q1d8 = [[Zf721fd429b alloc] initWithV5m8p2:OX_NS("MENU") color:ZThemeBorder()];
    _h3c9v5 = [[Zf721fd429b alloc] initWithV5m8p2:OX_NS("LỊCH SỬ") color:ZThemeBorder()];
    _g8n2x6 = [[Zf721fd429b alloc] initWithV5m8p2:OX_NS("ĐỔI UI") color:ZThemeBorder()];
    for (UIButton *b in @[_m6q1d8, _h3c9v5, _g8n2x6]) { b.hidden = YES; [self addSubview:b]; }
    _z7h4p1 = [[UIView alloc] initWithFrame:CGRectZero];
    _z7h4p1.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_z7h4p1, ZThemeBorder(), 10.0, 0.9);
    _z7h4p1.hidden = YES;
    [self addSubview:_z7h4p1];
    _x2c8m5 = [[UIImageView alloc] initWithFrame:CGRectZero];
    _x2c8m5.contentMode = UIViewContentModeScaleAspectFit;
    [_z7h4p1 addSubview:_x2c8m5];
    _p9v3k7 = Label([NSString string], 12.0, UIFontWeightBlack, ZThemeWhite(), NSTextAlignmentLeft);
    _p9v3k7.adjustsFontSizeToFitWidth = YES;
    _p9v3k7.minimumScaleFactor = 0.55;
    [_z7h4p1 addSubview:_p9v3k7];
    _r4n6d2 = [UIButton buttonWithType:UIButtonTypeCustom];
    ZPlainIconButton(_r4n6d2, ZCounterTrashIconImage());
    [_z7h4p1 addSubview:_r4n6d2];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    [self addGestureRecognizer:pan];
    return self;
}
- (void)setQ6m2v8:(BOOL)collapsed {
    _q6m2v8 = collapsed;
    [self setNeedsLayout];
    [self layoutIfNeeded];
}
- (void)setA1v8m3:(BOOL)enabled {
    _a1v8m3 = enabled;
    [self setNeedsLayout];
    [self layoutIfNeeded];
}
- (void)layoutSubviews {
    [super layoutSubviews];
    NSArray *allViews = @[_d5q9v3, _t2m7k6, _c8x1p4, _r3n9d5, _v6q2m8, _k4p7c1];
    NSArray *altOnlyViews = @[_u2p7k4, _m6q1d8, _h3c9v5, _g8n2x6, _z7h4p1];
    if (!_a1v8m3 || _q6m2v8) {
        for (UIView *v in altOnlyViews) v.hidden = YES;
    }
    if (_a1v8m3 && !_q6m2v8) {
        for (UIView *v in allViews) v.hidden = NO;
        _q4n8p2.hidden = NO;
        _u2p7k4.hidden = NO;
        _m6q1d8.hidden = NO;
        _h3c9v5.hidden = NO;
        _g8n2x6.hidden = YES;
        _z7h4p1.hidden = NO;
        self.backgroundColor = ZThemePanelColor();
        ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
        self.layer.cornerRadius = 14.0;
        CGFloat w = self.bounds.size.width;
        CGFloat gap = 3.0;
        CGFloat margin = 4.0;
        CGFloat topY = 4.0;
        CGFloat topH = 40.0;
        CGFloat arrowW = 24.0;
        CGFloat inner = w - margin * 2.0 - gap * 4.0 - arrowW;
        CGFloat wifiW = inner * 0.205;
        CGFloat skipW = inner * 0.205;
        CGFloat targetW = inner * 0.295;
        CGFloat playW = inner - wifiW - skipW - targetW;
        CGFloat x = margin;
        _d5q9v3.frame = CGRectMake(x, topY, wifiW, topH); x += wifiW + gap;
        _k4p7c1.frame = CGRectMake(x, topY, skipW, topH); x += skipW + gap;
        _r3n9d5.frame = CGRectMake(x, topY, targetW, topH); x += targetW + gap;
        _v6q2m8.frame = CGRectMake(x, topY, playW, topH);
        _q4n8p2.frame = CGRectMake(w - margin - arrowW, topY, arrowW, topH);
        _q4n8p2.layer.cornerRadius = 8.0;
        _r3n9d5.layer.cornerRadius = 10.0;
        _r3n9d5.backgroundColor = ZThemeButtonOff();
        ApplyNeon(_r3n9d5, ZThemeBorder(), 10.0, 1.0);
        CGFloat row2Y = 47.0;
        CGFloat row2H = 31.0;
        _u2p7k4.frame = CGRectMake(0.0, row2Y - 2.0, w, row2H + 4.0);
        _u2p7k4.backgroundColor = UIColor.clearColor;
        _u2p7k4.layer.cornerRadius = 0.0;
        _u2p7k4.layer.borderWidth = 0.0;
        _u2p7k4.layer.shadowOpacity = 0.0;
        CGFloat fixedW = (w - margin * 2.0 - gap * 3.0) / 4.0;
        CGFloat bx = margin;
        _m6q1d8.frame = CGRectMake(bx, row2Y, fixedW, row2H); bx += fixedW + gap;
        _t2m7k6.frame = CGRectMake(bx, row2Y, fixedW, row2H); bx += fixedW + gap;
        _c8x1p4.frame = CGRectMake(bx, row2Y, fixedW, row2H); bx += fixedW + gap;
        _h3c9v5.frame = CGRectMake(bx, row2Y, fixedW, row2H);
        _g8n2x6.frame = CGRectZero;
        for (UIButton *b in @[_m6q1d8, _t2m7k6, _c8x1p4, _h3c9v5]) Z611a3d09ce(b, 10.5, 5.5);
        CGFloat row3Y = 81.0;
        CGFloat row3H = MAX(28.0, self.bounds.size.height - row3Y - 4.0);
        _z7h4p1.frame = CGRectMake(margin, row3Y, w - margin * 2.0, row3H);
        _z7h4p1.layer.cornerRadius = 9.0;
        CGFloat iconW = MIN(28.0, row3H - 4.0);
        _x2c8m5.frame = CGRectMake(5.0, (row3H - iconW) * 0.5, iconW, iconW);
        CGFloat trashW = 31.0;
        _r4n6d2.frame = CGRectMake(_z7h4p1.bounds.size.width - trashW - 3.0, 2.0, trashW, row3H - 4.0);
        _p9v3k7.frame = CGRectMake(8.0 + iconW, 1.0, _z7h4p1.bounds.size.width - iconW - trashW - 15.0, row3H - 2.0);
        return;
    }
    if (!_a1v8m3) {
        self.backgroundColor = ZThemePanelColor();
        ApplyNeon(self, ZThemeBorder(), 14.0, 1.2);
    }
    if (_q6m2v8) {
        for (UIView *v in allViews) v.hidden = (v != _r3n9d5);
        _q4n8p2.hidden = YES;
        CGFloat side = MAX(1.0, MIN(self.bounds.size.width, self.bounds.size.height) - 5.0);
        _r3n9d5.frame = CGRectMake((self.bounds.size.width-side)/2.0, (self.bounds.size.height-side)/2.0, side, side);
        _r3n9d5.layer.cornerRadius = side / 2.0;
        _r3n9d5.backgroundColor = UIColor.clearColor;
        _r3n9d5.layer.borderWidth = 0.0;
        _r3n9d5.layer.shadowOpacity = 0.0;
        self.layer.cornerRadius = MIN(self.bounds.size.width, self.bounds.size.height) / 2.0;
        return;
    }
    NSArray *views = @[_d5q9v3, _t2m7k6, _c8x1p4, _v6q2m8, _k4p7c1];
    for (UIView *v in allViews) v.hidden = (v == _r3n9d5);
    _q4n8p2.hidden = NO;
    self.layer.cornerRadius = 14.0;
    CGFloat s = z067adc83c5();
    CGFloat gap = 4 * s;
    CGFloat y = 5 * s;
    CGFloat h = self.bounds.size.height - 10 * s;
    CGFloat x = 5 * s;
    CGFloat arrowW = MAX(19.0, 28.0 * s);
    CGFloat arrowGap = 3.0;
    CGFloat usable = self.bounds.size.width - 10 * s - arrowW - arrowGap - gap * 4;
    CGFloat btnW = usable / 5.0;
    for (UIView *v in views) {
        v.frame = CGRectMake(x, y, btnW, h);
        if ([v isKindOfClass:[UIButton class]]) Z611a3d09ce((UIButton *)v, zb1d8336499(22.0, 13.0), 6.0);
        x += btnW + gap;
    }
    _q4n8p2.frame = CGRectMake(self.bounds.size.width - 5.0 * s - arrowW, y, arrowW, h);
    _q4n8p2.layer.cornerRadius = 0.0;
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *superview = self.superview;
    if (!superview) return;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) _x3q8c6 = self.center;
    if (pan.state == UIGestureRecognizerStateChanged) {
        CGPoint c = CGPointMake(_x3q8c6.x + translation.x, _x3q8c6.y + translation.y);
        CGFloat s = z067adc83c5();
        CGFloat halfW = self.bounds.size.width / 2.0;
        CGFloat halfH = self.bounds.size.height / 2.0;
        CGFloat visibleX = MAX(26.0 * s, 18.0);
        c.x = MAX(visibleX - halfW, MIN(superview.bounds.size.width - visibleX + halfW, c.x));
        c.y = MAX(halfH, MIN(superview.bounds.size.height - halfH, c.y));
        self.center = c;
    } else if (!_q6m2v8 && (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled || pan.state == UIGestureRecognizerStateFailed)) {
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setFloat:self.frame.origin.x forKey:OX_NS("tool_x")];
        [ud setFloat:self.frame.origin.y forKey:OX_NS("tool_y")];
        [ud setFloat:self.frame.size.width forKey:OX_NS("tool_w")];
        [ud setFloat:self.frame.size.height forKey:OX_NS("tool_h")];
        [ud synchronize];
    }
}
@end

@implementation Z1c94f803b6

- (NSInteger)u4m9q2 {
    NSInteger mask = 0;
    if (Ongnong::Zx8fTokenAllowed()) mask |= 1;
    if (Ongnong::Zx8fPotionAllowed()) mask |= 2;
    if (Ongnong::Zx8fLightningAllowed()) mask |= 4;
    return mask;
}

- (NSArray<NSNumber *> *)e5r1k7:(NSInteger)allowedMask {
    static NSArray<NSNumber *> *order = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        order = @[@0, @1, @2, @4, @3, @5, @6, @7];
    });
    NSMutableArray<NSNumber *> *cycle = [NSMutableArray arrayWithObject:@0];
    for (NSNumber *n in order) {
        NSInteger candidate = n.integerValue;
        if (candidate == 0) continue;
        if ((candidate & ~allowedMask) != 0) continue;
        if ((candidate & allowedMask) == 0) continue;
        [cycle addObject:n];
    }
    return cycle;
}

- (BOOL)w8c2m5 {
    return [self u4m9q2] != 0;
}

- (NSInteger)m8v2p6:(NSInteger)storedMask allowed:(NSInteger)allowedMask {
    if (storedMask < 0) storedMask = 0;
    if ((storedMask & ~allowedMask) != 0) storedMask &= allowedMask;
    NSArray<NSNumber *> *cycle = [self e5r1k7:allowedMask];
    for (NSNumber *n in cycle) if (n.integerValue == storedMask) return storedMask;
    return 0;
}

- (NSUInteger)eyePosition:(NSInteger)idx {
    for (NSUInteger i = 0; i < self.t6m1v8.count; i++) if (self.t6m1v8[i].p4x9c3 == idx) return i;
    return NSNotFound;
}

- (BOOL)t3p8x4:(NSInteger)idx {
    NSUInteger position = [self eyePosition:idx];
    return position == NSNotFound || ((_eyeVisibleBits & ((NSUInteger)1 << position)) != 0);
}

- (void)q6v1d9 {
    _eyeButton.hidden = NO;
    _eyeButton.alpha = 1.0;
    ZPlainIconButton(_eyeButton, ZCounterEyeIconImage(NO));
}

- (void)eyeResizeToCount:(NSUInteger)count {
    CGFloat available = self.superview ? self.superview.bounds.size.width - 16.0 : UIScreen.mainScreen.bounds.size.width - 16.0;
    CGFloat maxFullWidth = MAX(210.0, MIN(available, UIScreen.mainScreen.bounds.size.width - 16.0));
    _eyeFullWidth = MAX(210.0, MIN(_eyeFullWidth, maxFullWidth));
    CGFloat cellWidth = (_eyeFullWidth - 38.0) / 8.0;
    CGFloat desired = (10.0 + cellWidth * (CGFloat)count + 4.0 * (CGFloat)(count - 1));
    desired = MIN(desired, available);
    CGRect f = self.frame;
    f.size.width = desired;
    if (self.superview) f.origin.x = MAX(0.0, MIN(f.origin.x, self.superview.bounds.size.width - desired));
    self.frame = f;
    [self setNeedsLayout];

    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setFloat:_eyeFullWidth forKey:OX_NS("hist_eye_full_width_resizable_v3")];
    [ud setFloat:f.origin.x forKey:OX_NS("hist_x")];
    [ud setFloat:f.size.width forKey:OX_NS("hist_w")];
    [ud synchronize];
}

- (void)setHidden:(BOOL)hidden {
    [super setHidden:hidden];
    if (hidden && _eyePalette.superview) [_eyePalette removeFromSuperview];
}

- (void)removeFromSuperview {
    if (_eyePalette.superview) [_eyePalette removeFromSuperview];
    [super removeFromSuperview];
}

- (void)eyeChoose:(UIButton *)sender {
    NSUInteger bit = (NSUInteger)1 << (NSUInteger)sender.tag;
    NSUInteger next = _eyeVisibleBits ^ bit;
    NSUInteger count = 0;
    for (NSUInteger i = 0; i < 8; i++) if (next & ((NSUInteger)1 << i)) count++;
    if (count < 4) return;
    _eyeVisibleBits = next;
    [[NSUserDefaults standardUserDefaults] setInteger:(NSInteger)next forKey:OX_NS("hist_eye_visible_bits_v2")];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self eyeResizeToCount:count];

    [self eyeRefreshPalette];
    [self n4q9c1];
    Z0418c1e0ae();
}

- (void)eyeRefreshPalette {
    for (UIView *v in _eyePalette.subviews) {
        if (![v isKindOfClass:[UIButton class]]) continue;
        UIButton *button = (UIButton *)v;
        BOOL visible = (_eyeVisibleBits & ((NSUInteger)1 << (NSUInteger)button.tag)) != 0;
        button.backgroundColor = visible ? RGB(46, 55, 63) : RGB(215, 222, 227);
        button.layer.borderColor = (visible ? RGB(100, 120, 134) : RGB(160, 170, 180)).CGColor;
        button.alpha = visible ? 1.0 : 0.78;
    }
}

- (void)eyePaletteDrag:(UIPanGestureRecognizer *)pan {
    UIView *palette = _eyePalette;
    UIView *parent = palette.superview;
    if (!parent) return;
    if (pan.state == UIGestureRecognizerStateBegan) self.eyePaletteDragOrigin = palette.frame.origin;
    if (pan.state == UIGestureRecognizerStateChanged) {
        CGPoint delta = [pan translationInView:parent];
        CGRect frame = palette.frame;
        frame.origin.x = MAX(0.0, MIN(parent.bounds.size.width - frame.size.width, self.eyePaletteDragOrigin.x + delta.x));
        frame.origin.y = MAX(0.0, MIN(parent.bounds.size.height - frame.size.height, self.eyePaletteDragOrigin.y + delta.y));
        palette.frame = frame;
    }
    if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setFloat:palette.frame.origin.x forKey:OX_NS("hist_eye_palette_x_v16")];
        [ud setFloat:palette.frame.origin.y forKey:OX_NS("hist_eye_palette_y_v16")];
        [ud setBool:YES forKey:OX_NS("hist_eye_palette_moved_v16")];
        [ud synchronize];
    }
}

- (void)f7m2k6:(UIButton *)sender {
    Z0418c1e0ae();
    if (_eyePalette.superview) {
        [_eyePalette removeFromSuperview];
        return;
    }
    UIView *parent = self.superview;
    if (!parent) return;
    CGFloat cell = 46.0;
    CGFloat spacing = 5.0;
    CGFloat width = 4.0 * cell + 5.0 * spacing;
    CGFloat handleHeight = 0.0;
    CGFloat height = 2.0 * cell + 3.0 * spacing;
    CGFloat x = MAX(3.0, MIN(CGRectGetMidX(self.frame) - width * 0.5, parent.bounds.size.width - width - 3.0));
    CGFloat y = CGRectGetMaxY(self.frame) + 4.0;
    if (y + height > parent.bounds.size.height - 8.0) y = MAX(8.0, CGRectGetMinY(self.frame) - height - 4.0);
    NSUserDefaults *paletteDefaults = [NSUserDefaults standardUserDefaults];
    if ([paletteDefaults boolForKey:OX_NS("hist_eye_palette_moved_v16")]) {
        x = MAX(0.0, MIN([paletteDefaults floatForKey:OX_NS("hist_eye_palette_x_v16")], parent.bounds.size.width - width));
        y = MAX(0.0, MIN([paletteDefaults floatForKey:OX_NS("hist_eye_palette_y_v16")], parent.bounds.size.height - height));
    }
    if (!_eyePalette) {
        _eyePalette = [[UIView alloc] initWithFrame:CGRectZero];
        _eyePalette.backgroundColor = RGB(35, 43, 50);
        _eyePalette.layer.cornerRadius = 10.0;
        _eyePalette.layer.borderWidth = 1.0;
        _eyePalette.layer.borderColor = RGB(110, 125, 135).CGColor;
        UIPanGestureRecognizer *palettePan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(eyePaletteDrag:)];
        palettePan.minimumNumberOfTouches = 1;
        palettePan.maximumNumberOfTouches = 1;
        palettePan.cancelsTouchesInView = NO;
        palettePan.delaysTouchesBegan = NO;
        [_eyePalette addGestureRecognizer:palettePan];
        for (NSUInteger i = 0; i < 8; i++) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.tag = (NSInteger)i;
            button.frame = CGRectMake(spacing + (i % 4) * (cell + spacing), handleHeight + spacing + (i / 4) * (cell + spacing), cell, cell);
            button.layer.cornerRadius = 6.0;
            button.layer.borderWidth = 1.0;
            button.imageView.contentMode = UIViewContentModeScaleAspectFit;
            UIImage *icon = OngnongCounterIconImage(self.t6m1v8[i].p4x9c3);
            [button setImage:icon forState:UIControlStateNormal];
            button.imageEdgeInsets = UIEdgeInsetsMake(5.0, 5.0, 5.0, 5.0);
            [button addTarget:self action:@selector(eyeChoose:) forControlEvents:UIControlEventTouchUpInside];
            [_eyePalette addSubview:button];
        }
    }
    _eyePalette.frame = CGRectMake(x, y, width, height);
    [parent addSubview:_eyePalette];

    [self eyeRefreshPalette];
}

- (NSArray<Z6dcb301a04 *> *)zefc0e4e6bd {
    NSMutableArray<Z6dcb301a04 *> *visible = [NSMutableArray arrayWithCapacity:self.t6m1v8.count];
    for (Z6dcb301a04 *card in self.t6m1v8) {
        BOOL show = [self t3p8x4:card.p4x9c3];
        card.hidden = !show;
        if (show) [visible addObject:card];
    }
    return visible;
}

- (NSArray<Zc1dba0f365 *> *)z7d5c8a0f42 {
    NSMutableArray<Zc1dba0f365 *> *visible = [NSMutableArray arrayWithCapacity:self.p7k4n2.count];
    for (Zc1dba0f365 *column in self.p7k4n2) {
        BOOL show = [self t3p8x4:column.p4x9c3];
        column.hidden = !show;
        if (show) [visible addObject:column];
    }
    return visible;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = RGB(31, 13, 24);
    ApplyNeon(self, RGB(245, 169, 53), 18.0, 1.2);
    self.layer.shadowOpacity = 0.0;
    self.clipsToBounds = NO;
    NSUserDefaults *eyeDefaults = [NSUserDefaults standardUserDefaults];
    _eyeVisibleBits = [eyeDefaults objectForKey:OX_NS("hist_eye_visible_bits_v2")] ? ((NSUInteger)[eyeDefaults integerForKey:OX_NS("hist_eye_visible_bits_v2")] & 255) : 255;
    NSUInteger visibleCount = 0;
    for (NSUInteger i = 0; i < 8; i++) if (_eyeVisibleBits & ((NSUInteger)1 << i)) visibleCount++;
    if (visibleCount < 4) { _eyeVisibleBits = 255; visibleCount = 8; }
    if (![eyeDefaults boolForKey:OX_NS("hist_eye_compact_v4_initialized")]) {
        [eyeDefaults setFloat:280.0 forKey:OX_NS("hist_eye_full_width_resizable_v3")];
        [eyeDefaults setBool:YES forKey:OX_NS("hist_eye_compact_v4_initialized")];
        [eyeDefaults synchronize];
    }
    _eyeFullWidth = [eyeDefaults floatForKey:OX_NS("hist_eye_full_width_resizable_v3")];
    if (_eyeFullWidth < 210.0) _eyeFullWidth = 280.0;
    _eyeFullWidth = MIN(_eyeFullWidth, MAX(210.0, UIScreen.mainScreen.bounds.size.width - 16.0));
    CGRect eyeFrame = self.frame;
    CGFloat eyeCellWidth = (_eyeFullWidth - 38.0) / 8.0;
    eyeFrame.size.width = (10.0 + eyeCellWidth * (CGFloat)visibleCount + 4.0 * (CGFloat)(visibleCount - 1));
    self.frame = eyeFrame;


    _title = Label(
        Ongnong::Zx8fUILabel(OX_NS("counter_title"), OX_NS("ONGNONG.io.vn")),
        13.0,
        UIFontWeightBlack,
        ZThemeWhite(),
        NSTextAlignmentCenter);
    _title.numberOfLines = 1;
    _title.adjustsFontSizeToFitWidth = YES;
    _title.minimumScaleFactor = 0.34;
    _title.lineBreakMode = NSLineBreakByClipping;
    if (@available(iOS 9.0, *)) _title.allowsDefaultTighteningForTruncation = YES;
    _title.layer.shadowColor = RGB(255, 120, 20).CGColor;
    _title.layer.shadowOpacity = 0.0;
    _title.layer.shadowRadius = 0.0;
    _title.layer.shadowOffset = CGSizeZero;
    _title.userInteractionEnabled = YES;
    [self addSubview:_title];

    _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_closeButton setTitle:qsec_s_0068() forState:UIControlStateNormal];
    [_closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightHeavy];
    _closeButton.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_closeButton, ZThemeBorder(), 6.0, 0.75);
    _closeButton.layer.shadowOpacity = 0.30;
    [_closeButton addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_closeButton];

    _k3v9d4 = [UIButton buttonWithType:UIButtonTypeCustom];
    ZPlainIconButton(_k3v9d4, ZCounterTrashIconImage());
    [_k3v9d4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:_k3v9d4];

    _legacySwitchButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_legacySwitchButton setTitle:@"🔄" forState:UIControlStateNormal];
    [_legacySwitchButton setTitleColor:RGB(90, 235, 255) forState:UIControlStateNormal];
    _legacySwitchButton.titleLabel.font = [UIFont boldSystemFontOfSize:15.0];
    [_legacySwitchButton addTarget:self action:@selector(zSwitchCounterIcons:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_legacySwitchButton];

    _eyeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    ZPlainIconButton(_eyeButton, ZCounterEyeIconImage(NO));
    [_eyeButton addTarget:self action:@selector(f7m2k6:) forControlEvents:UIControlEventTouchUpInside];
    _eyeButton.hidden = YES;
    [self addSubview:_eyeButton];

    Z6dcb301a04 *shieldCard = [[Z6dcb301a04 alloc] initWithC7q3x9:OX_NS("KHIÊN") fallback:OX_NS("KHIÊN") color:Z07aec8e446(Zshield5e2026) index:Zshield5e2026];
    Z6dcb301a04 *c0 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0021() fallback:qsec_s_0069() color:Z07aec8e446(Z700020a485) index:Z700020a485];
    Z6dcb301a04 *c1 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0023() fallback:qsec_s_0070() color:Z07aec8e446(Z124338f2d8) index:Z124338f2d8];
    Z6dcb301a04 *c2 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0025() fallback:qsec_s_0071() color:Z07aec8e446(Z94881eb8d3) index:Z94881eb8d3];
    Z6dcb301a04 *c3 = [[Z6dcb301a04 alloc] initWithC7q3x9:qsec_s_0027() fallback:qsec_s_0072() color:Z07aec8e446(Z646dcbe562) index:Z646dcbe562];
    Z6dcb301a04 *c4 = [[Z6dcb301a04 alloc] initWithC7q3x9:[NSString string] fallback:[NSString string] color:Z07aec8e446(Z2f0c1a9d77) index:Z2f0c1a9d77];
    Z6dcb301a04 *c5 = [[Z6dcb301a04 alloc] initWithC7q3x9:[NSString string] fallback:Ongnong::Z57eb159d41(Z87f6d0c11d) color:Z07aec8e446(Z87f6d0c11d) index:Z87f6d0c11d];
    Z6dcb301a04 *c6 = [[Z6dcb301a04 alloc] initWithC7q3x9:[NSString string] fallback:Ongnong::Z57eb159d41(Z5d92a7e4c1) color:Z07aec8e446(Z5d92a7e4c1) index:Z5d92a7e4c1];
    _t6m1v8 = @[c0, c1, c2, shieldCard, c3, c4, c5, c6];
    for (UIView *v in _t6m1v8) {
        v.userInteractionEnabled = NO;
        [self addSubview:v];
    }

    _d9q3x5 = [[UIView alloc] initWithFrame:CGRectZero];
    _d9q3x5.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.10];
    _d9q3x5.clipsToBounds = YES;
    _d9q3x5.userInteractionEnabled = YES;
    _d9q3x5.layer.cornerRadius = 7.0;
    _d9q3x5.layer.borderWidth = 0.0;
    _d9q3x5.layer.shadowOpacity = 0.0;
    [self addSubview:_d9q3x5];

    Zc1dba0f365 *shieldHistory = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Zshield5e2026) index:Zshield5e2026];
    Zc1dba0f365 *h0 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z700020a485) index:Z700020a485];
    Zc1dba0f365 *h1 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z124338f2d8) index:Z124338f2d8];
    Zc1dba0f365 *h2 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z94881eb8d3) index:Z94881eb8d3];
    Zc1dba0f365 *h3 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z646dcbe562) index:Z646dcbe562];
    Zc1dba0f365 *h4 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z2f0c1a9d77) index:Z2f0c1a9d77];
    Zc1dba0f365 *h5 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z87f6d0c11d) index:Z87f6d0c11d];
    Zc1dba0f365 *h6 = [[Zc1dba0f365 alloc] initWithD2n6k4:Z07aec8e446(Z5d92a7e4c1) index:Z5d92a7e4c1];
    _p7k4n2 = @[h0, h1, h2, shieldHistory, h3, h4, h5, h6];
    for (UIView *v in _p7k4n2) {
        v.clipsToBounds = YES;
        [_d9q3x5 addSubview:v];
    }

    _y1m5x9 = Label(OX_NS("↘"), 18.0, UIFontWeightHeavy, RGB(120, 220, 255), NSTextAlignmentCenter);
    _y1m5x9.userInteractionEnabled = YES;
    _y1m5x9.alpha = 0.75;
    [self addSubview:_y1m5x9];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(a3v7c2:)];
    pan.cancelsTouchesInView = NO;
    pan.delaysTouchesBegan = NO;
    pan.delaysTouchesEnded = NO;
    pan.delegate = self;
    [self addGestureRecognizer:pan];

    [self n4q9c1];
    return self;
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;

    CGFloat margin = 5.0;
    CGFloat gap = 4.0;
    CGFloat titleY = 3.0;
    CGFloat titleH = 17.0;
    BOOL compactHeader = NO;
    CGFloat iconTop = 27.0;
    CGFloat iconH = MIN(88.0, MAX(20.0, (_eyeFullWidth - margin * 2.0 - gap * 7.0) / 8.0 * 0.94));
    CGFloat historyY = iconTop + iconH + 1.0;
    CGFloat bottomPad = 5.0;

    self.layer.cornerRadius = 12.0;
    UIView *headerStrip = [self viewWithTag:987641];
    if (!headerStrip) {
        headerStrip = [[UIView alloc] initWithFrame:CGRectZero];
        headerStrip.tag = 987641;
        headerStrip.userInteractionEnabled = NO;
        headerStrip.layer.cornerRadius = 0.0;
        [self insertSubview:headerStrip atIndex:0];
    }
    CGFloat headerWidth = w;
    CGFloat headerOffset = 0.0;
    headerStrip.backgroundColor = self.backgroundColor;
    headerStrip.layer.borderColor = self.layer.borderColor;
    headerStrip.layer.borderWidth = 0.0;
    headerStrip.frame = CGRectMake(0.0, 0.0, headerWidth, 26.0);

    [self q6v1d9];
    CGFloat controlSize = 22.0;
    CGFloat leftPadding = 3.0;
    CGFloat rightPadding = 3.0;
    CGFloat controlSpacing = 2.0;
    _k3v9d4.frame = CGRectMake(leftPadding, 2.0, controlSize, controlSize);
    _k3v9d4.contentEdgeInsets = UIEdgeInsetsZero;
    _legacySwitchButton.frame = CGRectMake(CGRectGetMaxX(_k3v9d4.frame) + controlSpacing, 2.0, controlSize, controlSize);
    _legacySwitchButton.titleLabel.adjustsFontSizeToFitWidth = YES;
    _legacySwitchButton.titleLabel.minimumScaleFactor = 0.75;
    _legacySwitchButton.contentEdgeInsets = UIEdgeInsetsZero;
    _legacySwitchButton.titleLabel.font = [UIFont systemFontOfSize:18.0 weight:UIFontWeightBold];
    _closeButton.frame = CGRectMake(w - rightPadding - controlSize, 2.0, controlSize, controlSize);
    _closeButton.layer.cornerRadius = 6.0;
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightHeavy];
    BOOL showEye = !_eyeButton.hidden && [self w8c2m5];
    CGFloat eyeX = CGRectGetMinX(_closeButton.frame) - controlSpacing - controlSize;
    _eyeButton.frame = CGRectMake(eyeX, 2.0, controlSize, controlSize);
    CGFloat titleLeft = CGRectGetMaxX(_legacySwitchButton.frame) + 3.0;
    CGFloat titleRight = (showEye ? eyeX : CGRectGetMinX(_closeButton.frame)) - 3.0;
    CGFloat titleW = MAX(0.0, titleRight - titleLeft);
    NSString *headerText = _title.text ?: @"";
    CGFloat maxFont = 11.0;
    CGFloat minFont = 7.0;
    UIFont *measureFont = [UIFont systemFontOfSize:maxFont weight:UIFontWeightBlack];
    CGFloat textWidth = ceil([headerText sizeWithAttributes:@{NSFontAttributeName:measureFont}].width) + 2.0;
    CGFloat fittedFont = textWidth > 0.0 ? MIN(maxFont, maxFont * titleW / textWidth) : maxFont;
    BOOL titleFits = titleW > 0.0 && fittedFont >= minFont;
    _title.hidden = !titleFits;
    _title.font = [UIFont systemFontOfSize:MAX(minFont, fittedFont) weight:UIFontWeightBlack];
    _title.adjustsFontSizeToFitWidth = NO;
    _title.numberOfLines = 1;
    _title.lineBreakMode = NSLineBreakByClipping;
    _title.textAlignment = NSTextAlignmentCenter;
    _title.frame = titleFits ? CGRectMake(titleLeft, 3.0, titleW, 19.0) : CGRectZero;

    NSArray<Z6dcb301a04 *> *visibleCards = [self zefc0e4e6bd];
    NSUInteger cardCount = MAX((NSUInteger)1, visibleCards.count);
    CGFloat cardW = MIN((_eyeFullWidth - margin * 2.0 - gap * 7.0) / 8.0, MAX(12.0, (w - margin * 2.0 - gap * (CGFloat)(cardCount - 1)) / (CGFloat)cardCount));
    CGFloat contentWidth = cardW * (CGFloat)cardCount + gap * (CGFloat)(cardCount - 1);
    CGFloat contentX = MAX(margin, (w - contentWidth) * 0.5);
    CGFloat slotStep = cardW + gap;
    for (NSUInteger i = 0; i < visibleCards.count; i++) {
        Z6dcb301a04 *card = visibleCards[i];
        card.layer.cornerRadius = 7.0;
        card.frame = CGRectMake(contentX + slotStep * i, iconTop, cardW, iconH);
    }

    CGFloat boxH = MAX(34.0, h - historyY - bottomPad);
    _d9q3x5.frame = CGRectMake(margin, historyY, w - margin * 2.0, boxH);
    _d9q3x5.layer.cornerRadius = 7.0;

    NSArray<Zc1dba0f365 *> *visibleColumns = [self z7d5c8a0f42];
    NSUInteger columnCount = MAX((NSUInteger)1, visibleColumns.count);
    CGFloat colW = slotStep;
    CGFloat historyStartX = contentX - margin;
    for (NSUInteger i = 0; i < visibleColumns.count; i++) {
        Zc1dba0f365 *column = visibleColumns[i];
        CGFloat columnWidth = (i + 1 == visibleColumns.count) ? cardW : colW;
        column.frame = CGRectMake(historyStartX + colW * i, 0.0, columnWidth, _d9q3x5.bounds.size.height);
        if (i > 0) {
            UIView *line = [_d9q3x5 viewWithTag:8000 + i];
            if (!line) {
                line = [[UIView alloc] initWithFrame:CGRectZero];
                line.tag = 8000 + i;
                line.backgroundColor = ZThemeBorder();
                line.alpha = 0.24;
                [_d9q3x5 addSubview:line];
            }
            line.hidden = NO;
            line.frame = CGRectMake(historyStartX + colW * i, 0.0, 1.0, _d9q3x5.bounds.size.height);
            [_d9q3x5 bringSubviewToFront:line];
        }
    }
    for (NSUInteger i = visibleColumns.count; i < _p7k4n2.count; i++) {
        UIView *line = [_d9q3x5 viewWithTag:8000 + i];
        if (line) line.hidden = YES;
    }

    CGFloat gapLineY = MIN(25.0, MAX(21.0, colW * 0.23));
    UIView *gapLine = [_d9q3x5 viewWithTag:8900];
    if (!gapLine) {
        gapLine = [[UIView alloc] initWithFrame:CGRectZero];
        gapLine.tag = 8900;
        gapLine.backgroundColor = ZThemeBorder();
        gapLine.alpha = 0.36;
        [_d9q3x5 addSubview:gapLine];
    }
    gapLine.frame = CGRectMake(0.0, gapLineY, _d9q3x5.bounds.size.width, 1.0);
    [_d9q3x5 bringSubviewToFront:gapLine];

    CGFloat rowStartY = gapLineY + 2.0;
    CGFloat rowH = 15.5;
    NSInteger maxLines = MIN(ZHistoryVisibleRows, (NSInteger)((_d9q3x5.bounds.size.height - rowStartY) / rowH));
    for (NSInteger r = 1; r <= maxLines; r++) {
        UIView *rowLine = [_d9q3x5 viewWithTag:9000 + r];
        if (!rowLine) {
            rowLine = [[UIView alloc] initWithFrame:CGRectZero];
            rowLine.tag = 9000 + r;
            rowLine.backgroundColor = ZThemeBorder();
            rowLine.alpha = 0.10;
            [_d9q3x5 addSubview:rowLine];
        }
        rowLine.hidden = NO;
        rowLine.frame = CGRectMake(0.0, rowStartY + rowH * r, _d9q3x5.bounds.size.width, 1.0);
        [_d9q3x5 bringSubviewToFront:rowLine];
    }
    for (NSInteger r = maxLines + 1; r <= ZHistoryVisibleRows; r++) {
        UIView *oldLine = [_d9q3x5 viewWithTag:9000 + r];
        if (oldLine) oldLine.hidden = YES;
    }

    _y1m5x9.frame = CGRectMake(w - 24.0, h - 24.0, 24.0, 24.0);
}

- (void)a3v7c2:(UIPanGestureRecognizer *)pan {
    UIView *superview = self.superview;
    if (!superview) return;

    if (pan.state == UIGestureRecognizerStateBegan) {
        _h9m2d5 = self.frame;
        _x3q8c6 = [pan locationInView:self];
        BOOL inResizeCorner = (_x3q8c6.x >= self.bounds.size.width - 32.0 && _x3q8c6.y >= self.bounds.size.height - 32.0);
        _v4p7k1 = inResizeCorner ? 2 : 1;
        _c8n3q6 = YES;
    }

    if (pan.state == UIGestureRecognizerStateChanged) {
        if (_v4p7k1 == 2) {
            CGPoint p = [pan locationInView:superview];
            CGRect f = _h9m2d5;
            CGFloat minH = Zed1192a6d1;
            CGFloat maxH = MIN(superview.bounds.size.height - f.origin.y - 34.0, 430.0);
            NSUInteger activeCount = MAX((NSUInteger)4, [[self zefc0e4e6bd] count]);
            CGFloat minFullWidth = 210.0;
            CGFloat maxFullWidth = MAX(minFullWidth, MIN(superview.bounds.size.width - 16.0, UIScreen.mainScreen.bounds.size.width - 16.0));
            CGFloat requestedFullWidth = 38.0 + 8.0 * ((p.x - f.origin.x - 10.0 - 4.0 * (CGFloat)(activeCount - 1)) / (CGFloat)activeCount);
            _eyeFullWidth = MAX(minFullWidth, MIN(maxFullWidth, requestedFullWidth));
            CGFloat cellWidth = (_eyeFullWidth - 38.0) / 8.0;
            f.size.width = MIN(maxFullWidth, 10.0 + cellWidth * (CGFloat)activeCount + 4.0 * (CGFloat)(activeCount - 1));
            f.size.height = MAX(minH, MIN(maxH, p.y - f.origin.y));
            self.frame = f;
            [self setNeedsLayout];
        } else if (_v4p7k1 == 1) {
            CGPoint p = [pan locationInView:superview];
            CGRect f = self.frame;
            f.origin.x = p.x - _x3q8c6.x;
            f.origin.y = p.y - _x3q8c6.y;

            CGFloat visible = 24.0;
            f.origin.x = MAX(visible - f.size.width, MIN(superview.bounds.size.width - visible, f.origin.x));
            f.origin.y = MAX(visible - f.size.height, MIN(superview.bounds.size.height - visible, f.origin.y));
            self.frame = f;
        }
    }

    if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled || pan.state == UIGestureRecognizerStateFailed) {
        NSInteger eyeCompletedAction = _v4p7k1;
        _v4p7k1 = 0;
        _c8n3q6 = NO;
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setFloat:self.frame.origin.x forKey:OX_NS("hist_x")];
        [ud setFloat:self.frame.origin.y forKey:OX_NS("hist_y")];
        [ud setFloat:self.frame.size.width forKey:OX_NS("hist_w")];
        NSUInteger eyeCount = 0;
        for (NSUInteger i = 0; i < 8; i++) if (_eyeVisibleBits & ((NSUInteger)1 << i)) eyeCount++;
        if (eyeCount >= 4) {
            [ud setFloat:_eyeFullWidth forKey:OX_NS("hist_eye_full_width_resizable_v3")];
        }
        [ud setFloat:self.frame.size.height forKey:OX_NS("hist_h")];
        [ud synchronize];

        [self setNeedsLayout];
        [self n4q9c1];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    UIView *touched = touch.view;
    if (touched == _closeButton || [touched isDescendantOfView:_closeButton]) return NO;
    if (touched == _k3v9d4 || [touched isDescendantOfView:_k3v9d4]) return NO;
    if (touched == _legacySwitchButton || [touched isDescendantOfView:_legacySwitchButton]) return NO;
    if (touched == _eyeButton || [touched isDescendantOfView:_eyeButton]) return NO;

    CGPoint p = [touch locationInView:self];
    BOOL inResizeCorner = (p.x >= self.bounds.size.width - 34.0 && p.y >= self.bounds.size.height - 34.0);
    if (inResizeCorner || touched == _y1m5x9 || [touched isDescendantOfView:_y1m5x9]) return YES;

    if (touched == _d9q3x5 || [touched isDescendantOfView:_d9q3x5]) return YES;
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return NO;
}

- (void)zSwitchCounterIcons:(UIButton *)sender {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setBool:!ZLegacyCounterSelected() forKey:OX_NS("counter_legacy_icons")];
    for (Z6dcb301a04 *card in _t6m1v8) {
        card.c6d9x4.image = OngnongCounterIconImage(card.p4x9c3);
        card.n7q1v6.hidden = card.c6d9x4.image != nil;
    }
    [self n4q9c1];
    [self setNeedsLayout];
    for (Z6dcb301a04 *card in _t6m1v8) [card setNeedsLayout];
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_counter_icon_changed") object:nil];
}

- (void)n4q9c1 {
    _title.text = Ongnong::Zx8fUILabel(OX_NS("counter_title"), OX_NS("ONGNONG.io.vn"));
    [self setNeedsLayout];
    [self q6v1d9];
    for (Z6dcb301a04 *card in _t6m1v8) {
        card.value.hidden = YES;
        card.hidden = ![self t3p8x4:card.p4x9c3];
    }

    for (Zc1dba0f365 *column in [self z7d5c8a0f42]) {
        int idx = (int)column.p4x9c3;
        NSArray<NSNumber *> *items = Zd282eb67ef(idx);

        NSString *gapText = [NSString stringWithFormat:qsec_s_0074(), zce119e8048.zc9f4191bf8[idx]];
        Z3218ec4b5a(column.y8m2d7, gapText, 11.0, 5.2, UIFontWeightBlack);

        NSInteger maxCount = MIN((NSInteger)items.count, (NSInteger)column.a3v6p8.count);

        for (NSInteger i = 0; i < (NSInteger)column.a3v6p8.count; i++) {
            UILabel *row = column.a3v6p8[i];
            if (i < maxCount) {
                Z3218ec4b5a(row, items[i].stringValue, 11.0, 6.0, UIFontWeightHeavy);
                row.hidden = NO;
            } else {
                Z3218ec4b5a(row, [NSString string], 11.0, 6.0, UIFontWeightHeavy);
                row.hidden = YES;
            }
        }
    }
}
@end

@implementation Z9abcb7bb90

- (CGRect)zClampFrame:(CGRect)frame minW:(CGFloat)minW minH:(CGFloat)minH maxW:(CGFloat)maxW maxH:(CGFloat)maxH {
    CGRect bounds = self.view.bounds.size.width > 0 ? self.view.bounds : UIScreen.mainScreen.bounds;
    frame.size.width = MAX(minW, MIN(maxW, frame.size.width));
    frame.size.height = MAX(minH, MIN(maxH, frame.size.height));
    CGFloat visible = 26.0;
    frame.origin.x = MAX(visible - frame.size.width, MIN(bounds.size.width - visible, frame.origin.x));
    frame.origin.y = MAX(42.0, MIN(bounds.size.height - visible, frame.origin.y));
    return frame;
}

- (void)zSaveQuickPanelFrame {
    if (!_a9q2x4 || _f7q2n8) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if (_a6t3y8) {
        [ud setFloat:_a9q2x4.frame.origin.x forKey:OX_NS("alt_ui_x")];
        [ud setFloat:_a9q2x4.frame.origin.y forKey:OX_NS("alt_ui_y")];
        [ud synchronize];
        return;
    }
    [ud setFloat:_a9q2x4.frame.origin.x forKey:OX_NS("tool_x")];
    [ud setFloat:_a9q2x4.frame.origin.y forKey:OX_NS("tool_y")];
    [ud setFloat:_a9q2x4.frame.size.width forKey:OX_NS("tool_w")];
    [ud setFloat:_a9q2x4.frame.size.height forKey:OX_NS("tool_h")];
    [ud synchronize];
}

- (void)q1c8v4 {
    if (!_a9q2x4) return;
    if (!_f7q2n8) {
        [_a9q2x4 layoutIfNeeded];
        _p4m9c1 = _a9q2x4.frame;
        [self zSaveQuickPanelFrame];
        CGPoint middlePoint = CGPointMake((CGRectGetMaxX(_a9q2x4.c8x1p4.frame) + CGRectGetMinX(_a9q2x4.v6q2m8.frame))/2.0, CGRectGetMidY(_a9q2x4.bounds));
        CGPoint middleCenter = [_a9q2x4 convertPoint:middlePoint toView:self.view];
        CGFloat side = _a9q2x4.a1v8m3 ? 66.0 : MAX(60.0, _a9q2x4.bounds.size.height * 1.45);
        middleCenter.x = MAX(side/2.0, MIN(self.view.bounds.size.width-side/2.0, middleCenter.x));
        middleCenter.y = MAX(42.0+side/2.0, MIN(self.view.bounds.size.height-side/2.0, middleCenter.y));
        _f7q2n8 = YES;
        _a9q2x4.q6m2v8 = YES;
        _a9q2x4.bounds = CGRectMake(0, 0, side, side);
        _a9q2x4.center = middleCenter;
        [_a9q2x4 setNeedsLayout];
        [_a9q2x4 layoutIfNeeded];
        if (_a6t3y8) {
            _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = YES;
            _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = YES;
        }
    } else {
        CGPoint popupCenter = _a9q2x4.center;
        CGRect restored = CGRectIsEmpty(_p4m9c1) ? (_a6t3y8 ? CGRectMake(0, 0, 230.0, 114.0) : CGRectMake(0, 0, 360.0*z067adc83c5(), 66.0*z067adc83c5())) : _p4m9c1;
        _f7q2n8 = NO;
        _a9q2x4.q6m2v8 = NO;
        CGRect sizingFrame = _a9q2x4.frame;
        sizingFrame.size = restored.size;
        _a9q2x4.frame = sizingFrame;
        [_a9q2x4 setNeedsLayout];
        [_a9q2x4 layoutIfNeeded];
        CGPoint middlePoint = CGPointMake((CGRectGetMaxX(_a9q2x4.c8x1p4.frame) + CGRectGetMinX(_a9q2x4.v6q2m8.frame))/2.0, CGRectGetMidY(_a9q2x4.bounds));
        restored.origin.x = popupCenter.x - middlePoint.x;
        restored.origin.y = popupCenter.y - middlePoint.y;
        if (_a6t3y8) {
            restored.origin.x = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - restored.size.width - 4.0), restored.origin.x));
            restored.origin.y = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - restored.size.height - 4.0), restored.origin.y));
        } else {
            restored = [self zClampFrame:restored minW:restored.size.width minH:restored.size.height maxW:restored.size.width maxH:restored.size.height];
        }
        _a9q2x4.frame = restored;
        _p4m9c1 = restored;
        [self zSaveQuickPanelFrame];
        if (_a6t3y8) {
            _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = NO;
            _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = NO;
        }
    }
    [self.view bringSubviewToFront:_a9q2x4];
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)q9d3m6 {
    BOOL allowed = Ongnong::Zx8fBetCycleAllowed();
    BOOL isVIP = Ongnong::Zx8fIsVIP();
    Ongnong::R3ni(allowed);
    Zcb66126fa3 *button = _v2p6k1.a7m1c5.count > 11 ? _v2p6k1.a7m1c5[11] : nil;
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *key = OX_NS("ongnong_main_visible_11");
    BOOL personallyHidden = [prefs objectForKey:key] && ![prefs boolForKey:key];
    BOOL shouldHide = (!allowed && isVIP) || personallyHidden;
    BOOL layoutChanged = button && button.hidden != shouldHide;
    if (button) {
        button.hidden = shouldHide;
        button.enabled = allowed || !isVIP;
        button.alpha = allowed ? 1.0 : (isVIP ? 0.0 : 0.36);
    }
    if (!allowed && _q72p9m4) _q72p9m4.hidden = YES;
    if (layoutChanged) [_v2p6k1 setNeedsLayout];
}

- (void)zSaveCounterPanelFrame {
    if (!_n7c3m8) return;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setFloat:_n7c3m8.frame.origin.x forKey:OX_NS("hist_x")];
    [ud setFloat:_n7c3m8.frame.origin.y forKey:OX_NS("hist_y")];
    [ud setFloat:_n7c3m8.frame.size.width forKey:OX_NS("hist_w")];
    [ud setFloat:_n7c3m8.frame.size.height forKey:OX_NS("hist_h")];
    [ud synchronize];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    _zAltFloatButtons = [NSMutableDictionary dictionary];
    if (!Ongnong::AutoBuildModuleIsEnabled() && !Ongnong::AutoBuildModuleIsPending()) Ongnong::AutoBuildModuleSetEnabled(false);
    Ongnong::RaidHammerModuleSetEnabled(false);
    Ongnong::MagicCardsModuleSetEnabled(false);
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:OX_NS("ot_running")];
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:ZThemeVisibleKey()];
    CGFloat s = z067adc83c5();
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat menuW = 214 * s;
    CGFloat menuH = 560 * s;
    if (menuH > screen.size.height - 88 * s) menuH = screen.size.height - 88 * s;
    CGFloat menuX = 6.0 * s;
    CGFloat menuY = MAX(36.0 * s, floor((screen.size.height - menuH) * 0.5));
    _v2p6k1 = [[Za540ef69c7 alloc] initWithFrame:CGRectMake(menuX, menuY, menuW, menuH)];
    _x5m9c2 = _v2p6k1.frame;
    [self.view addSubview:_v2p6k1];

    _b3n7v1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [_b3n7v1 setTitle:qsec_s_0038() forState:UIControlStateNormal];
    [_b3n7v1 setTitleColor:RGB(160, 250, 255) forState:UIControlStateNormal];
    _b3n7v1.titleLabel.font = [UIFont systemFontOfSize:zb1d8336499(24.0, 15.0) weight:UIFontWeightHeavy];
    _b3n7v1.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_b3n7v1, ZThemeBorder(), 9.0, 1.0);
    [_b3n7v1 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:_b3n7v1];
    [self z3q7d9];

    CGFloat quickW = MIN(screen.size.width - 28.0 * s, 360.0 * s);
    CGFloat quickH = 66 * s;
    _a9q2x4 = [[Z4c5163ab2a alloc] initWithFrame:CGRectMake(0, 0, quickW, quickH)];
    [self.view addSubview:_a9q2x4];
    NSUserDefaults *toolUd = [NSUserDefaults standardUserDefaults];
    if ([toolUd objectForKey:OX_NS("tool_x")]) {
        CGFloat tx = [toolUd floatForKey:OX_NS("tool_x")];
        CGFloat ty = [toolUd floatForKey:OX_NS("tool_y")];
        _a9q2x4.frame = [self zClampFrame:CGRectMake(tx, ty, quickW, quickH) minW:quickW minH:quickH maxW:quickW maxH:quickH];
    } else {
        [self p8c4n2];
    }
    _p4m9c1 = _a9q2x4.frame;
    NSInteger savedSlot = [[NSUserDefaults standardUserDefaults] integerForKey:Z0f21de981b()];
    _z4b51d86a09 = [self z3f0b8e15a2:savedSlot];
    _h1x9c5 = NO;
    _a9q2x4.hidden = NO;
    [self.view bringSubviewToFront:_a9q2x4];

    CGFloat atX = MAX(8.0, MIN(screen.size.width - 166.0 - 8.0, CGRectGetMaxX(_v2p6k1.frame) + 10.0));
    CGFloat atY = MAX(42.0, MIN(screen.size.height - 88.0 - 8.0, CGRectGetMinY(_v2p6k1.frame) + 30.0));
    NSUserDefaults *atUd = [NSUserDefaults standardUserDefaults];
    if ([atUd objectForKey:OX_NS("ot_x")]) atX = [atUd floatForKey:OX_NS("ot_x")];
    if ([atUd objectForKey:OX_NS("ot_y")]) atY = [atUd floatForKey:OX_NS("ot_y")];
    _d2q8n4 = [[Zd4f227a905 alloc] initWithFrame:CGRectMake(atX, atY, 166.0, 88.0)];
    _d2q8n4.hidden = YES;
    [self.view addSubview:_d2q8n4];

    NSUserDefaults *bcUd = [NSUserDefaults standardUserDefaults];
    CGFloat bcX = [bcUd objectForKey:OX_NS("ongnong_bet_cycle_ui_x")] ? [bcUd floatForKey:OX_NS("ongnong_bet_cycle_ui_x")] : MAX(8.0, screen.size.width - 290.0);
    CGFloat bcY = [bcUd objectForKey:OX_NS("ongnong_bet_cycle_ui_y")] ? [bcUd floatForKey:OX_NS("ongnong_bet_cycle_ui_y")] : 42.0;
    _q72p9m4 = [[X4f0a1 alloc] initWithFrame:CGRectMake(bcX, bcY, 330.0, 286.0)];
    _q72p9m4.hidden = YES;
    [self.view addSubview:_q72p9m4];

    CGFloat colorW = 208.0;
    CGFloat colorH = 190.0;
    CGFloat colorX = MAX(8.0, MIN(screen.size.width - colorW - 8.0, CGRectGetMaxX(_v2p6k1.frame) + 10.0));
    CGFloat colorY = MAX(42.0, MIN(screen.size.height - colorH - 8.0, CGRectGetMinY(_v2p6k1.frame) + 160.0));
    NSUserDefaults *colorUd = [NSUserDefaults standardUserDefaults];
    if ([colorUd objectForKey:ZThemePosXKey()]) colorX = [colorUd floatForKey:ZThemePosXKey()];
    if ([colorUd objectForKey:ZThemePosYKey()]) colorY = [colorUd floatForKey:ZThemePosYKey()];
    _w7p3v6 = [[Z8x4c2v7 alloc] initWithFrame:CGRectMake(colorX, colorY, colorW, colorH)];
    _w7p3v6.hidden = ![colorUd boolForKey:ZThemeVisibleKey()];
    [self.view addSubview:_w7p3v6];
    [self r9b4t1];
    [self z8a5c1];

    NSArray<NSString *> *menuKeys = @[OX_NS("update"),OX_NS("buy_vip"),OX_NS("history"),OX_NS("auto_build"),OX_NS("pig_hammer"),OX_NS("magic_cards"),OX_NS("auto_click"),OX_NS("tools"),OX_NS("auto_stop"),OX_NS("menu_color"),OX_NS("auto_expedition"),OX_NS("bet_cycle"),OX_NS("auto_merge"),OX_NS("friend_invite"),OX_NS("potion"),OX_NS("interface")];
    for (NSUInteger i = 0; i < MIN(menuKeys.count, _v2p6k1.a7m1c5.count); i++) {
        UILongPressGestureRecognizer *hold = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(zRenameMenuHold:)];
        hold.minimumPressDuration = 3.0;
        hold.cancelsTouchesInView = YES;
        hold.name = menuKeys[i];
        [_v2p6k1.a7m1c5[i] addGestureRecognizer:hold];
    }
    [_v2p6k1.a7m1c5[0] addTarget:self action:@selector(k7p2m6) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 1) [_v2p6k1.a7m1c5[1] addTarget:self action:@selector(d4u8s0) forControlEvents:UIControlEventTouchUpInside];
    [_v2p6k1.k3v9d4 addTarget:self action:@selector(zShowBuyVipRegionPicker) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 2) [_v2p6k1.a7m1c5[2] addTarget:self action:@selector(l4m8k3) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 3) [_v2p6k1.a7m1c5[3] addTarget:self action:@selector(m8c2r6) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 4) [_v2p6k1.a7m1c5[4] addTarget:self action:@selector(f5n9x1) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 5) [_v2p6k1.a7m1c5[5] addTarget:self action:@selector(a7q3d8) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 6) [_v2p6k1.a7m1c5[6] addTarget:self action:@selector(e9m1p7) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 7) [_v2p6k1.a7m1c5[7] addTarget:self action:@selector(b4x8c3) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 8) [_v2p6k1.a7m1c5[8] addTarget:self action:@selector(t6r2n9) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 9) [_v2p6k1.a7m1c5[9] addTarget:self action:@selector(j3v7q5) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 10) [_v2p6k1.a7m1c5[10] addTarget:self action:@selector(h5p1k8) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 11) [_v2p6k1.a7m1c5[11] addTarget:self action:@selector(v7b2c9) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 12) [_v2p6k1.a7m1c5[12] addTarget:self action:@selector(z6m4a8) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 13) [_v2p6k1.a7m1c5[13] addTarget:self action:@selector(ongFriendModule) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 14) [_v2p6k1.a7m1c5[14] addTarget:self action:@selector(ongPotionModule) forControlEvents:UIControlEventTouchUpInside];
    if (_v2p6k1.a7m1c5.count > 15) [_v2p6k1.a7m1c5[15] addTarget:self action:@selector(zToggleInterface) forControlEvents:UIControlEventTouchUpInside];
    [_v2p6k1.k3v9d4 addTarget:self action:@selector(x1c7p5) forControlEvents:UIControlEventTouchUpInside];
    [_v2p6k1.r6q2p8 addTarget:self action:@selector(c8x3n6) forControlEvents:UIControlEventTouchUpInside];
    [_b3n7v1 addTarget:self action:@selector(q6d9b2) forControlEvents:UIControlEventTouchUpInside];

    NSString *savedLanguage = [[NSUserDefaults standardUserDefaults] stringForKey:qsec_s_0075()];
    [_v2p6k1 e4p7n1:(savedLanguage.length ? savedLanguage : OngnongUIVaultResolvedLanguageCode())];

    [_a9q2x4.d5q9v3 addTarget:self action:@selector(d8k4m1) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.t2m7k6 addTarget:self action:@selector(y2p6a9) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.c8x1p4 addTarget:self action:@selector(u7c3x8) forControlEvents:UIControlEventTouchUpInside];
    UILongPressGestureRecognizer *speed9LongPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(r2c6m8:)];
    speed9LongPress.minimumPressDuration = 0.45;
    [_a9q2x4.t2m7k6 addGestureRecognizer:speed9LongPress];
    UILongPressGestureRecognizer *speed108LongPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(t7p3v1:)];
    speed108LongPress.minimumPressDuration = 0.45;
    [_a9q2x4.c8x1p4 addGestureRecognizer:speed108LongPress];
    _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = YES;
    _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = YES;
    UITapGestureRecognizer *quickTargetTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(z7ee09a13c4)];
    [_a9q2x4.r3n9d5.c6d9x4 addGestureRecognizer:quickTargetTap];
    UITapGestureRecognizer *quickNumberTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(q1c8v4)];
    [_a9q2x4.r3n9d5.t2m8r5 addGestureRecognizer:quickNumberTap];
    [_a9q2x4.v6q2m8 addTarget:self action:@selector(n5q1r4) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.k4p7c1 addTarget:self action:@selector(g9v2d6) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.q4n8p2 addTarget:self action:@selector(q1c8v4) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.m6q1d8 addTarget:self action:@selector(zAltOpenMenu) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.h3c9v5 addTarget:self action:@selector(l4m8k3) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.g8n2x6 addTarget:self action:@selector(zToggleInterface) forControlEvents:UIControlEventTouchUpInside];
    [_a9q2x4.r4n6d2 addTarget:self action:@selector(x1c7p5) forControlEvents:UIControlEventTouchUpInside];
    _a9q2x4.x2c8m5.userInteractionEnabled = YES;
    _a9q2x4.p9v3k7.userInteractionEnabled = YES;
    UITapGestureRecognizer *altTargetIconTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(zAltTargetCycle)];
    [_a9q2x4.x2c8m5 addGestureRecognizer:altTargetIconTap];
    UITapGestureRecognizer *altTargetHistoryTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(zAltTargetCycle)];
    [_a9q2x4.p9v3k7 addGestureRecognizer:altTargetHistoryTap];

    _c5a8u2 = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 252.0, 174.0)];
    _c5a8u2.backgroundColor = ZThemePanelColor();
    ApplyNeon(_c5a8u2, ZThemeBorder(), 16.0, 1.2);
    _c5a8u2.layer.cornerRadius = 16.0;
    _c5a8u2.hidden = YES;
    NSArray<NSString *> *altTitles = [self zAltMenuTitles];
    NSMutableArray<UIButton *> *altButtons = [NSMutableArray array];
    CGFloat ag = 4.0;
    CGFloat am = 6.0;
    CGFloat arrowRail = 30.0;
    CGFloat contentW = _c5a8u2.bounds.size.width - arrowRail - am * 2.0;
    CGFloat aw = (contentW - ag * 3.0) / 4.0;
    CGFloat ah = 35.0;
    for (NSInteger i = 0; i < (NSInteger)altTitles.count; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        b.exclusiveTouch = YES;
        NSInteger row = i / 4;
        NSInteger col = i % 4;
        b.frame = CGRectMake(am + col * (aw + ag), 6.0 + row * (ah + ag), aw, ah);
        [b setTitle:altTitles[i] forState:UIControlStateNormal];
        [b setAttributedTitle:nil forState:UIControlStateNormal];
        [self zApplyAltButtonStyle:b index:i];
        ApplyNeon(b, ZThemeBorder(), 8.0, 0.9);
        [b addTarget:self action:@selector(zAltGridTap:) forControlEvents:UIControlEventTouchUpInside];
        [_c5a8u2 addSubview:b];
        [altButtons addObject:b];
    }
    _s4k7e1 = altButtons;
    _w6j2r9 = [UIButton buttonWithType:UIButtonTypeCustom];
    _w6j2r9.frame = CGRectMake(_c5a8u2.bounds.size.width - 27.0, 6.0, 23.0, _c5a8u2.bounds.size.height - 12.0);
    [_w6j2r9 setTitle:OX_NS("‹") forState:UIControlStateNormal];
    [_w6j2r9 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _w6j2r9.titleLabel.font = [UIFont systemFontOfSize:21.0 weight:UIFontWeightBlack];
    _w6j2r9.backgroundColor = ZThemeActiveGreen();
    ApplyNeon(_w6j2r9, ZThemeBorder(), 12.0, 1.0);
    [_w6j2r9 addTarget:self action:@selector(zAltCloseMenu) forControlEvents:UIControlEventTouchUpInside];
    [_c5a8u2 addSubview:_w6j2r9];
    UIPanGestureRecognizer *altGridPan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(zAltGridPan:)];
    altGridPan.minimumNumberOfTouches = 1;
    altGridPan.maximumNumberOfTouches = 1;
    altGridPan.cancelsTouchesInView = YES;
    [_c5a8u2 addGestureRecognizer:altGridPan];
    [self.view addSubview:_c5a8u2];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(c2m6r4) name:Z973e694cc8 object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(a5v1x8:) name:qsec_s_0062() object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(g5x9q4:) name:ZThemeNotify() object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(b6x4j9:) name:Ongnong::R7f404() object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(n8q4m2:) name:OX_NS("om_auto_merge_state_changed") object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(zServerMenuLabelsChanged:) name:OX_NS("ongnong_menu_labels_changed") object:nil];

    Z9abcb7bb90 *controllerForHistory = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(7.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!controllerForHistory || !controllerForHistory.view.window) return;
        if (!Ongnong::Zx8fCounterAllowed()) return;
        [controllerForHistory h2p7m9];
        controllerForHistory.n7c3m8.hidden = NO;
        [controllerForHistory.n7c3m8 n4q9c1];
        [controllerForHistory.view bringSubviewToFront:controllerForHistory.n7c3m8];
        [controllerForHistory q7m2d8];
    });

    NSUserDefaults *layoutDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger onSavedLayout = [layoutDefaults objectForKey:OX_NS("ongnong_layout_three_mode")] ? [layoutDefaults integerForKey:OX_NS("ongnong_layout_three_mode")] : 3;
    _onThirdLayout = onSavedLayout == 3;
    _v2p6k1.onThirdLayout = _onThirdLayout;
    _a6t3y8 = onSavedLayout == 2;
    [self onThirdBuild];
    _d7u4i1 = NO;
    [self zApplyInterface];
    [self g5x9q4:nil];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.2 target:self selector:@selector(tick) userInfo:nil repeats:YES];
    _timer.tolerance = 0.35;
    [self q7m2d8];
    [self d2x8q4];
}



- (BOOL)zAltFeatureAllowedForTag:(NSInteger)tag {
    switch (tag) {
        case 0: return YES;
        case 1: return YES;
        case 2: return Ongnong::Zx8fCounterAllowed();
        case 3: return Ongnong::Zx8fAutoBuildAllowed();
        case 4: return Ongnong::Zx8fRaidHammerAllowed();
        case 5: return Ongnong::Zx8fMagicCardsAllowed();
        case 6: return Ongnong::Zx8fAutoClickAllowed();
        case 7: return Ongnong::Zx8fAutoStopAllowed();
        case 8: return Ongnong::Zx8fMenuColorAllowed();
        case 9: return Ongnong::R7f401();
        case 10: return Ongnong::Zx8fBetCycleAllowed();
        case 11: return Ongnong::Zx8fAutoMergeAllowed();
        case 12: return Ongnong::Zx8fFriendInviteAllowed();
        case 13: return Ongnong::Zx8fPotionAllowed();
        case 14: return YES;
        case 15: return YES;
        default: return YES;
    }
}

- (BOOL)zAltVipLockedForTag:(NSInteger)tag {
    if (Ongnong::Zx8fIsVIP()) return NO;
    return ![self zAltFeatureAllowedForTag:tag];
}

- (void)zShowAltVipRequiredOnButton:(UIButton *)button {
    if (!button) return;
    NSString *message = ZuiPick5(OX_NS("CẦN NÂNG CẤP VIP"), OX_NS("需要升级 VIP"), OX_NS("ต้องอัปเกรด VIP"), OX_NS("PASSA A VIP"), OX_NS("VIP UPGRADE REQUIRED"));
    NSInteger marker = 92831;
    UILabel *existing = [button viewWithTag:marker];
    [existing removeFromSuperview];
    UILabel *label = [[UILabel alloc] initWithFrame:button.bounds];
    label.tag = marker;
    label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    label.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.96];
    label.text = message;
    label.textColor = RGB(238, 22, 22);
    label.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightBlack];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 2;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.68;
    label.layer.cornerRadius = 8.0;
    label.layer.masksToBounds = YES;
    label.layer.borderWidth = 1.1;
    label.layer.borderColor = RGB(255, 65, 65).CGColor;
    label.userInteractionEnabled = NO;
    [button addSubview:label];
    [button bringSubviewToFront:label];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (label.superview == button) [label removeFromSuperview];
    });

    NSInteger flyMarker = 92832;
    UIView *oldFly = [self.view viewWithTag:flyMarker];
    [oldFly removeFromSuperview];
    CGRect buttonRect = [button convertRect:button.bounds toView:self.view];
    CGFloat flyW = MIN(230.0, MAX(170.0, self.view.bounds.size.width - 24.0));
    CGFloat flyH = 38.0;
    CGFloat flyX = MIN(MAX(12.0, CGRectGetMidX(buttonRect) - flyW * 0.5), MAX(12.0, self.view.bounds.size.width - flyW - 12.0));
    CGFloat flyY = MAX(50.0, CGRectGetMinY(buttonRect) - 8.0);
    UILabel *fly = [[UILabel alloc] initWithFrame:CGRectMake(flyX, flyY, flyW, flyH)];
    fly.tag = flyMarker;
    fly.text = message;
    fly.textColor = RGB(210, 0, 0);
    fly.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightBlack];
    fly.textAlignment = NSTextAlignmentCenter;
    fly.adjustsFontSizeToFitWidth = YES;
    fly.minimumScaleFactor = 0.72;
    fly.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.92];
    fly.layer.cornerRadius = 10.0;
    fly.layer.masksToBounds = NO;
    fly.layer.borderWidth = 1.2;
    fly.layer.borderColor = RGB(235, 35, 35).CGColor;
    fly.layer.shadowColor = [UIColor blackColor].CGColor;
    fly.layer.shadowOpacity = 0.55;
    fly.layer.shadowRadius = 6.0;
    fly.layer.shadowOffset = CGSizeMake(0.0, 2.0);
    fly.userInteractionEnabled = NO;
    fly.alpha = 0.0;
    fly.transform = CGAffineTransformMakeScale(0.88, 0.88);
    [self.view addSubview:fly];
    [self.view bringSubviewToFront:fly];
    [UIView animateWithDuration:0.18 animations:^{
        fly.alpha = 1.0;
        fly.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:2.82 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            fly.frame = CGRectOffset(fly.frame, 0.0, -64.0);
            fly.alpha = 0.0;
            fly.transform = CGAffineTransformMakeScale(1.08, 1.08);
        } completion:^(BOOL finished2) {
            [fly removeFromSuperview];
        }];
    }];
}

- (void)zShowMainVipRequiredAtIndex:(NSInteger)index {
    if (Ongnong::Zx8fIsVIP()) return;
    if (index < 0 || index >= (NSInteger)_v2p6k1.a7m1c5.count) return;
    UIButton *button = _v2p6k1.a7m1c5[index];
    [self zShowAltVipRequiredOnButton:button];
}

- (void)zApplyAltLanguageButtonTitle:(UIButton *)button {
    if (!button) return;
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = NSTextAlignmentCenter;
    style.lineSpacing = 0.0;
    NSDictionary *smallAttrs = @{
        NSFontAttributeName:[UIFont systemFontOfSize:7.5 weight:UIFontWeightHeavy],
        NSForegroundColorAttributeName:[UIColor colorWithWhite:0.90 alpha:0.95],
        NSParagraphStyleAttributeName:style
    };
    NSDictionary *bigAttrs = @{
        NSFontAttributeName:[UIFont systemFontOfSize:10.0 weight:UIFontWeightBlack],
        NSForegroundColorAttributeName:ZThemeWhite(),
        NSParagraphStyleAttributeName:style
    };
    NSMutableAttributedString *value = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:OX_NS("%@\n"), ZAltLanguageHeaderText()] attributes:smallAttrs];
    [value appendAttributedString:[[NSAttributedString alloc] initWithString:ZAltLanguageText() attributes:bigAttrs]];
    [button setAttributedTitle:value forState:UIControlStateNormal];
    button.titleLabel.numberOfLines = 2;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.titleLabel.adjustsFontSizeToFitWidth = NO;
}

- (void)zApplyAltButtonStyle:(UIButton *)button index:(NSInteger)index {
    if (!button) return;
    [button setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:10.0 weight:UIFontWeightBlack];
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    button.titleLabel.minimumScaleFactor = 0.55;
    button.titleLabel.numberOfLines = 1;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.backgroundColor = ZThemeButtonOff();
    if (index == 0) {
        button.backgroundColor = [RGB(205, 28, 28) colorWithAlphaComponent:0.90];
    } else if (index == 1) {
        button.backgroundColor = [RGB(203, 148, 20) colorWithAlphaComponent:0.93];
    } else if (index == 14) {
        [self zApplyAltLanguageButtonTitle:button];
    }
    BOOL vipLocked = [self zAltVipLockedForTag:index];
    button.alpha = vipLocked ? 0.36 : 1.0;
    button.enabled = YES;
}

- (NSArray<NSString *> *)zAltMenuTitles {
    return @[
        ZuiPick5(OX_NS("CẬP NHẬT"), OX_NS("更新"), OX_NS("อัปเดต"), OX_NS("AGGIORNA"), OX_NS("UPDATE")),
        Ongnong::Zx8fIsVIP() ? OX_NS("VIP") : OngnongUIVaultText(OngnongUIVaultFreeBuyVipAction),
        ZuiPick5(OX_NS("LỊCH SỬ"), OX_NS("历史"), OX_NS("ประวัติ"), OX_NS("STORIA"), OX_NS("HISTORY")),
        ZuiPick5(OX_NS("XÂY"), OX_NS("建造"), OX_NS("สร้าง"), OX_NS("COSTRUISCI"), OX_NS("BUILD")),
        ZuiPick5(OX_NS("HEO/BÚA"), OX_NS("猪/锤"), OX_NS("หมู/ค้อน"), OX_NS("MAIALE/MART."), OX_NS("PIG/HAMMER")),
        ZuiPick5(OX_NS("THẺ"), OX_NS("卡牌"), OX_NS("การ์ด"), OX_NS("CARTE"), OX_NS("CARDS")),
        ZuiPick5(OX_NS("TỰ NHẤP"), OX_NS("自动点击"), OX_NS("คลิกอัตโนมัติ"), OX_NS("AUTO CLICK"), OX_NS("AUTO CLICK")),
        ZuiPick5(OX_NS("MỤC TIÊU"), OX_NS("目标"), OX_NS("เป้าหมาย"), OX_NS("OBIETTIVO"), OX_NS("TARGET")),
        ZuiPick5(OX_NS("MÀU"), OX_NS("颜色"), OX_NS("สี"), OX_NS("COLORE"), OX_NS("COLOR")),
        ZuiPick5(OX_NS("RỪNG"), OX_NS("森林"), OX_NS("ป่า"), OX_NS("FORESTA"), OX_NS("FOREST")),
        OX_NS("XBET"),
        ZuiPick5(OX_NS("GHÉP"), OX_NS("合并"), OX_NS("รวม"), OX_NS("UNISCI"), OX_NS("MERGE")),
        ZuiPick5(OX_NS("BẠN BÈ"), OX_NS("好友"), OX_NS("เพื่อน"), OX_NS("AMICI"), OX_NS("FRIENDS")),
        ZuiPick5(OX_NS("THUỐC"), OX_NS("药水"), OX_NS("ยา"), OX_NS("POZIONE"), OX_NS("POTION")),
        ZAltLanguageText(),
        ZuiPick5(OX_NS("ĐỔI UI"), OX_NS("切换UI"), OX_NS("เปลี่ยน UI"), OX_NS("CAMBIA UI"), OX_NS("SWITCH UI"))
    ];
}

- (void)zRefreshAltMenuTitles {
    NSArray<NSString *> *titles = [self zAltMenuTitles];
    NSUInteger count = MIN(_s4k7e1.count, titles.count);
    for (NSUInteger i = 0; i < count; i++) {
        UIButton *button = _s4k7e1[i];
        [button setAttributedTitle:nil forState:UIControlStateNormal];
        [button setTitle:titles[i] forState:UIControlStateNormal];
        [self zApplyAltButtonStyle:button index:i];
    }
    if (_a9q2x4) {
        [_a9q2x4.m6q1d8 setTitle:ZuiPick5(OX_NS("MENU"), OX_NS("菜单"), OX_NS("เมนู"), OX_NS("MENU"), OX_NS("MENU")) forState:UIControlStateNormal];
        [_a9q2x4.h3c9v5 setTitle:ZuiServerPick5(OX_NS("history"), OX_NS("LỊCH SỬ"), OX_NS("历史"), OX_NS("ประวัติ"), OX_NS("STORIA"), OX_NS("HISTORY")) forState:UIControlStateNormal];
    }
}

- (void)onThirdApplyHostSafeArea:(BOOL)enabled {
    static NSMapTable<UIViewController *, NSValue *> *originalInsets = nil;
    static NSMapTable<UIView *, NSValue *> *originalFrames = nil;
    if (!originalInsets) originalInsets = [NSMapTable weakToStrongObjectsMapTable];
    if (!originalFrames) originalFrames = [NSMapTable weakToStrongObjectsMapTable];
    CGFloat reserved = 62.0 + self.view.safeAreaInsets.bottom;
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        if (!window || window == self.view.window || window.hidden || !window.rootViewController) continue;
        UIViewController *root = window.rootViewController;
        if (root == self || [root isKindOfClass:[UIAlertController class]]) continue;
        NSString *className = NSStringFromClass([root.view class]);
        NSString *controllerName = NSStringFromClass([root class]);
        BOOL unityHost = ([className rangeOfString:@"Unity" options:NSCaseInsensitiveSearch].location != NSNotFound || [controllerName rangeOfString:@"Unity" options:NSCaseInsensitiveSearch].location != NSNotFound);
        NSValue *saved = [originalInsets objectForKey:root];
        if (enabled && !unityHost) {
            if (!saved) {
                [originalInsets setObject:[NSValue valueWithUIEdgeInsets:root.additionalSafeAreaInsets] forKey:root];
                saved = [originalInsets objectForKey:root];
            }
            UIEdgeInsets insets = saved.UIEdgeInsetsValue;
            insets.bottom += reserved;
            if (!UIEdgeInsetsEqualToEdgeInsets(root.additionalSafeAreaInsets, insets)) {
                root.additionalSafeAreaInsets = insets;
                [root.view setNeedsLayout];
            }
        } else if (saved) {
            root.additionalSafeAreaInsets = saved.UIEdgeInsetsValue;
            [root.view setNeedsLayout];
            [originalInsets removeObjectForKey:root];
        }
        if (!unityHost) continue;
        UIView *host = root.view;
        NSValue *frameSaved = [originalFrames objectForKey:host];
        if (enabled) {
            if (!frameSaved) {
                [originalFrames setObject:[NSValue valueWithCGRect:host.frame] forKey:host];
                frameSaved = [originalFrames objectForKey:host];
            }
            CGRect base = frameSaved.CGRectValue;
            CGRect target = base;
            target.size.height = MAX(1.0, base.size.height - reserved);
            if (!CGRectEqualToRect(host.frame, target)) {
                host.frame = target;
                [host setNeedsLayout];
                [host layoutIfNeeded];
            }
        } else if (frameSaved) {
            host.frame = frameSaved.CGRectValue;
            [host setNeedsLayout];
            [originalFrames removeObjectForKey:host];
        }
    }
    if (!enabled) {
        for (UIViewController *root in originalInsets.keyEnumerator.allObjects) {
            NSValue *saved = [originalInsets objectForKey:root];
            if (root && saved) root.additionalSafeAreaInsets = saved.UIEdgeInsetsValue;
        }
        [originalInsets removeAllObjects];
        for (UIView *host in originalFrames.keyEnumerator.allObjects) {
            NSValue *saved = [originalFrames objectForKey:host];
            if (host && saved) host.frame = saved.CGRectValue;
        }
        [originalFrames removeAllObjects];
    }
}

- (void)onThirdBuild {
    _onThirdBar = [[UIView alloc] initWithFrame:CGRectZero];
    _onThirdBar.backgroundColor = [UIColor colorWithWhite:0.82 alpha:1.0];
    _onThirdBar.layer.cornerRadius = 0.0;
    _onThirdBar.clipsToBounds = YES;
    _onThirdButtons = [NSMutableArray array];
    NSArray<NSString *> *titles = @[ZuiPick5(OX_NS("MENU"), OX_NS("菜单"), OX_NS("เมนู"), OX_NS("MENU"), OX_NS("MENU")), ZuiPick5(OX_NS("BỎ QUA"), OX_NS("跳过"), OX_NS("ข้าม"), OX_NS("SALTA"), OX_NS("SKIP")), @"", @"Ⅱ", @"9", @"+", @"+", @"D"];
    for (NSInteger i=0;i<8;i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        [b setTitle:titles[i] forState:UIControlStateNormal];
        if (i==2) {
            [b setImage:Z9a3e7f9348() forState:UIControlStateNormal];
            b.imageView.contentMode = UIViewContentModeScaleAspectFit;
            b.tintColor = [UIColor whiteColor];
        }
        b.titleLabel.font = [UIFont boldSystemFontOfSize:i<2 ? 10.0 : 15.0];
        b.backgroundColor = i==7 ? RGB(16, 119, 246) : [UIColor colorWithWhite:0.75 alpha:1];
        b.layer.cornerRadius = 15.0;
        b.layer.masksToBounds = YES;
        [b setTitleColor:i==7 ? [UIColor whiteColor] : RGB(56, 56, 56) forState:UIControlStateNormal];
        b.layer.borderWidth = 0.8;
        b.layer.borderColor = [UIColor colorWithWhite:0.66 alpha:1].CGColor;
        [b addTarget:self action:@selector(onThirdTap:) forControlEvents:UIControlEventTouchUpInside];
        if (i>=4 && i<=6) {
            UILongPressGestureRecognizer *hold = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(onThirdHold:)];
            hold.minimumPressDuration = 0.45;
            [b addGestureRecognizer:hold];
        }
        [_onThirdBar addSubview:b];
        [_onThirdButtons addObject:b];
    }
    [self.view addSubview:_onThirdBar];
    [self onThirdRefresh];
}

- (void)onThirdRefresh {
    if (!_onThirdBar) return;
    if (_onThirdBar.hidden == _onThirdLayout) _onThirdBar.hidden = !_onThirdLayout;
    if (!_onThirdLayout) return;
    _onThirdBar.backgroundColor = [UIColor colorWithWhite:0.82 alpha:1.0];
    [self onThirdApplyHostSafeArea:YES];
    CGRect bounds = self.view.bounds;
    CGFloat safeBottom = self.view.safeAreaInsets.bottom;
    CGFloat width = bounds.size.width;
    CGFloat height = 62.0 + safeBottom;
    CGRect barFrame = CGRectMake(0.0, bounds.size.height-height, width, height);
    if (!CGRectEqualToRect(_onThirdBar.frame, barFrame)) _onThirdBar.frame = barFrame;
    CGFloat gap=4.0;
    CGFloat cell=(width-24.0-gap*7.0)/8.0;
    for (NSInteger i=0;i<8;i++) {
        UIButton *b=_onThirdButtons[i];
        CGRect buttonFrame = CGRectMake(12.0+i*(cell+gap),8.0,cell,43.0);
        if (!CGRectEqualToRect(b.frame, buttonFrame)) b.frame = buttonFrame;
        if (i==2) {
            CGFloat iconSide = MIN(27.0, cell * 0.53);
            UIEdgeInsets iconInsets = UIEdgeInsetsMake((43.0-iconSide)*0.5, (cell-iconSide)*0.5, (43.0-iconSide)*0.5, (cell-iconSide)*0.5);
            if (!UIEdgeInsetsEqualToEdgeInsets(b.imageEdgeInsets, iconInsets)) b.imageEdgeInsets = iconInsets;
        }
        CGFloat buttonRadius = MIN(19.0, MIN(cell, 43.0) * 0.42);
        if (b.layer.cornerRadius != buttonRadius) b.layer.cornerRadius = buttonRadius;
        if (i==0) {
            NSString *newTitle = ZuiPick5(OX_NS("MENU"), OX_NS("菜单"), OX_NS("เมนู"), OX_NS("MENU"), OX_NS("MENU"));
            if (![b.currentTitle isEqualToString:newTitle]) [b setTitle:newTitle forState:UIControlStateNormal];
        }
        if (i==1) {
            NSString *newTitle = ZuiPick5(OX_NS("BỎ QUA"), OX_NS("跳过"), OX_NS("ข้าม"), OX_NS("SALTA"), OX_NS("SKIP"));
            if (![b.currentTitle isEqualToString:newTitle]) [b setTitle:newTitle forState:UIControlStateNormal];
        }
        if (i==4) {
            NSString *newTitle = [NSString stringWithFormat:@"%ld",(long)[self v3q9a5]];
            if (![b.currentTitle isEqualToString:newTitle]) [b setTitle:newTitle forState:UIControlStateNormal];
        }
        if (i==5 || i==6) {
            NSString *key=[NSString stringWithFormat:@"ongnong_third_speed_%ld",(long)i];
            NSInteger val=[[NSUserDefaults standardUserDefaults] integerForKey:key];
            NSString *newTitle = val>0 ? [NSString stringWithFormat:@"%ld",(long)val] : @"+";
            if (![b.currentTitle isEqualToString:newTitle]) [b setTitle:newTitle forState:UIControlStateNormal];
        }
        if (i==7) {
            BOOL isVIP = Ongnong::Zx8fIsVIP();
            NSString *newTitle = isVIP ? OX_NS("VIP") : ZuiPick5(OX_NS("MUA VIP"), OX_NS("购买 VIP"), OX_NS("ซื้อ VIP"), OX_NS("ACQUISTA VIP"), OX_NS("BUY VIP"));
            if (![b.currentTitle isEqualToString:newTitle]) [b setTitle:newTitle forState:UIControlStateNormal];
            b.titleLabel.font = [UIFont boldSystemFontOfSize:isVIP ? 14.0 : 9.0];
        }
        if (i==3) {
            NSString *newTitle = zce119e8048.z904d9bb65a ? @"▶" : @"Ⅱ";
            if (![b.currentTitle isEqualToString:newTitle]) [b setTitle:newTitle forState:UIControlStateNormal];
        }
        BOOL active = (i==2 && zce119e8048.zacc65d5e7b) || (i==3 && zce119e8048.z904d9bb65a);
        if (i>=4 && i<=6) {
            NSInteger slotSpeed = i==4 ? [self v3q9a5] : [[NSUserDefaults standardUserDefaults] integerForKey:[NSString stringWithFormat:@"ongnong_third_speed_%ld",(long)i]];
            active = slotSpeed>0 && !zce119e8048.z904d9bb65a && fabsf(zce119e8048.z68593f2227-(float)slotSpeed)<0.1f;
        }
        UIColor *newBackground = i==2 ? (zce119e8048.z7180b46195 ? RGB(210,45,45) : RGB(62,174,99)) : i==7 ? RGB(203,148,20) : i==0 && !_v2p6k1.hidden ? RGB(203,148,20) : i==1 && zce119e8048.z54007f39a0 ? RGB(210,45,45) : i==3 && zce119e8048.z904d9bb65a ? RGB(203,148,20) : active ? RGB(62,174,99) : (i>=4 && i<=6 && ![b.currentTitle isEqualToString:@"+"] ? RGB(163,192,228) : [UIColor colorWithWhite:0.75 alpha:1]);
        if (![b.backgroundColor isEqual:newBackground]) b.backgroundColor = newBackground;
        b.layer.borderColor = [UIColor colorWithWhite:0.66 alpha:1].CGColor;
    }
    [self.view bringSubviewToFront:_onThirdBar];
}

- (void)onThirdToggleMenu {
    BOOL show = _v2p6k1.hidden;
    if (show) {
        _collapsed = NO;
        CGRect target = _x5m9c2;
        if (target.size.width < 50.0 || target.size.height < 50.0) target = _v2p6k1.frame;
        target.origin.x = 8.0;
        target.origin.y = MAX(44.0, self.view.bounds.size.height - (62.0 + self.view.safeAreaInsets.bottom) - target.size.height - 8.0);
        _v2p6k1.transform = CGAffineTransformIdentity;
        _v2p6k1.frame = target;
        [_v2p6k1 setNeedsLayout];
        [_v2p6k1 layoutIfNeeded];
    }
    _v2p6k1.hidden = !show;
    _b3n7v1.hidden = YES;
    if (show) [self.view bringSubviewToFront:_v2p6k1];
    [self onThirdRefresh];
}

- (void)onThirdEditSpeed:(NSInteger)slot {
    NSString *key=slot==4 ? qsec_s_0082() : [NSString stringWithFormat:@"ongnong_third_speed_%ld",(long)slot];
    NSUserDefaults *ud=[NSUserDefaults standardUserDefaults];
    NSInteger current=slot==4 ? [self v3q9a5] : [ud integerForKey:key];
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"TỐC ĐỘ SPEED" message:@"Nhập tốc độ từ 1 đến 201" preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *field) { field.keyboardType=UIKeyboardTypeNumberPad; field.text=current>0 ? [NSString stringWithFormat:@"%ld",(long)current] : @""; }];
    [a addAction:[UIAlertAction actionWithTitle:@"LƯU" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSInteger val=a.textFields.firstObject.text.integerValue;
        if (val<1 || val>201) return;
        [ud setInteger:val forKey:key];
        [ud synchronize];
        [self onThirdRefresh];
    }]];
    if (slot!=4 && current>0) [a addAction:[UIAlertAction actionWithTitle:@"XÓA NÚT" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [ud removeObjectForKey:key];
        [ud synchronize];
        [self onThirdRefresh];
    }]];
    [a addAction:[UIAlertAction actionWithTitle:@"HỦY" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *presenter=self;
    while (presenter.presentedViewController) presenter=presenter.presentedViewController;
    [presenter presentViewController:a animated:YES completion:nil];
}

- (void)onThirdHold:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state!=UIGestureRecognizerStateBegan) return;
    Z0418c1e0ae();
    UIButton *button=(UIButton *)gesture.view;
    [self onThirdEditSpeed:button.tag];
}

- (void)onThirdTap:(UIButton *)button {
    NSInteger i=button.tag;
    Z0418c1e0ae();
    if (i==0) { [self onThirdToggleMenu]; return; }
    if (i==1) { [self g9v2d6]; [self onThirdRefresh]; return; }
    if (i==2) { [self d8k4m1]; [self onThirdRefresh]; return; }
    if (i==3) { [self n5q1r4]; [self onThirdRefresh]; return; }
    if (i>=4 && i<=6) {
        if (!Ongnong::Zx8fSpeedAllowed()) return;
        NSInteger value=i==4 ? [self v3q9a5] : [[NSUserDefaults standardUserDefaults] integerForKey:[NSString stringWithFormat:@"ongnong_third_speed_%ld",(long)i]];
        if (value<=0) { [self onThirdEditSpeed:i]; return; }
        zce119e8048.z68593f2227=(float)value;
        zce119e8048.zacc65d5e7b=true;
        zce119e8048.z904d9bb65a=false;
        Z108056b942();
        [self q7m2d8];
        [self onThirdRefresh];
        return;
    }
    if (i==7) {
        if (Ongnong::Zx8fIsVIP()) [self d4u8s0];
        else [self zBuyVipPayOS];
        return;
    }
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    if (_onThirdLayout) [self onThirdRefresh];
}

- (void)zApplyInterface {
    if (!_onThirdLayout) [self onThirdApplyHostSafeArea:NO];
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if (_onThirdLayout) {
        _a9q2x4.hidden=YES;
        _c5a8u2.hidden=YES;
        _d7u4i1=NO;
        _v2p6k1.hidden=YES;
        _b3n7v1.hidden=YES;
        [self onThirdRefresh];
        return;
    }
    if (_onThirdBar) _onThirdBar.hidden=YES;

    if (_f7q2n8) {
        _f7q2n8 = NO;
        _a9q2x4.q6m2v8 = NO;
    }
    if (_a6t3y8) {
        _v2p6k1.hidden = YES;
        _b3n7v1.hidden = YES;
        _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = NO;
        _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = NO;
        [_a9q2x4 setA1v8m3:YES];
        CGFloat qw = 230.0;
        CGFloat qh = 114.0;
        CGFloat maxX = MAX(4.0, self.view.bounds.size.width - qw - 4.0);
        CGFloat maxY = MAX(44.0, self.view.bounds.size.height - qh - 4.0);
        CGFloat x = [ud objectForKey:OX_NS("alt_ui_x")] ? [ud floatForKey:OX_NS("alt_ui_x")] : MAX(4.0, (self.view.bounds.size.width - qw) * 0.5);
        CGFloat y = [ud objectForKey:OX_NS("alt_ui_y")] ? [ud floatForKey:OX_NS("alt_ui_y")] : MAX(48.0, self.view.bounds.size.height * 0.34);
        x = MAX(4.0, MIN(maxX, x));
        y = MAX(44.0, MIN(maxY, y));
        _a9q2x4.frame = CGRectMake(x, y, qw, qh);
        _p4m9c1 = _a9q2x4.frame;
        _a9q2x4.hidden = _d7u4i1;
        _c5a8u2.hidden = !_d7u4i1;
        if (_d7u4i1) {
            CGRect gf = _c5a8u2.frame;
            CGFloat gx = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - gf.size.width - 4.0), gf.origin.x));
            CGFloat gy = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - gf.size.height - 4.0), gf.origin.y));
            gf.origin = CGPointMake(gx, gy);
            _c5a8u2.frame = gf;
            [self.view bringSubviewToFront:_c5a8u2];
        } else {
            [self.view bringSubviewToFront:_a9q2x4];
        }
    } else {
        _d7u4i1 = NO;
        _c5a8u2.hidden = YES;
        _a9q2x4.r3n9d5.c6d9x4.userInteractionEnabled = YES;
        _a9q2x4.r3n9d5.t2m8r5.userInteractionEnabled = YES;
        [_a9q2x4 setA1v8m3:NO];
        CGFloat s = z067adc83c5();
        CGFloat qw = MIN(self.view.bounds.size.width - 28.0 * s, 360.0 * s);
        CGFloat qh = 66.0 * s;
        if ([ud objectForKey:OX_NS("tool_x")]) {
            _a9q2x4.frame = [self zClampFrame:CGRectMake([ud floatForKey:OX_NS("tool_x")], [ud floatForKey:OX_NS("tool_y")], qw, qh) minW:qw minH:qh maxW:qw maxH:qh];
        } else {
            _a9q2x4.frame = CGRectMake((self.view.bounds.size.width - qw) * 0.5, MAX(42.0, self.view.bounds.size.height - qh - 28.0), qw, qh);
        }
        _p4m9c1 = _a9q2x4.frame;
        _a9q2x4.hidden = NO;
        _v2p6k1.hidden = NO;
        _b3n7v1.hidden = NO;
        [self.view bringSubviewToFront:_a9q2x4];
    }
    [_a9q2x4 setNeedsLayout];
    [_a9q2x4 layoutIfNeeded];
}

- (void)zSetInterfaceMode:(NSInteger)mode {
    if (mode < 1 || mode > 3) return;
    NSUserDefaults *ud=[NSUserDefaults standardUserDefaults];
    _onThirdLayout=mode==3;
    _v2p6k1.onThirdLayout = _onThirdLayout;
    _a6t3y8=mode==2;
    _d7u4i1=NO;
    [ud setInteger:mode forKey:OX_NS("ongnong_layout_three_mode")];
    g_themeLoaded = NO;
    [ud setBool:_a6t3y8 forKey:OX_NS("om_layout_alt")];
    [ud synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:ZThemeNotify() object:self];
    [self zApplyInterface];
    [self q7m2d8];
    [[NSNotificationCenter defaultCenter] postNotificationName:OX_NS("ongnong_fps_visibility_changed") object:nil];
    Z0418c1e0ae();
}

- (void)onResizeMainMenuToVisibleButtons {
    if (!_v2p6k1 || _collapsed) return;
    CGFloat s = z067adc83c5();
    NSUInteger count = 0;
    for (UIView *button in _v2p6k1.a7m1c5) if (!button.hidden) count++;
    BOOL showUpgrade = !_onThirdLayout && [ZuiBuyVipText() isEqualToString:OX_NS("FREE")] && Ongnong::Zx8fMenuItemVisible(OX_NS("upgrade_vip"));
    CGFloat header = (showUpgrade ? 150.0 : 104.0) * s;
    CGFloat desired = header + count * 43.0 * s + 7.0 * s;
    CGFloat maxHeight = MAX(160.0 * s, self.view.bounds.size.height - 88.0 * s);
    CGFloat height = MIN(maxHeight, MAX(header + 8.0 * s, desired));
    CGRect frame = _v2p6k1.frame;
    if (fabs(frame.size.height - height) < 0.5) return;
    CGFloat previousBottom = CGRectGetMaxY(frame);
    frame.size.height = height;
    frame.origin.y = MAX(36.0 * s, MIN(previousBottom - height, self.view.bounds.size.height - height - 8.0 * s));
    _v2p6k1.frame = frame;
    _x5m9c2 = frame;
    [_v2p6k1 setNeedsLayout];
    _b3n7v1.frame = [self collapseHandleFrameForMenuFrame:frame collapsed:NO];
}

- (void)onCloseVisibilityPanel {
    UIView *panel = [self.view viewWithTag:972401];
    [panel removeFromSuperview];
}

- (void)onToggleVisibilityItem:(UIButton *)sender {
    if (!Ongnong::Zx8fIsVIP()) return;
    NSUInteger i = (NSUInteger)(sender.tag - 972500);
    if (i >= _v2p6k1.a7m1c5.count || i == 1 || i == 15) return;
    Zcb66126fa3 *button = _v2p6k1.a7m1c5[i];
    BOOL visible = button.hidden;
    button.hidden = !visible;
    NSString *key = [NSString stringWithFormat:OX_NS("ongnong_main_visible_%lu"), (unsigned long)i];
    [[NSUserDefaults standardUserDefaults] setBool:visible forKey:key];
    [self onResizeMainMenuToVisibleButtons];
    [_v2p6k1 setNeedsLayout];
    [_v2p6k1 layoutIfNeeded];
    NSString *name = button.x9c4n6.text ?: OX_NS("");
    [sender setTitle:[NSString stringWithFormat:OX_NS("%@ %@"), visible ? OX_NS("●") : OX_NS("○"), name] forState:UIControlStateNormal];
    [sender setTitleColor:visible ? [UIColor colorWithRed:0.53 green:0.94 blue:0.80 alpha:1.0] : [UIColor whiteColor] forState:UIControlStateNormal];
}

- (void)onShowMenuVisibility {
    if (!Ongnong::Zx8fIsVIP()) return;
    [self onCloseVisibilityPanel];
    CGFloat screenW = self.view.bounds.size.width;
    CGFloat screenH = self.view.bounds.size.height;
    CGFloat panelW = MIN(310.0, screenW - 32.0);
    CGFloat panelH = MIN(440.0, screenH - 100.0);
    UIView *panel = [[UIView alloc] initWithFrame:CGRectMake((screenW - panelW) / 2.0, (screenH - panelH) / 2.0, panelW, panelH)];
    panel.tag = 972401;
    panel.backgroundColor = [UIColor colorWithRed:0.08 green:0.17 blue:0.20 alpha:0.96];
    panel.layer.cornerRadius = 14.0;
    panel.layer.borderWidth = 1.0;
    panel.layer.borderColor = [UIColor colorWithRed:0.20 green:0.75 blue:0.83 alpha:0.9].CGColor;
    [self.view addSubview:panel];
    UILabel *heading = [[UILabel alloc] initWithFrame:CGRectMake(12.0, 7.0, panelW - 60.0, 35.0)];
    heading.text = ZuiPick5(OX_NS("ẨN / HIỆN CHỨC NĂNG"), OX_NS("显示 / 隐藏功能"), OX_NS("แสดง / ซ่อนฟังก์ชัน"), OX_NS("MOSTRA / NASCONDI"), OX_NS("SHOW / HIDE"));
    heading.textColor = [UIColor whiteColor];
    heading.font = [UIFont boldSystemFontOfSize:15.0];
    heading.adjustsFontSizeToFitWidth = YES;
    [panel addSubview:heading];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(panelW - 43.0, 5.0, 37.0, 37.0);
    [close setTitle:OX_NS("✕") forState:UIControlStateNormal];
    [close setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont boldSystemFontOfSize:20.0];
    [close addTarget:self action:@selector(onCloseVisibilityPanel) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:close];
    UIScrollView *list = [[UIScrollView alloc] initWithFrame:CGRectMake(9.0, 46.0, panelW - 18.0, panelH - 55.0)];
    list.showsVerticalScrollIndicator = YES;
    [panel addSubview:list];
    CGFloat y = 0.0;
    NSArray<Zcb66126fa3 *> *buttons = _v2p6k1.a7m1c5;
    for (NSUInteger i = 0; i < buttons.count; i++) {
        if (i == 1 || i == 15) continue;
        Zcb66126fa3 *button = buttons[i];
        UIButton *entry = [UIButton buttonWithType:UIButtonTypeSystem];
        entry.tag = 972500 + (NSInteger)i;
        entry.frame = CGRectMake(0.0, y, list.bounds.size.width, 36.0);
        entry.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.09];
        entry.layer.cornerRadius = 7.0;
        entry.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        entry.contentEdgeInsets = UIEdgeInsetsMake(0.0, 12.0, 0.0, 8.0);
        entry.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightMedium];
        NSString *name = button.x9c4n6.text ?: OX_NS("");
        [entry setTitle:[NSString stringWithFormat:OX_NS("%@ %@"), button.hidden ? OX_NS("○") : OX_NS("●"), name] forState:UIControlStateNormal];
        [entry setTitleColor:button.hidden ? [UIColor whiteColor] : [UIColor colorWithRed:0.53 green:0.94 blue:0.80 alpha:1.0] forState:UIControlStateNormal];
        [entry addTarget:self action:@selector(onToggleVisibilityItem:) forControlEvents:UIControlEventTouchUpInside];
        [list addSubview:entry];
        y += 40.0;
    }
    list.contentSize = CGSizeMake(list.bounds.size.width, y);
}

- (void)zToggleInterface {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("CHỌN GIAO DIỆN"), OX_NS("选择界面"), OX_NS("เลือกหน้าตา"), OX_NS("SCEGLI INTERFACCIA"), OX_NS("SELECT INTERFACE")) message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    NSInteger selected=_onThirdLayout ? 3 : (_a6t3y8 ? 2 : 1);
    for (NSInteger mode=1;mode<=3;mode++) {
        NSString *title=[NSString stringWithFormat:OX_NS("%@%@ %ld"),selected==mode ? OX_NS("✓ ") : OX_NS(""), ZuiPick5(OX_NS("GIAO DIỆN"), OX_NS("界面"), OX_NS("หน้าตา"), OX_NS("INTERFACCIA"), OX_NS("INTERFACE")),(long)mode];
        [a addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [self zSetInterfaceMode:mode];
        }]];
    }
    BOOL visibilityVIP = Ongnong::Zx8fIsVIP();
    UIAlertAction *visibilityAction = [UIAlertAction actionWithTitle:ZuiPick5(OX_NS("ẨN / HIỆN CHỨC NĂNG"), OX_NS("显示 / 隐藏功能"), OX_NS("แสดง / ซ่อนฟังก์ชัน"), OX_NS("MOSTRA / NASCONDI FUNZIONI"), OX_NS("SHOW / HIDE FEATURES")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        if (!Ongnong::Zx8fIsVIP()) {
            UIAlertController *vip = [UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("CẦN NÂNG CẤP VIP"), OX_NS("需要升级 VIP"), OX_NS("ต้องอัปเกรด VIP"), OX_NS("PASSA A VIP"), OX_NS("VIP UPGRADE REQUIRED")) message:nil preferredStyle:UIAlertControllerStyleAlert];
            [vip addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
            [self presentViewController:vip animated:YES completion:nil];
            return;
        }
        [self onShowMenuVisibility];
    }];
    if (!visibilityVIP) [visibilityAction setValue:[UIColor lightGrayColor] forKey:OX_NS("titleTextColor")];
    [a addAction:visibilityAction];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("HỦY"), OX_NS("取消"), OX_NS("ยกเลิก"), OX_NS("ANNULLA"), OX_NS("CANCEL")) style:UIAlertActionStyleCancel handler:nil]];
    UIPopoverPresentationController *pop=a.popoverPresentationController;
    if (pop) { pop.sourceView=self.view; pop.sourceRect=CGRectMake(CGRectGetMidX(self.view.bounds),CGRectGetMidY(self.view.bounds),1,1); pop.permittedArrowDirections=0; }
    [self presentViewController:a animated:YES completion:nil];
}

- (void)zAltOpenMenu {
    if (!_a6t3y8 || !_c5a8u2) return;
    if (_f7q2n8) [self q1c8v4];
    _d7u4i1 = YES;
    [self zRefreshAltMenuTitles];
    CGRect f = _c5a8u2.frame;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if ([ud objectForKey:OX_NS("alt_menu_x")] && [ud objectForKey:OX_NS("alt_menu_y")]) {
        f.origin.x = [ud floatForKey:OX_NS("alt_menu_x")];
        f.origin.y = [ud floatForKey:OX_NS("alt_menu_y")];
    } else {
        f.origin.x = _a9q2x4.frame.origin.x;
        f.origin.y = _a9q2x4.frame.origin.y;
    }
    f.origin.x = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - f.size.width - 4.0), f.origin.x));
    f.origin.y = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - f.size.height - 4.0), f.origin.y));
    _c5a8u2.frame = f;
    _a9q2x4.hidden = YES;
    _c5a8u2.hidden = NO;
    [self.view bringSubviewToFront:_c5a8u2];
    Z0418c1e0ae();
}

- (void)zAltCloseMenu {
    if (!_a6t3y8) return;
    _d7u4i1 = NO;
    CGRect q = _a9q2x4.frame;
    q.origin = _c5a8u2.frame.origin;
    q.origin.x = MAX(4.0, MIN(MAX(4.0, self.view.bounds.size.width - q.size.width - 4.0), q.origin.x));
    q.origin.y = MAX(44.0, MIN(MAX(44.0, self.view.bounds.size.height - q.size.height - 4.0), q.origin.y));
    _a9q2x4.frame = q;
    _p4m9c1 = q;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setFloat:q.origin.x forKey:OX_NS("alt_ui_x")];
    [ud setFloat:q.origin.y forKey:OX_NS("alt_ui_y")];
    [ud synchronize];
    _c5a8u2.hidden = YES;
    _a9q2x4.hidden = NO;
    [self.view bringSubviewToFront:_a9q2x4];
    [self e7k3p9];
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)zAltShowShortcut:(NSInteger)tag {
    if (tag < 0 || tag >= 15) return;
    if (tag == 3 || tag == 4 || tag == 5 || tag == 9 || tag == 11) return;
    NSNumber *key = @(tag);
    UIButton *popup = self.zAltFloatButtons[key];
    NSArray<NSString *> *titles = [self zAltMenuTitles];
    NSString *title = (tag < (NSInteger)titles.count) ? titles[tag] : OX_NS("MENU");
    if (!popup) {
        CGFloat w = 132.0, h = 38.0;
        CGFloat x = MAX(8.0, self.view.bounds.size.width - w - 14.0);
        CGFloat y = 50.0 + (CGFloat)((tag % 6) * 46);
        y = MIN(MAX(42.0, y), self.view.bounds.size.height - h - 8.0);
        popup = [UIButton buttonWithType:UIButtonTypeCustom];
        popup.frame = CGRectMake(x, y, w, h);
        popup.tag = 6000 + tag;
        popup.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightHeavy];
        popup.titleLabel.adjustsFontSizeToFitWidth = YES;
        popup.titleLabel.minimumScaleFactor = 0.55;
        popup.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
        popup.layer.cornerRadius = 12.0;
        popup.layer.masksToBounds = NO;
        [popup setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
        [popup addTarget:self action:@selector(zAltShortcutTap:) forControlEvents:UIControlEventTouchUpInside];
        [popup addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(zAltShortcutPan:)];
        [popup addGestureRecognizer:pan];
        UIButton *close = [UIButton buttonWithType:UIButtonTypeCustom];
        close.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
        close.tag = 7000 + tag;
        [close setTitle:OX_NS("×") forState:UIControlStateNormal];
        [close setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
        close.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
        close.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
        close.layer.cornerRadius = 9.0;
        close.layer.borderWidth = 0.7;
        close.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
        [close addTarget:self action:@selector(zAltShortcutClose:) forControlEvents:UIControlEventTouchUpInside];
        [popup addSubview:close];
        self.zAltFloatButtons[key] = popup;
        [self.view addSubview:popup];
    }
    [popup setTitle:title forState:UIControlStateNormal];
    UIColor *color = ZThemeOnGreen();
    popup.backgroundColor = [color colorWithAlphaComponent:0.90];
    popup.layer.borderWidth = 1.1;
    popup.layer.borderColor = color.CGColor;
    popup.layer.shadowColor = color.CGColor;
    popup.layer.shadowOpacity = 0.45;
    popup.layer.shadowRadius = 8.0;
    popup.layer.shadowOffset = CGSizeZero;
    popup.hidden = NO;
    [self.view bringSubviewToFront:popup];
}

- (void)zAltShortcutTap:(UIButton *)sender {
    NSInteger tag = sender.tag - 6000;
    switch (tag) {
        case 0: [self k7p2m6]; break;
        case 1: [self d4u8s0]; break;
        case 2: [self l4m8k3]; break;
        case 6: [self e9m1p7]; break;
        case 7: [self t6r2n9]; break;
        case 8: [self j3v7q5]; break;
        case 10: [self v7b2c9]; break;
        case 12: [self ongFriendModule]; break;
        case 13: [self ongPotionModule]; break;
        case 14: [self c8x3n6]; break;
        default: break;
    }
}

- (void)zAltShortcutClose:(UIButton *)sender {
    NSInteger tag = sender.tag - 7000;
    UIButton *popup = self.zAltFloatButtons[@(tag)];
    if (popup) popup.hidden = YES;
}

- (void)zAltShortcutPan:(UIPanGestureRecognizer *)pan {
    UIView *popup = pan.view;
    UIView *sv = popup.superview;
    if (!popup || !sv) return;
    static CGPoint startCenter;
    if (pan.state == UIGestureRecognizerStateBegan) startCenter = popup.center;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint t = [pan translationInView:sv];
        CGPoint c = CGPointMake(startCenter.x + t.x, startCenter.y + t.y);
        CGFloat hw = popup.bounds.size.width * 0.5;
        CGFloat hh = popup.bounds.size.height * 0.5;
        c.x = MAX(hw + 8.0, MIN(sv.bounds.size.width - hw - 8.0, c.x));
        c.y = MAX(hh + 42.0, MIN(sv.bounds.size.height - hh - 8.0, c.y));
        popup.center = c;
    }
}

- (void)zMagicPopupClose {
    Ongnong::MagicCardsModuleSetEnabled(false);
    _r8m2d5 = NO;
    if (_u1x7p4) _u1x7p4.hidden = YES;
    [self h6d2q8];
    [self q7m2d8];
}

- (void)zForestPopupClose {
    Ongnong::ExpeditionAutoSetEnabled(false);
    _m3k9a2 = NO;
    if (_q8z1u4) _q8z1u4.hidden = YES;
    [self q2n9v6];
    [self q7m2d8];
}

- (void)zMergePopupClose {
    Ongnong::AutoMergeModuleSetEnabled(false);
    self.p7x3n6 = NO;
    if (self.k2m8v4) self.k2m8v4.hidden = YES;
    [self c3n7x5];
    [self q7m2d8];
}

- (void)zAltGridTap:(UIButton *)sender {
    if (_zAltGridDragging) return;
    NSInteger tag = sender.tag;
    if ([self zAltVipLockedForTag:tag]) {
        [self zShowAltVipRequiredOnButton:sender];
        Z0418c1e0ae();
        return;
    }
    if (tag == 15) {
        [self zToggleInterface];
        return;
    }
    [self zAltCloseMenu];
    switch (tag) {
        case 0: [self k7p2m6]; break;
        case 1: [self d4u8s0]; break;
        case 2: [self l4m8k3]; break;
        case 3: [self m8c2r6]; break;
        case 4: [self f5n9x1]; break;
        case 5: [self a7q3d8]; break;
        case 6: [self e9m1p7]; break;
        case 7: [self t6r2n9]; break;
        case 8: [self j3v7q5]; break;
        case 9: [self h5p1k8]; break;
        case 10: [self v7b2c9]; break;
        case 11: [self z6m4a8]; break;
        case 12: [self ongFriendModule]; break;
        case 13: [self ongPotionModule]; break;
        case 14: [self c8x3n6]; break;
        default: break;
    }
}

- (void)zAltGridPan:(UIPanGestureRecognizer *)pan {
    if (!_c5a8u2 || !_c5a8u2.superview) return;
    UIView *sv = _c5a8u2.superview;
    if (pan.state == UIGestureRecognizerStateBegan) {
        _f2o9p5 = _c5a8u2.center;
        _zAltGridDragging = NO;
    }
    CGPoint t = [pan translationInView:sv];
    if (!_zAltGridDragging && hypot(t.x, t.y) >= 7.0) _zAltGridDragging = YES;
    if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        CGPoint c = CGPointMake(_f2o9p5.x + t.x, _f2o9p5.y + t.y);
        CGFloat hw = _c5a8u2.bounds.size.width * 0.5;
        CGFloat hh = _c5a8u2.bounds.size.height * 0.5;
        c.x = MAX(hw + 2.0, MIN(sv.bounds.size.width - hw - 2.0, c.x));
        c.y = MAX(42.0 + hh, MIN(sv.bounds.size.height - hh - 2.0, c.y));
        _c5a8u2.center = c;
        if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_c5a8u2.frame.origin.x forKey:OX_NS("alt_menu_x")];
            [ud setFloat:_c5a8u2.frame.origin.y forKey:OX_NS("alt_menu_y")];
            [ud synchronize];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.16 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.zAltGridDragging = NO;
            });
        }
    }
}

- (void)h2p7m9 {
    if (_n7c3m8) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat panelW = Ze25ebfed17;
    CGFloat panelH = 120.0;
    CGFloat panelX = 8.0;
    CGFloat panelY = 100.0;
    panelW = MAX(Ze25ebfed17, MIN(MIN(screen.size.width - 16.0, 440.0), panelW));
    panelH = MAX(Zed1192a6d1, MIN(430.0, panelH));
    panelX = MAX(8.0, MIN(panelX, screen.size.width - panelW - 8.0));
    CGRect panelFrame = [self zClampFrame:CGRectMake(panelX, panelY, panelW, panelH) minW:Ze25ebfed17 minH:Zed1192a6d1 maxW:MIN(screen.size.width - 16.0, 440.0) maxH:430.0];
    _n7c3m8 = [[Z1c94f803b6 alloc] initWithFrame:panelFrame];
    _n7c3m8.hidden = YES;
    [_n7c3m8.closeButton addTarget:self action:@selector(l4m8k3) forControlEvents:UIControlEventTouchUpInside];
    [_n7c3m8.k3v9d4 addTarget:self action:@selector(x1c7p5) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_n7c3m8];
    [self g5x9q4:nil];
}

- (UIImage *)z0b9c95dabc:(int)idx {
    return OngnongCounterIconImage(idx);
}

- (NSInteger)z3f0b8e15a2:(NSInteger)slot {
    NSArray<NSNumber *> *targets = Ongnong::Z76e4c1b909();
    if (targets.count <= 0) return 0;
    if (slot < 0 || slot >= (NSInteger)targets.count) return 0;
    return slot;
}

- (void)e7k3p9 {
    if (!_a9q2x4.r3n9d5) return;
    _z4b51d86a09 = [self z3f0b8e15a2:_z4b51d86a09];
    int idx = Ongnong::Z76d01f2a88(_z4b51d86a09);
    int countValue = (idx >= 0 && idx < Za94c0d401a) ? zce119e8048.zc9f4191bf8[idx] : 0;
    NSString *v = [NSString stringWithFormat:qsec_s_0074(), countValue];
    if (![_a9q2x4.r3n9d5.t2m8r5.text isEqualToString:v]) {
        _a9q2x4.r3n9d5.t2m8r5.text = v;
    }
    UIImage *img = [self z0b9c95dabc:idx];
    if (_a9q2x4.r3n9d5.c6d9x4.image != img) {
        _a9q2x4.r3n9d5.c6d9x4.image = img;
    }
    _a9q2x4.r3n9d5.t2m8r5.textColor = Z07aec8e446(idx);
    if (_a9q2x4.a1v8m3) {
        _a9q2x4.x2c8m5.image = img;
        NSArray<NSNumber *> *items = Zd282eb67ef(idx);
        NSMutableArray<NSString *> *parts = [NSMutableArray array];
        NSInteger limit = MIN((NSInteger)4, (NSInteger)items.count);
        for (NSInteger i = 0; i < limit; i++) [parts addObject:items[i].stringValue];
        _a9q2x4.p9v3k7.text = parts.count ? [parts componentsJoinedByString:OX_NS(", ")] : OX_NS("-");
        _a9q2x4.p9v3k7.textColor = ZThemeWhite();
    }
}

- (void)z7ee09a13c4 {
    if (_a6t3y8 && !_f7q2n8) return;
    NSArray<NSNumber *> *targets = Ongnong::Z76e4c1b909();
    if (targets.count <= 0) return;
    _z4b51d86a09 = (_z4b51d86a09 + 1) % targets.count;
    [[NSUserDefaults standardUserDefaults] setInteger:_z4b51d86a09 forKey:Z0f21de981b()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    Z0418c1e0ae();
    [self e7k3p9];
    [self d2x8q4];
}

- (void)zAltTargetCycle {
    if (!_a6t3y8 || _d7u4i1) return;
    NSArray<NSNumber *> *targets = Ongnong::Z76e4c1b909();
    if (targets.count <= 0) return;
    _z4b51d86a09 = (_z4b51d86a09 + 1) % targets.count;
    [[NSUserDefaults standardUserDefaults] setInteger:_z4b51d86a09 forKey:Z0f21de981b()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    Z0418c1e0ae();
    [self e7k3p9];
    [self q7m2d8];
}

- (void)h9r3v7 {
    if (_d8r4q7) {
        [_d8r4q7 invalidate];
        _d8r4q7 = nil;
    }
}

- (void)d2x8q4 {
    [self h9r3v7];
    if (_collapsed || !_v2p6k1 || _v2p6k1.hidden) return;
    _d8r4q7 = [NSTimer scheduledTimerWithTimeInterval:12.0
                                                          target:self
                                                        selector:@selector(m1b6k5)
                                                        userInfo:nil
                                                         repeats:NO];
}

- (void)m1b6k5 {
    _d8r4q7 = nil;
    if (_collapsed || !_v2p6k1 || !_b3n7v1) return;

    _x5m9c2 = _v2p6k1.frame;
    CGRect z7fa19172fd = _v2p6k1.frame;
    z7fa19172fd.origin.x = -z7fa19172fd.size.width;
    CGRect handleTarget = [self collapseHandleFrameForMenuFrame:z7fa19172fd collapsed:YES];

    _collapsed = YES;
    [_b3n7v1 setTitle:qsec_s_0081() forState:UIControlStateNormal];
    _v2p6k1.transform = CGAffineTransformIdentity;
    _v2p6k1.frame = z7fa19172fd;
    _b3n7v1.frame = handleTarget;
}

- (void)p8c4n2 {
    CGFloat s = z067adc83c5();
    CGRect screen = self.view.bounds;
    CGFloat quickW = 360 * s;
    CGFloat quickH = 66 * s;
    CGFloat rightX = CGRectGetMaxX(_v2p6k1.frame) + 14 * s;
    CGFloat rightSpace = screen.size.width - rightX - 8 * s;
    if (rightSpace >= quickW) {
        _a9q2x4.frame = CGRectMake(rightX, _v2p6k1.frame.origin.y + 210 * s, quickW, quickH);
    } else {
        quickW = MIN(screen.size.width - 28 * s, 360 * s);
        CGFloat x = 14 * s;
        CGFloat y = CGRectGetMaxY(_v2p6k1.frame) + 10 * s;
        if (y + quickH > screen.size.height - 18 * s) {
            y = screen.size.height - quickH - 18 * s;
        }
        _a9q2x4.frame = CGRectMake(x, y, quickW, quickH);
    }
}

- (CGRect)collapseHandleFrameForMenuFrame:(CGRect)menuFrame collapsed:(BOOL)isCollapsed {
    CGFloat s = z067adc83c5();
    CGFloat handleW = 30.0 * s;
    CGFloat handleH = 68.0 * s;
    CGFloat x = isCollapsed ? 0.0 : CGRectGetMaxX(menuFrame) - 1.0;
    CGFloat y = menuFrame.origin.y + menuFrame.size.height * 0.40;
    CGFloat maxY = self.view.bounds.size.height - handleH - 4.0;
    y = MAX(4.0, MIN(maxY, y));
    return CGRectMake(x, y, handleW, handleH);
}

- (void)z3q7d9 {
    _b3n7v1.frame = [self collapseHandleFrameForMenuFrame:_v2p6k1.frame collapsed:_collapsed];
}

- (void)a5v1x8:(NSNotification *)note {
    if (!_collapsed) {
        CGRect fixed = _v2p6k1.frame;
        fixed.origin.x = 6.0 * z067adc83c5();
        _x5m9c2 = fixed;
        [self z3q7d9];
        [self d2x8q4];
    }
}

- (void)zRenameMenuHold:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan || !Ongnong::Zx8fAllowed()) return;
    NSString *key = gesture.name;
    if (key.length == 0) return;
    UIButton *button = (UIButton *)gesture.view;
    NSString *oldName = Ongnong::Zx8fMenuLabelVI(key, [button titleForState:UIControlStateNormal] ?: OX_NS(""));
    UIAlertController *dialog = [UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("ĐỔI TÊN NÚT"), OX_NS("重命名按钮"), OX_NS("เปลี่ยนชื่อปุ่ม"), OX_NS("RINOMINA PULSANTE"), OX_NS("RENAME BUTTON")) message:ZuiPick5(OX_NS("Nhập tên mới cho nút này"), OX_NS("输入此按钮的新名称"), OX_NS("ป้อนชื่อใหม่สำหรับปุ่มนี้"), OX_NS("Inserisci un nuovo nome per questo pulsante"), OX_NS("Enter a new name for this button")) preferredStyle:UIAlertControllerStyleAlert];
    [dialog addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.text = oldName;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [dialog addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [dialog addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("MẶC ĐỊNH"), OX_NS("恢复默认"), OX_NS("ค่าเริ่มต้น"), OX_NS("PREDEFINITO"), OX_NS("DEFAULT")) style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        Ongnong::Zx8fSetMenuName(key, OX_NS(""), YES);
    }]];
    [dialog addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("LƯU"), OX_NS("保存"), OX_NS("บันทึก"), OX_NS("SALVA"), OX_NS("SAVE")) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = [dialog.textFields.firstObject.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (name.length == 0 || [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > 48 || [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding] == 0) return;
        Ongnong::Zx8fSetMenuName(key, name, NO);
    }]];
    [self presentViewController:dialog animated:YES completion:nil];
}

- (void)zServerMenuLabelsChanged:(NSNotification *)note {
    (void)note;
    NSString *code = OngnongUIVaultResolvedLanguageCode();
    [_v2p6k1 e4p7n1:code];
    [self zRefreshAltMenuTitles];
    [self q7m2d8];
    if (_n7c3m8) [_n7c3m8 n4q9c1];
}

- (void)c2m6r4 {
    if (_a9q2x4 && !_a9q2x4.hidden) [self e7k3p9];
    if (!_n7c3m8 || _n7c3m8.hidden || _n7c3m8.c8n3q6) return;
    if (_k4m8r2) return;
    _k4m8r2 = YES;
    Z9abcb7bb90 *controller = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.035 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        controller.k4m8r2 = NO;
        if (controller.n7c3m8 && !controller.n7c3m8.hidden && !controller.n7c3m8.c8n3q6) [controller.n7c3m8 n4q9c1];
    });
}

- (void)tick {
    [self q9d3m6];
    if (_a6t3y8) {
        _v2p6k1.hidden = YES;
        _b3n7v1.hidden = YES;
    }
    if (_a9q2x4 && !_a9q2x4.hidden) [self e7k3p9];
    _p6d1v7++;
    if (!_collapsed && (_p6d1v7 % 3 == 0)) [self q7m2d8];
}

- (void)z51bfdd51e4:(UIButton *)sender {
    Z0418c1e0ae();
}

- (NSInteger)n4d8k2:(NSInteger)value {
    if (value < 1) return 1;
    if (value > 201) return 201;
    return value;
}

- (NSInteger)c7m1p6:(NSString *)key defaultValue:(NSInteger)defaultValue {
    NSInteger saved = [[NSUserDefaults standardUserDefaults] integerForKey:key];
    if (saved <= 0) saved = defaultValue;
    return [self n4d8k2:saved];
}

- (NSInteger)v3q9a5 {
    return [self c7m1p6:qsec_s_0082() defaultValue:9];
}

- (NSInteger)x8r2n7 {
    return [self c7m1p6:qsec_s_0083() defaultValue:108];
}

- (void)b6k4d1:(NSInteger)value forKey:(NSString *)key {
    value = [self n4d8k2:value];
    [[NSUserDefaults standardUserDefaults] setInteger:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)y4n8d2:(NSString *)key defaultValue:(NSInteger)defaultValue selectedButton:(UIButton *)button {
    NSInteger current = [self c7m1p6:key defaultValue:defaultValue];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:ZuiSpeedTitle()
                                                                   message:ZuiSpeedMessage()
                                                            preferredStyle:UIAlertControllerStyleAlert];

    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.text = [NSString stringWithFormat:qsec_s_0086(), (long)current];
        textField.placeholder = qsec_s_0087();
    }];

    Z9abcb7bb90 *controller = self;
    [alert addAction:[UIAlertAction actionWithTitle:ZuiSaveText()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSString *valueText = alert.textFields.firstObject.text ?: [NSString string];
        NSInteger value = [controller n4d8k2:valueText.integerValue];
        [controller b6k4d1:value forKey:key];
        zce119e8048.z68593f2227 = (float)value;
        zce119e8048.zacc65d5e7b = true;
        zce119e8048.z904d9bb65a = false;
        Z108056b942();
        [controller q7m2d8];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText()
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    UIPopoverPresentationController *popover = alert.popoverPresentationController;
    if (popover) {
        popover.sourceView = button;
        popover.sourceRect = button.bounds;
        popover.permittedArrowDirections = UIPopoverArrowDirectionAny;
    }

    UIViewController *presenter = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (presenter.presentedViewController) presenter = presenter.presentedViewController;
    [presenter presentViewController:alert animated:YES completion:nil];
}

- (void)r2c6m8:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    Z0418c1e0ae();
    [self y4n8d2:qsec_s_0082() defaultValue:9 selectedButton:_a9q2x4.t2m7k6];
}

- (void)t7p3v1:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    Z0418c1e0ae();
    [self y4n8d2:qsec_s_0083() defaultValue:108 selectedButton:_a9q2x4.c8x1p4];
}

- (void)g5x9q4:(NSNotification *)note {
    ZThemeLoad();
    _v2p6k1.backgroundColor = ZThemePanelColor();
    ApplyNeon(_v2p6k1, ZThemeBorder(), 24.0, 1.2);
    _v2p6k1.r6q2p8.backgroundColor = ZThemeButtonOff();
    [_v2p6k1.r6q2p8 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    ApplyNeon(_v2p6k1.r6q2p8, ZThemeBorder(), 12.0, 1.0);
    _v2p6k1.k3v9d4.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_v2p6k1.k3v9d4, ZThemeBorder(), 12.0, 1.0);
    _v2p6k1.x8p4n2.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_v2p6k1.x8p4n2, ZThemeBorder(), 8.0, 1.0);
    _a9q2x4.backgroundColor = ZThemePanelColor();
    ApplyNeon(_a9q2x4, ZThemeBorder(), 14.0, 1.2);
    if (_n7c3m8) {
        _n7c3m8.backgroundColor = ZThemePanelDarker();
        ApplyNeon(_n7c3m8, ZThemeBorder(), 18.0, 1.2);
        _n7c3m8.closeButton.backgroundColor = ZThemeButtonOff();
        ApplyNeon(_n7c3m8.closeButton, ZThemeBorder(), 6.0, 0.75);
        ZPlainIconButton(_n7c3m8.k3v9d4, ZCounterTrashIconImage());
        ZPlainIconButton(_n7c3m8.eyeButton, ZCounterEyeIconImage(_n7c3m8.r2c7m4 != 0));
        _n7c3m8.d9q3x5.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.10];
    }
    _d2q8n4.backgroundColor = ZThemePanelColor();
    ApplyNeon(_d2q8n4, ZThemeBorder(), 16.0, 1.1);
    if (_w7p3v6) [_w7p3v6 f5q1m9];
    if (_q72p9m4) [_q72p9m4 refreshTheme];
    [self q2n9v6];
    _b3n7v1.backgroundColor = ZThemeButtonOff();
    ApplyNeon(_b3n7v1, ZThemeBorder(), 9.0, 1.0);
    if (_a9q2x4.r3n9d5) {
        _a9q2x4.r3n9d5.backgroundColor = ZThemeButtonOff();
        ApplyNeon(_a9q2x4.r3n9d5, ZThemeBorder(), 10.0, 1.2);
        _a9q2x4.r3n9d5.t2m8r5.backgroundColor = [UIColor clearColor];
        [self e7k3p9];
    }
    [self q7m2d8];
    if (_onThirdLayout) [self onThirdRefresh];
    if (_n7c3m8) {
        [_n7c3m8 setNeedsLayout];
        [_n7c3m8 n4q9c1];
    }
}

- (void)q7m2d8 {
    UIColor *buttonOff = ZThemeButtonOff();
    UIColor *border = ZThemeBorder();
    UIColor *green = ZThemeOnGreen();
    UIColor *red = ZThemeOffRed();
    UIColor *orange = ZThemeOrange();

    BOOL wifiOn = zce119e8048.z7180b46195;
    UIColor *wifiColor = wifiOn ? red : buttonOff;
    _a9q2x4.d5q9v3.r8m1v5 = wifiColor;
    [_a9q2x4.d5q9v3 setTitle:[NSString string] forState:UIControlStateNormal];
    [_a9q2x4.d5q9v3 setImage:Z9a3e7f9348() forState:UIControlStateNormal];
    _a9q2x4.d5q9v3.tintColor = ZThemeWhite();
    _a9q2x4.d5q9v3.imageEdgeInsets = UIEdgeInsetsMake(5.0, 5.0, 5.0, 5.0);
    _a9q2x4.d5q9v3.backgroundColor = wifiColor;
    ApplyNeon(_a9q2x4.d5q9v3, wifiOn ? red : border, 10.0, 1.2);

    BOOL speedAllowed = Ongnong::Zx8fSpeedAllowed();
    NSInteger speed9 = [self v3q9a5];
    NSInteger speed108 = [self x8r2n7];
    [_a9q2x4.t2m7k6 setImage:nil forState:UIControlStateNormal];
    [_a9q2x4.c8x1p4 setImage:nil forState:UIControlStateNormal];
    [_a9q2x4.t2m7k6 setTitle:[NSString stringWithFormat:qsec_s_0086(), (long)speed9] forState:UIControlStateNormal];
    [_a9q2x4.c8x1p4 setTitle:[NSString stringWithFormat:qsec_s_0086(), (long)speed108] forState:UIControlStateNormal];

    BOOL speed9Selected = speedAllowed && zce119e8048.zacc65d5e7b && ((NSInteger)lroundf(zce119e8048.z68593f2227) == speed9);
    BOOL speed108Selected = speedAllowed && zce119e8048.zacc65d5e7b && ((NSInteger)lroundf(zce119e8048.z68593f2227) == speed108);

    _a9q2x4.t2m7k6.enabled = speedAllowed;
    _a9q2x4.c8x1p4.enabled = speedAllowed;
    _a9q2x4.v6q2m8.enabled = speedAllowed;
    _a9q2x4.t2m7k6.alpha = speedAllowed ? 1.0 : 0.36;
    _a9q2x4.c8x1p4.alpha = speedAllowed ? 1.0 : 0.36;
    _a9q2x4.v6q2m8.alpha = speedAllowed ? 1.0 : 0.36;
    [_a9q2x4.t2m7k6 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.t2m7k6.backgroundColor = speed9Selected ? orange : buttonOff;
    _a9q2x4.t2m7k6.r8m1v5 = border;
    ApplyNeon(_a9q2x4.t2m7k6, speed9Selected ? orange : border, 10.0, 1.2);

    [_a9q2x4.c8x1p4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.c8x1p4.backgroundColor = speed108Selected ? orange : buttonOff;
    _a9q2x4.c8x1p4.r8m1v5 = border;
    ApplyNeon(_a9q2x4.c8x1p4, speed108Selected ? orange : border, 10.0, 1.2);

    [_a9q2x4.v6q2m8 setTitle:zce119e8048.z904d9bb65a ? qsec_s_0081() : qsec_s_0065() forState:UIControlStateNormal];
    [_a9q2x4.v6q2m8 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.v6q2m8.backgroundColor = (speedAllowed && zce119e8048.z904d9bb65a) ? orange : buttonOff;
    _a9q2x4.v6q2m8.r8m1v5 = border;
    ApplyNeon(_a9q2x4.v6q2m8, (speedAllowed && zce119e8048.z904d9bb65a) ? orange : border, 10.0, 1.2);

    BOOL skipOn = zce119e8048.z54007f39a0;
    UIColor *skipColor = skipOn ? red : buttonOff;
    _a9q2x4.k4p7c1.r8m1v5 = skipColor;
    [_a9q2x4.k4p7c1 setTitle:ZuiSkipText() forState:UIControlStateNormal];
    [_a9q2x4.k4p7c1 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [_a9q2x4.k4p7c1 setNeedsLayout];
    _a9q2x4.k4p7c1.backgroundColor = skipColor;
    ApplyNeon(_a9q2x4.k4p7c1, skipOn ? red : border, 10.0, 1.2);

    _a9q2x4.r3n9d5.backgroundColor = UIColor.clearColor;
    _a9q2x4.r3n9d5.layer.borderWidth = 0.0;
    _a9q2x4.r3n9d5.layer.shadowOpacity = 0.0;
    _a9q2x4.q4n8p2.backgroundColor = UIColor.clearColor;
    [_a9q2x4.q4n8p2 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    _a9q2x4.q4n8p2.layer.borderWidth = 0.0;
    _a9q2x4.q4n8p2.layer.shadowOpacity = 0.0;
    _a9q2x4.q4n8p2.layer.cornerRadius = 0.0;
    [_a9q2x4 setNeedsLayout];
    [self e7k3p9];

    Zcb66126fa3 *updateButton = _v2p6k1.a7m1c5.count > 0 ? _v2p6k1.a7m1c5[0] : nil;
    if (updateButton) {
        UIColor *redUpdate = RGB(220, 40, 45);
        updateButton.h5m2k8 = NO;
        updateButton.r8m1v5 = redUpdate;
        updateButton.backgroundColor = redUpdate;
        updateButton.x9c4n6.textColor = ZThemeWhite();
        updateButton.x9c4n6.layer.shadowOpacity = 0.0;
        ApplyNeon(updateButton, RGB(255, 80, 80), 14.0, 1.2);
    }
    Zcb66126fa3 *vipButton = _v2p6k1.a7m1c5.count > 1 ? _v2p6k1.a7m1c5[1] : nil;
    if (vipButton) {
        vipButton.x9c4n6.text = ZuiBuyVipText();
        [vipButton setNeedsLayout];
        UIColor *vipGold = RGB(203, 148, 20);
        vipButton.h5m2k8 = NO;
        vipButton.r8m1v5 = RGB(255, 212, 55);
        vipButton.backgroundColor = vipGold;
        vipButton.x9c4n6.textColor = ZThemeWhite();
        vipButton.x9c4n6.layer.shadowOpacity = 0.0;
        ApplyNeon(vipButton, RGB(255, 212, 55), 14.0, 1.2);
    }
    if (_v2p6k1.k3v9d4) {
        BOOL freeMode = [ZuiBuyVipText() isEqualToString:OX_NS("FREE")];
        _v2p6k1.k3v9d4.hidden = !freeMode || !Ongnong::Zx8fMenuItemVisible(OX_NS("upgrade_vip")) || _onThirdLayout;
        [_v2p6k1.k3v9d4 setTitle:ZVipBuyNowText() forState:UIControlStateNormal];
        _v2p6k1.k3v9d4.backgroundColor = RGB(18, 105, 45);
        _v2p6k1.k3v9d4.layer.borderColor = RGB(40, 155, 72).CGColor;
        [_v2p6k1 setNeedsLayout];
    }
    if (_v2p6k1.a7m1c5.count > 0) _v2p6k1.a7m1c5[0].hidden = !Ongnong::Zx8fMenuItemVisible(OX_NS("update"));
    if (_v2p6k1.a7m1c5.count > 1) {
        BOOL isVIPStatus = Ongnong::Zx8fIsVIP();
        _v2p6k1.a7m1c5[1].hidden = _onThirdLayout || !Ongnong::Zx8fMenuItemVisible(isVIPStatus ? OX_NS("vip") : OX_NS("free"));
    }
    BOOL mainMenuVIP = Ongnong::Zx8fIsVIP();
    BOOL counterAllowed = Ongnong::Zx8fCounterAllowed();
    BOOL betCycleAllowed = Ongnong::Zx8fBetCycleAllowed();
    Ongnong::R3ni(betCycleAllowed);
    Zcb66126fa3 *betCycleButton = _v2p6k1.a7m1c5.count > 11 ? _v2p6k1.a7m1c5[11] : nil;
    if (!betCycleAllowed && _q72p9m4) _q72p9m4.hidden = YES;
    if (betCycleButton) {
        NSString *betVisibilityKey = OX_NS("ongnong_main_visible_11");
        NSUserDefaults *betVisibilityPrefs = [NSUserDefaults standardUserDefaults];
        BOOL betPersonallyHidden = mainMenuVIP && [betVisibilityPrefs objectForKey:betVisibilityKey] && ![betVisibilityPrefs boolForKey:betVisibilityKey];
        betCycleButton.hidden = (!betCycleAllowed && mainMenuVIP) || betPersonallyHidden;
        betCycleButton.enabled = betCycleAllowed || !mainMenuVIP;
        betCycleButton.alpha = betCycleAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        [self w2k7e5:betCycleButton color:border active:(betCycleAllowed && _q72p9m4 && !_q72p9m4.hidden)];
    }
    Zcb66126fa3 *mergeButton = _v2p6k1.a7m1c5.count > 12 ? _v2p6k1.a7m1c5[12] : nil;
    BOOL mergeAllowed = Ongnong::Zx8fAutoMergeAllowed();
    if (!mergeAllowed) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        if (self.k2m8v4) self.k2m8v4.hidden = YES;
    }
    if (mergeButton) {
        mergeButton.hidden = !mergeAllowed && mainMenuVIP;
        mergeButton.enabled = mergeAllowed || !mainMenuVIP;
        mergeButton.alpha = mergeAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        mergeButton.x9c4n6.text = ZuiAutoMergeText();
        [self w2k7e5:mergeButton
                       color:RGB(120, 235, 170)
                      active:(mergeAllowed &&
                              Ongnong::AutoMergeModuleIsEnabled())];
    }
    Zcb66126fa3 *counterButton = _v2p6k1.a7m1c5.count > 2 ? _v2p6k1.a7m1c5[2] : nil;
    if (counterButton) { counterButton.hidden = !counterAllowed && mainMenuVIP; counterButton.enabled = counterAllowed || !mainMenuVIP; counterButton.alpha = counterAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); }
    [self w2k7e5:counterButton color:border active:(counterAllowed && _n7c3m8 && !_n7c3m8.hidden)];
    Zcb66126fa3 *buildButton = _v2p6k1.a7m1c5.count > 3 ? _v2p6k1.a7m1c5[3] : nil;
    Zcb66126fa3 *raidButton = _v2p6k1.a7m1c5.count > 4 ? _v2p6k1.a7m1c5[4] : nil;
    Zcb66126fa3 *magicButton = _v2p6k1.a7m1c5.count > 5 ? _v2p6k1.a7m1c5[5] : nil;
    BOOL buildOn = Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending();
    BOOL buildAllowed = Ongnong::Zx8fAutoBuildAllowed();
    BOOL magicAllowed = Ongnong::Zx8fMagicCardsAllowed();
    if (!magicAllowed) {
        if (Ongnong::MagicCardsModuleIsEnabled()) Ongnong::MagicCardsModuleSetEnabled(false);
        _r8m2d5 = NO;
        if (_u1x7p4) _u1x7p4.hidden = YES;
    }
    BOOL raidOn = Ongnong::RaidHammerModuleIsEnabled();
    BOOL magicOn = magicAllowed && Ongnong::MagicCardsModuleIsEnabled();
    if (!buildAllowed) {
        _v7m4q1 = NO;
        if (_b6p2x9) _b6p2x9.hidden = YES;
    }
    if (buildButton) { buildButton.hidden = mainMenuVIP && !buildAllowed; [self w2k7e5:buildButton color:border active:(buildAllowed && (buildOn || (_v7m4q1 && _b6p2x9 && !_b6p2x9.hidden)))]; }
    [self w2k7e5:raidButton color:border active:(raidOn || (_x4p7m2 && _e3k9d6 && !_e3k9d6.hidden))];
    BOOL buildLocked = raidOn || magicOn;
    BOOL raidLocked = buildOn || magicOn;
    BOOL magicLocked = buildOn || raidOn;
    if (buildButton) { buildButton.alpha = buildAllowed ? (buildLocked ? 0.42 : 1.0) : (mainMenuVIP ? 0.0 : 0.36); buildButton.enabled = buildAllowed ? !buildLocked : !mainMenuVIP; }
    if (raidButton) { raidButton.alpha = raidLocked ? 0.42 : 1.0; raidButton.enabled = !raidLocked; }
    if (_b6p2x9) { _b6p2x9.enabled = buildAllowed && !buildLocked; _b6p2x9.alpha = (buildAllowed && !buildLocked) ? 1.0 : 0.42; [self z3n8v5]; }
    if (_e3k9d6) { _e3k9d6.enabled = !raidLocked; _e3k9d6.alpha = raidLocked ? 0.42 : 1.0; [self w1p5c9]; }
    if (magicButton) {
        magicButton.hidden = !magicAllowed && mainMenuVIP;
        magicButton.x9c4n6.text = ZuiMagicCardsQuickText();
        [self w2k7e5:magicButton color:border active:(magicAllowed && (magicOn || (_r8m2d5 && _u1x7p4 && !_u1x7p4.hidden)))];
        magicButton.alpha = magicAllowed ? (magicLocked ? 0.42 : 1.0) : (mainMenuVIP ? 0.0 : 0.36);
        magicButton.enabled = magicAllowed ? !magicLocked : !mainMenuVIP;
    }
    if (_u1x7p4) {
        _u1x7p4.enabled = magicAllowed && !magicLocked;
        _u1x7p4.alpha = (magicAllowed && !magicLocked) ? 1.0 : 0.42;
    }
    Zcb66126fa3 *friendButton = _v2p6k1.a7m1c5.count > 13 ? _v2p6k1.a7m1c5[13] : nil;
    BOOL friendAllowed = Ongnong::Zx8fFriendInviteAllowed();
    if (friendButton) { friendButton.hidden = !friendAllowed && mainMenuVIP; friendButton.enabled = friendAllowed || !mainMenuVIP; friendButton.alpha = friendAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:friendButton color:RGB(90, 210, 255) active:NO]; }
    Zcb66126fa3 *potionMenuButton = _v2p6k1.a7m1c5.count > 14 ? _v2p6k1.a7m1c5[14] : nil;
    BOOL potionAllowed = Ongnong::Zx8fPotionAllowed();
    if (!potionAllowed && Ongnong::AutoPotionIsEnabled()) Ongnong::AutoPotionSetEnabled(NO);
    if (potionMenuButton) {
        BOOL potionOn = potionAllowed && Ongnong::AutoPotionIsEnabled();
        potionMenuButton.hidden = !potionAllowed && mainMenuVIP;
        potionMenuButton.enabled = potionAllowed || !mainMenuVIP;
        potionMenuButton.alpha = potionAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        potionMenuButton.x9c4n6.text = ZuiPotionStateText(potionOn);
        [self w2k7e5:potionMenuButton color:RGB(185, 105, 255) active:potionOn];
    }
    Zcb66126fa3 *autoClickButton = _v2p6k1.a7m1c5.count > 6 ? _v2p6k1.a7m1c5[6] : nil;
    BOOL autoClickAllowed = Ongnong::Zx8fAutoClickAllowed();
    if (!autoClickAllowed) [Z5e8402e1b3 d7x2p6:NO];
    if (autoClickButton) { autoClickButton.hidden = !autoClickAllowed && mainMenuVIP; autoClickButton.enabled = autoClickAllowed || !mainMenuVIP; autoClickButton.alpha = autoClickAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:autoClickButton color:border active:(autoClickAllowed && [Z5e8402e1b3 c3n9k5])]; }
    Zcb66126fa3 *toolsButton = _v2p6k1.a7m1c5.count > 7 ? _v2p6k1.a7m1c5[7] : nil;
    BOOL toolsAllowed = Ongnong::Zx8fToolsAllowed();
    if (!toolsAllowed && _a9q2x4) _a9q2x4.hidden = YES;
    BOOL toolVisible = toolsAllowed && (_a9q2x4 && !_a9q2x4.hidden);
    if (toolsButton) { toolsButton.hidden = _onThirdLayout || (!toolsAllowed && mainMenuVIP); toolsButton.enabled = toolsAllowed || !mainMenuVIP; toolsButton.alpha = toolsAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:toolsButton color:border active:toolVisible]; }
    Zcb66126fa3 *autoStopButton = _v2p6k1.a7m1c5.count > 8 ? _v2p6k1.a7m1c5[8] : nil;
    BOOL autoStopAllowed = Ongnong::Zx8fAutoStopAllowed();
    if (!autoStopAllowed && _d2q8n4) _d2q8n4.hidden = YES;
    if (autoStopButton) { autoStopButton.hidden = !autoStopAllowed && mainMenuVIP; autoStopButton.enabled = autoStopAllowed || !mainMenuVIP; autoStopButton.alpha = autoStopAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:autoStopButton color:border active:(autoStopAllowed && _d2q8n4 && !_d2q8n4.hidden)]; }
    Zcb66126fa3 *menuColorButton = _v2p6k1.a7m1c5.count > 9 ? _v2p6k1.a7m1c5[9] : nil;
    BOOL menuColorAllowed = Ongnong::Zx8fMenuColorAllowed();
    if (!menuColorAllowed && _w7p3v6) _w7p3v6.hidden = YES;
    if (menuColorButton) { menuColorButton.hidden = !menuColorAllowed && mainMenuVIP; menuColorButton.enabled = menuColorAllowed || !mainMenuVIP; menuColorButton.alpha = menuColorAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:menuColorButton color:border active:(menuColorAllowed && _w7p3v6 && !_w7p3v6.hidden)]; }
    BOOL raidAllowed = Ongnong::Zx8fRaidHammerAllowed();
    if (!raidAllowed) { Ongnong::RaidHammerModuleSetEnabled(false); _x4p7m2 = NO; if (_e3k9d6) _e3k9d6.hidden = YES; }
    if (raidButton) { raidButton.hidden = !raidAllowed && mainMenuVIP; raidButton.enabled = raidAllowed ? !raidLocked : !mainMenuVIP; raidButton.alpha = raidAllowed ? (raidLocked ? 0.42 : 1.0) : (mainMenuVIP ? 0.0 : 0.36); [self w2k7e5:raidButton color:border active:(raidAllowed && (raidOn || (_x4p7m2 && _e3k9d6 && !_e3k9d6.hidden)))]; }
    [self zRefreshAltMenuTitles];
    [_v2p6k1 setNeedsLayout];
    Zcb66126fa3 *expeditionButton = _v2p6k1.a7m1c5.count > 10 ? _v2p6k1.a7m1c5[10] : nil;
    BOOL expeditionAllowed = Ongnong::R7f401();
    if (!expeditionAllowed) {
        if (Ongnong::ExpeditionAutoIsEnabled()) {
            Ongnong::ExpeditionAutoSetEnabled(false);
        }
        _m3k9a2 = NO;
        if (_q8z1u4) {
            _q8z1u4.hidden = YES;
        }
    }
    if (expeditionButton) {
        expeditionButton.hidden = !expeditionAllowed && mainMenuVIP;
        expeditionButton.enabled = expeditionAllowed || !mainMenuVIP;
        expeditionButton.alpha = expeditionAllowed ? 1.0 : (mainMenuVIP ? 0.0 : 0.36);
        expeditionButton.x9c4n6.text = Zr7f421();
        [self w2k7e5:expeditionButton
                       color:border
                      active:(expeditionAllowed &&
                              _m3k9a2 &&
                              _q8z1u4 &&
                              !_q8z1u4.hidden)];
    }
    [self q2n9v6];
    NSUserDefaults *menuPrefs = [NSUserDefaults standardUserDefaults];
    for (NSUInteger menuIndex = 0; menuIndex < _v2p6k1.a7m1c5.count; menuIndex++) {
        if (menuIndex == 1 || menuIndex == 15) continue;
        NSString *visibilityKey = [NSString stringWithFormat:OX_NS("ongnong_main_visible_%lu"), (unsigned long)menuIndex];
        if (mainMenuVIP && [menuPrefs objectForKey:visibilityKey] && ![menuPrefs boolForKey:visibilityKey]) {
            _v2p6k1.a7m1c5[menuIndex].hidden = YES;
        }
    }
    [self onResizeMainMenuToVisibleButtons];
    [_v2p6k1 setNeedsLayout];
    if (_n7c3m8 && !_n7c3m8.hidden) {
        [_n7c3m8 setNeedsLayout];
        [_n7c3m8 n4q9c1];
    }
    if (_d2q8n4 && !_d2q8n4.hidden) {
        [_d2q8n4 r8p3d7];
        [_d2q8n4 a9m3c6];
        [_d2q8n4 setNeedsLayout];
    }
}

- (void)v4p9a1:(NSString *)code {
    [self d2x8q4];
    if (code.length == 0) code = qsec_s_0039();
    [[NSUserDefaults standardUserDefaults] setObject:code forKey:qsec_s_0075()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:OngnongUIVaultLanguageNotification() object:nil];
    [_v2p6k1 e4p7n1:code];
    if (_d2q8n4) {
        if (_d2q8n4.d7m2x6 <= 0) [_d2q8n4.h8m3x6 setTitle:ZuiSetText() forState:UIControlStateNormal];
        [_d2q8n4 setNeedsLayout];
    }
    if (_w7p3v6) [_w7p3v6 f5q1m9];
    [self h6d2q8];
    [self q7m2d8];
    [self q2n9v6];
    [self c3n7x5];
    [self zRefreshAltMenuTitles];
}

- (void)c8x3n6 {
    [self d2x8q4];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:ZuiLanguageTitle()
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    Z9abcb7bb90 *controller = self;

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0091()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0039()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0092()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0040()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0093()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0048()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:qsec_s_0094()
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:qsec_s_0056()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultEnglishAction)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        [controller v4p9a1:OngnongUIVaultLangCodeEN()];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText()
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];

    UIPopoverPresentationController *popover = alert.popoverPresentationController;
    if (popover) {
        popover.sourceView = _v2p6k1.r6q2p8;
        popover.sourceRect = _v2p6k1.r6q2p8.bounds;
        popover.permittedArrowDirections = UIPopoverArrowDirectionAny;
    }

    UIViewController *presenter = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (presenter.presentedViewController) presenter = presenter.presentedViewController;
    [presenter presentViewController:alert animated:YES completion:nil];
}

- (void)w2k7e5:(Zcb66126fa3 *)button color:(UIColor *)color active:(BOOL)active {
    if (!button) return;
    UIColor *useColor = active ? ZThemeActiveGreen() : ZThemeBorder();
    button.h5m2k8 = active;
    button.r8m1v5 = useColor;
    button.backgroundColor = active ? ZThemeActiveGreen() : ZThemeButtonOff();
    button.x9c4n6.textColor = ZThemeWhite();
    button.q3p7d2.textColor = active ? ZThemeWhite() : ZThemeBorder();
    button.x9c4n6.layer.shadowOpacity = 0.0;
    button.q3p7d2.layer.shadowOpacity = 0.0;
    ApplyNeon(button, active ? ZThemeActiveGreen() : ZThemeBorder(), 14.0, 1.1);
    [button setNeedsDisplay];
}


- (UIButton *)c4m8q2:(CGRect)frame title:(NSString *)title action:(SEL)action closeAction:(SEL)closeAction panAction:(SEL)panAction {
    UIButton *popup = [UIButton buttonWithType:UIButtonTypeCustom];
    popup.frame = frame;
    popup.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    popup.titleLabel.adjustsFontSizeToFitWidth = YES;
    popup.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    popup.layer.cornerRadius = 12.0;
    popup.layer.masksToBounds = NO;
    [popup setTitle:title forState:UIControlStateNormal];
    [popup setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [popup addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [popup addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:panAction];
    [popup addGestureRecognizer:pan];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeCustom];
    close.frame = CGRectMake(frame.size.width - 20.0, 2.0, 18.0, 18.0);
    [close setTitle:OX_NS("×") forState:UIControlStateNormal];
    [close setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    close.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    close.layer.cornerRadius = 9.0;
    close.layer.borderWidth = 0.7;
    close.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [close addTarget:self action:closeAction forControlEvents:UIControlEventTouchUpInside];
    [close addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    [popup addSubview:close];
    return popup;
}

- (void)b2v7n4 {
    if (_b6p2x9) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 50.0;
    if ([ud objectForKey:OX_NS("ab_float_x")]) x = [ud floatForKey:OX_NS("ab_float_x")];
    if ([ud objectForKey:OX_NS("ab_float_y")]) y = [ud floatForKey:OX_NS("ab_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _b6p2x9 = [self c4m8q2:CGRectMake(x, y, w, h) title:ZuiAutoBuildStateText(NO) action:@selector(g7q3m8) closeAction:@selector(t5x9c2) panAction:@selector(k1d6p4:)];
    _b6p2x9.hidden = YES;
    [self.view addSubview:_b6p2x9];
    [self z3n8v5];
}

- (void)z3n8v5 {
    if (!_b6p2x9) return;
    BOOL pending = Ongnong::AutoBuildModuleIsPending();
    BOOL on = Ongnong::AutoBuildModuleIsEnabled();
    [_b6p2x9 setTitle:(pending ? [NSString stringWithFormat:OX_NS("%@ %@"), ZuiAutoBuildText(), OX_NS("CHỜ")] : ZuiAutoBuildStateText(on)) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : (pending ? [UIColor orangeColor] : ZThemeOffRed());
    _b6p2x9.backgroundColor = [color colorWithAlphaComponent:0.90];
    _b6p2x9.layer.borderWidth = 1.1;
    _b6p2x9.layer.borderColor = color.CGColor;
    _b6p2x9.layer.shadowColor = color.CGColor;
    _b6p2x9.layer.shadowOpacity = 0.45;
    _b6p2x9.layer.shadowRadius = 8.0;
    _b6p2x9.layer.shadowOffset = CGSizeZero;
}

- (void)k1d6p4:(UIPanGestureRecognizer *)pan {
    if (!_b6p2x9 || !_b6p2x9.superview) return;
    UIView *superview = _b6p2x9.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _n5c8r2 = _b6p2x9.center;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(_n5c8r2.x + translation.x, _n5c8r2.y + translation.y);
        CGFloat halfW = _b6p2x9.bounds.size.width * 0.5;
        CGFloat halfH = _b6p2x9.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _b6p2x9.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_b6p2x9.frame.origin.x forKey:OX_NS("ab_float_x")];
            [ud setFloat:_b6p2x9.frame.origin.y forKey:OX_NS("ab_float_y")];
            [ud synchronize];
        }
    }
}

- (void)t5x9c2 {
    Ongnong::AutoBuildModuleSetEnabled(false);
    [self u7m1c9];
    _v7m4q1 = NO;
    if (_b6p2x9) _b6p2x9.hidden = YES;
    [self z3n8v5];
    [self q7m2d8];
}

- (void)g7q3m8 {
    [self d2x8q4];
    BOOL buildActiveOrPending = Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending();
    BOOL willEnable = !buildActiveOrPending;
    if (willEnable && !Ongnong::Zx8fAutoBuildAllowed()) { [self q7m2d8]; return; }
    if (willEnable && (Ongnong::RaidHammerModuleIsEnabled() || Ongnong::MagicCardsModuleIsEnabled())) {
        [self z3n8v5];
        [self q7m2d8];
        return;
    }
    if (willEnable) {
        [self j6t3a8];
        [self y4d8p2];
        Ongnong::AutoBuildModuleSetEnabled(true);
        if (!(Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending())) [self u7m1c9];
    } else {
        Ongnong::AutoBuildModuleSetEnabled(false);
        [self u7m1c9];
    }
    [self z3n8v5];
    [self q7m2d8];
}

- (void)v5c2q8 {
    if (_e3k9d6) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 96.0;
    if ([ud objectForKey:OX_NS("rh_float_x")]) x = [ud floatForKey:OX_NS("rh_float_x")];
    if ([ud objectForKey:OX_NS("rh_float_y")]) y = [ud floatForKey:OX_NS("rh_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _e3k9d6 = [self c4m8q2:CGRectMake(x, y, w, h) title:ZuiAutoPigHammerStateText(NO) action:@selector(y6m1p7) closeAction:@selector(q4d8x3) panAction:@selector(a9r2k6:)];
    _e3k9d6.hidden = YES;
    [self.view addSubview:_e3k9d6];
    [self w1p5c9];
}

- (void)w1p5c9 {
    if (!_e3k9d6) return;
    BOOL on = Ongnong::RaidHammerModuleIsEnabled();
    [_e3k9d6 setTitle:ZuiAutoPigHammerStateText(on) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    _e3k9d6.backgroundColor = [color colorWithAlphaComponent:0.90];
    _e3k9d6.layer.borderWidth = 1.1;
    _e3k9d6.layer.borderColor = color.CGColor;
    _e3k9d6.layer.shadowColor = color.CGColor;
    _e3k9d6.layer.shadowOpacity = 0.45;
    _e3k9d6.layer.shadowRadius = 8.0;
    _e3k9d6.layer.shadowOffset = CGSizeZero;
}

- (void)a9r2k6:(UIPanGestureRecognizer *)pan {
    if (!_e3k9d6 || !_e3k9d6.superview) return;
    UIView *superview = _e3k9d6.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _h8q1v5 = _e3k9d6.center;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(_h8q1v5.x + translation.x, _h8q1v5.y + translation.y);
        CGFloat halfW = _e3k9d6.bounds.size.width * 0.5;
        CGFloat halfH = _e3k9d6.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _e3k9d6.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_e3k9d6.frame.origin.x forKey:OX_NS("rh_float_x")];
            [ud setFloat:_e3k9d6.frame.origin.y forKey:OX_NS("rh_float_y")];
            [ud synchronize];
        }
    }
}

- (void)q4d8x3 {
    Ongnong::RaidHammerModuleSetEnabled(false);
    _x4p7m2 = NO;
    if (_e3k9d6) _e3k9d6.hidden = YES;
    [self w1p5c9];
    Z108056b942();
    [self q7m2d8];
}

- (void)y6m1p7 {
    [self d2x8q4];
    if (!Ongnong::Zx8fRaidHammerAllowed()) { Ongnong::RaidHammerModuleSetEnabled(false); [self q7m2d8]; return; }
    BOOL willEnable = !Ongnong::RaidHammerModuleIsEnabled();
    if (willEnable && ((Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending()) || Ongnong::MagicCardsModuleIsEnabled())) {
        [self w1p5c9];
        [self q7m2d8];
        return;
    }
    Ongnong::RaidHammerModuleToggle();
    [self w1p5c9];
    Z108056b942();
    [self q7m2d8];
}

- (void)r9b4t1 {
    if (_u1x7p4) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 96.0;
    if ([ud objectForKey:OX_NS("mc_float_x")]) x = [ud floatForKey:OX_NS("mc_float_x")];
    if ([ud objectForKey:OX_NS("mc_float_y")]) y = [ud floatForKey:OX_NS("mc_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _u1x7p4 = [UIButton buttonWithType:UIButtonTypeCustom];
    _u1x7p4.frame = CGRectMake(x, y, w, h);
    _u1x7p4.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    _u1x7p4.titleLabel.adjustsFontSizeToFitWidth = YES;
    _u1x7p4.layer.cornerRadius = 12.0;
    _u1x7p4.layer.masksToBounds = NO;
    [_u1x7p4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [_u1x7p4 addTarget:self action:@selector(s2k6v4) forControlEvents:UIControlEventTouchUpInside];
    [_u1x7p4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(p3v7m5:)];
    [_u1x7p4 addGestureRecognizer:pan];
    UIButton *magicClose = [UIButton buttonWithType:UIButtonTypeCustom];
    magicClose.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
    [magicClose setTitle:OX_NS("×") forState:UIControlStateNormal];
    [magicClose setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    magicClose.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    magicClose.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    magicClose.layer.cornerRadius = 9.0;
    magicClose.layer.borderWidth = 0.7;
    magicClose.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [magicClose addTarget:self action:@selector(zMagicPopupClose) forControlEvents:UIControlEventTouchUpInside];
    [_u1x7p4 addSubview:magicClose];
    _u1x7p4.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    _u1x7p4.hidden = YES;
    [self.view addSubview:_u1x7p4];
    [self h6d2q8];
}

- (void)h6d2q8 {
    if (!_u1x7p4) return;
    BOOL on = Ongnong::MagicCardsModuleIsEnabled();
    [_u1x7p4 setTitle:ZuiMagicCardsStateText(on) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    _u1x7p4.backgroundColor = [color colorWithAlphaComponent:0.90];
    _u1x7p4.layer.borderWidth = 1.1;
    _u1x7p4.layer.borderColor = color.CGColor;
    _u1x7p4.layer.shadowColor = color.CGColor;
    _u1x7p4.layer.shadowOpacity = 0.45;
    _u1x7p4.layer.shadowRadius = 8.0;
    _u1x7p4.layer.shadowOffset = CGSizeZero;
    [_u1x7p4 setNeedsLayout];
}

- (void)p3v7m5:(UIPanGestureRecognizer *)pan {
    if (!_u1x7p4 || !_u1x7p4.superview) return;
    UIView *superview = _u1x7p4.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _r6q2p8 = _u1x7p4.center;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(_r6q2p8.x + translation.x, _r6q2p8.y + translation.y);
        CGFloat halfW = _u1x7p4.bounds.size.width * 0.5;
        CGFloat halfH = _u1x7p4.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _u1x7p4.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_u1x7p4.frame.origin.x forKey:OX_NS("mc_float_x")];
            [ud setFloat:_u1x7p4.frame.origin.y forKey:OX_NS("mc_float_y")];
            [ud synchronize];
        }
    }
}

- (void)z8a5c1 {
    if (_q8z1u4) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0;
    CGFloat h = 38.0;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    CGFloat x = screen.size.width - w - 14.0;
    CGFloat y = 142.0;
    if ([ud objectForKey:OX_NS("exp_float_x")]) x = [ud floatForKey:OX_NS("exp_float_x")];
    if ([ud objectForKey:OX_NS("exp_float_y")]) y = [ud floatForKey:OX_NS("exp_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    _q8z1u4 = [UIButton buttonWithType:UIButtonTypeCustom];
    _q8z1u4.frame = CGRectMake(x, y, w, h);
    _q8z1u4.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    _q8z1u4.titleLabel.adjustsFontSizeToFitWidth = YES;
    _q8z1u4.titleLabel.minimumScaleFactor = 0.65;
    _q8z1u4.layer.cornerRadius = 12.0;
    _q8z1u4.layer.masksToBounds = NO;
    [_q8z1u4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [_q8z1u4 addTarget:self action:@selector(w3m7d2) forControlEvents:UIControlEventTouchUpInside];
    [_q8z1u4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(n1c8f5:)];
    pan.cancelsTouchesInView = NO;
    [_q8z1u4 addGestureRecognizer:pan];
    UIButton *forestClose = [UIButton buttonWithType:UIButtonTypeCustom];
    forestClose.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
    [forestClose setTitle:OX_NS("×") forState:UIControlStateNormal];
    [forestClose setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    forestClose.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    forestClose.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    forestClose.layer.cornerRadius = 9.0;
    forestClose.layer.borderWidth = 0.7;
    forestClose.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [forestClose addTarget:self action:@selector(zForestPopupClose) forControlEvents:UIControlEventTouchUpInside];
    [_q8z1u4 addSubview:forestClose];
    _q8z1u4.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    _q8z1u4.hidden = YES;
    [self.view addSubview:_q8z1u4];
    [self q2n9v6];
}

- (void)q2n9v6 {
    if (!_q8z1u4) return;
    if (!Ongnong::R7f401()) {
        if (Ongnong::ExpeditionAutoIsEnabled()) {
            Ongnong::ExpeditionAutoSetEnabled(false);
        }
        _m3k9a2 = NO;
        _q8z1u4.hidden = YES;
        return;
    }
    BOOL on = Ongnong::ExpeditionAutoIsEnabled() ? YES : NO;
    [_q8z1u4 setTitle:Zr7f422(on) forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    _q8z1u4.backgroundColor = [color colorWithAlphaComponent:0.90];
    _q8z1u4.layer.borderWidth = 1.1;
    _q8z1u4.layer.borderColor = color.CGColor;
    _q8z1u4.layer.shadowColor = color.CGColor;
    _q8z1u4.layer.shadowOpacity = 0.45;
    _q8z1u4.layer.shadowRadius = 8.0;
    _q8z1u4.layer.shadowOffset = CGSizeZero;
    [_q8z1u4 setNeedsLayout];
}

- (void)v7b2c9 {
    if (!_q72p9m4 || !Ongnong::Zx8fBetCycleAllowed()) {
        Ongnong::R3ni(NO);
        if (_q72p9m4) _q72p9m4.hidden = YES;
        [self zShowMainVipRequiredAtIndex:11];
        [self q7m2d8];
        return;
    }
    _q72p9m4.hidden = !_q72p9m4.hidden;
    if (!_q72p9m4.hidden) {
        [_q72p9m4 refreshAll];
        [self.view bringSubviewToFront:_q72p9m4];
    }
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)h5p1k8 {
    [self d2x8q4];
    if (!Ongnong::R7f401()) {
        Ongnong::ExpeditionAutoSetEnabled(false);
        _m3k9a2 = NO;
        if (_q8z1u4) {
            _q8z1u4.hidden = YES;
        }
        [self zShowMainVipRequiredAtIndex:10];
        [self q7m2d8];
        return;
    }
    [self z8a5c1];
    _m3k9a2 = !_m3k9a2;
    if (_m3k9a2) {
        _q8z1u4.hidden = NO;
        [self.view bringSubviewToFront:_q8z1u4];
    } else {
        Ongnong::ExpeditionAutoSetEnabled(false);
        _q8z1u4.hidden = YES;
    }
    [self q2n9v6];
    [self q7m2d8];
}

- (void)w3m7d2 {
    if (!Ongnong::R7f401()) {
        Ongnong::ExpeditionAutoSetEnabled(false);
        _m3k9a2 = NO;
        if (_q8z1u4) {
            _q8z1u4.hidden = YES;
        }
        [self q7m2d8];
        return;
    }
    Ongnong::ExpeditionAutoSetEnabled(
        !Ongnong::ExpeditionAutoIsEnabled());
    [self q2n9v6];
    [self q7m2d8];
}

- (void)b6x4j9:(NSNotification *)note {
    (void)note;
    [self q2n9v6];
}

- (void)n1c8f5:(UIPanGestureRecognizer *)pan {
    if (!_q8z1u4 || !_q8z1u4.superview) return;
    UIView *superview = _q8z1u4.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) {
        _c7w2e6 = _q8z1u4.center;
        _zForestDragging = NO;
    } else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        if (!_zForestDragging && hypot(translation.x, translation.y) >= 7.0) _zForestDragging = YES;
        if (!_zForestDragging && pan.state == UIGestureRecognizerStateChanged) return;
        CGPoint c = CGPointMake(_c7w2e6.x + translation.x, _c7w2e6.y + translation.y);
        CGFloat halfW = _q8z1u4.bounds.size.width * 0.5;
        CGFloat halfH = _q8z1u4.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        _q8z1u4.center = c;
        if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setFloat:_q8z1u4.frame.origin.x forKey:OX_NS("exp_float_x")];
            [ud setFloat:_q8z1u4.frame.origin.y forKey:OX_NS("exp_float_y")];
            [ud synchronize];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.14 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.zForestDragging = NO;
            });
        }
    }
}


- (void)j6t3a8 {
    if (_n3q9c6) return;
    _c9m5r3 = zce119e8048.z68593f2227;
    _b7v1k8 = zce119e8048.zacc65d5e7b;
    _t4p6x2 = zce119e8048.z904d9bb65a;
    _n3q9c6 = YES;
}

- (void)y4d8p2 {
    zce119e8048.z68593f2227 = (float)[self v3q9a5];
    zce119e8048.zacc65d5e7b = true;
    zce119e8048.z904d9bb65a = false;
    Z108056b942();
}

- (void)u7m1c9 {
    if (!_n3q9c6) return;
    zce119e8048.z68593f2227 = _c9m5r3;
    zce119e8048.zacc65d5e7b = _b7v1k8;
    zce119e8048.z904d9bb65a = _t4p6x2;
    _n3q9c6 = NO;
    Z108056b942();
}

- (void)f3q6v8 {
    _n3q9c6 = NO;
}

- (void)m8c2r6 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoBuildAllowed()) { [self zShowMainVipRequiredAtIndex:3]; [self q7m2d8]; return; }
    [self b2v7n4];
    _v7m4q1 = YES;
    _b6p2x9.hidden = NO;
    [self.view bringSubviewToFront:_b6p2x9];
    [self z3n8v5];
    [self q7m2d8];
}

- (void)f5n9x1 {
    [self d2x8q4];
    if (!Ongnong::Zx8fRaidHammerAllowed()) { Ongnong::RaidHammerModuleSetEnabled(false); [self zShowMainVipRequiredAtIndex:4]; [self q7m2d8]; return; }
    [self v5c2q8];
    _x4p7m2 = YES;
    _e3k9d6.hidden = NO;
    [self.view bringSubviewToFront:_e3k9d6];
    [self w1p5c9];
    [self q7m2d8];
}

- (void)a7q3d8 {
    [self d2x8q4];
    if (!Ongnong::Zx8fMagicCardsAllowed()) {
        _r8m2d5 = NO;
        if (_u1x7p4) _u1x7p4.hidden = YES;
        Ongnong::MagicCardsModuleSetEnabled(false);
        [self zShowMainVipRequiredAtIndex:5];
        [self q7m2d8];
        return;
    }
    BOOL willShow = !_r8m2d5;
    if (willShow && ((Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending()) || Ongnong::RaidHammerModuleIsEnabled())) {
        [self q7m2d8];
        return;
    }
    [self r9b4t1];
    _r8m2d5 = willShow;
    if (_r8m2d5) {
        _u1x7p4.hidden = NO;
        [self.view bringSubviewToFront:_u1x7p4];
    } else {
        Ongnong::MagicCardsModuleSetEnabled(false);
        _u1x7p4.hidden = YES;
    }
    [self h6d2q8];
    [self w2k7e5:_v2p6k1.a7m1c5.count > 5 ? _v2p6k1.a7m1c5[5] : nil color:ZThemeBorder() active:_r8m2d5];
    [self q7m2d8];
}

- (void)s2k6v4 {
    if (!Ongnong::Zx8fMagicCardsAllowed()) {
        Ongnong::MagicCardsModuleSetEnabled(false);
        if (_u1x7p4) _u1x7p4.hidden = YES;
        _r8m2d5 = NO;
        [self q7m2d8];
        return;
    }
    BOOL willEnable = !Ongnong::MagicCardsModuleIsEnabled();
    if (willEnable && ((Ongnong::AutoBuildModuleIsEnabled() || Ongnong::AutoBuildModuleIsPending()) || Ongnong::RaidHammerModuleIsEnabled())) {
        [self h6d2q8];
        [self q7m2d8];
        return;
    }
    Ongnong::MagicCardsModuleToggle();
    [self h6d2q8];
    [self q7m2d8];
}


- (void)z6m4a8 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoMergeAllowed()) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        if (self.k2m8v4) self.k2m8v4.hidden = YES;
        [self zShowMainVipRequiredAtIndex:12];
        [self q7m2d8];
        return;
    }
    [self u4m8p2];
    self.p7x3n6 = !self.p7x3n6;
    self.k2m8v4.hidden = !self.p7x3n6;
    if (self.p7x3n6) [self.view bringSubviewToFront:self.k2m8v4];
    [self c3n7x5];
    Zcb66126fa3 *button = _v2p6k1.a7m1c5.count > 12 ? _v2p6k1.a7m1c5[12] : nil;
    if (button) [self w2k7e5:button color:RGB(120, 235, 170) active:self.p7x3n6];
    [self q7m2d8];
}

- (void)u4m8p2 {
    if (self.k2m8v4) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat w = 132.0, h = 38.0;
    NSUserDefaults *ud = NSUserDefaults.standardUserDefaults;
    CGFloat x = screen.size.width - w - 14.0, y = 190.0;
    if ([ud objectForKey:OX_NS("merge_float_x")]) x = [ud floatForKey:OX_NS("merge_float_x")];
    if ([ud objectForKey:OX_NS("merge_float_y")]) y = [ud floatForKey:OX_NS("merge_float_y")];
    x = MAX(8.0, MIN(screen.size.width - w - 8.0, x));
    y = MAX(42.0, MIN(screen.size.height - h - 8.0, y));
    self.k2m8v4 = [UIButton buttonWithType:UIButtonTypeCustom];
    self.k2m8v4.frame = CGRectMake(x, y, w, h);
    self.k2m8v4.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightHeavy];
    self.k2m8v4.titleLabel.adjustsFontSizeToFitWidth = YES;
    self.k2m8v4.titleLabel.minimumScaleFactor = 0.65;
    self.k2m8v4.layer.cornerRadius = 12.0;
    self.k2m8v4.layer.masksToBounds = NO;
    [self.k2m8v4 setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    [self.k2m8v4 addTarget:self action:@selector(r9k2d6) forControlEvents:UIControlEventTouchUpInside];
    [self.k2m8v4 addTarget:self action:@selector(z51bfdd51e4:) forControlEvents:UIControlEventTouchDown];
    UILongPressGestureRecognizer *orderHold = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(orderDiagHold:)];
    orderHold.minimumPressDuration = 1.0;
    orderHold.cancelsTouchesInView = YES;
    [self.k2m8v4 addGestureRecognizer:orderHold];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(y5v1q8:)];
    [self.k2m8v4 addGestureRecognizer:pan];
    UIButton *mergeClose = [UIButton buttonWithType:UIButtonTypeCustom];
    mergeClose.frame = CGRectMake(w - 20.0, 2.0, 18.0, 18.0);
    [mergeClose setTitle:OX_NS("×") forState:UIControlStateNormal];
    [mergeClose setTitleColor:ZThemeWhite() forState:UIControlStateNormal];
    mergeClose.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBlack];
    mergeClose.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.28];
    mergeClose.layer.cornerRadius = 9.0;
    mergeClose.layer.borderWidth = 0.7;
    mergeClose.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.62].CGColor;
    [mergeClose addTarget:self action:@selector(zMergePopupClose) forControlEvents:UIControlEventTouchUpInside];
    [self.k2m8v4 addSubview:mergeClose];
    self.k2m8v4.contentEdgeInsets = UIEdgeInsetsMake(0.0, 4.0, 0.0, 21.0);
    self.k2m8v4.hidden = YES;
    [self.view addSubview:self.k2m8v4];
    [self c3n7x5];
}

- (void)n8q4m2:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self c3n7x5];
        [self q7m2d8];
    });
}

- (void)c3n7x5 {
    if (!self.k2m8v4) return;
    if (!Ongnong::Zx8fAutoMergeAllowed()) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        self.k2m8v4.hidden = YES;
        return;
    }
    BOOL on = Ongnong::AutoMergeModuleIsEnabled();
    [self.k2m8v4 setTitle:OngnongUIVaultText(
                                on
                                    ? OngnongUIVaultAutoMergeOn
                                    : OngnongUIVaultAutoMergeOff)
                       forState:UIControlStateNormal];
    UIColor *color = on ? ZThemeOnGreen() : ZThemeOffRed();
    self.k2m8v4.backgroundColor = [color colorWithAlphaComponent:0.90];
    self.k2m8v4.layer.borderWidth = 1.1;
    self.k2m8v4.layer.borderColor = color.CGColor;
    self.k2m8v4.layer.shadowColor = color.CGColor;
    self.k2m8v4.layer.shadowOpacity = 0.45;
    self.k2m8v4.layer.shadowRadius = 8.0;
    self.k2m8v4.layer.shadowOffset = CGSizeZero;
}


- (void)orderDiagHold:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    NSString *details = Ongnong::AutoMergeOrderDebugCopy();
    [UIPasteboard generalPasteboard].string = details ?: @"";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:OX_NS("ĐÃ SAO CHÉP ORDER EXPRESS") message:OX_NS("Đã sao chép nhật ký vào bộ nhớ tạm. Dán trực tiếp vào cuộc trò chuyện để kiểm tra.") preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleDefault handler:nil]];
    UIViewController *top = self;
    while (top.presentedViewController) top = top.presentedViewController;
    [top presentViewController:alert animated:YES completion:nil];
}

- (void)r9k2d6 {
    if (!Ongnong::Zx8fAutoMergeAllowed()) {
        Ongnong::AutoMergeModuleSetEnabled(false);
        self.p7x3n6 = NO;
        if (self.k2m8v4) self.k2m8v4.hidden = YES;
        [self q7m2d8];
        return;
    }
    Ongnong::AutoMergeModuleToggle();
    [self c3n7x5];
    [self q7m2d8];
}

- (void)y5v1q8:(UIPanGestureRecognizer *)pan {
    if (!self.k2m8v4 || !self.k2m8v4.superview) return;
    UIView *superview = self.k2m8v4.superview;
    CGPoint translation = [pan translationInView:superview];
    if (pan.state == UIGestureRecognizerStateBegan) self.a4q9d1 = self.k2m8v4.center;
    else if (pan.state == UIGestureRecognizerStateChanged || pan.state == UIGestureRecognizerStateEnded) {
        CGPoint c = CGPointMake(self.a4q9d1.x + translation.x, self.a4q9d1.y + translation.y);
        CGFloat halfW = self.k2m8v4.bounds.size.width * 0.5, halfH = self.k2m8v4.bounds.size.height * 0.5;
        c.x = MAX(halfW + 8.0, MIN(superview.bounds.size.width - halfW - 8.0, c.x));
        c.y = MAX(halfH + 42.0, MIN(superview.bounds.size.height - halfH - 8.0, c.y));
        self.k2m8v4.center = c;
        if (pan.state == UIGestureRecognizerStateEnded) {
            NSUserDefaults *ud = NSUserDefaults.standardUserDefaults;
            [ud setFloat:self.k2m8v4.frame.origin.x forKey:OX_NS("merge_float_x")];
            [ud setFloat:self.k2m8v4.frame.origin.y forKey:OX_NS("merge_float_y")];
            [ud synchronize];
        }
    }
}

- (void)e9m1p7 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoClickAllowed()) { [Z5e8402e1b3 d7x2p6:NO]; [self zShowMainVipRequiredAtIndex:6]; [self q7m2d8]; return; }
    BOOL willShow = ![Z5e8402e1b3 c3n9k5];
    [Z5e8402e1b3 d7x2p6:willShow];
    [self q7m2d8];
    [self w2k7e5:_v2p6k1.a7m1c5.count > 6 ? _v2p6k1.a7m1c5[6] : nil color:RGB(45, 255, 70) active:willShow];
}

- (void)b4x8c3 {
    [self d2x8q4];
    if (!Ongnong::Zx8fToolsAllowed()) { if (_a9q2x4) _a9q2x4.hidden = YES; [self zShowMainVipRequiredAtIndex:7]; [self q7m2d8]; return; }
    BOOL panelVisible = (_a9q2x4 && !_a9q2x4.hidden);
    if (panelVisible) {
        [self zSaveQuickPanelFrame];
        _a9q2x4.hidden = YES;
        _h1x9c5 = YES;
    } else {
        if (!_a9q2x4) return;
        _h1x9c5 = NO;
        if (CGRectIsEmpty(_a9q2x4.frame)) [self p8c4n2];
        _a9q2x4.hidden = NO;
        [self.view bringSubviewToFront:_a9q2x4];
        [self e7k3p9];
        [self zSaveQuickPanelFrame];
    }
    [self q7m2d8];
}

- (void)t6r2n9 {
    [self d2x8q4];
    if (!Ongnong::Zx8fAutoStopAllowed()) { if (_d2q8n4) _d2q8n4.hidden = YES; [self zShowMainVipRequiredAtIndex:8]; [self q7m2d8]; return; }
    if (!_d2q8n4) return;
    _d2q8n4.hidden = !_d2q8n4.hidden;
    if (!_d2q8n4.hidden) {
        _d2q8n4.v3n8p4 = YES;
        [_d2q8n4 k9m2c8:YES];
        [self.view bringSubviewToFront:_d2q8n4];
    }
    [self q7m2d8];
}

- (void)j3v7q5 {
    [self d2x8q4];
    if (!Ongnong::Zx8fMenuColorAllowed()) { if (_w7p3v6) _w7p3v6.hidden = YES; [self zShowMainVipRequiredAtIndex:9]; [self q7m2d8]; return; }
    if (!_w7p3v6) return;
    _w7p3v6.hidden = !_w7p3v6.hidden;
    [[NSUserDefaults standardUserDefaults] setBool:!_w7p3v6.hidden forKey:ZThemeVisibleKey()];
    [[NSUserDefaults standardUserDefaults] synchronize];
    if (!_w7p3v6.hidden) {
        [_w7p3v6 f5q1m9];
        [self.view bringSubviewToFront:_w7p3v6];
    }
    [self q7m2d8];
    Z0418c1e0ae();
}

- (void)d8k4m1 {
    zce119e8048.z7180b46195 = !zce119e8048.z7180b46195;
    Z108056b942();
    [self q7m2d8];
}

- (void)y2p6a9 {
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    zce119e8048.z68593f2227 = (float)[self v3q9a5];
    zce119e8048.zacc65d5e7b = true;
    zce119e8048.z904d9bb65a = false;
    Z108056b942();
    [self q7m2d8];
}

- (void)u7c3x8 {
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    if (Ongnong::AutoBuildModuleIsEnabled()) {
        Ongnong::AutoBuildModuleSetEnabled(false);
        [self f3q6v8];
        if (_v2p6k1.a7m1c5.count > 3) [self w2k7e5:_v2p6k1.a7m1c5[3] color:RGB(50, 190, 255) active:NO];
    }
    zce119e8048.z68593f2227 = (float)[self x8r2n7];
    zce119e8048.zacc65d5e7b = true;
    zce119e8048.z904d9bb65a = false;
    Z108056b942();
    [self q7m2d8];
}

- (void)n5q1r4 {
    if (!Ongnong::Zx8fSpeedAllowed()) return;
    zce119e8048.z904d9bb65a = !zce119e8048.z904d9bb65a;
    zce119e8048.zacc65d5e7b = true;
    Z108056b942();
    [self q7m2d8];
}

- (void)g9v2d6 {
    zce119e8048.z54007f39a0 = !zce119e8048.z54007f39a0;
    Z108056b942();
    [self q7m2d8];
}

- (void)l4m8k3 {
    [self d2x8q4];
    if (!Ongnong::Zx8fCounterAllowed()) { if (_n7c3m8) _n7c3m8.hidden = YES; [self zShowMainVipRequiredAtIndex:2]; [self q7m2d8]; return; }
    [self h2p7m9];
    _n7c3m8.hidden = !_n7c3m8.hidden;
    if (_n7c3m8.hidden && _n7c3m8.eyePalette.superview) [_n7c3m8.eyePalette removeFromSuperview];
    if (!_n7c3m8.hidden) {
        [_n7c3m8 n4q9c1];
        [self.view bringSubviewToFront:_n7c3m8];
    }
    [self zSaveCounterPanelFrame];
    [self q7m2d8];
}

- (void)x1c7p5 {
    [self d2x8q4];
    if (!Ongnong::Zx8fCounterAllowed()) return;
    Z2b9185919a();
    Z5eca9eb2c9();
}

- (void)q6d9b2 {
    [self h9r3v7];
    CGFloat s = z067adc83c5();
    CGRect z7fa19172fd = _v2p6k1.frame;
    BOOL willCollapse = !_collapsed;

    if (willCollapse) {
        _x5m9c2 = _v2p6k1.frame;
        z7fa19172fd.origin.x = -z7fa19172fd.size.width;
        CGRect handleTarget = [self collapseHandleFrameForMenuFrame:z7fa19172fd collapsed:YES];

        _collapsed = YES;
        [_b3n7v1 setTitle:qsec_s_0081() forState:UIControlStateNormal];
        _v2p6k1.transform = CGAffineTransformIdentity;
        _v2p6k1.frame = z7fa19172fd;
        _b3n7v1.frame = handleTarget;
        return;
    }

    z7fa19172fd = _x5m9c2;
    z7fa19172fd.origin.x = MAX(6.0 * s, z7fa19172fd.origin.x);
    CGRect handleTarget = [self collapseHandleFrameForMenuFrame:z7fa19172fd collapsed:NO];

    [UIView animateWithDuration:0.12 animations:^{
        _v2p6k1.transform = CGAffineTransformIdentity;
        _v2p6k1.frame = z7fa19172fd;
        _b3n7v1.frame = handleTarget;
    } completion:^(BOOL finished) {
        _collapsed = NO;
        [_b3n7v1 setTitle:qsec_s_0038() forState:UIControlStateNormal];
        [self d2x8q4];
    }];
}

- (void)dealloc {
    [self h9r3v7];
    [_timer invalidate];
    _timer = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)v3n8a4:(NSString *)urlString {
    [self d2x8q4];
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:url];
        }
    });
}

- (void)k7p2m6 {
    NSString *url = Ongnong::Zx8fUpdateURL();
    if (url.length == 0) url = OX_NS("https://ongnong.io.vn/chungchi/game-download.php");
    [self v3n8a4:url];
}

- (void)zOpenInternationalCheckout {
    [self d2x8q4];
    NSString *device = Ongnong::Zx8fDeviceId() ?: OX_NS("");
    NSURLComponents *components = [NSURLComponents componentsWithString:OX_NS("https://ongnong.io.vn/pay")];
    if (!components) return;
    NSMutableArray<NSURLQueryItem *> *items = [NSMutableArray array];
    [items addObject:[NSURLQueryItem queryItemWithName:OX_NS("platform") value:OX_NS("ios")]];
    if (device.length > 0) [items addObject:[NSURLQueryItem queryItemWithName:OX_NS("code") value:device]];
    components.queryItems = items;
    NSURL *url = components.URL;
    if (!url) return;
    [self v3n8a4:url.absoluteString];
}

- (void)zShowBuyVipRegionPicker {
    [self zBuyVipPayOS];
}

- (void)zBuyVipPayOS {
    [self d2x8q4];
    [self zVipLoadPlans];
}

- (void)zVipLoadPlans {
    NSString *device = Ongnong::Zx8fDeviceId() ?: OX_NS("");
    UIAlertController *loading = [UIAlertController alertControllerWithTitle:ZVipBuyNowText()
                                                                      message:ZuiPick5(OX_NS("Đang tải các gói từ máy chủ..."), OX_NS("正在从服务器加载套餐..."), OX_NS("กำลังโหลดแพ็กเกจจากเซิร์ฟเวอร์..."), OX_NS("Caricamento pacchetti dal server..."), OX_NS("Loading plans from server..."))
                                                               preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:loading animated:YES completion:nil];
    NSURL *url = [NSURL URLWithString:OX_NS("https://ongnong.io.vn/chungchi/keyshop/plans.php")];
    [[[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *json = error ? nil : ZVipJSON(data);
        NSArray *plans = [json[OX_NS("plans")] isKindOfClass:[NSArray class]] ? json[OX_NS("plans")] : nil;
        BOOL ok = [json[OX_NS("ok")] boolValue] && [json[OX_NS("enabled")] boolValue] && plans.count > 0;
        dispatch_async(dispatch_get_main_queue(), ^{
            [loading dismissViewControllerAnimated:NO completion:^{
                if (!ok) {
                    UIAlertController *e = [UIAlertController alertControllerWithTitle:ZVipBuyNowText()
                                                                                message:ZuiPick5(OX_NS("Không tải được gói VIP. Vui lòng thử lại."), OX_NS("无法加载 VIP 套餐，请重试。"), OX_NS("ไม่สามารถโหลดแพ็กเกจ VIP ได้ โปรดลองอีกครั้ง"), OX_NS("Impossibile caricare i pacchetti VIP. Riprova."), OX_NS("Could not load VIP plans. Please try again."))
                                                                         preferredStyle:UIAlertControllerStyleAlert];
                    [e addAction:[UIAlertAction actionWithTitle:ZVipCloseText() style:UIAlertActionStyleCancel handler:nil]];
                    [self presentViewController:e animated:YES completion:nil];
                    return;
                }
                NSString *msg = [NSString stringWithFormat:ZuiPick5(OX_NS("Mã kích hoạt: %@"), OX_NS("激活码：%@"), OX_NS("รหัสเปิดใช้งาน: %@"), OX_NS("Codice attivazione: %@"), OX_NS("Activation code: %@")), device];
                UIAlertController *picker = [UIAlertController alertControllerWithTitle:ZVipChoosePlanText() message:msg preferredStyle:UIAlertControllerStyleAlert];
                [picker addAction:[UIAlertAction actionWithTitle:ZVipCopyText() style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                    UIPasteboard.generalPasteboard.string = device;
                }]];
                for (NSDictionary *p in plans) {
                    NSString *pid = [p[OX_NS("id")] description] ?: OX_NS("");
                    NSInteger amount = [p[OX_NS("amount")] integerValue];
                    NSString *label = [p[OX_NS("label")] description] ?: pid;
                    if (pid.length == 0 || amount <= 0) continue;
                    NSString *title = [NSString stringWithFormat:OX_NS("%@  •  %@"), label, ZVipMoney(amount)];
                    [picker addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                        UIAlertController *wait = [UIAlertController alertControllerWithTitle:label
                                                                                      message:ZuiPick5(OX_NS("Đang tạo mã QR PayOS..."), OX_NS("正在生成 PayOS 二维码..."), OX_NS("กำลังสร้าง QR PayOS..."), OX_NS("Creazione QR PayOS..."), OX_NS("Creating PayOS QR..."))
                                                                               preferredStyle:UIAlertControllerStyleAlert];
                        [self presentViewController:wait animated:YES completion:nil];
                        NSDictionary *body = @{OX_NS("platform"):OX_NS("ios"), OX_NS("plan"):pid, OX_NS("device_id"):device, OX_NS("customer_name"):OX_NS(""), OX_NS("payment_method"):OX_NS("vn"), OX_NS("lang"):OngnongUIVaultResolvedLanguageCode() ?: OX_NS("vi")};
                        NSData *bodyData = [NSJSONSerialization dataWithJSONObject:body options:0 error:nil];
                        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:OX_NS("https://ongnong.io.vn/chungchi/keyshop/create.php")]];
                        req.HTTPMethod = OX_NS("POST");
                        req.timeoutInterval = 10.0;
                        req.HTTPBody = bodyData;
                        [req setValue:OX_NS("application/json; charset=utf-8") forHTTPHeaderField:OX_NS("Content-Type")];
                        [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *d, NSURLResponse *r, NSError *err) {
                            NSDictionary *j = err ? nil : ZVipJSON(d);
                            BOOL created = [j[OX_NS("ok")] boolValue];
                            NSString *order = [j[OX_NS("order_code")] description] ?: OX_NS("");
                            NSString *token = [j[OX_NS("status_token")] description] ?: OX_NS("");
                            NSString *qr = [j[OX_NS("qr_code")] description] ?: OX_NS("");
                            NSInteger finalAmount = [j[OX_NS("amount")] integerValue];
                            if (finalAmount <= 0) finalAmount = amount;
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [wait dismissViewControllerAnimated:NO completion:^{
                                    if (!created || order.length == 0 || token.length == 0 || qr.length == 0) {
                                        UIAlertController *e2 = [UIAlertController alertControllerWithTitle:ZVipBuyNowText()
                                                                                                     message:ZuiPick5(OX_NS("Không tạo được mã QR PayOS. Vui lòng thử lại."), OX_NS("无法创建 PayOS 二维码，请重试。"), OX_NS("ไม่สามารถสร้าง QR PayOS ได้ โปรดลองอีกครั้ง"), OX_NS("Impossibile creare il QR PayOS. Riprova."), OX_NS("Could not create the PayOS QR. Please try again."))
                                                                                              preferredStyle:UIAlertControllerStyleAlert];
                                        [e2 addAction:[UIAlertAction actionWithTitle:ZVipCloseText() style:UIAlertActionStyleCancel handler:nil]];
                                        [self presentViewController:e2 animated:YES completion:nil];
                                        return;
                                    }
                                    ZVipPayController *pay = [[ZVipPayController alloc] init];
                                    pay.orderCode = order;
                                    pay.statusToken = token;
                                    pay.modalPresentationStyle = UIModalPresentationOverFullScreen;
                                    UIView *panel = [[UIView alloc] initWithFrame:CGRectZero];
                                    panel.translatesAutoresizingMaskIntoConstraints = NO;
                                    panel.backgroundColor = [UIColor colorWithWhite:0.10 alpha:0.98];
                                    panel.layer.cornerRadius = 16.0;
                                    panel.layer.borderWidth = 1.0;
                                    panel.layer.borderColor = RGB(60, 180, 90).CGColor;
                                    [pay.view addSubview:panel];
                                    [NSLayoutConstraint activateConstraints:@[[panel.centerXAnchor constraintEqualToAnchor:pay.view.centerXAnchor], [panel.centerYAnchor constraintEqualToAnchor:pay.view.centerYAnchor], [panel.widthAnchor constraintLessThanOrEqualToConstant:390.0], [panel.widthAnchor constraintEqualToAnchor:pay.view.widthAnchor multiplier:0.88]]];
                                    UILabel *pt = [[UILabel alloc] init]; pt.translatesAutoresizingMaskIntoConstraints = NO; pt.textAlignment = NSTextAlignmentCenter; pt.textColor = UIColor.whiteColor; pt.font = [UIFont boldSystemFontOfSize:19.0]; pt.text = [NSString stringWithFormat:OX_NS("%@ — %@"), label, ZVipMoney(finalAmount)]; [panel addSubview:pt];
                                    UIImageView *iv = [[UIImageView alloc] initWithImage:ZVipQRImage(qr, 280.0)]; iv.translatesAutoresizingMaskIntoConstraints = NO; iv.contentMode = UIViewContentModeScaleAspectFit; iv.backgroundColor = UIColor.whiteColor; iv.layer.cornerRadius = 8.0; iv.clipsToBounds = YES; [panel addSubview:iv];
                                    UILabel *st = [[UILabel alloc] init]; st.translatesAutoresizingMaskIntoConstraints = NO; st.textAlignment = NSTextAlignmentCenter; st.numberOfLines = 2; st.textColor = UIColor.whiteColor; st.font = [UIFont boldSystemFontOfSize:14.0]; st.text = ZVipWaitingText(); [panel addSubview:st]; pay.statusLabel = st;
                                    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem]; close.translatesAutoresizingMaskIntoConstraints = NO; [close setTitle:ZVipCloseText() forState:UIControlStateNormal]; [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal]; close.titleLabel.font = [UIFont boldSystemFontOfSize:16.0]; close.backgroundColor = RGB(18, 105, 45); close.layer.cornerRadius = 8.0; [panel addSubview:close];
                                    [NSLayoutConstraint activateConstraints:@[[pt.topAnchor constraintEqualToAnchor:panel.topAnchor constant:16.0], [pt.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:12.0], [pt.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-12.0], [iv.topAnchor constraintEqualToAnchor:pt.bottomAnchor constant:12.0], [iv.centerXAnchor constraintEqualToAnchor:panel.centerXAnchor], [iv.widthAnchor constraintEqualToConstant:280.0], [iv.heightAnchor constraintEqualToConstant:280.0], [st.topAnchor constraintEqualToAnchor:iv.bottomAnchor constant:10.0], [st.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:12.0], [st.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-12.0], [close.topAnchor constraintEqualToAnchor:st.bottomAnchor constant:12.0], [close.centerXAnchor constraintEqualToAnchor:panel.centerXAnchor], [close.widthAnchor constraintEqualToConstant:180.0], [close.heightAnchor constraintEqualToConstant:42.0], [close.bottomAnchor constraintEqualToAnchor:panel.bottomAnchor constant:-16.0]]];
                                    [close addAction:[UIAction actionWithHandler:^(__unused UIAction *action) { pay.stopped = YES; [pay dismissViewControllerAnimated:YES completion:nil]; }] forControlEvents:UIControlEventTouchUpInside];
                                    [self presentViewController:pay animated:YES completion:nil];
                                    __weak ZVipPayController *weakPay = pay;
                                    __block void (^poll)(void) = nil;
                                    poll = ^{
                                        ZVipPayController *strongPay = weakPay;
                                        if (!strongPay || strongPay.stopped) return;
                                        NSString *escapedOrder = [order stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
                                        NSString *escapedToken = [token stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
                                        NSString *u = [NSString stringWithFormat:OX_NS("https://ongnong.io.vn/chungchi/keyshop/status.php?oc=%@&t=%@"), escapedOrder ?: OX_NS(""), escapedToken ?: OX_NS("")];
                                        [[[NSURLSession sharedSession] dataTaskWithURL:[NSURL URLWithString:u] completionHandler:^(NSData *sd, NSURLResponse *sr, NSError *se) {
                                            NSDictionary *sj = se ? nil : ZVipJSON(sd);
                                            BOOL paid = [sj[OX_NS("paid")] boolValue];
                                            BOOL activated = [sj[OX_NS("activated")] boolValue];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                ZVipPayController *pvc = weakPay;
                                                if (!pvc || pvc.stopped) return;
                                                if (activated) {
                                                    pvc.statusLabel.text = ZVipActivatedText();
                                                    Ongnong::Zx8fRefreshNow();
                                                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (!pvc.stopped) { pvc.stopped = YES; [pvc dismissViewControllerAnimated:YES completion:nil]; } });
                                                    return;
                                                }
                                                if (paid) pvc.statusLabel.text = ZVipPaidText();
                                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (poll) poll(); });
                                            });
                                        }] resume];
                                    };
                                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (poll) poll(); });
                                }];
                            });
                        }] resume];
                    }]];
                }
                [picker addAction:[UIAlertAction actionWithTitle:ZVipCloseText() style:UIAlertActionStyleCancel handler:nil]];
                [self presentViewController:picker animated:YES completion:nil];
            }];
        });
    }] resume];
}

- (void)zCollectLabelsFromView:(UIView *)view into:(NSMutableArray<UILabel *> *)labels {
    if (!view) return;
    if ([view isKindOfClass:[UILabel class]]) [labels addObject:(UILabel *)view];
    for (UIView *sub in view.subviews) [self zCollectLabelsFromView:sub into:labels];
}

- (void)zApplyBuyVipStyleInAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle {
    if (!alert || buyTitle.length == 0) return;
    NSMutableArray<UILabel *> *labels = [NSMutableArray array];
    [self zCollectLabelsFromView:alert.view into:labels];
    UIColor *fill = RGB(18, 122, 40);
    UIColor *border = RGB(112, 255, 145);
    for (UILabel *label in labels) {
        if (![label.text isKindOfClass:[NSString class]]) continue;
        if (![label.text isEqualToString:buyTitle]) continue;
        label.textColor = UIColor.whiteColor;
        label.font = [UIFont systemFontOfSize:label.font.pointSize weight:UIFontWeightBlack];
        UIView *target = nil;
        UIView *cursor = label.superview;
        for (NSInteger step = 0; step < 8 && cursor; step++) {
            CGFloat w = cursor.bounds.size.width;
            CGFloat h = cursor.bounds.size.height;
            if (w > 150.0 && h >= 36.0 && h <= 80.0) {
                target = cursor;
                break;
            }
            cursor = cursor.superview;
        }
        if (!target) continue;
        target.backgroundColor = fill;
        target.layer.cornerRadius = 15.0;
        target.layer.masksToBounds = YES;
        target.layer.borderWidth = 1.3;
        target.layer.borderColor = border.CGColor;
    }
}

- (void)zStyleBuyVipAlert:(UIAlertController *)alert buyTitle:(NSString *)buyTitle {
    if (!alert || buyTitle.length == 0) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.02 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self zApplyBuyVipStyleInAlert:alert buyTitle:buyTitle];
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.18 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self zApplyBuyVipStyleInAlert:alert buyTitle:buyTitle];
    });
}

- (void)zCustomUINameEditorForTarget:(NSString *)target title:(NSString *)targetTitle {
    NSString *current = Ongnong::Zx8fCustomUINameForTarget(target) ?: OX_NS("");
    UIAlertController *a = [UIAlertController alertControllerWithTitle:targetTitle
                                                               message:ZuiPick5(OX_NS("Tự đặt tên, tối đa 16 ký tự"), OX_NS("自定义名称，最多16个字符"), OX_NS("ตั้งชื่อเอง สูงสุด 16 ตัวอักษร"), OX_NS("Nome personalizzato, massimo 16 caratteri"), OX_NS("Custom name, maximum 16 characters"))
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *f) {
        f.text = current;
        f.placeholder = ZuiPick5(OX_NS("Nhập tên muốn hiển thị"), OX_NS("输入显示名称"), OX_NS("ใส่ชื่อที่ต้องการแสดง"), OX_NS("Inserisci il nome da mostrare"), OX_NS("Enter display name"));
        f.autocapitalizationType = UITextAutocapitalizationTypeSentences;
        f.autocorrectionType = UITextAutocorrectionTypeNo;
        f.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("LƯU"), OX_NS("保存"), OX_NS("บันทึก"), OX_NS("SALVA"), OX_NS("SAVE")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        NSString *name = a.textFields.firstObject.text ?: OX_NS("");
        Ongnong::Zx8fSetCustomUINameForTarget(target, name);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self zBrandProfileEditor];
        });
    }]];
    if (current.length > 0) {
        [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("DÙNG MẶC ĐỊNH"), OX_NS("使用默认"), OX_NS("ใช้ค่าเริ่มต้น"), OX_NS("USA PREDEFINITO"), OX_NS("USE DEFAULT")) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *x) {
            Ongnong::Zx8fSetCustomUINameForTarget(target, OX_NS(""));
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self zBrandProfileEditor];
            });
        }]];
    }
    [a addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)zBrandProfileEditor {
    if (!Ongnong::Zx8fIsVIP()) {
        UIAlertController *vip = [UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("CẦN NÂNG CẤP VIP"), OX_NS("需要升级 VIP"), OX_NS("ต้องอัปเกรด VIP"), OX_NS("PASSA A VIP"), OX_NS("VIP UPGRADE REQUIRED"))
                                                                    message:nil
                                                             preferredStyle:UIAlertControllerStyleAlert];
        [vip addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:vip animated:YES completion:nil];
        return;
    }

    UIAlertController *a = [UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("ĐỔI GIAO DIỆN"), OX_NS("更改界面"), OX_NS("เปลี่ยนอินเทอร์เฟซ"), OX_NS("CAMBIA INTERFACCIA"), OX_NS("CHANGE INTERFACE"))
                                                               message:ZuiPick5(OX_NS("Chọn vị trí muốn đổi tên"), OX_NS("选择要改名的位置"), OX_NS("เลือกตำแหน่งที่ต้องการเปลี่ยนชื่อ"), OX_NS("Scegli dove cambiare il nome"), OX_NS("Choose where to change the name"))
                                                        preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("TÊN CHÍNH"), OX_NS("主标题"), OX_NS("ชื่อหลัก"), OX_NS("NOME PRINCIPALE"), OX_NS("MAIN NAME")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        [self zCustomUINameEditorForTarget:OX_NS("main_title") title:ZuiPick5(OX_NS("TÊN CHÍNH"), OX_NS("主标题"), OX_NS("ชื่อหลัก"), OX_NS("NOME PRINCIPALE"), OX_NS("MAIN NAME"))];
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("BẢNG ĐẾM TỔNG"), OX_NS("总计数器"), OX_NS("ตารางนับรวม"), OX_NS("CONTATORE TOTALE"), OX_NS("TOTAL COUNTER")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        [self zCustomUINameEditorForTarget:OX_NS("counter_title") title:ZuiPick5(OX_NS("BẢNG ĐẾM TỔNG"), OX_NS("总计数器"), OX_NS("ตารางนับรวม"), OX_NS("CONTATORE TOTALE"), OX_NS("TOTAL COUNTER"))];
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("FPS / FOOTER"), OX_NS("FPS / 底部"), OX_NS("FPS / ด้านล่าง"), OX_NS("FPS / FOOTER"), OX_NS("FPS / FOOTER")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        [self zCustomUINameEditorForTarget:OX_NS("footer_name") title:OX_NS("FPS / FOOTER")];
    }]];
    NSString *fpsToggleTitle = Ongnong::Zx8fFPSVisible()
        ? ZuiPick5(OX_NS("ẨN FPS"), OX_NS("隐藏 FPS"), OX_NS("ซ่อน FPS"), OX_NS("NASCONDI FPS"), OX_NS("HIDE FPS"))
        : ZuiPick5(OX_NS("HIỆN FPS"), OX_NS("显示 FPS"), OX_NS("แสดง FPS"), OX_NS("MOSTRA FPS"), OX_NS("SHOW FPS"));
    [a addAction:[UIAlertAction actionWithTitle:fpsToggleTitle style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x) {
        Ongnong::Zx8fSetFPSVisible(!Ongnong::Zx8fFPSVisible());
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self zBrandProfileEditor];
        });
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("KHÔI PHỤC MẶC ĐỊNH"), OX_NS("恢复默认"), OX_NS("คืนค่าเริ่มต้น"), OX_NS("RIPRISTINA PREDEFINITO"), OX_NS("RESTORE DEFAULT")) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *x) {
        Ongnong::Zx8fResetAllCustomUINames();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self zBrandProfileEditor];
        });
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)d4u8s0 {
    [self d2x8q4];
    NSString *device = Ongnong::Zx8fDeviceId() ?: @"";
    NSString *message = [NSString stringWithFormat:OngnongUIVaultText(OngnongUIVaultVipActivationMessageFormat), device];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:OngnongUIVaultText(OngnongUIVaultVipActivationTitle)
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultVipCopyActivation) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        UIPasteboard.generalPasteboard.string = device;
    }]];
    BOOL isVIP = Ongnong::Zx8fIsVIP();
    NSString *buyTitle = ZVipBuyNowText();
    if (isVIP) {
        NSString *enrollURL = Ongnong::Zx8fEnrollmentURL();
        if (enrollURL.length > 0) {
            [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultVipRestoreActivation) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                [self v3n8a4:enrollURL];
            }]];
        }
    } else {
        [alert addAction:[UIAlertAction actionWithTitle:buyTitle style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            [self zBuyVipPayOS];
        }]];
        NSString *enrollURL = Ongnong::Zx8fEnrollmentURL();
        if (enrollURL.length > 0) {
            [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultFreeRestoreVipAction) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                [self v3n8a4:enrollURL];
            }]];
        }
    }
    [alert addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("ĐỔI GIAO DIỆN"), OX_NS("更改界面"), OX_NS("เปลี่ยนอินเทอร์เฟซ"), OX_NS("CAMBIA INTERFACCIA"), OX_NS("CHANGE INTERFACE")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        [self zBrandProfileEditor];
    }]];
    if (!isVIP) {
        [alert addAction:[UIAlertAction actionWithTitle:OngnongUIVaultText(OngnongUIVaultVipContactBuy) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            [self v3n8a4:OX_NS("https://zalo.me/84702136078")];
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:ZuiCancelText() style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:^{
        if (!isVIP) {
            [self zStyleBuyVipAlert:alert buyTitle:buyTitle];
        }
    }];
}

- (void)ongFriendClearLink:(UIButton *)sender {
    UIView *view = sender;
    UITextField *field = nil;
    while (view) {
        if ([view isKindOfClass:[UITextField class]]) { field = (UITextField *)view; break; }
        view = view.superview;
    }
    if (!field && [self.presentedViewController isKindOfClass:[UIAlertController class]]) {
        UIAlertController *alert = (UIAlertController *)self.presentedViewController;
        field = alert.textFields.firstObject;
    }
    field.text = @"";
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:OX_NS("ong_friend_last_link")];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)ongFriendModule {
    Z0418c1e0ae();
    if (!Ongnong::Zx8fFriendInviteAllowed()) { [self zShowMainVipRequiredAtIndex:13]; [self q7m2d8]; return; }
    UIAlertController *a=[UIAlertController alertControllerWithTitle:ZuiFriendInviteText() message:Ongnong::FriendInviteStatus() preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *f){
        f.placeholder=ZuiPick5(OX_NS("DÁN LINK MỜI CỦA NGƯỜI KHÁC"), OX_NS("粘贴其他玩家的邀请链接"), OX_NS("วางลิงก์เชิญของผู้เล่นอื่น"), OX_NS("INCOLLA IL LINK INVITO DI UN ALTRO GIOCATORE"), OX_NS("PASTE ANOTHER PLAYER'S INVITE LINK"));
        f.text=[[NSUserDefaults standardUserDefaults] stringForKey:OX_NS("ong_friend_last_link")];
        f.autocapitalizationType=UITextAutocapitalizationTypeNone;
        f.autocorrectionType=UITextAutocorrectionTypeNo;
        UIButton *clear=[UIButton buttonWithType:UIButtonTypeSystem];
        clear.frame=CGRectMake(0,0,54,30);
        [clear setTitle:ZuiFriendClearText() forState:UIControlStateNormal];
        clear.titleLabel.font=[UIFont boldSystemFontOfSize:13.0];
        [clear addTarget:self action:@selector(ongFriendClearLink:) forControlEvents:UIControlEventTouchUpInside];
        f.rightView=clear;
        f.rightViewMode=UITextFieldViewModeAlways;
    }];
    __weak UIAlertController *wa=a;
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("GỬI"), OX_NS("发送"), OX_NS("ส่ง"), OX_NS("INVIA"), OX_NS("SEND")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x){
        NSString *link=wa.textFields.firstObject.text ?: @"";
        if (link.length) {
            [[NSUserDefaults standardUserDefaults] setObject:link forKey:OX_NS("ong_friend_last_link")];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        BOOL ok=Ongnong::FriendInviteSend(link);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(1.2*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
            UIAlertController *r=[UIAlertController alertControllerWithTitle:ZuiFriendInviteText() message:(ok?Ongnong::FriendInviteStatus():ZuiPick5(OX_NS("LINK KHÔNG HỢP LỆ"), OX_NS("链接无效"), OX_NS("ลิงก์ไม่ถูกต้อง"), OX_NS("LINK NON VALIDO"), OX_NS("INVALID LINK"))) preferredStyle:UIAlertControllerStyleAlert];
            [r addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:r animated:YES completion:nil];
        });
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("LINK CỦA TÔI"), OX_NS("我的链接"), OX_NS("ลิงก์ของฉัน"), OX_NS("IL MIO LINK"), OX_NS("MY LINK")) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x){
        if (!Ongnong::FriendInviteOpenMine()) {
            UIAlertController *r=[UIAlertController alertControllerWithTitle:ZuiFriendInviteText() message:ZuiPick5(OX_NS("GAME CHƯA SẴN SÀNG"), OX_NS("游戏尚未就绪"), OX_NS("เกมยังไม่พร้อม"), OX_NS("IL GIOCO NON È PRONTO"), OX_NS("GAME NOT READY")) preferredStyle:UIAlertControllerStyleAlert];
            [r addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:r animated:YES completion:nil];
        }
    }]];
    [a addAction:[UIAlertAction actionWithTitle:ZuiPick5(OX_NS("ĐÓNG"), OX_NS("关闭"), OX_NS("ปิด"), OX_NS("CHIUDI"), OX_NS("CLOSE")) style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

- (void)ongPotionModule {
    Z0418c1e0ae();
    if (!Ongnong::Zx8fPotionAllowed()) { Ongnong::AutoPotionSetEnabled(NO); [self zShowMainVipRequiredAtIndex:14]; [self q7m2d8]; return; }
    BOOL wasOn=Ongnong::AutoPotionIsEnabled();
    Ongnong::AutoPotionSetEnabled(wasOn ? NO : YES);

    
    
    Zcb66126fa3 *immediatePotionButton=(_v2p6k1.a7m1c5.count > 14) ? _v2p6k1.a7m1c5[14] : nil;
    if (immediatePotionButton) {
        BOOL immediateOn=Ongnong::AutoPotionIsEnabled();
        immediatePotionButton.x9c4n6.text=ZuiPotionStateText(immediateOn);
        [self w2k7e5:immediatePotionButton color:RGB(185, 105, 255) active:immediateOn];
        [immediatePotionButton setNeedsLayout];
        [_v2p6k1 setNeedsLayout];
    }

    UIAlertController *a=[UIAlertController alertControllerWithTitle:ZuiPick5(OX_NS("NHẬN THUỐC"), OX_NS("领取药水"), OX_NS("รับยา"), OX_NS("RITIRA POZIONE"), OX_NS("COLLECT POTION"))
                                                              message:Ongnong::AutoPotionStatus()
                                                       preferredStyle:UIAlertControllerStyleAlert];
    __weak UIAlertController *weakPotionAlert=a;
    [a addAction:[UIAlertAction actionWithTitle:OX_NS("OK") style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];

    
    
    NSArray<NSNumber *> *delays=@[@0.35,@0.8,@1.3,@2.0,@3.0,@5.0,@8.0];
    for (NSNumber *delayNumber in delays) {
        NSTimeInterval d=delayNumber.doubleValue;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(d*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
            BOOL success=Ongnong::AutoPotionIsEnabled();
            NSString *status=Ongnong::AutoPotionStatus();
            UIAlertController *liveAlert=weakPotionAlert;
            if (liveAlert && liveAlert.presentingViewController) {
                liveAlert.message=status;
                if (success) liveAlert.title=ZuiPick5(OX_NS("NHẬN THUỐC - THÀNH CÔNG"), OX_NS("领取药水 - 成功"), OX_NS("รับยา - สำเร็จ"), OX_NS("RITIRA POZIONE - RIUSCITO"), OX_NS("COLLECT POTION - SUCCESS"));
            }

            Zcb66126fa3 *potionButton=(self->_v2p6k1.a7m1c5.count > 14) ? self->_v2p6k1.a7m1c5[14] : nil;
            if (potionButton) {
                potionButton.x9c4n6.text=ZuiPotionStateText(success);
                [self w2k7e5:potionButton color:RGB(185, 105, 255) active:success];
                [potionButton setNeedsLayout];
            }
            [self->_v2p6k1 setNeedsLayout];
        });
    }
}

@end

static Z68534fe442 *gWindow = nil;
static Z9abcb7bb90 *gController = nil;

static UIWindow *Z75012fe6de(void) {
    if (@available(iOS 13.0, *)) {
        UIWindow *fallback = nil;
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            UIWindowScene *windowScene = (UIWindowScene *)scene;
            for (UIWindow *window in windowScene.windows) {
                if (!fallback && !window.hidden) fallback = window;
                if (scene.activationState == UISceneActivationStateForegroundActive && window.isKeyWindow) return window;
            }
            if (scene.activationState == UISceneActivationStateForegroundActive && windowScene.windows.count) return windowScene.windows.firstObject;
        }
        if (fallback) return fallback;
    }
    UIWindow *keyWindow = UIApplication.sharedApplication.keyWindow;
    if (keyWindow) return keyWindow;
    return UIApplication.sharedApplication.windows.firstObject;
}

static UIWindowScene *Z75012fe6dd(void) {
    if (@available(iOS 13.0, *)) {
        UIWindow *host = Z75012fe6de();
        if (host.windowScene) return host.windowScene;
        UIWindowScene *fallback = nil;
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) continue;
            UIWindowScene *windowScene = (UIWindowScene *)scene;
            if (!fallback) fallback = windowScene;
            if (scene.activationState == UISceneActivationStateForegroundActive) return windowScene;
            if (scene.activationState == UISceneActivationStateForegroundInactive) fallback = windowScene;
        }
        return fallback;
    }
    return nil;
}

namespace Ongnong {

void Z75012fe6dc() {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gWindow) {
            gWindow.hidden = NO;
            return;
        }
        UIWindow *hostWindow = Z75012fe6de();
        CGRect frame = hostWindow ? hostWindow.bounds : UIScreen.mainScreen.bounds;
        if (@available(iOS 13.0, *)) {
            UIWindowScene *windowScene = Z75012fe6dd();
            if (windowScene) {
                gWindow = [[Z68534fe442 alloc] initWithWindowScene:windowScene];
                frame = windowScene.coordinateSpace.bounds;
                gWindow.frame = frame;
            }
        }
        if (!gWindow) gWindow = [[Z68534fe442 alloc] initWithFrame:frame];
        gWindow.backgroundColor = [UIColor clearColor];
        gWindow.windowLevel = UIWindowLevelAlert + 20;
        gController = [[Z9abcb7bb90 alloc] init];
        gWindow.rootViewController = gController;
        [gWindow makeKeyAndVisible];
        [gController.view setNeedsLayout];
        [gController.view layoutIfNeeded];
        if (hostWindow && hostWindow != gWindow) [hostWindow makeKeyWindow];
    });
}

}
