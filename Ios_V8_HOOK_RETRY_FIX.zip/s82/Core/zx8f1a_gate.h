#pragma once
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

namespace Ongnong {
typedef void (^Zx8fAllowBlock)(NSInteger remainingDays);
void Zx8fStart(Zx8fAllowBlock allowBlock);
BOOL Zx8fAllowed(void);
BOOL Zx8fMenuAllowed(void);
BOOL Zx8fSpeedAllowed(void);
BOOL Zx8fCounterAllowed(void);
BOOL Zx8fPotionAllowed(void);
BOOL Zx8fTokenAllowed(void);
BOOL Zx8fLightningAllowed(void);
BOOL Zx8fBetCycleAllowed(void);
BOOL Zx8fAutoMergeAllowed(void);
BOOL Zx8fAutoClickAllowed(void);
BOOL Zx8fRaidHammerAllowed(void);
BOOL Zx8fToolsAllowed(void);
BOOL Zx8fAutoStopAllowed(void);
BOOL Zx8fMenuColorAllowed(void);
BOOL Zx8fFriendInviteAllowed(void);
BOOL Zx8fIsVIP(void);
BOOL Zx8fMenuItemVisible(NSString *key);
BOOL Zx8fAutoBuildAllowed(void);
BOOL Zx8fMagicCardsAllowed(void);
BOOL R7f407(void);
uint64_t R7f408(uint64_t challenge);
BOOL R7f409(uint64_t challenge, uint64_t response);
BOOL R7f410(NSData *payload, NSData *signature);
BOOL Zx8fPotionOrTokenAllowed(void);
BOOL Zx8fMenuLocked(void);
void Zx8fMarkRuntimeReady(void);
void Zx8fRefreshNow(void);
NSString *Zx8fDeviceId(void);
NSString *Zx8fMyKeyURL(void);
NSString *Zx8fEnrollmentURL(void);
NSString *Zx8fUpdateURL(void);
BOOL Zx8fHasSecureMyKeyURL(void);
NSString *Zx8fProtectedHash(void);
NSString *Zx8fRealFileHash(void);
NSString *Zx8fMenuLabelVI(NSString *key, NSString *fallback);
void Zx8fSetMenuName(NSString *key, NSString *name, BOOL reset);
NSString *Zx8fUILabel(NSString *key, NSString *fallback);
NSString *Zx8fBrandProfileCode(void);
void Zx8fSetBrandProfileCode(NSString *code);
NSString *Zx8fCustomUINameForTarget(NSString *target);
void Zx8fSetCustomUINameForTarget(NSString *target, NSString *name);
void Zx8fResetAllCustomUINames(void);
BOOL Zx8fFPSVisible(void);
void Zx8fSetFPSVisible(BOOL visible);
void Zx8fShowRemainingToast(NSInteger days);
}

#define Zx8fExpeditionAllowed R7f407
