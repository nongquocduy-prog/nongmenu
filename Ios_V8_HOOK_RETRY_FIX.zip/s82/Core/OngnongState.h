#pragma once

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <vector>

namespace Ongnong {

enum CounterIndex {
    Z700020a485 = 0,
    Z124338f2d8 = 1,
    Z94881eb8d3 = 2,
    Z646dcbe562 = 3,
    Zdb004c459e = 4,
    Z2f0c1a9d77 = 5,
    Z87f6d0c11d = 6,
    Z5d92a7e4c1 = 7,
    Zshield5e2026 = 8,
    Za94c0d401a = 9
};

struct State {
    bool z26f020afac;
    bool z8ba2f43efe;
    bool z7180b46195;
    bool z54007f39a0;
    bool zacc65d5e7b;
    bool z904d9bb65a;
    bool z7377de64e5;
    bool zfd92661903;
    float z68593f2227;
    int z7fa19172fd;
    int zc9f4191bf8[Za94c0d401a];
    std::vector<int> zf791f4202f[Za94c0d401a];
};

extern State zce119e8048;
extern NSString *Z973e694cc8;
extern NSString *Zefaf4f9e5d;
extern NSString *Z1e3f87b2aa;
extern NSString *Z9a421e103d;
extern NSString *Z02a7e13d91;
extern NSString *Z6a3e9c1d74;

void ZPotionTrace(NSString *event);
NSString *ZPotionTraceCopy();
void Z1124fca77a();
void Z108056b942();
void Z2b9185919a();
void Z5eca9eb2c9();
void Z33f3ef693d();
void Z74902605ad(int symbol);
void Za184ac7ef2();
uint64_t Z9c4a7f611b();
void Z67a0d1f8e9();
void Zed58c1f2a6();
void Z67a0d1f8e9s(uint64_t snap);
void Zed58c1f2a6s(uint64_t snap);
void Z3c8e1a6d52();
void Z3c8e1a6d52s(uint64_t snap);
int Z1562633390(int symbol);
int Ze669ef335a(int index);
NSString *Z57eb159d41(int index);
UIColor *Z07aec8e446(int index);
NSArray<NSNumber *> *Zd282eb67ef(int index);
void Z8167e05f9c();
void Z6cb2075a89();
void Z5b100328e3();

NSArray<NSNumber *> *Z76e4c1b909(void);
int Z76d01f2a88(NSInteger slot);
BOOL Z76e20b7f66(int index);
BOOL Z76f880a1d(NSInteger slot);
BOOL Z76c51b907e(int index);
BOOL Z76d7aa0492(NSInteger slot);
BOOL Z76a9d34c1e(int index);
BOOL Z76b8e20f53(NSInteger slot);
BOOL Z76f45d8a2c(int index);
void Z4c97f7e81a();

}
