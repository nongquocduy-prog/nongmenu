#import "Qr65d.h"
#import "OngnongState.h"
#import "zx8f1a_gate.h"
#import "zx8f1a_pro.h"
#import <Foundation/Foundation.h>
#include <stdint.h>

static uint64_t q65d0 = 0;
static NSTimeInterval q65d1 = 0;

static uint64_t q65d2(NSString *a, NSString *b, NSInteger c, NSInteger d) {
    NSString *s = [NSString stringWithFormat:zxv_p38(), a ?: @"", b ?: @"", (long)c, (long)d];
    return (uint64_t)s.hash;
}

static BOOL q65d3(NSString *a, Q65B0 *b) {
    uint64_t x = q65d2(a, b.x0, b.x1, b.x2);
    NSTimeInterval n = [NSDate timeIntervalSinceReferenceDate];
    q65d0 = x;
    q65d1 = n;
    return YES;
}

void q65d4(NSString *a, Q65B0 *b, uint64_t snap) {
    if (!q65d3(a, b)) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        Ongnong::Z67a0d1f8e9s(snap);
        Ongnong::Z108056b942();
        Ongnong::Z8167e05f9c();
    });
}
