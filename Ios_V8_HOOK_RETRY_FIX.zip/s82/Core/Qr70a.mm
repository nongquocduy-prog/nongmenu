#import "Qr70a.h"
#import "Qr65a.h"
#import "Qr71a.h"
#import "Qr71b.h"
#import "OngnongState.h"
#import "zx8f1a_gate.h"
#import <Foundation/Foundation.h>

BOOL q70a0(NSData *data) {
    return q71a0(data);
}

void q70a1(NSData *data, NSString *url, uint64_t snap) {
    if (!Ongnong::Zx8fLightningAllowed() || !q71a0(data)) return;
    (void)0;
    NSError *error = nil;
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (error || !json) {
        (void)0;
        return;
    }
    NSArray<Q71N *> *items = q71a1(json);
    if (items.count == 0) {
        (void)0;
        return;
    }
    NSString *account = q65a1(url);
    NSInteger countAtParse = Ongnong::zce119e8048.zc9f4191bf8[Ongnong::Z5d92a7e4c1];
    if (q71b0(items, account, snap)) {
        (void)0;
        Ongnong::Z3c8e1a6d52s(snap);
        return;
    }

}
