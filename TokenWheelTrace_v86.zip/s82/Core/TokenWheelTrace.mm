#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#include <string.h>
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"

static NSRecursiveLock *twLock;
static NSMutableArray<NSString *> *twLines;
static unsigned long twSeq=0;
static unsigned long twSpinId=0;
static unsigned long twCalls[5]={0,0,0,0,0};
static bool twInstalled[5]={false,false,false,false,false};
static void twLog(NSString *s) {
    [twLock lock];
    if(!twLines)twLines=[NSMutableArray array];
    [twLines addObject:[NSString stringWithFormat:@"%05lu | %@ | %@",++twSeq,[NSDate date],s?:@""]];
    while(twLines.count>600)[twLines removeObjectAtIndex:0];
    [twLock unlock];
}
static NSString *twCopy(void) {
    [twLock lock];
    NSString *s=[[twLines copy] componentsJoinedByString:@"\n"];
    [twLock unlock];
    return [@"ONGNONG TOKEN WHEEL TRACE V86\n" stringByAppendingString:s?:@""];
}
static NSString *twBalance(void *p) {
    if(!p)return @"response=NULL";
    const uint8_t *b=(const uint8_t *)p;
    int token=0,bag=0,spent=0;
    memcpy(&token,b+0x10,4);
    memcpy(&bag,b+0x14,4);
    memcpy(&spent,b+0x18,4);
    uint8_t wonValid=*(b+0x2c);
    int wonIndex=0;
    memcpy(&wonIndex,b+0x28,4);
    void *rewards=nullptr;
    memcpy(&rewards,b+0x20,sizeof(void *));
    return [NSString stringWithFormat:@"balance=%p tokenBalance=%d bag=%d spent=%d wonIndex=%@ rewardsList=%p",p,token,bag,spent,wonValid? [NSString stringWithFormat:@"%d",wonIndex]:@"null",rewards];
}
static void *(*origClick)(void *,const void *);
static void *(*origActive)(void *,const void *);
static void *(*origSend)(void *,int,void *,const void *);
static void *(*origSingle)(void *,void *,int,const void *);
static void *(*origMulti)(void *,void *,int,const void *);
static void *twClick(void *s,const void *m) {
    twSpinId++;twCalls[0]++;
    twLog([NSString stringWithFormat:@"SPIN_CLICKED spin=%lu controller=%p",twSpinId,s]);
    return origClick(s,m);
}
static void *twActive(void *s,const void *m) {
    twCalls[1]++;twLog([NSString stringWithFormat:@"SPIN_ACTIVE spin=%lu controller=%p",twSpinId,s]);
    return origActive(s,m);
}
static void *twSend(void *s,int bag,void *event,const void *m) {
    twCalls[2]++;twLog([NSString stringWithFormat:@"REQUEST_SENT spin=%lu bag=%d event=%p",twSpinId,bag,event]);
    return origSend(s,bag,event,m);
}
static void *twSingle(void *s,void *response,int before,const void *m) {
    twCalls[3]++;twLog([NSString stringWithFormat:@"RESULT_SINGLE spin=%lu tokensBefore=%d %@",twSpinId,before,twBalance(response)]);
    return origSingle(s,response,before,m);
}
static void *twMulti(void *s,void *response,int before,const void *m) {
    twCalls[4]++;twLog([NSString stringWithFormat:@"RESULT_MULTI spin=%lu tokensBefore=%d %@",twSpinId,before,twBalance(response)]);
    return origMulti(s,response,before,m);
}
static void twInstall(void) {
    const char *names[]={"SpinClicked","SpinClickedActiveState","SendSpinRequest","ProcessSuccessSpinRequest","ProcessSuccessSpinRequestWithMultipleWonIndexes"};
    const char *spaces[]={"TokenWheel.MVC","TokenWheel.MVC","TokenWheel.NetworkV2","TokenWheel.MVC","TokenWheel.MVC"};
    const char *classes[]={"TokenWheelPopupController","TokenWheelPopupController","TokenWheelNetworkManagerV2","TokenWheelPopupController","TokenWheelPopupController"};
    int counts[]={0,0,2,2,2};
    void *hooks[]={(void *)twClick,(void *)twActive,(void *)twSend,(void *)twSingle,(void *)twMulti};
    void **originals[]={(void **)&origClick,(void **)&origActive,(void **)&origSend,(void **)&origSingle,(void **)&origMulti};
    for(int i=0;i<5;i++) {
        if(twInstalled[i])continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage(spaces[i],classes[i],&img);
        if(!klass||!img) {twLog([NSString stringWithFormat:@"HOOK_WAIT %s class_missing",names[i]]);continue;}
        MethodInfo *mi=Il2CppFindMethodInfoRaw(img,spaces[i],classes[i],names[i],counts[i],false);
        if(!mi||!mi->methodPointer){twLog([NSString stringWithFormat:@"HOOK_WAIT %s method_missing",names[i]]);continue;}
        int rc=DobbyHook((void *)mi->methodPointer,hooks[i],originals[i]);
        if(rc==0&&*originals[i])twInstalled[i]=true;
        twLog([NSString stringWithFormat:@"HOOK %s status=%d installed=%d address=%p trampoline=%p",names[i],rc,twInstalled[i],mi->methodPointer,*originals[i]]);
    }
}
@interface ONTokenTraceV86Button:UIButton
@end
@implementation ONTokenTraceV86Button
- (void)tap:(id)sender {
    NSString *message=[NSString stringWithFormat:@"Calls: click=%lu active=%lu request=%lu single=%lu multi=%lu\n\n%@",twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4],twCopy()];
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"TOKEN TRACE V86" message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"COPY" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=message;}]];
    [a addAction:[UIAlertAction actionWithTitle:@"CLOSE" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *vc=self.window.rootViewController;
    if(!vc)return;
    while(vc.presentedViewController)vc=vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)hold:(UILongPressGestureRecognizer *)g {
    if(g.state==UIGestureRecognizerStateBegan){[UIPasteboard generalPasteboard].string=twCopy();twLog(@"TRACE_COPIED");}
}
- (void)drag:(UIPanGestureRecognizer *)g {
    CGPoint p=[g translationInView:self.superview];self.center=CGPointMake(self.center.x+p.x,self.center.y+p.y);[g setTranslation:CGPointZero inView:self.superview];
}
@end
static void twUI(void) {
    UIWindow *w=nil;
    for(UIScene *s in UIApplication.sharedApplication.connectedScenes){
        if(![s isKindOfClass:UIWindowScene.class])continue;
        for(UIWindow *x in ((UIWindowScene *)s).windows)if(x.isKeyWindow){w=x;break;}
        if(w)break;
    }
    if(!w)w=UIApplication.sharedApplication.keyWindow;
    if(!w||[w viewWithTag:8172026])return;
    ONTokenTraceV86Button *b=[ONTokenTraceV86Button buttonWithType:UIButtonTypeSystem];
    b.tag=8172026;b.frame=CGRectMake(12,170,116,36);
    b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.78];b.layer.cornerRadius=9;
    [b setTitle:@"TOKEN TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [b addTarget:b action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
    [b addGestureRecognizer:[[UILongPressGestureRecognizer alloc]initWithTarget:b action:@selector(hold:)]];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc]initWithTarget:b action:@selector(drag:)]];
    [w addSubview:b];
}
__attribute__((constructor))static void twStart(void) {
    twLock=[NSRecursiveLock new];twLines=[NSMutableArray array];
    twLog(@"START V86 targeted wheel request/result trace");
    dispatch_async(dispatch_get_main_queue(),^{twUI();});
    for(int i=0;i<8;i++)dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(3+i*5)*NSEC_PER_SEC),dispatch_get_main_queue(),^{twInstall();twUI();});
}
