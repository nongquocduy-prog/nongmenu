#!/usr/bin/env bash
set -euo pipefail
export THEOS="${THEOS:-$HOME/theos}"
if [[ -f s82/Makefile ]]; then cd s82; fi
if [[ ! -f libwebp_ios.a ]]; then
  git clone --depth 1 --branch v1.5.0 https://github.com/webmproject/libwebp.git "${RUNNER_TEMP:-/tmp}/libwebp"
  SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
  cmake -S "${RUNNER_TEMP:-/tmp}/libwebp" -B "${RUNNER_TEMP:-/tmp}/webp-build" -G 'Unix Makefiles' -DCMAKE_SYSTEM_NAME=iOS -DCMAKE_OSX_SYSROOT="$SDK" -DCMAKE_OSX_ARCHITECTURES=arm64 -DCMAKE_OSX_DEPLOYMENT_TARGET=14.0 -DWEBP_BUILD_CWEBP=OFF -DWEBP_BUILD_DWEBP=OFF -DWEBP_BUILD_EXTRAS=OFF -DWEBP_BUILD_LIBWEBPMUX=OFF -DWEBP_BUILD_LIBWEBPDEMUX=OFF -DWEBP_ENABLE_SIMD=OFF -DBUILD_SHARED_LIBS=OFF -DCMAKE_BUILD_TYPE=MinSizeRel
  cmake --build "${RUNNER_TEMP:-/tmp}/webp-build" --target webp -j 2
  cp "${RUNNER_TEMP:-/tmp}/webp-build/libwebp.a" libwebp_ios.a
  mkdir -p webp
  cp "${RUNNER_TEMP:-/tmp}/libwebp/src/webp/"{decode.h,types.h} webp/
fi
make clean || true
make -j2 FINALPACKAGE=1
