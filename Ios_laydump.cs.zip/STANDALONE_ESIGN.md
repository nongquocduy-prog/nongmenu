Standalone ESign build for non-jailbroken iPhone.
After a successful dump the tweak exports ONLY Documents/dump.cs and automatically opens the native iOS share sheet for that file.
Choose Save to Files to copy dump.cs outside the app sandbox.
