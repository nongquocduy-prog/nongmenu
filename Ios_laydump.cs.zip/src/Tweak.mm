#include <cstdio>
#include <string>
#include <fstream>
#include <utility>

#import <SCLAlertView/SCLAlertView.h>
#import <SSZipArchive/ZipArchive.h>

#include "AlertUtils.h"

#include "Core/Il2cpp.hpp"
#include "Core/Dumper.hpp"

#include "Core/config.h"

void dump_thread();

static UIViewController *ONTopViewController(UIViewController *vc)
{
  if (vc == nil) return nil;

  if ([vc isKindOfClass:[UINavigationController class]]) {
    return ONTopViewController(((UINavigationController *)vc).visibleViewController);
  }

  if ([vc isKindOfClass:[UITabBarController class]]) {
    UIViewController *selected = ((UITabBarController *)vc).selectedViewController;
    if (selected) return ONTopViewController(selected);
  }

  if (vc.presentedViewController) {
    return ONTopViewController(vc.presentedViewController);
  }

  return vc;
}

static UIViewController *ONCurrentViewController(void)
{
  UIWindow *targetWindow = nil;

  if (@available(iOS 13.0, *)) {
    for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
      if (scene.activationState != UISceneActivationStateForegroundActive) continue;
      if (![scene isKindOfClass:[UIWindowScene class]]) continue;

      UIWindowScene *windowScene = (UIWindowScene *)scene;
      for (UIWindow *window in windowScene.windows) {
        if (window.isKeyWindow) {
          targetWindow = window;
          break;
        }
      }

      if (!targetWindow) {
        for (UIWindow *window in windowScene.windows) {
          if (!window.hidden && window.alpha > 0.0) {
            targetWindow = window;
            break;
          }
        }
      }

      if (targetWindow) break;
    }
  }

  if (!targetWindow) {
    targetWindow = [UIApplication sharedApplication].keyWindow;
  }

  return ONTopViewController(targetWindow.rootViewController);
}

static void ONShareDumpCS(NSString *dumpCSPath)
{
  if (dumpCSPath.length == 0 || ![[NSFileManager defaultManager] fileExistsAtPath:dumpCSPath]) {
    showError(@"Dump xong nhưng không tìm thấy dump.cs để chia sẻ.");
    return;
  }

  dispatch_async(dispatch_get_main_queue(), ^{
    NSURL *url = [NSURL fileURLWithPath:dumpCSPath];
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];

    UIViewController *presenter = ONCurrentViewController();
    if (!presenter) {
      showError([NSString stringWithFormat:@"dump.cs đã tạo tại:\n%@\n\nKhông mở được bảng chia sẻ.", dumpCSPath]);
      return;
    }

    if (share.popoverPresentationController) {
      share.popoverPresentationController.sourceView = presenter.view;
      share.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(presenter.view.bounds), CGRectGetMidY(presenter.view.bounds), 1.0, 1.0);
      share.popoverPresentationController.permittedArrowDirections = 0;
    }

    [presenter presentViewController:share animated:YES completion:nil];
  });
}

__attribute__((constructor)) static void onLoad()
{
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
        NSLog(@"=================STRAT DUMPPER=================");
        dump_thread();
        NSLog(@"=================END DUMPPER=================");
    });
}

void dump_thread()
{
  sleep(5);

  showInfo([NSString stringWithFormat:@"Dumping after %d seconds.", WAIT_TIME_SEC], WAIT_TIME_SEC / 2);

  sleep(WAIT_TIME_SEC);

  NSString *docDir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];

  NSString *appName = [[[NSBundle mainBundle] infoDictionary] objectForKey:(id)kCFBundleNameKey];

  NSString *dumpFolderName = [NSString stringWithFormat:@"%@_%s", [appName stringByReplacingOccurrencesOfString:@" " withString:@""], DUMP_FOLDER];

  NSString *dumpPath = [NSString stringWithFormat:@"%@/%@", docDir, dumpFolderName];
  NSString *headersdumpPath = [NSString stringWithFormat:@"%@/%@", dumpPath, @"Assembly"];
  NSString *exportDumpCSPath = [docDir stringByAppendingPathComponent:@"dump.cs"];

  NSString *appPath = [[NSBundle mainBundle] bundlePath];
  NSString *binaryPath = [NSString stringWithFormat:@"%s", BINARY_NAME];
  if ([binaryPath isEqualToString:@"UnityFramework"])
  {
    binaryPath = [appPath stringByAppendingPathComponent:@"Frameworks/UnityFramework.framework/UnityFramework"];
  }
  else
  {
    binaryPath = [appPath stringByAppendingPathComponent:binaryPath];
  }

  Variables::IL2CPP::processAttach(binaryPath.UTF8String);

  if (Dumper::status != Dumper::DumpStatus::SUCCESS) {
    if (Dumper::status == Dumper::DumpStatus::ERROR_FRAMEWORK) {
      showError(@"Error while dumping, error framework");
      return;
    }
    if (Dumper::status == Dumper::DumpStatus::ERROR_SYMBOLS) {
      showError(@"Error while dumping, error symbols");
      return;
    }
  }

  NSLog(@"UNITY_PATH: %@", dumpPath);

  NSFileManager *fileManager = [NSFileManager defaultManager];

  if ([fileManager fileExistsAtPath:dumpPath])
  {
    [fileManager removeItemAtPath:dumpPath error:nil];
  }
  if ([fileManager fileExistsAtPath:exportDumpCSPath])
  {
    [fileManager removeItemAtPath:exportDumpCSPath error:nil];
  }

  NSError *error = nil;
  if (![fileManager createDirectoryAtPath:headersdumpPath withIntermediateDirectories:YES attributes:nil error:&error])
  {
    NSLog(@"Failed to create folders.\nError: %@", error);
    showError([NSString stringWithFormat:@"Failed to create folders.\nError: %@", error]);
    return;
  }

  SCLAlertView *waitingAlert = nil;
  showWaiting(@"Dumping...", &waitingAlert);
  
  Dumper::DumpStatus Dump =  Dumper::dump(dumpPath.UTF8String, headersdumpPath.UTF8String);

  NSString *generatedDumpCS = [dumpPath stringByAppendingPathComponent:@"dump.cs"];

  if ([fileManager fileExistsAtPath:generatedDumpCS])
  {
    NSError *copyError = nil;
    [fileManager copyItemAtPath:generatedDumpCS toPath:exportDumpCSPath error:&copyError];
    if (copyError)
    {
      NSLog(@"Failed to copy dump.cs: %@", copyError);
    }
  }

  // Keep only the exported dump.cs. Remove the temporary dump folder and
  // all auxiliary output such as script.json / Assembly.
  if ([fileManager fileExistsAtPath:dumpPath])
  {
    [fileManager removeItemAtPath:dumpPath error:nil];
  }

  dismisWaiting(waitingAlert);

  if (Dump != Dumper::DumpStatus::SUCCESS) {
    showError(@"Error while dumping, check logs.txt");
    return;
  }

  NSLog(@"Dump finished: %@", exportDumpCSPath);

  if (![fileManager fileExistsAtPath:exportDumpCSPath])
  {
    showError(@"Dump báo thành công nhưng không tìm thấy dump.cs.");
    return;
  }

  // Non-jailbroken iPhone: share only dump.cs so it can be saved directly
  // to the Files app without browsing the app sandbox.
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    ONShareDumpCS(exportDumpCSPath);
  });
}
