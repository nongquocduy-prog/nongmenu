#import <UIKit/UIKit.h>
#include <string.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <objc/runtime.h>
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"

static NSMutableArray<NSString *> *twLines;
static NSRecursiveLock *twLock;
static void twLog(NSString *line) {
    [twLock lock];
    if (!twLines) twLines = [NSMutableArray array];
    [twLines addObject:[NSString stringWithFormat:@"%@ | %@", [NSDate date], line ?: @""]];
    while (twLines.count > 800) [twLines removeObjectAtIndex:0];
    [twLock unlock];
}
static NSString *twCopy(void) {
    [twLock lock];
    NSString *s = [[twLines copy] componentsJoinedByString:@"\n"];
    [twLock unlock];
    return [@"ONGNONG TOKEN WHEEL TRACE v84\n" stringByAppendingString:s ?: @""];
}
static UITextView *twLiveView;
static UIView *twLivePanel;
static NSUInteger twLiveShownCount=0;
static void twRefreshLive(void) {
    if (!twLivePanel || twLivePanel.hidden || !twLiveView) return;
    [twLock lock];
    NSUInteger count=twLines.count;
    if (count==twLiveShownCount) { [twLock unlock]; return; }
    NSUInteger start=count>22?count-22:0;
    NSArray *last=[twLines subarrayWithRange:NSMakeRange(start,count-start)];
    [twLock unlock];
    twLiveShownCount=count;
    twLiveView.text=[last componentsJoinedByString:@"\n"];
    if (twLiveView.text.length) [twLiveView scrollRangeToVisible:NSMakeRange(twLiveView.text.length,0)];
}
@interface ONTokenTraceButton : UIButton
@end
@implementation ONTokenTraceButton
- (void)twHold:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    [UIPasteboard generalPasteboard].string = twCopy();
    twLog(@"TRACE_COPIED");
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Token Wheel Trace" message:@"Đã sao chép trace. Dán vào ChatGPT để gửi." preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    UIViewController *vc = self.window.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)twShow:(id)sender {
    if (twLivePanel) { twLivePanel.hidden=!twLivePanel.hidden; twRefreshLive(); return; }
    NSString *logText = twCopy();
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"TOKEN WHEEL TRACE" message:logText.length ? logText : @"Chưa có dữ liệu" preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"Sao chép" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [UIPasteboard generalPasteboard].string = logText;
        twLog(@"TRACE_COPIED_FROM_POPUP");
    }]];
    [a addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *vc = self.window.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)twCopyLive:(id)sender {
    [UIPasteboard generalPasteboard].string=twCopy();
    twLog(@"LIVE_TRACE_COPIED");
}
- (void)twDrag:(UIPanGestureRecognizer *)g {
    CGPoint p = [g translationInView:self.superview];
    self.center = CGPointMake(self.center.x+p.x,self.center.y+p.y);
    [g setTranslation:CGPointZero inView:self.superview];
}
@end
static void twUI(void) {
    UIWindow *w = nil;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if (![s isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *x in ((UIWindowScene *)s).windows) if (x.isKeyWindow) { w=x; break; }
        if (w) break;
    }
    if (!w) w = UIApplication.sharedApplication.keyWindow;
    if (!w || [w viewWithTag:8172026]) return;
    ONTokenTraceButton *b = [ONTokenTraceButton buttonWithType:UIButtonTypeSystem];
    b.tag=8172026; b.frame=CGRectMake(12,170,116,36);
    b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.78];
    b.layer.cornerRadius=9;
    [b setTitle:@"TOKEN TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [b addTarget:b action:@selector(twShow:) forControlEvents:UIControlEventTouchUpInside];
    [b addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:b action:@selector(twHold:)]];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:b action:@selector(twDrag:)]];
    [w addSubview:b];
    UIView *panel=[[UIView alloc] initWithFrame:CGRectMake(12,215,MIN(w.bounds.size.width-24,390),245)];
    panel.tag=8172027;
    panel.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.86];
    panel.layer.cornerRadius=9;
    panel.hidden=YES;
    UILabel *heading=[[UILabel alloc] initWithFrame:CGRectMake(9,5,panel.bounds.size.width-90,24)];
    heading.text=@"LIVE TOKEN TRACE v84";
    heading.textColor=UIColor.greenColor;
    heading.font=[UIFont boldSystemFontOfSize:12];
    [panel addSubview:heading];
    UIButton *copy=[UIButton buttonWithType:UIButtonTypeSystem];
    copy.frame=CGRectMake(panel.bounds.size.width-76,3,68,28);
    [copy setTitle:@"COPY" forState:UIControlStateNormal];
    [copy setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [copy addTarget:b action:@selector(twCopyLive:) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:copy];
    UITextView *view=[[UITextView alloc] initWithFrame:CGRectMake(6,34,panel.bounds.size.width-12,205)];
    view.backgroundColor=UIColor.clearColor;
    view.textColor=UIColor.whiteColor;
    view.font=[UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightRegular];
    view.editable=NO;
    view.selectable=YES;
    [panel addSubview:view];
    [w addSubview:panel];
    twLivePanel=panel;
    twLiveView=view;
    NSTimer *timer=[NSTimer scheduledTimerWithTimeInterval:0.3 repeats:YES block:^(NSTimer *t) { twRefreshLive(); }];
    (void)timer;
}
static void *(*origSpin)(void *,int,void *,const void *);
static void *twSpin(void *self,int bag,void *event,const void *method) {
    twLog([NSString stringWithFormat:@"SPIN_REQUEST bag=%d event=%p",bag,event]);
    return origSpin(self,bag,event,method);
}
static void *(*origSuccess)(int,void *,const void *);
static void *twSuccess(int type,void *balance,const void *method) {
    twLog([NSString stringWithFormat:@"NETWORK_SUCCESS requestType=%d balance=%p",type,balance]);
    return origSuccess(type,balance,method);
}
static void *(*origCollect)(int,void *,const void *);
static void *twCollect(int type,void *response,const void *method) {
    twLog([NSString stringWithFormat:@"COLLECT_SUCCESS requestType=%d response=%p",type,response]);
    return origCollect(type,response,method);
}

static void *(*origPopupSpin)(void *,const void *);
static void *twPopupSpin(void *self,const void *method) {
    twLog([NSString stringWithFormat:@"POPUP_SPIN_CLICKED controller=%p",self]);
    return origPopupSpin(self,method);
}
static void *(*origPopupActive)(void *,const void *);
static void *twPopupActive(void *self,const void *method) {
    twLog([NSString stringWithFormat:@"POPUP_SPIN_ACTIVE controller=%p",self]);
    return origPopupActive(self,method);
}
static void *(*origPopupResult)(void *,void *,int,const void *);
static void *twPopupResult(void *self,void *response,int tokens,const void *method) {
    twLog([NSString stringWithFormat:@"POPUP_SPIN_RESULT response=%p tokensBefore=%d",response,tokens]);
    return origPopupResult(self,response,tokens,method);
}
static void *(*origPopupSingle)(void *,void *,int,const void *);
static void *twPopupSingle(void *self,void *response,int tokens,const void *method) {
    twLog([NSString stringWithFormat:@"POPUP_SINGLE_RESULT controller=%p response=%p tokensBefore=%d",self,response,tokens]);
    return origPopupSingle(self,response,tokens,method);
}
static bool twPopupInstalled[4]={false,false,false,false};
static void twInstallPopup(void) {
    const char *img=nullptr;
    void *c=Il2CppFindClassAnyImage("TokenWheel.MVC","TokenWheelPopupController",&img);
    if (!c || !img) {twLog(@"POPUP_CLASS_NOT_FOUND");return;}
    const char *names[]={"SpinClicked","SpinClickedActiveState","ProcessSuccessSpinRequestWithMultipleWonIndexes","ProcessSuccessSpinRequest"};
    void *hooks[]={ (void *)twPopupSpin,(void *)twPopupActive,(void *)twPopupResult,(void *)twPopupSingle };
    void **originals[]={ (void **)&origPopupSpin,(void **)&origPopupActive,(void **)&origPopupResult,(void **)&origPopupSingle };
    int argc[]={0,0,2,2};
    for(int i=0;i<4;i++) {
        if(twPopupInstalled[i]) continue;
        MethodInfo *m=Il2CppFindMethodInfoRaw(img,"TokenWheel.MVC","TokenWheelPopupController",names[i],argc[i],false);
        if(m && m->methodPointer && DobbyHook((void *)m->methodPointer,hooks[i],originals[i])==0) {
            twPopupInstalled[i]=true;
            twLog([NSString stringWithFormat:@"POPUP_HOOK_INSTALLED_NOT_VERIFIED %s image=%s address=%p trampoline=%p",names[i],img,m->methodPointer,*originals[i]]);
        } else twLog([NSString stringWithFormat:@"POPUP_HOOK_MISSING %s",names[i]]);
    }
}


static void (*twMoveOriginal[4])(void *,const void *);
static bool twMoveInstalled[4]={false,false,false,false};
static void twMoveLog(int index,void *machine,const void *method) {
    int state=machine ? *(int *)((char *)machine+0x10) : -999;
    const char *names[]={"SpinClicked","SpinClickedActiveState","ProcessSuccessSpinRequestLegacy","ProcessSuccessSpinRequestWithMultipleWonIndexes"};
    twLog([NSString stringWithFormat:@"ASYNC_MOVENEXT %s state=%d machine=%p",names[index],state,machine]);
    if(twMoveOriginal[index]) twMoveOriginal[index](machine,method);
}
static void twMove0(void *s,const void *m){twMoveLog(0,s,m);}
static void twMove1(void *s,const void *m){twMoveLog(1,s,m);}
static void twMove2(void *s,const void *m){twMoveLog(2,s,m);}
static void twMove3(void *s,const void *m){twMoveLog(3,s,m);}
static void twInstallAsync(void) {
    const char *names[]={"<SpinClicked>d__69","<SpinClickedActiveState>d__71","<ProcessSuccessSpinRequestLegacy>d__86","<ProcessSuccessSpinRequestWithMultipleWonIndexes>d__73"};
    void *replacements[]={ (void *)twMove0,(void *)twMove1,(void *)twMove2,(void *)twMove3};
    for(int i=0;i<4;i++) {
        if(twMoveInstalled[i]) continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage("",names[i],&img);
        if(!klass || !img) {
            twLog([NSString stringWithFormat:@"ASYNC_CLASS_MISSING %s",names[i]]);
            continue;
        }
        MethodInfo *m=Il2CppFindMethodInfoRaw(img,"",names[i],"MoveNext",0,false);
        if(m && m->methodPointer && DobbyHook((void *)m->methodPointer,replacements[i],(void **)&twMoveOriginal[i])==0) {
            twMoveInstalled[i]=true;
            twLog([NSString stringWithFormat:@"ASYNC_HOOK_INSTALLED_NOT_VERIFIED %s address=%p",names[i],m->methodPointer]);
        } else twLog([NSString stringWithFormat:@"ASYNC_HOOK_MISSING %s",names[i]]);
    }
}


static void (*twOriginalUnityPress)(void *,const void *);
static bool twUnityPressInstalled=false;
static unsigned long twUnityPressCount=0;
static void twUnityPress(void *button,const void *method) {
    twUnityPressCount++;
    twLog([NSString stringWithFormat:@"UNITY_BUTTON_PRESS count=%lu button=%p (button identity not verified)",twUnityPressCount,button]);
    if (twOriginalUnityPress) twOriginalUnityPress(button,method);
}
static void twDiscoverUnityUI(void) {
    if (twUnityPressInstalled) return;
    const char *image=nullptr;
    void *klass=Il2CppFindClassAnyImage("UnityEngine.UI","Button",&image);
    if (!klass || !image) { twLog(@"UNITY_BUTTON_CLASS_MISSING"); return; }
    MethodInfo *m=Il2CppFindMethodInfoRaw(image,"UnityEngine.UI","Button","Press",0,false);
    if (!m || !m->methodPointer) { twLog(@"UNITY_BUTTON_PRESS_METHOD_MISSING"); return; }
    int status=DobbyHook((void *)m->methodPointer,(void *)twUnityPress,(void **)&twOriginalUnityPress);
    if(status==0) {twUnityPressInstalled=true;twLog([NSString stringWithFormat:@"UNITY_BUTTON_PRESS_HOOK_INSTALLED_NOT_VERIFIED image=%s address=%p",image,m->methodPointer]);}
    else twLog([NSString stringWithFormat:@"UNITY_BUTTON_PRESS_HOOK_FAILED status=%d",status]);
}

static void (*tw84Orig[3])(void *,void *,void *,const void *)={nullptr,nullptr,nullptr};
static unsigned long tw84Calls[3]={0,0,0};
static void tw84LogCall(int idx,void *self,void *arg0,void *arg1,const void *method) {
    unsigned long count=++tw84Calls[idx];
    if(count<=80)twLog([NSString stringWithFormat:@"V85_CALLBACK slot=%d count=%lu self=%p arg0=%p arg1=%p",idx,count,self,arg0,arg1]);
    if(tw84Orig[idx])tw84Orig[idx](self,arg0,arg1,method);
}
static void tw84Hook0(void *s,void *a,void *b,const void *m){tw84LogCall(0,s,a,b,m);}
static void tw84Hook1(void *s,void *a,void *b,const void *m){tw84LogCall(1,s,a,b,m);}
static void tw84Hook2(void *s,void *a,void *b,const void *m){tw84LogCall(2,s,a,b,m);}
static bool tw84Installed[3]={false,false,false};
static void tw84InstallLive(void) {
    typedef void *(*dg)(void);
    typedef void **(*ga)(const void *,size_t *);
    typedef const void *(*gi)(const void *);
    typedef size_t (*gc)(const void *);
    typedef void *(*gcl)(const void *,size_t);
    typedef const char *(*gn)(void *);
    typedef const void *(*gm)(void *,void **);
    typedef const char *(*mn)(const void *);
    typedef uint32_t (*pc)(const void *);
    typedef const void *(*rt)(const void *);
    typedef char *(*tn)(const void *);
    dg domain=(dg)dlsym(RTLD_DEFAULT,"il2cpp_domain_get");
    ga assemblies=(ga)dlsym(RTLD_DEFAULT,"il2cpp_domain_get_assemblies");
    gi image=(gi)dlsym(RTLD_DEFAULT,"il2cpp_assembly_get_image");
    gc count=(gc)dlsym(RTLD_DEFAULT,"il2cpp_image_get_class_count");
    gcl klass=(gcl)dlsym(RTLD_DEFAULT,"il2cpp_image_get_class");
    gn cname=(gn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_name");
    gn cnamespace=(gn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_namespace");
    gm methods=(gm)dlsym(RTLD_DEFAULT,"il2cpp_class_get_methods");
    mn mname=(mn)dlsym(RTLD_DEFAULT,"il2cpp_method_get_name");
    pc argc=(pc)dlsym(RTLD_DEFAULT,"il2cpp_method_get_param_count");
    rt ret=(rt)dlsym(RTLD_DEFAULT,"il2cpp_method_get_return_type");
    tn typeName=(tn)dlsym(RTLD_DEFAULT,"il2cpp_type_get_name");
    if(!domain||!assemblies||!image||!count||!klass||!cname||!cnamespace||!methods||!mname||!argc||!ret||!typeName){twLog(@"V85_EXPORTS_MISSING");return;}
    const char *targets[]={"TokenWheelRewardItem|SetReward","TokenWheelWinRewardAnimations|UpdateRewardsText","TokenWheelWinRewardAnimation|PlayGenericRewardWin"};
    void *replacements[]={(void *)tw84Hook0,(void *)tw84Hook1,(void *)tw84Hook2};
    size_t n=0;void **arr=assemblies(domain(),&n);
    for(size_t i=0;arr&&i<n;i++){
        const void *im=image(arr[i]);if(!im)continue;
        for(size_t j=0;j<count(im);j++){
            void *cl=klass(im,j);if(!cl)continue;
            const char *cn=cname(cl),*ns=cnamespace(cl);
            if(!cn||!ns||!strstr(ns,"TokenWheel"))continue;
            for(int k=0;k<3;k++){
                NSString *pair=[NSString stringWithUTF8String:targets[k]];
                NSArray *pieces=[pair componentsSeparatedByString:@"|"];
                if(strcmp(cn,[pieces[0] UTF8String])!=0 || tw84Installed[k])continue;
                void *it=nullptr;const void *m=nullptr;
                while((m=methods(cl,&it))){
                    const char *name=mname(m);if(!name||strcmp(name,[pieces[1] UTF8String])!=0)continue;
                    uint32_t args=argc(m);
                    char *returnName=typeName(ret(m));
                    bool isVoid=returnName&&strcmp(returnName,"System.Void")==0;
                    twLog([NSString stringWithFormat:@"V85_CANDIDATE %s.%s::%s argc=%u return=%s method=%p",ns,cn,name,args,returnName?returnName:"?",m]);
                    if(returnName){void (*freefn)(void *)=(void (*)(void *))dlsym(RTLD_DEFAULT,"il2cpp_free");if(freefn)freefn(returnName);}
                    if(!isVoid||args!=2)continue;
                    void *address=*(void * const *)m;
                    if(!address){twLog(@"V85_NO_METHOD_POINTER");continue;}
                    int status=DobbyHook(address,replacements[k],(void **)&tw84Orig[k]);
                    twLog([NSString stringWithFormat:@"V85_HOOK slot=%d status=%d address=%p trampoline=%p",k,status,address,tw84Orig[k]]);
                    if(status==0)tw84Installed[k]=true;
                    break;
                }
            }
        }
    }
    twLog([NSString stringWithFormat:@"V85_READY slots=%d,%d,%d",tw84Installed[0],tw84Installed[1],tw84Installed[2]]);
}

static void twDiscoverTokenClasses(void) {
    typedef void *(*domain_get_fn)(void);
    typedef void **(*assemblies_fn)(const void *,size_t *);
    typedef const void *(*assembly_image_fn)(const void *);
    typedef size_t (*class_count_fn)(const void *);
    typedef void *(*class_get_fn)(const void *,size_t);
    typedef const char *(*class_name_fn)(void *);
    typedef const char *(*class_namespace_fn)(void *);
    typedef const void *(*class_method_fn)(void *,void **);
    typedef const char *(*method_name_fn)(const void *);
    typedef uint32_t (*method_params_fn)(const void *);
    domain_get_fn domain=(domain_get_fn)dlsym(RTLD_DEFAULT,"il2cpp_domain_get");
    assemblies_fn assemblies=(assemblies_fn)dlsym(RTLD_DEFAULT,"il2cpp_domain_get_assemblies");
    assembly_image_fn getimage=(assembly_image_fn)dlsym(RTLD_DEFAULT,"il2cpp_assembly_get_image");
    class_count_fn count=(class_count_fn)dlsym(RTLD_DEFAULT,"il2cpp_image_get_class_count");
    class_get_fn getclass=(class_get_fn)dlsym(RTLD_DEFAULT,"il2cpp_image_get_class");
    class_name_fn name=(class_name_fn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_name");
    class_namespace_fn ns=(class_namespace_fn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_namespace");
    class_method_fn nextmethod=(class_method_fn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_methods");
    method_name_fn methodname=(method_name_fn)dlsym(RTLD_DEFAULT,"il2cpp_method_get_name");
    method_params_fn params=(method_params_fn)dlsym(RTLD_DEFAULT,"il2cpp_method_get_param_count");
    if(!domain||!assemblies||!getimage||!count||!getclass||!name||!ns||!nextmethod||!methodname||!params) {
        twLog(@"V83_METHOD_DISCOVERY_EXPORTS_MISSING");return;
    }
    size_t n=0;void **arr=assemblies(domain(),&n);
    unsigned int classes=0,methods=0,candidates=0;
    for(size_t i=0;arr && i<n;i++) {
        const void *im=getimage(arr[i]);if(!im)continue;
        size_t nc=count(im);
        for(size_t j=0;j<nc;j++) {
            void *cl=getclass(im,j);if(!cl)continue;
            const char *cn=name(cl),*cns=ns(cl);
            NSString *full=[NSString stringWithFormat:@"%s.%s",cns?cns:"",cn?cn:""];
            if([full rangeOfString:@"TokenWheel" options:NSCaseInsensitiveSearch].location==NSNotFound)continue;
            BOOL target=([full rangeOfString:@"PopupController" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                [full rangeOfString:@"PopupModel" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                [full rangeOfString:@"SpinButton" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                [full rangeOfString:@"Network" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                [full rangeOfString:@"Reward" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                [full rangeOfString:@"Result" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                [full rangeOfString:@"ThunderSpinController" options:NSCaseInsensitiveSearch].location!=NSNotFound);
            if(!target)continue;
            classes++;
            if(classes<=70)twLog([NSString stringWithFormat:@"V83_CLASS %@",full]);
            void *iter=nullptr;const void *m=nullptr;unsigned int local=0;
            while((m=nextmethod(cl,&iter))!=nullptr && local<400) {
                local++;methods++;
                const char *mn=methodname(m);if(!mn)continue;
                NSString *method=[NSString stringWithUTF8String:mn];
                BOOL relevant=([method rangeOfString:@"Spin" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Reward" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Result" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Success" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Won" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Collect" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Response" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Click" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                    [method rangeOfString:@"Open" options:NSCaseInsensitiveSearch].location!=NSNotFound);
                if(relevant) {
                    candidates++;
                    if(candidates<=240)twLog([NSString stringWithFormat:@"V83_METHOD %@::%@ argc=%u method=%p",full,method,(unsigned int)params(m),m]);
                }
            }
        }
    }
    twLog([NSString stringWithFormat:@"V83_METHOD_DISCOVERY_DONE classes=%u methods=%u candidates=%u",classes,methods,candidates]);
}
static bool twSpinInstalled=false;
static bool twResultInstalled=false;
static int twAttempts=0;
static void twInstall(void) {
    twAttempts++;
    twDiscoverUnityUI();
    twInstallPopup();
    twInstallAsync();
    const char *img=nullptr;
    if (!twSpinInstalled) {
        void *c=Il2CppFindClassAnyImage("TokenWheel.NetworkV2", "TokenWheelNetworkManagerV2", &img);
        if (c && img) {
            MethodInfo *m=Il2CppFindMethodInfoRaw(img,"TokenWheel.NetworkV2","TokenWheelNetworkManagerV2","SendSpinRequest",2,false);
            if (m && m->methodPointer && DobbyHook((void *)m->methodPointer,(void *)twSpin,(void **)&origSpin)==0) {
                twSpinInstalled=true; twLog([NSString stringWithFormat:@"HOOK_SPIN_INSTALLED_NOT_VERIFIED image=%s address=%p trampoline=%p",img,m->methodPointer,origSpin]);
            } else twLog(@"HOOK_SPIN_FAILED");
        } else twLog([NSString stringWithFormat:@"CLASS_NETWORK_MANAGER_NOT_FOUND attempt=%d",twAttempts]);
    }
    img=nullptr;
    if (!twResultInstalled) {
        void *c=Il2CppFindClassAnyImage("TokenWheel", "TokenWheelNetworkRequestFinishedSignal", &img);
        if (c && img) {
            MethodInfo *m=Il2CppFindMethodInfoRaw(img,"TokenWheel","TokenWheelNetworkRequestFinishedSignal","CreateFromSuccessfulRequest",2,false);
            if (m && m->methodPointer && DobbyHook((void *)m->methodPointer,(void *)twSuccess,(void **)&origSuccess)==0) {
                twResultInstalled=true; twLog([NSString stringWithFormat:@"HOOK_RESULT_INSTALLED_NOT_VERIFIED image=%s address=%p trampoline=%p",img,m->methodPointer,origSuccess]);
            } else twLog(@"HOOK_RESULT_FAILED");
        } else twLog([NSString stringWithFormat:@"CLASS_RESULT_NOT_FOUND attempt=%d",twAttempts]);
    }
    if ((!twSpinInstalled || !twResultInstalled || !twPopupInstalled[0] || !twPopupInstalled[1] || !twPopupInstalled[2] || !twPopupInstalled[3]) && twAttempts < 12) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5*NSEC_PER_SEC),dispatch_get_main_queue(), ^{ twInstall(); });
    }
}

static void (*twOriginalSendEvent)(id,SEL,UIEvent *);
static NSUInteger twTouchCount=0;
static void twObservedSendEvent(id self,SEL cmd,UIEvent *event) {
    if (event.type == UIEventTypeTouches) {
        for (UITouch *touch in event.allTouches) {
            if (touch.phase == UITouchPhaseBegan) {
                CGPoint point=[touch locationInView:(UIView *)self];
                twTouchCount++;
                twLog([NSString stringWithFormat:@"UI_TOUCH_BEGIN seq=%lu x=%.1f y=%.1f window=%p",(unsigned long)twTouchCount,point.x,point.y,self]);
            } else if (touch.phase == UITouchPhaseEnded) {
                CGPoint point=[touch locationInView:(UIView *)self];
                twLog([NSString stringWithFormat:@"UI_TOUCH_END x=%.1f y=%.1f",point.x,point.y]);
            }
        }
    }
    twOriginalSendEvent(self,cmd,event);
}
static void twInstallTouchProbe(void) {
    Class cls=objc_getClass("UIWindow");
    Method method=class_getInstanceMethod(cls,@selector(sendEvent:));
    if (!method) { twLog(@"UI_TOUCH_PROBE_MISSING"); return; }
    twOriginalSendEvent=(void (*)(id,SEL,UIEvent *))method_getImplementation(method);
    method_setImplementation(method,(IMP)twObservedSendEvent);
    twLog(@"UI_TOUCH_PROBE_OK (touch coordinates only; not proof of wheel callback)");
}

__attribute__((constructor)) static void twStart(void) {
    twLock=[NSRecursiveLock new];
    twLines=[NSMutableArray array];
    twLog(@"START v85 token wheel early read-only trace; tap to view, long-press to copy");
    dispatch_async(dispatch_get_main_queue(), ^{ twInstallTouchProbe(); twUI(); });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1*NSEC_PER_SEC),dispatch_get_main_queue(), ^{ tw84InstallLive(); });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 4*NSEC_PER_SEC),dispatch_get_main_queue(), ^{ if(!tw84Installed[0])tw84InstallLive(); });
}
