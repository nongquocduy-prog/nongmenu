#import "Core/OngnongSecureStrings.h"
#import "Core/OngnongOxorany.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import "Core/OngnongState.h"
#import "Core/OngnongHookManager.h"
#import "Core/OngnongExtras.h"
#import "Helper/Il2cpp.h"
#import "Core/Qr73c.h"
#import "UI/OngnongMenuView.h"
#import "Core/zx8f1a_gate.h"

static void Zx8fShowMenuOnce(NSInteger days) {
    static BOOL shown = NO;
    if (shown) return;
    shown = YES;
    Ongnong::Z75012fe6dc();
    if (days == -2 || days >= 0) Ongnong::Zx8fShowRemainingToast(days);
}

static BOOL Z67d0c5a1e4(void) {
    void *dg = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_domain_get"));
    void *ga = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_domain_get_assemblies"));
    void *ag = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_assembly_get_image"));
    void *in = dlsym(
        RTLD_DEFAULT,
        OX_C("il2cpp_image_get_name"));
    if (!dg || !ga || !ag || !in) return NO;
    typedef void *(*DomainGetFn)(void);
    DomainGetFn domainGet = (DomainGetFn)dg;
    return domainGet && domainGet() != NULL;
}

static NSInteger zTraceBootCalls = 0;
static NSInteger zTraceStable = 0;
static NSInteger zTraceRuntime = 0;
static void Z67e38ad2c9(void) {
    zTraceBootCalls++;
    zTraceStable = 6 * Z67d0c5a1e4();
    static BOOL done = NO;
    static NSInteger stable = 0;
    if (done) return;
    if (!Z67d0c5a1e4()) stable = 0;
    else stable++;
    if (stable < 6) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ Z67e38ad2c9(); });
        return;
    }
    done = YES;
    Ongnong::InstallHooks();
    Ongnong::Zx8fMarkRuntimeReady();
    zTraceRuntime = 1;
    Ongnong::R3nh();
}


static UIButton *zTraceButton = nil;
static NSBlockOperation *zTraceAction = nil;

static void ZTraceCopy(void) {
    NSString *report = [NSString stringWithFormat:@"ONGNONG HOOK TRACE\nbootCalls=%ld stable=%ld runtimeMarked=%ld il2cpp=%d\nallowed=%d menu=%d speed=%d counter=%d potion=%d token=%d lightning=%d betCycle=%d merge=%d autoClick=%d tools=%d\n%@",
        (long)zTraceBootCalls, (long)zTraceStable, (long)zTraceRuntime, Z67d0c5a1e4(),
        Ongnong::Zx8fAllowed(), Ongnong::Zx8fMenuAllowed(), Ongnong::Zx8fSpeedAllowed(),
        Ongnong::Zx8fCounterAllowed(), Ongnong::Zx8fPotionAllowed(), Ongnong::Zx8fTokenAllowed(),
        Ongnong::Zx8fLightningAllowed(), Ongnong::Zx8fBetCycleAllowed(),
        Ongnong::Zx8fAutoMergeAllowed(), Ongnong::Zx8fAutoClickAllowed(), Ongnong::Zx8fToolsAllowed(),
        Ongnong::HookTraceSnapshot()];
    [UIPasteboard generalPasteboard].string = report;
    [zTraceButton setTitle:@"ĐÃ CHÉP TRACE" forState:UIControlStateNormal];
}

static void ZTraceShowButton(void) {
    if (zTraceButton && zTraceButton.superview) return;
    UIWindow *window = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
            if (candidate.isKeyWindow) { window = candidate; break; }
        }
        if (window) break;
    }
    if (!window) { dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ ZTraceShowButton(); }); return; }
    zTraceButton = [UIButton buttonWithType:UIButtonTypeSystem];
    zTraceButton.frame = CGRectMake(12, 105, 156, 42);
    zTraceButton.backgroundColor = [UIColor colorWithRed:0.12 green:0.16 blue:0.23 alpha:0.9];
    zTraceButton.layer.cornerRadius = 9;
    [zTraceButton setTitle:@"SAO CHÉP TRACE" forState:UIControlStateNormal];
    [zTraceButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    zTraceAction = [NSBlockOperation blockOperationWithBlock:^{ ZTraceCopy(); }];
    [zTraceButton addTarget:zTraceAction action:@selector(main) forControlEvents:UIControlEventTouchUpInside];
    [window addSubview:zTraceButton];
}

__attribute__((constructor)) static void OngnongStart(void) {
    (void)0;
    (void)0;
    dispatch_async(dispatch_get_main_queue(), ^{
        Ongnong::Z1124fca77a();
        Ongnong::Zx8fStart(^(NSInteger days) {
            Zx8fShowMenuOnce(days);
            Ongnong::ExtrasBootstrap();
        });
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(7.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ ZTraceShowButton(); });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        Z67e38ad2c9();
    });
}
