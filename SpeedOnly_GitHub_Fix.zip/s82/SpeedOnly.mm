#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <QuartzCore/QuartzCore.h>

typedef void (*SetScale)(float);
static SetScale speedSetter = NULL;
static float chosenSpeed = 1.0f;
static BOOL paused = NO;
static BOOL wifiIndicator = YES;
static void ApplySpeed(void) {
    if (!speedSetter) {
        void *handle = dlopen("UnityFramework", RTLD_NOLOAD | RTLD_NOW);
        if (!handle) handle = dlopen("@rpath/UnityFramework.framework/UnityFramework", RTLD_NOLOAD | RTLD_NOW);
        if (!handle) handle = RTLD_DEFAULT;
        void *(*resolve)(const char *) = (void *(*)(const char *))dlsym(handle,"il2cpp_resolve_icall");
        if (resolve) speedSetter = (SetScale)resolve("UnityEngine.Time::set_timeScale(System.Single)");
        if (!speedSetter && resolve) speedSetter = (SetScale)resolve("UnityEngine.Time::set_timeScale");
    }
    if (speedSetter) speedSetter(paused ? 0.0f : chosenSpeed);
}
@interface SpeedOnlyPanel : UIView
@property(nonatomic,strong) NSArray<UIButton *> *buttons;
@property(nonatomic,strong) NSTimer *timer;
@end
@implementation SpeedOnlyPanel
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self=[super initWithFrame:frame])) {
        self.backgroundColor=[UIColor colorWithRed:0.07 green:0.10 blue:0.16 alpha:0.92];
        self.layer.cornerRadius=15;
        self.layer.borderWidth=1;
        self.layer.borderColor=[UIColor colorWithRed:0.26 green:0.7 blue:1 alpha:0.8].CGColor;
        NSArray *names=@[@"9",@"108",@"Ⅱ",@"WiFi"];
        NSMutableArray *items=[NSMutableArray array];
        for (NSInteger i=0;i<4;i++) {
            UIButton *b=[UIButton buttonWithType:UIButtonTypeCustom];
            b.frame=CGRectMake(7+i*62,7,57,36);
            b.tag=i;
            b.titleLabel.font=[UIFont boldSystemFontOfSize:14];
            [b setTitle:names[i] forState:UIControlStateNormal];
            b.layer.cornerRadius=9;
            [b addTarget:self action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:b]; [items addObject:b];
        }
        self.buttons=items;
        [self addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(drag:)]];
        self.timer=[NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(tick) userInfo:nil repeats:YES];
        [self refresh];
    }
    return self;
}
- (void)tick { ApplySpeed(); }
- (void)tap:(UIButton *)sender {
    if(sender.tag==0){chosenSpeed=9;paused=NO;}
    if(sender.tag==1){chosenSpeed=108;paused=NO;}
    if(sender.tag==2){paused=!paused;}
    if(sender.tag==3){wifiIndicator=!wifiIndicator;}
    ApplySpeed(); [self refresh];
}
- (void)refresh {
    for (UIButton *b in self.buttons) {
        BOOL active=(b.tag==0&&!paused&&chosenSpeed==9)||(b.tag==1&&!paused&&chosenSpeed==108)||(b.tag==2&&paused)||(b.tag==3&&wifiIndicator);
        b.backgroundColor=active?[UIColor colorWithRed:0.93 green:0.48 blue:0.12 alpha:1]:[UIColor colorWithWhite:0.19 alpha:1];
    }
}
- (void)drag:(UIPanGestureRecognizer *)gesture {
    CGPoint t=[gesture translationInView:self.superview];
    self.center=CGPointMake(self.center.x+t.x,self.center.y+t.y);
    [gesture setTranslation:CGPointZero inView:self.superview];
}
@end
static SpeedOnlyPanel *panel;
static void ShowSpeed(void) {
    if(panel.superview) return;
    UIWindow *window=nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *w in ((UIWindowScene *)scene).windows) if(w.isKeyWindow){window=w;break;}
        if(window) break;
    }
    if(!window) window=UIApplication.sharedApplication.windows.firstObject;
    if(!window) return;
    if(!panel) panel=[[SpeedOnlyPanel alloc] initWithFrame:CGRectMake(12,100,262,50)];
    [window addSubview:panel];
}
__attribute__((constructor)) static void StartSpeed(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES block:^(NSTimer *timer){ShowSpeed();}];
    });
}
