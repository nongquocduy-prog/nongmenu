Speed-only iOS source. Only horizontal Speed UI and its Unity timeScale call remain.
Upload SpeedOnly_GitHub.zip to repository root and extract its contents, or place the ZIP in the repository root alongside .github/workflows/build.yml.
GitHub Actions -> Build Ongnongios1 dylib -> Run workflow.
Output artifact: Ongnongios1.dylib.
Note: GitHub build and game compatibility have not been tested here. WiFi button is visual state only.
