#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <dlfcn.h>
#import <mach-o/dyld.h>

@interface ONLiveEventBar : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) UITextView *view;
@property(nonatomic,strong) UIButton *toggle;
@property(nonatomic,strong) NSMutableArray<NSString *> *lines;
@property(nonatomic,assign) BOOL expanded;
+ (instancetype)shared;
- (void)append:(NSString *)line;
- (void)show;
@end

@implementation ONLiveEventBar
+ (instancetype)shared { static ONLiveEventBar *o; static dispatch_once_t once; dispatch_once(&once, ^{ o=[ONLiveEventBar new]; o.lines=[NSMutableArray array]; }); return o; }
- (void)append:(NSString *)line {
 if (!line) return;
 dispatch_async(dispatch_get_main_queue(), ^{
  NSString *s=[NSString stringWithFormat:@"%@ %@", [[NSDate date] descriptionWithLocale:nil], line];
  [self.lines addObject:s];
  if (self.lines.count>160) [self.lines removeObjectAtIndex:0];
  if (self.expanded) { self.view.text=[self.lines componentsJoinedByString:@"\n"]; [self.view scrollRangeToVisible:NSMakeRange(self.view.text.length,0)]; }
  NSString *p=[NSTemporaryDirectory() stringByAppendingPathComponent:@"ONGNONG_LiveEvents.txt"];
  NSFileHandle *f=[NSFileHandle fileHandleForWritingAtPath:p];
  if (!f) { [[NSData data] writeToFile:p atomically:YES]; f=[NSFileHandle fileHandleForWritingAtPath:p]; }
  @try { [f seekToEndOfFile]; [f writeData:[[s stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]]; [f closeFile]; } @catch(NSException *e) {}
 });
}
- (void)togglePanel {
 self.expanded=!self.expanded;
 self.view.hidden=!self.expanded;
 self.window.frame=self.expanded?CGRectMake(8,105,UIScreen.mainScreen.bounds.size.width-16,285):CGRectMake(8,105,210,42);
 [self.toggle setTitle:self.expanded?@"LIVE EVENTS  −  SHARE":@"LIVE EVENTS  +" forState:UIControlStateNormal];
 if (self.expanded) self.view.text=[self.lines componentsJoinedByString:@"\n"];
}
- (void)shareLog {
 NSString *p=[NSTemporaryDirectory() stringByAppendingPathComponent:@"ONGNONG_LiveEvents.txt"];
 UIViewController *root=UIApplication.sharedApplication.keyWindow.rootViewController;
 if (!root) return;
 UIActivityViewController *a=[[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:p]] applicationActivities:nil];
 if (a.popoverPresentationController) a.popoverPresentationController.sourceView=self.toggle;
 [root presentViewController:a animated:YES completion:nil];
}
- (void)tap:(UITapGestureRecognizer *)g { if (g.numberOfTapsRequired==2) [self shareLog]; }
- (void)show {
 if (self.window) return;
 UIWindow *w=[[UIWindow alloc] initWithFrame:CGRectMake(8,105,210,42)];
 w.windowLevel=UIWindowLevelAlert+50; w.backgroundColor=[UIColor colorWithWhite:0.05 alpha:0.88]; w.layer.cornerRadius=10; w.clipsToBounds=YES;
 UIViewController *vc=[UIViewController new]; vc.view.backgroundColor=UIColor.clearColor; w.rootViewController=vc;
 UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem]; b.frame=CGRectMake(0,0,210,42); b.autoresizingMask=UIViewAutoresizingFlexibleWidth; [b setTitle:@"LIVE EVENTS  +" forState:UIControlStateNormal]; [b setTitleColor:UIColor.greenColor forState:UIControlStateNormal]; b.titleLabel.font=[UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightBold]; [b addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside]; [vc.view addSubview:b]; self.toggle=b;
 UITapGestureRecognizer *dbl=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(shareLog)]; dbl.numberOfTapsRequired=2; [b addGestureRecognizer:dbl];
 UITextView *t=[[UITextView alloc] initWithFrame:CGRectMake(5,43,200,236)]; t.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; t.editable=NO; t.backgroundColor=UIColor.clearColor; t.textColor=UIColor.greenColor; t.font=[UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightRegular]; t.hidden=YES; [vc.view addSubview:t]; self.view=t;
 self.window=w; w.hidden=NO;
 [self append:@"MONITOR_STARTED UIKit + IL2CPP runtime object snapshots (no method hooks)"];
}
@end

@interface UIApplication (ONLiveEvents)
- (void)onlive_sendEvent:(UIEvent *)event;
@end
@implementation UIApplication (ONLiveEvents)
- (void)onlive_sendEvent:(UIEvent *)event {
 if (event.type==UIEventTypeTouches) {
  NSSet<UITouch *> *touches=event.allTouches;
  for (UITouch *t in touches) {
   if (t.phase==UITouchPhaseBegan || t.phase==UITouchPhaseEnded) {
    CGPoint p=[t locationInView:nil];
    [[ONLiveEventBar shared] append:[NSString stringWithFormat:@"TOUCH %@ x=%.0f y=%.0f", t.phase==UITouchPhaseBegan?@"DOWN":@"UP",p.x,p.y]];
   }
  }
 }
 [self onlive_sendEvent:event];
}
@end



namespace {
typedef void* (*ONDomainGet)(void);
typedef void** (*ONDomainAssemblies)(void*,size_t*);
typedef void* (*ONAssemblyImage)(void*);
typedef void* (*ONClassFromName)(void*,const char*,const char*);
typedef void* (*ONClassGetMethod)(void*,const char*,int);
typedef void* (*ONClassGetType)(void*);
typedef void* (*ONTypeGetObject)(void*);
typedef void* (*ONRuntimeInvoke)(void*,void*,void**,void**);
typedef uintptr_t (*ONArrayLength)(void*);
typedef void* (*ONStringChars)(void*);
struct ONApi {ONDomainGet domain;ONDomainAssemblies assemblies;ONAssemblyImage image;ONClassFromName klass;ONClassGetMethod method;ONClassGetType type;ONTypeGetObject typeObject;ONRuntimeInvoke invoke;ONArrayLength arrayLength;};
static ONApi onApi={};
static void* onFind(const char* name) {void* p=dlsym(RTLD_DEFAULT,name); if(p)return p; uint32_t n=_dyld_image_count();for(uint32_t i=0;i<n;i++){const char* nm=_dyld_get_image_name(i);if(nm&&strstr(nm,"UnityFramework")){void* h=dlopen(nm,RTLD_NOW|RTLD_NOLOAD);if(h){p=dlsym(h,name);if(p)return p;}}}return nullptr;}
static bool onReady(){
 if(onApi.invoke)return true;
 onApi.domain=(ONDomainGet)onFind("il2cpp_domain_get");
 onApi.assemblies=(ONDomainAssemblies)onFind("il2cpp_domain_get_assemblies");
 onApi.image=(ONAssemblyImage)onFind("il2cpp_assembly_get_image");
 onApi.klass=(ONClassFromName)onFind("il2cpp_class_from_name");
 onApi.method=(ONClassGetMethod)onFind("il2cpp_class_get_method_from_name");
 onApi.type=(ONClassGetType)onFind("il2cpp_class_get_type");
 onApi.typeObject=(ONTypeGetObject)onFind("il2cpp_type_get_object");
 onApi.invoke=(ONRuntimeInvoke)onFind("il2cpp_runtime_invoke");
 onApi.arrayLength=(ONArrayLength)onFind("il2cpp_array_length");
 return onApi.domain&&onApi.assemblies&&onApi.image&&onApi.klass&&onApi.method&&onApi.type&&onApi.typeObject&&onApi.invoke;
}
static void* onClass(const char* ns,const char* name){size_t n=0;void* d=onApi.domain();if(!d)return nullptr;void** as=onApi.assemblies(d,&n);if(!as)return nullptr;for(size_t i=0;i<n;i++){void* im=onApi.image(as[i]);if(im){void* c=onApi.klass(im,ns,name);if(c)return c;}}return nullptr;}
static void* onInvoke(void* method,void* obj,void** args){if(!method)return nullptr;void* ex=nullptr;void* result=onApi.invoke(method,obj,args,&ex);return ex?nullptr:result;}
static NSString* onName(void* object,void* getter){void* v=onInvoke(getter,object,nullptr);if(!v)return nil;typedef int32_t (*StrLen)(void*);typedef const uint16_t* (*StrChars)(void*);static StrLen sl=(StrLen)onFind("il2cpp_string_length");static StrChars sc=(StrChars)onFind("il2cpp_string_chars");if(!sl||!sc)return nil;int32_t len=sl(v);if(len<0||len>256)return nil;return [[NSString alloc]initWithCharacters:(const unichar*)sc(v) length:len];}
static NSMutableDictionary<NSString*,NSNumber*>* onPrevious;
static NSUInteger onCycle=0;
static void onSnapshot(){
 if(!onReady()){if(onCycle++%15==0)[[ONLiveEventBar shared] append:@"IL2CPP_WAIT exports unavailable"];return;}
 static void* finder=nullptr;static void* getter=nullptr;static void* gameObjectType=nullptr;
 if(!finder){void* res=onClass("UnityEngine","Resources");void* go=onClass("UnityEngine","GameObject");void* obj=onClass("UnityEngine","Object");if(res&&go&&obj){finder=onApi.method(res,"FindObjectsOfTypeAll",1);getter=onApi.method(obj,"get_name",0);gameObjectType=onApi.typeObject(onApi.type(go));}if(!finder||!getter||!gameObjectType){if(onCycle++%15==0)[[ONLiveEventBar shared] append:@"IL2CPP_WAIT UnityEngine APIs not ready"];return;}}
 void* arg=gameObjectType;void* args[]={&arg};
 void* array=onInvoke(finder,nullptr,args);
 if(!array){if(onCycle++%15==0)[[ONLiveEventBar shared] append:@"IL2CPP_SCAN_EMPTY or invoke error"];return;}
 uintptr_t count=onApi.arrayLength?onApi.arrayLength(array):*(uintptr_t*)((char*)array+sizeof(void*)*3);
 if(count>50000){[[ONLiveEventBar shared] append:@"IL2CPP_SCAN_REJECT invalid array length"];return;}
 NSMutableDictionary<NSString*,NSNumber*>* current=[NSMutableDictionary dictionary];
 uintptr_t limit=count<2500?count:2500;
 void** elements=(void**)((char*)array+sizeof(void*)*4);
 for(uintptr_t i=0;i<limit;i++){
  void* item=elements[i];if(!item)continue;
  NSString* name=onName(item,getter);if(!name.length)continue;
  NSNumber* num=current[name]?:@0;current[name]=@(num.unsignedIntegerValue+1);
 }
 if(!onPrevious){[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"IL2CPP_READY GameObjects=%lu sampled=%lu names=%lu",(unsigned long)count,(unsigned long)limit,(unsigned long)current.count]];onPrevious=current;return;}
 NSUInteger changes=0;
 for(NSString* key in current){NSInteger delta=current[key].integerValue-[onPrevious[key] integerValue];if(delta>0){if(changes++<18)[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"UNITY_OBJECT +%ld %@",(long)delta,key]];}}
 for(NSString* key in onPrevious){NSInteger delta=[onPrevious[key] integerValue]-[current[key] integerValue];if(delta>0){if(changes++<18)[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"UNITY_OBJECT -%ld %@",(long)delta,key]];}}
 if(changes>18)[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"UNITY_OBJECT more_changes=%lu",(unsigned long)(changes-18)]];
 if(onCycle++%10==0)[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"IL2CPP_SCAN objects=%lu sampled=%lu changes=%lu",(unsigned long)count,(unsigned long)limit,(unsigned long)changes]];
 onPrevious=current;
}
}
@interface ONRuntimeScanner:NSObject
@property(nonatomic,strong) NSTimer* timer;
@end
@implementation ONRuntimeScanner
- (void)tick:(NSTimer*)timer { @try {onSnapshot();} @catch(NSException* e) {[[ONLiveEventBar shared] append:[NSString stringWithFormat:@"IL2CPP_ERROR %@",e.name]];} }
@end
static ONRuntimeScanner* onScanner;

__attribute__((constructor)) static void ONLiveBoot(void) {
 dispatch_async(dispatch_get_main_queue(), ^{
  Method a=class_getInstanceMethod([UIApplication class],@selector(sendEvent:));
  Method b=class_getInstanceMethod([UIApplication class],@selector(onlive_sendEvent:));
  if (a && b) method_exchangeImplementations(a,b);
  [[ONLiveEventBar shared] show];
  onScanner=[ONRuntimeScanner new];
  onScanner.timer=[NSTimer scheduledTimerWithTimeInterval:1.5 target:onScanner selector:@selector(tick:) userInfo:nil repeats:YES];
 });
}
