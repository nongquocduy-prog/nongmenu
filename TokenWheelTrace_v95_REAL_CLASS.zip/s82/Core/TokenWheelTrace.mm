#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <objc/runtime.h>
#include <string.h>
#include <mach-o/dyld.h>
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"

static NSRecursiveLock *twLock;
static NSMutableArray<NSString *> *twLines;
static unsigned long twSeq=0;
static UITextView *twLiveView=nil;
static UIView *twLivePanel=nil;
static bool twLiveEnabled=true;
static unsigned long twSpinId=0;
static unsigned long twCalls[5]={0,0,0,0,0};
static bool twInstalled[5]={false,false,false,false,false};
static unsigned long twScanCount=0;
static unsigned long twLastReport=0;
static unsigned long twClassSeen[5]={0,0,0,0,0};
static unsigned long twMethodSeen[5]={0,0,0,0,0};
static void twLog(NSString *s) {
    [twLock lock];
    if(!twLines)twLines=[NSMutableArray array];
    [twLines addObject:[NSString stringWithFormat:@"%05lu | %@ | %@",++twSeq,[NSDate date],s?:@""]];
    while(twLines.count>600)[twLines removeObjectAtIndex:0];
    [twLock unlock];
    dispatch_async(dispatch_get_main_queue(), ^{
        if(twLiveView && twLiveEnabled){
            NSUInteger start=twLines.count>18?twLines.count-18:0;
            NSArray *tail=[twLines subarrayWithRange:NSMakeRange(start,twLines.count-start)];
            twLiveView.text=[tail componentsJoinedByString:@"\n"];
            if(twLiveView.text.length) [twLiveView scrollRangeToVisible:NSMakeRange(twLiveView.text.length-1,1)];
        }
    });
}
static NSString *twCopy(void) {
    [twLock lock];
    NSString *s=[[twLines copy] componentsJoinedByString:@"\n"];
    [twLock unlock];
    return [@"ONGNONG TOKEN WHEEL TRACE V95 REAL CLASS DIAGNOSTIC\n" stringByAppendingString:s?:@""];
}
static void *(*origStart)(void *,const void *);
static void *(*origStop)(void *,const void *);
static bool (*origValidate)(void *,void **,void **,const void *);
static void *(*origPointerEnd)(void *,int,const void *);
static void *(*origUIActivate)(void *,bool,const void *);
static void *twStartSpin(void *s,const void *m) {
    twSpinId++;twCalls[0]++;
    twLog([NSString stringWithFormat:@"THUNDER_START spin=%lu controller=%p",twSpinId,s]);
    return origStart(s,m);
}
static void *twStopSpin(void *s,const void *m) {
    twCalls[1]++;twLog([NSString stringWithFormat:@"THUNDER_STOP spin=%lu controller=%p",twSpinId,s]);
    return origStop(s,m);
}
static bool twValidate(void *s,void **ts,void **tw,const void *m) {
    twCalls[2]++;
    bool ok=origValidate(s,ts,tw,m);
    twLog([NSString stringWithFormat:@"THUNDER_VALIDATE spin=%lu success=%d thunderReward=%p wheelReward=%p",twSpinId,(int)ok,ts?*ts:nullptr,tw?*tw:nullptr]);
    return ok;
}
static void *twPointerEnd(void *s,int slot,const void *m) {
    twCalls[3]++;twLog([NSString stringWithFormat:@"THUNDER_POINTER_END spin=%lu slot=%d pointer=%p",twSpinId,slot,s]);
    return origPointerEnd(s,slot,m);
}
static void *twUIActivate(void *s,bool animate,const void *m) {
    twCalls[4]++;twLog([NSString stringWithFormat:@"THUNDER_UI_ACTIVATE animate=%d view=%p",(int)animate,s]);
    return origUIActivate(s,animate,m);
}

static unsigned long tokenCalls[8]={0};
static bool tokenVerified[8]={false};
static bool tokenInstalled[8]={false};
static void *(*origTokenClick)(void *,const void *);
static void *(*origTokenSend)(void *,int,void *,const void *);
static void *(*origTokenSuccess)(void *,void *,int,const void *);
static void *(*origTokenMultiple)(void *,void *,int,const void *);
static void *(*origTokenGrand)(void *,bool,int,void *,const void *);
static void *(*origTokenCollect)(void *,void *,void *,const void *);
static void *(*origTokenBars)(void *,void *,const void *);
static void *(*origTokenCollectMultiple)(void *,void *,void *,const void *);
static void *tokenClick(void *o,const void *m){tokenCalls[0]++;twLog([NSString stringWithFormat:@"TOKEN_CLICK n=%lu obj=%p",tokenCalls[0],o]);return origTokenClick(o,m);}
static void *tokenSend(void *o,int bag,void *event,const void *m){tokenCalls[1]++;twLog([NSString stringWithFormat:@"TOKEN_SEND n=%lu rewardsAmountInBag=%d eventPtr=%p",tokenCalls[1],bag,event]);return origTokenSend(o,bag,event,m);}
static void *tokenSuccess(void *o,void *data,int before,const void *m){tokenCalls[2]++;twLog([NSString stringWithFormat:@"TOKEN_SUCCESS n=%lu tokensBefore=%d response=%p",tokenCalls[2],before,data]);return origTokenSuccess(o,data,before,m);}
static void *tokenMultiple(void *o,void *data,int before,const void *m){tokenCalls[3]++;twLog([NSString stringWithFormat:@"TOKEN_MULTIPLE n=%lu tokensBefore=%d response=%p",tokenCalls[3],before,data]);return origTokenMultiple(o,data,before,m);}
static void *tokenGrand(void *o,bool skin,int iteration,void *task,const void *m){tokenCalls[4]++;twLog([NSString stringWithFormat:@"TOKEN_GRAND n=%lu skin=%d iteration=%d",tokenCalls[4],(int)skin,iteration]);return origTokenGrand(o,skin,iteration,task,m);}
static void *tokenCollect(void *o,void *reward,void *data,const void *m){tokenCalls[5]++;twLog([NSString stringWithFormat:@"TOKEN_COLLECT n=%lu reward=%p data=%p",tokenCalls[5],reward,data]);return origTokenCollect(o,reward,data,m);}
static void *tokenBars(void *o,void *data,const void *m){tokenCalls[6]++;twLog([NSString stringWithFormat:@"TOKEN_BARS n=%lu data=%p",tokenCalls[6],data]);return origTokenBars(o,data,m);}
static void *tokenCollectMultiple(void *o,void *rewards,void *data,const void *m){tokenCalls[7]++;twLog([NSString stringWithFormat:@"TOKEN_COLLECT_MULTIPLE n=%lu rewards=%p data=%p",tokenCalls[7],rewards,data]);return origTokenCollectMultiple(o,rewards,data,m);}
static unsigned long v92UnityPressCalls=0;
static unsigned long v92UIKitCalls=0;
static bool v92UnityInstalled=false;
static bool v92UIKitInstalled=false;
static void *(*v92OrigUnityPress)(void *,const void *);
static void *v92UnityPress(void *obj,const void *method){
    v92UnityPressCalls++;
    twLog([NSString stringWithFormat:@"V92_UNITY_BUTTON_PRESS count=%lu object=%p",v92UnityPressCalls,obj]);
    return v92OrigUnityPress(obj,method);
}
static void (*v92OrigUIKitAction)(id,SEL,SEL,id,UIEvent *);
static void v92UIKitAction(id obj,SEL cmd,SEL action,id target,UIEvent *event){
    if(!([obj isKindOfClass:[UIView class]] && [(UIView *)obj tag]==8172026)){
        v92UIKitCalls++;
        if(v92UIKitCalls<=30)twLog([NSString stringWithFormat:@"V92_UIKIT_ACTION count=%lu action=%@ target=%@",v92UIKitCalls,NSStringFromSelector(action),NSStringFromClass([target class])]);
    }
    v92OrigUIKitAction(obj,cmd,action,target,event);
}
static void v92InstallInputTrace(void){
    static unsigned long attempts=0;
    attempts++;
    if(!v92UIKitInstalled){
        Method m=class_getInstanceMethod([UIControl class],@selector(sendAction:to:forEvent:));
        if(m){
            IMP old=method_setImplementation(m,(IMP)v92UIKitAction);
            if(old){v92OrigUIKitAction=(void (*)(id,SEL,SEL,id,UIEvent *))old;v92UIKitInstalled=true;twLog(@"V92_UIKIT_INPUT installed=1");}
        }
    }
    if(!v92UnityInstalled){
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage("UnityEngine.UI","Button",&img);
        if(klass&&img){
            MethodInfo *mi=Il2CppFindMethodInfoRaw(img,"UnityEngine.UI","Button","Press",0,false);
            if(mi&&mi->methodPointer){
                Dl_info info={0};dladdr(mi->methodPointer,&info);
                twLog([NSString stringWithFormat:@"V92_UNITY_PRESS_FOUND ptr=%p image=%s",mi->methodPointer,info.dli_fname?info.dli_fname:"unknown"]);
                int rc=DobbyHook((void*)mi->methodPointer,(void*)v92UnityPress,(void**)&v92OrigUnityPress);
                v92UnityInstalled=(rc==0&&v92OrigUnityPress);
                twLog([NSString stringWithFormat:@"V92_UNITY_PRESS_HOOK rc=%d installed=%d",rc,(int)v92UnityInstalled]);
            }
        }
        if(attempts%15==0)twLog([NSString stringWithFormat:@"V92_INPUT_DISCOVERY pressInstalled=%d uiInstalled=%d pressCalls=%lu uiCalls=%lu",(int)v92UnityInstalled,(int)v92UIKitInstalled,v92UnityPressCalls,v92UIKitCalls]);
    }
}
static void (*v94OriginalSendEvent)(id,SEL,UIEvent *);
static unsigned long v94Touches=0;
static void v94WindowSendEvent(id window,SEL cmd,UIEvent *event){
    if(event && event.type==UIEventTypeTouches){
        for(UITouch *touch in event.allTouches){
            if(touch.phase!=UITouchPhaseEnded)continue;
            UIView *hit=touch.view;
            UIView *cursor=hit;
            bool isTrace=false;
            for(int depth=0;cursor&&depth<12;depth++,cursor=cursor.superview){if(cursor.tag==8172026||cursor==twLivePanel){isTrace=true;break;}}
            if(isTrace)continue;
            CGPoint pt=[touch locationInView:window];
            v94Touches++;
            twLog([NSString stringWithFormat:@"V94_TOUCH_END n=%lu x=%.0f y=%.0f view=%@ window=%@",v94Touches,pt.x,pt.y,NSStringFromClass([hit class]),NSStringFromClass([window class])]);
        }
    }
    v94OriginalSendEvent(window,cmd,event);
}
static void v94InstallTouchTrace(void){
    static bool attempted=false;
    if(attempted)return;
    attempted=true;
    Method m=class_getInstanceMethod([UIWindow class],@selector(sendEvent:));
    if(!m){twLog(@"V94_TOUCH_HOOK method_missing");return;}
    IMP previous=method_setImplementation(m,(IMP)v94WindowSendEvent);
    v94OriginalSendEvent=(void (*)(id,SEL,UIEvent *))previous;
    twLog([NSString stringWithFormat:@"V94_TOUCH_HOOK installed=%d",previous!=NULL]);
}
static bool v93ActiveInstalled=false;
static unsigned long v93ActiveCalls=0;
static void *(*v93OrigSetActive)(void *,bool,const void *);
static void *(*v93GetName)(void *,const void *);
struct V93String {void *klass;void *monitor;int32_t length;uint16_t chars[1];};
static NSString *v93ObjectName(void *obj){
    if(!obj||!v93GetName)return @"";
    V93String *value=(V93String *)v93GetName(obj,nullptr);
    if(!value||value->length<=0||value->length>256)return @"";
    return [[NSString alloc]initWithCharacters:(const unichar *)value->chars length:(NSUInteger)value->length];
}
static void *v93SetActive(void *obj,bool active,const void *method){
    v93ActiveCalls++;
    NSString *name=v93ObjectName(obj);
    NSString *lower=name.lowercaseString;
    if([lower containsString:@"token"]||[lower containsString:@"wheel"]||[lower containsString:@"spin"]||[lower containsString:@"popup"]){
        twLog([NSString stringWithFormat:@"V93_GAMEOBJECT_ACTIVE name=%@ active=%d count=%lu",name,(int)active,v93ActiveCalls]);
    }
    return v93OrigSetActive(obj,active,method);
}
static void v93InstallSceneTrace(void){
    static unsigned long attempts=0;
    if(v93ActiveInstalled)return;
    attempts++;
    const char *img=nullptr;
    void *klass=Il2CppFindClassAnyImage("UnityEngine","GameObject",&img);
    if(!klass||!img){if(attempts%15==1)twLog(@"V93_SCENE_DISCOVERY GameObject missing");return;}
    MethodInfo *set=Il2CppFindMethodInfoRaw(img,"UnityEngine","GameObject","SetActive",1,false);
    const char *objectImage=nullptr;
    void *objectClass=Il2CppFindClassAnyImage("UnityEngine","Object",&objectImage);
    MethodInfo *get=(objectClass&&objectImage)?Il2CppFindMethodInfoRaw(objectImage,"UnityEngine","Object","get_name",0,false):nullptr;
    if(!set||!set->methodPointer||!get||!get->methodPointer){if(attempts%15==1)twLog(@"V93_SCENE_DISCOVERY methods missing");return;}
    v93GetName=(void *(*)(void *,const void *))get->methodPointer;
    int rc=DobbyHook((void *)set->methodPointer,(void *)v93SetActive,(void **)&v93OrigSetActive);
    v93ActiveInstalled=(rc==0&&v93OrigSetActive);
    twLog([NSString stringWithFormat:@"V93_SCENE_HOOK SetActive rc=%d installed=%d ptr=%p",rc,(int)v93ActiveInstalled,set->methodPointer]);
}
static unsigned long v95Calls[5]={0};
static bool v95Installed[5]={false};
static void *(*v95OrigViewClick)(void *,const void *);
static void *(*v95OrigActive)(void *,const void *);
static void *(*v95OrigInactive)(void *,const void *);
static void *(*v95OrigSendValidate)(void *,const void *);
static void *(*v95OrigPopup)(void *,int,const void *);
static void *v95ViewClick(void *o,const void *m){v95Calls[0]++;twLog([NSString stringWithFormat:@"V95_REAL_VIEW_ON_SPIN_CLICKED n=%lu obj=%p",v95Calls[0],o]);return v95OrigViewClick(o,m);}
static void *v95Active(void *o,const void *m){v95Calls[1]++;twLog([NSString stringWithFormat:@"V95_REAL_SPIN_ACTIVE n=%lu obj=%p",v95Calls[1],o]);return v95OrigActive(o,m);}
static void *v95Inactive(void *o,const void *m){v95Calls[2]++;twLog([NSString stringWithFormat:@"V95_REAL_SPIN_INACTIVE n=%lu obj=%p",v95Calls[2],o]);return v95OrigInactive(o,m);}
static void *v95SendValidate(void *o,const void *m){v95Calls[3]++;twLog([NSString stringWithFormat:@"V95_REAL_SEND_VALIDATE n=%lu obj=%p",v95Calls[3],o]);return v95OrigSendValidate(o,m);}
static void *v95Popup(void *o,int source,const void *m){v95Calls[4]++;twLog([NSString stringWithFormat:@"V95_REAL_SHOW_POPUP n=%lu source=%d obj=%p",v95Calls[4],source,o]);return v95OrigPopup(o,source,m);}
static void v95InstallRealMethods(void){
    static const char *names[]={"OnSpinClicked","SpinClickedActiveState","SpinClickedInactiveState","SendAndValidateSpinRequest","ShowPopup"};
    static const char *classes[]={"TokenWheelPopupView","TokenWheelPopupController","TokenWheelPopupController","TokenWheelPopupController","TokenWheelPopupController"};
    static const int counts[]={0,0,0,0,1};
    static const uintptr_t rvas[]={0x32FFFA0,0x32E8784,0x32E8768,0x32EB0B4,0x32E3D30};
    void *hooks[]={(void *)v95ViewClick,(void *)v95Active,(void *)v95Inactive,(void *)v95SendValidate,(void *)v95Popup};
    void **originals[]={(void **)&v95OrigViewClick,(void **)&v95OrigActive,(void **)&v95OrigInactive,(void **)&v95OrigSendValidate,(void **)&v95OrigPopup};
    static unsigned long scans=0;scans++;
    for(int i=0;i<5;i++){
        if(v95Installed[i])continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage("TokenWheel.MVC",classes[i],&img);
        if(!klass||!img){if(scans==1||scans%15==0)twLog([NSString stringWithFormat:@"V95_CLASS_WAIT %s",names[i]]);continue;}
        MethodInfo *mi=Il2CppFindMethodInfoRaw(img,"TokenWheel.MVC",classes[i],names[i],counts[i],false);
        if(!mi||!mi->methodPointer){if(scans==1||scans%15==0)twLog([NSString stringWithFormat:@"V95_METHOD_WAIT %s",names[i]]);continue;}
        Dl_info info={0};bool mapped=dladdr(mi->methodPointer,&info)!=0;
        uintptr_t actual=mapped?(uintptr_t)mi->methodPointer-(uintptr_t)info.dli_fbase:0;
        if(!mapped||!info.dli_fname||!strstr(info.dli_fname,"UnityFramework")||actual!=rvas[i]){
            twLog([NSString stringWithFormat:@"V95_SKIP %s actual=0x%llx expected=0x%llx",names[i],(unsigned long long)actual,(unsigned long long)rvas[i]]);continue;
        }
        int rc=DobbyHook((void *)mi->methodPointer,hooks[i],originals[i]);
        v95Installed[i]=(rc==0&&*originals[i]);
        twLog([NSString stringWithFormat:@"V95_REAL_HOOK %s class=%s rva=0x%llx rc=%d installed=%d",names[i],classes[i],(unsigned long long)actual,rc,(int)v95Installed[i]]);
    }
    if(scans%15==0)twLog([NSString stringWithFormat:@"V95_REAL_HEARTBEAT installed=%d%d%d%d%d calls=%lu,%lu,%lu,%lu,%lu",v95Installed[0],v95Installed[1],v95Installed[2],v95Installed[3],v95Installed[4],v95Calls[0],v95Calls[1],v95Calls[2],v95Calls[3],v95Calls[4]]);
}
static void tokenInstall(void){
    static const char *names[]={"SpinClicked","SendSpinRequest","ProcessSuccessSpinRequest","ProcessSuccessSpinRequestWithMultipleWonIndexes","ProcessGrandPrize","CollectRewards","ProcessGenericProgressBarsUpdate","CollectMultipleRewards"};
    static const char *spaces[]={"TokenWheel.MVC","TokenWheel.NetworkV2","TokenWheel.MVC","TokenWheel.MVC","TokenWheel.MVC","TokenWheel.MVC","TokenWheel.MVC","TokenWheel.MVC"};
    static const char *classes[]={"TokenWheelPopupController","TokenWheelNetworkManagerV2","TokenWheelPopupController","TokenWheelPopupController","TokenWheelPopupController","TokenWheelPopupController","TokenWheelPopupController","TokenWheelPopupController"};
    static const int argc[]={0,2,2,2,3,2,1,2};
    static const uintptr_t rva[]={0x32E8694,0x32E55A4,0x32E8860,0x32E8A6C,0x32E8D38,0x32E9A80,0x32E983C,0x32E9B84};
    void *hooks[]={(void*)tokenClick,(void*)tokenSend,(void*)tokenSuccess,(void*)tokenMultiple,(void*)tokenGrand,(void*)tokenCollect,(void*)tokenBars,(void*)tokenCollectMultiple};
    void **originals[]={(void**)&origTokenClick,(void**)&origTokenSend,(void**)&origTokenSuccess,(void**)&origTokenMultiple,(void**)&origTokenGrand,(void**)&origTokenCollect,(void**)&origTokenBars,(void**)&origTokenCollectMultiple};
    static unsigned long scans=0;scans++;
    for(int i=0;i<8;i++){
        if(tokenInstalled[i])continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage(spaces[i],classes[i],&img);
        if(!klass||!img){if(scans==1||scans%30==0)twLog([NSString stringWithFormat:@"TOKEN_DISCOVERY %s class_missing",names[i]]);continue;}
        MethodInfo *mi=Il2CppFindMethodInfoRaw(img,spaces[i],classes[i],names[i],argc[i],false);
        if(!mi||!mi->methodPointer){if(scans==1||scans%30==0)twLog([NSString stringWithFormat:@"TOKEN_DISCOVERY %s method_missing",names[i]]);continue;}
        Dl_info info={0};bool mapped=dladdr(mi->methodPointer,&info)!=0;
        uintptr_t offset=mapped?(uintptr_t)mi->methodPointer-(uintptr_t)info.dli_fbase:0;
        twLog([NSString stringWithFormat:@"TOKEN_VERIFY %s assembly=%s actual=0x%llx dump=0x%llx ptr=%p image=%s",names[i],img,(unsigned long long)offset,(unsigned long long)rva[i],mi->methodPointer,info.dli_fname?info.dli_fname:"unknown"]);
        if(!mapped||!info.dli_fname||!strstr(info.dli_fname,"UnityFramework")){twLog([NSString stringWithFormat:@"TOKEN_SKIP %s wrong_image",names[i]]);continue;}
        tokenVerified[i]=(offset==rva[i]);
        if(!tokenVerified[i]){twLog([NSString stringWithFormat:@"TOKEN_SKIP %s RVA_mismatch actual=0x%llx expected=0x%llx",names[i],(unsigned long long)offset,(unsigned long long)rva[i]]);continue;}
        int rc=DobbyHook((void*)mi->methodPointer,hooks[i],originals[i]);
        tokenInstalled[i]=(rc==0&&*originals[i]);
        twLog([NSString stringWithFormat:@"TOKEN_HOOK %s rc=%d installed=%d verified=1",names[i],rc,(int)tokenInstalled[i]]);
    }
    if(scans%15==0)twLog([NSString stringWithFormat:@"TOKEN_HEARTBEAT installed=%d%d%d%d%d%d%d%d callbacks=%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu",tokenInstalled[0],tokenInstalled[1],tokenInstalled[2],tokenInstalled[3],tokenInstalled[4],tokenInstalled[5],tokenInstalled[6],tokenInstalled[7],tokenCalls[0],tokenCalls[1],tokenCalls[2],tokenCalls[3],tokenCalls[4],tokenCalls[5],tokenCalls[6],tokenCalls[7]]);
}

static void twInstall(void) {
    const char *names[]={"StartSpin","StopSpin","TryValidateSpinResult","EndPointerSpin","ActivateThunderSpinUI"};
    const char *spaces[]={"MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin","MoonActive.TokenWheel.ThunderSpin"};
    const char *classes[]={"ThunderSpinController","ThunderSpinController","ThunderSpinController","ThunderSpinPointer","ThunderSpinMainUIView"};
    const int counts[]={0,0,2,1,1};
    void *hooks[]={(void *)twStartSpin,(void *)twStopSpin,(void *)twValidate,(void *)twPointerEnd,(void *)twUIActivate};
    void **originals[]={(void **)&origStart,(void **)&origStop,(void **)&origValidate,(void **)&origPointerEnd,(void **)&origUIActivate};
    static const uintptr_t expectedRVA[5]={0x38CA1B8,0x38CA28C,0x38CA5E4,0x38D9964,0x38CFD20};
    twScanCount++;
    for(int i=0;i<5;i++) {
        if(twInstalled[i])continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage(spaces[i],classes[i],&img);
        if(!klass||!img){
            if(twScanCount==1||twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s class_missing scans=%lu",names[i],twScanCount]);
            continue;
        }
        MethodInfo *mi=Il2CppFindMethodInfoRaw(img,spaces[i],classes[i],names[i],counts[i],false);
        if(!mi||!mi->methodPointer){
            if(twScanCount==1||twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s method_missing",names[i]]);
            continue;
        }
        Dl_info info={0};
        bool mapped=dladdr(mi->methodPointer,&info)!=0;
        uintptr_t offset=mapped?(uintptr_t)mi->methodPointer-(uintptr_t)info.dli_fbase:0;
        twLog([NSString stringWithFormat:@"VERIFY %s class=%s assembly=%s offset=0x%llx expected=0x%llx",names[i],classes[i],img,(unsigned long long)offset,(unsigned long long)expectedRVA[i]]);
        if(!mapped||!info.dli_fname||!strstr(info.dli_fname,"UnityFramework")||offset!=expectedRVA[i]){
            twLog([NSString stringWithFormat:@"SKIP %s binary_or_RVA_mismatch",names[i]]);
            continue;
        }
        int rc=DobbyHook((void *)mi->methodPointer,hooks[i],originals[i]);
        if(rc==0&&*originals[i])twInstalled[i]=true;
        twLog([NSString stringWithFormat:@"HOOK %s status=%d installed=%d address=%p",names[i],rc,twInstalled[i],mi->methodPointer]);
    }
    if(twScanCount-twLastReport>=15){
        twLastReport=twScanCount;
        twLog([NSString stringWithFormat:@"LIVE_HEARTBEAT scans=%lu hooks=%d%d%d%d%d callbacks=%lu,%lu,%lu,%lu,%lu",twScanCount,twInstalled[0],twInstalled[1],twInstalled[2],twInstalled[3],twInstalled[4],twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4]]);
    }
}
@interface ONTokenTraceV87Button:UIButton
@end
@implementation ONTokenTraceV87Button
- (void)tap:(id)sender {
    NSString *message=[NSString stringWithFormat:@"Calls: start=%lu stop=%lu validate=%lu pointer=%lu ui=%lu\n\n%@",twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4],twCopy()];
    twLiveEnabled=!twLiveEnabled;
    if(twLivePanel)twLivePanel.hidden=!twLiveEnabled;
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"TOKEN TRACE V95" message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"COPY" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=message;}]];
    [a addAction:[UIAlertAction actionWithTitle:@"CLOSE" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *vc=self.window.rootViewController;
    if(!vc)return;
    while(vc.presentedViewController)vc=vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)hold:(UILongPressGestureRecognizer *)g {
    if(g.state==UIGestureRecognizerStateBegan){[UIPasteboard generalPasteboard].string=twCopy();twLog(@"TRACE_COPIED");}
}
- (void)drag:(UIPanGestureRecognizer *)g {
    CGPoint p=[g translationInView:self.superview];self.center=CGPointMake(self.center.x+p.x,self.center.y+p.y);[g setTranslation:CGPointZero inView:self.superview];
}
@end
static void twUI(void) {
    UIWindow *w=nil;
    for(UIScene *s in UIApplication.sharedApplication.connectedScenes){
        if(![s isKindOfClass:UIWindowScene.class])continue;
        for(UIWindow *x in ((UIWindowScene *)s).windows)if(x.isKeyWindow){w=x;break;}
        if(w)break;
    }
    if(!w)w=UIApplication.sharedApplication.keyWindow;
    if(!w)return;
    if([w viewWithTag:8172026]){
        if(twLivePanel && !twLivePanel.superview)[w addSubview:twLivePanel];
        return;
    }
    ONTokenTraceV87Button *b=[ONTokenTraceV87Button buttonWithType:UIButtonTypeSystem];
    b.tag=8172026;b.frame=CGRectMake(12,170,116,36);
    b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.78];b.layer.cornerRadius=9;
    [b setTitle:@"TOKEN TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [b addTarget:b action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
    [b addGestureRecognizer:[[UILongPressGestureRecognizer alloc]initWithTarget:b action:@selector(hold:)]];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc]initWithTarget:b action:@selector(drag:)]];
    [w addSubview:b];
    if(!twLivePanel){
        CGFloat width=MIN(w.bounds.size.width-24,390);
        UIView *panel=[[UIView alloc]initWithFrame:CGRectMake(12,215,width,235)];
        panel.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.87];
        panel.layer.cornerRadius=9;
        panel.clipsToBounds=YES;
        UILabel *head=[[UILabel alloc]initWithFrame:CGRectMake(9,4,width-18,22)];
        head.text=@"LIVE TOKEN WHEEL • V95";
        head.textColor=[UIColor colorWithRed:0.5 green:1 blue:0.7 alpha:1];
        head.font=[UIFont boldSystemFontOfSize:12];
        [panel addSubview:head];
        UITextView *view=[[UITextView alloc]initWithFrame:CGRectMake(5,27,width-10,203)];
        view.backgroundColor=[UIColor clearColor];
        view.textColor=UIColor.whiteColor;
        view.font=[UIFont monospacedSystemFontOfSize:9 weight:UIFontWeightRegular];
        view.editable=NO;
        view.selectable=YES;
        [panel addSubview:view];
        twLiveView=view;twLivePanel=panel;
        [w addSubview:panel];
    }
}
__attribute__((constructor))static void twStart(void) {
    twLock=[NSRecursiveLock new];twLines=[NSMutableArray array];
    twLog(@"START V95 real TokenWheel class diagnostic");
    dispatch_async(dispatch_get_main_queue(),^{twUI();});
    dispatch_source_t timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC),2*NSEC_PER_SEC,250*NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer,^{v95InstallRealMethods();twInstall();tokenInstall();twUI();});
    dispatch_resume(timer);
    static dispatch_source_t retainedTimer;
    retainedTimer=timer;
}
