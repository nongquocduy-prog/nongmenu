#pragma once
#include <stdbool.h>

@class NSString;
namespace Ongnong {
NSString *AutoMergeOrderDebugCopy(void);
void AutoMergeModuleTraceMode(int mode);
void AutoMergeModuleInstall(void);
void AutoMergeModuleSetEnabled(bool enabled);
void AutoMergeModuleToggle(void);
bool AutoMergeModuleIsEnabled(void);
void AutoMergeModuleTick(void);
bool AutoMergeModuleClaimReward(void);
void AutoMergeModuleResetSession(void);
}
