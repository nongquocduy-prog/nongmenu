#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>
#include <dlfcn.h>
#import <objc/runtime.h>
#include <mach-o/dyld.h>
#include <mach/mach.h>
#import "../PatchNonJB/PatchNonJB.h"
#import "../Helper/Il2cpp.h"

static NSMutableArray<NSString *> *thLines;
static NSLock *thLock;
static void THLog(NSString *s) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{ thLines=[NSMutableArray new]; thLock=[NSLock new]; });
    [thLock lock];
    [thLines addObject:[NSString stringWithFormat:@"%.3f %@",[NSDate timeIntervalSinceReferenceDate],s]];
    while (thLines.count>900) [thLines removeObjectAtIndex:0];
    [thLock unlock];
}
static NSString *THCopy(void) {
    [thLock lock]; NSString *s=[thLines componentsJoinedByString:@"\n"]; [thLock unlock];
    return [@"ONGNONG THUNDER TRACE (READ ONLY)\n" stringByAppendingString:s ?: @""];
}
@interface THButton : UIButton
@end
@implementation THButton
- (void)didMoveToWindow { [super didMoveToWindow]; }
@end
@interface THOverlay : NSObject
@property(nonatomic,strong) THButton *button;
@end
@implementation THOverlay
- (void)tapped:(id)sender { THLog(@"TRACE_BUTTON_TAP logger=ok"); }
- (void)hold:(UILongPressGestureRecognizer *)g {
    if (g.state!=UIGestureRecognizerStateBegan) return;
    [UIPasteboard generalPasteboard].string=THCopy();
    [self.button setTitle:@"COPIED" forState:UIControlStateNormal];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{ [self.button setTitle:@"THUNDER TRACE" forState:UIControlStateNormal]; });
}
- (void)pan:(UIPanGestureRecognizer *)g {
    UIView *v=self.button; CGPoint p=[g translationInView:v.superview];
    v.center=CGPointMake(v.center.x+p.x,v.center.y+p.y); [g setTranslation:CGPointZero inView:v.superview];
}
- (void)show {
    UIWindow *w=nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        if (scene.activationState!=UISceneActivationStateForegroundActive) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) if (candidate.isKeyWindow) {w=candidate;break;}
        if (w) break;
    }
    if (!w) w=UIApplication.sharedApplication.keyWindow;
    if (!w) { dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{[self show];}); return; }
    if (self.button.superview==w) return;
    THButton *b=[THButton buttonWithType:UIButtonTypeCustom];
    b.frame=CGRectMake(5,300,135,38); b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.8];
    b.layer.cornerRadius=11; b.layer.borderWidth=1; b.layer.borderColor=UIColor.cyanColor.CGColor;
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12]; [b setTitle:@"THUNDER TRACE" forState:UIControlStateNormal];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
    UILongPressGestureRecognizer *hold=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(hold:)];
    hold.minimumPressDuration=0.75; [b addGestureRecognizer:hold];
    [b addTarget:self action:@selector(tapped:) forControlEvents:UIControlEventTouchUpInside];
    [w addSubview:b]; self.button=b;
}
@end
static THOverlay *thOverlay;
static void THButtonTap(void) { THLog(@"TRACE_BUTTON_TAP logger=ok"); }

static void *(*thSpin)(void *,void *)=NULL;
static void *(*thResult)(void *,void *,int,void *)=NULL;
static void *(*thGrand)(void *,bool,int,void *,void *)=NULL;
static void (*thViewClick)(void *,void *)=NULL;
static void *(*thActive)(void *,void *)=NULL;
static void THViewClick(void *self,void *method) {
    THLog(@"VIEW_ON_SPIN_CLICKED"); if (thViewClick) thViewClick(self,method);
}
static void *THActive(void *self,void *method) {
    THLog(@"SPIN_ACTIVE_STATE"); return thActive ? thActive(self,method):NULL;
}
static void *THSpin(void *self,void *method) {
    THLog(@"SPIN_CLICK"); return thSpin ? thSpin(self,method):NULL;
}
static void *THResult(void *self,void *response,int before,void *method) {
    THLog([NSString stringWithFormat:@"SPIN_RESULT beforeTokens=%d responsePresent=%d",before,response!=NULL]);
    return thResult ? thResult(self,response,before,method):NULL;
}
static void *THGrand(void *self,bool newSkin,int iteration,void *loadTask,void *method) {
    THLog([NSString stringWithFormat:@"GRAND_PRIZE newSkin=%d iterationBeforeSwitch=%d",(int)newSkin,iteration]);
    return thGrand ? thGrand(self,newSkin,iteration,loadTask,method):NULL;
}
typedef void *(*THDomainGetFn)(void);
typedef void *(*THMethodFindFn)(void *, const char *, int);
static void *(*thTSStart)(void *,void *)=NULL;
static void *(*thTSStop)(void *,void *)=NULL;
static bool (*thTSValidate)(void *,void **,void **,void *)=NULL;
static void (*thTSCashback)(void *,void *,void *,void *)=NULL;
static void (*thTSMultiplier)(void *,void *,void *,void *)=NULL;
static void *(*thTSAfter)(void *,void *)=NULL;
static void *(*thTSFlow)(void *,void *)=NULL;
static void (*thTSUpdate)(void *,void *)=NULL;
static void *TH_TS_Start(void *o,void *m) { THLog([NSString stringWithFormat:@"THUNDER_START_SPIN controller=%p initialized=%d",o,o!=NULL]); return thTSStart?thTSStart(o,m):NULL; }
static void *TH_TS_Stop(void *o,void *m) { THLog([NSString stringWithFormat:@"THUNDER_STOP_SPIN controller=%p initialized=%d",o,o!=NULL]); return thTSStop?thTSStop(o,m):NULL; }
static bool TH_TS_Validate(void *o,void **a,void **b,void *m) {
    THLog(@"THUNDER_VALIDATE_ENTER"); bool r=thTSValidate?thTSValidate(o,a,b,m):false;
    THLog([NSString stringWithFormat:@"THUNDER_VALIDATE_EXIT ok=%d thunder=%d wheel=%d",(int)r,a&&*a!=NULL,b&&*b!=NULL]); return r;
}
static void TH_TS_Cashback(void *o,void *a,void *b,void *m) { THLog(@"THUNDER_CASHBACK"); if(thTSCashback)thTSCashback(o,a,b,m); }
static void TH_TS_Multiplier(void *o,void *a,void *b,void *m) { THLog(@"THUNDER_MULTIPLIER_WIN"); if(thTSMultiplier)thTSMultiplier(o,a,b,m); }
static void *TH_TS_After(void *o,void *m) { THLog(@"THUNDER_AFTER_SPIN"); return thTSAfter?thTSAfter(o,m):NULL; }
static void *TH_TS_Flow(void *o,void *m) { THLog(@"THUNDER_FLOW_AFTER_SPIN"); return thTSFlow?thTSFlow(o,m):NULL; }
static void TH_TS_Update(void *o,void *m) { THLog(@"THUNDER_LIMIT_UPDATE"); if(thTSUpdate)thTSUpdate(o,m); }
static void (*thTSCtor)(void *,void *,void *,void *,void *,void *,void *)=NULL;
static void (*thTSInit)(void *,void *,void *,void *,void *,void *)=NULL;
static bool thLifeInstalled[2]={false,false};
static void TH_TS_Ctor(void *o,void *a,void *b,void *c,void *d,void *e,void *m) {
    THLog([NSString stringWithFormat:@"THUNDER_CTOR_ENTER controller=%p loader=%p error=%p limits=%p tooltip=%p listener=%p",o,a,b,c,d,e]);
    if(thTSCtor)thTSCtor(o,a,b,c,d,e,m);
    THLog([NSString stringWithFormat:@"THUNDER_CTOR_EXIT controller=%p",o]);
}
static void TH_TS_Init(void *o,void *a,void *b,void *c,void *d,void *m) {
    THLog([NSString stringWithFormat:@"THUNDER_INIT_ENTER controller=%p view=%p service=%p tracking=%p bundle=%p",o,a,b,c,d]);
    if(thTSInit)thTSInit(o,a,b,c,d,m);
    THLog([NSString stringWithFormat:@"THUNDER_INIT_EXIT controller=%p",o]);
}
static void THInspectPointer(const char *name, void *mi, void *addr) {
    Dl_info info={0};
    int found=addr && dladdr(addr,&info);
    Dl_info meta={0};
    int metaFound=mi && dladdr(mi,&meta);
    THLog([NSString stringWithFormat:@"THUNDER_POINTER name=%s methodInfo=%p methodPointer=%p codeImage=%s codeBase=%p metadataImage=%s",name,mi,addr,found&&info.dli_fname?info.dli_fname:"UNKNOWN",found?info.dli_fbase:NULL,metaFound&&meta.dli_fname?meta.dli_fname:"UNKNOWN"]);
}
static bool thTSInstalled[8]={false};
static bool thThunderClassFound=false;
static int thThunderAttempts=0;
static void THInstallThunder(THMethodFindFn methodFind) {
    ++thThunderAttempts;
    const char *img=NULL;
    void *klass=Il2CppFindClassAnyImage("MoonActive.TokenWheel.ThunderSpin","ThunderSpinController",&img);
    thThunderClassFound=(klass!=NULL);
    THLog([NSString stringWithFormat:@"THUNDER_CONTROLLER_STATE attempt=%d classFound=%d class=%p methodResolver=%d",thThunderAttempts,thThunderClassFound,klass,methodFind!=NULL]);
    if(!klass || !methodFind) { THLog([NSString stringWithFormat:@"THUNDER_RESOLVE missing class=%p methodFind=%d",klass,methodFind!=NULL]); return; }
    THLog([NSString stringWithFormat:@"THUNDER_RESOLVE image=%s class=%p",img?img:"?",klass]);
    const char *lifecycle[]={".ctor","Awake","Start","OnEnable","Initialize","Init"};
    for(int j=0;j<6;j++){
        void *lm=methodFind(klass,lifecycle[j],-1);
        THLog([NSString stringWithFormat:@"THUNDER_LIFECYCLE_METHOD name=%s found=%d method=%p",lifecycle[j],lm!=NULL,lm]);
    }
    const char *lifeNames[]={".ctor","Init"};
    const int lifeCounts[]={5,4};
    void *lifeHooks[]={(void*)TH_TS_Ctor,(void*)TH_TS_Init};
    void **lifeOriginals[]={(void**)&thTSCtor,(void**)&thTSInit};
    for(int j=0;j<2;j++) {
        if(thLifeInstalled[j])continue;
        void *mi=methodFind(klass,lifeNames[j],lifeCounts[j]);
        void *addr=mi?*(void**)mi:NULL;
        THInspectPointer(lifeNames[j],mi,addr);
        if(!addr){THLog([NSString stringWithFormat:@"THUNDER_LIFECYCLE_HOOK name=%s unresolved method=%p",lifeNames[j],mi]);continue;}
        int status=DobbyHook(addr,lifeHooks[j],lifeOriginals[j]);
        thLifeInstalled[j]=(status==0 && *lifeOriginals[j]!=NULL);
        THLog([NSString stringWithFormat:@"THUNDER_LIFECYCLE_HOOK name=%s address=%p status=%d installed=%d",lifeNames[j],addr,status,thLifeInstalled[j]]);
    }
    const char *names[]={"StartSpin","StopSpin","TryValidateSpinResult","StopSpinOnCashback","StopSpinOnMultiplierWin","AfterSpinFlowEnded","HandleThunderSpinFlowAfterSpin","UpdateLimitUsages"};
    const int counts[]={0,0,2,2,2,0,0,0};
    void *hooks[]={(void*)TH_TS_Start,(void*)TH_TS_Stop,(void*)TH_TS_Validate,(void*)TH_TS_Cashback,(void*)TH_TS_Multiplier,(void*)TH_TS_After,(void*)TH_TS_Flow,(void*)TH_TS_Update};
    void **originals[]={(void**)&thTSStart,(void**)&thTSStop,(void**)&thTSValidate,(void**)&thTSCashback,(void**)&thTSMultiplier,(void**)&thTSAfter,(void**)&thTSFlow,(void**)&thTSUpdate};
    for(int i=0;i<8;i++) {
        if(thTSInstalled[i])continue;
        void *mi=methodFind(klass,names[i],counts[i]); void *addr=mi?*(void**)mi:NULL;
        THInspectPointer(names[i],mi,addr);
        if(!addr){THLog([NSString stringWithFormat:@"THUNDER_HOOK_%d %s unresolved",i,names[i]]);continue;}
        int status=DobbyHook(addr,hooks[i],originals[i]);
        thTSInstalled[i]=(status==0 && *originals[i]!=NULL);
        THLog([NSString stringWithFormat:@"THUNDER_HOOK_%d %s address=%p status=%d installed=%d",i,names[i],addr,status,thTSInstalled[i]]);
    }
}


static void (*thUnityButtonClick)(void *,void *,void *)=NULL;
static void (*thUnitySelectableDown)(void *,void *,void *)=NULL;
static bool thUnityUIInstalled[2]={false,false};
static void THUnityButtonClick(void *button,void *event,void *method) {
    THLog([NSString stringWithFormat:@"UNITY_BUTTON_POINTER_CLICK button=%p event=%p method=%p",button,event,method]);
    if(thUnityButtonClick)thUnityButtonClick(button,event,method);
}
static void THUnitySelectableDown(void *button,void *event,void *method) {
    THLog([NSString stringWithFormat:@"UNITY_SELECTABLE_POINTER_DOWN selectable=%p event=%p method=%p",button,event,method]);
    if(thUnitySelectableDown)thUnitySelectableDown(button,event,method);
}
static void THInstallUnityUI(THMethodFindFn methodFind) {
    const char *names[]={"OnPointerClick","OnPointerDown"};
    const char *classes[]={"Button","Selectable"};
    void *hooks[]={(void*)THUnityButtonClick,(void*)THUnitySelectableDown};
    void **originals[]={(void**)&thUnityButtonClick,(void**)&thUnitySelectableDown};
    for(int i=0;i<2;i++) {
        if(thUnityUIInstalled[i])continue;
        const char *image=NULL;
        void *klass=Il2CppFindClassAnyImage("UnityEngine.UI",classes[i],&image);
        void *mi=klass&&methodFind?methodFind(klass,names[i],1):NULL;
        void *addr=mi?*(void**)mi:NULL;
        THInspectPointer(names[i],mi,addr);
        if(!addr){THLog([NSString stringWithFormat:@"UNITY_UI_RESOLVE class=%s method=%s found=%d image=%s",classes[i],names[i],klass!=NULL,image?image:"UNKNOWN"]);continue;}
        int status=DobbyHook(addr,hooks[i],originals[i]);
        thUnityUIInstalled[i]=(status==0 && *originals[i]!=NULL);
        THLog([NSString stringWithFormat:@"UNITY_UI_HOOK class=%s method=%s address=%p status=%d installed=%d",classes[i],names[i],addr,status,thUnityUIInstalled[i]]);
    }
}

static void THBalanceSnapshot(const char *tag, void *balance) {
    if(!balance) { THLog([NSString stringWithFormat:@"BALANCE_%s null",tag]); return; }
    uint8_t *b=(uint8_t*)balance;
    int tokens=0,bag=0,spent=0,idx=0,maxIdx=0;
    uint8_t won[8]={0},last[8]={0};
    memcpy(won,b+0x28,8); memcpy(last,b+0x30,8);
    memcpy(&tokens,b+0x10,4); memcpy(&bag,b+0x14,4); memcpy(&spent,b+0x18,4);
    memcpy(&idx,b+0x40,4); memcpy(&maxIdx,b+0x44,4);
    THLog([NSString stringWithFormat:@"BALANCE_%s tokens=%d bag=%d spent=%d stage=%d maxStage=%d atMax=%d wonRaw=%02x%02x%02x%02x%02x%02x%02x%02x lastRaw=%02x%02x%02x%02x%02x%02x%02x%02x",tag,tokens,bag,spent,idx,maxIdx,maxIdx>=0&&idx>=maxIdx,won[0],won[1],won[2],won[3],won[4],won[5],won[6],won[7],last[0],last[1],last[2],last[3],last[4],last[5],last[6],last[7]]);
}
static void (*thSetWheelState)(void *,void *,void *)=NULL;
static void (*thBalanceSignal)(void *,void *,int,void *)=NULL;
static void *(*thSendSpin)(void *,int,void *,void *)=NULL;
static void THSetWheelState(void *o,void *balance,void *m) {
    THBalanceSnapshot("MODEL_SET",balance);
    if(thSetWheelState)thSetWheelState(o,balance,m);
}
static void THBalanceSignal(void *o,void *balance,int requestType,void *m) {
    THLog([NSString stringWithFormat:@"BALANCE_SIGNAL requestType=%d",requestType]);
    THBalanceSnapshot("SERVER_UPDATE",balance);
    if(thBalanceSignal)thBalanceSignal(o,balance,requestType,m);
}
static void *THSendSpin(void *o,int bag,void *eventID,void *m) {
    THLog([NSString stringWithFormat:@"SPIN_REQUEST bag=%d eventID=%p",bag,eventID]);
    return thSendSpin?thSendSpin(o,bag,eventID,m):NULL;
}
static bool (*thIsGrandPrizeExists)(void *,void *,void *)=NULL;
static void *(*thGrandPointerValue)(void *,void *,void *,void *)=NULL;
static bool thPrizeInstalled[2]={false,false};
static bool THIsGrandPrizeExists(void *self,void *balance,void *method) {
    THBalanceSnapshot("GRAND_CHECK_IN",balance);
    bool result=thIsGrandPrizeExists?thIsGrandPrizeExists(self,balance,method):false;
    THLog([NSString stringWithFormat:@"GRAND_EXISTS result=%d",(int)result]);
    return result;
}
static void *THGrandPointerValue(void *self,void *spinResponse,void *balanceBeforeSpin,void *method) {
    THBalanceSnapshot("POINTER_SPIN",spinResponse);
    THBalanceSnapshot("POINTER_BEFORE",balanceBeforeSpin);
    void *result=thGrandPointerValue?thGrandPointerValue(self,spinResponse,balanceBeforeSpin,method):NULL;
    THLog([NSString stringWithFormat:@"GRAND_POINTER resultPresent=%d",result!=NULL]);
    return result;
}
static void THInstallPrize(THMethodFindFn methodFind) {
    if(!methodFind)return;
    const char *img=NULL;
    void *klass=Il2CppFindClassAnyImage("TokenWheel.MVC","TokenWheelPopupController",&img);
    const char *names[]={"IsGrandPrizeExists","GetGrandPrizePointerValue"};
    const int counts[]={1,2};
    void *hooks[]={(void*)THIsGrandPrizeExists,(void*)THGrandPointerValue};
    void **originals[]={(void**)&thIsGrandPrizeExists,(void**)&thGrandPointerValue};
    for(int i=0;i<2;i++) {
        if(thPrizeInstalled[i])continue;
        void *mi=klass?methodFind(klass,names[i],counts[i]):NULL;
        void *addr=mi?*(void**)mi:NULL;
        if(!addr){THLog([NSString stringWithFormat:@"PRIZE_RESOLVE name=%s found=%d",names[i],mi!=NULL]);continue;}
        int status=DobbyHook(addr,hooks[i],originals[i]);
        thPrizeInstalled[i]=(status==0&&*originals[i]!=NULL);
        THLog([NSString stringWithFormat:@"PRIZE_HOOK name=%s installed=%d status=%d",names[i],thPrizeInstalled[i],status]);
    }
}
static bool thStateInstalled[3]={false,false,false};
static void THInstallState(THMethodFindFn methodFind) {
    if(!methodFind)return;
    const char *classes[]={"TokenWheelPopupModel","TokenWheelNetworkManagerV2","TokenWheelNetworkManagerV2"};
    const char *names[]={"set_TokenWheelState","SendBalanceSuccessfullyUpdatedSignals","SendSpinRequest"};
    const int counts[]={1,2,2};
    void *hooks[]={(void*)THSetWheelState,(void*)THBalanceSignal,(void*)THSendSpin};
    void **originals[]={(void**)&thSetWheelState,(void**)&thBalanceSignal,(void**)&thSendSpin};
    for(int i=0;i<3;i++) {
        if(thStateInstalled[i])continue;
        const char *img=NULL;
        void *klass=Il2CppFindClassAnyImage(i==0?"TokenWheel.MVC":"TokenWheel.NetworkV2",classes[i],&img);
        void *mi=klass?methodFind(klass,names[i],counts[i]):NULL;
        void *addr=mi?*(void**)mi:NULL;
        if(!addr){THLog([NSString stringWithFormat:@"STATE_RESOLVE name=%s found=%d image=%s",names[i],klass!=NULL,img?img:"UNKNOWN"]);continue;}
        int status=DobbyHook(addr,hooks[i],originals[i]);
        thStateInstalled[i]=(status==0&&*originals[i]!=NULL);
        THLog([NSString stringWithFormat:@"STATE_HOOK name=%s address=%p installed=%d status=%d",names[i],addr,thStateInstalled[i],status]);
    }
}

static int thAttempt=0;
static bool thInstalled[5]={false,false,false,false,false};
static void THInstall(void) {
    ++thAttempt;
    THDomainGetFn domainGet=(THDomainGetFn)dlsym(RTLD_DEFAULT,"il2cpp_domain_get");
    THMethodFindFn methodFind=(THMethodFindFn)dlsym(RTLD_DEFAULT,"il2cpp_class_get_method_from_name");
    const char *imageName=NULL;
    void *klass=Il2CppFindClassAnyImage("TokenWheel.MVC","TokenWheelPopupController",&imageName);
    if (!klass) {
        THLog([NSString stringWithFormat:@"RESOLVE attempt=%d class=missing runtime=%d",thAttempt,domainGet!=NULL]);
    } else {
        THLog([NSString stringWithFormat:@"RESOLVE attempt=%d image=%s class=%p",thAttempt,imageName?imageName:"?",klass]);
        const char *names[]={"SpinClicked","ProcessSuccessSpinRequest","ProcessGrandPrize","OnSpinClicked","SpinClickedActiveState"};
        const int counts[]={0,2,3,0,0};
        void *hooks[]={(void*)THSpin,(void*)THResult,(void*)THGrand,(void*)THViewClick,(void*)THActive};
        void **originals[]={(void**)&thSpin,(void**)&thResult,(void**)&thGrand,(void**)&thViewClick,(void**)&thActive};
        for (int i=0;i<5;i++) {
            const char *targetImage=NULL;
            void *targetClass=(i==3) ? Il2CppFindClassAnyImage("TokenWheel.MVC","TokenWheelPopupView",&targetImage) : klass;
            if (!targetClass) { THLog([NSString stringWithFormat:@"HOOK_%d class_missing",i]); continue; }
            if (thInstalled[i]) continue;
            void *method=methodFind ? methodFind(targetClass,names[i],counts[i]) : NULL;
            void *addr=method ? *(void**)method : NULL;
            THInspectPointer(names[i],method,addr);
            if (!addr) {
                THLog([NSString stringWithFormat:@"HOOK_%d unresolved method=%p",i,method]);
                continue;
            }
            int result=DobbyHook(addr,hooks[i],originals[i]);
            thInstalled[i]=(result==0 && *originals[i]!=NULL);
            THLog([NSString stringWithFormat:@"HOOK_%d address=%p status=%d original=%p installed=%d",i,addr,result,*originals[i],thInstalled[i]]);
        }
    }
    THInstallState(methodFind);
    THInstallPrize(methodFind);
    THInstallThunder(methodFind);
    THInstallUnityUI(methodFind);
    bool allThunder=true; for(int i=0;i<8;i++) if(!thTSInstalled[i]) allThunder=false;
    THLog([NSString stringWithFormat:@"THUNDER_INSTALL_SUMMARY classFound=%d installed=%d/8",thThunderClassFound,([&](){int n=0;for(int i=0;i<8;i++)n+=thTSInstalled[i];return n;})()]);
    if ((!thPrizeInstalled[0] || !thPrizeInstalled[1] || !thStateInstalled[0] || !thStateInstalled[1] || !thStateInstalled[2] || !thLifeInstalled[0] || !thLifeInstalled[1] || !(thInstalled[0]&&thInstalled[1]&&thInstalled[2]&&thInstalled[3]&&thInstalled[4]) || !allThunder || !thUnityUIInstalled[0] || !thUnityUIInstalled[1]) && thAttempt<20) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(1.5*NSEC_PER_SEC)),dispatch_get_main_queue(),^{THInstall();});
    }
}

static NSString *THViewPath(UIView *v) {
    NSMutableArray<NSString *> *parts=[NSMutableArray array];
    for(int k=0;v && k<7;k++,v=v.superview) {
        NSString *aid=v.accessibilityIdentifier;
        [parts addObject:[NSString stringWithFormat:@"%@%@",NSStringFromClass(v.class),aid.length?[NSString stringWithFormat:@"[%@]",aid]:@""]];
    }
    return [parts componentsJoinedByString:@" > "];
}
@interface UIWindow (ONGThunderTouch)
- (void)ong_th_sendEvent:(UIEvent *)event;
@end
@implementation UIWindow (ONGThunderTouch)
- (void)ong_th_sendEvent:(UIEvent *)event {
    if(event.type==UIEventTypeTouches) {
        for(UITouch *touch in event.allTouches) {
            if(touch.phase!=UITouchPhaseEnded) continue;
            CGPoint p=[touch locationInView:self];
            UIView *v=touch.view;
            if(v && ![v isDescendantOfView:thOverlay.button]) {
                THLog([NSString stringWithFormat:@"TOUCH_UP x=%.0f y=%.0f view=%@ path=%@",p.x,p.y,NSStringFromClass(v.class),THViewPath(v)]);
                UIControl *control=nil;
                for(UIView *node=v;node && node!=self;node=node.superview) if([node isKindOfClass:UIControl.class]) {control=(UIControl *)node;break;}
                if(control) {
                    NSArray *targets=control.allTargets.allObjects;
                    NSMutableArray *actions=[NSMutableArray array];
                    for(id target in targets) {
                        NSArray *names=[control actionsForTarget:target forControlEvent:UIControlEventTouchUpInside];
                        if(names.count) [actions addObject:[NSString stringWithFormat:@"%@:%@",NSStringFromClass([target class]),[names componentsJoinedByString:@","]]];
                    }
                    THLog([NSString stringWithFormat:@"UI_CONTROL type=%@ actions=%@",NSStringFromClass(control.class),[actions componentsJoinedByString:@" | "]]);
                }
            }
        }
    }
    [self ong_th_sendEvent:event];
}
@end
static void THInstallTouchTrace(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        Method original=class_getInstanceMethod(UIWindow.class,@selector(sendEvent:));
        Method replacement=class_getInstanceMethod(UIWindow.class,@selector(ong_th_sendEvent:));
        if(original && replacement) {
            method_exchangeImplementations(original,replacement);
            THLog(@"TOUCH_TRACE_INSTALLED UIWindow.sendEvent");
        } else THLog(@"TOUCH_TRACE_UNAVAILABLE");
    });
}

extern "C" void OngnongThunderTraceStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        THLog(@"TRACE_INIT v58");
        thOverlay=[THOverlay new];
        dispatch_async(dispatch_get_main_queue(),^{[thOverlay show]; THInstall();});
    });
}
