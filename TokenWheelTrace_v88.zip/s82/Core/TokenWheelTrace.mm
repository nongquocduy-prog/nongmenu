#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#include <string.h>
#include <mach-o/dyld.h>
#import "../Helper/Il2cpp.h"
#import "../PatchNonJB/dobby.h"

static NSRecursiveLock *twLock;
static NSMutableArray<NSString *> *twLines;
static unsigned long twSeq=0;
static UITextView *twLiveView=nil;
static UIView *twLivePanel=nil;
static bool twLiveEnabled=true;
static unsigned long twSpinId=0;
static unsigned long twCalls[5]={0,0,0,0,0};
static bool twInstalled[5]={false,false,false,false,false};
static unsigned long twScanCount=0;
static unsigned long twLastReport=0;
static unsigned long twClassSeen[5]={0,0,0,0,0};
static unsigned long twMethodSeen[5]={0,0,0,0,0};
static void twLog(NSString *s) {
    [twLock lock];
    if(!twLines)twLines=[NSMutableArray array];
    [twLines addObject:[NSString stringWithFormat:@"%05lu | %@ | %@",++twSeq,[NSDate date],s?:@""]];
    while(twLines.count>600)[twLines removeObjectAtIndex:0];
    [twLock unlock];
    dispatch_async(dispatch_get_main_queue(), ^{
        if(twLiveView && twLiveEnabled){
            NSUInteger start=twLines.count>18?twLines.count-18:0;
            NSArray *tail=[twLines subarrayWithRange:NSMakeRange(start,twLines.count-start)];
            twLiveView.text=[tail componentsJoinedByString:@"\n"];
            if(twLiveView.text.length) [twLiveView scrollRangeToVisible:NSMakeRange(twLiveView.text.length-1,1)];
        }
    });
}
static NSString *twCopy(void) {
    [twLock lock];
    NSString *s=[[twLines copy] componentsJoinedByString:@"\n"];
    [twLock unlock];
    return [@"ONGNONG TOKEN WHEEL TRACE V88\n" stringByAppendingString:s?:@""];
}
static NSString *twBalance(void *p) {
    if(!p)return @"response=NULL";
    const uint8_t *b=(const uint8_t *)p;
    int token=0,bag=0,spent=0;
    memcpy(&token,b+0x10,4);
    memcpy(&bag,b+0x14,4);
    memcpy(&spent,b+0x18,4);
    uint8_t wonValid=*(b+0x2c);
    int wonIndex=0;
    memcpy(&wonIndex,b+0x28,4);
    void *rewards=nullptr;
    memcpy(&rewards,b+0x20,sizeof(void *));
    return [NSString stringWithFormat:@"balance=%p tokenBalance=%d bag=%d spent=%d wonIndex=%@ rewardsList=%p",p,token,bag,spent,wonValid? [NSString stringWithFormat:@"%d",wonIndex]:@"null",rewards];
}
static void *(*origClick)(void *,const void *);
static void *(*origActive)(void *,const void *);
static void *(*origSend)(void *,int,void *,const void *);
static void *(*origSingle)(void *,void *,int,const void *);
static void *(*origMulti)(void *,void *,int,const void *);
static void *twClick(void *s,const void *m) {
    twSpinId++;twCalls[0]++;
    twLog([NSString stringWithFormat:@"SPIN_CLICKED spin=%lu controller=%p",twSpinId,s]);
    return origClick(s,m);
}
static void *twActive(void *s,const void *m) {
    twCalls[1]++;twLog([NSString stringWithFormat:@"SPIN_ACTIVE spin=%lu controller=%p",twSpinId,s]);
    return origActive(s,m);
}
static void *twSend(void *s,int bag,void *event,const void *m) {
    twCalls[2]++;twLog([NSString stringWithFormat:@"REQUEST_SENT spin=%lu bag=%d event=%p",twSpinId,bag,event]);
    return origSend(s,bag,event,m);
}
static void *twSingle(void *s,void *response,int before,const void *m) {
    twCalls[3]++;twLog([NSString stringWithFormat:@"RESULT_SINGLE spin=%lu tokensBefore=%d %@",twSpinId,before,twBalance(response)]);
    return origSingle(s,response,before,m);
}
static void *twMulti(void *s,void *response,int before,const void *m) {
    twCalls[4]++;twLog([NSString stringWithFormat:@"RESULT_MULTI spin=%lu tokensBefore=%d %@",twSpinId,before,twBalance(response)]);
    return origMulti(s,response,before,m);
}
static void twInstall(void) {
    const char *names[]={"SpinClicked","SpinClickedActiveState","SendSpinRequest","ProcessSuccessSpinRequest","ProcessSuccessSpinRequestWithMultipleWonIndexes"};
    const char *spaces[]={"TokenWheel.MVC","TokenWheel.MVC","TokenWheel.NetworkV2","TokenWheel.MVC","TokenWheel.MVC"};
    const char *classes[]={"TokenWheelPopupController","TokenWheelPopupController","TokenWheelNetworkManagerV2","TokenWheelPopupController","TokenWheelPopupController"};
    int counts[]={0,0,2,2,2};
    void *hooks[]={(void *)twClick,(void *)twActive,(void *)twSend,(void *)twSingle,(void *)twMulti};
    void **originals[]={(void **)&origClick,(void **)&origActive,(void **)&origSend,(void **)&origSingle,(void **)&origMulti};
    twScanCount++;
    static const uintptr_t expectedRVA[5]={0x32E8694,0x32E8784,0x32E55A4,0x32E8860,0x32E8A6C};
    for(int i=0;i<5;i++) {
        if(twInstalled[i])continue;
        const char *img=nullptr;
        void *klass=Il2CppFindClassAnyImage(spaces[i],classes[i],&img);
        if(!klass||!img) {
            if(twScanCount==1 || twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s class_missing scans=%lu",names[i],twScanCount]);
            continue;
        }
        twClassSeen[i]++;
        MethodInfo *mi=Il2CppFindMethodInfoRaw(img,spaces[i],classes[i],names[i],counts[i],false);
        if(!mi||!mi->methodPointer){
            if(twScanCount==1 || twScanCount%30==0)twLog([NSString stringWithFormat:@"DISCOVERY %s method_missing image=%s",names[i],img]);
            continue;
        }
        twMethodSeen[i]++;
        Dl_info info={0};
        bool mapped=dladdr(mi->methodPointer,&info)!=0;
        uintptr_t imageBase=mapped?(uintptr_t)info.dli_fbase:0;
        intptr_t offset=mapped?(intptr_t)((uintptr_t)mi->methodPointer-imageBase):-1;
        twLog([NSString stringWithFormat:@"VERIFY %s assembly=%s ptr=%p image=%s imageOffset=0x%llx expectedDumpRVA=0x%llx",names[i],img,mi->methodPointer,mapped&&info.dli_fname?info.dli_fname:"UNMAPPED",(unsigned long long)offset,(unsigned long long)expectedRVA[i]]);
        if(!mapped || !info.dli_fname || !strstr(info.dli_fname,"UnityFramework")){
            twLog([NSString stringWithFormat:@"SKIP %s pointer_not_in_UnityFramework",names[i]]);
            continue;
        }
        int rc=DobbyHook((void *)mi->methodPointer,hooks[i],originals[i]);
        if(rc==0&&*originals[i])twInstalled[i]=true;
        twLog([NSString stringWithFormat:@"HOOK %s status=%d installed=%d address=%p trampoline=%p",names[i],rc,twInstalled[i],mi->methodPointer,*originals[i]]);
    }
    if(twScanCount-twLastReport>=15){
        twLastReport=twScanCount;
        twLog([NSString stringWithFormat:@"LIVE_HEARTBEAT scans=%lu hooks=%d%d%d%d%d callbacks=%lu,%lu,%lu,%lu,%lu",twScanCount,twInstalled[0],twInstalled[1],twInstalled[2],twInstalled[3],twInstalled[4],twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4]]);
    }
}
@interface ONTokenTraceV87Button:UIButton
@end
@implementation ONTokenTraceV87Button
- (void)tap:(id)sender {
    NSString *message=[NSString stringWithFormat:@"Calls: click=%lu active=%lu request=%lu single=%lu multi=%lu\n\n%@",twCalls[0],twCalls[1],twCalls[2],twCalls[3],twCalls[4],twCopy()];
    twLiveEnabled=!twLiveEnabled;
    if(twLivePanel)twLivePanel.hidden=!twLiveEnabled;
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"TOKEN TRACE V88" message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"COPY" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=message;}]];
    [a addAction:[UIAlertAction actionWithTitle:@"CLOSE" style:UIAlertActionStyleCancel handler:nil]];
    UIViewController *vc=self.window.rootViewController;
    if(!vc)return;
    while(vc.presentedViewController)vc=vc.presentedViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
- (void)hold:(UILongPressGestureRecognizer *)g {
    if(g.state==UIGestureRecognizerStateBegan){[UIPasteboard generalPasteboard].string=twCopy();twLog(@"TRACE_COPIED");}
}
- (void)drag:(UIPanGestureRecognizer *)g {
    CGPoint p=[g translationInView:self.superview];self.center=CGPointMake(self.center.x+p.x,self.center.y+p.y);[g setTranslation:CGPointZero inView:self.superview];
}
@end
static void twUI(void) {
    UIWindow *w=nil;
    for(UIScene *s in UIApplication.sharedApplication.connectedScenes){
        if(![s isKindOfClass:UIWindowScene.class])continue;
        for(UIWindow *x in ((UIWindowScene *)s).windows)if(x.isKeyWindow){w=x;break;}
        if(w)break;
    }
    if(!w)w=UIApplication.sharedApplication.keyWindow;
    if(!w)return;
    if([w viewWithTag:8172026]){
        if(twLivePanel && !twLivePanel.superview)[w addSubview:twLivePanel];
        return;
    }
    ONTokenTraceV87Button *b=[ONTokenTraceV87Button buttonWithType:UIButtonTypeSystem];
    b.tag=8172026;b.frame=CGRectMake(12,170,116,36);
    b.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.78];b.layer.cornerRadius=9;
    [b setTitle:@"TOKEN TRACE" forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont boldSystemFontOfSize:12];
    [b addTarget:b action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
    [b addGestureRecognizer:[[UILongPressGestureRecognizer alloc]initWithTarget:b action:@selector(hold:)]];
    [b addGestureRecognizer:[[UIPanGestureRecognizer alloc]initWithTarget:b action:@selector(drag:)]];
    [w addSubview:b];
    if(!twLivePanel){
        CGFloat width=MIN(w.bounds.size.width-24,390);
        UIView *panel=[[UIView alloc]initWithFrame:CGRectMake(12,215,width,235)];
        panel.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.87];
        panel.layer.cornerRadius=9;
        panel.clipsToBounds=YES;
        UILabel *head=[[UILabel alloc]initWithFrame:CGRectMake(9,4,width-18,22)];
        head.text=@"LIVE TOKEN WHEEL • V88";
        head.textColor=[UIColor colorWithRed:0.5 green:1 blue:0.7 alpha:1];
        head.font=[UIFont boldSystemFontOfSize:12];
        [panel addSubview:head];
        UITextView *view=[[UITextView alloc]initWithFrame:CGRectMake(5,27,width-10,203)];
        view.backgroundColor=[UIColor clearColor];
        view.textColor=UIColor.whiteColor;
        view.font=[UIFont monospacedSystemFontOfSize:9 weight:UIFontWeightRegular];
        view.editable=NO;
        view.selectable=YES;
        [panel addSubview:view];
        twLiveView=view;twLivePanel=panel;
        [w addSubview:panel];
    }
}
__attribute__((constructor))static void twStart(void) {
    twLock=[NSRecursiveLock new];twLines=[NSMutableArray array];
    twLog(@"START V88 targeted wheel request/result trace");
    dispatch_async(dispatch_get_main_queue(),^{twUI();});
    dispatch_source_t timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC),2*NSEC_PER_SEC,250*NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer,^{twInstall();twUI();});
    dispatch_resume(timer);
    static dispatch_source_t retainedTimer;
    retainedTimer=timer;
}
