#import "Esp/ImGuiDrawView.h"
#import <Foundation/Foundation.h>
#include <string>
#import "Esp/LoadView.h"
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#import "Helper/images_base64.h"
#include "webp/decode.h"
#include <sys/types.h>
#include <sys/sysctl.h>
#define ICON_FA_COG u8"\uf013"
#define ICON_FA_WRENCH u8"\uf0ad"
#define ICON_FA_EXTRA u8"\uf067"
#include <iostream> 
#include <UIKit/UIKit.h>
#include <vector>
#include "iconcpp.h"
#import "pthread.h"
#include <array>
#include <cmath>
#include <deque>
#include <fstream>
#include <algorithm>
#include <string>
#import "Avatar.h"
#import "IMGUI/stb_image.h"
struct ImFont;
ImFont *_espFont;
ImFont *_iconFont;
static bool MenDeal = false;
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdint>
#include <cerrno>
#include <cctype>
static int style_idx = 0;
#import "JRMemory.framework/Headers/MemScan.h"
#import "Esp/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_internal.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/zzz.h"
#include "oxorany/oxorany_include.h"
#include "font.h"
#import "Esp/Includes.h"
#include "Helper/font.h"
#include "Helper/data.h"
#include "Helper/Semakin.h"
#import "FPSDisplay/FPSDisplay.h"

ImFont* verdana_smol;
ImFont* pixel_big = {};
ImFont* pixel_smol = {};
ImFont* semakin_font = {};

#include "Helper/Obfuscate.h"
#import "Helper/Hooks.h"

#import "IMGUI/zzz.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>
#import "ProFont.h"
#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define UIColorFromHex(hexColor) [UIColor colorWithRed:((float)((hexColor & 0xFF0000) >> 16))/255.0 green:((float)((hexColor & 0xFF00) >> 8))/255.0 blue:((float)(hexColor & 0xFF))/255.0 alpha:1.0]
UIWindow *mainWindow;
UIButton *menuView;

static inline float lerp_local(float a, float b, float t) {
    return a + t * (b - a);
}

ImVec4 lerp(const ImVec4& a, const ImVec4& b, float t) {
    return ImVec4(lerp_local(a.x, b.x, t), lerp_local(a.y, b.y, t), lerp_local(a.z, b.z, t), lerp_local(a.w, b.w, t));
}

static inline void OpenURL_iOS(const char* url_cstr) {
    NSString *s = [NSString stringWithUTF8String:url_cstr ?: ""];
    NSURL *u = [NSURL URLWithString:s];
    if (!u) return;
    UIApplication *app = [UIApplication sharedApplication];
    if (@available(iOS 10.0, *)) {
        [app openURL:u options:@{} completionHandler:nil];
    } else {
        [app openURL:u];
    }
}

struct Texture {
    id<MTLTexture> texture; 
    float height;
    float width;
};
id<MTLTexture> LoadImageFromMemory(id<MTLDevice> device, unsigned char* image_data, size_t image_size) {
    CFDataRef imageData = CFDataCreate(kCFAllocatorDefault, image_data, image_size);
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData(imageData);
    CGImageRef cgImage = CGImageCreateWithPNGDataProvider(dataProvider, NULL, false, kCGRenderingIntentDefault);
    CFRelease(imageData);
    CGDataProviderRelease(dataProvider);
    if (!cgImage) {
        return nil;
    }
    NSError *error = nil;
    MTKTextureLoader *textureLoader = [[MTKTextureLoader alloc] initWithDevice:device];
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    id<MTLTexture> texture = [textureLoader newTextureWithCGImage:cgImage options:options error:&error];

    if (error) {
        CGImageRelease(cgImage);
        return nil;
    }
    CGImageRelease(cgImage);
    return texture;
}
std::vector<unsigned char> Base64Decode(const std::string &in) {
    std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::vector<unsigned char> out;
    std::vector<int> T(256, -1);
    for (int i = 0; i < 64; i++) T[base64_chars[i]] = i;

    int val = 0, valb = -8;
    for (unsigned char c : in) {
        if (T[c] == -1) break;
        val = (val << 6) + T[c];
        valb += 6;
        if (valb >= 0) {
            out.push_back(char((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return out;
}
id<MTLTexture> LoadTextureFromBase64(id<MTLDevice> device, const std::string& base64) {

    std::vector<unsigned char> decodedData = Base64Decode(base64);


    int width, height, channels;
    unsigned char* imageData = stbi_load_from_memory(decodedData.data(), decodedData.size(), &width, &height, &channels, 4);
    if (!imageData) {
        NSLog(@"[Error] Failed to load image from Base64");
        return nil;
    }


    MTLTextureDescriptor* descriptor = [[MTLTextureDescriptor alloc] init];
    descriptor.pixelFormat = MTLPixelFormatRGBA8Unorm;
    descriptor.width = width;
    descriptor.height = height;
    descriptor.usage = MTLTextureUsageShaderRead;


    id<MTLTexture> texture = [device newTextureWithDescriptor:descriptor];
    if (texture) {

        MTLRegion region = {{0, 0, 0}, {static_cast<NSUInteger>(width), static_cast<NSUInteger>(height), 1}};
        [texture replaceRegion:region mipmapLevel:0 withBytes:imageData bytesPerRow:width * 4];
    } else {
        NSLog(@"[Error] Failed to create texture");
    }


    stbi_image_free(imageData);

    return texture;
}

const ImVec4 neonPink = ImVec4(1.00f, 0.00f, 0.50f, 1.00f);
const ImVec4 neonCyan = ImVec4(0.00f, 1.00f, 1.00f, 1.00f);
const ImVec4 neonGreen = ImVec4(0.00f, 1.00f, 0.30f, 1.00f);
const ImVec4 neonBlue = ImVec4(0.20f, 0.50f, 1.00f, 1.00f);
const ImVec4 darkBackground = ImVec4(0.05f, 0.05f, 0.08f, 0.98f);
const ImVec4 midBackground = ImVec4(0.10f, 0.10f, 0.15f, 0.98f);
const ImVec4 lightBackground = ImVec4(0.15f, 0.15f, 0.20f, 1.00f);
const ImVec4 greyText = ImVec4(0.60f, 0.60f, 0.65f, 1.00f);
const ImVec4 whiteText = ImVec4(0.95f, 0.95f, 1.00f, 1.00f);
const ImVec4 brightAccent = neonCyan;
const ImVec4 secondaryAccent = neonPink;

namespace BrandTheme {
    const ImVec4 BackgroundDark = ImVec4(0.08f, 0.09f, 0.11f, 0.98f);
    const ImVec4 BackgroundMedium = ImVec4(0.12f, 0.13f, 0.16f, 0.98f); 
    const ImVec4 BackgroundLight = ImVec4(0.16f, 0.17f, 0.20f, 1.00f);
    const ImVec4 FrameBg = ImVec4(0.10f, 0.11f, 0.13f, 1.00f);   
    const ImVec4 FrameBgHovered = ImVec4(0.14f, 0.15f, 0.18f, 1.00f); 
    const ImVec4 FrameBgActive = ImVec4(0.18f, 0.19f, 0.22f, 1.00f); 
    const ImVec4 TitleBg = BackgroundDark;                           
    const ImVec4 TitleBgActive = ImVec4(0.0f, 0.45f, 0.48f, 1.00f);   
    const ImVec4 TitleBgCollapsed = BackgroundDark;
    const ImVec4 AccentColor = ImVec4(0.0f, 0.55f, 0.60f, 1.00f);    
    const ImVec4 AccentHover = ImVec4(0.0f, 0.65f, 0.70f, 1.00f);   
    const ImVec4 AccentActive = ImVec4(0.0f, 0.75f, 0.80f, 1.00f);     
    const ImVec4 SecondaryAccent = ImVec4(0.85f, 0.35f, 0.20f, 1.00f);
    const ImVec4 SecondaryHover = ImVec4(0.90f, 0.40f, 0.25f, 1.00f);
    const ImVec4 SecondaryActive = ImVec4(0.95f, 0.45f, 0.30f, 1.00f);
    const ImVec4 TextPrimary = ImVec4(0.90f, 0.91f, 0.92f, 1.00f);  
    const ImVec4 TextSecondary = ImVec4(0.65f, 0.66f, 0.68f, 1.00f);  
    const ImVec4 TextDisabled = ImVec4(0.45f, 0.46f, 0.48f, 1.00f); 
    const ImVec4 TextHeader = AccentColor; 
    const float BaseRounding = 8.0f;        
    const float FrameRounding = 6.0f;
    const float GrabRounding = 4.0f;
    const float WindowBorderSize = 0.0f;    
    const float FrameBorderSize = 1.0f;    
    const ImVec2 ItemSpacing = ImVec2(8, 6);   
    const ImVec2 ItemInnerSpacing = ImVec2(6, 6);
    const float ScrollbarSize = 12.0f;
    const float GrabMinSize = 12.0f;
}

void CustomTextNeon(const char* label) {
    ImGui::PushStyleColor(ImGuiCol_Text, neonGreen);
    ImGui::Text(label);
    ImGui::PopStyleColor(1);
}

void StyleImGui(){
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    colors[ImGuiCol_Text] = BrandTheme::TextPrimary;
    colors[ImGuiCol_TextDisabled] = BrandTheme::TextDisabled;
    colors[ImGuiCol_WindowBg] = BrandTheme::BackgroundDark;
    colors[ImGuiCol_ChildBg] = ImVec4(0,0,0,0); 
    colors[ImGuiCol_PopupBg] = BrandTheme::BackgroundMedium;
    colors[ImGuiCol_Border] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_FrameBg] = BrandTheme::FrameBg;
    colors[ImGuiCol_FrameBgHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_FrameBgActive] = BrandTheme::FrameBgActive;
    colors[ImGuiCol_TitleBg] = BrandTheme::TitleBg;
    colors[ImGuiCol_TitleBgActive] = BrandTheme::TitleBgActive;
    colors[ImGuiCol_TitleBgCollapsed] = BrandTheme::TitleBgCollapsed;
    colors[ImGuiCol_MenuBarBg] = BrandTheme::BackgroundMedium;
    colors[ImGuiCol_ScrollbarBg] = BrandTheme::BackgroundDark;
    colors[ImGuiCol_ScrollbarGrab] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_ScrollbarGrabHovered] = BrandTheme::FrameBgActive;
    colors[ImGuiCol_ScrollbarGrabActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_CheckMark] = BrandTheme::AccentColor;
    colors[ImGuiCol_SliderGrab] = BrandTheme::AccentColor;
    colors[ImGuiCol_SliderGrabActive] = BrandTheme::AccentActive;
    colors[ImGuiCol_Button] = BrandTheme::AccentColor; 
    colors[ImGuiCol_ButtonHovered] = BrandTheme::AccentHover;
    colors[ImGuiCol_ButtonActive] = BrandTheme::AccentActive;
    colors[ImGuiCol_Header] = BrandTheme::FrameBg;
    colors[ImGuiCol_HeaderHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_HeaderActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_Separator] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_SeparatorHovered] = BrandTheme::AccentColor;
    colors[ImGuiCol_SeparatorActive] = BrandTheme::AccentActive;
    colors[ImGuiCol_ResizeGrip] = BrandTheme::FrameBg;
    colors[ImGuiCol_ResizeGripHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_ResizeGripActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_Tab] = BrandTheme::FrameBg;
    colors[ImGuiCol_TabHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_TabActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_TabUnfocused] = BrandTheme::FrameBg;
    colors[ImGuiCol_TabUnfocusedActive] = BrandTheme::FrameBgHovered; 
    colors[ImGuiCol_PlotLines] = BrandTheme::AccentColor;
    colors[ImGuiCol_PlotLinesHovered] = BrandTheme::AccentHover;
    colors[ImGuiCol_PlotHistogram] = BrandTheme::AccentColor;
    colors[ImGuiCol_PlotHistogramHovered] = BrandTheme::AccentHover;
    colors[ImGuiCol_TableHeaderBg] = BrandTheme::FrameBg;
    colors[ImGuiCol_TableBorderStrong] = BrandTheme::BackgroundLight; 
    colors[ImGuiCol_TableBorderLight] = BrandTheme::FrameBgHovered;  
    colors[ImGuiCol_TableRowBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f); 
    colors[ImGuiCol_TableRowBgAlt] = ImVec4(1.00f, 1.00f, 1.00f, 0.04f);
    colors[ImGuiCol_TextSelectedBg] = ImVec4(BrandTheme::AccentColor.x, BrandTheme::AccentColor.y, BrandTheme::AccentColor.z, 0.35f);
    colors[ImGuiCol_DragDropTarget] = ImVec4(BrandTheme::AccentColor.x, BrandTheme::AccentColor.y, BrandTheme::AccentColor.z, 0.90f);
    colors[ImGuiCol_NavHighlight] = BrandTheme::AccentColor; 
    colors[ImGuiCol_NavWindowingHighlight] = ImVec4(BrandTheme::AccentColor.x, BrandTheme::AccentColor.y, BrandTheme::AccentColor.z, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.20f, 0.20f, 0.20f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg] = ImVec4(BrandTheme::BackgroundDark.x, BrandTheme::BackgroundDark.y, BrandTheme::BackgroundDark.z, 0.6f);

    style.WindowRounding = BrandTheme::BaseRounding;
    style.FrameRounding = BrandTheme::FrameRounding;
    style.PopupRounding = BrandTheme::FrameRounding; 
    style.ScrollbarRounding = BrandTheme::FrameRounding;
    style.GrabRounding = BrandTheme::GrabRounding;
    style.TabRounding = BrandTheme::FrameRounding; 
    style.ChildRounding = BrandTheme::BaseRounding * 0.5f; 

    style.WindowBorderSize = BrandTheme::WindowBorderSize;
    style.FrameBorderSize = BrandTheme::FrameBorderSize;
    style.PopupBorderSize = BrandTheme::FrameBorderSize; 
    style.ChildBorderSize = 0.0f;
    style.ScrollbarSize = BrandTheme::ScrollbarSize;
    style.GrabMinSize = BrandTheme::GrabMinSize;
    style.Alpha = 1.0f;
}
void CustomText(const char* label) {


     ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.13f, 0.75f, 0.55f, 1.00f));

    ImGui::Text(label);
    ImGui::PopStyleColor(1);
}


bool CustomTextInput(const char* label, std::string& text, bool integerOnly, UIView* parentView)
{
    static std::unordered_map<std::string, UITextField*> fieldMap;
    std::string textInputID = std::string(label);

    static std::unordered_map<std::string, std::string> lastValueMap;
    if (lastValueMap[textInputID] != text) {
        lastValueMap[textInputID] = text;
    }

    ImGui::Text("%s", label);
    ImGui::SameLine();

    ImVec2 posPx = ImGui::GetCursorScreenPos();
    ImVec2 sizePx = ImVec2(150, ImGui::GetTextLineHeightWithSpacing());

    ImGui::SetItemAllowOverlap();
    ImGui::InvisibleButton(textInputID.c_str(), sizePx);
    bool active = ImGui::IsItemActive();
    bool clicked = ImGui::IsItemClicked();


    CGFloat scale = [UIScreen mainScreen].scale;
    CGRect frame = CGRectMake(posPx.x / scale, posPx.y / scale, sizePx.x / scale, sizePx.y / scale);

    if (fieldMap.find(textInputID) == fieldMap.end()) {
        UITextField* tf = [[UITextField alloc] initWithFrame:frame];
        tf.text = [NSString stringWithUTF8String:text.c_str()];
        tf.borderStyle = UITextBorderStyleRoundedRect;
        tf.keyboardType = integerOnly ? UIKeyboardTypeNumberPad : UIKeyboardTypeDefault;
        tf.autocorrectionType = UITextAutocorrectionTypeNo;
        tf.clearButtonMode = UITextFieldViewModeWhileEditing;
        tf.hidden = NO;
        [parentView addSubview:tf];
        fieldMap[textInputID] = tf;
    }

    UITextField* tf = fieldMap[textInputID];
    tf.frame = frame;


    if (clicked && ![tf isFirstResponder]) {
        [tf becomeFirstResponder];
    }

    if (!ImGui::IsItemHovered() && ImGui::IsMouseClicked(0) && [tf isFirstResponder]) {
        [tf resignFirstResponder];
    }

    NSString* currentText = tf.text ?: @"";
    std::string newText = [currentText UTF8String];


    if (integerOnly) {
        std::string filtered;
        for (char c : newText) {
            if (c >= '0' && c <= '9') filtered.push_back(c);
        }
        if (filtered != newText) {
            newText = filtered;
            tf.text = [NSString stringWithUTF8String:filtered.c_str()];
        }
    }

    if (newText != text) {
        text = newText;
        lastValueMap[textInputID] = newText;
        return true;
    }

    return false;
}
void TriggerHapticFeedback() {
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *generator = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [generator prepare];
        [generator impactOccurred];
    }
}

template <unsigned int N, char K>
struct XorString {
    char data[N];
    constexpr XorString(const char* str) : data{0} {
        for (unsigned int i = 0; i < N - 1; ++i) {
            data[i] = str[i] ^ K; 
        }
        data[N-1] = '\0';
    }
    
    char* decrypt() {
        for (unsigned int i = 0; i < N - 1; ++i) {
            data[i] ^= K;
        }
        return data;
    }
};

#define XOR_KEY (char)(__LINE__ % 255 + 1)
#define OBF_STR(str) [NSString stringWithUTF8String:XorString<sizeof(str), XOR_KEY>(str).decrypt()]

@interface SpeedHudView : UIView <UIGestureRecognizerDelegate>
@end

@implementation SpeedHudView {
    CGPoint _panStartCenter;
    BOOL _isDragging;
    UIPanGestureRecognizer *_pan;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;

    self.userInteractionEnabled = YES;
    self.exclusiveTouch = YES;

    _pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    _pan.delegate = self;
    _pan.maximumNumberOfTouches = 1;
    _pan.cancelsTouchesInView = YES; 
    [self addGestureRecognizer:_pan];

    return self;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    UIView *v = touch.view;
    while (v && v != self) {
        if ([v isKindOfClass:[UIControl class]]) return NO;
        v = v.superview;
    }
    return YES;
}

- (void)handlePan:(UIPanGestureRecognizer *)gr {
    UIView *sv = self.superview;
    if (!sv) return;

    if (gr.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
        _isDragging = YES;
    } else if (gr.state == UIGestureRecognizerStateChanged) {
        CGPoint t = [gr translationInView:sv];
        CGPoint newCenter = CGPointMake(_panStartCenter.x + t.x, _panStartCenter.y + t.y);
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        self.center = newCenter;
        [CATransaction commit];
    } else if (gr.state == UIGestureRecognizerStateEnded || gr.state == UIGestureRecognizerStateCancelled) {
        if (_isDragging) [self shouldResetFrame];
        _isDragging = NO;
    }
}

- (void)shouldResetFrame {
    CGFloat maxX = CGRectGetWidth(self.superview.frame);
    CGFloat maxY = CGRectGetHeight(self.superview.frame);
    CGRect frame = self.frame;

    if (CGRectGetMinX(frame) < 0) frame.origin.x = 0;
    else if (CGRectGetMaxX(frame) > maxX) frame.origin.x = maxX - CGRectGetWidth(frame);

    if (CGRectGetMinY(frame) < 0) frame.origin.y = 0;
    else if (CGRectGetMaxY(frame) > maxY) frame.origin.y = maxY - CGRectGetHeight(frame);

    [UIView animateWithDuration:0.20 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.frame = frame;
    } completion:nil];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}

@end

@interface HistoryHudView : UIView <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIView *titleBar;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIButton *clearButton;
@end

@implementation HistoryHudView {
    CGPoint _panStartCenter;
    CGRect _startFrame;
    UIView *_resizeHandle;
    UIPanGestureRecognizer *_movePanGesture;
}
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.85];
    self.layer.cornerRadius = 10.0;
    self.clipsToBounds = YES;
    self.layer.borderWidth = 1.0;
    self.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.2].CGColor;
    self.userInteractionEnabled = YES;
    self.exclusiveTouch = YES;
    _titleBar = [[UIView alloc] initWithFrame:CGRectZero];
    _titleBar.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    _titleBar.userInteractionEnabled = YES;
    [self addSubview:_titleBar];
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _titleLabel.text = OBF_STR("ONGNONG.io.vn");
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightBold];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.adjustsFontSizeToFitWidth = YES;
    _titleLabel.minimumScaleFactor = 0.8;
    [_titleBar addSubview:_titleLabel];
    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_closeButton setTitle:OBF_STR("X") forState:UIControlStateNormal];
    [_closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_titleBar addSubview:_closeButton];
    _clearButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_clearButton setTitle:OBF_STR("🗑️") forState:UIControlStateNormal];
    [_clearButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_titleBar addSubview:_clearButton];
    _resizeHandle = [[UIView alloc] initWithFrame:CGRectZero];
    _resizeHandle.userInteractionEnabled = YES;
    [self addSubview:_resizeHandle];
    CAShapeLayer *triangle = [CAShapeLayer layer];
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(20, 0)];
    [path addLineToPoint:CGPointMake(20, 20)];
    [path addLineToPoint:CGPointMake(0, 20)];
    [path closePath];
    triangle.path = path.CGPath;
    triangle.fillColor = [UIColor colorWithWhite:1.0 alpha:0.3].CGColor;
    [_resizeHandle.layer addSublayer:triangle];
    _movePanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleMove:)];
    _movePanGesture.delegate = self;
    _movePanGesture.cancelsTouchesInView = YES;
    [self addGestureRecognizer:_movePanGesture];
    UIPanGestureRecognizer *resizePan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleResize:)];
    resizePan.cancelsTouchesInView = YES;
    [_resizeHandle addGestureRecognizer:resizePan];
    UITapGestureRecognizer *doubleTapResize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleResizeDoubleTap:)];
    doubleTapResize.numberOfTapsRequired = 2;
    [_resizeHandle addGestureRecognizer:doubleTapResize];
    return self;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    return ![touch.view isKindOfClass:[UIControl class]];
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    CGFloat titleH = 22.0;
    _titleBar.frame = CGRectMake(0, 0, w, titleH);
    _clearButton.frame = CGRectMake(2, 0, 40, titleH);
    _closeButton.frame = CGRectMake(w - 42, 0, 40, titleH);
    _titleLabel.frame = CGRectMake(42, 0, MAX(0, w - 84), titleH);
    _resizeHandle.frame = CGRectMake(w - 30, h - 30, 30, 30);
    CALayer *resizeIconLayer = _resizeHandle.layer.sublayers.firstObject;
    resizeIconLayer.frame = CGRectMake(10, 10, 20, 20);
}
- (void)handleMove:(UIPanGestureRecognizer *)gr {
    UIView *sv = self.superview;
    if (!sv) return;
    if (gr.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
    } else if (gr.state == UIGestureRecognizerStateChanged) {
        CGPoint t = [gr translationInView:sv];
        CGPoint newCenter = CGPointMake(_panStartCenter.x + t.x, _panStartCenter.y + t.y);
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        self.center = newCenter;
        [CATransaction commit];
    }
}
- (void)handleResize:(UIPanGestureRecognizer *)gr {
    UIView *sv = self.superview;
    if (!sv) return;
    if (gr.state == UIGestureRecognizerStateBegan) {
        _startFrame = self.frame;
    } else if (gr.state == UIGestureRecognizerStateChanged) {
        CGPoint t = [gr translationInView:sv];
        CGFloat newW = MAX(190.0, _startFrame.size.width + t.x);
        CGFloat newH = MAX(100.0, _startFrame.size.height + t.y);
        if (self.frame.origin.x + newW > CGRectGetWidth(sv.frame)) newW = CGRectGetWidth(sv.frame) - self.frame.origin.x;
        if (self.frame.origin.y + newH > CGRectGetHeight(sv.frame)) newH = CGRectGetHeight(sv.frame) - self.frame.origin.y;
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        self.frame = CGRectMake(_startFrame.origin.x, _startFrame.origin.y, newW, newH);
        [self layoutIfNeeded];
        [CATransaction commit];
    }
}
- (void)handleResizeDoubleTap:(UITapGestureRecognizer *)gr {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ResetAllCounters" object:nil];
}
@end

@interface AutoSpinTargetHud : UIView <UITextFieldDelegate, UIGestureRecognizerDelegate>

@property (nonatomic, strong) UIView *expandedView;
@property (nonatomic, strong) UIButton *minimizeButton;
@property (nonatomic, strong) UIButton *closeButton; 
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *spinTextLabel;
@property (nonatomic, strong) UITextField *spinInputField;
@property (nonatomic, strong) UISwitch *autoSwitch;

@property (nonatomic, strong) UIView *collapsedView;
@property (nonatomic, strong) UIButton *expandButton;
@property (nonatomic, strong) UILabel *counterLabel;

@property (nonatomic, assign) NSInteger currentSpins;
@property (nonatomic, assign) NSInteger targetSpins;
@property (nonatomic, assign) BOOL isAutoSpinning;
@property (nonatomic, assign) BOOL isMinimized;

- (void)onSpinHappened;
- (void)onMainHudReset; 
@end

@implementation AutoSpinTargetHud {
    CGPoint _panStartCenter;
    UIPanGestureRecognizer *_movePanGesture;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, 220, 100)];
    if (!self) return nil;

    self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.85];
    self.layer.cornerRadius = 10.0;
    self.clipsToBounds = YES;
    self.layer.borderWidth = 1.0;
    self.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.2].CGColor;
    self.userInteractionEnabled = YES;
    self.exclusiveTouch = YES; 

    self.currentSpins = 0;
    self.targetSpins = 0;
    self.isAutoSpinning = NO;
    self.isMinimized = NO;

    UITapGestureRecognizer *tapBg = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self addGestureRecognizer:tapBg];

    _movePanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleMove:)];
    _movePanGesture.delegate = self;
    _movePanGesture.cancelsTouchesInView = YES; 
    [self addGestureRecognizer:_movePanGesture];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSpinHappened) name:OBF_STR("UpdateAutoSpinCount") object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onMainHudReset) name:OBF_STR("ResetAutoTargetCount") object:nil];

    [self setupExpandedView];
    [self setupCollapsedView];
    
    self.expandedView.hidden = NO;
    self.collapsedView.hidden = YES;

    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)setupExpandedView {
    self.expandedView = [[UIView alloc] initWithFrame:self.bounds];
    self.expandedView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self addSubview:self.expandedView];

    self.minimizeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.minimizeButton.frame = CGRectMake(5, 0, 30, 22);
    [self.minimizeButton setTitle:@"◀" forState:UIControlStateNormal];
    [self.minimizeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.minimizeButton addTarget:self action:@selector(minimizeTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.expandedView addSubview:self.minimizeButton];

    self.closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.closeButton.frame = CGRectMake(self.bounds.size.width - 35, 0, 30, 22);
    [self.closeButton setTitle:@"✕" forState:UIControlStateNormal];
    [self.closeButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    self.closeButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
    [self.closeButton addTarget:self action:@selector(closeHudAction) forControlEvents:UIControlEventTouchUpInside];
    [self.expandedView addSubview:self.closeButton];

    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, self.bounds.size.width - 80, 22)];
    self.titleLabel.text = OBF_STR("Auto Target");
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightBold];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.expandedView addSubview:self.titleLabel];

    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 22, self.bounds.size.width, 1)];
    line.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.2];
    [self.expandedView addSubview:line];

    self.spinTextLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 45, 100, 30)];
    self.spinTextLabel.text = OBF_STR("Nhập số vòng:");
    self.spinTextLabel.textColor = [UIColor yellowColor];
    self.spinTextLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    [self.expandedView addSubview:self.spinTextLabel];

    self.spinInputField = [[UITextField alloc] initWithFrame:CGRectMake(110, 45, 50, 30)];
    self.spinInputField.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.1];
    self.spinInputField.textColor = [UIColor whiteColor];
    self.spinInputField.font = [UIFont systemFontOfSize:14 weight:UIFontWeightBold];
    self.spinInputField.textAlignment = NSTextAlignmentCenter;
    self.spinInputField.keyboardType = UIKeyboardTypeNumberPad;
    self.spinInputField.layer.cornerRadius = 6;
    self.spinInputField.layer.borderWidth = 1;
    self.spinInputField.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.3].CGColor;
    self.spinInputField.delegate = self;
    [self.expandedView addSubview:self.spinInputField];

    self.autoSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(165, 45, 50, 30)];
    self.autoSwitch.transform = CGAffineTransformMakeScale(0.8, 0.8);
    [self.autoSwitch addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    [self.expandedView addSubview:self.autoSwitch];
}

- (void)setupCollapsedView {
    self.collapsedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 35)];
    [self addSubview:self.collapsedView];

    self.expandButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.expandButton.frame = CGRectMake(5, 5, 25, 25);
    [self.expandButton setTitle:@"▶" forState:UIControlStateNormal];
    [self.expandButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.expandButton addTarget:self action:@selector(expandTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.collapsedView addSubview:self.expandButton];

    self.counterLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 0, 70, 35)];
    self.counterLabel.text = @"0/0";
    self.counterLabel.textColor = [UIColor greenColor];
    self.counterLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightHeavy];
    self.counterLabel.textAlignment = NSTextAlignmentCenter;
    
    [self.collapsedView addSubview:self.counterLabel];
}

- (void)minimizeTapped {
    [self dismissKeyboard];
    self.isMinimized = YES;
    [UIView animateWithDuration:0.2 animations:^{
        self.expandedView.hidden = YES;
        self.collapsedView.hidden = NO;
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, 100, 35);
    }];
}

- (void)expandTapped {
    self.isMinimized = NO;
    [UIView animateWithDuration:0.2 animations:^{
        self.collapsedView.hidden = YES;
        self.expandedView.hidden = NO;
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, 220, 100);
    }];
}

- (void)closeHudAction {
    [self dismissKeyboard];
    [self.autoSwitch setOn:NO animated:YES]; 
    self.isAutoSpinning = NO;
    
    [UIView animateWithDuration:0.2 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        self.hidden = YES; 
        self.alpha = 1.0;
    }];
}

- (void)switchChanged:(UISwitch *)sender {
    [self dismissKeyboard];
    if (sender.isOn) {
        NSInteger target = [self.spinInputField.text integerValue];
        if (target <= 0) {
            [sender setOn:NO animated:YES];
            return;
        }
        self.targetSpins = target;
        self.currentSpins = 0; 
        self.isAutoSpinning = YES;
    } else {
        self.isAutoSpinning = NO;
    }
    [self updateDisplay];
}

- (void)onMainHudReset {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.currentSpins = 0;  
        [self updateDisplay];
    });
}

- (void)onSpinHappened {
    if (!self.isAutoSpinning) return;

    self.currentSpins++;
    [self updateDisplay];

    if (self.currentSpins >= self.targetSpins) {
        self.isAutoSpinning = NO;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.autoSwitch setOn:NO animated:YES]; 
            
            Vars.disconnect = YES;
            [[NSUserDefaults standardUserDefaults] setBool:Vars.disconnect forKey:[NSString stringWithUTF8String:oxorany("pv_disconnect")]];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithUTF8String:oxorany("UpdateSpeedHud")] object:nil];
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:[NSString stringWithUTF8String:oxorany("Thông báo")] message:[NSString stringWithUTF8String:oxorany("DONE !")] preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:[NSString stringWithUTF8String:oxorany("Đóng")] style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                Vars.disconnect = NO;
                [[NSUserDefaults standardUserDefaults] setBool:Vars.disconnect forKey:[NSString stringWithUTF8String:oxorany("pv_disconnect")]];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithUTF8String:oxorany("UpdateSpeedHud")] object:nil];
            }];
            
            [alert addAction:cancelAction];
            
            UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
            if (rootVC.presentedViewController) {
                [rootVC.presentedViewController presentViewController:alert animated:YES completion:nil];
            } else {
                [rootVC presentViewController:alert animated:YES completion:nil];
            }
        });
    }
}


- (void)updateDisplay {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.counterLabel.text = [NSString stringWithFormat:@"%ld/%ld", (long)self.currentSpins, (long)self.targetSpins];
        if (self.currentSpins >= self.targetSpins && self.targetSpins > 0) {
            self.counterLabel.textColor = [UIColor redColor]; 
        } else {
            self.counterLabel.textColor = [UIColor greenColor];
        }
    });
}

- (void)dismissKeyboard { [self endEditing:YES]; }

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([touch.view isKindOfClass:[UIControl class]] || [touch.view isKindOfClass:[UITextField class]]) return NO;
    return YES;
}

- (void)handleMove:(UIPanGestureRecognizer *)gr {
    UIView *sv = self.superview;
    if (!sv) return;
    if (gr.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
    } else if (gr.state == UIGestureRecognizerStateChanged) {
        CGPoint t = [gr translationInView:sv];
        self.center = CGPointMake(_panStartCenter.x + t.x, _panStartCenter.y + t.y);
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {}

@end


@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) MTKTextureLoader *texLoader;
@property (nonatomic, strong) id<MTLTexture> avatarTex;
@property (nonatomic, strong) id<MTLTexture> bombIconTex;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@property (nonatomic) int activeTab;
@property (nonatomic) int targetTab;
@property (nonatomic) float tabAnimationProgress;
@property (nonatomic) float lastTabSwitchTime;
@property (nonatomic, assign) float currentFPS;

@property (nonatomic, strong) SpeedHudView *speedHudView;
@property (nonatomic, strong) UIButton *adminButton;
@property (nonatomic, strong) UIButton *skipButton;
@property (nonatomic, assign) BOOL skipMode;      
@property (nonatomic, assign) BOOL skipEnabled;   

@property (nonatomic, strong) UIView *titleBar;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIView *titleDivider;
@property (nonatomic, strong) UIButton *colorOpenButton;
@property (nonatomic, strong) UIButton *collapseButton;

@property (nonatomic, strong) UIView *colorHud;
@property (nonatomic, strong) UIView *colorHudTitleBar;
@property (nonatomic, strong) UILabel *colorHudTitleLabel;
@property (nonatomic, strong) UIView *colorHudDivider;
@property (nonatomic, strong) UIButton *colorHudCloseButton;
@property (nonatomic, strong) UISlider *colorR;
@property (nonatomic, strong) UISlider *colorG;
@property (nonatomic, strong) UISlider *colorB;
@property (nonatomic, strong) UISlider *colorA;
@property (nonatomic, strong) UIButton *colorResetButton;

@property (nonatomic, strong) UIButton *fpsToggleButton;
@property (nonatomic, assign) BOOL showFPS; 

@property (nonatomic, assign) BOOL hudCollapsed;

@property (nonatomic, strong) UIButton *wifiButton;
@property (nonatomic, strong) UILabel *counterLabel;
@property (nonatomic, strong) UILabel *targetLabel;
@property (nonatomic, strong) UIImageView *targetImageView;
@property (nonatomic, strong) UIButton *targetTapButton;
@property (nonatomic, strong) UIButton *startButton;

@property (nonatomic, strong) UISlider *speedSlider;
@property (nonatomic, strong) UILabel *speedValueLabel;

@property (nonatomic, strong) UIImageView *collapsedImageView;

@property (nonatomic, strong) UIButton *historyOpenButton;
@property (nonatomic, strong) HistoryHudView *historyHud;

@property (nonatomic, strong) UIButton *autoSpinOpenButton;
@property (nonatomic, strong) AutoSpinTargetHud *autoSpinHud;

@property (nonatomic, strong) UIButton *sliderToggleButton;

@property (nonatomic, assign) NSInteger bottomDisplayMode; 
@property (nonatomic, strong) UIView *mainHistoryContainer; 
@property (nonatomic, strong) UIImageView *mainHistoryIcon;
@property (nonatomic, strong) UIScrollView *mainHistoryScrollView;
@property (nonatomic, strong) UILabel *mainHistoryLabel;
@property (nonatomic, strong) NSArray<UIButton *> *speedPresetButtons;
@property (nonatomic, strong) NSMutableArray<NSNumber *> *speedPresetValues;

@property (nonatomic, strong) UIImage *connectImage;
@property (nonatomic, strong) UIImage *disconnectImage;
@property (nonatomic, strong) UIImage *startImage;
@property (nonatomic, strong) UIImage *pauseImage;
@property (nonatomic, strong) UIImage *attackImage;
@property (nonatomic, strong) UIImage *raidImage;
@property (nonatomic, strong) UIImage *spinImage;
@property (nonatomic, strong) UIImage *symbolImage;
@property (nonatomic, strong) UIImage *poinImage;

@property (nonatomic, strong) UIColor *defaultHudColor;
@property (nonatomic, strong) UIColor *currentHudColor;

@property (nonatomic, strong) UIButton *miniExpandButton;
@property (nonatomic, strong) NSString *adminLinkStr; 
@property (nonatomic, strong) NSString *alertTitleDefault;
@property (nonatomic, strong) NSString *updateMsgFormat;
@property (nonatomic, strong) NSString *btnUpdateNowText;
@property (nonatomic, strong) NSString *btnUpdateLaterText;
@property (nonatomic, strong) NSString *btnUnderstoodText;

@property (nonatomic, assign) BOOL isServerLoaded;
@property (nonatomic, assign) BOOL isMenuAllowedByServer;
@property (nonatomic, strong) NSString *serverVersion;
@property (nonatomic, strong) NSString *updateUrl;
@property (nonatomic, assign) BOOL isUpdateAvailable;

- (CGFloat)adminButtonWidth;
- (CGFloat)skipButtonWidth;
@end


UIView *view;
UIView* parentView = [UIApplication sharedApplication].keyWindow.rootViewController.view;

NSFileManager *fileManager1 = [NSFileManager defaultManager];
NSString *documentDir1 = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];

@implementation ImGuiDrawView

- (NSString *)stringFromHexString:(NSString *)hexString {
    if (!hexString || [hexString length] == 0) return @"";
    NSMutableData *data = [[NSMutableData alloc] initWithCapacity:[hexString length] / 2];
    for (NSInteger i = 0; i < [hexString length]; i += 2) {
        NSString *hexChar = [hexString substringWithRange:NSMakeRange(i, 2)];
        unsigned int value;
        [[NSScanner scannerWithString:hexChar] scanHexInt:&value];
        uint8_t byte = (uint8_t)value;
        [data appendBytes:&byte length:1];
    }
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

- (CGFloat)_pillWidthForButton:(UIButton *)btn
                      fallbackTitle:(NSString *)title
                       minWidth:(CGFloat)minW
                       maxWidth:(CGFloat)maxW
{
    if (!btn) {
        return [self _pillWidthForTitle:title minWidth:minW maxWidth:maxW];
    }

    if (!btn.titleLabel.font) {
        btn.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    }

    if (btn.currentTitle.length == 0 && title.length > 0) {
        [btn setTitle:title forState:UIControlStateNormal];
    }

    CGSize fit = [btn sizeThatFits:CGSizeMake(CGFLOAT_MAX, 24.0)];
    CGFloat w = ceil(fit.width) + 2.0;

    if (w < minW) w = minW;
    if (w > maxW) w = maxW;
    return w;
}

- (CGFloat)_pillWidthForTitle:(NSString *)t minWidth:(CGFloat)minW maxWidth:(CGFloat)maxW {
    if (t.length == 0) return minW;

    UIFont *font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    CGSize textSize = [t sizeWithAttributes:@{ NSFontAttributeName: font }];

    CGFloat padLR = 8.0;   
    CGFloat extra = 2.0;   
    CGFloat w = ceil(textSize.width) + padLR * 2.0 + extra;

    if (w < minW) w = minW;
    if (w > maxW) w = maxW;
    return w;
}

- (CGFloat)adminButtonWidth {
    return [self _pillWidthForButton:self.adminButton
                      fallbackTitle:[NSString stringWithUTF8String:oxorany("Admin")] 
                           minWidth:50.0
                           maxWidth:110.0];
}

- (CGFloat)skipButtonWidth {
    return [self _pillWidthForButton:self.skipButton
                      fallbackTitle:[NSString stringWithUTF8String:oxorany("Skip")] 
                           minWidth:50.0
                           maxWidth:110.0];
}

NSMutableDictionary *heroTextures;

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];
    _activeTab = 1;
    _targetTab = 1;
    _tabAnimationProgress = 1.0f;
    _lastTabSwitchTime = -1.0f;
    if (!_device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    StyleImGui();

    ImFontConfig config;
    ImFontConfig icons_config;
    config.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;
    static const ImWchar icons_ranges[] = {0xf000, 0xf3ff, 0};

    _espFont = io.Fonts->AddFontFromMemoryTTF(profont_data, profont_size, 38.0f, &config, io.Fonts->GetGlyphRangesVietnamese());
    _iconFont = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 25.0f, &icons_config, icons_ranges);
    _iconFont->FontSize = 5;

    verdana_smol = io.Fonts->AddFontFromMemoryTTF(verdana, sizeof verdana, 40, NULL, io.Fonts->GetGlyphRangesCyrillic());
    pixel_big = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 128, NULL, io.Fonts->GetGlyphRangesCyrillic());
    pixel_smol = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 10*2, NULL, io.Fonts->GetGlyphRangesCyrillic());
    semakin_font = io.Fonts->AddFontFromMemoryTTF((void*)semakin, sizeof semakin, 50, NULL, io.Fonts->GetGlyphRangesVietnamese());

    io.FontGlobalScale = 0.32f;
    ImGui_ImplMetal_Init(_device);

    _defaultHudColor = [UIColor colorWithWhite:0 alpha:0.85];
    _currentHudColor = _defaultHudColor;

    self.skipMode = NO;
    self.skipEnabled = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshSpeedHud) name:[self stringFromHexString:@"5570646174655370656564487564"] object:nil];

    return self;
}

+ (void)showChange:(BOOL)open { MenDeal = open; }
+ (BOOL)isMenuShowing { return MenDeal; }

- (MTKView *)mtkView { return (MTKView *)self.view; }

- (void)loadView {
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (UIImage *)createThumbImageWithSize:(CGFloat)size {
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(size, size), NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();

    CGContextSetFillColorWithColor(context, [UIColor whiteColor].CGColor);
    CGContextFillEllipseInRect(context, CGRectMake(0, 0, size, size));

    CGContextSetStrokeColorWithColor(context, [UIColor colorWithWhite:0.3 alpha:1.0].CGColor);
    CGContextSetLineWidth(context, 1.0);
    
    CGContextStrokeEllipseInRect(context, CGRectMake(0, 0, size, size));

    UIImage *thumbImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return thumbImage;
}

-(void)loadsetting {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];

    Vars.Enable     = [ud boolForKey:[NSString stringWithUTF8String:oxorany("pv_enable")]];
    Vars.history    = [ud boolForKey:[NSString stringWithUTF8String:oxorany("pv_history")]];
    StreamerMode    = [ud boolForKey:[NSString stringWithUTF8String:oxorany("pv_streamer_mode")]];
    Vars.target     = (int)[ud integerForKey:[NSString stringWithUTF8String:oxorany("pv_target")]];
    Vars.resetOnTarget = [ud boolForKey:[NSString stringWithUTF8String:oxorany("pv_reset_on_target")]];
    Vars.speed      = [ud floatForKey:[NSString stringWithUTF8String:oxorany("pv_speed")]];

    Vars.countAttack = (int)[ud integerForKey:[NSString stringWithUTF8String:oxorany("pv_count_atk")]];
    Vars.countRaid   = (int)[ud integerForKey:[NSString stringWithUTF8String:oxorany("pv_count_rd")]];
    Vars.countSymbol = (int)[ud integerForKey:[NSString stringWithUTF8String:oxorany("pv_count_sym")]];
    Vars.countSpin   = (int)[ud integerForKey:[NSString stringWithUTF8String:oxorany("pv_count_spn")]];
    Vars.countPoin   = (int)[ud integerForKey:[NSString stringWithUTF8String:oxorany("pv_count_poin")]];

    Vars.history  = YES;
    Vars.resetOnTarget = YES;
    Vars.Enable   = YES;
    Vars.speedEnabled = NO;
    [ud setBool:YES forKey:[NSString stringWithUTF8String:oxorany("pv_disconnect")]];
    [ud setBool:NO  forKey:[NSString stringWithUTF8String:oxorany("pv_speed_enabled")]];

    float r = [ud floatForKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_r")]];
    float g = [ud floatForKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_g")]];
    float b = [ud floatForKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_b")]];
    float a = [ud floatForKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_a")]];
    if (a > 0.0f) self.currentHudColor = [UIColor colorWithRed:r green:g blue:b alpha:a];
    else self.currentHudColor = self.defaultHudColor;

    self.skipEnabled = [ud boolForKey:[NSString stringWithUTF8String:oxorany("pv_skip_enabled")]];
    self.skipMode = NO; 
    Vars.SkipAttackRaid = self.skipEnabled;
    
    NSString *displayKey = [NSString stringWithUTF8String:oxorany("pv_bottom_display")];
    if ([ud objectForKey:displayKey] == nil) {
        self.bottomDisplayMode = 1;
    } else {
        self.bottomDisplayMode = [ud integerForKey:displayKey];
    }

    NSString *fpsKey = [NSString stringWithUTF8String:oxorany("pv_show_fps")];
    if ([ud objectForKey:fpsKey] == nil) {
        self.showFPS = YES;
    } else {
        self.showFPS = [ud boolForKey:fpsKey];
    }
    [[FPSDisplay shareFPSDisplay] setDisplayHidden:!self.showFPS];

    auto loadHist = [&](NSString* key, std::vector<int>& vec) {
        NSArray *arr = [ud objectForKey:key];
        if (arr) { vec.clear(); for(NSNumber *n in arr) vec.push_back([n intValue]); }
    };
    loadHist([NSString stringWithUTF8String:oxorany("pv_hist_atk")], Vars.historyAttack);
    loadHist([NSString stringWithUTF8String:oxorany("pv_hist_rd")], Vars.historyRaid);
    loadHist([NSString stringWithUTF8String:oxorany("pv_hist_sym")], Vars.historySymbol);
    loadHist([NSString stringWithUTF8String:oxorany("pv_hist_spn")], Vars.historySpin);
    loadHist([NSString stringWithUTF8String:oxorany("pv_hist_poin")], Vars.historyPoin);

    [ud synchronize];
}

-(void)saveSetting {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];

    [ud setBool:Vars.Enable forKey:[NSString stringWithUTF8String:oxorany("pv_enable")]];
    [ud setBool:Vars.history forKey:[NSString stringWithUTF8String:oxorany("pv_history")]];
    [ud setBool:StreamerMode forKey:[NSString stringWithUTF8String:oxorany("pv_streamer_mode")]];
    [ud setInteger:Vars.target forKey:[NSString stringWithUTF8String:oxorany("pv_target")]];
    [ud setBool:Vars.resetOnTarget forKey:[NSString stringWithUTF8String:oxorany("pv_reset_on_target")]];
    [ud setFloat:Vars.speed forKey:[NSString stringWithUTF8String:oxorany("pv_speed")]];
    [ud setBool:Vars.speedEnabled forKey:[NSString stringWithUTF8String:oxorany("pv_speed_enabled")]];

    [ud setInteger:Vars.countAttack forKey:[NSString stringWithUTF8String:oxorany("pv_count_atk")]];
    [ud setInteger:Vars.countRaid forKey:[NSString stringWithUTF8String:oxorany("pv_count_rd")]];
    [ud setInteger:Vars.countSymbol forKey:[NSString stringWithUTF8String:oxorany("pv_count_sym")]];
    [ud setInteger:Vars.countSpin forKey:[NSString stringWithUTF8String:oxorany("pv_count_spn")]];
    [ud setInteger:Vars.countPoin forKey:[NSString stringWithUTF8String:oxorany("pv_count_poin")]];

    [ud setBool:self.skipEnabled forKey:[NSString stringWithUTF8String:oxorany("pv_skip_enabled")]];
    Vars.SkipAttackRaid = self.skipEnabled;
    
    [ud setInteger:self.bottomDisplayMode forKey:[NSString stringWithUTF8String:oxorany("pv_bottom_display")]];
    [ud setBool:self.showFPS forKey:[NSString stringWithUTF8String:oxorany("pv_show_fps")]];

    CGFloat r=0,g=0,b=0,a=0;
    if ([self.currentHudColor getRed:&r green:&g blue:&b alpha:&a]) {
        [ud setFloat:r forKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_r")]];
        [ud setFloat:g forKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_g")]];
        [ud setFloat:b forKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_b")]];
        [ud setFloat:a forKey:[NSString stringWithUTF8String:oxorany("pv_hud_color_a")]];
    }

    auto saveHist = [&](NSString* key, const std::vector<int>& vec) {
        NSMutableArray *arr = [NSMutableArray array];
        for (int v : vec) [arr addObject:@(v)];
        [ud setObject:arr forKey:key];
    };
    saveHist([NSString stringWithUTF8String:oxorany("pv_hist_atk")], Vars.historyAttack);
    saveHist([NSString stringWithUTF8String:oxorany("pv_hist_rd")], Vars.historyRaid);
    saveHist([NSString stringWithUTF8String:oxorany("pv_hist_sym")], Vars.historySymbol);
    saveHist([NSString stringWithUTF8String:oxorany("pv_hist_spn")], Vars.historySpin);
    saveHist([NSString stringWithUTF8String:oxorany("pv_hist_poin")], Vars.historyPoin);

    [ud synchronize];
}

static UIImage *CMSWebPImage(NSData *data) {
    if (!data || data.length < 12) return nil;
    int width = 0, height = 0;
    if (!WebPGetInfo((const uint8_t *)data.bytes, data.length, &width, &height)) return nil;
    if (width <= 0 || height <= 0 || width > 8192 || height > 8192) return nil;
    uint8_t *rgba = WebPDecodeRGBA((const uint8_t *)data.bytes, data.length, &width, &height);
    if (!rgba) return nil;
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(rgba, width, height, 8, width * 4, space, kCGBitmapByteOrderDefault | kCGImageAlphaLast);
    CGImageRef cg = context ? CGBitmapContextCreateImage(context) : NULL;
    UIImage *result = cg ? [UIImage imageWithCGImage:cg scale:1 orientation:UIImageOrientationUp] : nil;
    if (cg) CGImageRelease(cg);
    if (context) CGContextRelease(context);
    CGColorSpaceRelease(space);
    WebPFree(rgba);
    return result;
}

- (UIImage *)imageFromBase64String:(NSString *)base64String {
    if (!base64String || base64String.length == 0) return nil;
    NSData *imageData = [[NSData alloc] initWithBase64EncodedString:base64String options:NSDataBase64DecodingIgnoreUnknownCharacters];
    if (!imageData) return nil;
    UIImage *image = CMSWebPImage(imageData);
    if (!image) return nil;
    return [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

- (void)loadHudImages {
    self.connectImage = [self imageFromBase64String:kConnectImageBase64];
    self.disconnectImage = [self imageFromBase64String:kDisconnectImageBase64];
    self.startImage = [self imageFromBase64String:kStartImageBase64];
    self.pauseImage = [self imageFromBase64String:kPauseImageBase64];
    self.attackImage = [self imageFromBase64String:kAttackImageBase64];
    self.raidImage = [self imageFromBase64String:kRaidImageBase64];
    self.spinImage = [self imageFromBase64String:kSpinImageBase64];
    self.symbolImage = [self imageFromBase64String:kSymbolImageBase64];
    self.poinImage = [self imageFromBase64String:kPotionImageBase64];
}

- (void)animateHudCollapsed:(BOOL)collapsed {
    if (!self.speedHudView) return;

    self.speedHudView.userInteractionEnabled = NO;

    self.hudCollapsed = collapsed;

    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    [self layoutSpeedHud];
    [CATransaction commit];

    [UIView animateWithDuration:0.22
                          delay:0
         usingSpringWithDamping:0.88
          initialSpringVelocity:0.0
                        options:UIViewAnimationOptionBeginFromCurrentState |
                                UIViewAnimationOptionAllowUserInteraction |
                                UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        [self layoutSpeedHud];
    } completion:^(BOOL finished) {
        self.speedHudView.userInteractionEnabled = YES;
    }];
}

- (void)showToastMessage:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *targetView = self.speedHudView.superview;
        if (!targetView) targetView = self.view;
        if (!targetView) targetView = [UIApplication sharedApplication].keyWindow.rootViewController.view;
        if (!targetView) return;
        
        UILabel *toastLabel = [[UILabel alloc] init];
        toastLabel.text = message;
        toastLabel.textColor = [UIColor whiteColor];
        toastLabel.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.85];
        toastLabel.textAlignment = NSTextAlignmentCenter;
        toastLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightBold];
        toastLabel.layer.cornerRadius = 12.0;
        toastLabel.clipsToBounds = YES;
        toastLabel.numberOfLines = 0;
        
        CGSize textSize = [toastLabel sizeThatFits:CGSizeMake(targetView.bounds.size.width - 60, CGFLOAT_MAX)];
        CGFloat labelWidth = MIN(textSize.width + 40, targetView.bounds.size.width - 40);
        CGFloat labelHeight = textSize.height + 20;
        
        CGFloat yPosition = targetView.bounds.size.height * 0.75;
        
        toastLabel.frame = CGRectMake((targetView.bounds.size.width - labelWidth) / 2,
                                      yPosition, 
                                      labelWidth,
                                      labelHeight);
        
        toastLabel.alpha = 0.0;
        [targetView addSubview:toastLabel];
        [targetView bringSubviewToFront:toastLabel];
        
        if (@available(iOS 10.0, *)) {
            UINotificationFeedbackGenerator *gen = [[UINotificationFeedbackGenerator alloc] init];
            [gen notificationOccurred:UINotificationFeedbackTypeSuccess];
        }
        
        [UIView animateWithDuration:0.5 animations:^{
            toastLabel.alpha = 1.0;
        } completion:^(BOOL finished) {
         
            [UIView animateWithDuration:0.5 delay:8.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                toastLabel.alpha = 0.0;
            } completion:^(BOOL finished) {
                [toastLabel removeFromSuperview];
            }];
        }];
    });
}
- (void)fetchServerConfig {
    self.isServerLoaded = YES;
    self.isMenuAllowedByServer = YES;
    [self refreshSpeedHud];
}

- (void)applyConfig:(NSDictionary *)json isFromServer:(BOOL)fromServer {
    self.isServerLoaded = YES; 
    self.isMenuAllowedByServer = YES;

    NSString *statusValue = json[[NSString stringWithUTF8String:oxorany("status")]];
    if ([statusValue isKindOfClass:[NSString class]]) {
        if ([statusValue isEqualToString:[NSString stringWithUTF8String:oxorany("hide")]]) {
            self.isMenuAllowedByServer = YES;
            Vars.Enable = NO;
            [self showToastMessage:[NSString stringWithUTF8String:oxorany("Menu đang bị TẮT từ sever")]];
        } 
        else if ([statusValue isEqualToString:[NSString stringWithUTF8String:oxorany("show")]]) {
            self.isMenuAllowedByServer = YES;
            Vars.Enable = YES;
            if (fromServer) [self showToastMessage:[NSString stringWithUTF8String:oxorany("Speed Free By Hoàng Hải")]];
        } else {
            self.isMenuAllowedByServer = YES;
            Vars.Enable = YES;
        }
    } else {
        self.isMenuAllowedByServer = YES;
        Vars.Enable = YES;
    }

    NSString *menuName = json[[NSString stringWithUTF8String:oxorany("menu_name")]];
    if ([menuName isKindOfClass:[NSString class]] && menuName.length > 0) self.titleLabel.text = menuName;

    NSString *historyName = json[[NSString stringWithUTF8String:oxorany("history_name")]];
    if ([historyName isKindOfClass:[NSString class]] && historyName.length > 0 && self.historyHud) self.historyHud.titleLabel.text = historyName;

    NSString *autoName = json[[NSString stringWithUTF8String:oxorany("auto_name")]];
    if ([autoName isKindOfClass:[NSString class]] && autoName.length > 0 && self.autoSpinHud) self.autoSpinHud.titleLabel.text = autoName;
    
    NSString *serverVer = json[[NSString stringWithUTF8String:oxorany("version")]]; 
    NSString *updateLink = json[[NSString stringWithUTF8String:oxorany("update_url")]]; 
    if ([serverVer isKindOfClass:[NSString class]]) {
        self.serverVersion = serverVer;
        if (![self.serverVersion isEqualToString:[NSString stringWithUTF8String:oxorany("3.5.2510")]]) {
            self.isUpdateAvailable = YES;
            if ([updateLink isKindOfClass:[NSString class]]) self.updateUrl = updateLink;
            if (fromServer) [self showUpdateAlert];
        } else {
            self.isUpdateAvailable = NO;
        }
    }

    if (fromServer) {
        NSString *announcementMsg = json[[NSString stringWithUTF8String:oxorany("announcement")]];
        NSString *announcementId = json[[NSString stringWithUTF8String:oxorany("announcement_id")]];
        if ([announcementMsg isKindOfClass:[NSString class]] && announcementMsg.length > 0 &&
            [announcementId isKindOfClass:[NSString class]] && announcementId.length > 0) {
            
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            NSString *lastSeenKey = [NSString stringWithUTF8String:oxorany("pv_last_announcement_id")];
            if (![announcementId isEqualToString:[ud stringForKey:lastSeenKey]]) {
                [self showAnnouncementAlert:announcementMsg]; 
                [ud setObject:announcementId forKey:lastSeenKey];
                [ud synchronize];
            }
        }
    }

    NSString *jAlertTitle = json[[NSString stringWithUTF8String:oxorany("alert_title")]];
    if ([jAlertTitle isKindOfClass:[NSString class]] && jAlertTitle.length > 0) self.alertTitleDefault = jAlertTitle;

    NSString *jUpdateMsg = json[[NSString stringWithUTF8String:oxorany("update_msg")]];
    if ([jUpdateMsg isKindOfClass:[NSString class]] && jUpdateMsg.length > 0) self.updateMsgFormat = jUpdateMsg;

    NSString *jBtnUpdNow = json[[NSString stringWithUTF8String:oxorany("btn_update_now")]];
    if ([jBtnUpdNow isKindOfClass:[NSString class]] && jBtnUpdNow.length > 0) self.btnUpdateNowText = jBtnUpdNow;

    NSString *jBtnUpdLater = json[[NSString stringWithUTF8String:oxorany("btn_update_later")]];
    if ([jBtnUpdLater isKindOfClass:[NSString class]] && jBtnUpdLater.length > 0) self.btnUpdateLaterText = jBtnUpdLater;

    NSString *jBtnUnderstood = json[[NSString stringWithUTF8String:oxorany("btn_understood")]];
    if ([jBtnUnderstood isKindOfClass:[NSString class]] && jBtnUnderstood.length > 0) self.btnUnderstoodText = jBtnUnderstood;

    [self saveSetting];
    [self refreshSpeedHud]; 
    
    if (!self.isMenuAllowedByServer) {
        if (self.historyHud) self.historyHud.hidden = YES;
        if (self.autoSpinHud) self.autoSpinHud.hidden = YES;
    }
}

- (void)showUpdateAlert {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *title = self.alertTitleDefault ?: [NSString stringWithUTF8String:oxorany("Thông Báo Từ Mr Khói")];
        NSString *format = self.updateMsgFormat ?: [NSString stringWithUTF8String:oxorany("Đã có phiên bản mới (v%@). Vui lòng cập nhật để trải nghiệm tốt nhất.")];
        NSString *msg = [NSString stringWithFormat:format, self.serverVersion];
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];

        NSString *updBtnText = self.btnUpdateNowText ?: [NSString stringWithUTF8String:oxorany("Cập nhật ngay")];
        UIAlertAction *updateAction = [UIAlertAction actionWithTitle:updBtnText style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if (self.updateUrl) {
                NSURL *url = [NSURL URLWithString:self.updateUrl];
                if (@available(iOS 10.0, *)) {
                    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
                } else {
                    [[UIApplication sharedApplication] openURL:url];
                }
            }
        }];
        
        NSString *cancelBtnText = self.btnUpdateLaterText ?: [NSString stringWithUTF8String:oxorany("Để sau")];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelBtnText style:UIAlertActionStyleCancel handler:nil];

        [alert addAction:updateAction];
        [alert addAction:cancelAction];

        UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
        if (rootVC.presentedViewController) {
            [rootVC.presentedViewController presentViewController:alert animated:YES completion:nil];
        } else {
            [rootVC presentViewController:alert animated:YES completion:nil];
        }
    });
}

- (void)showAnnouncementAlert:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *title = self.alertTitleDefault ?: [NSString stringWithUTF8String:oxorany("Thông Báo Từ Mr Khói")];
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        
        NSString *okBtnText = self.btnUnderstoodText ?: [NSString stringWithUTF8String:oxorany("Đã hiểu")];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:okBtnText style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:okAction];
        
        UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
        if (rootVC.presentedViewController) {
            [rootVC.presentedViewController presentViewController:alert animated:YES completion:nil];
        } else {
            [rootVC presentViewController:alert animated:YES completion:nil];
        }
    });
}

- (void)handleAdminTap {
    NSString *adminLink = self.adminLinkStr ? self.adminLinkStr : [NSString stringWithUTF8String:oxorany("https://www.facebook.com/share/1CJfYgkpb1/?mibextid=wwXIfr")];
    NSURL *url = [NSURL URLWithString:adminLink];
    if (!url) return;

    UIApplication *app = [UIApplication sharedApplication];
    if (@available(iOS 10.0, *)) [app openURL:url options:@{} completionHandler:nil];
    else [app openURL:url];

    TriggerHapticFeedback();
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.isServerLoaded = YES;
    self.isMenuAllowedByServer = YES;
    
    self.mtkView.device = self.device;
    if (!self.mtkView.device) return;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    
    [self loadsetting];
    CheatHandle();
    
    [self setupSpeedHud];
    
    [self refreshSpeedHud];
}


#pragma mark - UI Helpers

- (void)applyHudColor:(UIColor *)c {
    self.currentHudColor = c ?: self.defaultHudColor;

    if (self.speedHudView) self.speedHudView.backgroundColor = self.currentHudColor;
    if (self.colorHud) self.colorHud.backgroundColor = self.currentHudColor;
    
    if (self.historyHud) self.historyHud.backgroundColor = self.currentHudColor;
    if (self.autoSpinHud) self.autoSpinHud.backgroundColor = self.currentHudColor;

    if (self.titleBar) self.titleBar.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];
    if (self.colorHudTitleBar) self.colorHudTitleBar.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];

    [self saveSetting];
}

- (void)presentColorHud:(BOOL)show {
    if (!self.colorHud || !self.speedHudView) return;

    self.colorHud.hidden = !show;
    if (show) {
        [self.speedHudView bringSubviewToFront:self.colorHud];
    }
}

- (void)updateSkipButtonStyle {
    if (!self.skipButton) return;

    if (self.skipEnabled) {
        self.skipButton.backgroundColor = [UIColor colorWithRed:0.10 green:0.72 blue:0.25 alpha:1.0];
        [self.skipButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    } else {
        self.skipButton.backgroundColor = [UIColor yellowColor];
        [self.skipButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
}

#pragma mark - Layout

- (void)layoutExpanded {
    if (!self.speedHudView) return;

    self.collapsedImageView.hidden = YES;
    self.speedHudView.layer.cornerRadius = 16.0;
    self.speedHudView.backgroundColor = self.currentHudColor;

    self.counterLabel.backgroundColor = [UIColor clearColor];
    self.counterLabel.textColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:1.0];
    self.counterLabel.font = [UIFont systemFontOfSize:30.0 weight:UIFontWeightSemibold];
    self.counterLabel.layer.cornerRadius = 0;

    CGFloat titleH = 22.0;
    CGFloat divH   = 1.0;
    CGFloat gap    = 4.0;

    CGFloat row2H = 35.0, row2LR = 7.0;
    CGFloat row3H = 25.0, row3LR = 10.0;
    CGFloat row4H = 25.0, row4LR = 5.0;

    CGFloat row2Y = titleH + divH + gap;
    CGFloat row3Y = row2Y + row2H + gap;
    CGFloat row4Y = row3Y + row3H + gap;
    
    CGFloat bottomAreaH = 0;
    if (self.bottomDisplayMode == 1) bottomAreaH = 20.0;
    else if (self.bottomDisplayMode == 2) bottomAreaH = 25.0; 

    CGFloat bottomInset = 2.0;
    CGFloat hudH = row4Y + row4H + (bottomAreaH > 0 ? bottomAreaH + 8.0 : 4.0) + bottomInset;

    UIView *root = self.speedHudView.superview ?: [UIApplication sharedApplication].keyWindow.rootViewController.view;
    CGFloat minW = 250.0;

    CGFloat (^Clamp)(CGFloat v, CGFloat lo, CGFloat hi) = ^CGFloat(CGFloat v, CGFloat lo, CGFloat hi) {
        return MIN(hi, MAX(lo, v));
    };

    CGFloat (^AutoPillWidth)(UIButton *btn, NSString *title) = ^CGFloat(UIButton *btn, NSString *title) {
        if (!btn) return 0;
        UIFont *f = btn.titleLabel.font ?: [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
        UIEdgeInsets inset = btn.contentEdgeInsets;
        if (UIEdgeInsetsEqualToEdgeInsets(inset, UIEdgeInsetsZero)) inset = UIEdgeInsetsMake(0, 8, 0, 8);

        CGSize t = [title sizeWithAttributes:@{ NSFontAttributeName: f }];
        CGFloat w = ceil(t.width) + inset.left + inset.right;
        return Clamp(w, 44.0, 120.0);
    };

    void (^LayoutEvenlyMinGap)(NSArray<UIView *> *views, CGFloat yRow, CGFloat hRow, CGFloat left, CGFloat right, CGFloat minGap) =
    ^(NSArray<UIView *> *views, CGFloat yRow, CGFloat hRow, CGFloat left, CGFloat right, CGFloat minGap) {
        if (views.count == 0) return;

        CGFloat w = CGRectGetWidth(self.speedHudView.bounds);
        CGFloat available = w - left - right;

        CGFloat totalW = 0;
        for (UIView *v in views) totalW += CGRectGetWidth(v.frame);

        NSInteger gaps = MAX((NSInteger)views.count - 1, 1);
        CGFloat gapX = (available - totalW) / (CGFloat)gaps;
        gapX = MAX(minGap, floor(gapX));

        if (totalW + gapX*(CGFloat)gaps > available) gapX = minGap;

        CGFloat cx = left;
        for (UIView *v in views) {
            CGRect f = v.frame;
            f.origin.x = cx;
            f.origin.y = yRow + floor((hRow - f.size.height) * 0.5);
            v.frame = f;
            cx += f.size.width + gapX;
        }
    };

    CGFloat counterW = 60.0;
    if (self.counterLabel.text.length > 0) {
        CGSize s = [self.counterLabel sizeThatFits:CGSizeMake(CGFLOAT_MAX, row2H)];
        counterW = MAX(60.0, ceil(s.width) + 8.0);
    }

    if (self.speedValueLabel) {
        self.speedValueLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
        self.speedValueLabel.textAlignment = NSTextAlignmentCenter;
    }

    CGFloat speedW = 40.0;
    if (self.speedValueLabel.text.length > 0) {
        CGSize s = [self.speedValueLabel sizeThatFits:CGSizeMake(CGFLOAT_MAX, row3H)];
        speedW = Clamp(ceil(s.width) + 10.0, 34.0, 70.0);
    }

    CGFloat iconSize = 32.0;

    CGFloat adminW = AutoPillWidth(self.adminButton, [self stringFromHexString:@"41646d696e"]); 
    CGFloat skipW  = AutoPillWidth(self.skipButton,  [self stringFromHexString:@"536b6970"]); 
    CGFloat midW   = self.skipMode ? skipW : adminW;

    CGFloat btnMinW = 30.0;
    CGFloat row2Required = row2LR + row2LR + iconSize + midW + counterW + iconSize + iconSize + 4*4;
    CGFloat row3Required = row3LR + row3LR + (btnMinW * 4) + speedW + 4*4;

    CGFloat targetW = MAX(minW, MAX(row2Required, row3Required));
    CGFloat maxW = CGRectGetWidth(root.bounds) - 16.0;
    targetW = MIN(targetW, maxW);

    CGPoint oldCenter = self.speedHudView.center;
    self.speedHudView.frame = (CGRect){ self.speedHudView.frame.origin, CGSizeMake(targetW, hudH) };
    self.speedHudView.center = oldCenter;

    self.titleBar.hidden = NO;
    self.titleDivider.hidden = NO;
    self.titleBar.frame = CGRectMake(0, 0, targetW, titleH);
    self.titleDivider.frame = CGRectMake(0, titleH, targetW, divH);
    self.titleLabel.frame = CGRectMake(0, 0, targetW, titleH);

    self.colorOpenButton.frame = CGRectMake(7, 0, 30.0, titleH);
    self.collapseButton.hidden = NO;
    self.collapseButton.frame = CGRectMake(targetW - 7 - 30.0, 0, 30.0, titleH);

    self.wifiButton.hidden = NO;
    self.startButton.hidden = NO;
    self.targetTapButton.hidden = NO;

    self.wifiButton.frame = (CGRect){CGPointZero, CGSizeMake(iconSize, iconSize)};

    self.counterLabel.frame = (CGRect){CGPointZero, CGSizeMake(counterW, row2H)};
    self.targetImageView.frame = (CGRect){CGPointZero, CGSizeMake(iconSize, iconSize)};
    self.startButton.frame = (CGRect){CGPointZero, CGSizeMake(iconSize, iconSize)};

    self.adminButton.frame = (CGRect){CGPointZero, CGSizeMake(adminW, 24.0)};
    self.skipButton.frame  = (CGRect){CGPointZero, CGSizeMake(skipW,  24.0)};

    UIView *midBtn = self.skipMode ? (UIView *)self.skipButton : (UIView *)self.adminButton;

    CGFloat row2MinGap = Clamp(floor(targetW * 0.02), 4.0, 10.0);

    LayoutEvenlyMinGap(@[self.wifiButton, midBtn, self.counterLabel, self.targetImageView, self.startButton],
                       row2Y, row2H, row2LR, row2LR, row2MinGap);

    self.targetLabel.frame = self.targetImageView.frame;
    self.targetTapButton.frame = self.targetImageView.frame;

    if (self.speedPresetButtons.count == 4) {

        CGFloat w = CGRectGetWidth(self.speedHudView.bounds);
        CGFloat left = row3LR;
        CGFloat right = row3LR;

        CGFloat speedX = floor(w*0.5 - speedW*0.5);
        self.speedValueLabel.frame = CGRectMake(speedX, row3Y, speedW, row3H);
        self.speedValueLabel.hidden = NO;

        CGFloat available = w - left - right;
        CGFloat freeForButtons = MAX(0.0, available - speedW);

        CGFloat minGap = Clamp(floor(targetW * 0.015), 3.0, 8.0);

        CGFloat gapX = minGap;
        CGFloat btnW = floor((freeForButtons - 4.0*gapX) / 4.0);
        btnW = Clamp(btnW, 30.0, 62.0);

        if (btnW*4.0 + gapX*4.0 > freeForButtons) {
            gapX = floor((freeForButtons - btnW*4.0) / 4.0);
            if (gapX < minGap) gapX = minGap;
        }

        for (UIButton *b in self.speedPresetButtons) {
            b.hidden = NO;
            b.frame = CGRectMake(0, 0, btnW, row3H);
        }

        CGFloat xL = left;
        self.speedPresetButtons[0].frame = CGRectMake(xL, row3Y, btnW, row3H);
        xL += btnW + gapX;
        self.speedPresetButtons[1].frame = CGRectMake(xL, row3Y, btnW, row3H);

        CGFloat xR = CGRectGetMaxX(self.speedValueLabel.frame) + gapX;
        self.speedPresetButtons[2].frame = CGRectMake(xR, row3Y, btnW, row3H);
        xR += btnW + gapX;
        self.speedPresetButtons[3].frame = CGRectMake(xR, row3Y, btnW, row3H);
    }

    if (self.historyOpenButton) {
        self.historyOpenButton.hidden = NO;
        self.autoSpinOpenButton.hidden = NO;
        self.sliderToggleButton.hidden = NO;

        CGFloat gapBtns = 5.0;
        CGFloat thirdW = (targetW - 2*row4LR - gapBtns*2) / 3.0; 

        self.historyOpenButton.frame = CGRectMake(row4LR, row4Y, thirdW, row4H);
        self.autoSpinOpenButton.frame = CGRectMake(CGRectGetMaxX(self.historyOpenButton.frame) + gapBtns, row4Y, thirdW, row4H);
        self.sliderToggleButton.frame = CGRectMake(CGRectGetMaxX(self.autoSpinOpenButton.frame) + gapBtns, row4Y, thirdW, row4H);
    }

    CGFloat bottomAreaY = row4Y + row4H + 6.0;
    if (self.bottomDisplayMode == 1) {
        self.speedSlider.hidden = NO;
        self.mainHistoryContainer.hidden = YES;
        self.speedSlider.frame = CGRectMake(row4LR, bottomAreaY, targetW - 2*row4LR, bottomAreaH);
    } else if (self.bottomDisplayMode == 2) {
        self.speedSlider.hidden = YES;
        self.mainHistoryContainer.hidden = NO;
        self.mainHistoryContainer.frame = CGRectMake(row4LR, bottomAreaY, targetW - 2*row4LR, bottomAreaH);
        
        CGFloat iconSize = 25.0;
        CGFloat gapH = 6.0; 
        self.mainHistoryIcon.frame = CGRectMake(0, 0, iconSize, iconSize);
        self.mainHistoryScrollView.frame = CGRectMake(iconSize + gapH, 0, targetW - 2*row4LR - iconSize - gapH, iconSize);
    } else {
        self.speedSlider.hidden = YES;
        self.mainHistoryContainer.hidden = YES;
    }

    if (self.colorHud) self.colorHud.frame = self.speedHudView.bounds;

    CGFloat cTitleH = 22.0;
    CGFloat cDivH   = 1.0;

    if (self.colorHudTitleBar) self.colorHudTitleBar.frame = CGRectMake(0, 0, targetW, cTitleH);
    if (self.colorHudDivider) self.colorHudDivider.frame = CGRectMake(0, cTitleH, targetW, cDivH);
    if (self.colorHudTitleLabel) self.colorHudTitleLabel.frame = CGRectMake(0, 0, targetW, cTitleH);
    if (self.colorHudCloseButton) self.colorHudCloseButton.frame = CGRectMake(targetW - 7 - 30.0, 0, 30.0, cTitleH);

    CGFloat resetH = 25.0;
    CGFloat bottomPad = 2.0;
    CGFloat side = 10.0;
    CGFloat gapX = 8.0;
    CGFloat halfW = (targetW - side*2 - gapX) / 2.0;

    self.colorResetButton.frame = CGRectMake(side,
                                             CGRectGetHeight(self.colorHud.bounds) - bottomPad - resetH,
                                             halfW,
                                             resetH);
                                             
    self.fpsToggleButton.frame = CGRectMake(side + halfW + gapX,
                                            CGRectGetHeight(self.colorHud.bounds) - bottomPad - resetH,
                                            halfW,
                                            resetH);

    CGFloat topY = cTitleH + cDivH + 1.0;
    CGFloat bottomY = CGRectGetMinY(self.colorResetButton.frame) - 3.0;

    CGFloat sH = 18.0;
    CGFloat sW = targetW - 2*side;

    CGFloat availH = MAX(0.0, bottomY - topY);
    CGFloat gapY = (availH - 4.0*sH) / 5.0;
    if (gapY < 3.0) gapY = 3.0;

    CGFloat y0 = topY + gapY;

    if (self.colorR) self.colorR.frame = CGRectMake(side, y0 + 0*(sH + gapY), sW, sH);
    if (self.colorG) self.colorG.frame = CGRectMake(side, y0 + 1*(sH + gapY), sW, sH);
    if (self.colorB) self.colorB.frame = CGRectMake(side, y0 + 2*(sH + gapY), sW, sH);
    if (self.colorA) self.colorA.frame = CGRectMake(side, y0 + 3*(sH + gapY), sW, sH);
}

- (void)layoutCollapsed {
    if (!self.speedHudView) return;

    CGFloat W = 60.0;
    CGFloat H = 60.0;

    CGPoint oldCenter = self.speedHudView.center;
    self.speedHudView.frame = (CGRect){ self.speedHudView.frame.origin, CGSizeMake(W, H) };
    self.speedHudView.center = oldCenter;

    self.speedHudView.backgroundColor = [UIColor clearColor];
    self.speedHudView.layer.cornerRadius = W / 2.0;

    self.titleBar.hidden = YES;
    self.titleDivider.hidden = YES;
    [self presentColorHud:NO];

    for (UIButton *b in self.speedPresetButtons) b.hidden = YES;
    self.wifiButton.hidden = YES;
    self.adminButton.hidden = YES;
    self.skipButton.hidden = YES;
    self.startButton.hidden = YES;

    if (self.historyOpenButton)     self.historyOpenButton.hidden = YES;
    if (self.autoSpinOpenButton)    self.autoSpinOpenButton.hidden = YES;
    if (self.sliderToggleButton)     self.sliderToggleButton.hidden = YES;

    self.speedSlider.hidden = YES;
    self.speedValueLabel.hidden = YES;
    self.mainHistoryContainer.hidden = YES; 

    self.targetImageView.hidden = YES;
    self.targetLabel.hidden = YES;
    self.targetTapButton.hidden = YES;
    self.collapseButton.hidden = YES;

    self.collapsedImageView.hidden = NO;
    self.collapsedImageView.frame = CGRectMake(0, 0, W, H);
    self.collapsedImageView.layer.cornerRadius = W / 2.0;

    self.counterLabel.hidden = NO;
    self.counterLabel.frame = CGRectMake(0, 0, W, H);
    self.counterLabel.font = [UIFont systemFontOfSize:25.0 weight:UIFontWeightBold];
    self.counterLabel.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.4];
    
    self.counterLabel.textColor = [UIColor greenColor]; 
    
    self.counterLabel.layer.cornerRadius = W / 2.0;
    self.counterLabel.clipsToBounds = YES;

    [self.speedHudView bringSubviewToFront:self.collapsedImageView];
    [self.speedHudView bringSubviewToFront:self.counterLabel];
}

- (void)layoutSpeedHud {
    if (self.hudCollapsed) [self layoutCollapsed];
    else [self layoutExpanded];
}

#pragma mark - Setup HUD

- (void)setupSpeedHud {
    [self loadHudImages];

    UIView *rootView = [UIApplication sharedApplication].keyWindow.rootViewController.view;
    if (!rootView) rootView = self.view.superview ?: self.view;

   CGFloat hudMinWidth = 250.0;

    CGFloat approxH = 22 + 1 + 4 + 35 + 4 + 25 + 4 + 25 + 4 + 20 + 2;

    CGRect bounds = rootView.bounds;
    CGFloat x = (CGRectGetWidth(bounds) - hudMinWidth) / 2.0;
    CGFloat y = (CGRectGetHeight(bounds) - approxH) / 2.0 - 80.0;

    SpeedHudView *hud = [[SpeedHudView alloc] initWithFrame:CGRectMake(x, y, hudMinWidth, approxH)];
    hud.layer.cornerRadius = 16.0;
    hud.layer.masksToBounds = YES;
    hud.userInteractionEnabled = YES;
    hud.backgroundColor = self.currentHudColor;
    
    hud.alpha = 0.0;
    hud.hidden = YES;

    UIView *titleBar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, hudMinWidth, 22)];
    titleBar.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];
    [hud addSubview:titleBar];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, hudMinWidth, 22)];
    titleLabel.text = [NSString stringWithUTF8String:oxorany("Ông Nông")];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightBold]; 
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleBar addSubview:titleLabel];

    UIButton *colorBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [colorBtn setTitle:[NSString stringWithUTF8String:oxorany("🎨")] forState:UIControlStateNormal];
    colorBtn.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    [colorBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    colorBtn.frame = CGRectMake(hudMinWidth - 60, 0, 30, 22);
    [colorBtn addTarget:self action:@selector(handleOpenColorHud) forControlEvents:UIControlEventTouchUpInside];
    [titleBar addSubview:colorBtn];

    UIButton *collapseBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [collapseBtn setTitle:[NSString stringWithUTF8String:oxorany("◀")] forState:UIControlStateNormal]; 
    collapseBtn.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    [collapseBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    collapseBtn.frame = CGRectMake(hudMinWidth - 30, 0, 30, 22);
    [collapseBtn addTarget:self action:@selector(handleCollapseToggle) forControlEvents:UIControlEventTouchUpInside];
    [titleBar addSubview:collapseBtn];

    UIView *divider = [[UIView alloc] initWithFrame:CGRectMake(0, 22, hudMinWidth, 1)];
    divider.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.18];
    [hud addSubview:divider];

    CGFloat iconSize = 32.0;

    UIButton *wifi = [UIButton buttonWithType:UIButtonTypeCustom];
    wifi.frame = CGRectMake(0, 0, iconSize, iconSize);
    wifi.backgroundColor = [UIColor clearColor];
    wifi.adjustsImageWhenHighlighted = NO;
    wifi.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [wifi addTarget:self action:@selector(handleWifiTap) forControlEvents:UIControlEventTouchUpInside];
    [hud addSubview:wifi];

    self.adminButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.adminButton.frame = CGRectMake(0, 0, [self adminButtonWidth], 24.0);
    [self.adminButton setTitle:[NSString stringWithUTF8String:oxorany("Admin")] forState:UIControlStateNormal];
    self.adminButton.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    [self.adminButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.adminButton.backgroundColor = [UIColor yellowColor];
    self.adminButton.layer.cornerRadius = 6.0;
    self.adminButton.layer.masksToBounds = YES;
    self.adminButton.layer.borderWidth = 1.5;
    self.adminButton.layer.borderColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:1.0].CGColor;
    self.adminButton.contentEdgeInsets = UIEdgeInsetsMake(0, 2, 0, 2);
    [self.adminButton addTarget:self action:@selector(handleAdminTap) forControlEvents:UIControlEventTouchUpInside];

    UILongPressGestureRecognizer *lpAdmin =
    [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleAdminLongPress:)];
    lpAdmin.minimumPressDuration = 0.35;
    [self.adminButton addGestureRecognizer:lpAdmin];
    [hud addSubview:self.adminButton];

    self.skipButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.skipButton.frame = CGRectMake(0, 0, [self skipButtonWidth], 24.0);
    [self.skipButton setTitle:[NSString stringWithUTF8String:oxorany("Skip")] forState:UIControlStateNormal]; 
    self.skipButton.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    self.skipButton.layer.cornerRadius = 6.0;
    self.skipButton.layer.masksToBounds = YES;
    self.skipButton.layer.borderWidth = 1.5;
    self.skipButton.layer.borderColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:1.0].CGColor;
    self.skipButton.contentEdgeInsets = UIEdgeInsetsMake(0, 2, 0, 2);
    [self.skipButton addTarget:self action:@selector(handleSkipTap) forControlEvents:UIControlEventTouchUpInside];

    UILongPressGestureRecognizer *lpSkip =
    [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleSkipLongPress:)];
    lpSkip.minimumPressDuration = 0.35;
    [self.skipButton addGestureRecognizer:lpSkip];
    [hud addSubview:self.skipButton];

    self.skipMode = NO;
    self.adminButton.hidden = NO;
    self.skipButton.hidden  = YES;
    [self updateSkipButtonStyle];

    UILabel *counter = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 60.0, 35.0)];
    counter.textColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:1.0];
    counter.font = [UIFont systemFontOfSize:30.0 weight:UIFontWeightSemibold];
    counter.textAlignment = NSTextAlignmentCenter;
    counter.userInteractionEnabled = YES;
    [hud addSubview:counter];

    UITapGestureRecognizer *dbl = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleCountDoubleTap)];
    dbl.numberOfTapsRequired = 2;
    [counter addGestureRecognizer:dbl];
    
    UITapGestureRecognizer *sglCountTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleCountSingleTap)];
    sglCountTap.numberOfTapsRequired = 1;
    [sglCountTap requireGestureRecognizerToFail:dbl];
    [counter addGestureRecognizer:sglCountTap];

    UIImageView *targetImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, iconSize, iconSize)];
    targetImageView.contentMode = UIViewContentModeScaleAspectFit;
    targetImageView.backgroundColor = [UIColor clearColor];
    [hud addSubview:targetImageView];

    UILabel *target = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, iconSize, iconSize)];
    target.textColor = [UIColor whiteColor];
    target.font = [UIFont systemFontOfSize:10.0 weight:UIFontWeightSemibold];
    target.textAlignment = NSTextAlignmentCenter;
    target.backgroundColor = [UIColor clearColor];
    target.adjustsFontSizeToFitWidth = YES;
    target.minimumScaleFactor = 0.5;
    [hud addSubview:target];

    UIButton *targetTap = [UIButton buttonWithType:UIButtonTypeCustom];
    targetTap.backgroundColor = [UIColor clearColor];
    targetTap.adjustsImageWhenHighlighted = NO;
    [targetTap addTarget:self action:@selector(handleTargetTap) forControlEvents:UIControlEventTouchUpInside];
    [hud addSubview:targetTap];

    UIButton *start = [UIButton buttonWithType:UIButtonTypeCustom];
    start.frame = CGRectMake(0, 0, iconSize, iconSize);
    start.backgroundColor = [UIColor clearColor];
    start.adjustsImageWhenHighlighted = NO;
    start.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [start addTarget:self action:@selector(handleStartTap) forControlEvents:UIControlEventTouchUpInside];
    [hud addSubview:start];

    UILabel *speedValue = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 46.0, 25.0)];
    speedValue.textColor = [UIColor yellowColor];
    speedValue.font = [UIFont systemFontOfSize:22.0 weight:UIFontWeightSemibold];
    speedValue.textAlignment = NSTextAlignmentCenter;
    speedValue.adjustsFontSizeToFitWidth = YES;
    speedValue.minimumScaleFactor = 0.6;
    speedValue.userInteractionEnabled = YES;
    [hud addSubview:speedValue];

    UITapGestureRecognizer *tapSpeed = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSpeedValueTap)];
    [speedValue addGestureRecognizer:tapSpeed];

    NSMutableArray<UIButton *> *presets = [NSMutableArray array];
    NSArray<NSNumber *> *defaultValues = @[@9.0, @14.0, @54.0, @108.0];

    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSArray *savedPresets = [ud objectForKey:[NSString stringWithUTF8String:oxorany("pv_speed_presets")]];
    NSMutableArray<NSNumber *> *values = [NSMutableArray array];
    if (savedPresets && savedPresets.count == defaultValues.count) {
        for (NSNumber *num in savedPresets) [values addObject:num];
    } else {
        [values addObjectsFromArray:defaultValues];
    }
    self.speedPresetValues = values;

    for (NSInteger i = 0; i < values.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame = CGRectMake(0, 0, 40, 25);
        [btn setTitle:[values[i] stringValue] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
        btn.layer.cornerRadius = 6.0;
        btn.layer.masksToBounds = YES;
        btn.backgroundColor = [UIColor colorWithWhite:0.2 alpha:1.0];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn.layer.borderWidth = 1.0;
        btn.layer.borderColor = [UIColor colorWithRed:0.20 green:0.55 blue:1.0 alpha:0.95].CGColor;
        btn.tag = i;
        [btn addTarget:self action:@selector(handlePresetTap:) forControlEvents:UIControlEventTouchUpInside];

        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handlePresetLongPress:)];
        longPress.minimumPressDuration = 0.5;
        [btn addGestureRecognizer:longPress];

        [hud addSubview:btn];
        [presets addObject:btn];
    }

    UIButton *historyOpenBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [historyOpenBtn setTitle:[NSString stringWithUTF8String:oxorany("HISTORY")] forState:UIControlStateNormal];
    historyOpenBtn.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    [historyOpenBtn setTitleColor:[UIColor yellowColor] forState:UIControlStateNormal];
    historyOpenBtn.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    historyOpenBtn.layer.cornerRadius = 6.0;
    historyOpenBtn.layer.borderWidth = 1.0;
    historyOpenBtn.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
    [historyOpenBtn addTarget:self action:@selector(handleHistoryOpenTap) forControlEvents:UIControlEventTouchUpInside];
    [hud addSubview:historyOpenBtn];
    self.historyOpenButton = historyOpenBtn;
    
    UIButton *autoSpinBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [autoSpinBtn setTitle:[NSString stringWithUTF8String:oxorany("AUTO")] forState:UIControlStateNormal]; 
    autoSpinBtn.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    [autoSpinBtn setTitleColor:[UIColor cyanColor] forState:UIControlStateNormal];
    autoSpinBtn.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    autoSpinBtn.layer.cornerRadius = 6.0;
    autoSpinBtn.layer.borderWidth = 1.0;
    autoSpinBtn.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
    [autoSpinBtn addTarget:self action:@selector(handleAutoSpinOpenTap) forControlEvents:UIControlEventTouchUpInside];
    [hud addSubview:autoSpinBtn];
    self.autoSpinOpenButton = autoSpinBtn;

    UIButton *sliderToggleBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    sliderToggleBtn.titleLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightSemibold];
    sliderToggleBtn.layer.cornerRadius = 6.0;
    sliderToggleBtn.layer.borderWidth = 1.0;
    sliderToggleBtn.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
    [sliderToggleBtn addTarget:self action:@selector(handleSliderToggleTap) forControlEvents:UIControlEventTouchUpInside];
    [hud addSubview:sliderToggleBtn];
    self.sliderToggleButton = sliderToggleBtn;
    [self updateSliderToggleButtonState]; 

    self.mainHistoryContainer = [[UIView alloc] initWithFrame:CGRectZero];
    self.mainHistoryContainer.hidden = YES;
    [hud addSubview:self.mainHistoryContainer];

    self.mainHistoryIcon = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 25, 25)];
    self.mainHistoryIcon.contentMode = UIViewContentModeScaleAspectFit;
    self.mainHistoryIcon.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.1];
    self.mainHistoryIcon.layer.cornerRadius = 4;
    self.mainHistoryIcon.layer.borderWidth = 1.0;
    self.mainHistoryIcon.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.3].CGColor;
    [self.mainHistoryContainer addSubview:self.mainHistoryIcon];

    self.mainHistoryScrollView = [[UIScrollView alloc] initWithFrame:CGRectZero];
    self.mainHistoryScrollView.showsHorizontalScrollIndicator = NO;
    self.mainHistoryScrollView.showsVerticalScrollIndicator = NO;
    self.mainHistoryScrollView.bounces = YES;
    self.mainHistoryScrollView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.15];
    self.mainHistoryScrollView.layer.cornerRadius = 4;
    self.mainHistoryScrollView.layer.borderWidth = 1.0;
    self.mainHistoryScrollView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.2].CGColor;
    [self.mainHistoryContainer addSubview:self.mainHistoryScrollView];

    self.mainHistoryLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.mainHistoryLabel.textColor = [UIColor whiteColor];
    self.mainHistoryLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightBold];
    self.mainHistoryLabel.textAlignment = NSTextAlignmentLeft;
    [self.mainHistoryScrollView addSubview:self.mainHistoryLabel];

    self.autoSpinHud = [[AutoSpinTargetHud alloc] initWithFrame:CGRectMake(50, 150, 220, 100)];
    self.autoSpinHud.alpha = 0.0; 
    self.autoSpinHud.hidden = YES;
    [rootView addSubview:self.autoSpinHud];

    self.collapsedImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    self.collapsedImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.collapsedImageView.layer.masksToBounds = YES;
    self.collapsedImageView.layer.borderWidth = 0.0;
    self.collapsedImageView.userInteractionEnabled = YES;
    self.collapsedImageView.hidden = YES;
    [hud addSubview:self.collapsedImageView];

    UITapGestureRecognizer *expandTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleMiniExpandTap)];
    [self.collapsedImageView addGestureRecognizer:expandTap];

    NSString *iconUrlString = [NSString stringWithUTF8String:oxorany("https://i.ibb.co/gLG3wXjq/IMG-1061.jpg")]; 
    [[[NSURLSession sharedSession] dataTaskWithURL:[NSURL URLWithString:iconUrlString] completionHandler:^(NSData *d, NSURLResponse *r, NSError *e) {
        if(d) {
            UIImage *img = [UIImage imageWithData:d];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.collapsedImageView.image = img;
            });
        }
    }] resume];

    HistoryHudView *hHud = [[HistoryHudView alloc] initWithFrame:CGRectMake(50, 100, 190, 100)];
    hHud.alpha = 0.0; 
    hHud.hidden = YES;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[NSString stringWithUTF8String:oxorany("ResetAllCounters")] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleResetAllCounters) name:[NSString stringWithUTF8String:oxorany("ResetAllCounters")] object:nil];
    
    [hHud.closeButton addTarget:self action:@selector(handleHistoryCloseTap) forControlEvents:UIControlEventTouchUpInside];
    [hHud.clearButton addTarget:self action:@selector(handleHistoryClearTap) forControlEvents:UIControlEventTouchUpInside];
     
    
    
    self.historyHud = hHud;

    UISlider *slider = [[UISlider alloc] initWithFrame:CGRectZero];
    slider.minimumValue = 0.0f;
    slider.maximumValue = 300.0f;
    CGFloat thumbSize = 20.0;
    [slider setThumbImage:[self createThumbImageWithSize:thumbSize] forState:UIControlStateNormal];
    [slider setThumbImage:[self createThumbImageWithSize:thumbSize] forState:UIControlStateHighlighted];
    [slider addTarget:self action:@selector(handleSliderChanged:) forControlEvents:UIControlEventValueChanged];
    [slider addTarget:self action:@selector(handleSliderFinished:) forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside];
    [hud addSubview:slider];

    UIView *colorHud = [[UIView alloc] initWithFrame:hud.bounds];
    colorHud.backgroundColor = self.currentHudColor;
    colorHud.hidden = YES;
    [colorHud setClipsToBounds:YES];
    [hud addSubview:colorHud];

    CGFloat titleH2 = 22.0;
    CGFloat divH2 = 1.0;

    UIView *chTitle = [[UIView alloc] initWithFrame:CGRectMake(0, 0, hud.bounds.size.width, titleH2)];
    chTitle.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];
    [colorHud addSubview:chTitle];

    UILabel *chTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, hud.bounds.size.width, titleH2)];
    chTitleLabel.text = [NSString stringWithUTF8String:oxorany("Edit Color")]; 
    chTitleLabel.textColor = [UIColor whiteColor];
    chTitleLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightSemibold]; 
    chTitleLabel.textAlignment = NSTextAlignmentCenter;
    [chTitle addSubview:chTitleLabel];

    UIButton *chClose = [UIButton buttonWithType:UIButtonTypeSystem];
    chClose.frame = CGRectMake(hud.bounds.size.width - 7 - 30.0, 0, 30.0, titleH2);
    [chClose setTitle:[NSString stringWithUTF8String:oxorany("✕")] forState:UIControlStateNormal];
    chClose.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    [chClose setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [chClose addTarget:self action:@selector(handleCloseColorHud) forControlEvents:UIControlEventTouchUpInside];
    [chTitle addSubview:chClose];

    UIView *chDiv = [[UIView alloc] initWithFrame:CGRectMake(0, titleH2, hud.bounds.size.width, divH2)];
    chDiv.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.18];
    [colorHud addSubview:chDiv];

    UISlider *rS = [[UISlider alloc] initWithFrame:CGRectZero];
    rS.minimumValue = 0; rS.maximumValue = 1;
    [rS addTarget:self action:@selector(handleColorSlider:) forControlEvents:UIControlEventValueChanged];
    [colorHud addSubview:rS];

    UISlider *gS = [[UISlider alloc] initWithFrame:CGRectZero];
    gS.minimumValue = 0; gS.maximumValue = 1;
    [gS addTarget:self action:@selector(handleColorSlider:) forControlEvents:UIControlEventValueChanged];
    [colorHud addSubview:gS];

    UISlider *bS = [[UISlider alloc] initWithFrame:CGRectZero];
    bS.minimumValue = 0; bS.maximumValue = 1;
    [bS addTarget:self action:@selector(handleColorSlider:) forControlEvents:UIControlEventValueChanged];
    [colorHud addSubview:bS];

    UISlider *aS = [[UISlider alloc] initWithFrame:CGRectZero];
    aS.minimumValue = 0.2; aS.maximumValue = 1;
    [aS addTarget:self action:@selector(handleColorSlider:) forControlEvents:UIControlEventValueChanged];
    [colorHud addSubview:aS];

    CGFloat cThumb = 24.0;
    UIImage *timg = [self createThumbImageWithSize:cThumb];
    [rS setThumbImage:timg forState:UIControlStateNormal];
    [rS setThumbImage:timg forState:UIControlStateHighlighted];
    [gS setThumbImage:timg forState:UIControlStateNormal];
    [gS setThumbImage:timg forState:UIControlStateHighlighted];
    [bS setThumbImage:timg forState:UIControlStateNormal];
    [bS setThumbImage:timg forState:UIControlStateHighlighted];
    [aS setThumbImage:timg forState:UIControlStateNormal];
    [aS setThumbImage:timg forState:UIControlStateHighlighted];

    CGFloat resetH = 25.0;
    CGFloat bottomPad = 1.0;
    CGFloat side = 10.0;
    CGFloat gapX = 8.0; 
    CGFloat halfW = (hud.bounds.size.width - side*2 - gapX) / 2.0;

    UIButton *resetColor = [UIButton buttonWithType:UIButtonTypeSystem];
    resetColor.frame = CGRectMake(side,
                                  hud.bounds.size.height - bottomPad - resetH,
                                  halfW,
                                  resetH);
    [resetColor setTitle:[NSString stringWithUTF8String:oxorany("Reset Color")] forState:UIControlStateNormal];
    resetColor.titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    [resetColor setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    resetColor.layer.cornerRadius = 8;
    resetColor.layer.masksToBounds = YES;
    resetColor.backgroundColor = [UIColor colorWithWhite:1 alpha:0.10];
    resetColor.layer.borderWidth = 1.2;
    resetColor.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.25].CGColor;
    [resetColor addTarget:self action:@selector(handleResetColorDefault) forControlEvents:UIControlEventTouchUpInside];
    [colorHud addSubview:resetColor];
    
    UIButton *fpsToggle = [UIButton buttonWithType:UIButtonTypeSystem];
    fpsToggle.frame = CGRectMake(side + halfW + gapX,
                                 hud.bounds.size.height - bottomPad - resetH,
                                 halfW,
                                 resetH);
    [fpsToggle setTitle:(self.showFPS ? [NSString stringWithUTF8String:oxorany("Hide FPS")] : [NSString stringWithUTF8String:oxorany("Show FPS")]) forState:UIControlStateNormal];
    fpsToggle.titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    [fpsToggle setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    fpsToggle.layer.cornerRadius = 8;
    fpsToggle.layer.masksToBounds = YES;
    fpsToggle.backgroundColor = self.showFPS ? [UIColor colorWithRed:0.0 green:0.8 blue:0.0 alpha:0.3] : [UIColor colorWithWhite:1 alpha:0.10];
    fpsToggle.layer.borderWidth = 1.2;
    fpsToggle.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.25].CGColor;
    [fpsToggle addTarget:self action:@selector(handleToggleFPS) forControlEvents:UIControlEventTouchUpInside];
    [colorHud addSubview:fpsToggle];
    self.fpsToggleButton = fpsToggle;

    CGFloat topY = titleH2 + divH2 + 1.0;
    CGFloat bottomY = resetColor.frame.origin.y - 6.0;
    CGFloat sH = 18.0;
    CGFloat availableH = MAX(0, bottomY - topY);
    CGFloat gapY = 6.0;
    if (availableH > 4*sH) {
        gapY = (availableH - 4*sH) / 5.0;
        if (gapY < 6.0) gapY = 6.0;
    }
    CGFloat y0 = topY + gapY;
    CGFloat sW = hud.bounds.size.width - side*2;

    rS.frame = CGRectMake(side, y0 + 0*(sH+gapY), sW, sH);
    gS.frame = CGRectMake(side, y0 + 1*(sH+gapY), sW, sH);
    bS.frame = CGRectMake(side, y0 + 2*(sH+gapY), sW, sH);
    aS.frame = CGRectMake(side, y0 + 3*(sH+gapY), sW, sH);

    CGFloat rr=0,gg=0,bb=0,aa=0;
    if ([self.currentHudColor getRed:&rr green:&gg blue:&bb alpha:&aa]) {
        rS.value = rr; gS.value = gg; bS.value = bb; aS.value = aa;
    }

    self.speedHudView = hud;

    self.titleBar = titleBar;
    self.titleLabel = titleLabel;
    self.titleDivider = divider;
    self.colorOpenButton = colorBtn;
    self.collapseButton = collapseBtn;

    self.wifiButton = wifi;
    self.counterLabel = counter;
    self.targetLabel = target;
    self.targetImageView = targetImageView;
    self.targetTapButton = targetTap;
    self.startButton = start;

    self.speedSlider = slider;
    self.speedValueLabel = speedValue;

    self.speedPresetButtons = presets;

    self.colorHud = colorHud;
    self.colorHudTitleBar = chTitle;
    self.colorHudTitleLabel = chTitleLabel;
    self.colorHudDivider = chDiv;
    self.colorHudCloseButton = chClose;
    self.colorR = rS; self.colorG = gS; self.colorB = bS; self.colorA = aS;
    self.colorResetButton = resetColor;

    [rootView addSubview:hud];
    [rootView addSubview:hHud];

    UIView *iconMenu = [rootView viewWithTag:100];
    if (iconMenu) [rootView bringSubviewToFront:iconMenu];

    self.hudCollapsed = NO;
    [self refreshSpeedHud];
}

#pragma mark - Actions (Admin/Skip)

- (void)handleAdminLongPress:(UILongPressGestureRecognizer *)gr {
    if (gr.state != UIGestureRecognizerStateBegan) return;
    self.skipMode = YES;
    if (self.adminButton) self.adminButton.hidden = YES;
    if (self.skipButton)  self.skipButton.hidden  = NO;
    [self updateSkipButtonStyle];
    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

- (void)handleSkipLongPress:(UILongPressGestureRecognizer *)gr {
    if (gr.state != UIGestureRecognizerStateBegan) return;
    self.skipMode = NO;
    if (self.adminButton) self.adminButton.hidden = NO;
    if (self.skipButton)  self.skipButton.hidden  = YES;
    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

- (void)handleSkipTap {
    self.skipEnabled = !self.skipEnabled;
    Vars.SkipAttackRaid = self.skipEnabled;

    [self saveSetting];
    [self updateSkipButtonStyle];
    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

- (void)handleMiniExpandTap {
    if (!self.hudCollapsed) return;

    self.hudCollapsed = NO;

    self.titleBar.hidden = NO;
    self.titleDivider.hidden = NO;

    self.wifiButton.hidden = NO;
    self.startButton.hidden = NO;

    self.adminButton.hidden = self.skipMode;
    self.skipButton.hidden  = !self.skipMode;

    for (UIButton *b in self.speedPresetButtons) b.hidden = NO;

    if (self.historyOpenButton) self.historyOpenButton.hidden = NO;
    if (self.autoSpinOpenButton) self.autoSpinOpenButton.hidden = NO;
    if (self.sliderToggleButton) self.sliderToggleButton.hidden = NO; 
    
    self.speedSlider.hidden = (self.bottomDisplayMode != 1);
    
    self.mainHistoryContainer.hidden = (self.bottomDisplayMode != 2);

    [self.collapseButton setTitle:[self stringFromHexString:@"e29780"] forState:UIControlStateNormal];

    self.speedHudView.userInteractionEnabled = NO;

    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    [self layoutSpeedHud];
    [CATransaction commit];

    [UIView animateWithDuration:0.22
                          delay:0
         usingSpringWithDamping:0.88
          initialSpringVelocity:0.0
                        options:UIViewAnimationOptionBeginFromCurrentState |
                                UIViewAnimationOptionAllowUserInteraction |
                                UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        [self layoutSpeedHud];
    } completion:^(BOOL finished) {
        self.speedHudView.userInteractionEnabled = YES;
    }];

    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

#pragma mark - Other Actions

- (void)handleCountDoubleTap {
        if (Vars.target == 3) Vars.countAttack = 0;
    else if (Vars.target == 4) Vars.countRaid = 0;
    else if (Vars.target == 30) Vars.countSymbol = 0;
    else if (Vars.target == 6) Vars.countSpin = 0;
    else if (Vars.target == 54) Vars.countPoin = 0;
    
    [self saveSetting];
    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

- (void)handleCountSingleTap {
    if (self.hudCollapsed) {
        [self handleMiniExpandTap];
        TriggerHapticFeedback();
    }
}

- (void)handleOpenColorHud {
    [self presentColorHud:YES];
    TriggerHapticFeedback();
}

- (void)handleCloseColorHud {
    [self presentColorHud:NO];
    TriggerHapticFeedback();
}

- (void)handleColorSlider:(UISlider *)s {
    UIColor *c = [UIColor colorWithRed:self.colorR.value green:self.colorG.value blue:self.colorB.value alpha:self.colorA.value];
    [self applyHudColor:c];
}

- (void)handleResetColorDefault {
    self.currentHudColor = self.defaultHudColor;
    CGFloat rr=0,gg=0,bb=0,aa=0;
    if ([self.currentHudColor getRed:&rr green:&gg blue:&bb alpha:&aa]) {
        self.colorR.value = rr; self.colorG.value = gg; self.colorB.value = bb; self.colorA.value = aa;
    }
    [self applyHudColor:self.currentHudColor];
    TriggerHapticFeedback();
}

- (void)handleToggleFPS {
    self.showFPS = !self.showFPS;
    
    [self.fpsToggleButton setTitle:(self.showFPS ? [NSString stringWithUTF8String:oxorany("Hide FPS")] : [NSString stringWithUTF8String:oxorany("Show FPS")]) forState:UIControlStateNormal];
    self.fpsToggleButton.backgroundColor = self.showFPS ? [UIColor colorWithRed:0.0 green:0.8 blue:0.0 alpha:0.3] : [UIColor colorWithWhite:1 alpha:0.10];
    
    [self saveSetting];
    [[FPSDisplay shareFPSDisplay] setDisplayHidden:!self.showFPS];

    TriggerHapticFeedback();
}

- (void)handleCollapseToggle {

    BOOL toCollapsed = !self.hudCollapsed;

    if (!toCollapsed) {
        self.titleBar.hidden = NO;
        self.titleDivider.hidden = NO;
        self.wifiButton.hidden = NO;
        self.startButton.hidden = NO;
        self.adminButton.hidden = self.skipMode;
        self.skipButton.hidden  = !self.skipMode;

        for (UIButton *b in self.speedPresetButtons) b.hidden = NO;
        if (self.historyOpenButton) self.historyOpenButton.hidden = NO;
        if (self.autoSpinOpenButton) self.autoSpinOpenButton.hidden = NO;
        if (self.sliderToggleButton) self.sliderToggleButton.hidden = NO; 

        self.speedSlider.hidden = (self.bottomDisplayMode != 1);
        self.mainHistoryContainer.hidden = (self.bottomDisplayMode != 2);

        [self.collapseButton setTitle:[self stringFromHexString:@"e29780"] forState:UIControlStateNormal];
    } else {
        [self.collapseButton setTitle:[self stringFromHexString:@"e296b6"] forState:UIControlStateNormal];
    }

    self.hudCollapsed = toCollapsed;

    self.speedHudView.userInteractionEnabled = NO;

    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    [self layoutSpeedHud];
    [CATransaction commit];

    [UIView animateWithDuration:0.22
                          delay:0
         usingSpringWithDamping:0.88
          initialSpringVelocity:0.0
                        options:UIViewAnimationOptionBeginFromCurrentState |
                                UIViewAnimationOptionAllowUserInteraction |
                                UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        [self layoutSpeedHud];
    } completion:^(BOOL finished) {

        if (self.hudCollapsed) {
            self.titleBar.hidden = YES;
            self.titleDivider.hidden = YES;
            self.wifiButton.hidden = YES;
            self.startButton.hidden = YES;
            self.adminButton.hidden = YES;
            self.skipButton.hidden  = YES;

            for (UIButton *b in self.speedPresetButtons) b.hidden = YES;
            if (self.historyOpenButton) self.historyOpenButton.hidden = YES;
            if (self.autoSpinOpenButton) self.autoSpinOpenButton.hidden = YES;
            if (self.sliderToggleButton) self.sliderToggleButton.hidden = YES; 
            
            self.speedSlider.hidden = YES; 
            
               self.mainHistoryContainer.hidden = YES;
        }

        self.speedHudView.userInteractionEnabled = YES;
    }];

    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

- (void)handleWifiTap {
    Vars.disconnect = !Vars.disconnect;
    [self saveSetting];
    [self refreshSpeedHud];
}

- (void)handleStartTap {
    Vars.speedEnabled = !Vars.speedEnabled;
    [self saveSetting];
    [self refreshSpeedHud];
}

- (void)handleTargetTap {
    NSArray<NSNumber *> *order = @[@0, @3, @4, @30, @6, @54];
    NSInteger idx = [order indexOfObject:@(Vars.target)];
    if (idx == NSNotFound) idx = 0;
    idx = (idx + 1) % order.count;
    Vars.target = [order[idx] intValue];
    [self saveSetting];
    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

- (void)handleSpeedValueTap {
    float current = Vars.speed;

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:[NSString stringWithUTF8String:oxorany("Set Speed")]
                                                                   message:[NSString stringWithUTF8String:oxorany("Enter speed (0-1000)")]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.text = [NSString stringWithFormat:@"%.1f", current];
        textField.keyboardType = UIKeyboardTypeDecimalPad;
        textField.placeholder = [NSString stringWithUTF8String:oxorany("Speed")];
    }];

    UIAlertAction *ok = [UIAlertAction actionWithTitle:[NSString stringWithUTF8String:oxorany("OK")] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) { 
        UITextField *tf = alert.textFields.firstObject;
        float v = [tf.text floatValue];
        if (v < 0.0f) v = 0.0f;
        if (v > 1000.0f) v = 1000.0f;

        Vars.speed = v;
        Vars.speedEnabled = YES;
        [self saveSetting];
        [self refreshSpeedHud];
        TriggerHapticFeedback();
    }];
    [alert addAction:ok];
    [alert addAction:[UIAlertAction actionWithTitle:[NSString stringWithUTF8String:oxorany("Cancel")] style:UIAlertActionStyleCancel handler:nil]];

    UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    if (rootVC.presentedViewController) {
        [rootVC.presentedViewController presentViewController:alert animated:YES completion:nil];
    } else {
        [rootVC presentViewController:alert animated:YES completion:nil];
    }
}

- (void)handlePresetLongPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;

    UIButton *sender = (UIButton *)gesture.view;
    NSInteger index = sender.tag;
    if (index < 0 || index >= self.speedPresetValues.count) return;

    float currentValue = [self.speedPresetValues[index] floatValue];

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:[NSString stringWithUTF8String:oxorany("Edit Speed Value")]
                                                                   message:[NSString stringWithUTF8String:oxorany("Enter new speed value (0-1000)")]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.text = [NSString stringWithFormat:@"%.1f", currentValue];
        textField.keyboardType = UIKeyboardTypeDecimalPad;
        textField.placeholder = [NSString stringWithUTF8String:oxorany("Speed value")];
    }];
    
    UIAlertAction *saveAction = [UIAlertAction actionWithTitle:[NSString stringWithUTF8String:oxorany("Save")] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { 
        UITextField *textField = alert.textFields.firstObject;
        float newValue = [textField.text floatValue];

        if (newValue < 0.0f) newValue = 0.0f;
        if (newValue > 1000.0f) newValue = 1000.0f;

        self.speedPresetValues[index] = @(newValue);
        [sender setTitle:[NSString stringWithFormat:@"%.0f", newValue] forState:UIControlStateNormal];

        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        [ud setObject:self.speedPresetValues forKey:[NSString stringWithUTF8String:oxorany("pv_speed_presets")]]; 
        [ud synchronize];

        if (fabsf(Vars.speed - currentValue) < 0.01f) {
            Vars.speed = newValue;
            [self saveSetting];
        }

        [self refreshSpeedHud];
        TriggerHapticFeedback();
    }];

    [alert addAction:saveAction];
    [alert addAction:[UIAlertAction actionWithTitle:[NSString stringWithUTF8String:oxorany("Cancel")] style:UIAlertActionStyleCancel handler:nil]];

    UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    if (rootVC.presentedViewController) {
        [rootVC.presentedViewController presentViewController:alert animated:YES completion:nil];
    } else {
        [rootVC presentViewController:alert animated:YES completion:nil];
    }
    TriggerHapticFeedback();
}


- (void)handlePresetTap:(UIButton *)sender {
    NSInteger index = sender.tag;
    if (index >= 0 && index < self.speedPresetValues.count) {
        float value = [self.speedPresetValues[index] floatValue];
        Vars.speed = value;
        Vars.speedEnabled = YES;
        [self saveSetting];
        [self refreshSpeedHud];
    }
}

- (void)handleSliderChanged:(UISlider *)slider {
    Vars.speed = slider.value;
    Vars.speedEnabled = YES;
    [self refreshSpeedHud];
}

- (void)handleSliderFinished:(UISlider *)slider {
    Vars.speed = slider.value;
    Vars.speedEnabled = YES;
    [self saveSetting];
    [self refreshSpeedHud];
}

- (void)handleHistoryClearTap {
    Vars.historyAttack.clear();
    Vars.historyRaid.clear();
    Vars.historySymbol.clear();
    Vars.historySpin.clear();
    Vars.historyPoin.clear();

    
    if (self.mainHistoryLabel) {
        self.mainHistoryLabel.text = @"";
        [self.mainHistoryLabel sizeToFit];
        self.mainHistoryScrollView.contentSize = CGSizeMake(self.mainHistoryLabel.frame.size.width + 16, 25.0);
    }

    [self saveSetting];
    [self refreshSpeedHud];
    TriggerHapticFeedback();
}

- (void)handleResetAllCounters {
    Vars.countAttack = 0;
    Vars.countRaid = 0;
    Vars.countSymbol = 0;
    Vars.countSpin = 0;
    Vars.countPoin = 0;
    
    [self saveSetting];
    [self refreshSpeedHud];
    TriggerHapticFeedback();
}


- (void)handleHistoryOpenTap {
    if (self.historyHud) {
        self.historyHud.hidden = NO;
        [self.historyHud.superview bringSubviewToFront:self.historyHud];
        
        [UIView animateWithDuration:0.25 animations:^{
            self.historyHud.alpha = 1.0;
        }];
    }
}

- (void)handleAutoSpinOpenTap {
    if (self.autoSpinHud) {
        self.autoSpinHud.hidden = NO;
        [self.autoSpinHud.superview bringSubviewToFront:self.autoSpinHud];
        
        [UIView animateWithDuration:0.25 animations:^{
            self.autoSpinHud.alpha = 1.0;
        }];
    }
}

- (void)handleHistoryCloseTap {
    if (self.historyHud) {
        [UIView animateWithDuration:0.2 animations:^{
            self.historyHud.alpha = 0.0;
        } completion:^(BOOL finished) {
            self.historyHud.hidden = YES;
        }];
    }
}

- (void)handleSliderToggleTap {
    self.bottomDisplayMode = (self.bottomDisplayMode + 1) % 3; 
    [self updateSliderToggleButtonState];
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setInteger:self.bottomDisplayMode forKey:[self stringFromHexString:@"70765f626f74746f6d5f646973706c6179"]];
    [ud synchronize];

    self.speedHudView.userInteractionEnabled = NO;
    [UIView animateWithDuration:0.22 delay:0 usingSpringWithDamping:0.88 initialSpringVelocity:0.0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionCurveEaseInOut animations:^{
        [self layoutSpeedHud];
    } completion:^(BOOL finished) {
        self.speedHudView.userInteractionEnabled = YES;
    }];
    TriggerHapticFeedback();
}


#pragma mark - Refresh (Fixed Lag, Fade-in & Disappearing UI)

- (void)refreshSpeedHud {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self refreshSpeedHud];
        });
        return;
    }

    static BOOL isUIUpdateQueued = NO;
    if (!isUIUpdateQueued) {
        isUIUpdateQueued = YES; 
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self doRefreshSpeedHud]; 
            isUIUpdateQueued = NO;   
        });
    }
}

- (void)updateSliderToggleButtonState {
    self.sliderToggleButton.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.15];
    
    if (self.bottomDisplayMode == 1) {
        [self.sliderToggleButton setTitle:[NSString stringWithUTF8String:oxorany("SLIDER")] forState:UIControlStateNormal]; 
        [self.sliderToggleButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    } else if (self.bottomDisplayMode == 2) {
        [self.sliderToggleButton setTitle:[NSString stringWithUTF8String:oxorany("HISTORY")] forState:UIControlStateNormal];
        [self.sliderToggleButton setTitleColor:[UIColor cyanColor] forState:UIControlStateNormal];
    } else {
        [self.sliderToggleButton setTitle:[NSString stringWithUTF8String:oxorany("HIDDEN")] forState:UIControlStateNormal];
        [self.sliderToggleButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    }
}

- (void)doRefreshSpeedHud {
    if (!self.speedHudView) return;

    if (!self.isServerLoaded || !self.isMenuAllowedByServer) {
        self.speedHudView.hidden = YES;
        self.speedHudView.alpha = 0.0;
    } else {
        if (Vars.Enable) {
            if (self.speedHudView.alpha == 0.0 || self.speedHudView.hidden == YES) {
                self.speedHudView.hidden = NO;
                [UIView animateWithDuration:0.4 animations:^{
                    self.speedHudView.alpha = 1.0;
                    if (self.historyHud && !self.historyHud.hidden) self.historyHud.alpha = 1.0;
                    if (self.autoSpinHud && !self.autoSpinHud.hidden) self.autoSpinHud.alpha = 1.0;
                }];
            }
        } else {
            self.speedHudView.hidden = YES;
            self.speedHudView.alpha = 0.0;
        }
    }

    self.speedHudView.backgroundColor = self.currentHudColor;
    if (self.colorHud) self.colorHud.backgroundColor = self.currentHudColor;
    if (self.historyHud) self.historyHud.backgroundColor = self.currentHudColor;
    if (self.autoSpinHud) self.autoSpinHud.backgroundColor = self.currentHudColor;

    self.adminButton.hidden = self.skipMode;
    self.skipButton.hidden = !self.skipMode;
    [self updateSkipButtonStyle];

    if (self.wifiButton) {
        if (Vars.disconnect && self.disconnectImage) {
            [self.wifiButton setImage:self.disconnectImage forState:UIControlStateNormal];
            [self.wifiButton setTitle:nil forState:UIControlStateNormal];
        } else if (!Vars.disconnect && self.connectImage) {
            [self.wifiButton setImage:self.connectImage forState:UIControlStateNormal];
            [self.wifiButton setTitle:nil forState:UIControlStateNormal];
        } else {
            [self.wifiButton setImage:nil forState:UIControlStateNormal];
            [self.wifiButton setTitle:[NSString stringWithUTF8String:oxorany("📶")] forState:UIControlStateNormal]; 
            self.wifiButton.tintColor = Vars.disconnect ? [UIColor systemRedColor] : [UIColor whiteColor];
        }
    }

    int currentMainCount = 0;
    if (Vars.target == 3) currentMainCount = Vars.countAttack;
    else if (Vars.target == 4) currentMainCount = Vars.countRaid;
    else if (Vars.target == 30) currentMainCount = Vars.countSymbol;
    else if (Vars.target == 6) currentMainCount = Vars.countSpin;
    else if (Vars.target == 54) currentMainCount = Vars.countPoin; 
    self.counterLabel.text = [NSString stringWithFormat:@"%d", currentMainCount];

    NSString *targetText = [NSString stringWithUTF8String:oxorany("KHÓI")];
    UIImage *targetImage = nil;
    if (Vars.target == 3) { targetText = [NSString stringWithUTF8String:oxorany("Attack")]; targetImage = self.attackImage; }
    else if (Vars.target == 4) { targetText = [NSString stringWithUTF8String:oxorany("Raid")]; targetImage = self.raidImage; }
    else if (Vars.target == 30) { targetText = [NSString stringWithUTF8String:oxorany("Symbol")]; targetImage = self.symbolImage; }
    else if (Vars.target == 6) { targetText = [NSString stringWithUTF8String:oxorany("Spin")]; targetImage = self.spinImage; }
    else if (Vars.target == 54) { targetText = [NSString stringWithUTF8String:oxorany("Poin")]; targetImage = self.poinImage; }

    if (self.targetImageView) {
        if (targetImage) {
            self.targetImageView.image = targetImage;
            self.targetImageView.hidden = NO;
            self.targetLabel.hidden = YES;
        } else {
            self.targetImageView.image = nil;
            self.targetImageView.hidden = YES;
            self.targetLabel.hidden = NO;
        }
    }
    self.targetLabel.text = targetText;
    
    self.targetTapButton.hidden = NO;
    [self.speedHudView bringSubviewToFront:self.targetTapButton];

    if (self.startButton) {
        if (Vars.speedEnabled && self.pauseImage) {
            [self.startButton setImage:self.pauseImage forState:UIControlStateNormal];
            [self.startButton setTitle:nil forState:UIControlStateNormal];
        } else if (!Vars.speedEnabled && self.startImage) {
            [self.startButton setImage:self.startImage forState:UIControlStateNormal];
            [self.startButton setTitle:nil forState:UIControlStateNormal];
        } else {
            [self.startButton setImage:nil forState:UIControlStateNormal];
            [self.startButton setTitle:(Vars.speedEnabled ? [NSString stringWithUTF8String:oxorany("❚❚")] : [NSString stringWithUTF8String:oxorany("▶︎")]) forState:UIControlStateNormal];
        }
    }

    if (Vars.speed < 0.0f) Vars.speed = 0.0f;
    if (Vars.speed > 300.0f) Vars.speed = 300.0f;
    self.speedSlider.value = Vars.speed;
    if (self.speedValueLabel) self.speedValueLabel.text = [NSString stringWithFormat:@"%.0fx", Vars.speed];

    if (self.speedPresetButtons && self.speedPresetValues) {
        for (UIButton *btn in self.speedPresetButtons) {
            NSInteger index = btn.tag;
            if (index >= 0 && index < self.speedPresetValues.count) {
                float value = [self.speedPresetValues[index] floatValue];
                BOOL selected = fabsf(Vars.speed - value) < 0.01f;
                btn.backgroundColor = selected ? [UIColor colorWithRed:0.0 green:0.7 blue:0.4 alpha:1.0]
                                               : [UIColor colorWithWhite:0.2 alpha:1.0];
                [btn setTitle:[NSString stringWithFormat:@"%.0f", value] forState:UIControlStateNormal];
            }
        }
    }

    if (self.bottomDisplayMode == 2 && self.mainHistoryContainer) {
        std::vector<int> *currentHist = nil;
        UIColor *tColor = [UIColor whiteColor];
        UIImage *tImage = nil;
        
        if (Vars.target == 3) { currentHist = &Vars.historyAttack; tColor = [UIColor redColor]; tImage = self.attackImage; }
        else if (Vars.target == 4) { currentHist = &Vars.historyRaid; tColor = [UIColor orangeColor]; tImage = self.raidImage; }
        else if (Vars.target == 30) { currentHist = &Vars.historySymbol; tColor = [UIColor cyanColor]; tImage = self.symbolImage; }
        else if (Vars.target == 6) { currentHist = &Vars.historySpin; tColor = [UIColor magentaColor]; tImage = self.spinImage; }
        else if (Vars.target == 54) { currentHist = &Vars.historyPoin; tColor = [UIColor yellowColor]; tImage = self.poinImage; }

        self.mainHistoryIcon.image = tImage;
        self.mainHistoryLabel.textColor = tColor;

        if (currentHist && Vars.history) {
            NSMutableString *str = [NSMutableString string];
            for (int i = 0; i < currentHist->size(); i++) {
                [str appendFormat:@"%d%@", (*currentHist)[i], (i == currentHist->size() - 1) ? @"" : @","]; 
            }
            if (str.length == 0) [str appendString:@""];
            
            if (![self.mainHistoryLabel.text isEqualToString:str]) {
                self.mainHistoryLabel.text = str;
                [self.mainHistoryLabel sizeToFit]; 
                
                CGRect lFrame = self.mainHistoryLabel.frame;
                lFrame.origin = CGPointMake(8, (25.0 - lFrame.size.height) / 2.0); 
                self.mainHistoryLabel.frame = lFrame;
                
                self.mainHistoryScrollView.contentSize = CGSizeMake(lFrame.size.width + 16, 25.0);
                [self.mainHistoryScrollView setContentOffset:CGPointZero animated:NO];
            }
        } else {
            self.mainHistoryLabel.text = @"";
            [self.mainHistoryLabel sizeToFit];
            self.mainHistoryScrollView.contentSize = CGSizeMake(self.mainHistoryLabel.frame.size.width + 16, 25.0);
        }
    }

    [self layoutSpeedHud];

    UIView *rootView = self.speedHudView.superview;
    if (rootView) {
        [rootView bringSubviewToFront:self.speedHudView];
        if (self.historyHud) [rootView bringSubviewToFront:self.historyHud];
        if (self.autoSpinHud) [rootView bringSubviewToFront:self.autoSpinHud];

        UIView *iconMenu = [rootView viewWithTag:100];
        if (iconMenu) [rootView bringSubviewToFront:iconMenu];

        if (MenDeal && menuTouchView) {
            UIView *menuSuperview = menuTouchView.superview;
            if (menuSuperview) {
                [menuSuperview bringSubviewToFront:menuTouchView];
                if (iconMenu && iconMenu.superview == menuSuperview) {
                    [menuSuperview bringSubviewToFront:iconMenu];
                }
            }
        }
    }
}

static void DrawProfileChip(const char* name,
                            const char* subtitle,
                            ImTextureID avatarTex,
                            float width)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();

    float padX = 7.0f, padY = 10.0f;
    float h = 40.0f, r = h*0.5f, avatar = h - 12.0f;
    ImVec2 size(width, h);

    ImGui::InvisibleButton("##profile_chip", size);
    bool hovered = ImGui::IsItemHovered();
    bool held    = ImGui::IsItemActive();
    bool clicked = ImGui::IsItemClicked(ImGuiMouseButton_Left);
    if (hovered) ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);

    ImU32 bg=ImGui::GetColorU32(ImVec4(0.12f,0.12f,0.12f,1));
    ImU32 bgH=ImGui::GetColorU32(ImVec4(0.18f,0.18f,0.18f,1));
    ImU32 ring=ImGui::GetColorU32(ImVec4(0.20f,0.20f,0.20f,1));
    ImU32 text=ImGui::GetColorU32(ImVec4(0.90f,0.90f,0.90f,1));
    ImU32 sub =ImGui::GetColorU32(ImVec4(0.70f,0.70f,0.70f,1));

    dl->AddRectFilled(p, p + size, hovered ? bgH : bg, r);

    ImVec2 c = p + ImVec2(padX + avatar * 0.5f, h * 0.5f);
    if (avatarTex)
        dl->AddImageRounded(avatarTex,
            c - ImVec2(avatar*0.5f, avatar*0.5f),
            c + ImVec2(avatar*0.5f, avatar*0.5f),
            ImVec2(0,0), ImVec2(1,1), IM_COL32_WHITE, avatar*0.5f);
    else {
        dl->AddCircleFilled(c, avatar * 0.5f, IM_COL32(220,220,220,255));
        dl->AddCircle(c, avatar * 0.5f, ring, 48, 2.0f);
    }

    float textX = padX*1.5f + avatar;
    ImVec2 namePos = p + ImVec2(textX, padY - 1.0f);
    ImVec2 subPos  = p + ImVec2(textX, h - padY - ImGui::GetFontSize()*0.85f);
    subPos.y += 3.0f;

    dl->AddText(namePos, text, name);
    dl->AddText(subPos,  sub,  subtitle);

    ImVec2 textSize = ImGui::CalcTextSize(name);
    ImVec2 tickCenter = namePos + ImVec2(textSize.x + 6.0f, ImGui::GetFontSize()*0.5f);
    float rTick = ImGui::GetFontSize() * 0.4f;
    dl->AddCircleFilled(tickCenter, rTick, IM_COL32(0,150,255,255));
    ImVec2 pts[3] = {
        tickCenter + ImVec2(-rTick*0.45f,  0.0f),
        tickCenter + ImVec2(-rTick*0.15f,  rTick*0.30f),
        tickCenter + ImVec2( rTick*0.35f, -rTick*0.40f)
    };
    dl->AddPolyline(pts, 3, IM_COL32(255,255,255,255), false, 1.5f);

    if (held)
        dl->AddRect(p, p + size, ring, r, 0, 2.0f);


    if (clicked) {
        OpenURL_iOS("tg://resolve?domain=CMSVN");
    }
}

static id<MTLTexture>
LoadTextureFromBase64_MTK(id<MTLDevice> device,
                        MTKTextureLoader* loader,
                        NSString* base64Str) {

    NSString *b64 = base64Str;
    NSRange comma = [b64 rangeOfString:@","];
    if (comma.location != NSNotFound) b64 = [b64 substringFromIndex:comma.location+1];

    NSData *data = [[NSData alloc] initWithBase64EncodedString:b64 options:0];
    if (!data) { NSLog(@"base64 decode fail"); return nil; }

    NSDictionary *opt = @{
        MTKTextureLoaderOptionSRGB   : @NO,
        MTKTextureLoaderOptionOrigin : MTKTextureLoaderOriginTopLeft
    };
    NSError *err = nil;
    id<MTLTexture> tex = [loader newTextureWithData:data options:opt error:&err];
    if (!tex) NSLog(@"MTKTextureLoader error: %@", err);
    return tex;
}
- (void)drawInMTKView:(MTKView *)view {
    hideRecordTextfield.secureTextEntry = StreamerMode;
    ImGuiIO &io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    static double lastTime = 0.0;
    static int lastSavedCounts = -1;
    double currentTime = CACurrentMediaTime();
    float targetDeltaTime = 1.0f / (float)60.0f;
    io.DeltaTime = (lastTime > 0.0) ? (float)(currentTime - lastTime) : targetDeltaTime;
    lastTime = currentTime;
    self.currentFPS = io.Framerate;

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    self.texLoader = [[MTKTextureLoader alloc] initWithDevice:self.device];

    if (!self.avatarTex) {
        NSString *b64 = AvatarImage;
        self.avatarTex = LoadTextureFromBase64_MTK(self.device, self.texLoader, b64);
    }

    if (MenDeal == true) {
        [menuTouchView setUserInteractionEnabled:YES];
    } else {
        [menuTouchView setUserInteractionEnabled:NO];
    }

    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil) {
        id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@"ImGui Jane"];
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();

        CGFloat width = 360;
        CGFloat height = 270;
        ImGui::SetNextWindowPos(ImVec2((kWidth - width) / 2, (kHeight - height) / 2), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_FirstUseEver);

        const float animationDuration = 0.25f;
        float timeSinceSwitch = (_lastTabSwitchTime > 0) ? (ImGui::GetTime() - _lastTabSwitchTime) : animationDuration;
        _tabAnimationProgress = fminf(1.0f, timeSinceSwitch / animationDuration);
        if (_tabAnimationProgress >= 1.0f && _activeTab != _targetTab) {
            _activeTab = _targetTab;
            TriggerHapticFeedback();
            [self saveSetting];
        }
        auto CheckboxPersist = [&](const char* label, bool* v) {
            if (ImGui::Checkbox(label, v)) {
                [self saveSetting];
                return true;
            }
            return false;
        };

        if (MenDeal) {
            NSString *ver = [NSString stringWithUTF8String:oxorany("1.0")];
            NSString *nm = [[NSBundle mainBundle] objectForInfoDictionaryKey:NSSENCRYPT("CFBundleDisplayName")];
            std::string sName([nm UTF8String]);
            NSString *sv = [[NSBundle mainBundle] objectForInfoDictionaryKey:NSSENCRYPT("CFBundleShortVersionString")];
            std::string Version([sv UTF8String]);

            char *Gnam = (char*)[[NSString stringWithFormat:[NSString stringWithUTF8String:oxorany("Mr Khói - Version: %@ ")], ver] cStringUsingEncoding:NSUTF8StringEncoding];

            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0,0));
            ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar |
                                     ImGuiWindowFlags_NoScrollWithMouse;

            if (ImGui::Begin(Gnam, &MenDeal, flags)) {
                ImDrawList* draw = ImGui::GetWindowDrawList();
                const ImVec2 win_pos  = ImGui::GetWindowPos();
                const ImVec2 win_size = ImGui::GetWindowSize();

                const float bar_h = 28.0f;
                draw->AddRectFilled(win_pos, ImVec2(win_pos.x + win_size.x, win_pos.y + bar_h), ImColor(20,20,20,245), 6.0f);

                float time_anim = ImGui::GetTime();
                int currentDot = (int)floorf(time_anim) % 3;
                ImColor darkColors[3] = { ImColor(100,30,30), ImColor(100,70,30), ImColor(30,100,30) };
                ImColor glowColors[3] = { ImColor(255,50,50,200), ImColor(255,220,100,200), ImColor(130,255,130,200) };
                float cy = win_pos.y + bar_h * 0.5f;
                draw->AddCircleFilled(ImVec2(win_pos.x + 12, cy), 7, currentDot==0?glowColors[0]:darkColors[0], 32);
                draw->AddCircleFilled(ImVec2(win_pos.x + 33, cy), 7, currentDot==1?glowColors[1]:darkColors[1], 32);
                draw->AddCircleFilled(ImVec2(win_pos.x + 54, cy), 7, currentDot==2?glowColors[2]:darkColors[2], 32);

                ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0,0,0,0));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0,0,0,0));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0,0,0,0));
                ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
                ImGui::SetCursorScreenPos(ImVec2(win_pos.x + win_size.x - 28, win_pos.y + 2));
                if (ImGui::Button(oxorany("X"), ImVec2(24,24))) MenDeal = false; 
                ImGui::PopStyleVar();
                ImGui::PopStyleColor(3);

                char title_buf[256];
                snprintf(title_buf, sizeof(title_buf), "%s|v%s", sName.c_str(), Version.c_str());
                ImVec2 title_sz  = ImGui::CalcTextSize(title_buf);
                ImVec2 title_pos = ImVec2(win_pos.x + (win_size.x - title_sz.x) * 0.5f, win_pos.y + (bar_h - title_sz.y) * 0.5f);
                draw->AddText(title_pos, IM_COL32(255,255,0,255), title_buf);

                ImGui::SetCursorPosY(bar_h);
                ImGui::Spacing();
                ImGui::Columns(2, nullptr, false);
                ImGui::SetColumnOffset(1, 120.0f);

                {
                    ImVec4 colorInactive = ImGui::GetStyle().Colors[ImGuiCol_Button];
                    ImVec4 colorActive   = brightAccent;
                    ImVec4 colorHover    = ImGui::GetStyle().Colors[ImGuiCol_ButtonHovered];
                    int tabs[] = {1,2};
                    
                    const char* tabLabels[] = { 
                        oxorany(ICON_FA_WRENCH " FUNCTION"), 
                        oxorany(ICON_FA_COG " INFO") 
                    };
                    
                    ImVec2 buttonSize(100, 25);
                    for (int i=0;i<2;i++) {
                        int tabId = tabs[i];
                        bool isCurrent = (_activeTab == tabId);
                        bool isTarget  = (_targetTab == tabId);
                        bool outAnim   = (isCurrent && !isTarget && _tabAnimationProgress < 1.0f);
                        float t_color  = isTarget ? (isCurrent && !outAnim ? 1.0f : _tabAnimationProgress) : (outAnim ? 1.0f - _tabAnimationProgress : 0.0f);
                        ImVec4 btnCol  = lerp(colorInactive, colorActive, t_color);
                        ImGui::PushStyleColor(ImGuiCol_Button, btnCol);
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, lerp(colorHover, ImVec4(colorActive.x*1.1f, colorActive.y*1.1f, colorActive.z*1.1f, colorActive.w), t_color));
                        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  lerp(colorActive, secondaryAccent, t_color));
                        ImGui::PushStyleColor(ImGuiCol_Text, isTarget ? ImVec4(0,0,0,1) : whiteText);
                        if (ImGui::Button(tabLabels[i], buttonSize)) {
                            if (_targetTab != tabId) { _targetTab = tabId; _lastTabSwitchTime = ImGui::GetTime(); }
                        }
                        ImGui::PopStyleColor(4);
                        ImGui::Spacing();
                    }
                }

                char fpsBuf[64];
                snprintf(fpsBuf, sizeof(fpsBuf), oxorany("%.0f FPS"), ImGui::GetIO().Framerate);

                DrawProfileChip(oxorany("Ông Nông"), fpsBuf, (ImTextureID)(uintptr_t)(__bridge void*)self.avatarTex, ImGui::GetContentRegionAvail().x);

                ImGui::NextColumn();
                {
                    float contentAlpha = 1.0f;
                    int tabToRender = _activeTab;
                    if (_activeTab != _targetTab && _tabAnimationProgress < 1.0f) {
                        tabToRender = _targetTab; contentAlpha = _tabAnimationProgress;
                    }
                    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, contentAlpha);
                    float contentWidth = ImGui::GetColumnWidth() - ImGui::GetStyle().WindowPadding.x;

                    if (tabToRender == 1) {
                        CustomTextNeon(oxorany(ICON_FA_WRENCH " FUNCTION"));
                        ImGui::BeginChild("##khung0", ImVec2(contentWidth, 400.0f), true);

                        CheckboxPersist(oxorany("Enable"), &Vars.Enable);
                        CheckboxPersist(oxorany("History"), &Vars.history);
                        ImGui::Spacing();
                        bool wifiOn = !Vars.disconnect;
                        ImVec4 wifiColor = wifiOn ? ImVec4(0.12f, 0.82f, 0.24f, 1.0f) : ImVec4(0.92f, 0.16f, 0.16f, 1.0f);
                        ImGui::PushStyleColor(ImGuiCol_Button, wifiColor);
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, wifiColor);
                        ImGui::PushStyleColor(ImGuiCol_ButtonActive, wifiColor);
                        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
                        ImVec2 wifiButtonPos = ImGui::GetCursorScreenPos();
                        if (ImGui::Button(wifiOn ? oxorany("  Wi-Fi ON##wifi") : oxorany("  Wi-Fi OFF##wifi"), ImVec2(contentWidth - 12.0f, 32.0f))) {
                            [self handleWifiTap];
                        }
                        ImDrawList *wifiDraw = ImGui::GetWindowDrawList();
                        ImVec2 wifiCenter(wifiButtonPos.x + 18.0f, wifiButtonPos.y + 24.0f);
                        ImU32 wifiInk = IM_COL32(255, 255, 255, 255);
                        for (int ring = 0; ring < 3; ++ring) {
                            float radius = 5.0f + ring * 4.0f;
                            const int steps = 16;
                            for (int segment = 0; segment < steps; ++segment) {
                                float a = 3.75f + (5.67f - 3.75f) * segment / steps;
                                float b = 3.75f + (5.67f - 3.75f) * (segment + 1) / steps;
                                wifiDraw->AddLine(ImVec2(wifiCenter.x + cosf(a) * radius, wifiCenter.y + sinf(a) * radius), ImVec2(wifiCenter.x + cosf(b) * radius, wifiCenter.y + sinf(b) * radius), wifiInk, 1.8f);
                            }
                        }
                        wifiDraw->AddCircleFilled(wifiCenter, 2.3f, wifiInk, 12);
                        ImGui::PopStyleColor(4);


                        ImGui::Spacing();
                        ImGui::Separator();

                        CheckboxPersist(oxorany("Reset on Target"), &Vars.resetOnTarget);
                        
                        int oldTarget = Vars.target;
                        bool attack = (Vars.target == 3);
                        bool raid = (Vars.target == 4);
                        bool symbol = (Vars.target == 30);
                        bool spin = (Vars.target == 6);
                        bool poin = (Vars.target == 54); 
                        
                        if (ImGui::Checkbox(oxorany("Attack"), &attack)) { Vars.target = attack ? 3 : 0; [self saveSetting]; }
                        if (ImGui::Checkbox(oxorany("Raid"), &raid)) { Vars.target = raid ? 4 : 0; [self saveSetting]; }
                        if (ImGui::Checkbox(oxorany("Symbol"), &symbol)) { Vars.target = symbol ? 30 : 0; [self saveSetting]; }
                        if (ImGui::Checkbox(oxorany("Spin"), &spin)) { Vars.target = spin ? 6 : 0; [self saveSetting]; }
                        if (ImGui::Checkbox(oxorany("Poin"), &poin)) { Vars.target = poin ? 54 : 0; [self saveSetting]; }

                        if (Vars.target != oldTarget) {
                            Vars.countAttack = 0; Vars.countRaid = 0; Vars.countSymbol = 0; Vars.countSpin = 0; Vars.countPoin = 0;
                            Vars.historyAttack.clear(); Vars.historyRaid.clear(); Vars.historySymbol.clear(); Vars.historySpin.clear(); Vars.historyPoin.clear(); 
                            [self saveSetting];
                        }

                        if(Vars.lastSymbol1 == Vars.lastSymbol2 && Vars.lastSymbol2 == Vars.lastSymbol3 && Vars.lastSymbol1 >= 0){
                            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.0f, 1.0f, 0.0f, 1.0f));
                            ImGui::Text(oxorany("Copyright © 2026 Mr Khói. All rights reserved."), Vars.lastSymbol1, Vars.lastSymbol2, Vars.lastSymbol3);
                            ImGui::PopStyleColor();
                        }
                        ImGui::EndChild();
                    } 
                    else if (tabToRender == 2) {
                        CustomTextNeon(oxorany(ICON_FA_COG " UPDATE MANAGER"));
                        ImGui::BeginChild("##khung1", ImVec2(contentWidth, 400.0f), true);
                        
                        ImGui::Text("%s", oxorany("Phiên bản hiện tại: 1.0"));
                        if (self.serverVersion != nil) {
                            ImGui::Text("%s %s", oxorany("Phiên bản Server:"), [self.serverVersion UTF8String]);
                        } else {
                            ImGui::Text("%s", oxorany("Phiên bản Server: Đang kiểm tra..."));
                        }
                        
                        ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
                        
                        if (self.isUpdateAvailable) {
                            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
                            ImGui::Text("%s", oxorany("⚠ Đã có bản cập nhật mới!"));
                            ImGui::PopStyleColor();
                            ImGui::Spacing();
                            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.6f, 0.0f, 1.0f));
                            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 0.8f, 0.0f, 1.0f));
                            if (ImGui::Button(oxorany("Tải Bản Cập Nhật Ngay"), ImVec2(ImGui::GetContentRegionAvail().x, 35))) {
                                if (self.updateUrl) OpenURL_iOS([self.updateUrl UTF8String]);
                            }
                            ImGui::PopStyleColor(2);
                        } else {
                            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.3f, 1.0f, 0.3f, 1.0f));
                            ImGui::Text("%s", oxorany("✔ Bạn đang dùng bản mới nhất."));
                            ImGui::PopStyleColor();
                            ImGui::Spacing();
                            if (ImGui::Button(oxorany("Kiểm Tra Cập Nhật"), ImVec2(ImGui::GetContentRegionAvail().x, 35))) {
                                [self fetchServerConfig]; 
                                [self showToastMessage:[NSString stringWithUTF8String:oxorany("Đang kiểm tra cập nhật...")]];
                            }
                        }
                        ImGui::EndChild();
                    }
                    ImGui::PopStyleVar(); 
                }
                ImGui::Columns(1);
            }
            ImGui::End();
            ImGui::PopStyleVar(); 
        }

        [self refreshSpeedHud];

        int currentTotalCounts = Vars.countAttack + Vars.countRaid + Vars.countSymbol + Vars.countSpin + Vars.countPoin;
        if (lastSavedCounts != currentTotalCounts) {
            lastSavedCounts = currentTotalCounts;
            [self saveSetting];
        }

        if (Vars.Enable && Vars.speedEnabled && Vars.speed != 1.0f){ oSetTimeScale(Vars.speed, nullptr); }
        else { oSetTimeScale(1.0f, nullptr); }

        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];
        [commandBuffer presentDrawable:view.currentDrawable];
    }
    [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {
}

- (void)updateIOWithTouchEvent:(UIEvent *)event {
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}
@end